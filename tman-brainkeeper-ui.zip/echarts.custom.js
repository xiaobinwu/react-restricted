
// 引入 echarts 主模块。
export * from 'echarts/src/echarts';
// 引入饼图。
import 'echarts/src/chart/pie';
// 引入柱形图。
import 'echarts/src/chart/bar';
// 引入graph图。
import 'echarts/src/chart/graph';
// 引入折线图。
import 'echarts/src/chart/line';
// 引入散点图。
import 'echarts/src/chart/scatter';
// 涟漪特效动画的散点（气泡）图。
import 'echarts/src/chart/effectScatter';
// 引入地图。
import 'echarts/src/chart/map';
// 引入雷达图。
import 'echarts/src/chart/radar';

// 引入组件
// import 'echarts/src/component/angleAxis';
import 'echarts/src/component/axis';
import 'echarts/src/component/axisPointer';
// import 'echarts/src/component/brush';
// import 'echarts/src/component/calendar';
// import 'echarts/src/component/dataset';
import 'echarts/src/component/dataZoom';
import 'echarts/src/component/dataZoomInside';
import 'echarts/src/component/dataZoomSelect';
import 'echarts/src/component/geo';
import 'echarts/src/component/graphic';
import 'echarts/src/component/grid';
import 'echarts/src/component/gridSimple';
import 'echarts/src/component/legend';
// import 'echarts/src/component/legendScroll';
import 'echarts/src/component/markArea';
// import 'echarts/src/component/markLine';
import 'echarts/src/component/markPoint';
// import 'echarts/src/component/parallel';
// import 'echarts/src/component/parallelAxis';
// import 'echarts/src/component/polar';
import 'echarts/src/component/radar';
// import 'echarts/src/component/radiusAxis';
// import 'echarts/src/component/singleAxis';
// import 'echarts/src/component/timeline';
import 'echarts/src/component/title';
import 'echarts/src/component/toolbox';
import 'echarts/src/component/tooltip';
import 'echarts/src/component/visualMap';
// import 'echarts/src/component/visualMapContinuous';
// import 'echarts/src/component/visualMapPiecewise';