import { createStore, combineReducers } from 'redux';
import userReducer from './reducers/userReducer';
import routeReducer from './reducers/routeReducer';
import themeReducer from './reducers/themeReducer';
import viewReducer from './reducers/viewReducer';

const reducers = combineReducers({
    userState: userReducer,
    routeState: routeReducer,
    themeState: themeReducer,
    viewState: viewReducer
});

const store = createStore(reducers);

export default store;
