const initialState = {
    taskQueueServerKeys: []
};

/* 页面层级的Reducer */
const viewReducer = (state = initialState, action) => {
    // 延时调度-任务队列
    if (action.type === 'SET_TASK_QUEUE_SERVERKEYS') {
        return Object.assign({}, state, {
            taskQueueServerKeys: action.taskQueueServerKeys
        });
    }
    return state;
};

export default viewReducer;
