const initialState = {
    loadThemePending: true,
    pending: true,
    logged: false,
    username: '',
    account: '',
    permissions: [],
    needCode: false
};

const userReducer = (state = initialState, action) => {
    if (action.type === 'SET_LOGGED_USER') {
        return Object.assign({}, state, {
            logged: action.logged,
            username: action.username,
            account: action.account,
            pending: false
        });
    }
    if (action.type === 'SET_THEME_PENDING') {
        return Object.assign({}, state, {
            loadThemePending: false
        });
    }
    if (action.type === 'SET_PERMISSIONS') {
        return Object.assign({}, state, {
            permissions: action.permissions
        });
    }
    if (action.type === 'SET_NEEDCODE') {
        return Object.assign({}, state, {
            needCode: action.needCode
        });
    }
    return state;
};

export default userReducer;
