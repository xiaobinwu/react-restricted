const initialState = {
    theme: 'halloween',
    antd: 'dark'
};

const themeReducer = (state = initialState, action) => {
    if (action.type === 'SET_THEME') {
        return Object.assign({}, state, {
            theme: action.theme
        });
    }
    if (action.type === 'SET_ANTD') {
        return Object.assign({}, state, {
            antd: action.antd
        });
    }
    return state;
};

export default themeReducer;
