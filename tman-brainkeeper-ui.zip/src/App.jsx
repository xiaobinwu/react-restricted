
import React, { Component } from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import store from 'rRedux/store';
import Auth from 'pages/auth';
import Alram from 'pages/alram'; // 告警详情页,免登录
import BaseLayout from 'pages/baseLayout';
import { setTheme } from 'js/theme';
import { storage } from 'js/util';
import { THEME } from 'js/variable';

import AuthorizedRoute from './authorizedRoute';

class App extends Component {
    componentDidMount() {
        const tmanTheme = storage.getStore(THEME);
        if (tmanTheme) {
            const tmanThemeJson = JSON.parse(tmanTheme);
            if (tmanThemeJson.antd !== 'dark') {
                setTheme(tmanThemeJson).then(() => {
                    store.dispatch({
                        type: 'SET_THEME_PENDING',
                        loadThemePending: false
                    });
                });
            } else {
                store.dispatch({
                    type: 'SET_THEME_PENDING',
                    loadThemePending: false
                });
            }
        } else {
            store.dispatch({
                type: 'SET_THEME_PENDING',
                loadThemePending: false
            });
        }
    }
    render() {
        return (
            <Provider store={store}>
                <BrowserRouter>
                    <Switch>
                        <Route path="/alarm" component={Alram} />
                        <Route path="/auth" component={Auth} />
                        <AuthorizedRoute path="/" component={BaseLayout} />
                    </Switch>
                </BrowserRouter>
            </Provider>
        );
    }
}

export default App;
