
import error from 'img/404.png';
import React from 'react';

const NoMatch = ({ location }) => {
    return (
        <h3 style={{ textAlign: 'center' }}>
            <img alt="404" style={{ width: '500px', height: 'auto' }} src={error} />
            OOPS! The aliens took your page... No match for <code className="system-colony-caution-color">{location.pathname}</code>
        </h3>
    );
};

export default NoMatch;
