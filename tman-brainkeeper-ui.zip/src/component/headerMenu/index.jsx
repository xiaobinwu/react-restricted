import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Icon } from 'antd';
import { connect } from 'react-redux';
import store from 'rRedux/store';
import { storage, deepCopy } from 'js/util';
import { CURRENTNAVID } from 'js/variable';
import styles from './index.css';

const { SubMenu } = Menu;

class HeaderMenu extends Component {
    constructor(props) {
        super(props);
        this.state = {
            headerMenuSelectedKey: ['1'] // 默认为route配置文件的第一个菜单id
        };
    }
    UNSAFE_componentWillMount() { // eslint-disable-line
        this.view = this.reduceMenu(this.props.navData);
        this.handleLocation(this.props.location);
    }
    componentDidMount() {
        // 监听全局路由（除auth）的变化
        this.unlisten = this.props.history.listen((location, action) => {
            console.log(location);
            this.handleLocation(location);
        });
    }
    componentWillUnmount() {
        if (this.unlisten) {
            this.unlisten();
        }
    }
    // 更换当前站点,值为站点id，更新store
    changeSite = (currentSite, currentLocation) => {
        storage.setStore(CURRENTNAVID, Array.isArray(currentSite) ? currentSite[0] : currentSite);
        store.dispatch({
            type: 'SET_SITE',
            currentSite
        });
        store.dispatch({
            type: 'SET_LOCATION',
            currentLocation: window.location.pathname
        });
    }
    // 更换当前面包屑，更新store
    changeBreadCrumb = (e) => {
        if (e.key) {
            store.dispatch({
                type: 'SET_BREADCRUMB',
                breadCrumb: e.item.props.breadcrumb.split('/')
            });
        } else if (e.domEvent) {
            e.domEvent.stopPropagation();
        }
    }
    // 匹配当前{location}获取顶部菜单栏默认selectedKey（以路由配置表的id为key）
    handleLocation = ({ pathname }) => {
        const { navData } = this.props;
        const { routeState } = store.getState();
        let defaultSelectedKeys;
        if (navData.children && navData.children.length > 0) {
            const firstTopMenu = navData.children[0];
            if (this.checkSubNav(firstTopMenu)) {
                defaultSelectedKeys = String(firstTopMenu.children[0].id);
            } else {
                defaultSelectedKeys = String(firstTopMenu.id);
            }
        }
        let headerMenuSelectedKey;
        if (pathname === '/') {
            headerMenuSelectedKey = [defaultSelectedKeys || routeState.currentSite];
        } else {
            headerMenuSelectedKey = this.matchHeaderMenuSelectedKey(pathname);
        }
        this.changeSite(headerMenuSelectedKey || [defaultSelectedKeys || routeState.currentSite]);
        this.setState({
            headerMenuSelectedKey
        });
    }
    // 匹配选中的顶级菜单
    matchHeaderMenuSelectedKey = (pathname) => {
        let headerMenuSelectedKey;
        const { equaledMenu } = this.props;
        // 可能存在多个url相同的情况，但是所属顶级菜单不一样
        const selectedKeys = Object.keys(equaledMenu).filter((item, index) => {
            return equaledMenu[item].url === pathname;
        });
        const traversing = (selectedKey) => {
            let menuSelectedKey;
            while (equaledMenu[selectedKey] && equaledMenu[selectedKey].id && !this.checkSubNav(equaledMenu[selectedKey])) {
                menuSelectedKey = [String(equaledMenu[selectedKey].id)];
                selectedKey = equaledMenu[selectedKey].parentId;
            }
            return menuSelectedKey;
        };
        if (selectedKeys.length === 1) {
            headerMenuSelectedKey = traversing(selectedKeys[0]);
        } else if (selectedKeys.length > 1) {
            const currentNavId = storage.getStore(CURRENTNAVID);
            const menuSelectedKeys = [];
            selectedKeys.forEach((item, index) => {
                menuSelectedKeys.push(traversing(item));
            });
            headerMenuSelectedKey = menuSelectedKeys.findIndex((item, index) => item[0] === currentNavId) > -1 ? [currentNavId] : menuSelectedKeys[0];
        }
        return headerMenuSelectedKey;
    }
    // 拼凑顶部菜单栏的href，以及获取面包屑（用来更新store）
    reducePath = (item) => {
        let backPath = '';
        const backName = [];
        let pathObj = deepCopy(item);
        while (pathObj.children && pathObj.children.length > 0) {
            if (pathObj.children[0].type !== 3) {
                backPath = pathObj.children[0].url;
                backName.push(pathObj.children[0].name);
            }
            pathObj = pathObj.children[0]; // eslint-disable-line
        }
        if (backName.length === 0) {
            // 没有权限时，面包屑需要回滚为空
            store.dispatch({
                type: 'SET_BREADCRUMB',
                breadCrumb: []
            });
        }
        return {
            backPath,
            backName: backName.join('/')
        };
    }
    // 阻止submenu默认行为
    titleClick = (e) => {
        e.domEvent.stopPropagation();
        e.domEvent.preventDefault();
    }
    // 检查是否为subMenu,目前只支持创建二级顶级菜单
    checkSubNav = (item) => {
        return item.children.length > 0 && item.children.some((it, index) => {
            return it.type === 1;
        });
    }
    // 拼凑顶部菜单栏
    reduceMenu = (navData) => {
        const subNavData = {};
        const subMenuData = [];
        const menuData = navData.children.map((item, i) => {
            if (this.checkSubNav(item)) {
                const parent = JSON.stringify({
                    id: item.id,
                    icon: item.icon,
                    sort: item.sort,
                    name: item.name
                });
                subNavData[parent] = item.children;
                return null;
            }
            return this.getMenuItem(item);
        }).filter(item => item !== null);

        Object.keys(subNavData).forEach((item) => {
            const parseItem = JSON.parse(item);
            subMenuData.push(<SubMenu key={parseItem.id} order={parseItem.sort} title={
                <span>
                    {parseItem.icon && <Icon type={parseItem.icon} />}
                    <span>{parseItem.name}</span>
                </span>
            } onTitleClick={this.titleClick}>
                {
                    subNavData[item].map((it, i) => this.getMenuItem(it))
                }
            </SubMenu>);
        });
        const menus = [...menuData, ...subMenuData];
        menus.sort((a, b) => {
            return a.props.order - b.props.order;
        });
        return menus;
    }
    // 切换选中项
    handleSelectedChange = (item) => {
        this.setState({
            headerMenuSelectedKey: [item.key]
        });
    }
    // 返回顶部菜单submenu的menuItem
    getMenuItem(it) {
        const { backPath, backName } = this.reducePath(it);
        // changeSite需要bind绑定，不然会触发多次
        return backPath !== '' ?
            <Menu.Item key={it.id} order={it.sort} className={styles.menuItem} breadcrumb={`${it.name}/${backName}`}>
                <Icon type={it.icon} />
                <Link to={backPath} onClick={this.changeSite.bind(this, String(it.id))}>{it.name}</Link>
            </Menu.Item> : null;
    }
    render() {
        const { headerMenuSelectedKey } = this.state;
        const { antd } = this.props;
        const { view } = this;
        return (
            <Menu mode="horizontal" theme={antd} onSelect={this.handleSelectedChange} selectedKeys={headerMenuSelectedKey} className={`${styles.nav} system-nav`} onClick={this.changeBreadCrumb}>
                { view }
            </Menu>
        );
    }
}

const stateToProps = ({ themeState }) => ({
    antd: themeState.antd
});

export default connect(stateToProps)(HeaderMenu);
