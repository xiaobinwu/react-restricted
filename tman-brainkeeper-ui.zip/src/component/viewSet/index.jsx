import React, { Component } from 'react';
import routeSet from 'route/index';
import routeToComponentSet from 'route/routeToComponent';
import { Route, Switch } from 'react-router-dom';
import { withRouter } from 'react-router';
import store from 'rRedux/store';
import NoMatch from '../noMatch';

const paths = {};
const childrenHasNotInMenuBarRoute = [];
class ViewSet extends Component {
    constructor(props) {
        super(props);
        this.state = {
            views: [],
            defaultView: ''
        };
    }
    UNSAFE_componentWillMount() { // eslint-disable-line
        const walkRoutes = this.walkRoutes(this.props.navData.children);
        const views = [...walkRoutes, ...childrenHasNotInMenuBarRoute];
        store.dispatch({
            type: 'SET_PATHS',
            paths: { ...paths }
        });
        this.setState({
            views
        });
    }
    // 判断是否为功能项
    checkFeatures = (item) => {
        return item.children.some((it, index) => {
            return it.type === 3;
        });
    }
    walkRoutes = (routes, index) => routes.map((item, i) => {
        const routekey = typeof (index) !== 'undefined' ? `${index}-${i}` : `${i}`;
        const component = routeToComponentSet[item.url];
        if (item.children && item.children.length > 0) {
            if (this.checkFeatures(item)) {
                const route = <Route key={item.id} path={item.url} component={routeSet[component]} />;
                paths[component] = {
                    key: item.id, // 路由表的key值，用于后面权限管理
                    linkPath: item.url
                };
                childrenHasNotInMenuBarRoute.push(route);
            }
            return this.walkRoutes(item.children, routekey);
        }
        paths[component] = {
            key: item.id, // 路由表的key值，用于后面权限管理
            linkPath: item.url
        };
        const isBasePath = routekey.split('-').reduce((accumulator, currentValue) => Number(accumulator) + Number(currentValue), 0) === 0;
        if (isBasePath) {
            this.setState({
                defaultView: component
            });
        }
        return (
            <Route key={item.id} path={item.url} component={routeSet[component]} />
        );
    })
    render() {
        const { views, defaultView } = this.state;
        return (
            <Switch>
                <Route exact path="/" component={routeSet[defaultView]} />
                { views }
                {/* 404 */}
                <Route component={NoMatch} />
            </Switch>
        );
    }
}

export default withRouter(ViewSet);
