import React, { Component } from 'react';

// 高阶函数，获取由高阶函数包装的原始组件的Ref
// 由Form.create()高级函数包含的，可以直接使用wrappedComponentRef获取
const withRef = (WrappedComponent) => {
    return class extends Component {
        render() {
            const props = { ...this.props };
            const { getInstance } = props;
            if (typeof getInstance === 'function') {
                props.ref = getInstance;
            }
            return (
                <WrappedComponent {...props} />
            );
        }
    };
};

export default withRef;
