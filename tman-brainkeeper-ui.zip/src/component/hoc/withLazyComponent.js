import React, { Component, Suspense } from 'react';
import { Spin } from 'antd';
import lazyWithPreload from './lazyWithPreload';

const loadding = <Spin tip="Loading..." style={{ minHeight: '100%' }}>
    <div style={{
        minHeight: '800px',
        height: '100vh'
    }}>
    </div>
</Spin>;

// 高阶函数，返回Suspense包装组件
const withLazyComponent = (factory) => {
    const LazyPreComponent = lazyWithPreload(factory);
    class LazyComponent extends Component {
        render() {
            const props = { ...this.props };
            return (
                <Suspense fallback={loadding}>
                    <LazyPreComponent {...props} />
                </Suspense>
            );
        }
    }
    LazyComponent.preload = factory;
    return LazyComponent;
};

export default withLazyComponent;
