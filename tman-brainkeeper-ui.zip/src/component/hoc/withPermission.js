import store from 'rRedux/store';

// 处理权限配置导致功能性组件的显示与隐藏
const withPermission = (WrappedComponent, permissionName) => {
    const { userState, routeState } = store.getState();
    const { permissions } = userState;
    const { paths } = routeState;
    if (paths[permissionName]) {
        const { linkPath } = paths[permissionName];
        if (linkPath) {
            if (permissions.includes(linkPath)) {
                return WrappedComponent;
            }
        }
    }
    return null;
};

// 收集页面功能性操作展示权限
export const hanlePermission = (entry) => {
    const permissions = [];
    const walkEntry = (source) => {
        if (source.type === 3) {
            permissions.push(source.url);
        }
        if (source.children && source.children.length > 0) {
            source.children.forEach((element) => {
                walkEntry(element);
            });
        }
    };
    walkEntry(entry);
    store.dispatch({
        type: 'SET_PERMISSIONS',
        permissions
    });
};

export default withPermission;
