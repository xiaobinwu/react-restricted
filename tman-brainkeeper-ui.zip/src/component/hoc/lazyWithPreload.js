
import { lazy } from 'react';

// lazy函数增强, 预加载组件
const lazyWithPreload = (factory) => {
    const Component = lazy(factory);
    Component.preload = factory;
    return Component;
};

export default lazyWithPreload;
