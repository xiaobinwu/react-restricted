import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { ContextMenu, MenuItem, ContextMenuTrigger } from 'react-contextmenu';
import './index.css';

class CustomContextMenu extends Component {
    render() {
        const {
            id,
            name,
            menuItem
        } = this.props;
        return (
            <div className="system-contextMenu">
                <ContextMenuTrigger id={id}>
                    {name}
                </ContextMenuTrigger>
                <ContextMenu id={id}>
                    {
                        menuItem.map((item, index) => {
                            return (
                                <React.Fragment key={index}>
                                    <MenuItem data={item.prop} onClick={item.onClick}>
                                        {item.name}
                                    </MenuItem>
                                    {
                                        item.divider ? <MenuItem divider /> : null
                                    }
                                </React.Fragment>
                            );
                        })
                    }
                </ContextMenu>
            </div>
        );
    }
}

CustomContextMenu.propTypes = {
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    menuItem: PropTypes.arrayOf(PropTypes.shape({
        name: PropTypes.string.isRequired,
        prop: PropTypes.object.isRequired,
        onClick: PropTypes.func.isRequired,
        divider: PropTypes.bool
    }))
};

export default CustomContextMenu;
