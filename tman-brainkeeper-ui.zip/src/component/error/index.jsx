import React, { Component } from 'react';
import { Row, Col } from 'antd';

class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: false,
            info: null
        };
    }
    componentDidCatch(error, info) {
        this.setState({
            error,
            info
        });
    }
    render() {
        const {
            error,
            info
        } = this.state;
        const { children } = this.props;
        if (error) {
            return (
                <div className="system-error">
                    <Row gutter={20}>
                        <Col span={12} className="system-error-space-container">
                            <div className="system-error-space">
                                <div className="system-error-planet">
                                    <div className="system-error-planetShadow"></div>
                                    <div className="system-error-crater1"></div>
                                    <div className="system-error-crater2"></div>
                                    <div className="system-error-crater3"></div>
                                    <div className="system-error-crater4"></div>
                                </div>
                                <div className="system-error-stars">
                                    <div className="system-error-star"></div>
                                    <div className="system-error-star system-error-pink"></div>
                                    <div className="system-error-star system-error-blue"></div>
                                    <div className="system-error-star system-error-yellow"></div>
                                </div>
                            </div>
                        </Col>
                        <Col span={12}>
                            <h2 className="system-error-title">Oh-no! Something went wrong</h2>
                            <p className="system-error-item">{error && error.toString()}</p>
                            <div className="system-error-title">Component Stack Error Details: </div>
                            <div className="system-error-stackContent">
                                {
                                    info && info.componentStack.split('\n').map((i, index) => {
                                        return (
                                            <p className="system-error-item" key={index}>
                                                {i}
                                            </p>
                                        );
                                    })
                                }
                            </div>
                        </Col>
                    </Row>
                </div>
            );
        }
        return children;
    }
}

export default ErrorBoundary;
