import React, { Component } from 'react';
import { Form, Input } from 'antd';

const FormItem = Form.Item;

class ResetPasswordForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            confirmDirty: false
        };
    }
    validateToNextPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && this.state.confirmDirty) {
            form.validateFields(['confirmNewPassword'], { force: true });
        }
        callback();
    }
    handleConfirmBlur = (e) => {
        const { value } = e.target;
        this.setState({ confirmDirty: this.state.confirmDirty || !!value });
    }
    compareToFirstPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && value !== form.getFieldValue('newPassword')) {
            callback('前后密码不一致');
        } else {
            callback();
        }
    }
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        return (
            <Form>
                <FormItem label="旧密码" {...formItemLayout}>
                    {getFieldDecorator('oldPassword', {
                        initialValue: injectForm.oldPassword,
                        rules: [{
                            required: true, message: '请输入您的旧密码',
                        }]
                    })(<Input type="password"/>)}
                </FormItem>
                <FormItem label="新密码" {...formItemLayout}>
                    {getFieldDecorator('newPassword', {
                        initialValue: injectForm.newPassword,
                        rules: [{
                            required: true, message: '请输入您的新密码',
                        }, {
                            validator: this.validateToNextPassword,
                        }]
                    })(<Input type="password"/>)}
                </FormItem>
                <FormItem label="确认密码" {...formItemLayout}>
                    {getFieldDecorator('confirmNewPassword', {
                        initialValue: injectForm.confirmNewPassword,
                        rules: [{
                            required: true, message: '请输入确认后密码',
                        }, {
                            validator: this.compareToFirstPassword,
                        }]
                    })(<Input type="password" onBlur={this.handleConfirmBlur}/>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(ResetPasswordForm);
