import React, { Component } from 'react';
import { Icon, Menu, Button, message } from 'antd';
import { connect } from 'react-redux';
import { setTheme } from 'js/theme';
import { userService } from 'service';
import store from 'rRedux/store';
import { MENUSLIST, GATEWAY } from 'js/variable';
import { storage } from 'js/util';
import withFormModal from 'component/hoc/withFormModal';
import ResetPasswordForm from './resetPasswordForm';
import styles from './index.css';

// 添加/修改告警用户
const ResetPasswordFormModal = withFormModal(ResetPasswordForm);

const { SubMenu } = Menu;
const MenuItemGroup = Menu.ItemGroup;

class AidNav extends Component {
    constructor(props) {
        super(props);
        this.state = {
            resetPasswordForm: {
                oldPassword: '',
                newPassword: '',
                confirmNewPassword: ''
            },
            resetPasswordVisible: false,
            resetPasswordConfirmLoading: false,
        };
    }

    logout = async () => {
        const { code } = await userService.logout();
        if (code === '0') {
            // 退出登录，清除storage
            storage.clearStore(MENUSLIST);
            storage.clearStore(GATEWAY);
            store.dispatch({
                type: 'SET_LOGGED_USER',
                logged: false,
                username: '',
                account: ''
            });
        }
    }
    handleClick = (e) => {
        if (e.key) {
            switch (e.key) {
            case 'resetPassword':
                this.setState({
                    resetPasswordVisible: true
                });
                break;
            case 'user':
                this.logout();
                break;
            default: {
                if (e.key.search(/^theme/) > -1) {
                    setTheme(e.item.props);
                }
            }
            }

        } else if (e.domEvent) {
            e.domEvent.stopPropagation();
        }
    }
    // 阻止submenu默认行为
    titleClick = (e) => {
        e.domEvent.stopPropagation();
        e.domEvent.preventDefault();
    }
    // 获取ref
    getResetPasswordFormRef = (ref) => {
        this.resetPasswordFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.resetPasswordFormRef && this.resetPasswordFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    // 保存
    setResetPasswordSend = async () => {
        this.resetPasswordFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    resetPasswordConfirmLoading: true
                });
                const params = { ...this.resetPasswordFormRef.props.form.getFieldsValue() };
                delete params.confirmNewPassword;
                const res = await userService.resetPassword(params);
                if (res.code === '0') {
                    this.resetPasswordFormRef.props.form.resetFields();
                    this.setState({
                        resetPasswordConfirmLoading: false,
                        resetPasswordVisible: false
                    }, () => {
                        message.success('更新密码成功！');
                    });
                } else {
                    this.setState({
                        resetPasswordConfirmLoading: false
                    });
                }
            }
        });
    }
    render() {
        const { antd, username } = this.props;
        const {
            resetPasswordVisible,
            resetPasswordForm,
            resetPasswordConfirmLoading
        } = this.state;
        const userName = <div><Icon type="user" />{username}</div>;
        return (
            <React.Fragment>
                <Menu onClick={this.handleClick} theme={antd} mode="horizontal" className={`${styles.aidNav} system-aidNav`}>
                    <SubMenu title={<span><Icon type="setting" /></span>} onTitleClick={this.titleClick}>
                        <MenuItemGroup title="主题">
                            <Menu.Item key="theme-1" theme="halloween" antd="dark">酷炫黑（默认）</Menu.Item>
                            <Menu.Item key="theme-3" theme="walden" antd="light">经典白</Menu.Item>
                        </MenuItemGroup>
                    </SubMenu>
                    <SubMenu title={userName} onTitleClick={this.titleClick}>
                        <Menu.Item key="resetPassword">
                            更新密码
                        </Menu.Item>
                        <Menu.Item key="user">
                            退出
                        </Menu.Item>
                    </SubMenu>
                </Menu>
                <ResetPasswordFormModal
                    maskClosable={false}
                    injectForm={resetPasswordForm}
                    getRef={this.getResetPasswordFormRef}
                    title="更新密码"
                    visible={resetPasswordVisible}
                    onOk={this.setResetPasswordSend}
                    onCancel={this.handleCancel.bind(this, 'resetPasswordVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={resetPasswordConfirmLoading} onClick={this.setResetPasswordSend}>
                            确定
                        </Button>
                    ]}
                />
            </React.Fragment>
        );
    }
}

const stateToProps = ({ themeState, userState }) => ({
    antd: themeState.antd,
    username: userState.username
});

export default connect(stateToProps)(AidNav);
