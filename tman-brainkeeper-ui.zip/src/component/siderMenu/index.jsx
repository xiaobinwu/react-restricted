import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Icon } from 'antd';
import { connect } from 'react-redux';
import store from 'rRedux/store';
import { storage, isNotEmptyObject, deepCopy } from 'js/util';
import { CURRENTPAGEID } from 'js/variable';
import styles from './index.css';

const { SubMenu } = Menu;

class SiderMenu extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menuItems: {},
            selectedKeys: ['0'],
            openKeys: ['0-0']
        };
        this.rootSubmenuKeys = [];
    }
    UNSAFE_componentWillMount() { //eslint-disable-line
        // 组件挂载前格式化路由配置，将其变成左侧菜单
        const menuItems = {};
        this.props.navData.children.forEach((item, i) => {
            if (this.checkSubNav(item)) {
                item.children.forEach((it) => {
                    menuItems[it.id] = (it.children && it.children.length > 0) ? this.walkMenu(it.children, it.name) : [];
                });
            } else {
                menuItems[item.id] = (item.children && item.children.length > 0) ? this.walkMenu(item.children, item.name) : [];
            }
        });
        this.setState({
            menuItems
        });
        this.handleLocation(this.props.location, true);
    }
    UNSAFE_componentWillReceiveProps(nextProps) { //eslint-disable-line
        if (this.props.currentSite !== nextProps.currentSite || this.props.currentLocation !== nextProps.currentLocation) {
            this.handleLocation({ pathname: window.location.pathname }, false, nextProps.currentSite);
        }
    }
    // 检查是否为subMenu,目前只支持创建二级顶级菜单
    checkSubNav = (item) => {
        return item.children.length > 0 && item.children.some((it, index) => {
            return it.type === 1;
        });
    }
    // 判断是否为功能项
    checkFeatures = (item) => {
        return item.children && item.children.length > 0 && item.children.some((it, index) => {
            return it.type === 3;
        });
    }
    // 初始状态根据{location}获取左侧菜单栏selectedKey和openKey
    handleLocation = ({ pathname }, isInitial, currentSite) => {
        let siderMenuSelectedKey = '0';
        let siderMenuOpendedKey = [];
        let breadCrumb = [];
        const { navData } = this.props;
        if (navData.children && navData.children.length > 0) {
            if (pathname === '/') {
                let currentRoutes = navData.children[0];
                if (this.checkSubNav(currentRoutes)) {
                    currentRoutes = currentRoutes.children[0]; //eslint-disable-line
                }
                let pathObj = deepCopy(currentRoutes);
                breadCrumb.push(currentRoutes.name);
                while (pathObj.type !== 3 && pathObj.children && pathObj.children.length > 0) {
                    pathObj.id && siderMenuOpendedKey.push(String(pathObj.id));
                    siderMenuSelectedKey = pathObj.children[0].id;
                    breadCrumb.push(pathObj.children[0].name);
                    pathObj = pathObj.children[0]; //eslint-disable-line
                }
            } else {
                const result = this.matchSliderMenuSelectedKey(pathname, currentSite);
                const { keyPaths } = result;
                breadCrumb = breadCrumb.concat(result.breadCrumb);
                keyPaths.length > 0 && (siderMenuSelectedKey = keyPaths[keyPaths.length - 1]);
                if (keyPaths.length > 0) {
                    keyPaths.pop();
                    siderMenuOpendedKey = keyPaths;
                }
            }
            // 初始状态获取面包屑
            store.dispatch({
                type: 'SET_BREADCRUMB',
                breadCrumb
            });
            const state = {};
            if (!isInitial) {
                this.menuRef.handleOpenChange(siderMenuOpendedKey);
            } else {
                state.openKeys = siderMenuOpendedKey;
            }
            state.selectedKeys = [String(siderMenuSelectedKey)];
            this.setState(state);
        }
    }
    // 匹配选中的侧边栏菜单
    matchSliderMenuSelectedKey = (pathname, currentSite) => {
        const { equaledMenu } = this.props;
        // 可能存在多个url相同的情况，但是所属侧边栏菜单不一样
        const selectedKeys = Object.keys(equaledMenu).filter((item, index) => {
            return equaledMenu[item].url === pathname;
        });
        const traversing = (selectedKey) => {
            const breadCrumb = [];
            const keyPaths = [];
            while (equaledMenu[selectedKey] && equaledMenu[selectedKey].id && !this.checkSubNav(equaledMenu[selectedKey])) {
                keyPaths.push(String(equaledMenu[selectedKey].id));
                breadCrumb.push(equaledMenu[selectedKey].name);
                selectedKey = equaledMenu[selectedKey].parentId;
            }
            breadCrumb.reverse();
            keyPaths.reverse();
            return { keyPaths, breadCrumb };
        };
        if (selectedKeys.length === 1) {
            storage.setStore(CURRENTPAGEID, selectedKeys[0]);
            return traversing(selectedKeys[0]);
        } else if (selectedKeys.length > 1) {
            const currentPageId = storage.getStore(CURRENTPAGEID);
            const menuSelectedKeys = [];
            selectedKeys.forEach((item, index) => {
                menuSelectedKeys.push(traversing(item));
            });
            let menuIndex;
            if (currentSite) {
                menuIndex = menuSelectedKeys.findIndex((item, index) => {
                    return item.keyPaths.includes(currentPageId) && item.keyPaths.includes(currentSite);
                });
            } else {
                menuIndex = menuSelectedKeys.findIndex((item, index) => {
                    return item.keyPaths.includes(currentPageId);
                });
            }
            if (menuIndex === -1) {
                const { keyPaths } = menuSelectedKeys[0];
                storage.setStore(CURRENTPAGEID, keyPaths[keyPaths.length - 1]);
                return menuSelectedKeys[0];
            }
            return menuSelectedKeys[menuIndex];
        }
        return { keyPaths: [], breadCrumb: [] };
    }
    // 递归获取左侧菜单栏结构
    walkMenu = (menuSet, name) => {
        const produceMenu = (menus, mName, index) => {
            return menus.map((item, i) => {
                const key = typeof (index) !== 'undefined' ? `${index}-${i}` : `${i}`;
                const linkName = `${mName}/${item.name}`;
                if (item.type === 2 && !this.checkFeatures(item) && item.children && item.children.length > 0) {
                    // 获取根subMenu key值
                    key.length === 1 ? (this.rootSubmenuKeys.push(item.id)) : ''; //eslint-disable-line
                    return (
                        <SubMenu key={item.id} order={item.sort} title={
                            <span>
                                {item.icon && <Icon type={item.icon} />}
                                <span>{item.name}</span>
                            </span>
                        }>
                            {
                                produceMenu(item.children, linkName, key)
                            }
                        </SubMenu>
                    );
                }
                return (
                    <Menu.Item key={item.id} order={item.sort} breadcrumb={linkName}>
                        {item.icon && <Icon type={item.icon} />}
                        <span>{item.name}</span>
                        <Link to={item.url}></Link>
                    </Menu.Item>
                );
            });
        };
        return produceMenu(menuSet, name);
    }
    // menu onClick触发多次
    // https://github.com/ant-design/ant-design/issues/10382
    // 点击左侧菜单栏更改面包屑
    changeBreadCrumb = (e) => {
        if (e.key) {
            store.dispatch({
                type: 'SET_BREADCRUMB',
                breadCrumb: e.item.props.breadcrumb.split('/')
            });
        } else if (e.domEvent) {
            e.domEvent.stopPropagation();
        }
    }
    // 切换选中项
    handleSelectedChange = (item) => {
        storage.setStore(CURRENTPAGEID, item.key);
        this.setState({
            selectedKeys: [item.key]
        });
    }
    // 展开/关闭的回调
    toggleSubmenu = (openKeys) => {
        // if (openKeys.length >= 2) {
        //     console.log(openKeys);
        // }
    }
    render() {
        const { menuItems, selectedKeys, openKeys } = this.state;
        const { currentSite } = this.props;
        // 处理多站点左侧菜单的变化，使用props.openKeys,会导致Menu组件的this.inlineOpenKeys中间存储变量失效，就会出现收缩时的bug
        // 所以使用prop.defaultOpenKeys,可是defaultOpenKeys只会在初始化传入，导致不同系统切换左侧菜单栏打开定位不准，
        // 可以使用ref手动去修改Menu组件中的state.openKeys
        const view = isNotEmptyObject(menuItems) ? <Menu ref={(ref) => { this.menuRef = ref; }} mode="inline" theme="dark" onOpenChange={this.toggleSubmenu} onSelect={this.handleSelectedChange} selectedKeys={selectedKeys} defaultOpenKeys={openKeys} className={styles.sider} onClick={this.changeBreadCrumb}>
            { menuItems[currentSite] }
        </Menu> : null;
        return view;
    }
}
const stateToProps = ({ routeState, themeState }) => ({
    currentSite: routeState.currentSite,
    currentLocation: routeState.currentLocation
});

export default connect(stateToProps)(SiderMenu);
