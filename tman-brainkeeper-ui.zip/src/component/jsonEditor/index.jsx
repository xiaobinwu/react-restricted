import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Spin } from 'antd';
import './editor.css';
import './fixAce.css';

/**
 * @typedef {{
 * tree: string,
 * view: string,
 * form: string,
 * code: string,
 * text: string,
 * allValues: Array<string>
 * }} TJsonEditorModes
 */
const modes = {
    tree: 'tree',
    view: 'view',
    form: 'form',
    code: 'code',
    text: 'text'
};

const values = Object.values(modes);

modes.allValues = values;

/**
 * @constructor JSONEditor(container [, options [, json]])
 * @type {object}
 * @property {object} [value] - 编辑器初始化value
 * @property {string} [mode='tree'] - 设置编辑器mode
 * @property {string} [name=undefined] - 默认情况下，根节点的初始字段名称未定义。也可以使用设置JSONEditor.setName(name)。仅适用于mode“树”，“视图”或“表单”。
 * @property {object} [schema] - 根据JSON模式验证JSON对象。JSON模式描述了JSON对象必须具有的结构，例如必需属性或值必须具有的类型。有关更多信息，请参见http://json-schema.org/。
 * @property {object} [schemaRefs] - 使用选项$ref中设置的JSON模式的属性引用的模式，schema对象结构的形式为{reference_key: schemaObject}
 * @property {Function} [onChange] - 设置当JSONEditor的内容更改时触发的回调函数。没有参数调用。只会在用户所做的更改时触发，而不是通过函数set或程序进行编程更改setText。
 * @property {Function} [onError] -设置发生错误时触发的回调函数。作为第一个参数调用错误。仅针对用户操作触发的错误调用回调，例如从代码模式切换到树模式或在编辑器不包含有效JSON时单击“格式”按钮
 * @property {Function} [onModeChange] - 设置在用户更改模式后立即触发的回调函数。仅适用于用户可以更改模式时（即modes设置选项时）
 * @property {Function} [onLoad] - 编辑器为异步加载，成功加载会执行onLoad
 * @property {object} [ace] - 提供ace编辑器并使用它，适用于mode的code
 * @property {object} [ajv] -提供ajv自定义实例，用于JSON模式验证
 * @property {string} [theme] - 设置ace编辑器主题,默认'ace/theme/jsoneditor'
 * @property {boolean} [history=false] - 启用历史记录，在JSONEditor的菜单中添加按钮撤消和重做， 用于tree、form
 * @property {boolean} [navigationBar=true] - 将导航栏添加到菜单 - 导航栏可视化树结构上的当前位置以及允许面包屑导航，用于tree、form、view
 * @property {boolean} [statusBar=true] - 将状态栏添加到编辑器的底部 - 状态栏显示光标位置和所选字符的计数， 用于code、text模式
 * @property {boolean} [search=true] - 开启搜索框，用于tree、view、form Mode模式
 * @property {Array<string>} [allowedModes] - 开启切换可切换mode
 * @property {string} [tag='div'] - 定义html元素用于渲染
 * @property {object} [htmlElementProps] - 定义html元素的props
 * @property {Function} [innerRef] - 回调ref，用于上层组件获取编辑器ref
 * @property {string} [themeType] - 主题类别，根据这个动态切换基准颜色配置
 */
export default class Editor extends Component {
    static propTypes = {
        //  jsoneditor props
        value: PropTypes.object,
        mode: PropTypes.oneOf(values),
        name: PropTypes.string,
        schema: PropTypes.object,
        schemaRefs: PropTypes.object,

        onChange: PropTypes.func,
        onError: PropTypes.func,
        onModeChange: PropTypes.func,
        onLoad: PropTypes.func,

        ace: PropTypes.object,
        ajv: PropTypes.object,
        theme: PropTypes.string,
        history: PropTypes.bool,
        navigationBar: PropTypes.bool,
        statusBar: PropTypes.bool,
        search: PropTypes.bool,
        allowedModes: PropTypes.arrayOf(PropTypes.oneOf(values)),

        //  custom props
        tag: PropTypes.string,
        htmlElementProps: PropTypes.object,
        innerRef: PropTypes.func,
        themeType: PropTypes.string
    };

    static defaultProps = {
        tag: 'div',
        mode: modes.tree,
        history: false,
        search: true,
        navigationBar: true,
        statusBar: true,
        themeType: 'dark'
    };

    /**
     * @type TJsonEditorModes
     */
    static modes = modes;

    constructor(props) {
        super(props);

        this.htmlElementRef = null;
        this.jsonEditor = null;

        this.handleChange = this.handleChange.bind(this);
        this.setRef = this.setRef.bind(this);
        this.collapseAll = this.collapseAll.bind(this);
        this.expandAll = this.expandAll.bind(this);
        this.focus = this.focus.bind(this);
        this.setValue = this.setValue.bind(this);
        this.getValue = this.getValue.bind(this);

        this.state = {
            isLoading: true
        };
    }

    componentDidMount() {
        const {
            allowedModes,
            innerRef, // eslint-disable-line 
            htmlElementProps, // eslint-disable-line 
            tag, // eslint-disable-line 
            onChange, // eslint-disable-line 
            onLoad, // eslint-disable-line 
            ...rest
        } = this.props;

        // 引入JSONEditor
        import(/* webpackChunkName: 'jsoneditor' */ 'jsoneditor/dist/jsoneditor-minimalist').then((JSONEditor) => {
            this.setState({
                isLoading: false
            }, () => {
                window.JSONEditor = JSONEditor;
                this.createEditor({
                    ...rest,
                    modes: allowedModes
                });
                onLoad && onLoad(this.jsonEditor);
            });
        });
    }

    componentWillReceiveProps({
        allowedModes,
        schema,
        name,
        theme,
        schemaRefs,
        innerRef,
        htmlElementProps,
        tag,
        value,
        onChange,
        ...rest
    }) {
        if (this.jsonEditor) {
            if (theme !== this.props.theme) {
                this.createEditor({
                    ...rest,
                    theme,
                    value: this.jsonEditor.get(), // 重新赋值value，保证更换主题时不报错
                    modes: allowedModes
                });
            } else {
                if (schema !== this.props.schema ||
                    schemaRefs !== this.props.schemaRefs
                ) {
                    this.jsonEditor.setSchema(schema, schemaRefs);
                }

                if (name !== this.jsonEditor.getName()) {
                    this.jsonEditor.setName(name);
                }
            }
        }
    }

    shouldComponentUpdate({ htmlElementProps, themeType }, { isLoading }) {
        return htmlElementProps !== this.props.htmlElementProps || themeType !== this.props.themeType || this.state.isLoading !== isLoading;
    }

    componentWillUnmount() {
        if (this.jsonEditor) {
            this.jsonEditor.destroy();
            this.jsonEditor = null;
        }
    }

    setRef(element) {
        this.htmlElementRef = element;
        if (this.props.innerRef) {
            this.props.innerRef(element);
        }
    }

    createEditor({ value, ...rest }) {
        if (this.jsonEditor) {
            this.jsonEditor.destroy();
        }

        this.jsonEditor = new window.JSONEditor(this.htmlElementRef, {
            onChange: this.handleChange,
            ...rest
        });
        this.jsonEditor.set(value);
    }

    handleChange() {
        if (this.props.onChange) {
            try {
                const text = this.jsonEditor.getText();
                if (text === '') {
                    this.props.onChange(null);
                }
                const currentJson = this.jsonEditor.get();
                if (this.props.value !== currentJson) {
                    this.props.onChange(currentJson);
                }
            } catch (err) {
                this.err = err;
            }
        }
    }

    collapseAll() {
        if (this.jsonEditor) {
            this.jsonEditor.collapseAll();
        }
    }

    expandAll() {
        if (this.jsonEditor) {
            this.jsonEditor.expandAll();
        }
    }

    focus() {
        if (this.jsonEditor) {
            this.jsonEditor.focus();
        }
    }

    setValue(value) {
        if (this.jsonEditor) {
            this.jsonEditor.set(value);
        }
    }

    getValue() {
        if (this.jsonEditor) {
            return this.jsonEditor.get();
        }
        return null;
    }

    render() {
        const {
            htmlElementProps,
            tag,
            themeType
        } = this.props;
        const { isLoading } = this.state;
        return isLoading ?
            (<div style={{ height: '500px', textAlign: 'center', paddingTop: '60px' }}>
                <Spin spinning={isLoading} tip="Loading..."></Spin>
            </div>)
            : React.createElement(
                tag,
                {
                    className: `tman-json-editor tman-json-${themeType}-editor`,
                    ...htmlElementProps,
                    ref: this.setRef
                }
            );
    }
}
