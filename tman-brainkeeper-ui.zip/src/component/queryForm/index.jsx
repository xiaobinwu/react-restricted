import React, { Component } from 'react';
import { Form, Row, Col, Select, DatePicker, Button } from 'antd';
import { linkTrackingService, systemManagementService } from 'service';
import PropTypes from 'prop-types';
import { APPNAME, SERVICENAME, METHODNAME } from 'js/variable';
import { storage } from 'js/util';
import styles from './index.css';


const { Option } = Select;
const { RangePicker } = DatePicker;
const FormItem = Form.Item;

class QueryForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            serviceName: '',
            appList: [],
            serviceSet: [],
            methodSet: {},
            siteOptions: [],
        };
    }
    async UNSAFE_componentWillMount() { // eslint-disable-line
        const {
            service,
            app,
            method,
            site
        } = this.props.baseFormItemsSetting;
        if (app) {
            const { entry } = await systemManagementService.getAllApplications({}, true);
            this.setState({
                appList: entry
            }, () => {
                const { appList } = this.state;
                const filedValues = this.props.form.getFieldsValue();
                const appItem = appList && appList.find((item) => {
                    return item.name === filedValues[app.id];
                });
                if (appItem) {
                    this.handleAppChange(appItem.name, { props: { site: appItem.domain, id: appItem.id } }, () => {
                        this.handleServiceChange(filedValues[service.id]);
                        this.props.form.setFieldsValue({
                            [service.id]: filedValues[service.id],
                            [method.id]: filedValues[method.id]
                        });
                    });
                }
            });
        }
        if (site) {
            const siteOptions = [];
            const { entry } = await linkTrackingService.getAllSite();
            entry.forEach((item) => {
                siteOptions.push({
                    text: JSON.parse(item.value).cnName,
                    value: item.key
                });
            });
            this.setState({
                siteOptions
            });
            if (site.disabledShowAllSite) {
                this.props.form.setFieldsValue({
                    [site.id]: siteOptions[0].value
                });
            }
        }
    }
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    // 触发站点select onChange
    handleSiteChange = (value) => {
        const {
            site
        } = this.props.baseFormItemsSetting;
        site.onChange && site.onChange(value);
    }
    // 触发应用select onChange
    handleAppChange = async (value, option, callback) => {
        const {
            service, method, app
        } = this.props.baseFormItemsSetting;
        app.onChange && app.onChange(value);
        // 存储应用名， 清除服务名、方法名
        const appname = storage.getStore(APPNAME);
        if (appname !== value) {
            storage.setStore(APPNAME, value);
            storage.clearStore(SERVICENAME);
            storage.clearStore(METHODNAME);
        }
        if (service && method) {
            this.props.form.resetFields([
                service.id,
                method.id
            ]);
            service.onChange && service.onChange('');
            if (value === '') {
                return;
            }
            const { site, id } = option.props;
            const { entry } = await linkTrackingService.getAllService({ site, appId: id });
            const serviceSet = [];
            const methodSet = {};
            entry && entry.forEach((item) => {
                serviceSet.push({
                    id: item.id,
                    name: item.name
                });
                methodSet[item.name] = item.methods;
            });
            this.setState({
                serviceSet,
                methodSet
            }, () => {
                callback && callback();
            });
        }
    }
    // 触发服务select Onchange
    handleServiceChange = (value, option) => {
        const {
            service, method
        } = this.props.baseFormItemsSetting;
        // 存储服务名， 清除方法名
        const servicename = storage.getStore(SERVICENAME);
        if (servicename !== value) {
            storage.setStore(SERVICENAME, value);
            storage.clearStore(METHODNAME);
        }
        this.props.form.setFieldsValue({
            [method.id]: ''
        });
        if (value !== '') {
            this.setState({
                serviceName: value
            });
        }
        service.onChange && service.onChange(value);
    }
    // method Onchange
    handleMethodChange = (value, option) => {
        // 存储方法名
        const methodname = storage.getStore(METHODNAME);
        if (methodname !== value) {
            storage.setStore(METHODNAME, value);
        }
    }
    // 处理提交
    hanleSubmit = (e) => {
        // 存储应用名，服务名、方法名
        const {
            service, method, app
        } = this.props.baseFormItemsSetting;
        const { form } = this.props;
        const filedValues = form.getFieldsValue();
        if (app && filedValues[app.id]) {
            storage.setStore(APPNAME, filedValues[app.id]);
        }
        if (service && filedValues[service.id]) {
            storage.setStore(SERVICENAME, filedValues[service.id]);
        }
        if (method && filedValues[method.id]) {
            storage.setStore(METHODNAME, filedValues[method.id]);
        }
        // submit
        this.props.onSubmit(e);
    }
    render() {
        const {
            appList,
            serviceSet,
            methodSet,
            serviceName,
            siteOptions
        } = this.state;
        const {
            form, baseFormItemsSetting, extraFormItem, preFormItem, backFormItem
        } = this.props;
        const {
            app, service, method, rangeTime, button, site
        } = baseFormItemsSetting;
        const {
            getFieldDecorator, getFieldValue
        } = form;
        return (
            <div>
                <Form onSubmit={this.hanleSubmit} className={styles.inlinForm}>
                    <Row gutter={16}>
                        {
                            preFormItem && preFormItem.map((item, index) => {
                                return (<Col span={item.span} key={item.id}>
                                    <FormItem label={item.label} colon={false} className={item.className || ''}>
                                        {getFieldDecorator(item.id, item.options || {})(item.component)}
                                    </FormItem>
                                </Col>);
                            })
                        }
                        {
                            app ? <Col span={app.span || 3} style={app.style}>
                                <FormItem>
                                    {getFieldDecorator(app.id, app.options ? { ...{ initialValue: 'gateway' }, ...app.options } : {})(<Select style={{ width: '100%' }} showSearch optionFilterProp="children" onChange={this.handleAppChange} filterOption={this.filterOption}>
                                        <Option value="">全部(应用名)</Option>
                                        {
                                            appList && appList.map((item, index) => (
                                                <Option key={item.name} title={`${item.name}${item.description ? `(${item.description})` : ''}`} id={item.id} site={item.domain}>{item.name}</Option>
                                            ))
                                        }
                                    </Select>)}
                                </FormItem>
                            </Col> : null
                        }
                        {
                            service ? <Col span={service.span || 5}>
                                <FormItem>
                                    {getFieldDecorator(service.id, service.options || {})(<Select style={{ width: '100%' }} disabled={getFieldValue(app.id) === '' && serviceSet.length === 0} showSearch optionFilterProp="children" onChange={this.handleServiceChange} filterOption={this.filterOption}>
                                        <Option value="">全部(服务名)</Option>
                                        {
                                            serviceSet.map((item, index) => (
                                                <Option key={item.name} title={item.name} style={{ direction: 'rtl' }}>{item.name}</Option>
                                            ))
                                        }
                                    </Select>)}
                                </FormItem>
                            </Col> : null
                        }
                        {
                            method ? <Col span={method.span || 4}>
                                <FormItem>
                                    {getFieldDecorator(method.id, method.options || {})(<Select style={{ width: '100%' }} disabled={getFieldValue(service.id) === ''} showSearch optionFilterProp="children" filterOption={this.filterOption} onChange={this.handleMethodChange}>
                                        <Option value="">全部(方法名)</Option>
                                        {
                                            (serviceName && methodSet[serviceName]) ? methodSet[serviceName].map((item, index) => (
                                                <Option key={item.name} title={`${item.name}${item.description ? `(${item.description})` : ''}`}>{item.name}</Option>
                                            )) : null
                                        }
                                    </Select>)}
                                </FormItem>
                            </Col> : null
                        }
                        {
                            site ? <Col span={site.span || 4}>
                                <FormItem>
                                    {getFieldDecorator(site.id, site.options || {})(<Select style={{ width: '100%' }} onChange={this.handleSiteChange}>
                                        {
                                            !site.disabledShowAllSite ? <Option value="">全部(站点)</Option> : null
                                        }
                                        {
                                            siteOptions.map((item, index) => (
                                                <Option key={item.value} title={item.text}>{item.text}</Option>
                                            ))
                                        }
                                    </Select>)}
                                </FormItem>
                            </Col> : null
                        }
                        {
                            rangeTime ? <Col span={rangeTime.span || 6}>
                                <FormItem>
                                    {getFieldDecorator('rangeTime', rangeTime.options || {})(<RangePicker
                                        showTime
                                        format="YYYY-MM-DD HH:mm:ss"
                                        placeholder={['开始时间', '结束时间']}
                                        style={{ width: '100%' }}
                                        disabled={rangeTime.disabled || false}
                                        { ...rangeTime.extraProps }
                                    />)}
                                </FormItem>
                            </Col> : null
                        }
                        {
                            extraFormItem && extraFormItem.map((item, index) => {
                                return (<Col span={item.span} key={item.id}>
                                    <FormItem label={item.label} colon={false} className={item.className || ''}>
                                        {getFieldDecorator(item.id, item.options || {})(item.component)}
                                    </FormItem>
                                </Col>);
                            })
                        }
                        {
                            backFormItem && backFormItem.map((item, index) => {
                                return (<Col span={item.span} key={item.id}>
                                    <FormItem label={item.label} colon={false} className={item.className || ''}>
                                        {getFieldDecorator(item.id, item.options || {})(item.component)}
                                    </FormItem>
                                </Col>);
                            })
                        }
                        <Col span={button.span || 3}>
                            <FormItem>
                                <Button type="primary" htmlType="submit">查询</Button>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
            </div>
        );
    }
}

QueryForm.propTypes = {
    extraFormItem: PropTypes.array,
    baseFormItemsSetting: PropTypes.object.isRequired,
    onSubmit: PropTypes.func
};
QueryForm.defaultProps = {
    onSubmit: () => {}
};


export default Form.create()(QueryForm);
