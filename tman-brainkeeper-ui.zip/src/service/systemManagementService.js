import Service from './service';

const formDataonfig = {
    headers: {
        'Content-Type': 'multipart/form-data'
    }
};
const urlencodedConfig = {
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
};

class SystemManagementService extends Service {
    /** *************分组管理 start***************** */

    // 获取分组列表
    getGroupList(params = {}) {
        return this.post('/group/list', params);
    }
    // 获取分组列表（分页）
    getGroupPageList(params = {}) {
        return this.post('/group/page', params);
    }

    // 删除分组
    deleteGroup(params = {}) {
        return this.post('/group/del', params);
    }

    // 编辑及添加分组
    operateGroup(params = {}) {
        let url;
        if (!params.id) {
            url = '/group/add';
        } else {
            url = '/group/update';
        }
        return this.post(url, params);
    }

    /** *************分组管理 end***************** */


    /** *************作业管理 start***************** */
    // 获取作业列表
    getJobList(params = {}) {
        return this.post('/job/page', params);
    }

    // 获取作业列表
    deleteJob(params = {}) {
        return this.post('/job/del', params);
    }

    // 修改作业状态
    changeJobStatus(params = {}) {
        const { flag, ...reset } = params;
        if (flag) {
            return this.post('/job/start', reset);
        }
        return this.post('/job/stop', reset);
    }

    // 添加及编辑作业
    operateJob(params = {}) {
        let url;
        if (params.operateStatus === 0) {
            url = '/job/add';
        } else if (params.operateStatus === 1) {
            url = '/job/update';
        }
        delete params.operateStatus;
        const formData = new FormData();
        for (const i in params) {
            if (i === 'jarfile') {
                params[i] && params[i].length > 0 && (formData.append(i, params[i][0]));
            } else {
                formData.append(i, params[i]);
            }
        }
        return this.post(url, formData, formDataonfig);
    }

    /** *************作业管理 end***************** */

    /** ************* 应用管理 start ***************** */

    /* 获取应用列表，不带分页 */
    getAllApplications(params = {}, cache = false) {
        if (cache) {
            return this.requestForCache('/app/all', 'get', params);
        }
        return this.get('/app/all', params);
    }

    /* 获取应用列表，带分页 */
    getAllApplicationsByPage(params = {}) {
        return this.get('/app/getAllByPage', params);
    }

    /* 删除应用 */
    deleteApplication(params = {}) {
        return this.get('/app/delete', params);
    }

    /* 新增、更新应用 */
    setApplicationSend(params = {}) {
        if (params.id) {
            return this.post('/app/update', params, urlencodedConfig);
        }
        return this.post('/app/add', params);
    }

    /* 获取所属域列表、应用类型列表 */
    getConfigList(params = {}, cache = false) {
        if (cache) {
            return this.requestForCache('/config/list', 'post', params);
        }
        return this.post('/config/list', params);
    }

    /* 获取端列表 */
    getPlatFormsList() {
        return [
            {
                text: '全部',
                value: 'ALL'
            },
            {
                text: 'PC',
                value: 'PC'
            },
            {
                text: 'Wap',
                value: 'WAP'
            },
            {
                text: 'IOS',
                value: 'IOS'
            },
            {
                text: 'Android',
                value: 'ANDROID'
            }
        ];
    }

    /** ************* 应用管理 end ***************** */

    /** ************* 菜单管理 start ***************** */
    // 获取菜单树
    getResourceTree(params = {}) {
        return this.get('/sys/resource/getResourceTree', params);
    }
    // 新增菜单树
    saveResource(params = {}) {
        return this.post('/sys/permission-resource/save', params);
    }
    // 更新菜单树
    updateResource(params = {}) {
        return this.post('/sys/permission-resource/update', params);
    }
    // 删除菜单树某项
    deleteResource(params = {}) {
        return this.post('/sys/permission-resource/delete', params, urlencodedConfig);
    }
    /** ************* 菜单管理 end ***************** */

    /** ************* 用户管理 start ***************** */
    // 获取用户列表
    getUserList(params = {}) {
        return this.get('/sys/user/page', params);
    }
    // 保存、修改
    setUserSend(params = {}) {
        if (params.id) {
            return this.post('/sys/user/update', params);
        }
        return this.post('/sys/user/save', params);
    }
    // 删除
    deleteUser(params = {}) {
        return this.post('/sys/user/delete', params, urlencodedConfig);
    }
    // 重置密码
    resetPassword(params = {}) {
        return this.post('/sys/user/password/reset', params, urlencodedConfig);
    }
    // 获取用户绑定的角色
    getBindCharacterById(params = {}) {
        return this.get('/sys/user-role/getRolesByUserId', params);
    }
    // 绑定角色
    bindRole(params = {}) {
        return this.post('/sys/user-role/bindRole', params);
    }
    /** ************* 用户管理 end ***************** */

    /** ************* 角色管理 start ***************** */
    // 获取角色列表
    getCharacterList(params = {}) {
        return this.get('/sys/role/page', params);
    }
    // 获取角色列表，不带分页
    getAllCharacterList(params = {}) {
        return this.get('/sys/role/list', params);
    }
    // 保存、修改
    setCharacterSend(params = {}) {
        if (params.id) {
            return this.post('/sys/role/update', params);
        }
        return this.post('/sys/role/save', params);
    }
    // 删除
    deleteCharacter(params = {}) {
        return this.post('/sys/role/delete', params, urlencodedConfig);
    }
    // 获取所有应用
    getAllApp(params = {}) {
        return this.get('/sys/app/list', params);
    }
    // 获取所有用户
    getAllUser(params = {}) {
        return this.get('/sys/user/list', params);
    }
    // 获取绑定用户
    getBindUserById(params = {}) {
        return this.get('/sys/user-role/list', params);
    }
    // 绑定用户
    setBindUser(params = {}) {
        return this.post('/sys/user-role/save', params);
    }
    // 获取当前用户权限配置
    getPermissionResourceTree(params = {}) {
        return this.get('/sys/role-permission/getResourceTree', params);
    }
    // 保存用户权限配置
    savePermissionResourceTree(params = {}) {
        return this.post('/sys/role-permission/save', params);
    }

    /** ************* 角色管理 end ***************** */

    /** ************* 站点管理 start ***************** */
    // 获取应用列表，带分页
    getAppList(params = {}) {
        return this.get('/sys/app/page', params);
    }
    // 保存、修改
    setAppSend(params = {}) {
        if (params.id) {
            return this.post('/sys/app/update', params);
        }
        return this.post('/sys/app/save', params);
    }
    // 删除
    deleteApp(params = {}) {
        return this.post('/sys/app/delete', params, urlencodedConfig);
    }
    /** ************* 站点管理 end ***************** */

    /** ************* 配置管理 start ***************** */
    // 获取配置列表
    getSettingList(params = {}) {
        return this.get('/config/page', params);
    }
    // 保存、修改
    setSettingSend(params = {}) {
        if (params.id) {
            return this.post('/config/update', params);
        }
        return this.post('/config/save', params);
    }
    // 删除
    deleteSetting(params = {}) {
        return this.post('/config/delete', params, urlencodedConfig);
    }
    /** ************* 配置管理 end ***************** */

}

export default new SystemManagementService();
