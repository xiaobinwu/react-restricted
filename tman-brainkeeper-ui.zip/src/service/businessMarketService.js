import Service from './service';

class BusinessMarketService extends Service {
    // 核心服务列表
    getCoreServiceList(params = {}) {
        return this.get('/service/core/list', params);
    }
    // 首行统计
    getTrafficstat(params = {}) {
        return this.post('/business/overview/trafficstat', params);
    }
    // 故障汇总
    getFaultSum(params = {}) {
        return this.get('/alarm/dashboard/faultSum', params);
    }
    // 故障直方图
    getFaultHistogram(params = {}) {
        return this.get('/alarm/dashboard/faultHistogram', params);
    }
    // 告警的排名情况
    getAlarmTop(params = {}) {
        return this.get(`/alarm/dashboard/alarmTop?type=${params.type}`);
    }
}

export default new BusinessMarketService();
