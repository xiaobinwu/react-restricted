import Service from './service';

const serviceSchedulingPrefix = '/cantor';

const defaultConfig = {
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
};
class SchedulingService extends Service {
    // 获取服务节点列表
    getNodesList(params = {}) {
        return this.get(`${serviceSchedulingPrefix}/server/nodes`, params);
    }
    // 获取任务队列列表
    getTaskQueueList(params = {}) {
        return this.get(`${serviceSchedulingPrefix}/server/topics`, params);
    }

    // 新增或是删除任务
    setQueueTaskSend(params = {}) {
        params.executeTime = params.executeTime.valueOf();
        if (params.methodType === 'delete') {
            delete params.queue;
            delete params.data;
            delete params.executeTime;
            delete params.methodType;
            return this.post(`${serviceSchedulingPrefix}/tasks/delete`, params, defaultConfig);
        }
        delete params.methodType;
        return this.post(`${serviceSchedulingPrefix}/tasks/add`, params, defaultConfig);
    }

    // 查询任务
    getTaskDetail(params = {}) {
        return this.get(`${serviceSchedulingPrefix}/tasks/get`, params, defaultConfig);
    }

}

export default new SchedulingService();
