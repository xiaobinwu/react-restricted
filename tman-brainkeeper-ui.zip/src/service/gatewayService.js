import SockJS from 'sockjs-client';
import { base64, storage, deepCopy } from 'js/util';
import { GATEWAY } from 'js/variable';
import Service from './service';

const servicePrefix = '/gateway';

const serviceSocketPrefix = process.env.NODE_ENV === 'development' ? 'http://10.60.34.84:8082' : '/api/gateway';

const gateway = storage.getStore(GATEWAY);

const defaultConfig = {
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    },
    // 网关服务需要Authorization
    ...(gateway ? { auth: JSON.parse(base64.decode(gateway)) } : {})
};

const deleteHeaders = (handleConfig) => {
    const config = deepCopy(handleConfig);
    delete config.headers;
    delete config.transformRequest;
    return config;
};

class GatewayService extends Service {

    /** *************服务管理 start***************** */
    // 获取Gateway在线服务列表
    getOnlineList(params = {}) {
        return this.post(`${servicePrefix}/getServiceKeyList`, params, defaultConfig);
    }
    // 获取线程参数
    getHystrixThreadPoolSetter(params = {}) {
        return this.post(`${servicePrefix}/getHystrixThreadPoolSetter`, params, defaultConfig);
    }
    // 保存设置线程参数
    setHystrixThreadPoolSetter(params = {}) {
        const { selectKey } = params;
        delete params.selectKey;
        return this.post(`${servicePrefix}/setHystrixThreadPoolSetter?dubboServiceKey=${selectKey}`, params, deleteHeaders(defaultConfig));
    }
    // 保存Dubbo参数
    setDubboSetter(params = {}) {
        const { selectKey } = params;
        delete params.selectKey;
        return this.post(`${servicePrefix}/setDubboSetter?dubboServiceKey=${selectKey}`, params, deleteHeaders(defaultConfig));
    }
    // 获取Dubbo参数
    getDubboSetter(params = {}) {
        return this.post(`${servicePrefix}/getDubboSetter`, params, defaultConfig);
    }
    // 详情列表
    getLineService(params = {}) {
        return this.post(`${servicePrefix}/onLineService`, params, defaultConfig);
    }
    // 下线
    offLine(params = {}) {
        return this.post(`${servicePrefix}/offline`, params, defaultConfig);
    }
    // 上线
    onLine(params = {}) {
        return this.post(`${servicePrefix}/online`, params, defaultConfig);
    }
    // 降级与恢复
    onFallback(params = {}) {
        return this.post(`${servicePrefix}/fallback`, params, defaultConfig);
    }
    // 清除
    removeService(params = {}) {
        return this.post(`${servicePrefix}/removeService`, params, defaultConfig);
    }
    // 切换限流表单
    switchLimiter(params = {}) {
        return this.post(`${servicePrefix}/switchLimiter`, params, defaultConfig);
    }
    // 获取熔断参数设置表单初始数据
    getHystrixSetter(params = {}) {
        return this.post(`${servicePrefix}/getHystrixSetter`, params, defaultConfig);
    }
    getSemaphoreSend(params = {}) {
        return this.post(`${servicePrefix}/getSemaphoreSend`, params, defaultConfig);
    }
    // 保存熔断参数
    setHystrixSetter(params = {}) {
        const { selectKey } = params;
        delete params.selectKey;
        return this.post(`${servicePrefix}/setHystrixSetter?serviceKey=${selectKey}`, params, deleteHeaders(defaultConfig));
    }
    setSemaphoreSetter(params = {}) {
        const { selectKey } = params;
        delete params.selectKey;
        return this.post(`${servicePrefix}/setSemaphoreSetter?serviceKey=${selectKey}`, params, deleteHeaders(defaultConfig));
    }
    // 获取令牌桶参数
    getTokenBucketSend(params = {}) {
        return this.post(`${servicePrefix}/getTokenBucketSend`, params, defaultConfig);
    }
    // 保存令牌桶参数
    setTokenBucketSend(params = {}) {
        const { selectKey } = params;
        delete params.selectKey;
        return this.post(`${servicePrefix}/setTokenBucketSend?serviceKey=${selectKey}`, params, deleteHeaders(defaultConfig));
    }
    // 保存信息量参数
    setSemaphoreSend(params = {}) {
        const { selectKey } = params;
        delete params.selectKey;
        return this.post(`${servicePrefix}/setSemaphoreSend?serviceKey=${selectKey}`, params, deleteHeaders(defaultConfig));
    }
    // 批量上下线
    batchOnline(params = {}) {
        const { flag } = params;
        delete params.flag;
        return this.post(`${servicePrefix}/batchOnOrOffline?batchType=${flag}`, params.rows, { ...deleteHeaders(defaultConfig), isFilterEmptyField: false });
    }
    // 获取连接管理列表
    getConnectionInfoAll(params = {}) {
        return this.post(`${servicePrefix}/getConnectionInfoAll`, params, defaultConfig);
    }
    // 断开连接
    killConnect(params = {}) {
        return this.post(`${servicePrefix}/killConn`, params, defaultConfig);
    }
    // 加入黑名单
    addBlackList(params = {}) {
        return this.post(`${servicePrefix}/addBlackList`, params, defaultConfig);
    }
    getService(params = {}) {
        return this.post(`${servicePrefix}/service`, params, defaultConfig);
    }
    /** *************服务管理 end***************** */

    /** *************监控管理 start***************** */
    getServerList(params = {}) {
        return this.post(`${servicePrefix}/server/queryServerList`, params, defaultConfig);
    }
    // 在线监控websokit获取图表数据
    getWebSocket() {
        return new SockJS(`${serviceSocketPrefix}/sockjs/monitor?collector=monitor`);
    }
    // 获取QPS实时情况
    getQps(params = {}) {
        return this.post(`${servicePrefix}/monitoring/queryLast100`, params, deleteHeaders(defaultConfig));
    }
    // 获取热点服务列表
    getHotService(params = {}) {
        return this.post(`${servicePrefix}/monitoring/queryHotService`, params, deleteHeaders(defaultConfig));
    }
    // 获取错误服务列表
    getErrorService(params = {}) {
        return this.post(`${servicePrefix}/monitoring/queryErrorService`, params, deleteHeaders(defaultConfig));
    }
    // 全局流量分析
    getTrafficToSum(params = {}) {
        return this.post(`${servicePrefix}/global_traffic/queryTrafficToSum`, params, defaultConfig);
    }
    getTrafficToClassify(params = {}) {
        return this.post(`${servicePrefix}/global_traffic/queryTrafficToClassify`, params, defaultConfig);
    }
    getTrafficGroupByServerId(params = {}) {
        return this.post(`${servicePrefix}/global_traffic/queryTrafficGroupByServerId`, params, defaultConfig);
    }
    // 全局QPS分析
    getGlobalQpsToSum(params = {}) {
        return this.post(`${servicePrefix}/global_traffic/queryGlobalQpsToSum`, params, defaultConfig);
    }
    getGlobalQpsToClassify(params = {}) {
        return this.post(`${servicePrefix}/global_traffic/queryGlobalQpsToClassify`, params, defaultConfig);
    }
    // 获取慢服务数据列表
    getSlowService(params = {}) {
        return this.post(`${servicePrefix}/command/querySlowService`, params, defaultConfig);
    }
    /** *************监控管理 end***************** */

    /** *************集群管理 start***************** */
    // token管理
    getToken(params = {}) {
        return this.post(`${servicePrefix}/token/getTokens`, params, defaultConfig);
    }
    // token更改状态
    updateStatus(params = {}) {
        return this.post(`${servicePrefix}/token/updateStatus`, params, defaultConfig);
    }
    // 删除token
    removeToken(params = {}) {
        return this.post(`${servicePrefix}/token/remove`, params, defaultConfig);
    }
    // 注册token
    addToken(params = {}) {
        return this.post(`${servicePrefix}/token/register`, params, deleteHeaders(defaultConfig));
    }
    // 链路状态开关
    closeFireEye(params = {}) {
        return this.post(`${servicePrefix}/closeFireEye`, params, defaultConfig);
    }
    // 集群概览
    getColonyWebSocket() {
        return new SockJS(`${serviceSocketPrefix}/sockjs/monitor?collector=computer_monitor`);
    }
    flushServers(params = {}) {
        return this.post(`${servicePrefix}/server/flushServers`, params, { ...defaultConfig, errorPop: false });
    }
    // IP 黑名单 - 获取列表信息
    getBlackListService(params = {}) {
        return this.post(`${servicePrefix}/getBlackList`, params, defaultConfig);
    }
    updateMaxRequest(params = {}) {
        return this.post(`${servicePrefix}/server/updateMaxRequest`, params, defaultConfig);
    }
    // IP 黑名单 - 删除条目
    removeBlackList(params = {}) {
        return this.post(`${servicePrefix}/removeBlackList`, params, defaultConfig);
    }
    /** *************集群管理 end***************** */

    /** *************监控管理 start***************** */
    // 获取参数配置列表
    getParameterService(params = {}) {
        return this.post(`${servicePrefix}/admin/getList`, params, defaultConfig);
    }
    // 保存参数
    saveParamsService(params = {}) {
        return this.post(`${servicePrefix}/admin/modifyProperties`, params, { ...defaultConfig, isFilterEmptyField: false });
    }
    initProps(params = {}) {
        return this.post(`${servicePrefix}/admin/initProperties`, params, { ...defaultConfig, isFilterEmptyField: false });
    }
    clearAllProps(params = {}) {
        return this.post(`${servicePrefix}/admin/clearServiceProp`, params, { ...defaultConfig, isFilterEmptyField: false });
    }
    /** *************监控管理 end***************** */
}

export default new GatewayService();
