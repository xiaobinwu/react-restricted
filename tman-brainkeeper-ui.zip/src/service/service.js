import axios from 'axios';
import qs from 'qs';
import { message } from 'antd';
import { isNotEmptyObject } from 'js/util';
import store from 'rRedux/store';

const { CancelToken } = axios;
let requestCache = {};

class Service {
    constructor() {
        this.$http = axios.create({
            responsetype: 'json',
            timeout: 10 * 1000,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        this.__axiosPromiseArr = [];
        // 请求拦截器
        this.$http.interceptors.request.use((config) => {
            // 配置过滤字段空字符串
            config.data = this.dealConfigData(config);
            // dev server代理proxy
            if (config.enabledUrlConfigure) { // 默认开启url转化
                config.url = process.env.NODE_ENV === 'development' ? `/api-dev${config.url}` : `/api${config.url}`;
            }
            // 取消多个请求
            if (config.isCancel) {
                const key = `${config.url}-${JSON.stringify(config.data)}`;
                // 在一个发送请求前执行一下取消操作
                this.removePending(key);
                // 设置取消令牌
                config.cancelToken = new CancelToken((c) => {
                    this.__axiosPromiseArr.push({ u: key, f: c });
                });
            }
            delete config.enabledUrlConfigure;
            return config;
        }, error => Promise.reject(error));

        // 响应拦截器
        this.$http.interceptors.response.use(({ data, config }) => {
            if (data.code && data.code !== '0' && config.errorPop) {
                message.error(data.message, 1.5);
            }
            // 在一个ajax响应后再执行一下取消操作，把已经完成的请求从__axiosPromiseArr中移除
            if (config.isCancel) {
                const key = `${config.url}-${config.data}`;
                this.removePending(key);
            }
            return data;
        }, (error) => {
            if (error.response) {
                const {
                    status,
                    data
                } = error.response;

                switch (status) {
                case 403:
                    message.error('您没有操作权限，请联系系统管理员！', 3);
                    break;
                case 401:
                    // 修改状态，跳转至登陆页
                    store.dispatch({
                        type: 'SET_LOGGED_USER',
                        logged: false,
                        username: '',
                        account: ''
                    });
                    return data;
                default:
                    message.error(`状态码：${status}, 报错信息：${data.message || '未知错误'}`, 1.5);
                }
            }
            return { code: -1001 };
        });
        // 默认参数
        this.defaultConfig = {
            isCancel: true,
            errorPop: true,
            isFilterEmptyField: true,
            enabledUrlConfigure: true
        };
    }

    // 取消操作
    removePending(key) {
        this.__axiosPromiseArr.forEach((item, index) => {
            if (item.u === key) {
                item.f('取消操作');
                this.__axiosPromiseArr.splice(index, 1);
            }
        });
    }
    // 请求拦截器config处理
    dealConfigData(config) {
        const { data, isFilterEmptyField, headers } = config;
        // multipart/form-data不做字段过滤
        if (headers['Content-Type'] === 'multipart/form-data') { return data; }
        if (!isFilterEmptyField) { return data; }
        const param = {};
        if (data === null || data === undefined || data === '') return param;
        for (const key in data) {
            if (data[key] !== null && data[key] !== undefined && data[key] !== '') {
                param[key] = data[key];
            }
        }
        return param;
    }
    // 发起请求前与默认配置合并
    getConfig(config = {}) {
        // application/x-www-form-urlencoded需要使用qs
        if (isNotEmptyObject(config.headers) &&
            config.headers['Content-Type'] === 'application/x-www-form-urlencoded') {
            config.transformRequest = [(data, headers) => qs.stringify(data)];
        }
        config = Object.assign({}, this.defaultConfig, config);
        return {
            ...config
        };
    }
    // Get
    get(url, params = {}, config = {}) {
        return this.$http.request({
            method: 'get',
            url,
            params,
            ...this.getConfig(config)
        });
    }
    // Post
    post(url, params = {}, config = {}) {
        return this.$http.request({
            method: 'post',
            url,
            data: params,
            ...this.getConfig(config)
        });
    }
    // 缓存数据的请求
    requestForCache(url, method = 'get', params = {}, config = {}, cache = true) {
        if (cache) {
            const key = `${url}${JSON.stringify(params)}`;
            if (requestCache[key]) {
                return requestCache[key];
            }
            const promiseObject = this[method](url, params, config);
            promiseObject.then(() => {
                requestCache = { ...requestCache, ...{ [key]: promiseObject } };
            });
            promiseObject.catch(() => {
                delete requestCache[key];
            });
            return promiseObject;
        }
        return this[method](url, params, config);
    }

}

export default Service;
