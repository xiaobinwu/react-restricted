import Service from './service';

const defaultConfig = {
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
};

class UserService extends Service {
    // 登录
    login(params = {}) {
        return this.post('/login', params, defaultConfig);
    }
    // 登出
    logout() {
        return this.get('/logout');
    }
    // 清除cookie退出
    logOutCookie() {
        return this.get('/sys/user/cookie/clear');
    }
    // 获取用户信息
    getUserInfo() {
        return this.get('/sys/user/info');
    }
    // 系统信息
    getSysInfo() {
        return this.get('/sys/info');
    }
    // 获取权限管理下的菜单
    getResourceTree(params = { sourceType: '1,2,3' }) {
        return this.get('/sys/user-permission/getResourceTree', params);
    }
    // 更新密码
    resetPassword(params = {}) {
        return this.post('/sys/user/password/update', params, defaultConfig);
    }
    // 猫头鹰登录
    loginWithRtx(params = {}) {
        return this.get('/sso/login', params);
    }
}

export default new UserService();
