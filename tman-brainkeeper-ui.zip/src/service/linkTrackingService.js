import Service from './service';

class LinkTrackingService extends Service {

    // 获取服务列表
    getAllService(params = {}) {
        return this.post('/service/list', params);
    }

    // 获取站点列表
    getAllSite() {
        return this.requestForCache('/site/list');
    }

    /** *************链路跟踪 start***************** */
    // 获取链路信息列表
    getTraceInfoList(params = {}) {
        return this.post('/trace/tracelist', params);
    }
    // 通过traceid查询链路信息
    getOneTrace(params = {}) {
        return this.get('/trace/one', params);
    }
    // 通过traceid查询链路日志
    getOneTraceLog(params = {}) {
        return this.get('/trace/log', params);
    }
    /** *************链路跟踪 end***************** */


    /** *************接口调用 start***************** */
    // 获取单个接口调用分析数据
    getInterfaceInfo(params = {}) {
        return this.post('/metrics/detail', params);
    }
    // 获取应用实时报表数据
    getInterfaceInfoList(params = {}) {
        return this.post('/metrics/service/overview', params);
    }
    // 获取应用概览报表-提供服务数据
    getOverviewList(params = {}) {
        return this.post('/metrics/app/overview', params);
    }
    // 获取应用概览报表-异常日志
    getErrorLogList(params = {}) {
        return this.post('/metrics/log/overview', params);
    }
    // 历史对比
    getRecentavgList(params = {}) {
        return this.post('/metrics/recentavg', params);
    }
    // 质量评分
    getQualityScore(params = {}) {
        return this.get('/app/quality/score', params);
    }
    // 获取质量评分明细内容
    getQualityList(params = {}) {
        return this.get('/app/quality/list', params);
    }
    // http调用指标
    getHttpList(params = {}) {
        return this.post('/metrics/overview/http/qps', params);
    }
    // redis调用概览
    getRedisList(params = {}) {
        return this.post('/metrics/overview/redis/qps', params);
    }
    // redis连接概览
    getRedisConnectList(params = {}) {
        return this.post('/metrics/overview/redis/connection', params);
    }
    // 集群查询
    getClusterList(params = {}) {
        return this.post('/metrics/metadata/range/redis', params);
    }
    // dubbo调用指标
    getDubbosList(params = {}) {
        return this.post('/metrics/overview/dubbo/qps', params);
    }
    // dubbo 连接概览
    getDubbosConnectList(params = {}) {
        return this.post('/metrics/overview/dubbo/connection', params);
    }
    // dubbo 服务查询
    getDubboServiceList(params = {}) {
        return this.post('/metrics/metadata/range/dubbo', params);
    }
    // durid调用指标
    getDuridsList(params = {}) {
        return this.post('/metrics/overview/druid/qps', params);
    }
    // durid 数据库连接查询
    getDuridConnectList(params = {}) {
        return this.post('/metrics/metadata/range/druid', params);
    }
    // durid 连接概览
    getDuridsConnectList(params = {}) {
        return this.post('/metrics/overview/druid/connection', params);
    }
    // rabbitmq 集群
    getRabClusterList(params = {}) {
        return this.post('/metrics/metadata/range/rabbitmq', params);
    }
    // rabbitmq 生产者概览
    getRabProducerList(params = {}) {
        return this.post('/metrics/overview/rabbitmq/producer/qps', params);
    }
    // rabbitmq 消费者概览
    getRabCoustmerList(params = {}) {
        return this.post('/metrics/overview/rabbitmq/coustmer/qps', params);
    }
    // rabbitmq 连接概览
    getRabbitmqsConnectList(params = {}) {
        return this.post('/metrics/overview/rabbitmq/connection', params);
    }
    /** *************接口调用 end***************** */

    /** *************应用拓扑 start***************** */
    getTopology(params = {}) {
        return this.post('/topo/list', params);
    }
    /** *************应用拓扑 end***************** */

    /** *************站点流量统计 start***************** */
    getMetricsDetail(params = {}) {
        return this.post('/metrics/detail', params);
    }
    getMetricsWithSiteDetail(params = {}) {
        return this.post('/metrics/site/detail', params);
    }
    getAggMetric(params = {}) {
        return this.post('/metrics/aggMetric', params);
    }
    getAggWithSiteMetric(params = {}) {
        return this.post('/metrics/site/aggMetric', params);
    }
    getRecentavg(params = {}) {
        return this.post('/metrics/recentavg', params);
    }
    getRecentSiteavg(params = {}) {
        return this.post('/metrics/site/recentavg', params);
    }
    /** *************站点流量统计 start***************** */

    /** *************系统资源占用情况 start***************** */
    // 获取主机列表
    getOpsList(params = {}) {
        return this.get('/ops/list', params);
    }
    // 获取系统详情
    getOpsDetail(params = {}) {
        return this.get('/ops/detail', params);
    }
    // 获取排名信息
    getMetricsOpsTop5(params = {}) {
        return this.post('/metrics/ops/top5', params);
    }
    // 获取指标趋势
    getMetricsOpsDetail(params = {}) {
        return this.post('/metrics/ops/detail', params);
    }
    /** *************系统资源占用情况 end***************** */

    /** *************依赖服务和被依赖服务 start***************** */
    // 获取依赖指标
    getProviderList(params = {}) {
        return this.post('/metrics/provider/listTypeMetric', params);
    }
    // 获取被依赖指标
    getConsumerList(params = {}) {
        return this.post('/metrics/consumer/listTypeMetric', params);
    }
    /** *************依赖服务和被依赖服务 end***************** */

    /** ************服务管理 start***************** */
    // 获取服务列表
    getServiceList(params = {}) {
        return this.post('/service/page', params);
    }
    setServiceSend(params = {}) {
        return this.post('/service/save', params);
    }
    setAddServiceSend(params = {}) {
        return this.post('/service/add', params);
    }
    /** **************服务管理 end**************** */

    /** ************故障列表 start***************** */
    // 获取故障列表
    getFaultList(params = {}) {
        return this.post('/fault/list', params);
    }
    // 删除故障
    deleteFault(params = {}) {
        return this.post('/fault/delete', params);
    }
    // 保存、修改
    setFaultSend(params = {}) {
        if (params.id) {
            return this.post('/fault/save', params);
        }
        return this.post('/fault/add', params);
    }
    // 详情
    getFaultDetail(params = {}) {
        return this.post('/fault/detail', params);
    }
    /** **************故障列表 end**************** */

    /** ************监控点 start***************** */
    // 查询rms监控点
    getRmsEndPoint(params = {}) {
        return this.get('/alarm/rms/endpoint/list', params);
    }
    // 查询rms错误码
    getRmsCode(params = {}) {
        return this.get('/alarm/rms/endpointCode/list', params);
    }
    // 查询系统类型
    getSystemTypes(params = {}) {
        return this.get('/alarm/endpoint/system_type/list', params);
    }
    // 监控点列表
    getMonitorPointList(params = {}) {
        return this.get('/alarm/endpoint/page', params);
    }
    // 删除
    deleteMonitorPoint(params = {}) {
        return this.post(`/alarm/endpoint/delete?id=${params.id}`);
    }
    setPointSend(params = {}) {
        if (params.id) {
            return this.post('/alarm/endpoint/update', params);
        }
        return this.post('/alarm/endpoint/save', params);
    }
    /** ************监控点 end***************** */

    /** ************监控组 start***************** */
    // 监控组列表
    getMonitorGroupList(params = {}) {
        return this.get('/alarm/endpointGroup/list', params);
    }
    // 保存、修改
    setGroupSend(params = {}) {
        if (params.id) {
            return this.post('/alarm/endpointGroup/update', params);
        }
        return this.post('/alarm/endpointGroup/save', params);
    }
    // 删除
    deleteGroup(params = {}) {
        return this.post(`/alarm/endpointGroup/delete?id=${params.id}`);
    }
    /** ************监控组 end***************** */

    /** ************告警消息 start***************** */
    // 告警消息列表
    getMessageList(params = {}) {
        return this.post(`/alarm/message/page?countSql=true&pageNum=${params.pageNum}&pageSize=${params.pageSize}&sortField=alarm_time&direction=DESC`, params);
    }
    // 删除
    deleteMessage(params = {}) {
        return this.post(`/alarm/message/delete?id=${params.id}`);
    }
    // 获取详情
    getMessageDetail(params = {}) {
        return this.get('/alarm/message/get', params);
    }
    // 更新
    updateMessage(params = {}) {
        return this.post('/alarm/message/update', params);
    }
    // 获取系统
    getMessageTypeList(params = {}) {
        return this.get('/alarm/message/type/list');
    }
    // 一键处理
    batchMark(params = {}) {
        return this.post('/alarm/message/batchMark', params);
    }
    /** ************告警消息 end***************** */

    /** ************告警规则 start***************** */
    // 获取列表
    getMonitorRuleList(params = {}) {
        return this.post(`/alarm/rule/page?countSql=true&pageNum=${params.pageNum}&pageSize=${params.pageSize}`, params);
    }
    // 获取详情
    getRuleDetail(params = {}) {
        return this.get('/alarm/rule/get', params);
    }
    // 新增，修改
    setRuleSend(params = {}) {
        if (params.id) {
            return this.post('/alarm/rule/update', params);
        }
        return this.post('/alarm/rule/save', params);
    }
    // 删除
    deleteRule(params = {}) {
        return this.post(`/alarm/rule/delete?id=${params.id}`);
    }
    // 获取比较类型
    getCompareTypeList(params = {}, cache = true) {
        const url = '/alarm/rule/compare_type/list';
        if (cache) {
            return this.requestForCache(url, 'get', params);
        }
        return this.get(url);
    }
    // 获取条件类型
    getConditionTypeList(params = {}, cache = true) {
        const url = '/alarm/rule/condition_type/list';
        if (cache) {
            return this.requestForCache(url, 'get', params);
        }
        return this.get(url);
    }
    // 获取数据源
    getDataSourceList(params = {}, cache = true) {
        const url = '/alarm/rule/data_source/list';
        if (cache) {
            return this.requestForCache(url, 'get', params);
        }
        return this.get(url);
    }
    /** ************告警规则 end***************** */

    /** ************异常日志 start***************** */
    // 获取异常列表
    getExceptionList(params = {}) {
        return this.post('/log/exception/list', params);
    }
    // 获取异常走势详情
    getExceptionDetail(params = {}) {
        return this.post('/metrics/log/exception/detail', params);
    }
    // 获取日志详情
    getExceptionLog(params = {}) {
        return this.post('/log/exception/detail/list', params);
    }
    /** ************异常日志 end***************** */

    /** ************服务接口收藏功能 start***************** */
    // 添加新接口到收藏列表
    addFavorite(params = {}) {
        return this.post('/service/favorite/add', params);
    }
    // 删除收藏接口
    deleteFavorite(params = {}) {
        return this.post('/service/favorite/del', params);
    }
    // 我收藏的接口
    getFavoriteList(params = {}) {
        return this.post('/service/favorite/list', params);
    }
    /** ************服务接口收藏功能 end***************** */

}

export default new LinkTrackingService();
