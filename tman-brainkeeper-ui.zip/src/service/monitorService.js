import Service from './service';

const serviceMonitorPrefix = '/deye'; // easy mock

const defaultConfig = {
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
};
const formDataonfig = {
    headers: {
        'Content-Type': 'multipart/form-data'
    }
};

// const deleteHeaders = (handleConfig) => {
//     const config = JSON.parse(JSON.stringify(handleConfig));
//     delete config.headers;
//     delete config.transformRequest;
//     return config;
// };

class MonitorService extends Service {

    /* ********** 任务管理 ********** */

    /* 任务管理列表 */
    getTaskList(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobsql/queryNoPage`, params, defaultConfig);
    }
    /* 获取数据源 */
    getDataSource(params = {}, cache = false) {
        const url = `${serviceMonitorPrefix}/datasources/queryNoPage`;
        if (cache) {
            return this.requestForCache(url, 'post', params, defaultConfig);
        }
        return this.post(url, params, defaultConfig);
    }
    /* 保存任务 */
    setTaskSend(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobsql/insertUpdate`, params, defaultConfig);
    }
    /* 删除任务 */
    deleteTask(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobsql/delete`, params, defaultConfig);
    }
    /* 移除屏蔽 */
    removeMinute(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobsql/removeWarnId`, params, defaultConfig);
    }
    /* 更改状态 */
    execStatus(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobsql/execStatus`, params, defaultConfig);
    }
    /* 获取目标管理结果列表 */
    getTaskTargetlist(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobcomparator/queryNoPage`, params, defaultConfig);
    }
    // 保存结果目标管理数据
    setTaskTargetSend(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobcomparator/insertUpdate`, params, defaultConfig);
    }

    // 删除结果目标管理数据
    deleteTaskTarget(params = {}) {
        return this.post(`${serviceMonitorPrefix}/quartzjobcomparator/delete`, params, defaultConfig);
    }

    /* ********** 数据源管理 ********** */
    /* 更改状态 */
    execDataSourceStatus(params = {}) {
        return this.post(`${serviceMonitorPrefix}/datasources/execStatus`, params, defaultConfig);
    }

    /* 保存 */
    setDataSourceSend(params = {}) {
        return this.post(`${serviceMonitorPrefix}/datasources/insertUpdate`, params, defaultConfig);
    }

    /* 加载连接池 */
    loadRecord(params = {}) {
        return this.post(`${serviceMonitorPrefix}/datasources/loadRecord`, params, defaultConfig);
    }

    /* 删除数据源 */
    deleteDataSource(params = {}) {
        return this.post(`${serviceMonitorPrefix}/datasources/delete`, params, defaultConfig);
    }

    /* ********** 统计告警管理 ********** */
    /* 获取告警内容列表 */
    getAlarmContent(params = {}) {
        return this.post(`${serviceMonitorPrefix}/warn/queryNoPage`, params, defaultConfig);
    }

    /* 获取告警内容详情 */
    getAlarmContentDetail(params = {}) {
        return this.post(`${serviceMonitorPrefix}/warn/get`, params, defaultConfig);
    }

    /* 清除当前阶段的屏蔽 */
    removeWarnId(params = {}) {
        return this.post(`${serviceMonitorPrefix}/warn/removeWarnId`, params, defaultConfig);
    }

    /* 处理 */
    processAlarmContentDetail(params = {}) {
        return this.post(`${serviceMonitorPrefix}/warn/process`, params, defaultConfig);
    }

    /* ********** 对账告警管理 ********** */
    /* 对账告警列表 */
    getAlarmReconciliation(params = {}) {
        return this.post('/seer/warn/queryNoPage', params, defaultConfig);
    }
    /* 获取对账告警详情 */
    getAlarmReconciliationDetail(params = {}) {
        return this.post('/seer/warn/get', params, defaultConfig);
    }
    /* 处理 */
    processAlarmReconciliationDetail(params = {}) {
        return this.post('/seer/warn/process', params, defaultConfig);
    }

    /* ********** 告警用户管理 ********** */

    /* 获取告警用户列表 */
    getAlarmUser(params = {}) {
        return this.post(`${serviceMonitorPrefix}/alarmuser/queryNoPage`, params, defaultConfig);
    }

    /* 删除告警用户 */
    deleteAlarmUser(params = {}) {
        return this.post(`${serviceMonitorPrefix}/alarmuser/delete`, params, defaultConfig);
    }

    /* 新增、修改告警用户 */
    setAlarmUserSend(params = {}) {
        return this.post(`${serviceMonitorPrefix}/alarmuser/insertUpdate`, params, defaultConfig);
    }

    /* 获取绑定应用列表 */
    getBindApplicId(params = {}) {
        return this.post(`${serviceMonitorPrefix}/alarmuser/getBindApplicId`, params, defaultConfig);
    }

    /* 绑定应用 */
    bindApplicId(params = {}) {
        return this.post(`${serviceMonitorPrefix}/alarmuser/bindApplicId`, params, defaultConfig);
    }

    /* sql检测 */
    checkSql(params = {}) {
        return this.post(`${serviceMonitorPrefix}/index/checkSql`, params, defaultConfig);
    }

    /* ********** 一致性对账 ********** */

    // 获取对账结果列表
    getSeerList(params = {}) {
        return this.post('/seer/page', params);
    }

    /* ********** 对账数据源管理 ********** */

    // 获取对账数据源列表
    getReconciliationDataSource(params = {}) {
        return this.post('/seer/source/page', params);
    }
    // 删除对账数据源
    deleteReconciliationDataSource(params = {}) {
        return this.post(`/seer/source/del/${params.id}`, params);
    }
    /* 保存 */
    setReconciliationDataSourceSend(params = {}) {
        if (params.id) {
            return this.post('/seer/source/update', params);
        }
        return this.post('/seer/source/add', params);
    }
    // 获取对账数据源列表，不带分页
    getReconciliationDataSourceList(params = {}) {
        return this.post('/seer/source/list', params);
    }
    /* ********** 对账作业管理 ********** */

    // 获取对账作业列表
    getReconciliationJobs(params = {}) {
        return this.post('/seer/job/page', params);
    }
    // 删除对账作业
    deleteReconciliationJob(params = {}) {
        return this.post('/seer/job/del', params);
    }
    // 更改状态
    changeReconciliationJobStatus(params = {}) {
        const { flag, ...reset } = params;
        if (flag) {
            return this.post('/job/start', reset);
        }
        return this.post('/job/stop', reset);
    }
    // 审核作业
    auditReconciliationJob(params = {}) {
        const formData = new FormData();
        for (const i in params) {
            formData.append(i, params[i]);
        }
        return this.post('/seer/job/audit', formData, formDataonfig);
    }
    // 添加及编辑作业
    operateReconciliationJob(params = {}) {
        let url;
        if (params.operateStatus === 0) {
            url = '/seer/job/add';
        } else if (params.operateStatus === 1) {
            url = '/seer/job/update';
        }
        delete params.operateStatus;
        const formData = new FormData();
        for (const i in params) {
            if (i === 'jarfile') {
                params[i] && params[i].length > 0 && (formData.append(i, params[i][0]));
            } else {
                formData.append(i, params[i]);
            }
        }
        return this.post(url, formData, formDataonfig);
    }

    /* ********** Canal监控仪表 ********** */
    getMonitorDelay(params = {}) {
        return this.get('/canal/monitor/delay', params);
    }

    /* ********** 订单报表 ********** */
    // 获取列表
    getOrderReportList(params = {}) {
        return this.post(`${serviceMonitorPrefix}/order/report/orderPlatformReport`, params, defaultConfig);
    }
    // 双十一实时销售大盘
    getSaleData(params = {}) {
        return this.post(`${serviceMonitorPrefix}/order/report/saleData`, params, defaultConfig);
    }
    // 全量导入
    reportAllLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/order/report/reportAllLoad`, params, defaultConfig);
    }
    // 指定时间导入
    reportDateLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/order/report/reportDateLoad`, params, defaultConfig);
    }
    // 小时维度的报表
    getHourOrderReport(params = {}) {
        return this.post(`${serviceMonitorPrefix}/order/report/orderReport`, params, defaultConfig);
    }

    /* ********** 支付报表 ********** */
    // 获取列表
    getPayReportList(params = {}) {
        return this.post(`${serviceMonitorPrefix}/pay/report/orderPlatformReport`, params, defaultConfig);
    }
    // 全量导入
    payReportAllLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/pay/report/reportAllLoad`, params, defaultConfig);
    }
    // 指定时间导入
    payReportDateLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/pay/report/reportDateLoad`, params, defaultConfig);
    }

    /* ********** 营销报表 ********** */
    // 获取列表
    getPromotionReportList(params = {}) {
        return this.post(`${serviceMonitorPrefix}/promotion/report/orderPlatformReport`, params, defaultConfig);
    }
    // 全量导入
    promotionReportAllLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/promotion/report/reportAllLoad`, params, defaultConfig);
    }
    // 指定时间导入
    promotionReportDateLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/promotion/report/reportDateLoad`, params, defaultConfig);
    }

    /* ********** 会员报表 ********** */
    // 获取列表
    getMemberReportList(params = {}) {
        return this.post(`${serviceMonitorPrefix}/member/report/orderPlatformReport`, params, defaultConfig);
    }
    // 全量导入
    memberReportAllLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/member/report/reportAllLoad`, params, defaultConfig);
    }
    // 指定时间导入
    memberReportDateLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/member/report/reportDateLoad`, params, defaultConfig);
    }

    /* ********** 商品报表 ********** */
    // 获取列表
    getGoodsReportList(params = {}) {
        return this.post(`${serviceMonitorPrefix}/goods/report/orderPlatformReport`, params, defaultConfig);
    }
    // 全量导入
    goodsReportAllLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/goods/report/reportAllLoad`, params, defaultConfig);
    }
    // 指定时间导入
    goodsReportDateLoad(params = {}) {
        return this.post(`${serviceMonitorPrefix}/goods/report/reportDateLoad`, params, defaultConfig);
    }

    /* ********** 销售大盘 ********** */
    getSalesMarketData(params = {}) {
        return this.get('/sale/dashboard', params, defaultConfig);
    }

    /* ********** 销售区域分布 ********** */
    getBusinessOrdersReport(params = {}) {
        return this.get(`${serviceMonitorPrefix}/businessOrders/report/orderPlatformReport`, params, defaultConfig);
    }

    /* ************业务概览，登录注册、购物车数据对接************ */
    getBusinessReport(params = {}) {
        return this.get(`${serviceMonitorPrefix}/business/report/orderPlatformReport`, params, defaultConfig);
    }
}

export default new MonitorService();
