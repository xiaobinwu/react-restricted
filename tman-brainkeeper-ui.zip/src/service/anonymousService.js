import Service from './service';

/* 匿名接口，无需验证登录 */

// 告警信息展示
class AnonymousService extends Service {
    getAlarmDetail(params = {}) {
        return this.get('/alarm/message/getDetail', params);
    }
}

export default new AnonymousService();
