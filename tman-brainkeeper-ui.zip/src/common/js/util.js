

import base64 from './base64';
import storage from './storage';

// 解析当前url的query 参数
const getQueryString = (href) => {
    const url = String(href === undefined ? window.location.href : href).replace(/#.*$/, '');
    const search = url.substring(url.lastIndexOf('?') + 1);
    const obj = {};
    const reg = /([^?&=]+)=([^?&=]*)/g;
    search.replace(reg, (rs, $1, $2) => {
        const name = decodeURIComponent($1);
        const query = String(decodeURIComponent($2));
        obj[name] = query;
        return rs;
    });
    return obj;
};

// 四拾伍入
const roundNumber = (num, dec = 1) => {
    const result = Math.round(num * (10 ** dec)) / (10 ** dec);
    let resultString = result.toString();
    if (resultString.indexOf('.') === -1) {
        resultString = `${resultString}.0`;
    }
    return resultString;
};

// 格式化金额
const formatAmount = (num, precision = 2, separator = ',') => {
    let parts;
    if (!isNaN(parseFloat(num)) && isFinite(num)) { // eslint-disable-line
        let number = Number(num);
        number = (Math.round(num * (10 ** precision)) / (10 ** precision)).toFixed(precision).toString();
        parts = number.split('.');
        parts[0] = parts[0].toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, `$1${separator}`);
        return parts.join('.');
    }
    return NaN;
};

// 全屏切换
const toggleFullScreen = (isFullScreen, callback) => {
    if (!document.fullscreenElement &&
        !document.mozFullScreenElement &&
        !document.webkitFullscreenElement &&
        !document.msFullscreenElement
        && isFullScreen) {
        callback && callback();
        if (document.documentElement.requestFullscreen) {
            document.documentElement.requestFullscreen();
        } else if (document.documentElement.msRequestFullscreen) {
            document.documentElement.msRequestFullscreen();
        } else if (document.documentElement.mozRequestFullScreen) {
            document.documentElement.mozRequestFullScreen();
        } else if (document.documentElement.webkitRequestFullscreen) {
            document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
        }
    } else {
        callback && callback();
        if (document.exitFullscreen) { // eslint-disable-line
            document.exitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        }
    }
};

// 判断是否为空对象
const isNotEmptyObject = (obj) => {
    return obj && Object.keys(obj).length > 0;
};

// 深拷贝
const deepCopy = (obj) => {
    try {
        return JSON.parse(JSON.stringify(obj));
    } catch (e) {
        throw e;
    }
};


export {
    getQueryString,
    roundNumber,
    base64,
    formatAmount,
    storage,
    toggleFullScreen,
    isNotEmptyObject,
    deepCopy
};
