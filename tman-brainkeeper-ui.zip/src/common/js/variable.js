const THEME = 'theme'; // 主题信息
const MENUSLIST = 'menusList'; // 菜单树信息
const GATEWAY = 'gateway'; // 服务网关认证信息
const APPNAME = 'appname'; // 应用名级别信息
const SERVICENAME = 'servicename'; // 服务级别信息
const METHODNAME = 'methodname'; // 方法级别信息
const CURRENTNAVID = 'currentNavId'; // 当前顶级菜单Id，用于多个相同url的匹配
const CURRENTPAGEID = 'currentPageId'; // 当前侧边栏菜单Id，用于多个相同url的匹配
export {
    THEME,
    MENUSLIST,
    GATEWAY,
    APPNAME,
    SERVICENAME,
    METHODNAME,
    CURRENTNAVID,
    CURRENTPAGEID
};
