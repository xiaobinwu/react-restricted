/**
 * Created by Liu.Jun on 2018/11/5.
 */

const baseWidth = 1600;

// 屏幕物理分辨率的宽

function computedSize() {
    const curScreenWidth = window.screen.width - 40;
    document.body.style.minWidth = `${baseWidth}px`;

    if (curScreenWidth < baseWidth) {
        document.documentElement.style.zoom = `${curScreenWidth / baseWidth}`;
    }
}

computedSize();
