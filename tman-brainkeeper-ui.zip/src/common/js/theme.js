import store from 'rRedux/store';
import { registerTheme } from 'js/echarts.custom';
import { THEME } from 'js/variable';
import { storage } from 'js/util';

const setTheme = async ({ theme, antd, primarycolor }) => {
    try {
        const less = await import(/* webpackChunkName: 'less' */ 'js/less.min');
        const antdTheme = await import(/* webpackChunkName: 'antdThemes' */ `themes/antd/${antd}`);
        const echartTheme = await import(/* webpackChunkName: 'echartThemes' */ `themes/echart/${theme}`);
        store.dispatch({
            type: 'SET_ANTD',
            antd
        });
        const themeSeting = primarycolor ? { ...antdTheme.default, ...{ '@primary-color': primarycolor } } : antdTheme.default;
        less.modifyVars(themeSeting);
        registerTheme(theme, echartTheme.default);
        store.dispatch({
            type: 'SET_THEME',
            theme
        });
        // 存储当前选中theme
        storage.setStore(THEME, JSON.stringify({ theme, antd, primarycolor }));
        return Promise.resolve();
    } catch (error) {
        return Promise.reject(error);
    }
};

export {
    setTheme
};
