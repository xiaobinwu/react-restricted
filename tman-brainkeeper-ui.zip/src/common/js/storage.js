/**
 * 存储js，支持localStorage，sessionStorage，cookie
 * local => localStorage,
 * session => sessionStorage,
 * cookie => cookie
*/

const setStore = (name, content, type = 'local') => {
    if (!name) {
        return;
    }
    if (typeof content !== 'string') {
        content = JSON.stringify(content);
    }
    localStorage.setItem(name, content);
};

const getStore = (name, type = 'local') => {
    if (name) {
        return localStorage.getItem(name);
    }
    return undefined;
};

const clearStore = (name, type = 'local') => {
    if (!name) {
        return;
    }
    localStorage.removeItem(name);
};

export default {
    setStore,
    getStore,
    clearStore
};
