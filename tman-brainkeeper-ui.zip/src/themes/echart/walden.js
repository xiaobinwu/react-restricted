const theme =
{
    color: [
        '#6be6c1',
        '#6898ed',
        '#ff779b',
        '#a0a7e6',
        '#c4ebad',
        '#96dee8',
        '#e098c7',
        '#71669e',
        '#9b8bba',
        '#7cb4cc',
        '#6196ac',
        '#548498'
    ],
    backgroundColor: 'aliceblue',
    textStyle: {},
    title: {
        textStyle: {
            color: '#666666'
        },
        subtextStyle: {
            color: '#999999'
        }
    },
    line: {
        itemStyle: {
            normal: {
                borderWidth: '1'
            }
        },
        lineStyle: {
            normal: {
                width: '1'
            }
        },
        symbolSize: '4',
        symbol: 'emptyCircle',
        smooth: true,
        showSymbol: false
    },
    radar: {
        itemStyle: {
            normal: {
                borderWidth: '2'
            }
        },
        lineStyle: {
            normal: {
                width: '3'
            }
        },
        symbolSize: '8',
        symbol: 'emptyCircle',
        smooth: false
    },
    bar: {
        itemStyle: {
            normal: {
                barBorderWidth: 0,
                barBorderColor: '#ccc'
            },
            emphasis: {
                barBorderWidth: 0,
                barBorderColor: '#ccc'
            }
        }
    },
    pie: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            },
            emphasis: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        }
    },
    scatter: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            },
            emphasis: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        }
    },
    boxplot: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            },
            emphasis: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        }
    },
    parallel: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            },
            emphasis: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        }
    },
    sankey: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            },
            emphasis: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        }
    },
    funnel: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            },
            emphasis: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        }
    },
    gauge: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            },
            emphasis: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        }
    },
    candlestick: {
        itemStyle: {
            normal: {
                color: '#e6a0d2',
                color0: 'transparent',
                borderColor: '#e6a0d2',
                borderColor0: '#6898ed',
                borderWidth: '2'
            }
        }
    },
    graph: {
        itemStyle: {
            normal: {
                borderWidth: 0,
                borderColor: '#ccc'
            }
        },
        lineStyle: {
            normal: {
                width: '1',
                color: '#cccccc'
            }
        },
        symbolSize: '8',
        smooth: false,
        color: [
            '#6898ed',
            '#6be6c1',
            '#ff779b',
            '#a0a7e6',
            '#c4ebad',
            '#96dee8'
        ],
        label: {
            normal: {
                textStyle: {
                    color: '#ffffff'
                }
            }
        }
    },
    map: {
        itemStyle: {
            normal: {
                areaColor: '#eeeeee',
                borderColor: '#aaaaaa',
                borderWidth: 0.5
            },
            emphasis: {
                areaColor: 'rgba(63,177,227,0.25)',
                borderColor: '#6898ed',
                borderWidth: 1
            }
        },
        label: {
            normal: {
                textStyle: {
                    color: '#ffffff'
                }
            },
            emphasis: {
                textStyle: {
                    color: 'rgb(63,177,227)'
                }
            }
        }
    },
    geo: {
        itemStyle: {
            normal: {
                areaColor: '#eeeeee',
                borderColor: '#aaaaaa',
                borderWidth: 0.5
            },
            emphasis: {
                areaColor: 'rgba(63,177,227,0.25)',
                borderColor: '#6898ed',
                borderWidth: 1
            }
        },
        label: {
            normal: {
                textStyle: {
                    color: '#ffffff'
                }
            },
            emphasis: {
                textStyle: {
                    color: 'rgb(63,177,227)'
                }
            }
        }
    },
    categoryAxis: {
        axisLine: {
            show: true,
            lineStyle: {
                color: '#cccccc'
            }
        },
        axisTick: {
            show: false,
            lineStyle: {
                color: '#333'
            }
        },
        axisLabel: {
            show: true,
            textStyle: {
                color: '#999999'
            }
        },
        splitLine: {
            show: true,
            lineStyle: {
                color: [
                    '#eeeeee'
                ]
            }
        },
        splitArea: {
            show: false,
            areaStyle: {
                color: [
                    'rgba(250,250,250,0.05)',
                    'rgba(200,200,200,0.02)'
                ]
            }
        }
    },
    valueAxis: {
        axisLine: {
            show: true,
            lineStyle: {
                color: '#cccccc'
            }
        },
        axisTick: {
            show: false,
            lineStyle: {
                color: '#333'
            }
        },
        axisLabel: {
            show: true,
            textStyle: {
                color: '#999999'
            }
        },
        splitLine: {
            show: true,
            lineStyle: {
                color: [
                    '#eeeeee'
                ]
            }
        },
        splitArea: {
            show: false,
            areaStyle: {
                color: [
                    'rgba(250,250,250,0.05)',
                    'rgba(200,200,200,0.02)'
                ]
            }
        }
    },
    logAxis: {
        axisLine: {
            show: true,
            lineStyle: {
                color: '#cccccc'
            }
        },
        axisTick: {
            show: false,
            lineStyle: {
                color: '#333'
            }
        },
        axisLabel: {
            show: true,
            textStyle: {
                color: '#999999'
            }
        },
        splitLine: {
            show: true,
            lineStyle: {
                color: [
                    '#eeeeee'
                ]
            }
        },
        splitArea: {
            show: false,
            areaStyle: {
                color: [
                    'rgba(250,250,250,0.05)',
                    'rgba(200,200,200,0.02)'
                ]
            }
        }
    },
    timeAxis: {
        axisLine: {
            show: true,
            lineStyle: {
                color: '#cccccc'
            }
        },
        axisTick: {
            show: false,
            lineStyle: {
                color: '#333'
            }
        },
        axisLabel: {
            show: true,
            textStyle: {
                color: '#999999'
            }
        },
        splitLine: {
            show: true,
            lineStyle: {
                color: [
                    '#eeeeee'
                ]
            }
        },
        splitArea: {
            show: false,
            areaStyle: {
                color: [
                    'rgba(250,250,250,0.05)',
                    'rgba(200,200,200,0.02)'
                ]
            }
        }
    },
    toolbox: {
        iconStyle: {
            normal: {
                borderColor: '#999999'
            },
            emphasis: {
                borderColor: '#666666'
            }
        }
    },
    legend: {
        textStyle: {
            color: '#999999'
        }
    },
    tooltip: {
        axisPointer: {
            lineStyle: {
                color: '#cccccc',
                width: 1
            },
            crossStyle: {
                color: '#cccccc',
                width: 1
            }
        }
    },
    timeline: {
        lineStyle: {
            color: '#ff779b',
            width: 1
        },
        itemStyle: {
            normal: {
                color: '#ff779b',
                borderWidth: 1
            },
            emphasis: {
                color: '#ff779b'
            }
        },
        controlStyle: {
            normal: {
                color: '#ff779b',
                borderColor: '#ff779b',
                borderWidth: 0.5
            },
            emphasis: {
                color: '#ff779b',
                borderColor: '#ff779b',
                borderWidth: 0.5
            }
        },
        checkpointStyle: {
            color: '#6898ed',
            borderColor: 'rgba(63,177,227,0.15)'
        },
        label: {
            normal: {
                textStyle: {
                    color: '#ff779b'
                }
            },
            emphasis: {
                textStyle: {
                    color: '#ff779b'
                }
            }
        }
    },
    visualMap: {
        color: [
            '#2a99c9',
            '#afe8ff'
        ]
    },
    dataZoom: {
        backgroundColor: 'rgba(255,255,255,0)',
        dataBackgroundColor: 'rgba(222,222,222,1)',
        fillerColor: 'rgba(114,230,212,0.25)',
        handleColor: '#cccccc',
        handleSize: '100%',
        textStyle: {
            color: '#999999'
        }
    },
    markPoint: {
        label: {
            normal: {
                textStyle: {
                    color: '#ffffff'
                }
            },
            emphasis: {
                textStyle: {
                    color: '#ffffff'
                }
            }
        }
    }
};

export default theme;
