
import React from 'react';
import ReactDOM from 'react-dom';
import { registerTheme } from 'js/echarts.custom';
import theme from 'themes/echart/halloween';
import registerServiceWorker from 'src/registerServiceWorker';

// 计算页面缩放
// import 'js/computedZoom';

// 默认黑色主题
import 'themes/antd/antd-theme.less';

import App from './App';


// 默认ehart主题
registerTheme('halloween', theme);

if (module.hot) {
    module.hot.accept();
}

ReactDOM.render(
    <App />,
    document.getElementById('root')
);

registerServiceWorker();
