
import React, { useState, useEffect } from 'react';
import { Layout, Row, Col, Select, Input, Button, message, Spin, Tabs } from 'antd';
import { anonymousService, userService, linkTrackingService } from 'service';
import { getQueryString, isNotEmptyObject } from 'js/util';
import Interface from './charts/interface';
import styles from './index.css';

const { Header, Footer, Content } = Layout;
const { Option } = Select;
const { TextArea } = Input;
const { TabPane } = Tabs;

const Alram = (props) => {
    const [status, setStatus] = useState(false);
    const [type, setType] = useState('');
    const [alarm, setAlram] = useState({});
    const [messageTypeList, setMessageTypeList] = useState([]);
    const [remark, setRemark] = useState('');
    const [messageType, setMessageType] = useState('');
    const [xAxis, setXAxis] = useState([]);
    const [series1, setSeries1] = useState([]);
    const [series2, setSeries2] = useState([]);
    const [series3, setSeries3] = useState([]);
    const [logDetails, setLogDetails] = useState([]);
    const [annotations, setAnnotations] = useState([]);
    const [loading, setLoading] = useState(true);

    // 改变消息类型
    const changeMessageType = (value) => {
        setMessageType(value);
    };
    // 改变消息类型
    const changeRemark = (e) => {
        setRemark(e.target.value);
    };
    // 获取告警详情
    const getAlarmDetail = async (params) => {
        setType(params.type || '');
        const { code, entry } = await anonymousService.getAlarmDetail(params);
        if (code === '0') {
            const { data, alarm: alarmResult } = entry;
            setAlram(alarmResult);
            if (params.type === 'qps' && data) {
                const xAxisArr = [];
                const avgdurationArr = [];
                const avgqpsArr = [];
                const errorCountsArr = [];
                data.forEach((item, index) => {
                    xAxisArr.push(item.eventTime);
                    avgdurationArr.push((item.data && item.data.avgduration) || 0);
                    avgqpsArr.push((item.data && item.data.avgqps) || 0);
                    errorCountsArr.push((item.data && item.data.avgerror) || 0);
                });
                setXAxis(xAxisArr);
                setSeries1(avgdurationArr);
                setSeries2(avgqpsArr);
                setSeries3(errorCountsArr);
            }
            if (params.type === 'exception' && data) {
                setLogDetails(data);
            }
            if (params.type === 'error' && data) {
                setAnnotations(data);
            }
        }
        setLoading(false);
    };
    // 获取消息类型
    const getMessageTypeList = async () => {
        const { entry, code } = await linkTrackingService.getMessageTypeList();
        if (code === '0') {
            setMessageTypeList(entry);
        }
    };
    // 判断是否登录
    const judgeLoginStatus = async (params) => {
        const { code } = await userService.getUserInfo();
        if (code === '0') {
            setStatus(true);
            getMessageTypeList();
        }
    };
    // 处理
    const hanle = async (s, record) => {
        let params = {};
        if (s === 20) {
            params = {
                remark,
                type: messageType
            };
        }
        if (record) {
            const { code, entry } = await linkTrackingService.updateMessage({ status: s, id: record.id, ...params });
            if (code === '0') {
                message.success('处理成功');
                const result = Object.assign({}, alarm, entry);
                setAlram(result);
            }
        }
    };
    // 查找对应的消息类型
    const findMessageType = (t) => {
        const findItem = messageTypeList.find((item) => {
            return item.code === t;
        });
        if (findItem) {
            return findItem.name;
        }
        return '';
    };
    // 钩子
    useEffect(() => {
        const result = getQueryString();
        if (isNotEmptyObject(result)) {
            getAlarmDetail(result);
        }
    }, []);
    useEffect(() => {
        judgeLoginStatus();
    }, []);

    const colLayout = { marginBottom: 10 };
    const layout = { marginBottom: 15 };
    const span = {
        xs: 24,
        sm: 24,
        md: 12,
        lg: 12
    };
    return (
        <div style={{ maxWidth: '950px', margin: '0 auto' }}>
            <Layout>
                {
                    alarm ? <Header className={`system-header system-alarmDeatil-header ${styles.header}`}>告警信息（ID：{alarm.id}）</Header> : null
                }
                <Content className={`system-alarmDeatil-bg ${styles.content}`}>
                    {
                        loading ? <Spin spinning={loading} tip="Loading...">
                            <div style={{
                                minHeight: '800px'
                            }}></div>
                        </Spin> : <React.Fragment>
                            {
                                alarm ? <React.Fragment>
                                    <h3 className={`system-alarmDeatil-h3 ${styles.h3}`}>{alarm.title}</h3>
                                    <Row>
                                        <Col {...span} style={colLayout}>
                                            <span>监控组：</span>
                                            <span>{alarm.group}</span>
                                        </Col>
                                        <Col {...span} style={colLayout}>
                                            <span>监控点：</span>
                                            <span>{alarm.endpoint}</span>
                                        </Col>
                                        <Col {...span} style={colLayout}>
                                            <span>级别：</span>
                                            <span>{alarm.level}</span>
                                        </Col>
                                        <Col {...span} style={colLayout}>
                                            <span>处理状态：</span>
                                            <span>{alarm.statusStr}</span>
                                        </Col>
                                        <Col {...span} style={colLayout}>
                                            <span>消息时间：</span>
                                            <span>{alarm.alarmTime}</span>
                                        </Col>
                                        <Col {...span} style={colLayout}>
                                            <span>处理时间：</span>
                                            <span>{alarm.updateTime}</span>
                                        </Col>
                                        {
                                            alarm.status !== 0 ? <Col {...span} style={colLayout}>
                                                <span>错误类型：</span>
                                                <span>
                                                    {
                                                        alarm.status === 10 ? <Select onChange={changeMessageType} style={{ width: 200 }}>
                                                            {
                                                                messageTypeList.map((item, index) => {
                                                                    return (<Option key={item.code} value={item.code}>{item.name}</Option>);
                                                                })
                                                            }
                                                        </Select> : findMessageType(alarm.type)
                                                    }
                                                </span>
                                            </Col> : null
                                        }
                                        {
                                            alarm.status !== 0 ? <Col {...span} style={colLayout}>
                                                <span>备注：</span>
                                                {
                                                    alarm.status === 10 ? <TextArea row={5} style={{ width: '90%', verticalAlign: 'middle' }} onChange={changeRemark}/> : alarm.remark
                                                }
                                            </Col> : null
                                        }
                                        <Col span={24} style={colLayout}>
                                            <span>消息内容：</span>
                                            <div style={{ padding: 20 }} dangerouslySetInnerHTML={{ __html: alarm.messageContent }} />
                                        </Col>
                                    </Row>
                                </React.Fragment> : null
                            }
                            {
                                type === 'qps' ? <React.Fragment>
                                    <h3 className={`system-alarmDeatil-h3 ${styles.h3}`}>异常信息</h3>
                                    <Interface xAxis={xAxis} series1={series1} series2={series2} series3={series3}/>
                                </React.Fragment> : null
                            }
                            {
                                type === 'error' ? <React.Fragment>
                                    <h3 className={`system-alarmDeatil-h3 ${styles.h3}`}>错误信息</h3>
                                    <Tabs
                                        className={styles.tabs}
                                        defaultActiveKey="0"
                                    >
                                        {
                                            annotations.map((item, index) => {
                                                return (<TabPane tab={index + 1} key={index}>
                                                    <Row>
                                                        <Col span={24}>
                                                            <div className={styles.log}>
                                                                { item.value }
                                                            </div>
                                                        </Col>
                                                    </Row>
                                                </TabPane>);
                                            })
                                        }
                                    </Tabs>
                                </React.Fragment> : null
                            }
                            {
                                type === 'exception' ? <React.Fragment>
                                    <h3 className={`system-alarmDeatil-h3 ${styles.h3}`}>异常日志</h3>
                                    <Tabs
                                        className={styles.tabs}
                                        defaultActiveKey="0"
                                    >
                                        {
                                            logDetails.map((item, index) => {
                                                return (<TabPane tab={index + 1} key={index}>
                                                    <Row>
                                                        <Col span={8} style={layout}>
                                                            <Row>
                                                                <Col span={8}><strong>AppName:</strong></Col>
                                                                <Col span={16}>{item._domain}</Col>
                                                            </Row>
                                                        </Col>
                                                        <Col span={8} style={layout}>
                                                            <Row>
                                                                <Col span={8}><strong>IP:</strong></Col>
                                                                <Col span={16}>{item._ip}</Col>
                                                            </Row>
                                                        </Col>
                                                        <Col span={8} style={layout}>
                                                            <Row>
                                                                <Col span={8}><strong>Time:</strong></Col>
                                                                <Col span={16}>{item._time}</Col>
                                                            </Row>
                                                        </Col>
                                                        <Col span={14} style={layout}>
                                                            <Row>
                                                                <Col span={4}><strong>LogFile:</strong></Col>
                                                                <Col span={20}>{item._fileName}</Col>
                                                            </Row>
                                                        </Col>
                                                        <Col span={24}>
                                                            <strong>Detail: &nbsp;</strong>
                                                            <div className={styles.log}>
                                                                { item._log }
                                                            </div>
                                                        </Col>
                                                    </Row>
                                                </TabPane>);
                                            })
                                        }
                                    </Tabs>
                                </React.Fragment> : null
                            }
                            {
                                status && alarm ? <Row style={{ marginTop: 40, textAlign: 'center' }}>
                                    <Col span={24} style={colLayout}>
                                        {
                                            alarm.status === 0 ? <Button type="primary" onClick={hanle.bind(this, 10, alarm)} style={{ marginRight: '10px' }}>开始处理</Button> : null
                                        }
                                        {
                                            alarm.status === 10 ? <Button type="primary" onClick={hanle.bind(this, 20, alarm)} style={{ marginRight: '10px' }}>完成处理</Button> : null
                                        }
                                        {/* 写死/link-tracking/alarm/monitorRule TODO */}
                                        {
                                            alarm.ruleId ? <a href={`/link-tracking/alarm/monitorRule?ruleId=${alarm.ruleId}`} target="_blank">
                                                <Button type="primary">调整阀值</Button>
                                            </a> : null
                                        }
                                    </Col>
                                </Row> : null
                            }
                        </React.Fragment>
                    }
                </Content>
                <Footer className="system-footer system-alarmDeatil-footer">
                    BrainKeeper ©2018-2019 Created by the Platform Architecture Group of the Electronic Projects Division
                </Footer>
            </Layout>
        </div>
    );
};

export default Alram;
