import React, { Component } from 'react';
import store from 'rRedux/store';
import logo from 'src/logo.png';
import { base64, storage } from 'js/util';
import { hanlePermission } from 'component/hoc/withPermission';
import { Form, Icon, Input, Button, Checkbox, message, Tabs, Spin } from 'antd';
import { userService } from 'service';
import { MENUSLIST, GATEWAY } from 'js/variable';

import particles from './particles';
import styles from './index.css';

const FormItem = Form.Item;
const { TabPane } = Tabs;

class Auth extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            isLogin: true
        };
    }
    componentDidMount() {
        // 获取用户信息
        (async () => {
            const { code } = await userService.getUserInfo();
            if (code === '0') {
                // 也可以用Redirect于render函数去跳转
                this.props.history.replace('/');
            } else {
                this.setState({
                    isLogin: false
                }, () => {
                    // 引入particles
                    import(/* webpackChunkName: 'particles' */ 'js/particles').then((particlesJS) => {
                        particlesJS.default('particles-js', particles);
                    });
                });
            }
        })();
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    loading: true
                });
                const { username, password } = values;
                const data = await userService.login({ account: username, password });
                const sys = await userService.getSysInfo();
                if (data.code === '0' && sys.code === '0') {
                    // 用户验证成功后，获取权限路由信息
                    const res = await userService.getResourceTree();
                    if (res.code === '0') {
                        storage.setStore(MENUSLIST, JSON.stringify(res.entry));
                        hanlePermission(res.entry); // 收集页面功能性操作展示权限
                        storage.setStore(GATEWAY, base64.encode(JSON.stringify(sys.entry.gateway)));
                        store.dispatch({
                            type: 'SET_LOGGED_USER',
                            logged: true,
                            username,
                            account: data.entry.account
                        });
                        this.props.history.replace('/');
                    }
                } else {
                    this.setState({
                        loading: false
                    }, () => {
                        message.error(data.message);
                    });
                }
            }
        });
    }

    changeTabs = async (activeKey) => {
        if (activeKey === '2') {
            const { code, entry } = await userService.loginWithRtx();
            if (code === '0') {
                window.location.href = entry;
            }
        }
    }

    render() {
        const { getFieldDecorator } = this.props.form;
        const { loading, isLogin } = this.state;
        if (isLogin) {
            return (
                <Spin size="large" tip="Loading..." style={{ minHeight: '100%' }}>
                    <div style={{
                        minHeight: '800px',
                        height: '100vh'
                    }}>
                    </div>
                </Spin>
            );
        }
        return (
            <div>
                <div id='particles-js' className={styles['particles-js']}></div>
                <div className={styles.container}>
                    <div className={styles.logo}>
                        <img alt="logo" className={styles.img} src={logo} />
                    </div>
                    <Tabs type="card" className={styles.tabs} onChange={this.changeTabs} tabBarGutter={0}>
                        <TabPane tab="用户名密码" key="1">
                            <Form onSubmit={this.handleSubmit}>
                                <FormItem>
                                    { getFieldDecorator('username', {
                                        rules: [{ required: true, message: '请输入你的用户名!' }]
                                    })(<Input className={styles.input} prefix={<Icon type="user" className={styles.icon} />} size="large" placeholder="Username" />)}

                                </FormItem>
                                <FormItem>
                                    { getFieldDecorator('password', {
                                        rules: [{ required: true, message: '请输入密码!' }]
                                    })(<Input className={styles.input} prefix={<Icon type="lock" className={styles.icon} />} size="large" type="password" placeholder="Password" />)}
                                </FormItem>
                                <FormItem>
                                    { getFieldDecorator('remember', {
                                        valuePropName: 'checked',
                                        initialValue: true,
                                    })(<Checkbox>记住我</Checkbox>)}
                                    <a className={styles.forgot} href="">忘记密码？</a>
                                    <Button type="primary" htmlType="submit" className={styles.button} size="large" loading={loading}>
                                        登录
                                    </Button>
                                </FormItem>
                            </Form>
                        </TabPane>
                        <TabPane tab="用户中心" key="2">
                            <div style={{ height: 200, textAlign: 'center', lineHeight: '200px' }}>
                                <Spin tip="跳转至用户中心..."/>
                            </div>
                        </TabPane>
                    </Tabs>
                </div>
            </div>
        );
    }
}

const WrappedAuthForm = Form.create()(Auth);

export default WrappedAuthForm;
