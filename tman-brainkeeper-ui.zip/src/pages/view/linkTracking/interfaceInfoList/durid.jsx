import React, { Component } from 'react';
import { Switch, Select, message, Spin, Row, Col } from 'antd';
import moment from 'moment';
import { linkTrackingService } from 'service';
import QueryForm from 'component/queryForm';
import { fromJS } from 'immutable';
import withRef from 'component/hoc/withRef';
import { APPNAME } from 'js/variable';
import { storage } from 'js/util';
import TofuTable from './tofuTable';
import styles from './index.css';
import Connect from './charts/connect';

const { Option } = Select;

class Durid extends Component {
    constructor(props) {
        super(props);
        this.state = {
            ownKey: '7',
            dataSources: {},
            xAxisObj: {},
            seriesObj: {},
            dataType: [],
            datePickerDisabled: false,
            loading: false,
            opsList: [],
            layout: 12,
            connectList: [],
            xAxisConnect: [],
            seriesConnect: []
        };
        this.refreshOptions = [
            {
                text: 'OFF',
                value: ''
            },
            {
                text: '近5分钟',
                value: '300'
            },
            {
                text: '近15分钟',
                value: '900'
            },
            {
                text: '近30分钟',
                value: '1800'
            },
            {
                text: '近1小时',
                value: '3600'
            },
            {
                text: '近6小时',
                value: '21600'
            },
            {
                text: '近1天',
                value: '86400'
            },
            {
                text: '近3天',
                value: '259200'
            },
            {
                text: '近7天',
                value: '604800'
            },
            {
                text: '近30天',
                value: '2592000'
            }
        ];
        this.columns = [{
            title: '时间',
            dataIndex: 'eventTime',
            key: 'eventTime'
        }, {
            title: 'QPS',
            dataIndex: 'avgqps',
            key: 'avgqps'
        }, {
            title: '最大QPS',
            dataIndex: 'maxqps',
            key: 'maxqps'
        }, {
            title: '耗时',
            dataIndex: 'avgduration',
            key: 'avgduration'
        }, {
            title: '最大耗时',
            dataIndex: 'maxduration',
            key: 'maxduration'
        }, {
            title: '错误数',
            dataIndex: 'avgerror',
            key: 'avgerror'
        }];
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 默认查询
    initDefaultData(initFormCondition = null) {
        const { form } = this.duridRef.props;
        if (initFormCondition) {
            this.setState({
                loading: true,
                ...(initFormCondition.startEventTime && initFormCondition.endEventTime ? {} : { datePickerDisabled: true })
            }, () => {
                form.setFieldsValue(initFormCondition);
                this.onAppChange(initFormCondition.appName);
                this.getDurids();
            });
        } else {
            form.resetFields();
            const appName = storage.getStore(APPNAME);
            this.setState({
                loading: true,
                datePickerDisabled: true
            }, () => {
                form.setFieldsValue({ refresh: '21600', ...(appName ? { appName } : {}) });
                this.onAppChange(appName);
                this.getDurids();
            });
        }
    }
    // 查询主机列表
    getOpsList = async (value) => {
        const appName = value || storage.getStore(APPNAME);
        const { code, entry } = await linkTrackingService.getOpsList({ appName });
        let opsList = [];
        if (code === '0') {
            opsList = entry.map((item, index) => {
                return {
                    id: item.id,
                    endPoint: item.endPoint
                };
            });
            this.setState({
                opsList
            });
        }
    }
    // 获取数据库连接
    getDuridConnectList = async (appName, host) => {
        const { code, entry } = await linkTrackingService.getDuridConnectList({ appName, host, metric: 'druid.qps' });
        if (code === '0') {
            this.setState({
                connectList: entry
            });
        }
    }
    // 应用切换，导致主机列表更新
    onAppChange = (value) => {
        this.duridRef.props.form.setFieldsValue({ host: '', dbHost: '' });
        this.setState({
            opsList: [],
            connectList: []
        }, () => {
            this.getOpsList(value);
        });
    }
    // 主机切换，导致数据库连接列表更新
    changeOps = (value) => {
        const appName = storage.getStore(APPNAME);
        this.duridRef.props.form.setFieldsValue({ dbHost: '' });
        this.setState({
            connectList: []
        }, () => {
            this.getDuridConnectList(appName, value);
        });
    }
    // 获取系统资源占用情况数据总汇
    getDurids = async (e) => {
        e && e.preventDefault();
        this.duridRef.props.form.validateFields((err, values) => {
            if (!err) {
                if (e) {
                    this.setState({
                        loading: true
                    });
                }
                this.clearTimer();
                const formField = this.duridRef.props.form.getFieldsValue();
                let params = { ...formField };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                const { refresh, autoRefresh } = params;
                if (refresh) {
                    params = {
                        ...params,
                        ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
                    };
                    if (autoRefresh) {
                        this.autoRefreshChart(params, refresh);
                    } else {
                        this.setOptions(params);
                    }
                } else {
                    this.setOptions(params);
                }
            }
        });
    }
    // 轮询更新
    autoRefreshChart = async (params, refresh) => {
        this.clearTimer();
        const getParams = () => {
            return {
                ...params,
                ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
            };
        };
        await this.setOptions(params);
        this.timer = setTimeout(
            () => {
                this.autoRefreshChart(getParams(), refresh);
            },
            60000
        );
    }
    // 设置图标数据源
    setOptions = async (params) => {
        delete params.rangeTime;
        delete params.refresh;
        delete params.autoRefresh;
        const { ownKey } = this.state;
        const { activeKey } = this.props;
        // 判断是否发起请求
        if (this.duridRef && ownKey === activeKey) {
            let result;
            // 调用概览
            const { code, entry } = await linkTrackingService.getDuridsList({ ...params, metric: 'druid.qps' });
            if (code === '0') {
                const dataSources = {};
                const xAxisObj = {};
                const seriesObj = {};
                const dataType = [];
                if (code === '0' && entry) {
                    const { data } = entry;
                    for (const item in data) {
                        dataSources[item] = [];
                        xAxisObj[item] = [];
                        seriesObj[item] = [];
                        dataType.push(item);
                        data[item].forEach((it, index) => {
                            if (index < 5) {
                                dataSources[item].push({
                                    key: index,
                                    eventTime: moment(it.eventTime).format('HH:mm'),
                                    fullEventTime: it.eventTime,
                                    avgqps: it.data.qps_avg,
                                    maxqps: it.data.qps_max,
                                    avgduration: it.data.duration_avg,
                                    maxduration: it.data.duration_max,
                                    avgerror: it.data.error_avg
                                });
                            }
                            xAxisObj[item].push(it.eventTime);
                            seriesObj[item].push(it.data.qps_avg);
                        });
                        xAxisObj[item].reverse();
                        seriesObj[item].reverse();
                        // 缺5补到5
                        if (dataSources[item].length < 5) {
                            const diff = 5 - dataSources[item].length;
                            const diffArr = [];
                            for (let index = 0; index < diff; index += 1) {
                                diffArr.push({
                                    key: index + 5,
                                    eventTime: '-',
                                    fullEventTime: '-',
                                    avgqps: '-',
                                    maxqps: '-',
                                    avgduration: '-',
                                    maxduration: '-',
                                    avgerror: '-'
                                });
                            }
                            dataSources[item] = dataSources[item].concat(diffArr);
                        }
                    }
                    result = {
                        xAxisObj,
                        seriesObj,
                        dataSources,
                        dataType
                    };
                } else {
                    result = {
                        dataType: []
                    };
                }
            }
            const xAxisConnect = [];
            const seriesConnect = [{
                legend: '活跃连接数',
                data: []
            }, {
                legend: '连接数上限',
                data: []
            }];
            // 连接概览
            const { code: status, entry: connectData } = await linkTrackingService.getDuridsConnectList({ ...params, metric: 'druid.connection' });
            if (status === '0' && connectData) {
                const connections = [];
                const connectionLimits = [];
                connectData.forEach((item) => {
                    xAxisConnect.push(item.eventTime);
                    connections.push((item.data && item.data.connection) || 0);
                    connectionLimits.push((item.data && item.data.connection_limit) || 0);
                });
                seriesConnect[0].data = connections;
                seriesConnect[1].data = connectionLimits;
            }
            result = {
                ...result,
                xAxisConnect,
                seriesConnect,
                loading: false
            };
            this.setState(result);
        }
    }
    // 开启自动刷新后，静止datePicker
    changeSelect = (value) => {
        const { autoRefresh } = this.duridRef.props.form.getFieldsValue(['autoRefresh']);
        this.judgePickerDisabled(value, autoRefresh);
    }
    changeSwitch = (checked) => {
        const { refresh } = this.duridRef.props.form.getFieldsValue(['refresh']);
        this.judgePickerDisabled(refresh, checked);
    }
    judgePickerDisabled = (refresh, autoRefresh) => {
        if (autoRefresh && refresh) {
            message.success('已打开自动查询');
        }
        let flag = false;
        if (refresh !== '') {
            flag = true;
        }
        if (flag) {
            this.duridRef.props.form.resetFields([
                'rangeTime'
            ]);
        }
        this.setState({
            datePickerDisabled: flag
        }, () => {
            this.duridRef.props.form.validateFields(['rangeTime'], { force: true });
            if (autoRefresh && refresh) {
                this.getDurids();
            } else {
                this.clearTimer();
            }
        });
    }
    // 改变布局
    changeLayout = (layout) => {
        this.setState({
            layout
        });
    }
    render() {
        const {
            datePickerDisabled,
            opsList,
            connectList,
            loading,
            dataSources,
            xAxisObj,
            seriesObj,
            dataType,
            layout,
            xAxisConnect,
            seriesConnect
        } = this.state;
        const {
            refreshOptions,
            columns
        } = this;
        const baseFormItemsSetting = {
            app: {
                id: 'appName',
                span: 3,
                options: {
                    rules: [{
                        required: true,
                        message: '应用必选'
                    }]
                },
                onChange: this.onAppChange
            },
            rangeTime: {
                span: 5,
                options: {
                    initialValue: [],
                    rules: [{
                        type: 'array',
                        required: !datePickerDisabled,
                        message: '时间范围必选'
                    }]
                },
                extraProps: {
                    onOk: () => {
                        this.clearTimer();
                        this.duridRef.props.form.setFieldsValue({ autoRefresh: false, refresh: '' });
                    }
                }
            },
            button: {
                span: 2
            }
        };
        const refreshSelectComponent = (<Select onChange={this.changeSelect}>
            {
                refreshOptions.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const opsSelectComponent = (<Select style={{ width: '100%' }} disabled={opsList.length === 0} onChange={this.changeOps}>
            <Option value="">全部</Option>
            {
                opsList.map((item, index) => {
                    return (<Option value={item.endPoint} key={item.id} title={item.endPoint}>{item.endPoint}</Option>);
                })
            }
        </Select>);
        const connectSelectComponent = (<Select style={{ width: '100%' }} disabled={connectList.length === 0}>
            <Option value="">全部</Option>
            {
                connectList.map((item, index) => {
                    return (<Option key={item} title={item}>{item}</Option>);
                })
            }
        </Select>);
        const extraFormItem = [
            {
                span: 3,
                id: 'refresh',
                options: {
                    initialValue: ''
                },
                component: refreshSelectComponent
            },
            {
                span: 3,
                label: '自动更新',
                id: 'autoRefresh',
                options: {
                    valuePropName: 'checked',
                    initialValue: true
                },
                component: <Switch onChange={this.changeSwitch} />
            },
            {
                span: 4,
                id: 'host',
                label: '主机',
                options: {
                    initialValue: ''
                },
                className: styles.ops,
                component: opsSelectComponent
            },
            {
                span: 4,
                id: 'dbHost',
                label: '连接',
                options: {
                    initialValue: ''
                },
                className: styles.ops,
                component: connectSelectComponent
            }
        ];
        return (
            <div className="resouceOccupy">
                <Row gutter={16}>
                    <Col span={20}>
                        <QueryForm wrappedComponentRef={(ref) => { this.duridRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getDurids} />
                    </Col>
                    <Col span={4}>
                        <h4>
                            <span style={{ marginRight: '10px' }}>展示方式</span>
                            <Select style={{ width: 120 }} defaultValue={12} onChange={this.changeLayout}>
                                <Option value={12}>平铺</Option>
                                <Option value={24}>列表</Option>
                            </Select>
                        </h4>
                    </Col>
                </Row>
                {
                    loading ?
                        <Spin tip="Loading...">
                            <div style={{
                                minHeight: '800px'
                            }}></div>
                        </Spin>
                        : <div>
                            <h3 className={`${styles.title} system-interfaceInfo-title`}>
                                调用概览
                            </h3>
                            <Row gutter={16}>
                                {
                                    dataType.map((item, index) => {
                                        const title = <h4 style={{ marginTop: '20px', marginBottom: '10px' }}>
                                            {index + 1}.
                                            {item}
                                        </h4>;
                                        const dataSource = fromJS(dataSources[item]);
                                        const xAxis = fromJS(xAxisObj[item]);
                                        const series = fromJS(seriesObj[item]);
                                        return (
                                            <Col span={layout} key={item}>
                                                <TofuTable dataSource={dataSource} columns={columns} title={title} xAxis={xAxis} series={series}/>
                                            </Col>
                                        );
                                    })
                                }
                            </Row>
                            <h3 className={`${styles.title} system-interfaceInfo-title`}>
                                连接趋势
                            </h3>
                            <Connect xAxis={xAxisConnect} series={seriesConnect} />
                        </div>
                }
            </div>
        );
    }
}

export default withRef(Durid);
