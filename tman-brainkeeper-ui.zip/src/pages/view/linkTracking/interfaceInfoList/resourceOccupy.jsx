import React, { Component } from 'react';
import { Row, Col, Switch, Select, message, Spin, Anchor, Table, Collapse } from 'antd';
import moment from 'moment';
import { linkTrackingService } from 'service';
import QueryForm from 'component/queryForm';
import withRef from 'component/hoc/withRef';
import { APPNAME } from 'js/variable';
import { storage, isNotEmptyObject } from 'js/util';
import AreaStack from './charts/areaStack';
import styles from './index.css';

const { Option } = Select;
const { Link } = Anchor;
const { Panel } = Collapse;

class ResourceOccupy extends Component {
    constructor(props) {
        super(props);
        this.state = {
            ownKey: '2',
            datePickerDisabled: false,
            opsList: [],
            systemDetails: {},
            metricsDetails: {},
            types: []
        };
        this.refreshOptions = [
            {
                text: 'OFF',
                value: ''
            },
            {
                text: '近5分钟',
                value: '300'
            },
            {
                text: '近15分钟',
                value: '900'
            },
            {
                text: '近30分钟',
                value: '1800'
            },
            {
                text: '近1小时',
                value: '3600'
            },
            {
                text: '近6小时',
                value: '21600'
            },
            {
                text: '近1天',
                value: '86400'
            },
            {
                text: '近3天',
                value: '259200'
            },
            {
                text: '近7天',
                value: '604800'
            },
            {
                text: '近30天',
                value: '2592000'
            }
        ];
    }
    componentDidMount() {
        setTimeout(() => {
            window.scrollTo(0, 1); // 初始化scrollTop,触发锚点
        }, 1000);
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 默认查询
    initDefaultData(initFormCondition = null) {
        const { form } = this.resourceOccupyRef.props;
        if (initFormCondition) {
            this.setState({
                loading: true,
                ...(initFormCondition.startEventTime && initFormCondition.endEventTime ? {} : { datePickerDisabled: true })
            }, () => {
                form.setFieldsValue(initFormCondition);
                this.onAppChange(initFormCondition.col2);
                this.getResourceOccupy();
            });
        } else {
            form.resetFields();
            const col2 = storage.getStore(APPNAME);
            this.setState({
                loading: true,
                datePickerDisabled: true
            }, () => {
                form.setFieldsValue({ refresh: '21600', ...(col2 ? { col2 } : {}) });
                this.onAppChange(col2);
                this.getResourceOccupy();
            });
        }
    }
    // 查询主机列表
    getOpsList = async (appName) => {
        const col2 = appName || storage.getStore(APPNAME);
        const { code, entry } = await linkTrackingService.getOpsList({ appName: col2 });
        let opsList = [];
        if (code === '0') {
            opsList = entry.map((item, index) => {
                return {
                    id: item.id,
                    endPoint: item.endPoint
                };
            });
            this.setState({
                opsList
            });
        }
    }
    // 应用切换，导致主机列表更新
    onAppChange = (value) => {
        this.resourceOccupyRef.props.form.setFieldsValue({ col3: '' });
        this.setState({
            opsList: []
        }, () => {
            this.getOpsList(value);
        });
    }
    // 获取系统资源占用情况数据总汇
    getResourceOccupy = async (e) => {
        e && e.preventDefault();
        this.resourceOccupyRef.props.form.validateFields((err, values) => {
            if (!err) {
                if (e) {
                    this.setState({
                        loading: true
                    });
                }
                this.clearTimer();
                const formField = this.resourceOccupyRef.props.form.getFieldsValue();
                if (formField.app) {
                    formField.col2 = formField.app;
                }
                delete formField.app;
                let params = { ...formField };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                const { refresh, autoRefresh } = params;
                if (refresh) {
                    params = {
                        ...params,
                        ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
                    };
                    if (autoRefresh) {
                        this.autoRefreshChart(params, refresh);
                    } else {
                        this.setOptions(params);
                    }
                } else {
                    this.setOptions(params);
                }
            }
        });
    }
    // 轮询更新
    autoRefreshChart = async (params, refresh) => {
        this.clearTimer();
        const getParams = () => {
            return {
                ...params,
                ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
            };
        };
        await this.setOptions(params);
        this.timer = setTimeout(
            () => {
                this.autoRefreshChart(getParams(), refresh);
            },
            60000
        );
    }
    // 设置图标数据源
    setOptions = async (params) => {
        delete params.rangeTime;
        delete params.refresh;
        delete params.autoRefresh;
        const { ownKey } = this.state;
        const { activeKey } = this.props;
        // 判断是否发起请求
        if (this.resourceOccupyRef && ownKey === activeKey) {
            const { col3 } = this.resourceOccupyRef.props.form.getFieldsValue(['col3']);
            const res = await Promise.all([
                linkTrackingService.getOpsDetail({
                    appName: params.col2,
                    endPoint: params.col3
                }),
                linkTrackingService.getMetricsOpsTop5({
                    col2: params.col2,
                    startEventTime: params.startEventTime,
                    endEventTime: params.endEventTime,
                    minInterval: '1m'
                }),
                linkTrackingService.getMetricsOpsDetail({
                    col2: params.col2,
                    col3: params.col3,
                    metricName: col3 ? 'host.system.metric' : 'app.system.metric',
                    startEventTime: params.startEventTime,
                    endEventTime: params.endEventTime,
                    minInterval: '1m'
                })
            ]);
            let systemDetails = {};
            const metricsDetails = {};
            const types = [];
            res.forEach((item, index) => {
                // 系统详情
                if (index === 0 && item.code === '0') {
                    if (item.entry) {
                        systemDetails = JSON.parse(item.entry.configValue);
                    }
                }
                // 排名情况
                if (index === 1 && item.code === '0') {
                    if (item.entry) {
                        for (const i in item.entry) {
                            metricsDetails[i] = {};
                            item.entry[i].forEach((mitem, mindex) => {
                                mitem.key = mindex;
                            });
                            metricsDetails[i].top5 = item.entry[i];
                        }
                    }
                }
                // 指示趋势
                if (index === 2 && item.code === '0') {
                    if (item.entry) {
                        for (const j in item.entry) {
                            types.push({
                                name: j,
                                order: item.entry[j].order
                            });
                            types.sort((a, b) => {
                                return a.order - b.order;
                            });
                            metricsDetails[j].chart = item.entry[j];
                        }
                    }
                }
            });
            this.setState({
                loading: false,
                systemDetails,
                metricsDetails,
                types
            });
        }
    }
    // 开启自动刷新后，静止datePicker
    changeSelect = (value) => {
        const { autoRefresh } = this.resourceOccupyRef.props.form.getFieldsValue(['autoRefresh']);
        this.judgePickerDisabled(value, autoRefresh);
    }
    changeSwitch = (checked) => {
        const { refresh } = this.resourceOccupyRef.props.form.getFieldsValue(['refresh']);
        this.judgePickerDisabled(refresh, checked);
    }
    judgePickerDisabled = (refresh, autoRefresh) => {
        if (autoRefresh && refresh) {
            message.success('已打开自动查询');
        }
        let flag = false;
        if (refresh !== '') {
            flag = true;
        }
        if (flag) {
            this.resourceOccupyRef.props.form.resetFields([
                'rangeTime'
            ]);
        }
        this.setState({
            datePickerDisabled: flag
        }, () => {
            this.resourceOccupyRef.props.form.validateFields(['rangeTime'], { force: true });
            if (autoRefresh && refresh) {
                this.getResourceOccupy();
            } else {
                this.clearTimer();
            }
        });
    }
    // 切换主机
    changeEndPoint = (text) => {
        this.resourceOccupyRef.props.form.setFieldsValue({ col3: text });
        this.getResourceOccupy();
    }
    // 锚点不记录历史
    handleAnchorClick = (e) => {
        e.preventDefault();
    }
    render() {
        const {
            datePickerDisabled,
            opsList,
            loading,
            systemDetails,
            metricsDetails,
            types
        } = this.state;
        const {
            refreshOptions
        } = this;
        const baseFormItemsSetting = {
            app: {
                id: 'col2',
                span: 4,
                options: {
                    rules: [{
                        required: true,
                        message: '应用必选'
                    }]
                },
                onChange: this.onAppChange
            },
            rangeTime: {
                span: 5,
                options: {
                    initialValue: [],
                    rules: [{
                        type: 'array',
                        required: !datePickerDisabled,
                        message: '时间范围必选'
                    }]
                },
                extraProps: {
                    onOk: () => {
                        this.clearTimer();
                        this.resourceOccupyRef.props.form.setFieldsValue({ autoRefresh: false, refresh: '' });
                    }
                }
            },
            button: {
                span: 4
            }
        };
        const refreshSelectComponent = (<Select onChange={this.changeSelect}>
            {
                refreshOptions.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const opsSelectComponent = (<Select style={{ width: '100%' }} disabled={opsList.length === 0}>
            <Option value="">全部</Option>
            {
                opsList.map((item, index) => {
                    return (<Option value={item.endPoint} key={item.id} title={item.endPoint}>{item.endPoint}</Option>);
                })
            }
        </Select>);
        const extraFormItem = [
            {
                span: 2,
                id: 'refresh',
                options: {
                    initialValue: ''
                },
                component: refreshSelectComponent
            },
            {
                span: 3,
                label: '自动更新',
                id: 'autoRefresh',
                options: {
                    valuePropName: 'checked',
                    initialValue: true
                },
                component: <Switch onChange={this.changeSwitch} />
            },
            {
                span: 5,
                id: 'col3',
                label: '主机',
                options: {
                    initialValue: ''
                },
                className: styles.ops,
                component: opsSelectComponent
            }
        ];
        const metricsDetailsView = [];
        for (const i in metricsDetails) {
            const legend = [];
            const series = [];
            const { chart, top5 } = metricsDetails[i];
            if (chart && top5) {
                for (const j in chart.data) {
                    if (j !== 'eventTime') {
                        legend.push(j);
                        series.push({
                            name: j,
                            type: 'line',
                            stack: chart.showType === 'stack' ? i : null,
                            areaStyle: {
                                normal: {
                                    opacity: 0.3
                                }
                            },
                            lineStyle: {
                                normal: {
                                    width: 0.5
                                }
                            },
                            data: chart.data[j]
                        });
                    }
                }
                const columns = [{
                    title: 'top5 主机',
                    dataIndex: 'endPoint',
                    key: 'endPoint',
                    width: 180,
                    render: (text, record) => {
                        return (<div title={text} className={styles.endPoint}>
                            {
                                text !== '-' ?
                                    <a href="javascript:;;" onClick={this.changeEndPoint.bind(this, text)}>{text}</a>
                                    : <span>{text}</span>
                            }
                        </div>);
                    }
                }, {
                    title: top5.length === 0 ? '值' : top5[0].name,
                    dataIndex: 'value',
                    key: 'value'
                }];
                if (top5.length !== 0 && top5.length < 5) {
                    const diff = 5 - top5.length;
                    for (let index = 0; index < diff; index += 1) {
                        top5.push({
                            key: index + 5,
                            endPoint: '-',
                            value: '-'
                        });
                    }
                }
                metricsDetailsView.push(<Row gutter={16} order={chart.order} key={chart.order} id={`floor${chart.order}`} style={{ marginBottom: 40 }}>
                    <Col span={17}>
                        <AreaStack title={chart.title} xAxis={chart.data.eventTime} legend={legend} series={series} />
                    </Col>
                    <Col span={7}>
                        <Table dataSource={top5} columns={columns} pagination={false}/>
                    </Col>
                </Row>);
            }
        }
        metricsDetailsView.sort((a, b) => {
            return a.props.order - b.props.order;
        });
        const hasSystemDetail = isNotEmptyObject(systemDetails);
        const systemDetailsArr = [];
        if (hasSystemDetail) {
            for (const s in systemDetails) {
                systemDetailsArr.push({
                    name: s,
                    value: Array.isArray(systemDetails[s]) ? systemDetails[s].join('，') : systemDetails[s]
                });
            }
        }
        return (
            <div className="resouceOccupy">
                <QueryForm wrappedComponentRef={(ref) => { this.resourceOccupyRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getResourceOccupy} />
                {
                    loading ?
                        <Spin spinning={loading} tip="Loading...">
                            <div style={{
                                minHeight: '800px'
                            }}></div>
                        </Spin>
                        : <Row gutter={16} style={{ marginTop: 10 }}>
                            <Col span={3}>
                                <Anchor onClick={this.handleAnchorClick} bounds={300}>
                                    {
                                        types.map((item, index) => {
                                            return <Link href={`#floor${item.order}`} title={item.name} key={item.order} />;
                                        })
                                    }
                                    {
                                        hasSystemDetail ?
                                            <Link href={`#floor${types.length}`} title="系统详情" />
                                            : null
                                    }
                                </Anchor>
                            </Col>
                            <Col span={21}>
                                {metricsDetailsView}
                                {
                                    hasSystemDetail ?
                                        <Row gutter={16} id={`floor${types.length}`}>
                                            <Col span={24}>
                                                <Collapse activeKey={['1']}>
                                                    <Panel header="系统详情" key="1">
                                                        {
                                                            systemDetailsArr.map((item, index) => {
                                                                return <p key={index}><span className="system-resource-occupy" style={{ marginRight: 10 }}>{item.name}：</span><span>{item.value}</span></p>;
                                                            })
                                                        }
                                                    </Panel>
                                                </Collapse>
                                            </Col>
                                        </Row>
                                        : null
                                }
                            </Col>
                        </Row>
                }
            </div>
        );
    }
}

export default withRef(ResourceOccupy);
