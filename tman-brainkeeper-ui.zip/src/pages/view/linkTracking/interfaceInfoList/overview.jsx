import React, { Component } from 'react';
import { Row, Col, Switch, Select, Spin, message } from 'antd';
import moment from 'moment';
import { Link } from 'react-router-dom';
import { fromJS } from 'immutable';
import { connect } from 'react-redux';
import { linkTrackingService } from 'service';
import QueryForm from 'component/queryForm';
import withRef from 'component/hoc/withRef';
import { APPNAME } from 'js/variable';
import { storage, isNotEmptyObject } from 'js/util';
import Radar from './charts/radar';
import TofuTable from './tofuTable';
import QualityDetail from './qualityDetail';
import styles from './index.css';


const { Option } = Select;

class Overview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            ownKey: '1',
            dataSources: {},
            xAxisObj: {},
            seriesObj: {},
            dataType: [],
            datePickerDisabled: false,
            loading: false,
            layout: 12,
            // url search
            appName: '',
            startEventTime: '',
            endEventTime: '',
            qualityScore: {},
            // 异常日志
            xAxisArr: [],
            totalLogArr: [],
            logsArr: [],
            qualityList: {},
            qualityDetail: {}
        };
        this.columns = [{
            title: '时间',
            dataIndex: 'eventTime',
            key: 'eventTime'
        }, {
            title: 'QPS',
            dataIndex: 'avgqps',
            key: 'avgqps'
        }, {
            title: '最大QPS',
            dataIndex: 'maxqps',
            key: 'maxqps'
        }, {
            title: '耗时',
            dataIndex: 'avgduration',
            key: 'avgduration'
        }, {
            title: '最大耗时',
            dataIndex: 'maxduration',
            key: 'maxduration'
        }, {
            title: '错误/S',
            dataIndex: 'avgerror',
            key: 'avgerror',
            render: (text, row) => {
                if (text !== '-' && text !== 0) {
                    const { appName } = this.state;
                    const startEventTime = moment(row.fullEventTime).subtract(60, 'seconds').format('YYYY-MM-DD HH:mm:ss');
                    const endEventTime = row.fullEventTime;
                    return (
                        <Link to={{ pathname: this.props.paths.TraceInfoList.linkPath, search: `?appName=${appName}&onlyException=true&startEventTime=${startEventTime}&endEventTime=${endEventTime}` }} target="_blank">
                            {text}
                        </Link>
                    );
                }
                return text;
            }
        }];
        this.logColumns = [{
            title: '时间',
            dataIndex: 'time',
            key: 'time'
        }, {
            title: '日志总数',
            dataIndex: 'totalLog',
            key: 'totalLog'
        }, {
            title: '异常总数',
            dataIndex: 'totalException',
            key: 'totalException',
            render: (text, row) => {
                if (text !== '-' && text !== 0) {
                    const { appName } = this.state;
                    const startEventTime = moment(row.eventTime).subtract(60, 'seconds').format('YYYY-MM-DD HH:mm:ss');
                    const endEventTime = row.eventTime;
                    return (
                        <Link to={{ pathname: this.props.paths.ExceptionLog.linkPath, search: `?appName=${appName}&startEventTime=${startEventTime}&endEventTime=${endEventTime}` }} target="_blank">
                            {text}
                        </Link>
                    );
                }
                return text;
            }
        }];
        this.refreshOptions = [
            {
                text: 'OFF',
                value: ''
            },
            {
                text: '近5分钟',
                value: '300'
            },
            {
                text: '近15分钟',
                value: '900'
            },
            {
                text: '近30分钟',
                value: '1800'
            },
            {
                text: '近1小时',
                value: '3600'
            }
        ];
        this.orderOptions = [
            {
                text: 'QPS',
                value: 'avgqps'
            },
            {
                text: '耗时',
                value: 'avgduration'
            },
            {
                text: '错误',
                value: 'avgerror'
            }
        ];
    }
    componentDidMount() {
        this.initDefaultData();
    }
    initDefaultData(initFormCondition = null) {
        const { form } = this.overviewRef.props;
        if (initFormCondition) {
            this.setState({
                loading: true,
                ...(initFormCondition.startEventTime && initFormCondition.endEventTime ? {} : { datePickerDisabled: true })
            }, () => {
                form.setFieldsValue(initFormCondition);
                this.getOverviewList();
            });
        } else {
            form.resetFields();
            this.setState({
                loading: true,
                datePickerDisabled: true
            }, () => {
                const col2 = storage.getStore(APPNAME);
                form.setFieldsValue({ refresh: '900', ...(col2 ? { col2 } : {}) });
                this.getOverviewList();
            });
        }
        this.getQualityScore();
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 开启自动刷新后，静止datePicker
    changeSelect = (value) => {
        const { autoRefresh } = this.overviewRef.props.form.getFieldsValue(['autoRefresh']);
        this.judgePickerDisabled(value, autoRefresh);
    }
    changeSwitch = (checked) => {
        const { refresh } = this.overviewRef.props.form.getFieldsValue(['refresh']);
        this.judgePickerDisabled(refresh, checked);
    }
    judgePickerDisabled = (refresh, autoRefresh) => {
        if (autoRefresh && refresh) {
            message.success('已打开自动查询');
        }
        let flag = false;
        if (refresh !== '') {
            flag = true;
        }
        if (flag) {
            this.overviewRef.props.form.resetFields([
                'rangeTime'
            ]);
        }
        this.setState({
            datePickerDisabled: flag
        }, () => {
            this.overviewRef.props.form.validateFields(['rangeTime'], { force: true });
            if (autoRefresh && refresh) {
                this.getOverviewList();
            } else {
                this.clearTimer();
            }
        });
    }
    // 获取列表
    getOverviewList = async (e) => {
        e && e.preventDefault();
        this.overviewRef.props.form.validateFields((err, values) => {
            if (!err) {
                this.clearTimer();
                this.getQualityScore();
                this.getQualityList();
                let params = { ...this.overviewRef.props.form.getFieldsValue() };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                const { refresh, autoRefresh } = params;
                if (refresh) {
                    params = {
                        ...params,
                        ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
                    };
                    if (autoRefresh) {
                        this.autoRefreshChart(params, refresh);
                    } else {
                        this.setOptions(params);
                    }
                } else {
                    this.setOptions(params);
                }
            }
        });
    }
    // 轮询更新图表
    autoRefreshChart = async (params, refresh) => {
        this.clearTimer();
        const getParams = () => {
            return {
                ...params,
                ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
            };
        };
        await this.setOptions(params);
        this.timer = setTimeout(
            () => {
                this.autoRefreshChart(getParams(), refresh);
            },
            60000
        );
    }
    // 设置图标数据源
    setOptions = async (params) => {
        const { ownKey } = this.state;
        const { activeKey } = this.props;
        // 判断是否发起请求
        if (ownKey === activeKey) {
            delete params.rangeTime;
            delete params.refresh;
            delete params.autoRefresh;
            const { code, entry } = await linkTrackingService.getOverviewList(params); // 提供服务
            // 异常日志
            const { code: status, entry: logs } = await linkTrackingService.getErrorLogList({
                col1: 'app.log.exception',
                interval: '1m',
                ...params
            });
            let result;
            const dataSources = {};
            const xAxisObj = {};
            const seriesObj = {};
            const dataType = [];
            if (code === '0' && entry) {
                const { data } = entry;
                for (const item in data) {
                    dataSources[item] = [];
                    xAxisObj[item] = [];
                    seriesObj[item] = [];
                    dataType.push(item);
                    data[item].forEach((it, index) => {
                        if (index < 5) {
                            dataSources[item].push({
                                key: index,
                                eventTime: moment(it.eventTime).format('HH:mm'),
                                fullEventTime: it.eventTime,
                                avgqps: it.data.avgqps,
                                maxqps: it.data.maxqps,
                                avgduration: it.data.avgduration,
                                maxduration: it.data.maxduration,
                                avgerror: it.data.avgerror
                            });
                        }
                        xAxisObj[item].push(it.eventTime);
                        seriesObj[item].push(it.data.avgqps);
                    });
                    xAxisObj[item].reverse();
                    seriesObj[item].reverse();
                    // 缺5补到5
                    if (dataSources[item].length < 5) {
                        const diff = 5 - dataSources[item].length;
                        const diffArr = [];
                        for (let index = 0; index < diff; index += 1) {
                            diffArr.push({
                                key: index + 5,
                                eventTime: '-',
                                fullEventTime: '-',
                                avgqps: '-',
                                maxqps: '-',
                                avgduration: '-',
                                maxduration: '-',
                                avgerror: '-'
                            });
                        }
                        dataSources[item] = dataSources[item].concat(diffArr);
                    }
                }
                result = {
                    xAxisObj,
                    seriesObj,
                    dataSources,
                    dataType,
                    appName: params.col2,
                    startEventTime: params.startEventTime,
                    endEventTime: params.endEventTime
                };
            } else {
                result = {
                    dataType: []
                };
            }
            const xAxisArr = [];
            const totalLogArr = [];
            let logsArr = [];
            if (status === '0' && logs) {
                logs.forEach((item, index) => {
                    xAxisArr.push(item.endEventTime);
                    totalLogArr.push((item.data && item.data.totalLog) || 0);
                    if (index < 5) {
                        logsArr.push({
                            key: index,
                            eventTime: item.endEventTime,
                            time: moment(item.endEventTime).format('HH:mm'),
                            totalLog: (item.data && item.data.totalLog) || 0,
                            totalException: (item.data && item.data.totalException) || 0
                        });
                    }
                });
                // 缺5补到5
                if (logsArr.length < 5) {
                    const diff = 5 - logsArr.length;
                    const diffArr = [];
                    for (let index = 0; index < diff; index += 1) {
                        diffArr.push({
                            key: index + 5,
                            eventTime: '-',
                            time: '-',
                            totalLog: '-',
                            totalException: '-'
                        });
                    }
                    logsArr = logsArr.concat(diffArr);
                }
            }
            result = {
                ...result,
                xAxisArr,
                totalLogArr,
                logsArr,
                loading: false
            };
            this.setState(result);
        }
    }
    // 改变布局
    changeLayout = (layout) => {
        this.setState({
            layout
        });
    }
    // 获取应用质量评分
    getQualityScore = async () => {
        const { col2 } = this.overviewRef.props.form.getFieldsValue();
        const { code, entry } = await linkTrackingService.getQualityScore({ appName: col2 });
        if (code === '0' && entry) {
            this.setState({
                qualityScore: entry
            });
        }
    }
    // 获取应用质量明细
    getQualityList = async () => {
        const { col2 } = this.overviewRef.props.form.getFieldsValue();
        const { code, entry } = await linkTrackingService.getQualityList({ appName: col2 });
        if (code === '0' && entry) {
            this.setState({
                qualityList: entry,
                qualityDetail: {} // 清空
            });
        }
    }
    // 质量平分详情
    onSelect = (type) => {
        const { qualityList } = this.state;
        this.setState({
            qualityDetail: qualityList[type] || {}
        });
    }
    render() {
        const {
            datePickerDisabled,
            dataSources,
            dataType,
            appName,
            xAxisObj,
            seriesObj,
            loading,
            layout,
            qualityScore,
            xAxisArr,
            totalLogArr,
            logsArr,
            qualityDetail
        } = this.state;
        const {
            refreshOptions,
            orderOptions,
            columns,
            logColumns
        } = this;
        const baseFormItemsSetting = {
            app: {
                id: 'col2',
                span: 4,
                options: {
                    rules: [{
                        required: true,
                        message: '应用必选'
                    }]
                }
            },
            rangeTime: {
                span: 5,
                options: {
                    initialValue: [],
                    rules: [{
                        type: 'array',
                        required: !datePickerDisabled,
                        message: '时间范围必选'
                    }]
                },
                extraProps: {
                    onOk: () => {
                        this.clearTimer();
                        this.overviewRef.props.form.setFieldsValue({ autoRefresh: false, refresh: '' });
                    }
                }
            },
            button: {
                span: 4
            }
        };
        const refreshSelectComponent = (<Select onChange={this.changeSelect}>
            {
                refreshOptions.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const orderSelectComponent = (<Select>
            {
                orderOptions.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const extraFormItem = [
            {
                span: 3,
                id: 'refresh',
                options: {
                    initialValue: ''
                },
                component: refreshSelectComponent
            },
            {
                span: 3,
                label: '自动更新',
                id: 'autoRefresh',
                options: {
                    valuePropName: 'checked',
                    initialValue: true
                },
                component: <Switch onChange={this.changeSwitch} />
            },
            {
                span: 4,
                label: '排序',
                id: 'orderBy',
                options: {
                    initialValue: 'avgqps'
                },
                className: styles.formItem,
                component: orderSelectComponent
            }
        ];
        return (
            <div>
                <Row gutter={16}>
                    <Col span={20}>
                        <QueryForm wrappedComponentRef={(ref) => { this.overviewRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getOverviewList} />
                    </Col>
                    <Col span={4}>
                        <h4>
                            <span style={{ marginRight: '10px' }}>展示方式</span>
                            <Select style={{ width: 120 }} defaultValue={12} onChange={this.changeLayout}>
                                <Option value={12}>平铺</Option>
                                <Option value={24}>列表</Option>
                            </Select>
                        </h4>
                    </Col>
                </Row>
                {
                    loading ?
                        <Spin tip="Loading...">
                            <div style={{
                                minHeight: '800px'
                            }}></div>
                        </Spin>
                        : <div>
                            <h3 className={`${styles.title} system-interfaceInfo-title`}>
                                质量评分
                            </h3>
                            <Row gutter={16}>
                                <Col span={12}>
                                    <Radar qualityScore={qualityScore} onSelect={this.onSelect} />
                                </Col>
                                <Col span={12}>
                                    {
                                        isNotEmptyObject(qualityDetail) ? (
                                            <QualityDetail detail={qualityDetail}/>
                                        ) : null
                                    }
                                </Col>
                            </Row>
                            <h3 className={`${styles.title} system-interfaceInfo-title`}>
                                提供的服务
                            </h3>
                            <Row gutter={16}>
                                {
                                    dataType.map((item, index) => {
                                        const title = <h4 style={{ marginTop: '20px', marginBottom: '10px' }}>
                                            {index + 1}.
                                            <a href="javascript:;;" onClick={this.props.onChange.bind(this, '3')} style={{ marginRight: '10px', cursor: 'pointer' }}>
                                                {item}
                                            </a>
                                            <Link to={{ pathname: this.props.paths.InterfaceInfo.linkPath, search: `?col2=${appName}&refresh=900&autoRefresh=true` }} target="_blank" style={{ marginRight: '10px' }}>
                                                [调用明细]
                                            </Link>
                                            <Link to={{ pathname: this.props.paths.TraceInfoList.linkPath, search: `?appName=${appName}` }} target="_blank">
                                                [查看调用链]
                                            </Link>
                                        </h4>;
                                        const dataSource = fromJS(dataSources[item]);
                                        const xAxis = fromJS(xAxisObj[item]);
                                        const series = fromJS(seriesObj[item]);
                                        return (
                                            <Col span={layout} key={item}>
                                                <TofuTable dataSource={dataSource} columns={columns} title={title} xAxis={xAxis} series={series}/>
                                            </Col>
                                        );
                                    })
                                }
                            </Row>
                            <h3 className={`${styles.title} system-interfaceInfo-title`}>
                                日志概览
                            </h3>
                            <Row gutter={16}>
                                <Col span={layout}>
                                    <TofuTable dataSource={fromJS(logsArr)} columns={logColumns} title={null} xAxis={fromJS(xAxisArr)} series={fromJS(totalLogArr)}/>
                                </Col>
                            </Row>
                        </div>
                }
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(withRef(Overview));
