import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

const indicators = [
    { name: '可用性（Availability）', indicatorsType: 'availability', max: 100 },
    { name: '资源消耗（Cost）', indicatorsType: 'cost', max: 100 },
    { name: '性能（Performance）', indicatorsType: 'performance', max: 100 },
    { name: '错误率（ErrorRate）', indicatorsType: 'errorRate', max: 100 },
    { name: '代码质量（CodeQuality）', indicatorsType: 'codeQuality', max: 100 },
];

export default class Radar extends Component {
    chartReady = (echartObj) => {
        indicators.forEach((item, index) => {
            item.color = echartObj._theme.color[index];
        });
        echartObj.setOption({
            radar: {
                indicator: indicators
            },
        });
        // radar点击事件
        echartObj.on('click', (params) => {
            const { onSelect } = this.props;
            if (params.componentType === 'radar') {
                const indicatorsItem = indicators.find((item, index) => { return item.name === params.name; });
                onSelect && onSelect(indicatorsItem.indicatorsType);
            }
        });
    }
    render() {
        const {
            qualityScore
        } = this.props;
        const {
            cost,
            availability,
            performance,
            errorRate,
            codeQuality,
            total
        } = qualityScore;
        const options = {
            tooltip: {
                formatter: (params) => {
                    return '质量评分说明(每项评分具备不同的权重，最终将共同决定总评分值)：<br/>1.可用性：由近30天告警次数决定<br/>2.代码质量：由应用的代码检查工具所计算出的代码质量评分决定<br/>3.错误率：由近30天的RPC调用错误数和错误日志数决定<br/>4.性能：由QPS和延时比例决定<br/>5.资源消耗：由当前应用占用的服务节点数决定';
                },
                position: [650, 50]
            },
            backgroundColor: 'transparent',
            title: {
                text: `${total}分`,
                textAlign: 'center',
                left: '70%',
                top: '10%',
                textStyle: {
                    fontSize: 20,
                }
            },
            radar: {
                triggerEvent: true, // 响应和触发鼠标事件
                indicator: indicators
            },
            series: [{
                type: 'radar',
                itemStyle: {
                    normal: {
                        areaStyle: {
                            type: 'default'
                        }
                    }
                },
                data: [
                    {
                        value: [availability || 0, cost || 0, performance || 0, errorRate || 0, codeQuality || 0],
                        name: '质量评分'
                    }
                ],
                label: {
                    show: true,
                    formatter: '{c}分',
                    position: 'inside'
                },
                animation: true,
                animationDuration: 1000,
                animationEasing: 'cubicInOut',
                animationDurationUpdate: 1000,
                animationEasingUpdate: 'cubicInOut'
            }],
        };
        return (
            <div>
                <ReactEcharts ref='echarts_react'
                    option={options}
                    onChartReady={this.chartReady}
                    style={{ height: '300px', width: '100%', border: 'none' }} />
            </div>
        );
    }
}
