import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class AreaStack extends Component {
    render() {
        const {
            xAxis,
            series,
            legend,
            title
        } = this.props;
        const options = {
            title: {
                text: title
            },
            tooltip: {
                trigger: 'axis',
            },
            grid: {
                left: '40px',
                right: '20px',
                bottom: '20px',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: legend
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: xAxis
                }
            ],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 325, width: '100%' }} />
            </div>
        );
    }
}
