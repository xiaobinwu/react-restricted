import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Connect extends Component {
    render() {
        const {
            xAxis,
            series,
            yTtitle
        } = this.props;
        const legends = [];
        const seriesArray = series.map((item) => {
            legends.push(item.legend);
            return {
                name: item.legend,
                type: 'line',
                smooth: true,
                data: item.data
            };
        });
        const options = {
            tooltip: {
                trigger: 'axis',
            },
            grid: {
                left: '80px',
                right: '80px'
            },
            toolbox: {
                feature: {
                    dataZoom: {
                        yAxisIndex: false
                    },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: legends
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            xAxis: [
                {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    data: xAxis
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: yTtitle || '连接数',
                    position: 'left',
                    min: 0,
                    max: (value) => {
                        if (value.max <= 10) {
                            return 10;
                        }
                        return value.max;
                    },
                    axisLabel: {
                        formatter: '{value}'
                    }
                }
            ],
            series: seriesArray
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%' }}/>
            </div>
        );
    }
}
