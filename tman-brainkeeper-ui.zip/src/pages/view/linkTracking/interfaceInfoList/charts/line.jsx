import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Line extends Component {
    render() {
        const {
            xAxis,
            series,
        } = this.props;
        const options = {
            backgroundColor: 'transparent',
            grid: {
                top: 1,
                bottom: 1,
                right: 1,
                left: 1
            },
            xAxis: {
                type: 'category',
                show: false,
                axisLabel: {
                    show: false
                },
                splitLine: {
                    show: false
                },
                data: xAxis
            },
            yAxis: {
                type: 'value',
                show: false,
                min: 0,
                max: (value) => {
                    return value.max + value.min;
                },
                splitLine: {
                    show: false
                },
                axisLabel: {
                    show: false
                }
            },
            series: [{
                showSymbol: false,
                data: series,
                type: 'line',
                smooth: true
            }]
        };
        return (
            <div>
                <ReactEcharts ref='echarts_react'
                    option={options}
                    style={{ height: '100px', width: '100%' }} />
            </div>
        );
    }
}
