import React, { Component } from 'react';
import { Tabs } from 'antd';
import moment from 'moment';
import { getQueryString, isNotEmptyObject } from 'js/util';
import withLazyComponent from 'component/hoc/withLazyComponent';


// 应用概览
const overviewPromise = import(/* webpackChunkName: 'interfaceInfoList-overview' */ './overview');

// 系统信息
const resourceOccupyPromise = import(/* webpackChunkName: 'interfaceInfoList-resourceOccupy' */ './resourceOccupy');

// 提供的RPC服务
const rpcServicePromise = import(/* webpackChunkName: 'interfaceInfoList-rpcService' */ './rpcService');

// 依赖的服务
const dependentServicePromise = import(/* webpackChunkName: 'interfaceInfoList-dependentService' */ './dependentService');

// 被依赖的服务
const dependentedServicePromise = import(/* webpackChunkName: 'interfaceInfoList-dependentedService' */ './dependentedService');

// dubbo指标
const dubboPromise = import(/* webpackChunkName: 'interfaceInfoList-dubbo' */ './dubbo');

// durid指标
const duridPromise = import(/* webpackChunkName: 'interfaceInfoList-durid' */ './durid');

// redis指标
const redisPromise = import(/* webpackChunkName: 'interfaceInfoList-redis' */ './redis');

// rabbitmq指标
const rabbitmqPromise = import(/* webpackChunkName: 'interfaceInfoList-rabbitmq' */ './rabbitmq');

// http指标
const httpPromise = import(/* webpackChunkName: 'interfaceInfoList-http' */ './http');

const { TabPane } = Tabs;


// 配置
const setting = [
    // 应用概览
    {
        title: '应用概览',
        ref: React.createRef(),
        promise: overviewPromise,
        component: withLazyComponent(() => overviewPromise),
    },
    // 系统信息
    {
        title: '系统信息',
        ref: React.createRef(),
        promise: resourceOccupyPromise,
        component: withLazyComponent(() => resourceOccupyPromise),
    },
    // 提供的RPC服务
    {
        title: '提供的RPC服务',
        ref: React.createRef(),
        promise: rpcServicePromise,
        component: withLazyComponent(() => rpcServicePromise)
    },
    // 依赖的服务
    {
        title: '依赖的服务',
        ref: React.createRef(),
        promise: dependentServicePromise,
        component: withLazyComponent(() => dependentServicePromise)
    },
    // 被依赖的服务
    {
        title: '被依赖的服务',
        ref: React.createRef(),
        promise: dependentedServicePromise,
        component: withLazyComponent(() => dependentedServicePromise)
    },
    // dubbo指标
    {
        title: 'Dubbo',
        ref: React.createRef(),
        promise: dubboPromise,
        component: withLazyComponent(() => dubboPromise)
    },
    // durid指标
    {
        title: 'Durid',
        ref: React.createRef(),
        promise: duridPromise,
        component: withLazyComponent(() => duridPromise)
    },
    // redis指标
    {
        title: 'Redis',
        ref: React.createRef(),
        promise: redisPromise,
        component: withLazyComponent(() => redisPromise)
    },
    // rabbitmq指标
    {
        title: 'Rabbitmq',
        ref: React.createRef(),
        promise: rabbitmqPromise,
        component: withLazyComponent(() => rabbitmqPromise)
    },
    // http指标
    {
        title: 'Http',
        ref: React.createRef(),
        promise: httpPromise,
        component: withLazyComponent(() => httpPromise)
    }
];


class InterfaceInfoList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeKey: '1'
        };
    }
    componentDidMount() {
        const result = getQueryString();
        if (isNotEmptyObject(result)) {
            const { activeKey, ...resetResult } = result;
            this.setState({
                activeKey: activeKey || '1'
            }, async () => {
                await setting[activeKey - 1].promise; // 等待promise完成
                this.executeTabSwitch(this.handleFormCondition(resetResult));
            });
        }
    }
    handleFormCondition = (result) => {
        if (result.startEventTime && result.endEventTime) {
            result = { ...result, ...{ rangeTime: [moment(result.startEventTime), moment(result.endEventTime)], autoRefresh: false, refresh: '' } };
        }
        const autoRefresh = result.autoRefresh === 'true';
        if (autoRefresh) {
            result = { ...result, ...{ autoRefresh, refresh: result.refresh } };
        }
        return isNotEmptyObject(result) ? result : null;
    }
    onChange = (activeKey) => {
        this.setState({
            activeKey
        }, async () => {
            await setting[activeKey - 1].promise; // 等待promise完成
            this.executeTabSwitch(null);
        });
    }
    // 切换tab从新查询数据
    executeTabSwitch = (initFormCondition) => {
        const { activeKey } = this.state;
        const { ref } = setting[activeKey - 1];
        ref.initDefaultData && ref.initDefaultData(initFormCondition);
    }
    render() {
        const { activeKey } = this.state;
        return (
            <div>
                <Tabs activeKey={activeKey} onChange={this.onChange}>
                    {
                        setting.map((item, index) => {
                            const TabPaneComponent = item.component;
                            return (<TabPane tab={item.title} key={String(index + 1)}>
                                <TabPaneComponent onChange={this.onChange} getInstance={(ref) => { item.ref = ref; }} activeKey={activeKey} />
                            </TabPane>);
                        })
                    }
                </Tabs>
            </div>
        );
    }
}

export default InterfaceInfoList;
