import React from 'react';

const QualityDetail = (props) => {
    const { detail } = props;
    return (
        <div className="ant-table ant-table-small">
            <div className="ant-table-content">
                <div className="ant-table-body">
                    <table>
                        <tbody className="ant-table-tbody">
                            {
                                Object.keys(detail).map((item, index) => {
                                    return (
                                        <tr className="ant-table-row" key={index}>
                                            <td>{item}</td>
                                            <td>{detail[item]}</td>
                                        </tr>
                                    );
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default QualityDetail;
