import React, { Component } from 'react';
import { Row, Col, Switch, Select, Icon, Spin, message } from 'antd';
import moment from 'moment';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { fromJS } from 'immutable';
import withRef from 'component/hoc/withRef';
import { linkTrackingService } from 'service';
import QueryForm from 'component/queryForm';
import { APPNAME, SERVICENAME, METHODNAME } from 'js/variable';
import { storage } from 'js/util';
import withPermission from 'component/hoc/withPermission';
import TofuTable from './tofuTable';
import styles from './index.css';


const { Option } = Select;

class DependentService extends Component {
    constructor(props) {
        super(props);
        this.state = {
            ownKey: '4',
            dataSources: {},
            xAxisObj: {},
            seriesObj: {},
            dataType: [],
            favorites: [],
            total: 0,
            limit: 0,
            datePickerDisabled: false,
            loading: false,
            layout: 12,
            // url search
            appName: '',
            startEventTime: '',
            endEventTime: '',
            serviceNameOrMethodNameDisabled: true
        };
        this.columns = [{
            title: '时间',
            dataIndex: 'eventTime',
            key: 'eventTime'
        }, {
            title: 'QPS',
            dataIndex: 'avgqps',
            key: 'avgqps'
        }, {
            title: '最大QPS',
            dataIndex: 'maxqps',
            key: 'maxqps'
        }, {
            title: '耗时',
            dataIndex: 'avgduration',
            key: 'avgduration'
        }, {
            title: '最大耗时',
            dataIndex: 'maxduration',
            key: 'maxduration'
        }, {
            title: '错误/S',
            dataIndex: 'avgerror',
            key: 'avgerror',
            render: (text, row) => {
                if (text !== '-' && text !== 0) {
                    const { appName } = this.state;
                    const startEventTime = moment(row.fullEventTime).subtract(60, 'seconds').format('YYYY-MM-DD HH:mm:ss');
                    const endEventTime = row.fullEventTime;
                    return (
                        <Link to={{ pathname: this.props.paths.TraceInfoList.linkPath, search: `?appName=${appName}&serviceName=${row.col3}&methodName=${row.col4}&onlyException=true&startEventTime=${startEventTime}&endEventTime=${endEventTime}` }} target="_blank">
                            {text}
                        </Link>
                    );
                }
                return text;
            }
        }];
        this.refreshOptions = [
            {
                text: 'OFF',
                value: ''
            },
            {
                text: '近5分钟',
                value: '300'
            },
            {
                text: '近15分钟',
                value: '900'
            },
            {
                text: '近30分钟',
                value: '1800'
            },
            {
                text: '近1小时',
                value: '3600'
            }
        ];
        this.orderOptions = [
            {
                text: 'QPS',
                value: 'avgqps'
            },
            {
                text: '耗时',
                value: 'avgduration'
            },
            {
                text: '错误',
                value: 'avgerror'
            }
        ];
        this.limitOptions = [
            {
                text: '10',
                value: '10'
            },
            {
                text: '20',
                value: '20'
            },
            {
                text: '50',
                value: '50'
            },
            {
                text: '100',
                value: '100'
            }
        ];
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 默认查询
    initDefaultData(initFormCondition = null) {
        const { form } = this.interFaceRef.props;
        if (initFormCondition) {
            this.setState({
                loading: true,
                ...(initFormCondition.startEventTime && initFormCondition.endEventTime ? {} : { datePickerDisabled: true })
            }, () => {
                form.setFieldsValue(initFormCondition);
                this.getProviderList();
            });
        } else {
            form.resetFields();
            const col2 = storage.getStore(APPNAME);
            const col3 = storage.getStore(SERVICENAME);
            const col4 = storage.getStore(METHODNAME);
            this.setState({
                loading: true,
                datePickerDisabled: true
            }, () => {
                form.setFieldsValue({
                    refresh: '900',
                    ...(col2 ? { col2 } : {}),
                    ...(col3 ? { col3 } : {}),
                    ...(col4 ? { col4 } : {})
                });
                this.getProviderList();
            });
        }
    }
    // serviceName选择回调
    serviceChange = (value) => {
        this.setState({
            serviceNameOrMethodNameDisabled: value === ''
        }, () => {
            this.interFaceRef.props.form.validateFields(['col2', 'col3'], { force: true });
        });
    }
    // 开启自动刷新后，静止datePicker
    changeSelect = (value) => {
        const { autoRefresh } = this.interFaceRef.props.form.getFieldsValue(['autoRefresh']);
        this.judgePickerDisabled(value, autoRefresh);
    }
    changeSwitch = (checked) => {
        const { refresh } = this.interFaceRef.props.form.getFieldsValue(['refresh']);
        this.judgePickerDisabled(refresh, checked);
    }
    judgePickerDisabled = (refresh, autoRefresh) => {
        if (autoRefresh && refresh) {
            message.success('已打开自动查询');
        }
        let flag = false;
        if (refresh !== '') {
            flag = true;
        }
        if (flag) {
            this.interFaceRef.props.form.resetFields([
                'rangeTime'
            ]);
        }
        this.setState({
            datePickerDisabled: flag
        }, () => {
            this.interFaceRef.props.form.validateFields(['rangeTime'], { force: true });
            if (autoRefresh && refresh) {
                this.getProviderList();
            } else {
                this.clearTimer();
            }
        });
    }
    // 获取列表
    getProviderList = async (e) => {
        e && e.preventDefault();
        this.interFaceRef.props.form.validateFields((err, values) => {
            if (!err) {
                this.clearTimer();
                let params = { ...this.interFaceRef.props.form.getFieldsValue() };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                const { refresh, autoRefresh } = params;
                if (refresh) {
                    params = {
                        ...params,
                        ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
                    };
                    if (autoRefresh) {
                        this.autoRefreshChart(params, refresh);
                    } else {
                        this.setOptions(params);
                    }
                } else {
                    this.setOptions(params);
                }
            }
        });
    }
    // 轮询更新图表
    autoRefreshChart = async (params, refresh) => {
        this.clearTimer();
        const getParams = () => {
            return {
                ...params,
                ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
            };
        };
        await this.setOptions(params);
        this.timer = setTimeout(
            () => {
                this.autoRefreshChart(getParams(), refresh);
            },
            60000
        );
    }
    // 设置图标数据源
    setOptions = async (params) => {
        const { ownKey } = this.state;
        const { activeKey } = this.props;
        // 判断是否发起请求
        if (ownKey === activeKey) {
            delete params.rangeTime;
            delete params.refresh;
            delete params.autoRefresh;
            const { code, entry } = await linkTrackingService.getProviderList({
                interval: '1m',
                ...params
            });
            const dataSources = {};
            const xAxisObj = {};
            const seriesObj = {};
            const dataType = [];
            const favorites = [];
            if (code === '0' && entry) {
                if (code === '0' && entry) {
                    const { data, total } = entry;
                    for (const item in data) {
                        dataSources[item] = [];
                        xAxisObj[item] = [];
                        seriesObj[item] = [];
                        dataType.push(item);
                        favorites.push(false);
                        data[item].forEach((it, index) => {
                            if (index < 5) {
                                dataSources[item].push({
                                    key: index,
                                    col3: it.col3,
                                    col4: it.col4,
                                    eventTime: moment(it.eventTime).format('HH:mm'),
                                    fullEventTime: it.eventTime,
                                    avgqps: it.data.avgqps,
                                    maxqps: it.data.maxqps,
                                    avgduration: it.data.avgduration,
                                    maxduration: it.data.maxduration,
                                    avgerror: it.data.avgerror
                                });
                            }
                            xAxisObj[item].push(it.eventTime);
                            seriesObj[item].push(it.data.avgqps);
                        });
                        xAxisObj[item].reverse();
                        seriesObj[item].reverse();
                        // 缺5补到5
                        if (dataSources[item].length < 5) {
                            const diff = 5 - dataSources[item].length;
                            const diffArr = [];
                            for (let index = 0; index < diff; index += 1) {
                                diffArr.push({
                                    key: index + 5,
                                    col3: '-',
                                    col4: '-',
                                    eventTime: '-',
                                    avgqps: '-',
                                    maxqps: '-',
                                    avgduration: '-',
                                    maxduration: '-',
                                    avgerror: '-',
                                    fullEventTime: '-'
                                });
                            }
                            dataSources[item] = dataSources[item].concat(diffArr);
                        }
                    }
                    this.setState({
                        xAxisObj,
                        seriesObj,
                        dataSources,
                        dataType,
                        favorites,
                        total: total || 0,
                        limit: Math.min(params.limit, total || 0),
                        appName: params.col2,
                        startEventTime: params.startEventTime,
                        endEventTime: params.endEventTime,
                        loading: false
                    });
                }
            } else {
                this.setState({
                    loading: false,
                    dataType: [],
                    total: 0,
                    limit: 0,
                });
            }
        }
    }
    // 改变布局
    changeLayout = (layout) => {
        this.setState({
            layout
        });
    }
    // 添加新接口到收藏列表
    addFavorite = async (item, index) => {
        return message.warning('敬请期待');
        // const res = await linkTrackingService.addFavorite({ serviceId: item.id });
        // if (res.code === '0') {
        //     this.setState((prevState) => {
        //         prevState.favorites.splice(index, 1, true);
        //         return { favorites: prevState.favorites };
        //     });
        //     message.success(res.message);
        // }
    }
    // 下钻
    getDependentService = (item) => {
        const { form } = this.interFaceRef.props;
        const { appName, name, method } = item;
        form.setFieldsValue({
            ...(appName ? { col2: appName } : {}),
            ...(name ? { col3: name } : {}),
            ...(method ? { col4: method } : {})
        });
        this.getProviderList();
    }
    render() {
        const {
            datePickerDisabled,
            dataSources,
            dataType,
            favorites,
            total,
            limit,
            startEventTime,
            endEventTime,
            xAxisObj,
            seriesObj,
            loading,
            layout,
            serviceNameOrMethodNameDisabled
        } = this.state;
        const {
            refreshOptions,
            orderOptions,
            limitOptions,
            columns
        } = this;
        const baseFormItemsSetting = {
            app: {
                id: 'col2',
                span: 3,
                options: {
                    rules: [{
                        required: true,
                        message: '应用必选'
                    }]
                }
            },
            service: {
                id: 'col3',
                span: 4,
                options: {
                    initialValue: '',
                    rules: [{
                        required: !serviceNameOrMethodNameDisabled,
                        message: '服务名必选'
                    }]
                },
                onChange: this.serviceChange
            },
            method: {
                id: 'col4',
                span: 3,
                options: {
                    initialValue: '',
                    rules: [{
                        required: !serviceNameOrMethodNameDisabled,
                        message: '方法名必选'
                    }]
                }
            },
            rangeTime: {
                span: 5,
                options: {
                    initialValue: [],
                    rules: [{
                        type: 'array',
                        required: !datePickerDisabled,
                        message: '时间范围必选'
                    }]
                },
                extraProps: {
                    onOk: () => {
                        this.clearTimer();
                        this.interFaceRef.props.form.setFieldsValue({ autoRefresh: false, refresh: '' });
                    }
                }
            },
            button: {
                span: 4
            }
        };
        const refreshSelectComponent = (<Select onChange={this.changeSelect}>
            {
                refreshOptions.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const orderSelectComponent = (<Select>
            {
                orderOptions.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const limitSelectComponent = (<Select>
            {
                limitOptions.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const extraFormItem = [
            {
                span: 2,
                id: 'refresh',
                options: {
                    initialValue: ''
                },
                component: refreshSelectComponent
            },
            {
                span: 3,
                label: '自动更新',
                id: 'autoRefresh',
                options: {
                    valuePropName: 'checked',
                    initialValue: true
                },
                component: <Switch onChange={this.changeSwitch} />
            },
            {
                span: 3,
                label: '排序',
                id: 'orderBy',
                options: {
                    initialValue: 'avgqps'
                },
                className: styles.formItem,
                component: orderSelectComponent
            },
            {
                span: 4,
                label: '结果数',
                id: 'limit',
                options: {
                    initialValue: '10'
                },
                className: styles.formItem,
                component: limitSelectComponent
            }
        ];
        return (
            <div>
                <QueryForm wrappedComponentRef={(ref) => { this.interFaceRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getProviderList} />
                {
                    loading ?
                        <Spin spinning={loading} tip="Loading...">
                            <div style={{
                                minHeight: '800px'
                            }}></div>
                        </Spin>
                        : <div>
                            <h4>
                                <span>结果数：{total}，</span>
                                <span>已显示前{limit}项，</span>
                                <span style={{ marginRight: '10px' }}>展示方式</span>
                                <Select style={{ width: 120 }} defaultValue={12} onChange={this.changeLayout}>
                                    <Option value={12}>平铺</Option>
                                    <Option value={24}>列表</Option>
                                </Select>
                            </h4>
                            <Row gutter={16}>
                                {
                                    dataType.map((item, index) => {
                                        const parseItem = JSON.parse(item);
                                        const title = <h4 style={{ marginTop: '20px', marginBottom: '10px' }}>
                                            {index + 1}.
                                            <Link to={{ pathname: this.props.paths.InterfaceInfo.linkPath, search: `?col2=${parseItem.appName}&col3=${parseItem.name}&col4=${parseItem.method}&startEventTime=${startEventTime}&endEventTime=${endEventTime}` }} target="_blank">
                                                {parseItem.appName}{(parseItem.name && parseItem.method) ? `@${parseItem.name}@${parseItem.method}` : null}
                                            </Link>
                                            {(parseItem.name && parseItem.method) ? <br /> : null}
                                            { withPermission(<Icon type="star" theme={favorites[index] ? 'filled' : 'outlined'} title="点击收藏" style={{ margin: '0 10px', cursor: 'pointer' }} onClick={this.addFavorite.bind(this, parseItem, index)}/>, 'PermissionFavoritAdd') }
                                            <Link to={{ pathname: this.props.paths.TraceInfoList.linkPath, search: `?appName=${parseItem.appName}&serviceName=${parseItem.name}&methodName=${parseItem.method}` }} target="_blank">
                                                [查看调用链]
                                            </Link>
                                            <a href="javascript:;;" onClick={this.getDependentService.bind(this, parseItem)} style={{ marginLeft: '10px' }}>[下钻]</a>
                                        </h4>;
                                        const dataSource = fromJS(dataSources[item]);
                                        const xAxis = fromJS(xAxisObj[item]);
                                        const series = fromJS(seriesObj[item]);
                                        return (
                                            <Col span={layout} key={item}>
                                                <TofuTable dataSource={dataSource} columns={columns} title={title} xAxis={xAxis} series={series}/>
                                            </Col>
                                        );
                                    })
                                }
                            </Row>
                        </div>
                }
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(withRef(DependentService));
