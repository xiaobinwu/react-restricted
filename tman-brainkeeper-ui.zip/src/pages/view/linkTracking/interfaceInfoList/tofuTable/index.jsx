import React, { Component } from 'react';
import { is } from 'immutable';
import { Table } from 'antd';
import Line from '../charts/line';
import styles from './index.css';

class TofuTable extends Component {
    // 数据源相同，阻止render
    shouldComponentUpdate(nextProps = {}) {
        const thisProps = this.props || {};
        for (const key in nextProps) {
            if (!is(thisProps[key], nextProps[key])) {
                return true;
            }
        }
        return false;
    }
    render() {
        const {
            dataSource,
            columns,
            title,
            xAxis,
            series
        } = this.props;
        const newColumns = [...columns];
        newColumns.unshift({
            title: '',
            key: 'line',
            width: 200,
            className: 'system-bgGrey',
            render: (text, record, index) => {
                const obj = {
                    children: index === 0 ? <Line xAxis={xAxis.toJS()} series={series.toJS()} /> : null,
                    props: {
                        rowSpan: 5,
                    }
                };
                if (index > 0) {
                    obj.props.rowSpan = 0;
                }
                return obj;
            }
        });
        return (
            <div style={{ minHeight: '300px' }}>
                {title}
                <Table dataSource={dataSource.toJS()} size="small" columns={newColumns} pagination={false} className={styles.table}/>
            </div>
        );
    }
}

export default TofuTable;
