import React, { Component } from 'react';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { Table, Tooltip, Progress, Tag, message } from 'antd';
import fire from 'img/fire.svg';
import styles from './traceInquire.css';

const waterfallWidth = 200;
class TraceInquire extends Component {
    constructor(props) {
        super(props);
        this.columns = [{
            title: '应用名',
            dataIndex: 'appName',
            key: 'appName',
            render: this.handleAnnotations
        }, {
            title: '服务名',
            dataIndex: 'serviceName',
            key: 'serviceName',
            width: 180,
            render: (value, row) => {
                return (<div title={value} className={row.annotations ? `system-annotations-text ${styles.serviceName}` : `${styles.serviceName}`}>
                    {this.handleAnnotations(value, row)}
                </div>);
            }
        }, {
            title: '方法名',
            dataIndex: 'methodName',
            key: 'methodName',
            width: 150,
            render: (value, row) => (
                <div title={value} className={row.annotations ? `system-annotations-text ${styles.methodName}` : `${styles.methodName}`}>
                    {this.handleAnnotations(value, row)}
                </div>
            )
        }, {
            title: '参数',
            dataIndex: 'value',
            key: 'value',
            width: 150,
            className: styles.paramColumn,
            render: (value, row) => {
                const annotationsClassName = row.annotations && row.annotations[0].value ? `${styles.annotations} system-annotations-text` : styles.annotations;
                return (<div>
                    <div className={annotationsClassName}>
                        { row.annotations && row.annotations[0].value ?
                            <Tooltip title={<div>类型：{row.annotations[0].type}<br/>异常：{row.annotations[0].value}</div>}>
                                <img src={fire} style={{ width: '15px', height: 'auto' }} />
                            </Tooltip>
                            : null
                        }
                        {
                            value ?
                                <div title={value} className={styles.value}>
                                    <CopyToClipboard text={value} onCopy={() => { message.success('参数信息复制成功！'); }}>
                                        {this.handleAnnotations(value, row, null, true)}
                                    </CopyToClipboard>
                                </div>
                                : null
                        }
                    </div>
                </div>);
            }
        }, {
            title: '地址',
            dataIndex: 'ip',
            key: 'ip',
            width: 180,
            render: this.handleAnnotations
        }, {
            title: '类型',
            dataIndex: 'type',
            key: 'type',
            width: 100,
            render: this.handleAnnotations
        }, {
            title: '时间轴',
            dataIndex: '',
            key: 'waterfall',
            width: waterfallWidth,
            render: (value, row) => {
                let percent = 0;
                let marginLeft = 0;
                if (row.duration === this.props.maxDuration) {
                    percent = row.duration === 0 ? 1 : 100;
                    marginLeft = 0;
                } else {
                    marginLeft = ((row.timestamps - this.props.timestamps - (row.gap || 0)) / this.props.maxDuration) * waterfallWidth;
                    const calculatePercent = (row.duration / this.props.maxDuration) * 100;
                    percent = Math.floor(row.duration === 0 ? 1 : (calculatePercent < 1 ? 1 : calculatePercent));
                }
                const gapPercent = row.gap ? (percent + ((row.gap / this.props.maxDuration) * 100)) : 0;
                // 改变异常时的颜色，color.less
                let annotationsClassName = row.annotations ? 'system-annotations-tag' : 'system-default-trace-tag';
                const progressClassName = row.annotations ? 'system-annotations-progress' : '';
                annotationsClassName = `${annotationsClassName} ant-tag-has-color`;
                const waterfallClass = `${styles.waterfall} system-waterfall`;
                return (
                    <Tooltip placement="left" overlayClassName={styles.toolTip} title={() => (
                        <div className={styles.toolTipContent}>
                            <div><span><Tag className={annotationsClassName}>开始时间</Tag></span><span>{row.startTime}</span></div>
                            <div><span><Tag className={annotationsClassName}>结束时间</Tag></span><span>{row.endTime}</span></div>
                            <div><span><Tag className={annotationsClassName}>调用时长</Tag></span><span>{row.duration}ms</span></div>
                            <div><span><Tag className={annotationsClassName}>调用间隙</Tag></span><span>{row.gap}ms</span></div>
                        </div>
                    )}>
                        <div className={waterfallClass} style={{ width: waterfallWidth }}>
                            {
                                row.gap ?
                                    <Progress className={progressClassName} successPercent={gapPercent - percent} percent={gapPercent} style={{ marginLeft }} showInfo={false} />
                                    : <Progress className={progressClassName} percent={percent} style={{ marginLeft }} showInfo={false} />
                            }
                        </div>
                    </Tooltip>
                );
            }
        }, {
            title: '耗时(ms)',
            dataIndex: 'duration',
            key: 'duration',
            width: 90,
            render: this.handleAnnotations
        }
        ];
    }
    // 处理异常
    handleAnnotations = (value, row, dataIndex, slash = false) => (row.annotations ?
        <span className="system-annotations-text">
            {slash ? value.replace('\\/', '/') : value}
        </span>
        : <span>{slash ? value.replace('\\/', '/') : value}</span>)
    // 获取表格title
    getTitle = () => {
        const {
            traceId,
            startTime,
            totalDuration,
            step,
            annotationNum
        } = this.props;
        const title = traceId ?
            <div className={styles.title}>
                <span>TraceId:  { traceId }</span>
                <span>开始时间:  { startTime }</span>
                <span>总耗时:  { totalDuration }ms</span>
                <span>步长: { step }</span>
                <span>埋点数: { annotationNum }</span>
            </div>
            : null;
        return title;
    }

    render() {
        const { entry, loading, expendKeys } = this.props;
        const { columns } = this;
        return (
            <div className={styles.inquireTable}>
                {/* table-${entry.length > 0 && entry[0].key => 使table始终默认展开 */}
                <Table
                    key={`table-${entry.length > 0 && entry[0].key}`}
                    columns={columns}
                    childrenColumnName="childs"
                    indentSize={10}
                    defaultExpandedRowKeys={expendKeys}
                    dataSource={entry}
                    pagination={false}
                    title={this.getTitle}
                    loading={loading}
                />
            </div>
        );
    }
}

export default TraceInquire;
