import React, { Component } from 'react';
import { Input, Button, Tabs, Form, Row, Col } from 'antd';
import { linkTrackingService } from 'service';
import { fromJS } from 'immutable';
import { getQueryString } from 'js/util';
import TraceInquire from './traceInquire';
import TraceLog from './traceLog';

const { TabPane } = Tabs;
const FormItem = Form.Item;

class TraceInfo extends Component {
    state = {
        entry: [],
        logEntry: fromJS([]),
        timestamps: '',
        totalDuration: '',
        maxDuration: '',
        startTime: '',
        traceId: '',
        expendKeys: [],
        step: '',
        annotationNum: '',
        loading: false,
        logLoading: false,
    }
    // 查询
    inquire = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
                this.getTraceData(values.traceId.replace(/(^\s*)|(\s*$)/g, ''));
                this.getTraceLog(values.traceId.replace(/(^\s*)|(\s*$)/g, ''));
            }
        });
    }
    // 获取Trace数据
    getTraceData = async (traceId) => {
        this.setState({
            loading: true
        });
        const { entry, code } = await linkTrackingService.getOneTrace({ traceId });
        if (code === '0' && entry.length > 0) {
            const expendKeys = [];
            const walkExpendKey = (data, level) => {
                if (level > 1) {
                    return;
                }
                level++; // eslint-disable-line
                data && data.forEach((item, index) => {
                    expendKeys.push(item.key);
                    walkExpendKey(item.childs, level);
                });
            };
            walkExpendKey(entry, 0);
            const latestTime = (new Date(entry[0].latestTime)).valueOf();
            const earliestTime = (new Date(entry[0].earliestTime)).valueOf();
            const maxDuration = latestTime - earliestTime;
            this.setState({
                entry,
                expendKeys,
                maxDuration,
                timestamps: earliestTime,
                totalDuration: entry[0].duration,
                traceId: entry[0].traceId,
                startTime: entry[0].startTime,
                step: entry[0].step,
                annotationNum: entry[0].annotationNum
            });
        }
        this.setState({
            loading: false
        });
    }
    // 获取Trace日志
    getTraceLog = async (traceId) => {
        this.setState({
            logLoading: true
        });
        const { entry, code } = await linkTrackingService.getOneTraceLog({ traceId });
        if (code === '0' && entry.length > 0) {
            entry.forEach((item, index) => {
                item.key = index;
            });
            this.setState({
                logEntry: fromJS(entry)
            });
        }
        this.setState({
            logLoading: false
        });
    }
    componentDidMount() {
        const { traceId } = getQueryString();
        traceId && this.getTraceData(traceId);
        traceId && this.getTraceLog(traceId);
        traceId && this.props.form.setFieldsValue({ traceId });
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        return (
            <div>
                <Form onSubmit={this.inquire}>
                    <Row gutter={16}>
                        <Col span={4}>
                            <FormItem>
                                {getFieldDecorator('traceId', {
                                    initialValue: '',
                                    rules: [{ required: true, message: '请输入traceId!' }],
                                })(<Input placeholder="输入traceId"/>)}
                            </FormItem>
                        </Col>
                        <Col span={2}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit">查询</Button>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Tabs defaultActiveKey="1">
                    <TabPane tab="链路信息" key="1">
                        <TraceInquire {...this.state}/>
                    </TabPane>
                    <TabPane tab="链路日志" key="2">
                        <TraceLog entry={this.state.logEntry} loading={this.state.logLoading}/>
                    </TabPane>
                </Tabs>
            </div>
        );
    }
}

export default Form.create()(TraceInfo);
