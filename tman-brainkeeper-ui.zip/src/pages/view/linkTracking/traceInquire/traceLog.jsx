import React, { Component } from 'react';
import moment from 'moment';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { Button, Table, message } from 'antd';
import styles from './traceLog.css';

class TraceLog extends Component {
    constructor(props) {
        super(props);
        this.columns = [{
            title: '时间',
            dataIndex: 'timestamp',
            width: '200px',
            key: 'timestamp',
            defaultSortOrder: 'descend',
            sorter: (a, b) => {
                return moment(a.timestamp).valueOf() - moment(b.timestamp).valueOf();
            },
        }, {
            title: '内容',
            dataIndex: 'message',
            key: 'message',
            render: (value, row) => (
                <div title={value} className={styles.message}>
                    {value}
                </div>
            )
        }];
    }

    render() {
        const {
            entry,
            loading
        } = this.props;
        const { columns } = this;
        const immutableEntry = entry.toJS();
        const entryString = JSON.stringify(immutableEntry);
        return (
            <div>
                <CopyToClipboard text={entryString} onCopy={() => { message.success('日志复制成功！'); }}>
                    <Button type="primary" style={{ marginBottom: '20px' }}>一键复制日志</Button>
                </CopyToClipboard>
                <Table
                    loading={loading}
                    columns={columns}
                    dataSource={immutableEntry}
                    pagination={false}
                />
            </div>
        );
    }
}

export default TraceLog;
