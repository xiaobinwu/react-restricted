import React, { Component } from 'react';
import { Form, Select, Input } from 'antd';
import { linkTrackingService } from 'service';

const FormItem = Form.Item;
const { Option } = Select;
const { TextArea } = Input;

class PointForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            rmsEndPoints: [],
            rmsCodes: [],
            systemTypes: {},
        };
    }
    componentDidMount() {
        this.getSystemTypes();
        this.getRmsEndPoint();
    }
    // 查询系统类型
    getSystemTypes = async () => {
        const { entry, code } = await linkTrackingService.getSystemTypes();
        if (code === '0') {
            this.setState({
                systemTypes: entry
            });
        }
    }
    // 查询rms监控点
    getRmsEndPoint = async (e) => {
        const { entry, code } = await linkTrackingService.getRmsEndPoint();
        if (code === '0') {
            this.setState({
                rmsEndPoints: entry
            });
        }
    }
    // 查询rms错误码
    getRmsCode = async (pointCode) => {
        const { entry, code } = await linkTrackingService.getRmsCode({ pointCode });
        if (code === '0') {
            this.setState({
                rmsCodes: entry
            }, () => {
                const { form } = this.props;
                form.setFieldsValue({
                    rmsCode: entry.length > 0 ? entry[0].errorCode : '',
                    level: entry.length > 0 ? entry[0].level : ''
                });
            });
        }
    }
    changRmsEndPoint= (value) => {
        this.getRmsCode(value);
    }
    changRmsCode = (value, option) => {
        if (option.props.level !== '') {
            const { form } = this.props;
            form.setFieldsValue({ level: option.props.level });
        }
    }
    render() {
        const {
            rmsCodes,
            rmsEndPoints,
            systemTypes
        } = this.state;
        const {
            form,
            injectForm,
            groupList,
            endpointTypeList
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 5 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 19 },
            }
        };
        getFieldDecorator('status', { initialValue: injectForm.status });
        getFieldDecorator('level', { initialValue: injectForm.level });
        return (
            <Form>
                <FormItem label="组名" {...formItemLayout}>
                    {getFieldDecorator('groupId', {
                        initialValue: injectForm.groupId,
                        rules: [{
                            required: true, message: '请选择组名',
                        }],
                    })(<Select
                        placeholder="请选择组名"
                        showSearch
                        optionFilterProp='children'
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        {
                            groupList.map((item, index) => {
                                return <Option key={item.id}>{item.name}</Option>;
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true, message: '请填写名称',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="编码" {...formItemLayout}>
                    {getFieldDecorator('code', {
                        initialValue: injectForm.code,
                        rules: [{
                            required: true, message: '请填写编码',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="系统类型" {...formItemLayout}>
                    {getFieldDecorator('systemType', {
                        initialValue: injectForm.systemType,
                        rules: [{
                            required: true, message: '请选择系统类型',
                        }],
                    })(<Select placeholder="请选择系统类型">
                        {
                            Object.keys(systemTypes).map((item, index) => {
                                return <Option key={item}>{systemTypes[item]}</Option>;
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="rms监控点" {...formItemLayout}>
                    {getFieldDecorator('rmsEndpoint', {
                        initialValue: injectForm.rmsEndpoint,
                        rules: [{
                            required: true, message: '请选择rms监控点',
                        }],
                    })(<Select
                        onChange={this.changRmsEndPoint}
                        placeholder="请选择rms监控点"
                        showSearch
                        optionFilterProp='children'
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        {
                            rmsEndPoints.map((item, index) => {
                                return <Option key={item.pointCode}>{item.name}</Option>;
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="rms监控码" {...formItemLayout}>
                    {getFieldDecorator('rmsCode', {
                        initialValue: injectForm.rmsCode,
                        rules: [{
                            required: true, message: '请选择rms监控码',
                        }],
                    })(<Select
                        onChange={this.changRmsCode}
                        placeholder="请选择rms监控码"
                        showSearch
                        optionFilterProp='children'
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        {
                            rmsCodes.map((item, index) => {
                                return <Option key={item.errorCode} level={item.level} title={`${item.errorCode}-${item.errorDescr}`}>{item.errorCode}-{item.errorDescr}</Option>;
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="类型" {...formItemLayout}>
                    {getFieldDecorator('endpointType', {
                        initialValue: injectForm.endpointType,
                        rules: [{
                            required: true, message: '请选择组名',
                        }],
                    })(<Select
                        placeholder="请选择类型"
                        showSearch
                        optionFilterProp='children'
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        {
                            endpointTypeList.map((item, index) => {
                                return <Option key={item.value}>{item.text}</Option>;
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="描述" {...formItemLayout}>
                    {getFieldDecorator('description', {
                        initialValue: injectForm.description,
                    })(<TextArea row={4}/>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(PointForm);
