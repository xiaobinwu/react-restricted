import React, { Component } from 'react';
import { Button, Select, Table, message, Modal } from 'antd';
import { linkTrackingService, systemManagementService } from 'service';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import PointForm from './pointForm';

const { confirm } = Modal;
const { Option } = Select;
const PointFormModal = withFormModal(PointForm);
const defaultPointFormOptions = {
    id: '',
    name: '',
    description: '',
    groupId: '',
    endpointType: '',
    rmsCode: '',
    level: '',
    rmsEndpoint: '',
    code: '',
    isEdit: false,
    status: 1
};

class MonitorPoint extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            currentGroupId: '',
            groupList: [],
            endpointTypeList: [],
            pointForm: deepCopy(defaultPointFormOptions),
            pointVisible: false,
            pointConfirmLoading: false
        };
        this.columns = [{
            title: '组名',
            dataIndex: 'groupId',
            key: 'groupId',
            render: (text, record) => {
                const { groupList } = this.state;
                const item = groupList.find((it, index) => {
                    return it.id === text;
                });
                return item ? item.name : text;
            }
        }, {
            title: '名称',
            dataIndex: 'name',
            key: 'name',
            width: 250
        }, {
            title: '类型',
            dataIndex: 'endpointType',
            key: 'endpointType',
            render: (text, record) => {
                const { endpointTypeList } = this.state;
                if (endpointTypeList.length > 0) {
                    const item = endpointTypeList.find((it, index) => { return it.value === text; });
                    return item ? item.text : '';
                }
                return '';
            }
        }, {
            title: 'rms监控点',
            dataIndex: 'rmsEndpoint',
            key: 'rmsEndpoint'
        }, {
            title: 'rms错误码',
            dataIndex: 'rmsCode',
            key: 'rmsCode'
        }, {
            title: '系统类型名称',
            dataIndex: 'systemTypeName',
            key: 'systemTypeName'
        }, {
            title: '编码',
            dataIndex: 'code',
            key: 'code'
        }, {
            title: '级别',
            dataIndex: 'level',
            key: 'level'
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description',
            width: 250
        }, {
            title: '操作',
            key: 'action',
            render: (text, record) => {
                return (
                    <React.Fragment>
                        {
                            withPermission(<Button type="primary" style={{ marginRight: 10 }} onClick={this.setPoint.bind(this, record)}>修改</Button>, 'PermissionMonitorPointEdit')
                        }
                        {
                            withPermission(<Button type="primary" onClick={this.deletePoint.bind(this, record)}>删除</Button>, 'PermissionMonitorPointDelete')
                        }
                    </React.Fragment>
                );
            }
        }];
    }
    componentDidMount() {
        this.getConfigList();
        this.getMonitorGroupList();
        this.getMonitorPointList();
    }
    // 获取配置类型列表
    getConfigList = async () => {
        const { code, entry } = await systemManagementService.getConfigList({ scope: 'endpoint_type' }, true);
        if (code === '0' && entry) {
            const endpointTypeList = [];
            entry.forEach((item, index) => {
                const text = JSON.parse(item.value).desc;
                endpointTypeList.push({
                    value: item.key,
                    text
                });
            });
            this.setState({
                endpointTypeList
            });
        }
    }
    // 添加、修改用户Modal
    setPoint = (record) => {
        let pointFormObj = {};
        if (record) {
            pointFormObj = {
                id: record.id,
                name: record.name,
                description: record.description,
                groupId: String(record.groupId),
                endpointType: record.endpointType,
                rmsCode: record.rmsCode,
                systemType: record.systemType,
                rmsEndpoint: record.rmsEndpoint,
                level: String(record.level),
                status: 1,
                code: record.code,
                isEdit: true
            };
        } else {
            pointFormObj = deepCopy(defaultPointFormOptions);
        }
        this.setState({
            pointForm: pointFormObj,
            pointVisible: true
        });
    }
    // 保存
    setPointSend = async () => {
        this.pointFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    pointConfirmLoading: true
                });
                let params = { ...this.pointFormRef.props.form.getFieldsValue() };
                if (this.state.pointForm.id) {
                    params = { ...params, ...{ id: this.state.pointForm.id } };
                }
                const res = await linkTrackingService.setPointSend(params);
                if (res.code === '0') {
                    this.setState({
                        pointConfirmLoading: false,
                        pointVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.pointFormRef.props.form.resetFields();
                        this.getMonitorPointList();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        pointConfirmLoading: false
                    });
                }
            }
        });
    }
    // 删除
    deletePoint = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该监控点？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await linkTrackingService.deleteMonitorPoint({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getMonitorPointList();
                    }
                })();
            }
        });
    }
    // 获取监控组
    getMonitorGroupList = async (e) => {
        const { entry, code } = await linkTrackingService.getMonitorGroupList();
        if (code === '0') {
            this.setState({
                groupList: entry
            });
        }
    }
    // 获取列表
    getMonitorPointList = async (e) => {
        e && e.preventDefault();
        const { pagination, currentGroupId } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination, groupId: currentGroupId, countSql: true };
        delete params.totalCount;
        const { entry, code } = await linkTrackingService.getMonitorPointList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getMonitorPointList();
            });
        }
    }
    // 改变监控组
    changeMonitorGroup = (currentGroupId) => {
        this.setState({
            currentGroupId
        });
    }
    getPointFormRef = (ref) => {
        this.pointFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.pointFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            data,
            pagination,
            loading,
            groupList,
            endpointTypeList,
            pointForm,
            pointVisible,
            pointConfirmLoading
        } = this.state;
        const {
            columns
        } = this;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <div style={{ marginBottom: 20 }}>
                    <Select
                        onChange={this.changeMonitorGroup}
                        style={{ width: 200, marginRight: 10 }}
                        placeholder="请选择监控组"
                        showSearch
                        optionFilterProp='children'
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        <Option value="">全部</Option>
                        {
                            groupList.map((item, index) => {
                                return <Option key={item.id}>{item.name}</Option>;
                            })
                        }
                    </Select>
                    <Button type="primary" icon="search" onClick={this.getMonitorPointList.bind(this)} style={{ marginRight: 20 }}>搜索</Button>
                    {
                        withPermission(<Button type="primary" onClick={this.setPoint.bind(this, null)}>新增</Button>, 'PermissionMonitorPointAdd')
                    }
                </div>
                <Table rowKey="id" loading={loading} dataSource={data} columns={columns} pagination={pageControl} onChange={this.handleTableChange}/>
                <PointFormModal
                    maskClosable={false}
                    injectForm={pointForm}
                    getRef={this.getPointFormRef}
                    title="监控点添加/修改"
                    visible={pointVisible}
                    onOk={this.setPointSend}
                    onCancel={this.handleCancel.bind(this, 'pointVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={pointConfirmLoading} onClick={this.setPointSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp={{
                        groupList,
                        endpointTypeList
                    }}
                />
            </div>
        );
    }
}

export default MonitorPoint;
