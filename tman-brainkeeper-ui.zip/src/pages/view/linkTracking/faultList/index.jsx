import React, { Component } from 'react';
import { Row, Col, Table, Select, Button, Modal, message } from 'antd';
import { linkTrackingService, systemManagementService } from 'service';
import { fromJS } from 'immutable';
import moment from 'moment';
import QueryForm from 'component/queryForm';
import { getQueryString } from 'js/util';
import withPermission from 'component/hoc/withPermission';

import status from './status';
import FaultModal from './faultModal';
import FaultDrawer from './faultDrawer';

const { Option } = Select;
const { confirm } = Modal;
class FaultList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            visible: false,
            currentRecord: null,
            viewRecord: null,
            viewVisible: false,
            applications: []
        };
        this.columns = [{
            title: '业务域',
            dataIndex: 'domain',
            key: 'domain',
            width: 150,
        }, {
            title: '标题',
            dataIndex: 'title',
            key: 'title',
            width: 150
        }, {
            title: '故障时间',
            dataIndex: 'beginTime',
            key: 'beginTime',
            width: 180
        }, {
            title: '恢复时间',
            dataIndex: 'endTime',
            key: 'endTime',
            width: 180
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            width: 80,
            render: (text, record) => {
                return text === 'PENDING' ? '未处理' : (text === 'PROCESSING' ? '处理中' : '已处理');
            }
        }, {
            title: '故障级别',
            dataIndex: 'level',
            key: 'level',
            width: 100
        }, {
            title: '责任人',
            dataIndex: 'charge',
            key: 'charge',
            width: 100,
        }, {
            title: '报告人',
            dataIndex: 'createUser',
            key: 'createUser',
            width: 80
        }, {
            title: '报告日期',
            dataIndex: 'createTime',
            key: 'createTime',
            width: 180
        }, {
            title: '持续时长',
            dataIndex: 'duration',
            key: 'duration',
            width: 100,
            render: (text, record) => {
                return text || '无法估算';
            }
        }, {
            title: '操作',
            key: 'action',
            render: (text, record) => {
                return (
                    <React.Fragment>
                        {
                            withPermission(<Button type="primary" size="small" style={{ marginRight: 10, marginBottom: 5 }} onClick={this.openDrawer.bind(this, record)}>查看</Button>, 'PermissionFaultListView')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={{ marginRight: 10, marginBottom: 5 }} onClick={this.openOperateModal.bind(this, record)}>编辑</Button>, 'PermissionFaultListEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style= {{ marginBottom: 5 }} onClick={this.deleteFault.bind(this, record)}>删除</Button>, 'PermissionFaultListDelete')
                        }
                    </React.Fragment>
                );
            }
        }];

        this.statusSelectComponent = (<Select>
            {
                status.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        this.levelSelectComponent = (<Select>
            {
                [<Option value="" key="all">全部</Option>].concat([0, 1, 2, 3, 4, 5, 6].map((item, index) => {
                    return (<Option key={item}>{item}</Option>);
                }))
            }
        </Select>);
    }
    componentDidMount() {
        this.getApplications();
        this.initDefaultData();
    }
    initDefaultData() {
        const result = getQueryString();
        if (result.startEventTime && result.endEventTime) {
            this.faultRef.props.form.setFieldsValue({ rangeTime: [moment(result.startEventTime), moment(result.endEventTime)] });
            this.getFaultList();
        } else {
            this.getFaultList();
        }
    }
    // 打开操作Modal
    openOperateModal = (record, e) => {
        let currentRecord;
        if (record) {
            currentRecord = fromJS(record);
        } else {
            currentRecord = null;
        }
        this.setState({
            visible: true,
            currentRecord
        });
    }
    // 查看
    openDrawer = (record) => {
        this.setState({
            viewVisible: true,
            viewRecord: fromJS(record)
        });
    }
    // modal关闭
    onFaultModalClose = () => {
        this.setState({
            visible: false
        });
    }
    // 保存成功
    onFaultModalSuccess = () => {
        this.getFaultList();
    }
    // 获取列表
    getFaultList = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination, ...this.faultRef.props.form.getFieldsValue(), ...{ countSql: true } };
        if (params.rangeTime && params.rangeTime.length > 0) {
            const { rangeTime } = params;
            params.beginTimeBegin = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
            params.beginTimeEnd = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
        }
        delete params.rangeTime;
        delete params.totalCount;
        const { entry, code } = await linkTrackingService.getFaultList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 删除
    deleteFault = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await linkTrackingService.deleteFault({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getFaultList();
                    }
                })();
            }
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getServiceList();
            });
        }
    }
    // 抽屉回调
    onDrawerClose = () => {
        this.setState({
            viewVisible: false
        });
    }
    // 获取业务域
    getApplications = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'business_domain' }, true);
        if (code === '0') {
            this.setState({
                applications: entry
            });
        }
    }
    render() {
        const {
            data,
            pagination,
            loading,
            visible,
            currentRecord,
            viewVisible,
            viewRecord,
            applications
        } = this.state;
        const {
            columns
        } = this;
        const domainSelectComponent = <Select>
            <Option value="">全部</Option>
            {
                applications && applications.map((item, index) => {
                    return (<Option key={item.key}>{item.key}</Option>);
                })
            }
        </Select>;
        const baseFormItemsSetting = {
            rangeTime: {
                span: 5,
                options: {
                    initialValue: []
                },
                extraProps: {
                    format: 'YYYY-MM-DD'
                }
            },
            button: {
                span: 9
            }
        };
        const extraFormItem = [
            {
                span: 3,
                id: 'status',
                options: {
                    initialValue: ''
                },
                component: this.statusSelectComponent
            },
            {
                span: 3,
                id: 'level',
                options: {
                    initialValue: ''
                },
                component: this.levelSelectComponent
            }
        ];
        const preFormItem = [
            {
                span: 3,
                id: 'domain',
                options: {
                    initialValue: ''
                },
                component: domainSelectComponent
            },
        ];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <Row>
                    <Col span={22}>
                        <QueryForm wrappedComponentRef={(ref) => { this.faultRef = ref; }} preFormItem={preFormItem} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getFaultList} />
                    </Col>
                    {
                        withPermission(<Col span={2} style={{ textAlign: 'right' }}>
                            <Button type="primary" onClick={this.openOperateModal.bind(this, null)}>新增</Button>
                        </Col>, 'PermissionFaultListAdd')
                    }
                </Row>
                <FaultDrawer viewVisible={viewVisible} onClose={this.onDrawerClose} record={viewRecord}/>
                <FaultModal visible={visible} record={currentRecord} onFaultModalClose={this.onFaultModalClose} onFaultModalSuccess={this.onFaultModalSuccess}/>
                <Table rowKey="id" loading={loading} dataSource={data} columns={columns} pagination={pageControl} onChange={this.handleTableChange}/>
            </div>
        );
    }
}

export default FaultList;
