import React, { Component } from 'react';
import { Row, Col, Form, Input, DatePicker, Select, Button, Icon } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;
const { Option } = Select;
const { TextArea } = Input;
const FormItem = Form.Item;

let uuid = 1;
class FaultForm extends Component {
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    // 添加
    add = () => {
        const { form, injectForm } = this.props;
        const keys = form.getFieldValue('keys');
        if (injectForm.isEdit) {
            uuid = keys.length;
        }
        const nextKeys = keys.concat(uuid);
        uuid++; // eslint-disable-line
        form.setFieldsValue({
            keys: nextKeys
        });
    }
    // 删除
    remove = (k) => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        if (keys.length === 1) {
            return;
        }
        form.setFieldsValue({
            keys: keys.filter(key => key !== k)
        });
    }
    render() {
        const {
            form,
            injectForm,
            status,
            appList
        } = this.props;
        const { getFieldDecorator, getFieldValue } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        const timeLineFormItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 2 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 22 },
            }
        };
        getFieldDecorator('keys', { initialValue: injectForm.keys });
        const keys = getFieldValue('keys');
        const formItem = keys.map((k, index) => {
            return (
                <Col span={24} key={k}>
                    <FormItem label={index === 0 ? '时间线' : ' '} colon={index === 0} {...timeLineFormItemLayout}>
                        <Row gutter={20}>
                            <Col span={5}>
                                <FormItem {...formItemLayout}>
                                    {getFieldDecorator(`dates[${k}]`, {
                                        ...(injectForm.dates[k] ? { initialValue: moment(injectForm.dates[k]) } : {})
                                    })(<DatePicker
                                        showTime
                                        format="YYYY-MM-DD HH:mm:ss"
                                        placeholder="选择时间"
                                    />)}
                                </FormItem>
                            </Col>
                            <Col span={16}>
                                <FormItem {...formItemLayout} style={{ width: '100%' }}>
                                    {getFieldDecorator(`messages[${k}]`, {
                                        initialValue: injectForm.messages[k]
                                    })(<Input style={{ width: '100%' }} placeholder="描述当时发生的事件"/>)}
                                </FormItem>
                            </Col>
                            <Col span={3} style={{ textAlign: 'right' }}>
                                {/* onClick={() => this.add()} 必须这样写，不然会报错, 存在立即执行的方法，循环触发更新 https://github.com/ckinmind/ReactCollect/issues/99 */}
                                {
                                    (keys.indexOf(k) === keys.length - 1) ? <Button type="primary" style={{ marginRight: '5px' }} onClick={() => this.add()}><Icon type="plus" /></Button> : null
                                }
                                {
                                    keys.length > 1 ? <Button type="primary" onClick={() => this.remove(k)}><Icon type="minus" /></Button> : null
                                }
                            </Col>
                        </Row>
                    </FormItem>
                </Col>
            );
        });
        return (
            <Form>
                <Row>
                    <Col span={12}>
                        <FormItem label="标题" {...formItemLayout}>
                            {getFieldDecorator('title', {
                                initialValue: injectForm.title,
                                rules: [{
                                    required: true, message: '标题不为空',
                                }, {
                                    max: 50, message: '标题不能超过50个字符',
                                }],
                            })(<Input />)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="业务域" {...formItemLayout}>
                            {getFieldDecorator('domain', {
                                initialValue: injectForm.domain,
                            })(<Select showSearch optionFilterProp="children" filterOption={this.filterOption}>
                                {
                                    appList && appList.map((item, index) => {
                                        return (<Option key={item.key}>{item.key}</Option>);
                                    })
                                }
                            </Select>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="故障时间" {...formItemLayout}>
                            {getFieldDecorator('rangeTime', {
                                initialValue: injectForm.rangeTime,
                                rules: [{
                                    type: 'array', required: true, message: '故障时间不为空',
                                }],
                            })(<RangePicker style={{ width: '100%' }} showTime format="YYYY-MM-DD HH:mm:ss" placeholder={['开始时间', '结束时间']}/>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="状态" {...formItemLayout}>
                            {getFieldDecorator('status', {
                                initialValue: injectForm.status,
                                rules: [{
                                    required: true, message: '状态不为空',
                                }],
                            })(<Select>
                                {
                                    status.map((item, index) => {
                                        return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                                    }).slice(1)
                                }
                            </Select>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="故障级别" {...formItemLayout}>
                            {getFieldDecorator('level', {
                                initialValue: injectForm.level,
                                rules: [{
                                    required: true, message: '故障级别不为空',
                                }],
                            })(<Select>
                                {
                                    [0, 1, 2, 3, 4, 5, 6].map((item, index) => {
                                        return (<Option value={item} key={item}>{item}</Option>);
                                    })
                                }
                            </Select>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="故障责任人" {...formItemLayout}>
                            {getFieldDecorator('charge', {
                                initialValue: injectForm.charge,
                                rules: [{
                                    max: 50, message: '故障责任人不能超过50个字符',
                                }],
                            })(<Input />)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="故障原因" {...formItemLayout}>
                            {getFieldDecorator('reason', {
                                initialValue: injectForm.reason,
                                rules: [{
                                    max: 50, message: '故障原因不能超过50个字符',
                                }],
                            })(<TextArea rows={3}/>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="故障描述" {...formItemLayout}>
                            {getFieldDecorator('description', {
                                initialValue: injectForm.description,
                                rules: [{
                                    max: 1000, message: '故障描述不能超过1000个字符',
                                }],
                            })(<TextArea rows={3}/>)}
                        </FormItem>
                    </Col>
                    {formItem}
                </Row>
            </Form>
        );
    }
}

export default Form.create()(FaultForm);
