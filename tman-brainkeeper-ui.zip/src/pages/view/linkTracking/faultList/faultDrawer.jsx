import React, { Component } from 'react';
import { Row, Col, Drawer, Timeline, Icon } from 'antd';
import styles from './faultDrawer.css';

const TimelineItem = Timeline.Item;

class FaultDrawer extends Component {
    onClose = () => {
        const { onClose } = this.props;
        onClose && onClose();
    }
    render() {
        const { viewVisible, record } = this.props;
        const drawerRecord = record && record.toJS();
        const colLayout = { marginBottom: '30px' };
        return (
            <Drawer
                width="100%"
                height="100%"
                placement="top"
                closable={true}
                maskClosable={false}
                title={drawerRecord ? drawerRecord.title : '故障详情'}
                onClose={this.onClose}
                visible={viewVisible}
            >
                {
                    drawerRecord ? (<Row>
                        <Col span={12}>
                            <Row>
                                <Col span={12} style={colLayout}>
                                    <span>故障责任人：</span>
                                    <span>{drawerRecord.charge}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>业务域：</span>
                                    <span>{drawerRecord.domain}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>标题：</span>
                                    <span>{drawerRecord.title}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>故障时间：</span>
                                    <span>{drawerRecord.beginTime}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>恢复时间：</span>
                                    <span>{drawerRecord.endTime}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>故障状态：</span>
                                    <span>{drawerRecord.status === 'PENDING' ? '未处理' : (drawerRecord.status === 'PROCESSING' ? '处理中' : '已处理')}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>故障级别：</span>
                                    <span>{drawerRecord.level}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>恢复时间：</span>
                                    <span>{drawerRecord.endTime}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>报告日期：</span>
                                    <span>{drawerRecord.createTime}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>报告人：</span>
                                    <span>{drawerRecord.createUser}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>上一次修改时间：</span>
                                    <span>{drawerRecord.modifyTime}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>修改人：</span>
                                    <span>{drawerRecord.modifyUser}</span>
                                </Col>
                                <Col span={12} style={colLayout}>
                                    <span>故障原因：</span>
                                    <span>{drawerRecord.reason}</span>
                                </Col>
                                <Col span={24} style={colLayout}>
                                    <span>故障描述：</span>
                                    <span dangerouslySetInnerHTML={{ __html: drawerRecord.description }} />
                                </Col>
                            </Row>
                        </Col>
                        <Col span={12}>
                            {
                                drawerRecord.timeline ? <Timeline className={styles.timeline}>
                                    {
                                        JSON.parse(drawerRecord.timeline).map((item, index) => {
                                            return (
                                                <TimelineItem key={index} dot={<Icon type="clock-circle" theme="twoTone" style={{ fontSize: '16px' }} />}>
                                                    <span className="timelineDate">{item.date}</span>
                                                    <span className="timelineContent">{item.message}</span>
                                                </TimelineItem>
                                            );
                                        })
                                    }
                                </Timeline> : null
                            }
                        </Col>
                    </Row>) : null
                }
            </Drawer>
        );
    }
}

export default FaultDrawer;
