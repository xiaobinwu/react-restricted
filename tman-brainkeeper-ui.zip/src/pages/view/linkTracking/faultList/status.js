const status = [
    {
        text: '全部',
        value: ''
    },
    {
        text: '未处理',
        value: 'PENDING'
    },
    {
        text: '处理中',
        value: 'PROCESSING'
    },
    {
        text: '已处理',
        value: 'DONE'
    }
];

export default status;
