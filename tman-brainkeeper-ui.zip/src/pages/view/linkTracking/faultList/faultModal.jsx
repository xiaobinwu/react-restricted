import React, { Component } from 'react';
import { Button, message } from 'antd';
import PropTypes from 'prop-types';
import { linkTrackingService, systemManagementService } from 'service';
import withFormModal from 'component/hoc/withFormModal';
import { fromJS, is } from 'immutable';
import moment from 'moment';

import FaultForm from './faultForm';
import status from './status';

const FaultFormModal = withFormModal(FaultForm);

const defaultFormOptions = fromJS({
    id: '',
    title: '',
    rangeTime: [],
    domain: '',
    status: '',
    level: '',
    charge: '',
    reason: '',
    description: '',
    dates: [null],
    messages: [''],
    keys: [0],
    isEdit: false
});

class FaultModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            confirmLoading: false,
            visible: false,
            faultForm: defaultFormOptions,
            appList: []
        };
    }
    UNSAFE_componentWillReceiveProps(nextProps) { //eslint-disable-line
        const { record, isFetch, visible } = nextProps;
        if (this.state.appList.length === 0 && visible) {
            this.getAllApplications();
        }
        // 添加
        if (!record) {
            this.setState({
                faultForm: defaultFormOptions
            });
        }
        // 需要请求API获取详情
        if (record && isFetch) {
            (async () => {
                const res = await linkTrackingService.getFaultDetail({ id: record.id });
                if (res.code === '0') {
                    // empty
                }
            })();
        }
        // 不需要获取详情
        if (record && !isFetch) {
            if (!is(record, this.props.record)) {
                this.setState({
                    faultForm: this.handleRecord(record)
                });
            }
        }
        if (visible !== this.props.visible) {
            this.setState({
                visible
            });
        }
    }
    // 获取应用列表（cache）
    getAllApplications = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'business_domain' }, true);
        if (code === '0') {
            this.setState({
                appList: entry
            });
        }
    }
    // 处理record
    handleRecord = (record) => {
        const jsRecord = record.toJS();
        const { beginTime, endTime, timeline } = jsRecord;
        if (beginTime && endTime) {
            jsRecord.rangeTime = [moment(beginTime), moment(endTime)];
        }
        if (timeline) {
            const timelines = JSON.parse(timeline);
            if (timelines.length > 0) {
                const dates = [];
                const messages = [];
                timelines.forEach((item, index) => {
                    dates.push(item.date);
                    messages.push(item.message);
                });
                jsRecord.isEdit = true;
                jsRecord.keys = Array.from(new Array(timelines.length), (val, index) => index);
                jsRecord.messages = messages;
                jsRecord.dates = dates;
            }
        }
        return defaultFormOptions.mergeDeep(fromJS(jsRecord));
    }
    // 获取ref
    getFaultFormRef = (ref) => {
        this.faultFormRef = ref;
    }
    // 关闭Modal
    handleCancel = () => {
        this.faultFormRef && this.faultFormRef.props.form.resetFields();
        this.setState({
            visible: false
        }, () => {
            const { onFaultModalClose } = this.props;
            onFaultModalClose && onFaultModalClose();
        });
    }
    // 发送请求
    setFaultSend = async () => {
        this.faultFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    confirmLoading: true
                });
                const { faultForm } = this.state;
                const params = { ...this.faultFormRef.props.form.getFieldsValue(), id: faultForm.toJS().id };
                const timeline = [];
                const { dates, messages } = params;
                if (dates && dates.length > 0) {
                    dates.forEach((item, index) => {
                        if (item && messages[index]) {
                            timeline.push({
                                date: item.format('YYYY-MM-DD HH:mm:ss'),
                                message: messages[index]
                            });
                        }
                    });
                    if (timeline.length > 0) {
                        params.timeline = JSON.stringify(timeline);
                    }
                }
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.beginTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                delete params.keys;
                delete params.rangeTime;
                delete params.dates;
                delete params.messages;
                const res = await linkTrackingService.setFaultSend(params);
                if (res.code === '0') {
                    this.faultFormRef.props.form.resetFields();
                    this.setState({
                        confirmLoading: false,
                        visible: false
                    }, () => {
                        message.success('保存成功');
                        const {
                            onFaultModalClose,
                            onFaultModalSuccess
                        } = this.props;
                        onFaultModalClose && onFaultModalClose();
                        onFaultModalSuccess && onFaultModalSuccess(params);
                    });
                } else {
                    this.setState({
                        confirmLoading: false
                    });
                }
            }
        });
    }
    render() {
        const {
            visible,
            confirmLoading,
            faultForm,
            appList
        } = this.state;
        return (
            <FaultFormModal
                width={1100}
                maskClosable={false}
                injectForm={faultForm.toJS()}
                getRef={this.getFaultFormRef}
                title="故障信息录入/编辑"
                visible={visible}
                onOk={this.setFaultSend}
                onCancel={this.handleCancel}
                footer={[
                    <Button key="submit" type="primary" loading={confirmLoading} onClick={this.setFaultSend}>
                        确定
                    </Button>
                ]}
                wrappedProp= {{
                    status,
                    appList
                }}
            />
        );
    }
}

FaultModal.propTypes = {
    visible: PropTypes.bool.isRequired,
    isFetch: PropTypes.bool.isRequired,
    onFaultModalClose: PropTypes.func,
    onFaultModalSuccess: PropTypes.func,
    record: PropTypes.object
};

FaultModal.defaultProps = {
    visible: false,
    isFetch: false,
    onFaultModalClose: () => {},
    onFaultModalSuccess: () => {}
};


export default FaultModal;
