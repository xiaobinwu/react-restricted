import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Report extends Component {
    render() {
        const {
            categories,
            nodes,
            links,
            position,
            labelPosition
        } = this.props;
        const option = {
            tooltip: {},
            legend: [{
                data: categories.map((a) => {
                    return a.name;
                })
            }],
            animation: false,
            series: [
                {
                    name: '应用关系图',
                    type: 'graph',
                    draggable: true,
                    hoverAnimation: true,
                    animation: true,
                    layout: 'circular',
                    data: nodes,
                    links,
                    categories,
                    ...position,
                    focusNodeAdjacency: true,
                    edgeSymbol: ['arrow'],
                    label: {
                        position: labelPosition,
                        formatter: '{b}'
                    },
                    tooltip: {
                        formatter: (params) => {
                            if (params.dataType === 'edge') {
                                return params.name;
                            }
                            return `${params.marker}类型：${params.data.type}<br/>${params.marker}业务域：${params.data.domain}<br/>${params.marker}关联数：${params.value}`;
                        }
                    },
                    itemStyle: {
                        normal: {
                            shadowBlur: 10,
                            shadowColor: 'rgba(255, 255, 255, 0.3)'
                        }
                    },
                    lineStyle: {
                        color: 'source',
                        curveness: 0.1
                    },
                    emphasis: {
                        lineStyle: {
                            width: 3
                        }
                    },
                    roam: true,
                    // force: {
                    //     initLayout: 'circular',
                    //     repulsion: 3000,
                    //     layoutAnimation: false,
                    //     gravity: 0.1
                    // }
                }
            ]
        };
        return (
            <div style={{ marginBottom: '30px' }}>
                <ReactEcharts
                    option={option}
                    style={{ height: 700, width: '100%' }}/>
            </div>
        );
    }
}
