import React, { Component } from 'react';
import { linkTrackingService } from 'service';
import { Spin } from 'antd';
import QueryForm from 'component/queryForm';
import { isNotEmptyObject } from 'js/util';
// import graph from 'js/graph';
import Graph from './charts/graph';

const position = {
    // x坐标集合（每列的x位置）
    x: {
        pos1: 200,
        pos2: 300,
        pos3: 400,
        pos4: 600
    },
    y: 300, // y坐标起始位置
    distance: 100, // 每个节点原始距离
    maxHeight: 400 // 每列的最高高度
};

class TopologyInfo extends Component {
    state = {
        categories: [],
        apps: [],
        rels: [],
        componentPosition: { right: 'auto' },
        labelPosition: 'right',
        loading: false
    }
    componentDidMount() {
        this.getTopology();
    }
    // 计算每一列node集合y的位置
    calculateY = (index, len) => {
        return position.y + ((position.maxHeight - ((len - 1) * position.distance)) / 2) + (index * position.distance);
    }
    // 提取奇数或偶数的下标数组项
    handleNodes = (nodes, key) => {
        if (nodes.length <= 5) {
            nodes.forEach((item, index) => {
                item.x = position.x[key];
                item.y = this.calculateY(index, nodes.length);
            });
            return [...nodes, ...[]];
        }
        const evenNodes = nodes.filter((item, index) => index % 2 === 0);
        const oddNodes = nodes.filter((item, index) => index % 2 !== 0);
        evenNodes.forEach((item, index) => {
            item.x = position.x[key];
            item.y = this.calculateY(index, evenNodes.length);
        });
        oddNodes.forEach((item, index) => {
            item.x = position.x[key] + position.distance;
            item.y = this.calculateY(index, oddNodes.length);
        });
        return [...evenNodes, ...oddNodes];
    }
    // 生成LR的关系图,将所有nodes划分为四列，将node进行归类
    initChartData = (apps) => {
        // 找出第一级的node
        const firstNodes = apps.filter((item, index) => {
            return item.beReliedAppNameList.length === 0 && item.reliedAppNameList.length > 0;
        });
        // 找出第二级的node
        const secondNodes = apps.filter((item, index) => {
            return firstNodes.some(fitem => fitem.reliedAppNameList.includes(item.name));
        });
        // 找出最后一级的node
        const lastNodes = apps.filter((item, index) => {
            return !firstNodes.some(fitem => fitem.reliedAppNameList.includes(item.name)) && item.beReliedAppNameList.length >= 0 && item.reliedAppNameList.length === 0;
        });
        // 找出其他的node
        const otherNodes = [];
        {
            const willRemoveNodes = [...firstNodes, ...secondNodes, ...lastNodes];
            apps.forEach((item, index) => {
                if (willRemoveNodes.findIndex(ritem => ritem.name === item.name) === -1) {
                    otherNodes.push(item);
                }
            });
        }
        const firstResultNodes = this.handleNodes(firstNodes, 'pos1');
        const secondResultNodes = this.handleNodes(secondNodes, 'pos2');
        const otherResultNodes = this.handleNodes(otherNodes, secondNodes.length === 0 ? 'pos2' : 'pos3');
        const lastResultNodes = this.handleNodes(lastNodes, otherNodes.length === 0 ? 'pos3' : 'pos4');
        // console.log(firstResultNodes, secondResultNodes, otherResultNodes, lastResultNodes);
        const nodes = [...firstResultNodes, ...secondResultNodes, ...otherResultNodes, ...lastResultNodes];
        if (nodes.length > 2) {
            this.setState({
                componentPosition: { right: 'auto' }
            });
        } else {
            this.setState({
                componentPosition: { right: 150 }
            });
        }
        return nodes;
    }
    getTopology = async (e) => {
        e && e.preventDefault();
        this.setState({
            loading: true
        });
        const params = { ...this.topologyRef.props.form.getFieldsValue() };
        const { code, entry } = await linkTrackingService.getTopology(params);
        if (code === '0' && isNotEmptyObject(entry)) {
            const { apps, rels } = entry;
            const categories = [];
            // const finalApps = this.initChartData(apps);
            apps.forEach((node, index) => {
                node.symbolSize = 30;
                node.value = node.relAppCount;
                node.label = {
                    normal: {
                        show: node.symbolSize > 1
                    }
                };
                if (categories.findIndex(item => item.name === node.type) === -1) {
                    categories.push({
                        name: node.type
                    });
                }
                node.category = categories.findIndex(item => item.name === node.type);
                delete node.id;
                delete node.relAppCount;
            });
            rels.forEach((link, index) => {
                link.source = link.provider;
                link.target = link.consumer;
                delete link.provider;
                delete link.consumer;
            });
            this.setState({
                categories,
                apps,
                rels
            }, () => {
                if (params.serviceName || params.methodName) {
                    this.setState({
                        labelPosition: 'bottom'
                    });
                } else {
                    this.setState({
                        labelPosition: 'right'
                    });
                }
                this.setState({
                    loading: false
                });
            });
        } else {
            this.setState({
                categories: [],
                apps: [],
                rels: []
            }, () => {
                this.setState({
                    loading: false
                });
            });

        }
    }
    render() {
        const {
            categories,
            apps,
            rels,
            loading,
            componentPosition,
            labelPosition
        } = this.state;
        const baseFormItemsSetting = {
            app: {
                id: 'appName',
                span: 3,
                options: {
                    initialValue: ''
                }
            },
            service: {
                id: 'serviceName',
                span: 5,
                options: {
                    initialValue: ''
                }
            },
            method: {
                id: 'methodName',
                span: 4,
                options: {
                    initialValue: ''
                }
            },
            button: {
                span: 3
            }
        };
        return (
            <div>
                <QueryForm wrappedComponentRef={(ref) => { this.topologyRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} onSubmit={this.getTopology} />
                <Spin spinning={loading} delay={500} tip="Loading...">
                    <Graph categories={categories} nodes={apps} links={rels} position={componentPosition} labelPosition={labelPosition}/>
                </Spin>
            </div>
        );
    }
}

export default TopologyInfo;

