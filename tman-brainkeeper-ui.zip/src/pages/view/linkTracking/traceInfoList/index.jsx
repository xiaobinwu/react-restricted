import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { getQueryString, storage, isNotEmptyObject } from 'js/util';
import { Table, Switch } from 'antd';
import { linkTrackingService } from 'service';
import QueryForm from 'component/queryForm';
import moment from 'moment';
import { APPNAME, SERVICENAME, METHODNAME } from 'js/variable';
import styles from './index.css';


class TraceInfoList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            sortField: 'timestamps',
            direction: 'DESC',
        };

        this.columns = [{
            title: '序号',
            dataIndex: 'index',
            key: 'index'
        }, {
            title: '接口',
            dataIndex: 'serviceName',
            key: 'serviceName',
            render: (text, row) => {
                return (<div title={text} className={styles.serviceName}>
                    {text}
                </div>);
            }
        }, {
            title: '方法',
            dataIndex: 'methodName',
            key: 'methodName',
            render: (text, row) => (
                <Link to={{ pathname: this.props.paths.InterfaceInfo.linkPath, search: `?col2=${row.appName}&col3=${row.serviceName}&col4=${row.methodName}&refresh=900&autoRefresh=true` }} target="_blank">{text}</Link>
            )
        }, {
            title: '应用名',
            dataIndex: 'appName',
            key: 'appName'
        }, {
            title: '时间',
            dataIndex: 'startTime',
            key: 'startTime',
            defaultSortOrder: 'descend',
            sorter: (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
        }, {
            title: '耗时（ms）',
            dataIndex: 'duration',
            key: 'duration',
            sorter: (a, b) => a.duration - b.duration
        }, {
            title: 'traceId',
            dataIndex: 'traceId',
            key: 'traceId',
            render: (text, row) => (
                <Link to={{ pathname: this.props.paths.TraceInquire.linkPath, search: `?traceId=${row.traceId}` }} target="_blank">{text}</Link>
            )
        }];
    }
    componentDidMount() {
        const result = getQueryString();
        if (isNotEmptyObject(result)) {
            if (result.startEventTime && result.endEventTime) {
                result.rangeTime = [moment(result.startEventTime), moment(result.endEventTime)];
                delete result.endEventTime;
                delete result.startEventTime;
            }
            this.traceInfoRef.props.form.setFieldsValue(this.filterParams(result));
            this.getListData();
        } else {
            const appName = storage.getStore(APPNAME);
            const serviceName = storage.getStore(SERVICENAME);
            const methodName = storage.getStore(METHODNAME);
            this.traceInfoRef.props.form.setFieldsValue({
                ...(appName ? { appName } : {}),
                ...(serviceName ? { serviceName } : {}),
                ...(methodName ? { methodName } : {})
            });
            this.getListData();
        }
    }
    // 过滤对象中空键
    filterParams = (data) => {
        const param = {};
        for (const key in data) {
            if (data[key] !== null && data[key] !== undefined && data[key] !== '') {
                param[key] = data[key];
            }
            if (data[key] === 'true' || data[key] === 'false') {
                param[key] = Boolean(data[key]);
            }
        }
        return param;
    }
    // 修改页数
    changePage = (page, pageSize) => {
        const { pagination } = this.state;
        this.setState({
            pagination: { ...pagination, ...{ pageNum: page, pageSize } }
        }, () => {
            this.getListData();
        });
    }
    // 获取列表数据
    getListData = async (e) => {
        e && e.preventDefault();
        const {
            sortField,
            direction
        } = this.state;
        this.traceInfoRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                const { pagination } = this.state;
                const params = { ...this.traceInfoRef.props.form.getFieldsValue(), ...pagination };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startDate = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endDate = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                delete params.rangeTime;
                delete params.totalCount;
                this.setState({
                    loading: true
                });
                const { entry, code } = await linkTrackingService.getTraceInfoList({
                    ...params,
                    ...(direction ? { direction } : {}),
                    ...(sortField ? { sortField } : {}),
                });
                if (code === '0' && entry) {
                    const data = entry.list.map((item, index) => ({
                        index: index + 1,
                        key: `${item.serviceName}-${item.methodName}-${item.appName}-${index}`,
                        serviceName: item.serviceName,
                        methodName: item.methodName,
                        appName: item.appName,
                        startTime: item.startTime,
                        duration: item.duration,
                        traceId: item.traceId
                    }));
                    this.setState({
                        loading: false,
                        pagination: { ...pagination, ...{ totalCount: entry.total } },
                        data
                    });
                }
            }
        });
    }
    // 自定义时间范围验证
    handleConfirmRangeDate = (rule, value, callback) => {
        if (value && value[1].diff(value[0], 'second') > 3600) {
            callback('时间范围不能超过1个小时');
        }
        callback();
    }
    // 排序
    onSortChange = (pagination, filters, sorter) => {
        if (!({}).hasOwnProperty.call(sorter, 'columnKey')) {
            this.setState({
                direction: 'DESC',
                sortField: 'timestamps'
            }, () => {
                this.getListData();
            });
        } else {
            this.setState({
                sortField: sorter.columnKey === 'startTime' ? 'timestamps' : 'duration',
                direction: sorter.order === 'descend' ? 'DESC' : 'ASC'
            }, () => {
                this.getListData();
            });
        }
    }
    render() {
        const {
            loading, data, pagination
        } = this.state;
        const { columns } = this;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount,
            onChange: this.changePage,
            onShowSizeChange: this.changePage
        };

        const extraFormItem = [
            {
                span: 3,
                label: '只查看异常',
                id: 'onlyException',
                options: {
                    valuePropName: 'checked',
                    initialValue: false
                },
                component: <Switch />
            }
        ];

        const baseFormItemsSetting = {
            app: {
                id: 'appName',
                span: 3,
                options: {
                    initialValue: ''
                }
            },
            service: {
                id: 'serviceName',
                span: 5,
                options: {
                    initialValue: ''
                }
            },
            method: {
                id: 'methodName',
                span: 4,
                options: {
                    initialValue: ''
                }
            },
            rangeTime: {
                span: 6,
                options: {
                    initialValue: [moment().subtract(0.5, 'hours'), moment()],
                    rules: [
                        { type: 'array', required: true, message: '请选择时间范围!' },
                        {
                            validator: this.handleConfirmRangeDate
                        }
                    ]
                }
            },
            button: {
                span: 3
            }
        };

        return (
            <div>
                <QueryForm wrappedComponentRef={(ref) => { this.traceInfoRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getListData} />
                <Table
                    className={styles.list}
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.onSortChange}
                />
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(TraceInfoList);
