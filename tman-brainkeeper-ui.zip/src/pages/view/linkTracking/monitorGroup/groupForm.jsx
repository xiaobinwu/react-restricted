import React, { Component } from 'react';
import { Form, Input } from 'antd';

const FormItem = Form.Item;
const { TextArea } = Input;

class GroupForm extends Component {
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        return (
            <Form>
                <FormItem label="组名" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true, message: '请填写组名',
                        }],
                    })(<Input disabled={!!injectForm.id}/>)}
                </FormItem>
                <FormItem label="描述" {...formItemLayout}>
                    {getFieldDecorator('describe', {
                        initialValue: injectForm.describe,
                        rules: [{
                            required: true, message: '请填写描述',
                        }],
                    })(<TextArea rows={4} />)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(GroupForm);
