import React, { Component } from 'react';
import { linkTrackingService } from 'service';
import { Table, Button, message, Modal } from 'antd';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import GroupForm from './groupForm';

const { confirm } = Modal;

const GroupFormModal = withFormModal(GroupForm);
const defaultGroupFormOptions = {
    id: '',
    name: '',
    describe: ''
};

class MonitorGroup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            groupForm: deepCopy(defaultGroupFormOptions),
            groupVisible: false,
            groupConfirmLoading: false,
        };
        this.columns = [{
            title: '组名',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '描述',
            dataIndex: 'describe',
            key: 'describe'
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (text, record) => {
                return (
                    <React.Fragment>
                        {
                            withPermission(<Button type="primary" onClick={this.setGroup.bind(this, record)} style={{ marginRight: 10 }}>编辑</Button>, 'PermissionMonitorGroupEdit')
                        }
                        {
                            withPermission(<Button type="primary" onClick={this.deleteGroup.bind(this, record)}>删除</Button>, 'PermissionMonitorGroupDelete')
                        }
                    </React.Fragment>
                );
            }
        }];
    }
    componentDidMount() {
        this.getMonitorGroupList();
    }
    // 获取列表
    getMonitorGroupList = async (e) => {
        e && e.preventDefault();
        this.setState({
            loading: true
        });
        const { entry, code } = await linkTrackingService.getMonitorGroupList();
        if (code === '0') {
            this.setState({
                loading: false,
                data: entry
            });
        }
    }
    // 获取ref
    getGroupFormRef = (ref) => {
        this.groupFormRef = ref;
    }
    // 删除
    deleteGroup = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该监控组？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await linkTrackingService.deleteGroup({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getMonitorGroupList();
                    }
                })();
            }
        });
    }
    // 添加、修改用户Modal
    setGroup = (record) => {
        let groupFormObj = {};
        if (record) {
            groupFormObj = {
                id: record.id,
                name: record.name,
                describe: record.describe
            };
        } else {
            groupFormObj = deepCopy(defaultGroupFormOptions);
        }
        this.setState({
            groupForm: groupFormObj,
            groupVisible: true
        });
    }
    // 保存
    setGroupSend = async () => {
        this.groupFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    groupConfirmLoading: true
                });
                let params = { ...this.groupFormRef.props.form.getFieldsValue() };
                if (this.state.groupForm.id) {
                    params = { ...params, ...{ id: this.state.groupForm.id } };
                }
                const res = await linkTrackingService.setGroupSend(params);
                if (res.code === '0') {
                    this.setState({
                        groupConfirmLoading: false,
                        groupVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.groupFormRef.props.form.resetFields();
                        this.getMonitorGroupList();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        groupConfirmLoading: false
                    });
                }
            }
        });
    }
    // 关闭modal
    handleCancel = (type) => {
        this.groupFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            data,
            loading,
            groupForm,
            groupVisible,
            groupConfirmLoading
        } = this.state;
        const { columns } = this;
        return (
            <React.Fragment>
                {
                    withPermission(<div style={{ marginBottom: '20px' }}><Button type="primary" onClick={this.setGroup}>新增</Button></div>, 'PermissionMonitorGroupAdd')
                }
                <Table rowKey="id" loading={loading} dataSource={data} columns={columns} pagination={false} />
                <GroupFormModal
                    maskClosable={false}
                    injectForm={groupForm}
                    getRef={this.getGroupFormRef}
                    title="监控组添加/修改"
                    visible={groupVisible}
                    onOk={this.setGroupSend}
                    onCancel={this.handleCancel.bind(this, 'groupVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={groupConfirmLoading} onClick={this.setGroupSend}>
                            确定
                        </Button>
                    ]}
                />
            </React.Fragment>
        );
    }
}

export default MonitorGroup;
