import React, { Component } from 'react';
import { Form, Row, Col, Select, Button, Table, Modal, message, Tag, Input } from 'antd';
import { linkTrackingService } from 'service';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { getQueryString, deepCopy } from 'js/util';
import RuleForm from './ruleForm';

const FormItem = Form.Item;
const { Option } = Select;
const { confirm } = Modal;

const RuleFormModal = withFormModal(RuleForm);
const defaultRuleFormOptions = {
    id: '',
    messageTitle: '',
    messageContentTemplate: '',
    groupId: '',
    endpointId: '',
    dataSourceName: 'app',
    appName: [],
    site: [],
    serviceId: '',
    methodName: [],
    status: 0,
    itemRelation: 0,
    keys: [0],
    metricNames: [[]],
    compareTypes: [''],
    conditionTypes: [''],
    thresholds: [''],
    isEdit: false
};
class MonitorRule extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            groupList: [],
            pointList: [],
            ruleForm: deepCopy(defaultRuleFormOptions),
            ruleVisible: false,
            ruleConfirmLoading: false
        };
        this.columns = [{
            title: '监控组',
            dataIndex: 'group',
            key: 'group'
        }, {
            title: '监控点',
            dataIndex: 'endpoint',
            key: 'endpoint'
        }, {
            title: '标题',
            dataIndex: 'messageTitle',
            key: 'messageTitle',
        }, {
            title: '告警级别',
            dataIndex: 'level',
            key: 'level',
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            render: (text, record) => {
                return text === 1 ? <Tag className='system-online-detail-tag'>开启</Tag> : <Tag className='system-online-detail-error-tag'>关闭</Tag>;
            }
        }, {
            title: '修改时间',
            dataIndex: 'updateTime',
            key: 'updateTime',
        }, {
            title: '修改人',
            dataIndex: 'updateBy',
            key: 'updateBy',
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (text, record) => {
                return (
                    <React.Fragment>
                        {
                            withPermission(<Button type="primary" onClick={this.toggleStatus.bind(this, record)} style={{ marginRight: 10 }}>{ record.status === 0 ? '开启' : '关闭' }</Button>, 'PermissionMonitorRuleUpdate')
                        }
                        {
                            withPermission(<Button type="primary" onClick={this.setRule.bind(this, record)} style={{ marginRight: 10 }}>修改</Button>, 'PermissionMonitorRuleEdit')
                        }
                        {
                            withPermission(<Button type="primary" onClick={this.deleteRule.bind(this, record)}>删除</Button>, 'PermissionMonitorRuleDelete')
                        }
                    </React.Fragment>
                );
            }
        }];
    }
    componentDidMount() {
        const result = getQueryString();
        if (result.ruleId) {
            (async () => {
                const { code, entry } = await linkTrackingService.getRuleDetail({ id: result.ruleId });
                if (code === '0') {
                    this.setRule(entry);
                }
            })();
        }
        this.getMonitorGroupList();
        this.getMonitorRuleList();
    }
    // 切换状态
    toggleStatus = async (record) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否更新状态？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const { id, status } = record;
                    let toggleStatus;
                    if (status === 1) {
                        toggleStatus = 0;
                    } else {
                        toggleStatus = 1;
                    }
                    const { code } = await linkTrackingService.setRuleSend({ id, status: toggleStatus });
                    if (code === '0') {
                        message.success('更新状态成功');
                        that.getMonitorRuleList();
                    }
                })();
            }
        });

    }
    // 删除
    deleteRule = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该规则？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await linkTrackingService.deleteRule({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getMonitorRuleList();
                    }
                })();
            }
        });
    }
    // 获取列表
    getMonitorRuleList = (e) => {
        e && e.preventDefault();
        this.props.form.validateFields(async (err, values) => {
            if (!err) {
                const { endpointIdList, groupId, messageTitle } = this.props.form.getFieldsValue();
                const { pagination } = this.state;
                this.setState({
                    loading: true
                });
                const params = {
                    ...pagination,
                    countSql: true,
                    groupId,
                    messageTitle,
                    endpointIdList
                };
                delete params.totalCount;
                const { entry, code } = await linkTrackingService.getMonitorRuleList(params);
                if (code === '0') {
                    this.setState({
                        loading: false,
                        pagination: { ...pagination, ...{ totalCount: entry.total } },
                        data: entry.list
                    });
                }

            }
        });
    }
    // 获取监控组
    getMonitorGroupList = async (e) => {
        const { entry, code } = await linkTrackingService.getMonitorGroupList();
        if (code === '0') {
            this.setState({
                groupList: entry
            });
        }
    }
    // 获取监控点
    getMonitorPointList = async (groupId) => {
        const { form } = this.props;
        const { entry, code } = await linkTrackingService.getMonitorPointList({ groupId });
        if (code === '0') {
            this.setState({
                pointList: entry.list
            }, () => {
                form.setFieldsValue({ endpointIdList: [] });
            });
        }
    }
    // 监控组onChange
    changGroup= (value) => {
        this.getMonitorPointList(value);
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getMonitorRuleList();
            });
        }
    }
    // 获取ref
    getRuleFormRef = (ref) => {
        this.ruleFormRef = ref;
    }
    // 添加、修改用户Modal
    setRule = (record) => {
        let ruleFormObj = {};
        if (record) {
            const {
                appName,
                serviceId,
                methodName,
                siteName
            } = record.filter;
            const { ruleItemDtoList } = record;
            const metricNames = [];
            const compareTypes = [];
            const conditionTypes = [];
            const thresholds = [];
            let itemRelation;
            ruleItemDtoList && ruleItemDtoList.forEach((item, index) => {
                metricNames.push([item.metricName]);
                compareTypes.push(String(item.compareType));
                conditionTypes.push(String(item.conditionType));
                thresholds.push(item.threshold);
                if (index === 0) {
                    itemRelation = item.itemRelation; // eslint-disable-line
                }
            });
            ruleFormObj = {
                id: record.id,
                messageTitle: record.messageTitle,
                messageContentTemplate: record.messageContentTemplate,
                groupId: String(record.groupId),
                endpointId: record.endpointId,
                dataSourceName: record.dataSourceName,
                ...{ ...(appName ? (serviceId ? { appName: appName[0] } : { appName }) : {}) },
                ...{ ...(serviceId ? { serviceId: serviceId[0] } : {}) },
                ...{ ...(methodName ? { methodName } : {}) },
                ...{ ...(siteName ? { site: siteName } : {}) },
                status: record.status,
                keys: Array.from(new Array(ruleItemDtoList ? ruleItemDtoList.length : 0), (val, index) => index),
                itemRelation,
                metricNames,
                compareTypes,
                conditionTypes,
                thresholds,
                isEdit: true
            };
        } else {
            ruleFormObj = deepCopy(defaultRuleFormOptions);
        }
        this.setState({
            ruleForm: ruleFormObj,
            ruleVisible: true
        });
    }
    // 保存
    setRuleSend = async () => {
        this.ruleFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    ruleConfirmLoading: true
                });
                let params = { ...this.ruleFormRef.props.form.getFieldsValue() };
                params.filter = {};
                params.ruleItemDtoList = [];
                if (params.appName) {
                    params.filter.appName = Array.isArray(params.appName) ? params.appName : [params.appName];
                    delete params.appName;
                }
                if (params.serviceId) {
                    params.filter.serviceId = [params.serviceId];
                    delete params.serviceId;
                }
                if (params.methodName) {
                    params.filter.methodName = params.methodName;
                    delete params.methodName;
                }
                if (params.site) {
                    params.filter.siteName = params.site;
                    delete params.site;
                }
                params.keys.forEach((item, index) => {
                    params.ruleItemDtoList.push({
                        metricName: params.metricNames[item][0],
                        compareType: params.compareTypes[item],
                        conditionType: params.conditionTypes[item],
                        threshold: params.thresholds[item],
                        itemRelation: params.itemRelation
                    });
                });
                delete params.metricNames;
                delete params.compareTypes;
                delete params.conditionTypes;
                delete params.thresholds;
                delete params.keys;
                delete params.itemRelation;
                if (this.state.ruleForm.id) {
                    params = { ...params, ...{ id: this.state.ruleForm.id } };
                }
                const res = await linkTrackingService.setRuleSend(params);
                if (res.code === '0') {
                    this.setState({
                        ruleConfirmLoading: false,
                        ruleVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.getMonitorRuleList();
                        this.ruleFormRef.props.form.resetFields();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        ruleConfirmLoading: false
                    });
                }
            }
        });
    }
    // 关闭modal
    handleCancel = (type) => {
        this.ruleFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            groupList,
            pointList,
            pagination,
            loading,
            data,
            ruleForm,
            ruleVisible,
            ruleConfirmLoading
        } = this.state;
        const { columns } = this;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const { getFieldDecorator } = this.props.form;
        return (
            <div>
                <Form onSubmit={this.getMonitorRuleList} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('groupId')(<Select
                                    showSearch
                                    onChange={this.changGroup}
                                    placeholder="请选择监控组"
                                    optionFilterProp='children'
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                >
                                    <Option value="">全部</Option>
                                    {
                                        groupList.map((item, index) => {
                                            return <Option key={item.id}>{item.name}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={7}>
                            <FormItem>
                                {getFieldDecorator('endpointIdList', {
                                    initialValue: [],
                                })(<Select
                                    showSearch
                                    mode="multiple"
                                    placeholder='请选择监控点'
                                    optionFilterProp='children'
                                    disabled={pointList.length === 0}
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                >
                                    {
                                        pointList.map((item) => {
                                            return (<Option value={item.id} key={item.id} tile={item.name}>{item.name}</Option>);
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('messageTitle', {
                                    initialValue: '',
                                })(<Input placeholder='请填写规则名称' />)}
                            </FormItem>
                        </Col>
                        <Col span={6}>
                            <FormItem style={{ textAlign: 'center' }}>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: 10 }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.setRule.bind(this, null)}>新增</Button>, 'PermissionMonitorRuleAdd')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table rowKey="id" loading={loading} dataSource={data} columns={columns} pagination={pageControl} onChange={this.handleTableChange}/>
                <RuleFormModal
                    width="90%"
                    maskClosable={false}
                    injectForm={ruleForm}
                    getRef={this.getRuleFormRef}
                    title="监控规则添加/修改"
                    visible={ruleVisible}
                    onOk={this.setRuleSend}
                    onCancel={this.handleCancel.bind(this, 'ruleVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={ruleConfirmLoading} onClick={this.setRuleSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp={{
                        groupList
                    }}
                />
            </div>
        );
    }
}

export default Form.create()(MonitorRule);
