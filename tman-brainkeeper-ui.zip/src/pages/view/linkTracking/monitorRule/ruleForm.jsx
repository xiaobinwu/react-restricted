import React, { Component } from 'react';
import { Row, Col, Form, Input, Select, Radio, Button, Icon, Divider } from 'antd';
import { linkTrackingService, systemManagementService } from 'service';
import { isNotEmptyObject } from 'js/util';
import styles from './index.css';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { Option } = Select;

const { TextArea } = Input;
let uuid = 1;
class RuleForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pointList: [],
            compareTypeList: [],
            conditionTypeList: [],
            dataSourceList: {},
            appList: [],
            serviceSet: [],
            sites: [],
            methodSet: {},
            serviceName: '',
            dataSourceName: 'app',
            percentSign: {}
        };
    }
    componentDidMount() {
        this.updateDataSourceName();
        this.updateEndPoint();
        this.getSiteList();
        this.getCompareTypeList();
        this.getConditionTypeList();
        this.getDataSourceList();
        this.getAllApplications();
    }
    UNSAFE_componentWillReceiveProps(nextProps) { //eslint-disable-line
        // 更新类型
        if (this.props.injectForm.dataSourceName !== nextProps.injectForm.dataSourceName) {
            this.setState({
                dataSourceName: nextProps.injectForm.dataSourceName
            });
        }
        // 更新阀值百分号的显示
        if (this.props.injectForm.keys !== nextProps.injectForm.keys) {
            this.updatePercentSign(nextProps.injectForm);
        }
    }
    componentDidUpdate(prevProps, prevState, snapshot) {
        const { injectForm } = this.props;
        const { compareTypeList } = this.state;
        // groupId不一样时，触发一次监控点更新
        if (prevProps.injectForm.groupId !== injectForm.groupId) {
            this.updateEndPoint();
        }
        // 规则项-类型完成请求后，执行一次阀值百分号是否显示的更新（只触发一次）
        if (prevState.compareTypeList !== compareTypeList) {
            this.updatePercentSign(injectForm);
        }
    }
    // 规则项-类型 下拉框触发（用于切换类型项从而改变百分号的显示）
    changeType = (value, option, k) => {
        const { getFieldValue } = this.props.form;
        const keys = getFieldValue('keys');
        keys.forEach((item, index) => {
            if (item === k) {
                this.setState((prevState) => {
                    return {
                        percentSign: Object.assign({}, prevState.percentSign, { [k]: (option.props.ispercent === 'true') })
                    };
                });
            }
        });
    }
    // 更新阀值百分号的显示
    updatePercentSign(injectForm) {
        const { compareTypeList } = this.state;
        const percentSign = {};
        injectForm.keys.forEach((item) => {
            compareTypeList.some((it) => {
                if (String(injectForm.compareTypes[item]) === String(it.value)) {
                    percentSign[item] = (it.isPercent === 'true');
                    return true;
                }
                return false;
            });
        });
        if (isNotEmptyObject(percentSign)) {
            this.setState((prevState) => {
                return {
                    percentSign
                };
            });
        }
    }
    // 更新类型,从而改变应用，服务，接口，站点下拉框之间的变化
    updateDataSourceName() {
        const { injectForm } = this.props;
        if (injectForm.groupId) {
            this.setState({
                dataSourceName: injectForm.dataSourceName
            });
        }
    }
    // 更新监控点
    updateEndPoint() {
        const { injectForm } = this.props;
        if (injectForm.groupId && injectForm.groupId !== 'undefined') {
            this.getMonitorPointList(injectForm.groupId, false);
        }
    }
    // 添加
    add = () => {
        const { form, injectForm } = this.props;
        const keys = form.getFieldValue('keys');
        if (injectForm.isEdit) {
            uuid = keys.length;
        }
        const nextKeys = keys.concat(uuid);
        uuid++; // eslint-disable-line
        form.setFieldsValue({
            keys: nextKeys
        });
    }
    // 删除
    remove = (k) => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        if (keys.length === 1) {
            return;
        }
        form.setFieldsValue({
            keys: keys.filter(key => key !== k)
        });
    }
    // 获取比较类型
    getCompareTypeList = async () => {
        const { entry, code } = await linkTrackingService.getCompareTypeList();
        const compareTypeList = [];
        if (code === '0') {
            entry && Object.keys(entry).forEach((item) => {
                compareTypeList.push({
                    text: entry[item].desc,
                    value: entry[item].code,
                    isPercent: entry[item].isPercent.toString()
                });
            });
            this.setState({
                compareTypeList
            });
        }
    }
    // 获取条件类型
    getConditionTypeList = async () => {
        const { entry, code } = await linkTrackingService.getConditionTypeList();
        const conditionTypeList = [];
        if (code === '0') {
            entry && Object.keys(entry).forEach((item) => {
                conditionTypeList.push({
                    text: entry[item],
                    value: item
                });
            });
            this.setState({
                conditionTypeList
            });
        }
    }
    // 获取数据源
    getDataSourceList = async () => {
        const { entry, code } = await linkTrackingService.getDataSourceList();
        const dataSourceList = {};
        if (code === '0') {
            entry && entry.forEach((item) => {
                const metricItemMap = [];
                item.metricItemMap && Object.keys(item.metricItemMap).forEach((it) => {
                    metricItemMap.push({
                        text: it,
                        value: item.metricItemMap[it]
                    });
                });
                dataSourceList[item.name] = metricItemMap;
            });
            this.setState({
                dataSourceList
            });
        }
    }
    // 获取站点
    getSiteList = async () => {
        const sites = [];
        const { entry } = await linkTrackingService.getAllSite();
        entry.forEach((item) => {
            sites.push({
                text: JSON.parse(item.value).cnName,
                value: item.key
            });
        });
        this.setState({
            sites
        });
    }
    // 获取监控点
    getMonitorPointList = async (groupId, isReset = true) => {
        const { form } = this.props;
        if (groupId) {
            const { entry, code } = await linkTrackingService.getMonitorPointList({ groupId });
            if (code === '0') {
                this.setState({
                    pointList: entry.list
                }, () => {
                    if (isReset) {
                        form.setFieldsValue({ endpointId: '' });
                    }
                });
            }
        }
    }
    // 监控组onChange
    changGroup= (value) => {
        this.getMonitorPointList(value);
    }
    // 获取应用
    getAllApplications = async () => {
        const { entry, code } = await systemManagementService.getAllApplications({}, true);
        if (code === '0') {
            this.setState({
                appList: entry
            });
        }
    }
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    // app处理
    handleAppChange = async (value, option) => {
        const { dataSourceName } = this.state;
        if (dataSourceName !== 'app' && dataSourceName !== 'system') {
            this.props.form.resetFields([
                'serviceId',
                'methodName'
            ]);
            const { site, id } = option.props;
            const { entry } = await linkTrackingService.getAllService({ site, appId: id });
            const serviceSet = [];
            const methodSet = {};
            entry && entry.forEach((item) => {
                serviceSet.push({
                    id: item.id,
                    name: item.name
                });
                methodSet[item.name] = item.methods;
            });
            this.setState({
                serviceSet,
                methodSet
            });
        }
    }
    // 触发服务select Onchange
    handleServiceChange = (value, option) => {
        this.props.form.setFieldsValue({
            method: []
        });
        if (value !== '') {
            this.setState({
                serviceName: value
            });
        }
    }
    // 类型改变触发
    changeDataSourceName = (e) => {
        this.setState({
            dataSourceName: e.target.value
        }, () => {
            const { form } = this.props;
            const { getFieldValue } = form;
            const keys = getFieldValue('keys');
            const newKeys = keys.map((k) => {
                return `metricNames[${k}]`;
            });
            form.resetFields(newKeys);
        });
    }
    // 自定义指标验证
    handleConfirmMetricName = (rule, value, callback) => {
        if (value && value.length > 1) {
            callback('指标只能填写一个');
        }
        callback();
    }
    render() {
        const {
            form,
            injectForm,
            groupList,
        } = this.props;
        const {
            pointList,
            appList,
            serviceSet,
            methodSet,
            serviceName,
            compareTypeList,
            conditionTypeList,
            dataSourceList,
            dataSourceName,
            sites,
            percentSign
        } = this.state;
        const { getFieldDecorator, getFieldValue } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        const formAllItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 1 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 23 },
            }
        };
        getFieldDecorator('keys', { initialValue: injectForm.keys });
        const keys = getFieldValue('keys');
        const formItem = keys && keys.map((k, index) => {
            return (
                <React.Fragment key={index}>
                    <div className={styles.ruleWrap}>
                        <Col span={10}>
                            <FormItem {...formItemLayout} label="指标">
                                {getFieldDecorator(`metricNames[${k}]`, {
                                    initialValue: injectForm.metricNames[k],
                                    rules: [{
                                        required: true, message: '请选择指标',
                                    }, {
                                        validator: this.handleConfirmMetricName
                                    }],
                                })(<Select mode="tags">
                                    {
                                        dataSourceList[dataSourceName] && dataSourceList[dataSourceName].map((d, dInx) => (
                                            <Option key={d.value}>{d.text}</Option>
                                        ))
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={10}>
                            <FormItem {...formItemLayout} label="类型">
                                {getFieldDecorator(`compareTypes[${k}]`, {
                                    initialValue: injectForm.compareTypes[k],
                                    rules: [{
                                        required: true, message: '请选择类型',
                                    }],
                                })(<Select onChange={(value, option) => { this.changeType(value, option, k); }}>
                                    {
                                        compareTypeList.map((c, cInx) => (
                                            <Option key={c.value} ispercent={c.isPercent}>{c.text}</Option>
                                        ))
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={10}>
                            <FormItem {...formItemLayout} label="表达式">
                                {getFieldDecorator(`conditionTypes[${k}]`, {
                                    initialValue: injectForm.conditionTypes[k],
                                    rules: [{
                                        required: true, message: '请选择表达式',
                                    }],
                                })(<Select>
                                    {
                                        conditionTypeList.map((n, nInx) => (
                                            <Option key={n.value}>{n.text}</Option>
                                        ))
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={10}>
                            <FormItem {...formItemLayout} label="阀值">
                                {getFieldDecorator(`thresholds[${k}]`, {
                                    initialValue: injectForm.thresholds[k],
                                    rules: [{
                                        pattern: new RegExp(/^(-)?\d+(.\d+)?$/, 'g'), message: '可以填写整数或小数'
                                    }, {
                                        required: true, message: '请填写阀值'
                                    }],
                                })(<Input { ...(percentSign[k] ? { addonAfter: '%' } : {}) }/>)}
                            </FormItem>
                        </Col>
                        <Col span={4} style={{ textAlign: 'right' }}>
                            {/* onClick={() => this.add()} 必须这样写，不然会报错, 存在立即执行的方法，循环触发更新 https://github.com/ckinmind/ReactCollect/issues/99 */}
                            {
                                (keys.indexOf(k) === keys.length - 1) ? <Button type="primary" style={{ marginRight: '5px' }} onClick={() => this.add()}><Icon type="plus" /></Button> : null
                            }
                            {
                                keys.length > 1 ? <Button type="primary" onClick={() => this.remove(k)}><Icon type="minus" /></Button> : null
                            }
                        </Col>
                        {
                            (keys.indexOf(k) !== keys.length - 1) ? <Divider style={{ marginBottom: 0 }} className="system-colony-divider-color"/> : null
                        }
                    </div>
                </React.Fragment>
            );
        });
        return (
            <Form className={styles.form}>
                <Row>
                    <Col span={12}>
                        <FormItem label="标题" {...formItemLayout}>
                            {getFieldDecorator('messageTitle', {
                                initialValue: injectForm.messageTitle,
                                rules: [{
                                    required: true, message: '请填写标题',
                                }],
                            })(<Input />)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="状态" {...formItemLayout}>
                            {getFieldDecorator('status', {
                                initialValue: injectForm.status,
                                rules: [{
                                    required: true, message: '请选择状态',
                                }],
                            })(<RadioGroup>
                                <Radio value={1}>开启</Radio>
                                <Radio value={0}>关闭</Radio>
                            </RadioGroup>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="监控组" {...formItemLayout}>
                            {getFieldDecorator('groupId', {
                                initialValue: injectForm.groupId,
                                rules: [{
                                    required: true, message: '请选择监控组',
                                }],
                            })(<Select
                                onSelect={this.changGroup}
                                showSearch
                                placeholder="请选择监控组"
                                filterOption={this.filterOption}
                            >
                                {
                                    groupList.map((item, index) => {
                                        return <Option key={item.id}>{item.name}</Option>;
                                    })
                                }
                            </Select>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="监控点" {...formItemLayout}>
                            {getFieldDecorator('endpointId', {
                                initialValue: injectForm.endpointId,
                                rules: [{
                                    required: true, message: '请选择监控点',
                                }],
                            })(<Select
                                showSearch
                                placeholder='请选择监控点'
                                optionFilterProp='children'
                                disabled={pointList.length === 0}
                                filterOption={this.filterOption}
                            >
                                {
                                    pointList.map((item) => {
                                        return (<Option value={item.id} key={item.id} tile={item.endpointDesc}>{item.endpointDesc}</Option>);
                                    })
                                }
                            </Select>)}
                        </FormItem>
                    </Col>
                    <Col span={24}>
                        <FormItem {...formAllItemLayout} label="类型">
                            {getFieldDecorator('dataSourceName', {
                                initialValue: injectForm.dataSourceName,
                                rules: [{
                                    required: true, message: '请选择类型',
                                }],
                            })(<RadioGroup onChange={this.changeDataSourceName}>
                                <Radio value="app">应用</Radio>
                                <Radio value="service">服务</Radio>
                                <Radio value="site">站点</Radio>
                                <Radio value="system">系统</Radio>
                            </RadioGroup>)}
                        </FormItem>
                    </Col>
                    <Col span={24}>
                        <FormItem label="关联关系" {...formAllItemLayout}>
                            {getFieldDecorator('itemRelation', {
                                initialValue: injectForm.itemRelation,
                                rules: [{
                                    required: true, message: '请选择关联关系',
                                }],
                            })(<Select>
                                <Option value={0}>满足任一条件</Option>
                                <Option value={1}>满足全部条件</Option>
                            </Select>)}
                        </FormItem>
                    </Col>
                    {
                        (dataSourceName === 'app' || dataSourceName === 'service' || dataSourceName === 'system') ? <React.Fragment><Col span={dataSourceName === 'app' ? 24 : 8}>
                            <FormItem {...(dataSourceName === 'app' ? formAllItemLayout : formItemLayout)} label="应用">
                                {getFieldDecorator('appName', {
                                    initialValue: injectForm.appName,
                                    rules: [{
                                        required: true, message: '请选择监控点',
                                    }],
                                })(<Select
                                    { ...((dataSourceName === 'app' || dataSourceName === 'system') ? { mode: 'multiple' } : {}) }
                                    showSearch
                                    optionFilterProp="children"
                                    onChange={this.handleAppChange}
                                    filterOption={this.filterOption}
                                >
                                    {
                                        appList.map((item, index) => (
                                            <Option key={item.name} title={item.name} id={item.id} site={item.domain}>{item.name}</Option>
                                        ))
                                    }
                                </Select>)}
                            </FormItem>
                        </Col></React.Fragment> : null
                    }
                    {
                        dataSourceName === 'service' ? <React.Fragment><Col span={8}>
                            <FormItem {...formItemLayout} label="服务">
                                {getFieldDecorator('serviceId', {
                                    initialValue: injectForm.serviceId,
                                    rules: [{
                                        required: true, message: '请选择服务',
                                    }],
                                })(<Select
                                    showSearch
                                    optionFilterProp="children"
                                    onChange={this.handleServiceChange}
                                    filterOption={this.filterOption}
                                >
                                    {
                                        serviceSet.map((item, index) => (
                                            <Option key={item.name} title={item.name} style={{ direction: 'rtl' }}>{item.name}</Option>
                                        ))
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem {...formItemLayout} label="接口">
                                {getFieldDecorator('methodName', {
                                    initialValue: injectForm.methodName,
                                    rules: [{
                                        required: true, message: '请选择接口',
                                    }],
                                })(<Select
                                    mode="multiple"
                                    showSearch
                                    optionFilterProp="children"
                                    filterOption={this.filterOption}
                                >
                                    {
                                        (serviceName && methodSet[serviceName]) ? methodSet[serviceName].map((item, index) => (
                                            <Option key={item.name} title={item.name}>{item.name}</Option>
                                        )) : null
                                    }
                                </Select>)}
                            </FormItem>
                        </Col></React.Fragment> : null
                    }
                    {
                        dataSourceName === 'site' ? <React.Fragment><Col span={24}>
                            <FormItem {...formAllItemLayout} label="站点">
                                {getFieldDecorator('site', {
                                    initialValue: injectForm.site,
                                    rules: [{
                                        required: true, message: '请选择站点',
                                    }],
                                })(<Select
                                    mode="multiple"
                                    showSearch
                                    optionFilterProp="children"
                                    filterOption={this.filterOption}
                                >
                                    {
                                        sites.map((item, index) => (
                                            <Option key={item.value} title={item.text}>{item.text}</Option>
                                        ))
                                    }
                                </Select>)}
                            </FormItem>
                        </Col></React.Fragment> : null
                    }
                    <fieldset className="system-rule-fieldset">
                        <legend className="system-rule-legend">规则项</legend>
                        {formItem}
                    </fieldset>
                    <Col span={24}>
                        <FormItem label="消息" {...formAllItemLayout}>
                            {getFieldDecorator('messageContentTemplate', {
                                initialValue: injectForm.messageContentTemplate,
                                rules: [{
                                    required: true, message: '请填写消息',
                                }],
                            })(<TextArea rows={4} />)}
                        </FormItem>
                    </Col>
                </Row>
            </Form>
        );
    }
}

export default Form.create()(RuleForm);
