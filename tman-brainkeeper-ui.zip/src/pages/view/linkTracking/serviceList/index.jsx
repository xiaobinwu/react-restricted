import React, { Component } from 'react';
import { Table, Button, message, Input, Row, Col } from 'antd';
import { Link } from 'react-router-dom';
import { linkTrackingService } from 'service';
import QueryForm from 'component/queryForm';
import { connect } from 'react-redux';
import withPermission from 'component/hoc/withPermission';
import withFormModal from 'component/hoc/withFormModal';
import EditForm from './editForm';
import AddForm from './addForm';

// 编辑
const EditFormModal = withFormModal(EditForm);
const AddFormModal = withFormModal(AddForm);

class ServiceList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            editConfirmLoading: false,
            editVisible: false,
            editForm: null,
            addConfirmLoading: false,
            addVisible: false,
            addForm: {
                appId: '',
                name: '',
                method: '',
                description: ''
            }
        };
        this.columns = [{
            title: '应用名',
            dataIndex: 'appName',
            key: 'appName'
        }, {
            title: '服务名',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '方法名',
            dataIndex: 'method',
            key: 'method',
            render: (text, row) => (
                <Link to={{ pathname: this.props.paths.InterfaceInfo.linkPath, search: `?col2=${row.appName}&col3=${row.name}&col4=${row.method}&refresh=900&autoRefresh=true` }} target="_blank">{text}</Link>
            )
        }, {
            title: '描述',
            dataIndex: 'description',
            width: 200,
            key: 'description'
        }, {
            title: '创建时间',
            dataIndex: 'createTime',
            key: 'createTime'
        }, {
            title: '修改时间',
            dataIndex: 'modifyTime',
            key: 'modifyTime'
        }];
        if (withPermission(true, 'PermissionServiceListEdit')) {
            this.columns.push({
                title: '操作',
                key: 'action',
                render: (text, record) => {
                    return (
                        <React.Fragment>
                            <Button type="primary" style={{ marginRight: '5px' }} onClick={this.openEditServiceModal.bind(this, record.id, record.description)}>编辑</Button>
                            <Button type="primary" onClick={this.addFavorite.bind(this, record)}>添加到收藏</Button>
                        </React.Fragment>
                    );
                }
            });
        }
    }
    componentDidMount() {
        this.getServiceList();
    }
    // 添加接口到收藏列表
    addFavorite = async (item) => {
        const res = await linkTrackingService.addFavorite({ serviceId: item.id });
        if (res.code === '0') {
            message.success(res.message);
        }
    }
    // 编辑modal
    openEditServiceModal = (id, description) => {
        this.setState({
            editForm: { id, description },
            editVisible: true
        });
    }
    // 编辑保存
    bindEditSend = async () => {
        this.setState({
            editConfirmLoading: true
        });
        const params = { ...this.editFormRef.props.form.getFieldsValue(), id: this.state.editForm.id };
        const res = await linkTrackingService.setServiceSend(params);
        if (res.code === '0') {
            this.setState({
                editConfirmLoading: false,
                editVisible: false
            }, () => {
                message.success('保存成功');
                this.editFormRef.props.form.resetFields();
                this.getServiceList();
            });
        } else {
            this.setState({
                editConfirmLoading: false
            });
        }
    }
    // 添加
    add = () => {
        this.setState({
            addVisible: true
        });
    }
    // 新增
    bindAddSend = async () => {
        this.addFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    addConfirmLoading: true
                });
                const params = { ...this.addFormRef.props.form.getFieldsValue() };
                const res = await linkTrackingService.setAddServiceSend(params);
                if (res.code === '0') {
                    this.setState({
                        addConfirmLoading: false,
                        addVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.addFormRef.props.form.resetFields();
                        this.getServiceList();
                    });
                } else {
                    this.setState({
                        addConfirmLoading: false
                    });
                }
            }
        });
    }
    // 获取列表数据
    getServiceList = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination, ...this.serviceRef.props.form.getFieldsValue(), ...{ countSql: true } };
        delete params.totalCount;
        const { entry, code } = await linkTrackingService.getServiceList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getServiceList();
            });
        }
    }
    // 关闭modal
    handleCancel = (type) => {
        this.editFormRef && this.editFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    getEditFormRef = (ref) => {
        this.editFormRef = ref;
    }
    getAddFormRef = (ref) => {
        this.addFormRef = ref;
    }
    render() {
        const {
            data,
            pagination,
            loading,
            editVisible,
            editConfirmLoading,
            editForm,
            addForm,
            addConfirmLoading,
            addVisible
        } = this.state;
        const {
            columns
        } = this;
        const baseFormItemsSetting = {
            app: {
                id: 'appName',
                span: 3,
                options: {
                    initialValue: ''
                }
            },
            service: {
                id: 'name',
                span: 4,
                options: {
                    initialValue: '',
                }
            },
            method: {
                id: 'method',
                span: 3,
                options: {
                    initialValue: ''
                }
            },
            button: {
                span: 3
            }
        };
        const extraFormItem = [
            {
                span: 3,
                id: 'description',
                options: {
                    initialValue: ''
                },
                component: <Input placeholder="描述" />
            }
        ];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <Row>
                    <Col span={21}>
                        <QueryForm wrappedComponentRef={(ref) => { this.serviceRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getServiceList} />
                    </Col>
                    <Col span={3} style={{ textAlign: 'right' }}>
                        <Button type="primary" onClick={this.add}>添加</Button>
                    </Col>
                </Row>
                <Table rowKey="id" loading={loading} dataSource={data} columns={columns} pagination={pageControl} onChange={this.handleTableChange}/>
                <EditFormModal
                    maskClosable={false}
                    getRef={this.getEditFormRef}
                    injectForm={editForm}
                    title="编辑"
                    visible={editVisible}
                    onOk={this.bindEditSend}
                    onCancel={this.handleCancel.bind(this, 'editVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={editConfirmLoading} onClick={this.bindEditSend}>
                            确定
                        </Button>
                    ]}
                />
                <AddFormModal
                    maskClosable={false}
                    getRef={this.getAddFormRef}
                    injectForm={addForm}
                    title="新增"
                    visible={addVisible}
                    onOk={this.bindAddSend}
                    onCancel={this.handleCancel.bind(this, 'addVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={addConfirmLoading} onClick={this.bindAddSend}>
                            确定
                        </Button>
                    ]}
                />
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(ServiceList);
