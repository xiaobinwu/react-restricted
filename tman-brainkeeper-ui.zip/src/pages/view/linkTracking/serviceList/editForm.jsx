import React, { Component } from 'react';
import { Form, Input } from 'antd';

const { TextArea } = Input;
const FormItem = Form.Item;

class EditForm extends Component {
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        return (
            <Form>
                <FormItem label="描述" {...formItemLayout}>
                    {getFieldDecorator('description', {
                        initialValue: injectForm.description,
                    })(<TextArea rows={3}/>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(EditForm);
