import React, { Component } from 'react';
import { Form, Input, Select } from 'antd';
import { systemManagementService } from 'service';

const { TextArea } = Input;
const { Option } = Select;
const FormItem = Form.Item;

class AddForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            appList: [],
        };
    }
    componentDidMount() {
        this.getAppList();
    }
    // 获取应用列表
    getAppList = async () => {
        const { entry } = await systemManagementService.getAllApplications({}, true);
        this.setState({
            appList: entry
        });
    }
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0

    render() {
        const {
            form,
            injectForm
        } = this.props;
        const {
            appList,
        } = this.state;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        return (
            <Form>
                <FormItem label="应用" {...formItemLayout}>
                    {getFieldDecorator('appId', {
                        rules: [{
                            required: true, message: '请选择应用',
                        }],
                    })(<Select style={{ width: '100%' }} showSearch optionFilterProp="children" placeholder="请选择应用" filterOption={this.filterOption}>
                        {
                            appList && appList.map((item, index) => (
                                <Option key={item.id} title={`${item.name}${item.description ? `(${item.description})` : ''}`} id={item.id} site={item.domain}>{item.name}</Option>
                            ))
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="服务名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        rules: [{
                            required: true, message: '请填写服务',
                        }],
                    })(<Input placeholder="请填写服务" />)}
                </FormItem>
                <FormItem label="方法名称" {...formItemLayout}>
                    {getFieldDecorator('method', {
                        rules: [{
                            required: true, message: '请填写方法',
                        }],
                    })(<Input placeholder="请填写方法" />)}
                </FormItem>
                <FormItem label="描述" {...formItemLayout}>
                    {getFieldDecorator('description', {
                        initialValue: injectForm.description,
                        rules: [{
                            required: true, message: '请填写描述',
                        }],
                    })(<TextArea rows={3}/>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(AddForm);
