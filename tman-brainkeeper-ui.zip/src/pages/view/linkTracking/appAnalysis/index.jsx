import React, { Component } from 'react';
import QueryForm from 'component/queryForm';
import { Select, Spin } from 'antd';
import moment from 'moment';
import { linkTrackingService } from 'service';

import App from './charts/app';
import Proportion from './charts/proportion';

const { Option, OptGroup } = Select;

class AppAnalysis extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            proportion: {},
            pages: [],
            apps: [],
            tags: {},
            currentSeriesName: '',
            currentAppName: ''
        };
        this.rangeTimeInitialValue = [moment().subtract(1, 'hours'), moment()];
    }
    componentDidMount() {
        this.getApps();
        this.appSelect('gearbest-m-app');
        this.getAppAnalysisList();
    }
    // 获取应用
    getApps = async () => {
        const { code, entry } = await linkTrackingService.getListApps();
        if (code === '0') {
            this.setState({
                apps: entry
            });
        }
    }
    // 应用onChange
    appSelect = async (value) => {
        this.setState({
            currentAppName: value
        }, () => {
            this.appRef.props.form.resetFields(['pageName', 'tag']);
            this.getPages(value);
            this.getTags(value);
        });
    }
    // 获取页面
    getPages = async (appName) => {
        const { code, entry } = await linkTrackingService.getListPages({ appName });
        if (code === '0') {
            this.setState({
                pages: entry
            });
        }
    }
    // 获取标签
    getTags = async (appName) => {
        const { code, entry } = await linkTrackingService.getListTags({ appName });
        if (code === '0') {
            this.setState({
                tags: entry,
            });
        }
    }
    // 获取数据
    getAppAnalysisList = (e) => {
        e && e.preventDefault();
        this.appRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    loading: true
                });
                const params = { ...this.appRef.props.form.getFieldsValue() };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                delete params.rangeTime;
                const { entry, code } = await linkTrackingService.getListMetric(params);
                if (code === '0') {
                    this.setState({
                        loading: false,
                        data: entry,
                        proportion: {},
                        currentSeriesName: ''
                    });
                    this.onLineClick({
                        seriesName: '平均耗时',
                        componentSubType: 'line',
                        name: this.getLastDotTime(entry)
                    });
                }
            }
        });
    }
    // 获取最近一个点有数值的数据
    getLastDotTime = (entry) => {
        const result = entry.filter((item) => { return item.value && JSON.stringify(item.value) !== '{}'; });
        if (result.length === 0) {
            return moment().format('YYYY-MM-DD HH:mm:ss');
        }
        return result[result.length - 1].timestamp;
    }
    // 折线图点击事件
    onLineClick = async (params, showLoading = true) => {
        if (params.componentSubType === 'line') {
            if (showLoading) {
                this.setState({
                    loading: true
                });
            }
            const { code, entry } = await linkTrackingService.getListMetricRatio({
                ...this.appRef.props.form.getFieldsValue(),
                startEventTime: params.name,
                endEventTime: moment(params.name).add(60, 'seconds').format('YYYY-MM-DD HH:mm:ss')
            });
            if (code === '0') {
                this.setState({
                    proportion: entry,
                    loading: false,
                    currentSeriesName: params.seriesName
                });
            }
        }
    }
    // Tag验证规则
    validateTagNum = (rule, value, callback) => {
        if (value && value.length > 3) {
            callback('最多选择三个');
        }
        callback();
    }
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    render() {
        const {
            pages,
            apps,
            tags,
            data,
            proportion,
            currentSeriesName,
            loading
        } = this.state;
        const { rangeTimeInitialValue } = this;
        const baseFormItemsSetting = {
            rangeTime: {
                span: 7,
                options: {
                    initialValue: rangeTimeInitialValue,
                    rules: [{
                        required: true,
                        message: '时间必选'
                    }]
                }
            },
            button: {
                span: 3
            }
        };
        const pageSelectComponent = (<Select placeholder="请选择页面" showSearch filterOption={this.filterOption}>
            {
                pages.map((item, index) => {
                    return (<Option key={item}>{item}</Option>);
                })
            }
        </Select>);
        const appSelectComponent = (<Select placeholder="请选择应用" onChange={this.appSelect} showSearch filterOption={this.filterOption}>
            {
                apps.map((item, index) => {
                    return (<Option key={item}>{item}</Option>);
                })
            }
        </Select>);
        const tagSelectComponent = (<Select mode="multiple" placeholder="请选择标签" showSearch>
            {
                Object.keys(tags).map((item, index) => {
                    return (
                        <OptGroup label={item} key={index}>
                            {
                                tags[item] && tags[item].map((it) => {
                                    return (<Option key={it}>{it}</Option>);
                                })
                            }
                        </OptGroup>
                    );
                })
            }
        </Select>);
        const preFormItem = [
            {
                span: 3,
                id: 'appName',
                component: appSelectComponent,
                options: {
                    initialValue: 'gearbest-m-app',
                    rules: [{
                        required: true,
                        message: '应用必选'
                    }]
                }
            },
            {
                span: 5,
                id: 'pageName',
                component: pageSelectComponent,
                options: {
                    initialValue: 'home',
                    rules: [{
                        required: true,
                        message: '页面必选'
                    }]
                }
            },
            {
                span: 6,
                id: 'tag',
                component: tagSelectComponent,
                options: {
                    rules: [{
                        validator: this.validateTagNum
                    }]
                }
            }
        ];
        return (
            <div>
                <QueryForm wrappedComponentRef={(ref) => { this.appRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} preFormItem={preFormItem} onSubmit={this.getAppAnalysisList} />
                <Spin spinning={loading} tip="Loading...">
                    <App metric={data} onLineClick={this.onLineClick} />
                    {
                        currentSeriesName ? <Proportion proportion={proportion} currentSeriesName={currentSeriesName} /> : null
                    }
                </Spin>
            </div>
        );
    }
}

export default AppAnalysis;
