import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

const legends = [
    { legend: '最小耗时', field: 'minDuration' },
    { legend: '平均耗时', field: 'avgDuration' },
    { legend: '最大耗时', field: 'maxDuration' }
];
export default class App extends Component {
    render() {
        const {
            metric,
            onLineClick
        } = this.props;

        const xAxis = [];
        const data = {
            minDuration: [],
            avgDuration: [],
            maxDuration: []
        };
        metric.forEach((item, index) => {
            xAxis.push(item.timestamp);
            data.minDuration.push(item.value ? item.value.minDuration : 0);
            data.avgDuration.push(item.value ? item.value.avgDuration : 0);
            data.maxDuration.push(item.value ? item.value.maxDuration : 0);
        });

        const series = legends.map((item, index) => {
            return {
                name: item.legend,
                type: 'line',
                showSymbol: true,
                smooth: true,
                tooltip: {
                    trigger: 'item',
                    formatter: `点击显示${item.legend}占比<br>时间：{b}<br>耗时：{c}`
                },
                data: data[item.field]
            };
        });

        const options = {
            tooltip: [{
                trigger: 'axis'
            }],
            grid: [{
                top: 50
            }],
            toolbox: {
                show: true,
                feature: {
                    saveAsImage: {}
                }
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            legend: [{
                data: legends.map(item => item.legend),
                top: 12
            }],
            title: [{
                text: '耗时趋势（点击趋势图时间点可查看详情）',
                right: -100,
                top: 10,
                textAlign: 'center',
                textStyle: {
                    fontSize: 16
                }
            }],
            xAxis: [{
                type: 'category',
                splitLine: {
                    show: false
                },
                boundaryGap: false,
                data: xAxis
            }],
            yAxis: [{
                type: 'value',
                name: '耗时',
                splitLine: {
                    show: false
                }
            }],
            series
        };
        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%' }}
                    onEvents={{
                        click: (params) => {
                            onLineClick && onLineClick(params);
                        }
                    }} />
            </div>
        );
    }
}
