import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

const legends = [
    { legend: '最小耗时', field: 'minDuration' },
    { legend: '平均耗时', field: 'avgDuration' },
    { legend: '最大耗时', field: 'maxDuration' }
];
export default class App extends Component {
    render() {
        const {
            proportion,
            currentSeriesName
        } = this.props;

        const currentLegends = legends.find(item => item.legend === currentSeriesName);

        const proportionArr = Object.keys(proportion);

        const series = proportionArr.map((item, index) => {
            return {
                name: item,
                type: 'bar',
                stack: '总量',
                data: [proportion[item].minDuration, proportion[item].avgDuration, proportion[item].maxDuration]
            };
        });

        const options = {
            tooltip: [{
                trigger: 'axis'
            }],
            grid: [{
                top: 50,
                width: '50%'
            }],
            toolbox: {
                show: true,
                feature: {
                    saveAsImage: {}
                }
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            title: [{
                text: '耗时堆叠图',
                x: '30%',
                y: 10,
                textAlign: 'center',
                textStyle: {
                    fontSize: 14
                }
            }, {
                text: `${currentSeriesName}占比`,
                x: '80%',
                y: 10,
                textAlign: 'center',
                textStyle: {
                    fontSize: 14
                }
            }],
            xAxis: [{
                type: 'category',
                splitLine: {
                    show: false
                },
                data: legends.map(item => item.legend)
            }],
            yAxis: [{
                type: 'value',
                name: '耗时',
                splitLine: {
                    show: false
                }
            }],
            series: [
                {
                    type: 'pie',
                    radius: [0, '35%'],
                    center: ['80%', '45%'],
                    data: proportionArr.map((item, index) => {
                        return {
                            name: item,
                            value: (currentLegends.field in proportion[item]) ? proportion[item][currentLegends.field] : 0
                        };
                    }),
                    tooltip: {
                        trigger: 'item',
                        formatter: '类型： {b} <br> 值： {c} ({d}%)'
                    },
                    labelLine: {
                        normal: {
                            smooth: 0.2,
                            length: 10,
                            length2: 20
                        }
                    },
                    animationType: 'scale',
                    animationEasing: 'elasticOut',
                    animationDelay: (idx) => {
                        return Math.random() * 200;
                    }
                }
            ].concat(series)
        };
        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%', marginTop: 20 }}
                />
            </div>
        );
    }
}
