import React, { Component } from 'react';
import { Form, Row, Col, Select, DatePicker, Button, Table, Modal, message } from 'antd';
import { linkTrackingService } from 'service';
import { fromJS } from 'immutable';
import moment from 'moment';
import withPermission from 'component/hoc/withPermission';
import withFormModal from 'component/hoc/withFormModal';
import { getQueryString, isNotEmptyObject } from 'js/util';
import DetailDrawer from './detailDrawer';
import MessageForm from './messageForm';
import FaultModal from '../faultList/faultModal';

const { confirm } = Modal;
const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { Option } = Select;
const MessageFormModal = withFormModal(MessageForm);

class MonitorMessage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            groupList: [],
            pointList: [],
            viewRecord: null,
            viewVisible: false,
            closable: true,
            visible: false,
            currentRecord: null,
            selectedRowKeys: [],
            messageTypeList: [],
            messageVisible: false,
            messageConfirmLoading: false
        };
        this.columns = [{
            title: '监控组',
            dataIndex: 'group',
            key: 'group'
        }, {
            title: '监控点',
            dataIndex: 'endpoint',
            key: 'endpoint',
        }, {
            title: '标题',
            dataIndex: 'title',
            key: 'title',
            width: '435px'
        }, {
            title: '级别',
            dataIndex: 'level',
            key: 'level'
        }, {
            title: '时间',
            dataIndex: 'alarmTime',
            key: 'alarmTime'
        }, {
            title: '状态',
            dataIndex: 'statusStr',
            key: 'statusStr',
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (text, record) => {
                return (
                    <React.Fragment>
                        {
                            withPermission(<Button type="primary" style={{ marginRight: 10 }} onClick={this.openDrawer.bind(this, record)}>详情</Button>, 'PermissionMonitorMessageDetail')
                        }
                        {
                            withPermission(<Button type="primary" onClick={this.addFault.bind(this, record)}>录入故障</Button>, 'PermissionMonitorMessageAddFault')
                        }
                    </React.Fragment>
                );
            }
        }];
    }
    componentDidMount() {
        // url有带Id
        (async () => {
            const result = getQueryString();
            if (isNotEmptyObject(result) && result.id) {
                const record = await this.getMessageDetail(result);
                if (record) {
                    this.setState({
                        closable: false,
                        viewVisible: true,
                        viewRecord: fromJS(record)
                    });
                } else {
                    message.error('告警消息Id有错');
                }
            }
        })();
        this.getMessageTypeList();
        this.getMonitorGroupList();
        this.getMessages();
    }
    // 获取消息类型
    getMessageTypeList = async () => {
        const { entry, code } = await linkTrackingService.getMessageTypeList();
        if (code === '0') {
            this.setState({
                messageTypeList: entry
            });
        }
    }
    // 一键新增故障
    addFault = (record) => {
        this.setState({
            visible: true,
            currentRecord: fromJS({
                title: record.title,
                level: record.level,
                description: record.messageContent,
                dates: [moment(record.alarmTime)],
                messages: [''],
                keys: [0],
                isEdit: false
            })
        });
    }
    // 一键新增故障modal关闭
    onFaultModalClose = () => {
        this.setState({
            visible: false
        });
    }
    // 获取详情
    getMessageDetail = async ({ id }) => {
        const { code, entry } = await linkTrackingService.getMessageDetail({ id });
        if (code === '0') {
            return entry;
        }
        return null;
    }
    // 删除
    deleteMessage = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该条告警信息？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await linkTrackingService.deleteMessage({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getMessages();
                    }
                })();
            }
        });
    }
    // 获取监控组
    getMonitorGroupList = async (e) => {
        const { entry, code } = await linkTrackingService.getMonitorGroupList();
        if (code === '0') {
            this.setState({
                groupList: entry
            });
        }
    }
    // 获取监控点
    getMonitorPointList = async (groupId) => {
        const { form } = this.props;
        const { entry, code } = await linkTrackingService.getMonitorPointList({ groupId });
        if (code === '0') {
            this.setState({
                pointList: entry.list
            }, () => {
                form.setFieldsValue({ endpointIdList: [] });
            });
        }
    }
    // 监控组onChange
    changGroup= (value) => {
        this.getMonitorPointList(value);
    }
    getMessages = (e) => {
        e && e.preventDefault();
        this.props.form.validateFields(async (err, values) => {
            if (!err) {
                const {
                    endpointIdList,
                    groupId,
                    rangeTime,
                    status
                } = this.props.form.getFieldsValue();
                const { pagination } = this.state;
                this.setState({
                    loading: true
                });
                const params = {
                    ...pagination,
                    countSql: true,
                    endpointIdList,
                    groupId,
                    status
                };
                if (rangeTime && rangeTime.length > 0) {
                    params.alarmTimeBegin = +rangeTime[0];
                    params.alarmTimeEnd = +rangeTime[1];
                }
                delete params.totalCount;
                const { entry, code } = await linkTrackingService.getMessageList({ ...params });
                if (code === '0') {
                    this.setState({
                        loading: false,
                        pagination: { ...pagination, ...{ totalCount: entry.total } },
                        data: entry.list
                    });
                }
            }
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getMessages();
            });
        }
    }
    // 查看
    openDrawer = (record) => {
        this.setState({
            viewVisible: true,
            viewRecord: fromJS(record)
        });
    }
    // 抽屉回调
    onDrawerClose = () => {
        this.setState({
            viewVisible: false
        });
    }
    // 抽屉更新回调
    onHandle = (result) => {
        this.setState({
            viewRecord: result
        }, () => {
            this.getMessages();
        });
    }
    // table 可选择
    onSelectChange = (selectedRowKeys) => {
        this.setState({ selectedRowKeys });
    }
    // 打开一键处理的modal
    openHandleModal = () => {
        const { selectedRowKeys } = this.state;
        if (selectedRowKeys.length === 0) {
            return message.warning('请选择告警消息');
        }
        return this.setState({
            messageVisible: true
        });
    }
    // 一键处理save
    setMessageSend = async () => {
        this.messageFormRef.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    messageConfirmLoading: true
                });
                const params = { ...this.messageFormRef.getFieldsValue(), idList: this.state.selectedRowKeys, status: 20 };
                const res = await linkTrackingService.batchMark(params);
                if (res.code === '0') {
                    this.setState({
                        messageConfirmLoading: false,
                        messageVisible: false
                    }, () => {
                        message.success('一键处理成功');
                        this.messageFormRef.resetFields();
                        this.setState({
                            selectedRowKeys: []
                        });
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        messageConfirmLoading: false
                    });
                }
            }
        });
    }
    getMessageFormRef = (ref) => {
        this.messageFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.messageFormRef.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const {
            data,
            loading,
            groupList,
            pointList,
            pagination,
            viewVisible,
            viewRecord,
            closable,
            visible,
            currentRecord,
            selectedRowKeys,
            messageTypeList,
            messageVisible,
            messageConfirmLoading
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const { columns } = this;
        const rowSelection = {
            selectedRowKeys,
            onChange: this.onSelectChange,
        };
        return (
            <div>
                <Form onSubmit={this.getMessages} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('groupId')(<Select
                                    showSearch
                                    onChange={this.changGroup}
                                    placeholder="请选择监控组"
                                    optionFilterProp='children'
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                >
                                    <Option value="">全部</Option>
                                    {
                                        groupList.map((item, index) => {
                                            return <Option key={item.id}>{item.name}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem>
                                {getFieldDecorator('endpointIdList', {
                                    initialValue: [],
                                })(<Select
                                    showSearch
                                    mode="multiple"
                                    placeholder='请选择监控点'
                                    optionFilterProp='children'
                                    disabled={pointList.length === 0}
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                >
                                    {
                                        pointList.map((item) => {
                                            return (<Option value={item.id} key={item.id} tile={item.name}>{item.name}</Option>);
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeTime')(<RangePicker
                                    style={{ width: '100%' }}
                                    showTime
                                    format="YYYY-MM-DD HH:mm:ss"
                                    placeholder={['开始时间', '结束时间']}
                                />)}
                            </FormItem>
                        </Col>
                        <Col span={2}>
                            <FormItem>
                                {getFieldDecorator('status', {
                                    initialValue: '',
                                })(<Select>
                                    <Option value="">全部</Option>
                                    <Option value={0}>待处理</Option>
                                    <Option value={10}>处理中</Option>
                                    <Option value={20}>已处理</Option>
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={6}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: 10 }}>查询</Button>
                                <Button type="primary" onClick={this.openHandleModal}>批量处理</Button>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <DetailDrawer viewVisible={viewVisible} onClose={this.onDrawerClose} closable={closable} onHandle={this.onHandle} record={viewRecord} messageTypeList={messageTypeList}/>
                <Table
                    rowKey="id"
                    loading={loading}
                    dataSource={data}
                    columns={columns}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    rowSelection={rowSelection}
                />
                <FaultModal visible={visible} record={currentRecord} onFaultModalClose={this.onFaultModalClose} />
                <MessageFormModal
                    maskClosable={false}
                    getRef={this.getMessageFormRef}
                    title="一键处理"
                    visible={messageVisible}
                    onOk={this.setMessageSend}
                    onCancel={this.handleCancel.bind(this, 'messageVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={messageConfirmLoading} onClick={this.setMessageSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp={{
                        messageTypeList
                    }}
                />
            </div>
        );
    }
}

export default Form.create()(MonitorMessage);
