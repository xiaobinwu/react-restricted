import React, { Component } from 'react';
import { Row, Col, Drawer, Select, Input, Button, message } from 'antd';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { linkTrackingService } from 'service';

const { Option } = Select;
const { TextArea } = Input;
class DetailDrawer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            messageType: '',
            remark: ''
        };
    }
    onClose = () => {
        const { onClose } = this.props;
        this.setState({
            messageType: '',
            remark: ''
        }, () => {
            onClose && onClose();
        });
    }
    // 改变消息类型
    changeMessageType = (value) => {
        this.setState({
            messageType: value
        });
    }
    // 改变消息类型
    changeRemark = (e) => {
        this.setState({
            remark: e.target.value
        });
    }
    // 查找对应的消息类型
    findMessageType = (type) => {
        const { messageTypeList } = this.props;
        const findItem = messageTypeList.find((item) => {
            return item.code === type;
        });
        if (findItem) {
            return findItem.name;
        }
        return '';
    }
    // 处理
    hanle = (status) => {
        const {
            record,
            onHandle
        } = this.props;
        const {
            messageType,
            remark
        } = this.state;
        let params = {};
        if (status === 20) {
            params = {
                type: messageType,
                remark
            };
        }
        if (record) {
            this.logic({ status, id: record.get('id'), ...params }, (result) => {
                onHandle && onHandle(record.mergeDeep(result));
            });
        }
    }
    // 处理逻辑
    logic = async (params, callback) => {
        const { code, entry } = await linkTrackingService.updateMessage(params);
        if (code === '0') {
            message.success('处理成功');
            callback && callback(entry);
        }
    }
    render() {
        const {
            viewVisible,
            record,
            closable,
            messageTypeList
        } = this.props;
        const drawerRecord = record && record.toJS();
        const colLayout = { marginBottom: '30px' };
        return (
            <Drawer
                width="100%"
                height="100%"
                placement="top"
                closable={closable}
                maskClosable={false}
                title={drawerRecord ? drawerRecord.title : '告警详情'}
                onClose={this.onClose}
                visible={viewVisible}
            >
                {
                    drawerRecord ? <Row>
                        <Col span={12} style={colLayout}>
                            <span>监控组：</span>
                            <span>{drawerRecord.group}</span>
                        </Col>
                        <Col span={12} style={colLayout}>
                            <span>监控点：</span>
                            <span>{drawerRecord.endpoint}</span>
                        </Col>
                        <Col span={12} style={colLayout}>
                            <span>级别：</span>
                            <span>{drawerRecord.level}</span>
                        </Col>
                        <Col span={12} style={colLayout}>
                            <span>处理状态：</span>
                            <span>{drawerRecord.statusStr}</span>
                        </Col>
                        <Col span={12} style={colLayout}>
                            <span>消息时间：</span>
                            <span>{drawerRecord.alarmTime}</span>
                        </Col>
                        <Col span={12} style={colLayout}>
                            <span>处理时间：</span>
                            <span>{drawerRecord.updateTime}</span>
                        </Col>
                        <Col span={24} style={colLayout}>
                            <span>消息内容：</span>
                            <div style={{ padding: 20 }} dangerouslySetInnerHTML={{ __html: drawerRecord.messageContent }} />
                        </Col>
                        {
                            drawerRecord.status !== 0 ? <Col span={12} style={colLayout}>
                                <span>错误类型：</span>
                                <span>
                                    {
                                        drawerRecord.status === 10 ? <Select onChange={this.changeMessageType} style={{ width: 200 }}>
                                            {
                                                messageTypeList.map((item, index) => {
                                                    return (<Option key={item.code} value={item.code}>{item.name}</Option>);
                                                })
                                            }
                                        </Select> : this.findMessageType(drawerRecord.type)
                                    }
                                </span>
                            </Col> : null
                        }
                        {
                            drawerRecord.status !== 0 ? <Col span={12} style={colLayout}>
                                <span>备注：</span>
                                {
                                    drawerRecord.status === 10 ? <TextArea row={5} style={{ width: '90%', verticalAlign: 'middle' }} onChange={this.changeRemark}/> : drawerRecord.remark
                                }
                            </Col> : null
                        }
                        <Col span={12} style={colLayout}>
                            {
                                drawerRecord.status === 0 ? <Button type="primary" onClick={this.hanle.bind(this, 10)} style={{ marginRight: '10px' }}>开始处理</Button> : null
                            }
                            {
                                drawerRecord.status === 10 ? <Button type="primary" onClick={this.hanle.bind(this, 20)} style={{ marginRight: '10px' }}>完成处理</Button> : null
                            }
                            {
                                drawerRecord.ruleId ? <Link to={{ pathname: this.props.paths.MonitorRule.linkPath, search: `?ruleId=${drawerRecord.ruleId}` }} target="_blank">
                                    <Button type="primary">调整阀值</Button>
                                </Link> : null
                            }
                        </Col>
                    </Row> : null
                }
            </Drawer>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(DetailDrawer);
