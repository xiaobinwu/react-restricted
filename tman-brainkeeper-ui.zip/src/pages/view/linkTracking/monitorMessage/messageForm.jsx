import React, { Component } from 'react';
import { Form, Input, Select } from 'antd';

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;

class MessageForm extends Component {
    render() {
        const {
            form,
            messageTypeList
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        return (
            <Form>
                <FormItem label="错误类型" {...formItemLayout}>
                    {getFieldDecorator('type', {
                        initialValue: '',
                        rules: [{
                            required: true, message: '请选择消息类型',
                        }],
                    })(<Select>
                        {
                            messageTypeList.map((item, index) => {
                                return (<Option key={item.code}>{item.name}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="备注" {...formItemLayout}>
                    {getFieldDecorator('remark', {
                        initialValue: '',
                        rules: [{
                            required: true, message: '请填写备注',
                        }],
                    })(<TextArea rows={5} />)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(MessageForm);
