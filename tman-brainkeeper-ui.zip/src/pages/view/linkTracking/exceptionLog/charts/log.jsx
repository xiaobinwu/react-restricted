import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Log extends Component {
    render() {
        const {
            agg,
            histogram,
            onLineClick
        } = this.props;
        const xAxis = [];
        const data = [];
        let maxNodeNum = 0;
        histogram.forEach((item, index) => {
            xAxis.push(item.eventTime);
            data.push(item.data ? item.data.count : 0);
            if (item.data) {
                if (maxNodeNum <= item.data.count) {
                    maxNodeNum = item.data.count;
                }
            }
        });
        const options = {
            tooltip: [{
                trigger: 'axis'
            }],
            grid: [{
                top: 50,
                width: '50%'
            }],
            visualMap: {
                min: 0,
                max: maxNodeNum,
                dimension: 1,
                orient: 'vertical',
                show: false,
                inRange: {
                    color: ['#4baf4f', '#cc3333']
                }
            },
            toolbox: {
                show: true,
                feature: {
                    saveAsImage: {}
                }
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            legend: {
                orient: 'vertical',
                right: 10,
                top: 20,
                bottom: 20,
                data: agg.map((item, index) => {
                    return item.ip;
                }),
            },
            title: [{
                text: '异常趋势',
                x: '30%',
                y: 10,
                textAlign: 'center',
                textStyle: {
                    fontSize: 14
                }
            }, {
                text: '异常分布',
                x: '80%',
                y: 10,
                textAlign: 'center',
                textStyle: {
                    fontSize: 14
                }
            }],
            xAxis: [{
                type: 'category',
                splitLine: {
                    show: false
                },
                data: xAxis
            }],
            yAxis: [{
                type: 'value',
                splitLine: {
                    show: false
                }
            }],
            series: [{
                type: 'scatter',
                symbolSize: (val) => {
                    return val ? 10 : 0;
                },
                label: {
                    normal: {
                        show: false
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: '点击查看详情<br>{b}<br>{c}'
                },
                data
            }, {
                type: 'pie',
                radius: [0, '35%'],
                center: ['80%', '45%'],
                data: agg.map((item, index) => {
                    return {
                        name: item.ip,
                        value: item.num,
                        visualMap: false
                    };
                }),
                tooltip: {
                    trigger: 'item',
                    formatter: 'IP： {b} <br> 值： {c} ({d}%)'
                },
                labelLine: {
                    normal: {
                        smooth: 0.2,
                        length: 10,
                        length2: 20
                    }
                },
                animationType: 'scale',
                animationEasing: 'elasticOut',
                animationDelay: (idx) => {
                    return Math.random() * 200;
                }
            }]
        };
        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%' }}
                    onEvents={{
                        click: (params) => {
                            onLineClick && onLineClick(params);
                        }
                    }} />
            </div>
        );
    }
}
