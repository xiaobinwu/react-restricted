import React, { Component } from 'react';
import QueryForm from 'component/queryForm';
import { Table, Spin, Modal, Tabs, Row, Col } from 'antd';
import moment from 'moment';
import { linkTrackingService } from 'service';
import { getQueryString, isNotEmptyObject } from 'js/util';
import Log from './charts/log';

const { TabPane } = Tabs;

class ExceptionLog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            expandedRowKeys: [],
            rowLoading: false,
            visible: false,
            agg: [],
            histogram: [],
            currentExceptionName: '',
            logDetails: [],
            logLoading: false
        };
        this.columns = [{
            title: '应用名',
            dataIndex: 'appName',
            key: 'appName'
        }, {
            title: '异常名称',
            dataIndex: 'exceptionName',
            key: 'exceptionName'
        }, {
            title: '总数',
            dataIndex: 'totalNum',
            key: 'totalNum'
        }];
        this.rangeTimeInitialValue = [moment().subtract(1, 'days'), moment()];
    }
    componentDidMount() {
        this.initDefaultData();
    }
    // 初始化数据
    initDefaultData = () => {
        const result = getQueryString();
        if (isNotEmptyObject(result)) {
            let filterResult = result;
            if (result.startEventTime && result.endEventTime) {
                filterResult = { ...result, rangeTime: [moment(result.startEventTime), moment(result.endEventTime)] };
                delete filterResult.startEventTime;
                delete filterResult.endEventTime;
            }
            // tip：不要setFieldsValue不存在的值
            // 常见错误：You cannot set a form field before rendering a field associated with the value.
            this.exceptionLogRef.props.form.setFieldsValue(filterResult);
        }
        this.getExceptionLogList();
    }
    // 获取列表数据
    getExceptionLogList = async (e) => {
        e && e.preventDefault();
        this.setState({
            loading: true
        });
        const params = { ...this.exceptionLogRef.props.form.getFieldsValue() };
        if (params.rangeTime && params.rangeTime.length > 0) {
            const { rangeTime } = params;
            params.metricEndTimeBegin = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
            params.metricEndTimeEnd = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
        }
        delete params.rangeTime;
        const { entry, code } = await linkTrackingService.getExceptionList(params);
        entry && entry.forEach((item, index) => {
            item.key = index;
        });
        if (code === '0') {
            this.setState({
                loading: false,
                expandedRowKeys: [],
                data: entry
            });
        }
    }
    // 展开逻辑
    onExpandedRowsChange = async (expandedRows) => {
        const lastExpandedRows = expandedRows.pop();
        const { data } = this.state;
        if (data[lastExpandedRows]) {
            const { rangeTime, appName } = this.exceptionLogRef.props.form.getFieldsValue();
            const params = {
                col2: appName,
                col3: data[lastExpandedRows].exceptionName,
                metricName: 'log.exception.metric',
                interval: '1m'
            };
            if (rangeTime && rangeTime.length > 0) {
                params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
            }
            this.setState({
                expandedRowKeys: [lastExpandedRows],
                currentExceptionName: data[lastExpandedRows].exceptionName,
                rowLoading: true
            });
            const { code, entry } = await linkTrackingService.getExceptionDetail({ ...params });
            if (code === '0') {
                const { agg, histogram } = entry;
                this.setState({
                    agg,
                    histogram,
                    rowLoading: false
                });
            }
        } else {
            this.setState({
                expandedRowKeys: [],
                rowLoading: false
            });
        }
    }
    // 折线图点击事件
    onLineClick = async (params) => {
        if (params.componentSubType === 'scatter') {
            this.setState({
                visible: true,
                logLoading: true
            });
            const { currentExceptionName } = this.state;
            const { appName } = this.exceptionLogRef.props.form.getFieldsValue();
            const { code, entry } = await linkTrackingService.getExceptionLog({
                appName,
                exceptionName: currentExceptionName,
                startDate: moment(params.name).subtract(60, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                endDate: params.name
            });
            if (code === '0') {
                this.setState({
                    logDetails: entry,
                    logLoading: false
                });
            }
        }
    }
    render() {
        const {
            loading,
            data,
            expandedRowKeys,
            rowLoading,
            agg,
            histogram,
            visible,
            logDetails,
            currentExceptionName,
            logLoading
        } = this.state;
        const { columns, rangeTimeInitialValue } = this;
        const baseFormItemsSetting = {
            app: {
                id: 'appName',
                span: 4,
                options: {
                    rules: [{
                        required: true,
                        message: '应用必选'
                    }]
                }
            },
            rangeTime: {
                span: 7,
                options: {
                    initialValue: rangeTimeInitialValue,
                    rules: [{
                        required: true,
                        message: '时间必选'
                    }]
                }
            },
            button: {
                span: 13
            }
        };
        const layout = { marginBottom: 40 };
        return (
            <div>
                <QueryForm wrappedComponentRef={(ref) => { this.exceptionLogRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} onSubmit={this.getExceptionLogList} />
                <Table
                    loading={loading}
                    dataSource={data}
                    pagination={false}
                    columns={columns}
                    expandedRowRender={(record) => {
                        return (<div>
                            <Spin spinning={rowLoading}>
                                <Log agg={agg} histogram={histogram} onLineClick={this.onLineClick} />
                            </Spin>
                        </div>);
                    }}
                    expandedRowKeys={expandedRowKeys}
                    onExpandedRowsChange={this.onExpandedRowsChange}
                />
                <Modal
                    title="日志详情"
                    visible={visible}
                    maskClosable={false}
                    width={1000}
                    footer={null}
                    onCancel={() => {
                        this.setState({
                            visible: false,
                        });
                    }}
                    style={{ paddingTop: 20 }}
                >
                    <Spin spinning={logLoading}>
                        <Tabs
                            defaultActiveKey="0"
                        >
                            {
                                logDetails.map((item, index) => {
                                    return (<TabPane tab={index} key={index}>
                                        <Row>
                                            <Col span={8} style={layout}>
                                                <Row>
                                                    <Col span={8}><strong>AppName:</strong></Col>
                                                    <Col span={16}>{item._domain}</Col>
                                                </Row>
                                            </Col>
                                            <Col span={8} style={layout}>
                                                <Row>
                                                    <Col span={8}><strong>IP:</strong></Col>
                                                    <Col span={16}>{item._ip}</Col>
                                                </Row>
                                            </Col>
                                            <Col span={8} style={layout}>
                                                <Row>
                                                    <Col span={8}><strong>Time:</strong></Col>
                                                    <Col span={16}>{item._time}</Col>
                                                </Row>
                                            </Col>
                                            <Col span={10} style={layout}>
                                                <Row>
                                                    <Col span={8}><strong>ExceptionName:</strong></Col>
                                                    <Col span={16}>{currentExceptionName}</Col>
                                                </Row>
                                            </Col>
                                            <Col span={14} style={layout}>
                                                <Row>
                                                    <Col span={4}><strong>LogFile:</strong></Col>
                                                    <Col span={20}>{item._fileName}</Col>
                                                </Row>
                                            </Col>
                                            <Col span={24}>
                                                <strong>Detail: &nbsp;</strong>
                                                { item._log }
                                            </Col>
                                        </Row>
                                    </TabPane>);
                                })
                            }
                        </Tabs>
                    </Spin>
                </Modal>
            </div>
        );
    }
}

export default ExceptionLog;
