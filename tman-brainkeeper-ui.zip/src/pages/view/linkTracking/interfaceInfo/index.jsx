import React, { Component } from 'react';
import { Tabs } from 'antd';
import JadeLine from './jadeLine';
import HistoryCompare from './historyCompare';

const { TabPane } = Tabs;

class InterfaceInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeKey: '1'
        };
        this.jadeLineRef = React.createRef();
        this.historyCompareRef = React.createRef();
    }
    onChange = (activeKey) => {
        this.setState({
            activeKey
        }, () => {
            // 切换tab从新查询数据
            if (this.state.activeKey === '1') {
                this.jadeLineRef.initDefaultData();
            } else {
                this.historyCompareRef.initDefaultData();
            }
        });
    }
    render() {
        const { activeKey } = this.state;
        return (
            <div>
                <Tabs activeKey={activeKey} onChange={this.onChange}>
                    <TabPane tab="流量指标" key="1">
                        <JadeLine getInstance={(ref) => { this.jadeLineRef = ref; }} activeKey={activeKey} />
                    </TabPane>
                    <TabPane tab="历史对比" key="2">
                        <HistoryCompare getInstance={(ref) => { this.historyCompareRef = ref; }} activeKey={activeKey} />
                    </TabPane>
                </Tabs>
            </div>
        );
    }
}

export default InterfaceInfo;
