import React, { Component } from 'react';
import { Form, Input, Button, message, Icon } from 'antd';
import { userService } from 'service';

const FormItem = Form.Item;


class VerifyForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isClick: false,
            time: 60,
            injectForm: {
                emailCode: '',
                googleCode: ''
            },
            loading: false
        };
    }
    componentWillUnmount() {
        clearInterval(this.timerID);
    }
    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    loading: true
                });
                const { googleAuthSwitch, googleAuthStatusChange } = this.props;
                const { code } = await userService.googleAuthSwitch({
                    enabled: !googleAuthSwitch,
                    ...values
                });
                if (code === '0') {
                    googleAuthStatusChange && googleAuthStatusChange(!googleAuthSwitch);
                }
                this.setState({
                    loading: false
                });
            }
        });
    }
    sendEmailCode = async () => {
        const { code } = await userService.emailSend();
        if (code === '0') {
            this.setState({
                isClick: true
            }, () => {
                message.success('验证码已发送至您的邮箱，请查收');
                this.timerID = setInterval(
                    () => this.tick(),
                    1000
                );
            });
        }
    }
    tick = () => {
        const { time } = this.state;
        if (time === 0) {
            clearInterval(this.timerID);
            this.setState({
                isClick: false,
                time: 60
            });
        }
        this.setState(prevState => ({
            time: prevState.time - 1
        }));
    }
    render() {
        const {
            form,
            googleAuthSwitch
        } = this.props;
        const {
            injectForm,
            isClick,
            time,
            loading
        } = this.state;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            }
        };
        const tailFormItemLayout = {
            wrapperCol: {
                sm: {
                    span: 21,
                    offset: 3,
                },
            },
        };
        const addonAfter = <React.Fragment>
            {
                !isClick ? <a href="javascript:;;" onClick={this.sendEmailCode}>发送验证码</a> : <span>{time}秒后重发</span>
            }
        </React.Fragment>;
        return (
            <Form onSubmit={this.handleSubmit}>
                {
                    googleAuthSwitch ? <FormItem label="" {...tailFormItemLayout} className="system-auth-tip">
                        <Icon type="check-circle" theme="twoTone" twoToneColor="#52c41a" style={{ marginRight: '10px' }}/>您的账户已启用谷歌验证
                    </FormItem> : null
                }
                <FormItem label="邮箱验证码" {...formItemLayout}>
                    {getFieldDecorator('emailCode', {
                        initialValue: injectForm.emailCode,
                        rules: [{
                            required: true, message: '邮箱验证码不为空',
                        }],
                    })(<Input style={{ width: '300px' }} addonAfter={addonAfter}/>)}
                </FormItem>
                <FormItem label="双重验证码" {...formItemLayout}>
                    {getFieldDecorator('googleCode', {
                        initialValue: injectForm.googleCode,
                        rules: [{
                            required: true, message: '双重验证码不为空',
                        }],
                    })(<Input style={{ width: '300px' }} />)}
                </FormItem>
                <Form.Item {...tailFormItemLayout}>
                    <Button type="primary" htmlType="submit" style={{ width: '300px' }} loading={loading}>
                        {googleAuthSwitch ? '验证并关闭' : '验证并启用'}
                    </Button>
                </Form.Item>
            </Form>
        );
    }
}

export default Form.create()(VerifyForm);
