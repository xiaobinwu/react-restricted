import React, { Component } from 'react';
import { userService } from 'service';
import { Divider } from 'antd';
import VerifyForm from './verifyForm';
import styles from './index.css';

class GoogleVerification extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            googleAuthSwitch: false,
            googleSecretKey: '',
            qrUrl: '',
            isActive: false
        };
    }
    componentDidMount() {
        this.getGoogleAuthInfo();
    }
    getGoogleAuthInfo = async () => {
        this.setState({
            loading: true
        });
        const { code, entry } = await userService.getGoogleauthInfo();
        if (code === '0') {
            const { googleAuthSwitch, googleSecretKey, qrUrl } = entry;
            this.setState({
                googleAuthSwitch,
                googleSecretKey,
                qrUrl,
                loading: false,
                isActive: true
            });
        }
    }
    googleAuthStatusChange = (googleAuthSwitch) => {
        this.setState({
            googleAuthSwitch
        });
    }
    render() {
        const {
            googleAuthSwitch,
            googleSecretKey,
            qrUrl,
            isActive
        } = this.state;
        let className = styles.menu;
        if (isActive) {
            className += ` ${styles.menuActive}`;
        }
        return (
            <div className={className}>
                {
                    googleAuthSwitch ? <div>
                        <VerifyForm googleAuthSwitch={googleAuthSwitch} googleAuthStatusChange={this.googleAuthStatusChange} />
                    </div> : <div>
                        <p>Google Authenticator 双重验证可以更安全的保护您的账户。若您未开启谷歌双重验证，您在公网（公司办公网络之外的任何网络）进行登录时，将无法使用用户名密码方式登录。用户名密码登录可以使您方便的在任何安装有浏览器的网络设备上（电脑、手机）进行登录，而无需连接公司的VPN服务 。您可以依照下面的步骤来设置并启用这一功能。</p>
                        <p>步骤一、在您的手机上安装双重验证程序：Google Authenticator</p>
                        <p>iPhone手机：在App Store 中搜索 Google Authenticator</p>
                        <p><a href="http://itunes.apple.com/cn/app/google-authenticator/id388497605?mt=8" target="_blank">点此查看</a></p>
                        <p>其他手机：在各大应用市场钟搜索下载“谷歌身份验证器”，或搜索Google Authenticator</p>
                        <Divider className="system-colony-divider-color" />
                        <p>步骤二、安装完成后，您需要对该应用程序进行如下配置</p>
                        <p>在“Google Authenticator (身份验证器)”应用程序中，点击“添加新账户 (iOS 下是 + 号)”，然后选择“扫描条形码”。将手机上的相机镜头对准下图扫描该条形码。</p>
                        <img src={qrUrl}/>
                        <p>如果您无法扫描成功上图的条形码，您还可以手动添加账户，并输入如下密匙：<span className="system-colony-notice-color">{googleSecretKey}</span></p>
                        <p>配置完成后，手机上会显示一个 6 位数字，每隔 30 秒变化一次。这个数字即为您的双重验证密码。</p>

                        <p className="system-colony-caution-color">请勿删除此双重验证密码账户，否则会导致您无法进行账户操作</p>
                        <p className="system-colony-caution-color">您可将密钥记录下来: {googleSecretKey} 如果误删，可通过手动输入密钥来恢复。</p>

                        <p>如果您开启了谷歌双重验证确丢失了秘钥，导致无法通过用户名密码登录，请及时联系管理员处理。</p>

                        <Divider className="system-colony-divider-color" />
                        <p>步骤三、输入邮箱验证码，及谷歌双重验证码，以开启或关闭双重验证功能</p>
                        <VerifyForm googleAuthSwitch={googleAuthSwitch} googleAuthStatusChange={this.googleAuthStatusChange} />
                    </div>
                }
            </div>
        );
    }
}

export default GoogleVerification;
