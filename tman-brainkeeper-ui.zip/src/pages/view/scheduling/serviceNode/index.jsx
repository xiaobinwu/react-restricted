import React, { Component } from 'react';
import { schedulingService } from 'service';
import { Row, Col, Card, Tag } from 'antd';
import Pie from './charts/pie';
import styles from './index.css';

class ServiceNode extends Component {
    constructor(props) {
        super(props);
        this.state = {
            nodesList: []
        };
    }
    componentDidMount() {
        this.getNodesList();
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    getNodesList = async () => {
        this.clearTimer();
        const { code, entry } = await schedulingService.getNodesList();
        if (entry) {
            const entryArr = [];
            entry && entry.forEach((item) => {
                entryArr.push(`${item.host}_${item.port}`);
            });
            if (code === '0') {
                this.setState({
                    nodesList: entry
                });
            }
        }
        this.timer = setTimeout(() => { this.getNodesList(); }, 2000);
    }
    render() {
        const {
            nodesList
        } = this.state;
        return (
            <Row gutter={16}>
                {
                    nodesList.map((item, index) => {
                        const span = 12;
                        const layout = { marginBottom: '10px' };
                        const heapMemoryUsageUsed = (item.heapMemoryUsage.used > 0 ? item.heapMemoryUsage.used / 1024 / 1024 : 0).toFixed(2);
                        const nonHeapMemoryUsageUsed = (item.nonHeapMemoryUsage.used > 0 ? item.nonHeapMemoryUsage.used / 1024 / 1024 : 0).toFixed(2);
                        const heapMemoryUsageAll = (item.heapMemoryUsage.max > 0 ? item.heapMemoryUsage.max / 1024 / 1024 : 0).toFixed(2);
                        const nonHeapMemoryUsageAll = (item.nonHeapMemoryUsage.max > 0 ? item.nonHeapMemoryUsage.max / 1024 / 1024 : 0).toFixed(2);
                        const noUsed = (parseFloat(heapMemoryUsageAll) + parseFloat(nonHeapMemoryUsageAll)) - (parseFloat(heapMemoryUsageUsed) + parseFloat(nonHeapMemoryUsageUsed));
                        const series1 = [
                            { value: heapMemoryUsageUsed, name: '堆已使用' },
                            { value: nonHeapMemoryUsageUsed, name: '非堆已使用' },
                            { value: noUsed, name: '可使用' }
                        ];
                        const series2 = [
                            { value: item.errorTasksSize, name: '错误任务数' },
                            { value: item.withinTasksSize, name: '内存任务数' }
                        ];
                        return (<Col span={span} key={index} >
                            <Card title={item.host && item.port ? `${item.host}-${item.port}` : null} className={styles.card}>
                                <Row gutter={20} style={{ marginBottom: 20 }}>
                                    <Col span={12} style={layout}>
                                        <span>当前状态：</span>
                                        <span>{item.status}</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>错误任务数：</span>
                                        <span>{item.errorTasksSize}</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>是否为主节点：</span>
                                        {
                                            item.isMaster ? <Tag className='system-online-detail-tag' style={{ display: 'inline' }}>是</Tag>
                                                : <Tag className='system-online-detail-error-tag' style={{ display: 'inline' }}>否</Tag>
                                        }
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>内存任务数：</span>
                                        <span>{item.withinTasksSize}</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>堆总大小：</span>
                                        <span>{heapMemoryUsageAll} MB</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>非堆总大小：</span>
                                        <span>{nonHeapMemoryUsageAll} MB</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>堆初始大小：</span>
                                        <span>{(item.heapMemoryUsage.init > 0 ? item.heapMemoryUsage.init / 1024 / 1024 : 0).toFixed(2)} MB</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>非堆初始大小：</span>
                                        <span>{(item.nonHeapMemoryUsage.init > 0 ? item.nonHeapMemoryUsage.init / 1024 / 1024 : 0).toFixed(2)} MB</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>堆已使用大小：</span>
                                        <span>{heapMemoryUsageUsed} MB</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>非堆已使用大小：</span>
                                        <span>{nonHeapMemoryUsageUsed} MB</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>堆已提交大小：</span>
                                        <span>{(item.heapMemoryUsage.committed > 0 ? item.heapMemoryUsage.committed / 1024 / 1024 : 0).toFixed(2)} MB</span>
                                    </Col>
                                    <Col span={12} style={layout}>
                                        <span>非堆已提交大小：</span>
                                        <span>{(item.nonHeapMemoryUsage.committed > 0 ? item.nonHeapMemoryUsage.committed / 1024 / 1024 : 0).toFixed(2)} MB</span>
                                    </Col>
                                </Row>
                                <Row gutter={20}>
                                    <Col span={12}>
                                        <Pie series={series1} name="堆占用情况" legend={['堆已使用', '非堆已使用', '可使用']}/>
                                    </Col>
                                    <Col span={12}>
                                        <Pie series={series2} name="任务数占比" legend={['错误任务数', '内存任务数']}/>
                                    </Col>
                                </Row>
                            </Card>
                        </Col>);
                    })
                }
            </Row>
        );
    }
}

export default ServiceNode;
