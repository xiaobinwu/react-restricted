import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Pie extends Component {
    render() {
        const {
            series,
            name,
            legend
        } = this.props;
        const options = {
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b} : {c} ({d}%)',
            },
            legend: {
                left: 'center',
                data: legend
            },
            series: [
                {
                    name,
                    type: 'pie',
                    radius: '55%',
                    center: ['50%', '60%'],
                    data: series,
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 264, width: '100%' }}
                    onChartReady={this.chartReady}/>
            </div>
        );
    }
}
