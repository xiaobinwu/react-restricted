import React, { Component } from 'react';
import { schedulingService } from 'service';
import { Row, Col, Button, Table, Select, message, Input } from 'antd';
import moment from 'moment';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import TaskQueueForm from './taskQueueForm';

const { Option } = Select;

// 添加/修改任务
const TaskQueueFormModal = withFormModal(TaskQueueForm);

const defaultTaskFormOptions = {
    queue: '',
    executeTime: '',
    data: '',
    taskId: ''
};

class TaskQueue extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            serverKey: '',
            currentServerKey: '',
            taskQueueServerKeys: [],
            taskForm: deepCopy(defaultTaskFormOptions),
            taskVisible: false,
            taskConfirmLoading: false,
            searchTaskId: ''
        };
    }
    componentDidMount() {
        this.setState({
            loading: true
        });
        this.getTaskQueueServerKeys();
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 获取ServerKeys列表
    getTaskQueueServerKeys = async () => {
        const { code, entry } = await schedulingService.getNodesList();
        if (code === '0') {
            const entryArr = [];
            let serverKey = '';
            entry && entry.forEach((item) => {
                if (item.isMaster) {
                    serverKey = `${item.host}_${item.port}`;
                }
                entryArr.push(`${item.host}_${item.port}`);
            });
            this.setState({
                taskQueueServerKeys: entryArr,
                serverKey
            }, () => {
                this.getTaskQueueList();
            });
        }
    }
    // 获取列表
    getTaskQueueList = async (e) => {
        e && e.preventDefault();
        const {
            pagination,
            serverKey
        } = this.state;
        const params = { ...pagination, serverKey };
        delete params.totalCount;
        this.clearTimer();
        const { entry, code } = await schedulingService.getTaskQueueList(params);
        entry && entry.list && entry.list.forEach((item, index) => {
            item.key = index;
            item.lastClientSendTimeStr = moment(item.lastClientSendTime).format('YYYY-MM-DD HH:mm:ss');
            item.lastDeliveryToClientTimeStr = moment(item.lastDeliveryToClientTime).format('YYYY-MM-DD HH:mm:ss');
            item.outboundMeanRate = item.outboundMeanRate.toFixed(2);
            item.inboundMeanRate = item.inboundMeanRate.toFixed(2);
            item.inboundOneMinuteRate = item.inboundOneMinuteRate.toFixed(2);
            item.inboundFiveMinuteRate = item.inboundFiveMinuteRate.toFixed(2);
            item.outboundOneMinuteRate = item.outboundOneMinuteRate.toFixed(2);
            item.outboundFiveMinuteRate = item.outboundFiveMinuteRate.toFixed(2);
        });
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list || []
            });
        }
        this.timer = setTimeout(() => { this.getTaskQueueList(); }, 2000);
    }
    // 填写serverKey
    changeServerKey = (value) => {
        this.setState({
            serverKey: value
        });
    }
    // 填写查询的Id
    changeTaskId = (e) => {
        this.setState({
            searchTaskId: e.target.value.replace(/(^\s*)|(\s*$)/g, '')
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getTaskQueueList();
            });
        }
    }
    // 打开新增、查看Modal
    setQueueTask = (record) => {
        let taskFormObj = {};
        if (record) {
            taskFormObj = {
                queue: record.queue,
                executeTime: moment(record.executeTime),
                data: record.data,
                taskId: record.taskId
            };
        } else {
            taskFormObj = deepCopy(defaultTaskFormOptions);
        }
        this.setState({
            taskForm: taskFormObj,
            taskVisible: true
        });
    }
    setQueueTaskSend = async () => {
        const { serverKey } = this.state;
        this.setState({
            taskConfirmLoading: true
        });
        const params = { ...this.taskFormRef.props.form.getFieldsValue(), methodType: this.state.taskForm.taskId ? 'delete' : 'add', serverKey };
        const res = await schedulingService.setQueueTaskSend(params);
        if (res.code === '0') {
            this.setState({
                taskConfirmLoading: false,
                taskVisible: false
            }, () => {
                message.success(res.entry);
                this.taskFormRef.props.form.resetFields();
            });
        } else {
            this.setState({
                taskConfirmLoading: false
            });
        }
    }
    // 获取任务详情
    getTaskDetail = async (e) => {
        e && e.preventDefault();
        const {
            searchTaskId,
            serverKey
        } = this.state;
        if (!searchTaskId) {
            return message.error('查询Id不能为空');
        }
        const res = await schedulingService.getTaskDetail({ serverKey, taskId: searchTaskId });
        if (res.code === '0' && res.entry) {
            return this.setQueueTask(res.entry);
        }
        return message.error('查询结果错误');
    }
    // 获取目标管理任务ref
    getTaskFormRef = (ref) => {
        this.taskFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.taskFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            taskQueueServerKeys,
            serverKey,
            taskForm,
            taskVisible,
            taskConfirmLoading,
            searchTaskId
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '队列名称',
            dataIndex: 'queue',
            key: 'queue',
            width: 200,
            fixed: 'left'
        }, {
            title: '最后创建任务时间',
            dataIndex: 'lastClientSendTimeStr',
            key: 'lastClientSendTimeStr',
            width: 200
        }, {
            title: '最后回调任务时间',
            dataIndex: 'lastDeliveryToClientTimeStr',
            key: 'lastDeliveryToClientTimeStr',
            width: 200
        }, {
            title: '任务创建数',
            dataIndex: 'inboundCount',
            key: 'inboundCount',
            width: 150
        }, {
            title: '恢复任务数',
            dataIndex: 'recoverCount',
            key: 'recoverCount',
            width: 150
        }, {
            title: '任务回调数',
            dataIndex: 'outboundCount',
            key: 'outboundCount',
            width: 150
        }, {
            title: '任务回调tps',
            dataIndex: 'outboundMeanRate',
            key: 'outboundMeanRate',
            width: 150
        }, {
            title: '创建任务tps',
            dataIndex: 'inboundMeanRate',
            key: 'inboundMeanRate',
            width: 150
        }, {
            title: '创建任务1分钟tps',
            dataIndex: 'inboundOneMinuteRate',
            key: 'inboundOneMinuteRate',
            width: 200
        }, {
            title: '创建任务5分钟tps',
            dataIndex: 'inboundFiveMinuteRate',
            key: 'inboundFiveMinuteRate',
            width: 200
        }, {
            title: '任务回调1分钟tps',
            dataIndex: 'outboundOneMinuteRate',
            key: 'outboundOneMinuteRate',
            width: 200
        }, {
            title: '任务回调5分钟tps',
            dataIndex: 'outboundFiveMinuteRate',
            key: 'outboundFiveMinuteRate',
            width: 200
        }];
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 30 }}>
                    <Col span={5}>
                        <Select onChange={this.changeServerKey} placeholder="请选择serverKey" style={{ width: '100%' }} value={serverKey}>
                            {
                                taskQueueServerKeys.map((item, index) => {
                                    return (<Option key={item} value={item}>{item}</Option>);
                                })
                            }
                        </Select>
                    </Col>
                    <Col span={5}>
                        <Button icon="search" type="primary" onClick={this.getTaskQueueList} style={{ marginRight: 20 }}>查询</Button>
                    </Col>
                    <Col span={8} offset={6}>
                        <Row>
                            <Col span={12}>
                                <Input placeholder="任务Id" value={searchTaskId} onChange={this.changeTaskId} style={{ width: '100%' }}/>
                            </Col>
                            <Col span={10} offset={2}>
                                {
                                    withPermission(<Button type="primary" onClick={this.getTaskDetail} style={{ marginRight: 20 }}>查询任务</Button>, 'PermissionTaskQueueLook')
                                }
                                {
                                    withPermission(<Button type="primary" onClick={this.setQueueTask}>新增任务</Button>, 'PermissionTaskQueueAdd')
                                }
                            </Col>
                        </Row>
                    </Col>
                </Row>
                <Table
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    scroll={{ x: 2000 }}
                />
                <TaskQueueFormModal
                    maskClosable={false}
                    injectForm={taskForm}
                    getRef={this.getTaskFormRef}
                    title="任务添加/查看"
                    visible={taskVisible}
                    onOk={this.setQueueTaskSend}
                    onCancel={this.handleCancel.bind(this, 'taskVisible')}
                    footer={[
                        <Button key="submit" type='primary' loading={taskConfirmLoading} onClick={this.setQueueTaskSend}>
                            { taskForm.taskId ? '删除' : '保存' }
                        </Button>
                    ]}
                    wrappedProp= {{
                        data: data.map((item) => {
                            return item.queue;
                        }),
                        methodType: taskForm.taskId ? 'delete' : 'add'
                    }}
                />
            </div>
        );
    }
}

export default TaskQueue;
