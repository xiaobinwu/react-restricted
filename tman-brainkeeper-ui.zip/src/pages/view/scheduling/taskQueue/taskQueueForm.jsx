import React, { Component } from 'react';
import { Form, Input, DatePicker, AutoComplete } from 'antd';

const FormItem = Form.Item;
const AutoCompleteOption = AutoComplete.Option;
const { TextArea } = Input;

class TaskTargetForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            autoCompleteResult: this.props.data || []
        };
    }
    // autoComplete，自动搜索
    handleSearch = (value) => {
        let autoCompleteResult;
        if (!value) {
            autoCompleteResult = [];
        } else {
            autoCompleteResult = this.props.data.filter((item) => {
                return item.split(value).length > 1;
            });
        }
        this.setState({ autoCompleteResult });
    }
    render() {
        const {
            form,
            injectForm,
            methodType
        } = this.props;
        const { autoCompleteResult } = this.state;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        const dataOptions = autoCompleteResult.map((item, index) => {
            return <AutoCompleteOption key={index}>{item}</AutoCompleteOption>;
        });
        return (
            <Form>
                <FormItem label="发送队列" {...formItemLayout}>
                    {getFieldDecorator('queue', {
                        initialValue: injectForm.queue,
                    })(<AutoComplete dataSource={dataOptions} onSearch={this.handleSearch}>
                        <Input />
                    </AutoComplete>)}
                </FormItem>
                <FormItem label="任务Id" {...formItemLayout}>
                    {getFieldDecorator('taskId', {
                        initialValue: injectForm.taskId,
                    })(<Input disabled={methodType === 'delete'} />)}
                </FormItem>
                <FormItem label="任务数据" {...formItemLayout}>
                    {getFieldDecorator('data', {
                        initialValue: injectForm.data,
                    })(<TextArea disabled={methodType === 'delete'} row={4} />)}
                </FormItem>
                <FormItem label="执行时间" {...formItemLayout}>
                    {getFieldDecorator('executeTime', {
                        initialValue: injectForm.executeTime,
                    })(<DatePicker placeholder="请选择执行时间" disabled={methodType === 'delete'} style={{ width: '100%' }} showTime format="YYYY-MM-DD HH:mm:ss" />)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(TaskTargetForm);
