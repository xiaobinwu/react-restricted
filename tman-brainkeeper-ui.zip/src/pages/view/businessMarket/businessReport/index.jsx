import React, { Component } from 'react';
import { Switch, Select, Row, Col, message, Spin, Carousel } from 'antd';
import { connect } from 'react-redux';
import moment from 'moment';
import { fromJS } from 'immutable';
import { businessMarketService, linkTrackingService } from 'service';
import QueryForm from 'component/queryForm';
import { Link } from 'react-router-dom';
import Report from './charts/report';

const { Option } = Select;

class BusinessReport extends Component {
    constructor(props) {
        super(props);
        this.carouselRef = React.createRef();
        this.state = {
            datePickerDisabled: true,
            chartOptions: [],
            serviceList: [],
            detail: [],
            layout: 8,
            loading: false,
            currentCarousel: 0,
            closeAutoCarousel: false
        };
        this.options = [
            {
                text: 'OFF',
                value: ''
            },
            {
                text: '近5分钟',
                value: '300'
            },
            {
                text: '近15分钟',
                value: '900'
            },
            {
                text: '近30分钟',
                value: '1800'
            },
            {
                text: '近1小时',
                value: '3600'
            },
            {
                text: '近6小时',
                value: '21600'
            },
            {
                text: '近1天',
                value: '86400'
            },
            {
                text: '近7天',
                value: '604800'
            },
            {
                text: '近30天',
                value: '2592000'
            }
        ];
    }

    componentDidMount() {
        this.openCarouselTimer();
        this.getCoreServiceList();
    }
    componentWillUnmount() {
        // 清除计时器
        this.clearCarouselTimer();
        this.clearTimer();
    }
    // 开启跑马灯的timer
    openCarouselTimer = () => {
        this.clearCarouselTimer();
        this.carouselTimer = setInterval(() => {
            this.clearTimer();
            this.carouselRef.current.next();
        }, 30000);
    }
    // 清除计时器
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 清除跑马灯计时器
    clearCarouselTimer = () => {
        clearInterval(this.carouselTimer);
        this.carouselTimer = null;
    }
    // 获取核心服务列表
    getCoreServiceList = async () => {
        const { code, entry } = await businessMarketService.getCoreServiceList();
        if (code === '0') {
            this.setState({
                loading: true,
                serviceList: this.handleServiceList(entry)
            }, () => {
                this.getReportInfo();
            });
        }
    }
    // 生成二维数组
    handleServiceList = (serviceList) => {
        const spliceNum = 6;
        const spliceArray = [];
        serviceList.forEach((item, index) => {
            if (index % spliceNum === 0) spliceArray.push([]);
            spliceArray[Math.floor(index / spliceNum)].push(item);
        });
        return spliceArray;
    }
    // 查询
    getReportInfo = async (e) => {
        e && e.preventDefault();
        const { closeAutoCarousel } = this.state;
        this.reportRef.props.form.validateFields((err, values) => {
            if (!err) {
                if (e) {
                    this.setState({
                        loading: true
                    });
                }
                if (!closeAutoCarousel) {
                    this.openCarouselTimer(); // 开启跑马灯计时器
                }
                this.clearTimer();
                let params = { ...this.reportRef.props.form.getFieldsValue() };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                const { refresh, autoRefresh } = params;
                if (refresh) {
                    params = {
                        ...params,
                        ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
                    };
                    if (autoRefresh) {
                        this.autoRefreshChart(params, refresh);
                    } else {
                        this.setOptions(params);
                    }
                } else {
                    this.setOptions(params);
                }
            }
        });
    }
    // 轮询更新图表
    autoRefreshChart = async (params, refresh) => {
        this.clearTimer();
        const getParams = () => {
            return {
                ...params,
                ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
            };
        };
        await this.setOptions(params);
        this.timer = setTimeout(
            () => {
                this.autoRefreshChart(getParams(), refresh);
            },
            5000
        );
    }
    setOptions = async (params) => {
        delete params.rangeTime;
        delete params.refresh;
        delete params.autoRefresh;
        delete params.autoCarousel;
        const {
            serviceList,
            currentCarousel
        } = this.state;
        const options = [];
        const serviceArr = [];
        const detail = [];
        serviceList[currentCarousel] && serviceList[currentCarousel].forEach((item, index) => {
            const resultParams = {
                ...params,
                col2: item.appName,
                col3: item.name,
                col4: item.method
            };
            detail.push({ ...resultParams, ...{ description: item.description } });
            delete resultParams.id;
            delete resultParams.appId;
            delete resultParams.description;
            serviceArr.push(linkTrackingService.getInterfaceInfo(resultParams));
        });
        const res = await Promise.all(serviceArr);
        res.forEach((item, index) => {
            const { code, entry } = item;
            if (code === '0') {
                const xAxisArr = [];
                const avgqpsArr = [];
                entry.forEach((eitem) => {
                    xAxisArr.push(eitem.eventTime);
                    avgqpsArr.push((eitem.data && eitem.data.avgqps) || 0);
                });
                options.push({
                    xAxis: [
                        {
                            data: xAxisArr
                        }
                    ],
                    series: [
                        {
                            data: avgqpsArr
                        }
                    ]
                });
            }
        });
        if (options.length > 0) {
            this.setState({
                chartOptions: options,
                detail
            });
        }
        this.setState({
            loading: false
        });
    }
    // 开启自动刷新后，静止datePicker
    changeSelect = (value) => {
        const { autoRefresh } = this.reportRef.props.form.getFieldsValue(['autoRefresh']);
        this.judgePickerDisabled(value, autoRefresh);
    }
    // 自动更新
    changeSwitch = (checked) => {
        const { refresh } = this.reportRef.props.form.getFieldsValue(['refresh']);
        this.judgePickerDisabled(refresh, checked);
    }
    // 自动轮播
    changeCarouselSwitch = (checked) => {
        if (checked) {
            this.openCarouselTimer();
        } else {
            this.clearCarouselTimer();
        }
        this.setState({
            closeAutoCarousel: !checked
        });
    }
    judgePickerDisabled = (refresh, autoRefresh) => {
        if (autoRefresh && refresh) {
            message.success('已打开自动查询');
        }
        let flag = false;
        if (refresh !== '') {
            flag = true;
        }
        if (flag) {
            this.reportRef.props.form.resetFields([
                'rangeTime'
            ]);
        }
        this.setState({
            datePickerDisabled: flag
        }, () => {
            this.reportRef.props.form.validateFields(['rangeTime'], { force: true });
            if (autoRefresh && refresh) {
                this.getReportInfo();
            } else {
                this.clearTimer();
            }
        });
    }
    // 改变布局
    changeLayout = (layout) => {
        this.setState({
            layout
        });
    }
    // 跑马灯更换
    onBeforeChange = (from, to) => {
        this.clearTimer();
        this.setState({
            currentCarousel: to
        }, () => {
            setTimeout(() => {
                this.getReportInfo();
            }, 0);
        });
    }
    render() {
        const {
            datePickerDisabled,
            chartOptions,
            layout,
            detail,
            loading,
            serviceList
        } = this.state;
        const { options } = this;
        const baseFormItemsSetting = {
            rangeTime: {
                span: 5,
                options: {
                    initialValue: [],
                    rules: [{
                        type: 'array',
                        required: !datePickerDisabled,
                        message: '时间范围必选'
                    }]
                },
                extraProps: {
                    onOk: () => {
                        this.clearTimer();
                        this.reportRef.props.form.setFieldsValue({ autoRefresh: false, refresh: '' });
                    }
                }
            },
            button: {
                span: 7
            }
        };
        const selectComponent = (<Select onChange={this.changeSelect}>
            {
                options.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const extraFormItem = [
            {
                span: 2,
                id: 'refresh',
                options: {
                    initialValue: '300'
                },
                component: selectComponent
            },
            {
                span: 3,
                label: '自动更新',
                id: 'autoRefresh',
                options: {
                    valuePropName: 'checked',
                    initialValue: true
                },
                component: <Switch onChange={this.changeSwitch}/>
            },
            {
                span: 3,
                label: '自动轮播',
                id: 'autoCarousel',
                options: {
                    valuePropName: 'checked',
                    initialValue: true
                },
                component: <Switch onChange={this.changeCarouselSwitch}/>
            },
            {
                span: 4,
                label: '展示方式',
                id: 'layout',
                options: {
                    initialValue: 8
                },
                component: <Select style={{ width: 120 }} onChange={this.changeLayout}>
                    <Option value={8}>平铺</Option>
                    <Option value={24}>列表</Option>
                </Select>
            }
        ];
        return (
            <div>
                <QueryForm wrappedComponentRef={(ref) => { this.reportRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getReportInfo} />
                <Carousel beforeChange={this.onBeforeChange} ref={this.carouselRef}>
                    {
                        serviceList.map((it, i) => {
                            if (loading) {
                                return <Spin spinning={loading} tip="Loading..." key={i}>
                                    <div style={{
                                        minHeight: '800px'
                                    }}></div>
                                </Spin>;
                            }
                            return <Row gutter={16} key={i}>
                                {
                                    chartOptions.length > 0 && chartOptions.map((item, index) => {
                                        const title = <h4 style={{ marginTop: '20px', marginBottom: '10px' }}>
                                            {index + 1}.
                                            <Link style={{ marginRight: '10px' }} to={{ pathname: this.props.paths.InterfaceInfo.linkPath, search: `?col2=${detail[index].col2}&col3=${detail[index].col3}&col4=${detail[index].col4}&startEventTime=${detail[index].startEventTime}&endEventTime=${detail[index].endEventTime}` }} target="_blank">
                                                {detail[index].description || '未知类型'}
                                            </Link>
                                            <Link to={{ pathname: this.props.paths.TraceInfoList.linkPath, search: `?appName=${detail[index].col2}&serviceName=${detail[index].col3}&methodName=${detail[index].col4}` }} target="_blank">
                                                [查看调用链]
                                            </Link>
                                        </h4>;
                                        const setting = fromJS(item);
                                        return (<Col key={index} span={layout}>
                                            {title}
                                            <Report setting={setting} layout={layout} />
                                        </Col>);
                                    })
                                }
                            </Row>;
                        })
                    }
                </Carousel>
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});


export default connect(stateToProps)(BusinessReport);
