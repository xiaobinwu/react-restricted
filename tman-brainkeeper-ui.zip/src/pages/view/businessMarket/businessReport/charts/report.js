import React, { Component } from 'react';
import { is, fromJS } from 'immutable';
import ReactEcharts from 'component/echarts-for-react';

export default class Report extends Component {
    // 数据源相同，阻止render
    shouldComponentUpdate(nextProps = {}) {
        const thisProps = this.props || {};
        if (!is(thisProps.setting, nextProps.setting)) {
            return true;
        }
        if (thisProps.layout !== nextProps.layout) {
            return true;
        }
        return false;
    }
    render() {
        const { setting, layout } = this.props;
        const option = fromJS({
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                }
            },
            grid: {
                left: '60px',
                right: '20px',
                top: '50px',
                bottom: '30px'
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['QPS']
            },
            dataZoom: [{
                type: 'inside'
            }],
            xAxis: [
                {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    data: []
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: 'QPS',
                    axisLabel: {
                        formatter: '{value}'
                    },
                    max: (value) => {
                        if (value.max <= 10) {
                            return 10;
                        }
                        return value.max * 1.5;
                    },
                }
            ],
            series: [
                {
                    name: 'QPS',
                    type: 'line',
                    smooth: true,
                    data: []
                },
            ]
        });
        const finalOption = option.mergeDeep(setting);
        const style = layout === 24 ? { height: 500, width: '100%' } : { height: 300, width: '100%' };
        return (
            <div style={{ marginBottom: '16px' }}>
                <ReactEcharts
                    option={finalOption.toJS()}
                    style={style}/>
            </div>
        );
    }
}
