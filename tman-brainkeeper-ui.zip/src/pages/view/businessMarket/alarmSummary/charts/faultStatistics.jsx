import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';
import PropTypes from 'prop-types';


export default class FaultStatistics extends Component {
    render() {
        const {
            xAxis,
            isStack,
            stackName,
            mode,
            values,
            showLegend,
            categoryAxixName
        } = this.props;
        const legend = [];
        let modeView;
        if (mode === 'vertical') {
            modeView = {
                yAxis: [
                    {
                        type: 'category',
                        data: xAxis,
                        name: categoryAxixName
                    }
                ],
                xAxis: [
                    {
                        type: 'value'
                    }
                ],
            };
        } else {
            modeView = {
                xAxis: [
                    {
                        type: 'category',
                        data: xAxis,
                        name: categoryAxixName
                    }
                ],
                yAxis: [
                    {
                        type: 'value'
                    }
                ],
            };
        }
        const series = Object.keys(values).map((item, index) => {
            legend.push(item);
            return {
                name: item,
                type: 'bar',
                ...(isStack ? { stack: stackName } : {}),
                label: {
                    show: true,
                    position: 'inside',
                    formatter: (params) => {
                        return params.value || '';
                    }
                },
                data: values[item]
            };
        });
        const options = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                }
            },
            ...(showLegend ? {
                legend: {
                    data: legend
                }
            } : {}),
            toolbox: {
                feature: {
                    saveAsImage: {}
                }
            },
            ...modeView,
            series
        };
        return (
            <div style={{ width: '100%' }}>
                <ReactEcharts
                    option={options}
                    style={{ height: 450, width: '100%' }} />
            </div>
        );
    }
}

FaultStatistics.propTypes = {
    xAxis: PropTypes.array.isRequired,
    values: PropTypes.object.isRequired,
    isStack: PropTypes.bool,
    showLegend: PropTypes.bool,
    stackName: PropTypes.string,
    mode: PropTypes.string,
    categoryAxixName: PropTypes.string
};

FaultStatistics.defaultProps = {
    isStack: true,
    stackName: '总量',
    mode: 'horizontal',
    showLegend: true,
    categoryAxixName: ''
};
