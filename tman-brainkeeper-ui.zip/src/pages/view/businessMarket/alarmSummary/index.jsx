import React, { Component } from 'react';
import { Card, Col, Row, Icon } from 'antd';
import { connect } from 'react-redux';
import moment from 'moment';
import { businessMarketService } from 'service';
import FaultStatistics from './charts/faultStatistics';

import styles from './index.css';

const monthDateTime = moment().startOf('month').format('YYYY-MM-DD HH:mm:ss'); // 获取本月第一天
const yearDateTime = moment().startOf('year').format('YYYY-MM-DD HH:mm:ss'); // 获取本年第一天
const quarterDateTime = moment().startOf('quarter').format('YYYY-MM-DD HH:mm:ss'); // 获取本季度第一天

class AlarmSummary extends Component {
    state = {
        curMonthSum: 0,
        curQuarterSum: 0,
        curYearSum: 0,
        faultHistogramXAxis: [],
        faultHistogramValues: {},
        domainXAxis: [],
        domainValues: {},
        endPointXAxis: [],
        endPointValues: {},
        levelXAxis: [],
        levelValues: {}
    }
    componentDidMount() {
        this.getFaultSum();
        this.getFaultHistogram();
        this.getAlarmTop('DOMAIN');
        this.getAlarmTop('ENDPOINT_TYPE');
        this.getAlarmTop('LEVEL');
    }
    // 故障汇总
    getFaultSum = async () => {
        const { code, entry } = await businessMarketService.getFaultSum();
        if (code === '0') {
            const {
                curMonthSum,
                curQuarterSum,
                curYearSum
            } = entry;
            this.setState({
                curMonthSum,
                curQuarterSum,
                curYearSum
            });
        }
    }
    // 故障直方图
    getFaultHistogram = async () => {
        const { code, entry } = await businessMarketService.getFaultHistogram();
        const faultHistogramXAxis = [];
        const faultHistogramValues = {};
        if (code === '0' && entry && entry.itemList.length > 0) {
            entry.itemList.forEach((item, index) => {
                faultHistogramXAxis.push(item.month);
                item.faultSumList && item.faultSumList.forEach((it, inx) => {
                    !(it.domainName in faultHistogramValues) && (faultHistogramValues[it.domainName] = []);
                    faultHistogramValues[it.domainName].push(it.num);
                });
            });
        }
        this.setState({
            faultHistogramXAxis,
            faultHistogramValues
        });
    }
    // 处理本月业务告警
    handleDomain = (entry) => {
        const domainXAxis = [];
        const name = '业务告警排名';
        const domainValues = { [name]: [] };
        if (entry.itemList.length > 0) {
            entry.itemList.forEach((item, index) => {
                domainXAxis.push(item.metricName);
                domainValues[name].push(item.num);
            });
        }
        this.setState({
            domainXAxis,
            domainValues
        });
    }
    // 处理本月告警类型和告警级别
    handleAlarm = (entry, prefix) => {
        const xAxis = [];
        const values = {};
        if (entry.itemList.length > 0) {
            entry.itemList.forEach((item, index) => {
                xAxis.push(item.metricName);
                item.domainSumList && item.domainSumList.forEach((it, inx) => {
                    !(it.domainName in values) && (values[it.domainName] = []);
                    values[it.domainName].push(it.num);
                });
            });
        }
        this.setState({
            [`${prefix}XAxis`]: xAxis,
            [`${prefix}Values`]: values
        });
    }
    // 故障排名
    getAlarmTop = async (type) => {
        const { code, entry } = await businessMarketService.getAlarmTop({ type });
        if (code === '0' && entry) {
            switch (type) {
            case 'DOMAIN':
                this.handleDomain(entry);
                break;
            case 'ENDPOINT_TYPE':
                this.handleAlarm(entry, 'endPoint');
                break;
            default:
                this.handleAlarm(entry, 'level');
                break;
            }
        }
    }
    faultlink = (type) => {
        let search;
        const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
        switch (type) {
        case 'month':
            search = `?startEventTime=${monthDateTime}&endEventTime=${currentTime}`;
            break;
        case 'quarter':
            search = `?startEventTime=${quarterDateTime}&endEventTime=${currentTime}`;
            break;
        default:
            search = `?startEventTime=${yearDateTime}&endEventTime=${currentTime}`;
            break;
        }
        window.open(`${this.props.paths.FaultList.linkPath}${search}`); // 新窗口打开故障列表
    }
    render() {
        const {
            curMonthSum,
            curQuarterSum,
            curYearSum,
            faultHistogramXAxis,
            faultHistogramValues,
            domainXAxis,
            domainValues,
            endPointXAxis,
            endPointValues,
            levelXAxis,
            levelValues
        } = this.state;
        return (
            <div>
                <Row gutter={20}>
                    <Col span={8}>
                        <Card bordered={false} className={`${styles.cardBody} system-overview-border-color`}>
                            <Icon type="api" className={`system-alarmSummary-color1 ${styles.cardIcon}`} />
                            <div className={styles.cardTitle}>
                                本月故障数
                            </div>
                            <div className={styles.cardContent}>
                                <span className={styles.link} onClick={this.faultlink.bind(this, 'month')}>{curMonthSum}</span>
                            </div>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card bordered={false} className={`${styles.cardBody} system-overview-border-color`}>
                            <Icon type="thunderbolt" className={`system-alarmSummary-color2 ${styles.cardIcon}`}/>
                            <div className={styles.cardTitle}>
                                本季度故障数
                            </div>
                            <div className={styles.cardContent}>
                                <span className={styles.link} onClick={this.faultlink.bind(this, 'quarter')}>{curQuarterSum}</span>
                            </div>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card bordered={false} className={`${styles.cardBody} system-overview-border-color`}>
                            <Icon type="disconnect" className={`system-alarmSummary-color3 ${styles.cardIcon}`} />
                            <div className={styles.cardTitle}>
                                本年故障数
                            </div>
                            <div className={styles.cardContent}>
                                <span className={styles.link} onClick={this.faultlink.bind(this, 'year')}>{curYearSum}</span>
                            </div>
                        </Card>
                    </Col>
                </Row>
                <Row gutter={20} style={{ marginBottom: 20 }}>
                    <Col span={24}>
                        <Card className={styles.cardNoPadding} title="故障统计" bordered={false}>
                            <FaultStatistics xAxis={faultHistogramXAxis} values={faultHistogramValues} categoryAxixName="月份"/>
                        </Card>
                    </Col>
                </Row>
                <Row gutter={20} style={{ marginBottom: 20 }}>
                    <Col span={8}>
                        <Card className={styles.cardNoPadding} title="本月业务告警排名" bordered={false}>
                            <FaultStatistics xAxis={domainXAxis} values={domainValues} isStack={false} mode="vertical" showLegend={false} categoryAxixName="业务"/>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card className={styles.cardNoPadding} title="本月告警类型排名" bordered={false}>
                            <FaultStatistics xAxis={endPointXAxis} values={endPointValues} mode="vertical" showLegend={false} categoryAxixName="类型"/>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card className={styles.cardNoPadding} title="本月告警级别排名" bordered={false}>
                            <FaultStatistics xAxis={levelXAxis} values={levelValues} mode="vertical" showLegend={false} categoryAxixName="级别"/>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}


const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(AlarmSummary);
