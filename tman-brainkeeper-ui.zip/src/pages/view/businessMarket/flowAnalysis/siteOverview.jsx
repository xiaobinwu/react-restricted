import React, { Component } from 'react';
import { Row, Col, Switch, Select, message } from 'antd';
import { linkTrackingService } from 'service';
import moment from 'moment';
import QueryForm from 'component/queryForm';
import { getQueryString, isNotEmptyObject } from 'js/util';
import Overview from './charts/overview';

const { Option } = Select;
class SiteOverview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            ownKey: '1',
            xAxis: [],
            series: [],
            legend: [],
            datePickerDisabled: false
        };
        this.options = [
            {
                text: 'OFF',
                value: ''
            },
            {
                text: '近5分钟',
                value: '300'
            },
            {
                text: '近15分钟',
                value: '900'
            },
            {
                text: '近30分钟',
                value: '1800'
            },
            {
                text: '近1小时',
                value: '3600'
            },
            {
                text: '近6小时',
                value: '21600'
            },
            {
                text: '近1天',
                value: '86400'
            },
            {
                text: '近7天',
                value: '604800'
            },
            {
                text: '近30天',
                value: '2592000'
            }
        ];
    }
    componentDidMount() {
        const result = getQueryString();
        if (isNotEmptyObject(result)) {
            let finnalResult;
            if (result.startEventTime && result.endEventTime) {
                finnalResult = { ...{ rangeTime: [moment(result.startEventTime), moment(result.endEventTime)] } };
                this.flowRef.props.form.setFieldsValue(finnalResult);
                this.getFlowInfo();
            } else {
                const autoRefresh = result.autoRefresh === 'true';
                finnalResult = { ...{ refresh: result.refresh, autoRefresh } };
                this.setState({
                    datePickerDisabled: true
                }, () => {
                    this.flowRef.props.form.setFieldsValue(finnalResult);
                    this.getFlowInfo();
                });
            }
        } else {
            this.setState({
                datePickerDisabled: true
            }, () => {
                this.flowRef.props.form.setFieldsValue({ refresh: '900', autoRefresh: true });
                setTimeout(() => {
                    this.getFlowInfo();
                }, 500);
            });
        }
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    // 清除计时器
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 获取流量分析数据
    getFlowInfo = (e) => {
        e && e.preventDefault();
        this.flowRef.props.form.validateFields((err, values) => {
            if (!err) {
                this.clearTimer();
                let params = { ...this.flowRef.props.form.getFieldsValue(), metricName: 'site.tps' };
                if (params.rangeTime && params.rangeTime.length > 0) {
                    const { rangeTime } = params;
                    params.startEventTime = rangeTime[0].format('YYYY-MM-DD HH:mm:ss');
                    params.endEventTime = rangeTime[1].format('YYYY-MM-DD HH:mm:ss');
                }
                const { refresh, autoRefresh } = params;
                if (refresh) {
                    params = {
                        ...params,
                        ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
                    };
                    if (autoRefresh) {
                        this.autoRefreshChart(params, refresh);
                    } else {
                        this.setOptions(params);
                    }
                } else {
                    this.setOptions(params);
                }
            }
        });
    }
    // 轮询更新图表
    autoRefreshChart = async (params, refresh) => {
        this.clearTimer();
        const getParams = () => {
            return {
                ...params,
                ...{ startEventTime: moment().subtract(+refresh, 'seconds').format('YYYY-MM-DD HH:mm:ss'), endEventTime: moment().format('YYYY-MM-DD HH:mm:ss') },
            };
        };
        await this.setOptions(params);
        this.timer = setTimeout(
            () => {
                this.autoRefreshChart(getParams(), refresh);
            },
            5000
        );
    }
    // 设置图标数据源
    setOptions = async (params) => {
        const { ownKey } = this.state;
        const { activeKey } = this.props;
        // 判断是否发起请求
        if (ownKey === activeKey) {
            delete params.rangeTime;
            delete params.refresh;
            delete params.autoRefresh;
            const serviceArr = [];
            const legend = [];
            const series = [];
            const xAxisArr = [];
            const res = await linkTrackingService.getAllSite();
            Array.isArray(res.entry) && res.entry.forEach((item, index) => {
                const finalParams = { ...params, ...{ col2: item.key } };
                legend.push(JSON.parse(item.value).cnName);
                serviceArr.push(linkTrackingService.getMetricsDetail(finalParams));
            });
            const result = await Promise.all(serviceArr);
            result.forEach((item, index) => {
                const { code, entry } = item;
                if (code === '0') {
                    const avgqpsArr = [];
                    entry.forEach((citem, cindex) => {
                        if (index === 0) {
                            xAxisArr.push(citem.eventTime);
                        }
                        avgqpsArr.push((citem.data && citem.data.avgqps) || 0);
                    });
                    series.push({
                        name: legend[index],
                        type: 'line',
                        areaStyle: {
                            normal: {
                                opacity: 0.3
                            }
                        },
                        lineStyle: {
                            width: 0.5
                        },
                        showSymbol: false,
                        smoothMonotone: 'none',
                        stack: '平均QPS',
                        data: avgqpsArr
                    });
                }
            });
            this.setState({
                xAxis: xAxisArr,
                legend,
                series
            });
        }
    }
    // 开启自动刷新后，静止datePicker
    changeSelect = (value) => {
        const { autoRefresh } = this.flowRef.props.form.getFieldsValue(['autoRefresh']);
        this.judgePickerDisabled(value, autoRefresh);
    }
    changeSwitch = (checked) => {
        const { refresh } = this.flowRef.props.form.getFieldsValue(['refresh']);
        this.judgePickerDisabled(refresh, checked);
    }
    judgePickerDisabled = (refresh, autoRefresh) => {
        if (autoRefresh && refresh) {
            message.success('已打开自动查询');
        }
        let flag = false;
        if (refresh !== '') {
            flag = true;
        }
        if (flag) {
            this.flowRef.props.form.resetFields([
                'rangeTime'
            ]);
        }
        this.setState({
            datePickerDisabled: flag
        }, () => {
            this.flowRef.props.form.validateFields(['rangeTime'], { force: true });
            if (autoRefresh && refresh) {
                this.getFlowInfo();
            } else {
                this.clearTimer();
            }
        });
    }
    render() {
        const {
            xAxis,
            series,
            legend,
            datePickerDisabled
        } = this.state;
        const { options } = this;
        const baseFormItemsSetting = {
            rangeTime: {
                span: 5,
                options: {
                    initialValue: [],
                    rules: [{
                        type: 'array',
                        required: !datePickerDisabled,
                        message: '时间范围必选'
                    }]
                },
                extraProps: {
                    onOk: () => {
                        this.clearTimer();
                        this.flowRef.props.form.setFieldsValue({ autoRefresh: false, refresh: '' });
                    }
                }
            },
            button: {
                span: 3
            }
        };
        const selectComponent = (<Select onChange={this.changeSelect}>
            {
                options.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const extraFormItem = [
            {
                span: 2,
                id: 'refresh',
                options: {
                    initialValue: ''
                },
                component: selectComponent
            },
            {
                span: 3,
                label: '自动更新',
                id: 'autoRefresh',
                options: {
                    valuePropName: 'checked',
                    initialValue: false
                },
                component: <Switch onChange={this.changeSwitch}/>
            }
        ];
        return (
            <div>
                <QueryForm wrappedComponentRef={(ref) => { this.flowRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getFlowInfo} />
                <Row>
                    <Col>
                        <Overview xAxis={xAxis} series={series} legend={legend}/>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default SiteOverview;
