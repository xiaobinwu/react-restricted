
import React, { Component } from 'react';
import { Row, Col, Switch, DatePicker, message, Select } from 'antd';
import { linkTrackingService } from 'service';
import moment from 'moment';
import QueryForm from 'component/queryForm';
import withRef from 'component/hoc/withRef';

import HistoryCompareLine from './charts/history';
import TotalCompare from './charts/totalCompare';
import styles from './index.css';

const { Option } = Select;
class HistoryCompare extends Component {
    constructor(props) {
        super(props);
        this.state = {
            ownKey: '3',
            datePickerDisabled: false,
            serviceNameOrMethodNameDisabled: false,
            currentIndicatorsXAxisArr: [],
            threeDayIndicatorsXAxisArr: [],
            referenceIndicatorsXAxisArr: [],
            currentIndicatorsQpsArr: [],
            threeDayIndicatorsQpsArr: [],
            referenceIndicatorsQpsArr: [],
            todayTotal: 0,
            threeDayTotal: 0,
            referenceTotal: 0,
            referenceLegend: '',
            siteDisabled: true,
        };
        this.options = [
            {
                text: 'OFF',
                value: ''
            },
            {
                text: '近5分钟',
                value: '300'
            },
            {
                text: '近15分钟',
                value: '900'
            },
            {
                text: '近30分钟',
                value: '1800'
            },
            {
                text: '近1小时',
                value: '3600'
            },
            {
                text: '近6小时',
                value: '21600'
            },
            {
                text: '近1天',
                value: '86400'
            }
        ];
    }
    componentDidMount() {
        this.initDefaultData();
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    initDefaultData = () => {
        this.setState({
            datePickerDisabled: true
        }, () => {
            const { form } = this.historyRef.props;
            form.setFieldsValue({
                refresh: '900',
                site: 'GB',
                autoRefresh: true,
                app: 'gateway'
            });
            this.getHistoryisInfo();
        });
    }
    clearTimer = () => {
        clearInterval(this.timer);
        this.timer = null;
    }
    getHistoryisInfo = (e) => {
        e && e.preventDefault();
        const { form } = this.historyRef.props;
        form.validateFields((err, values) => {
            if (!err) {
                this.clearTimer();
                let params = { ...form.getFieldsValue() };
                const { refresh, autoRefresh } = params;
                // 选择了相对时间
                if (refresh) {
                    params.rangeTime = [moment().subtract(+refresh, 'seconds'), moment()];
                    // 开启自动更新
                    if (autoRefresh) {
                        this.autoRefreshChart({ ...params }, refresh);
                    }
                }
                params = this.getFinalParams(params);
                this.setOptions(params);
            }
        });
    }
    // 得到最终的params
    getFinalParams = (params) => {
        const format = 'YYYY-MM-DD HH:mm:ss';
        const { rangeTime, referenceTime } = params;
        const diff = rangeTime[1].unix() - rangeTime[0].unix();
        const calculatedRangTime0 = {
            hour: rangeTime[0].hour(),
            minute: rangeTime[0].minute(),
            second: rangeTime[0].second(),
            millisecond: rangeTime[0].millisecond()
        };
        const calculatedRangTime1 = {
            hour: rangeTime[1].hour(),
            minute: rangeTime[1].minute(),
            second: rangeTime[1].second(),
            millisecond: rangeTime[1].millisecond()
        };
        // moment是mutable
        // 当前指标
        params.currentIndicators = {
            startEventTime: rangeTime[0].format(format),
            endEventTime: rangeTime[1].format(format)
        };
        // 近7天指标
        params.threeDayIndicators = {
            startEventTime: moment(rangeTime[1]).subtract(4, 'day').set(calculatedRangTime0).format(format),
            endEventTime: moment(rangeTime[1]).subtract(1, 'day').set(calculatedRangTime1).format(format)
        };
        // 参考指标
        const referenceEndMoment = moment(referenceTime).set(calculatedRangTime1);
        const referenceEndEventTime = referenceEndMoment.format(format);
        params.referenceIndicators = {
            startEventTime: moment.unix(referenceEndMoment.unix() - diff).format(format),
            endEventTime: referenceEndEventTime
        };
        delete params.rangeTime;
        delete params.refresh;
        delete params.autoRefresh;
        return params;
    }
    // 轮询更新图表
    autoRefreshChart = (params, refresh) => {
        this.timer = setInterval(
            () => {
                params.rangeTime = [moment().subtract(+refresh, 'seconds'), moment()];
                const finnalParams = this.getFinalParams(params);
                this.setOptions(finnalParams);
            },
            60000
        );
    }
    // 设置图表数据源
    setOptions = async (params) => {
        const { ownKey } = this.state;
        const { activeKey } = this.props;
        // 判断是否发起请求
        if (ownKey === activeKey) {
            // 只查询接口
            if (params.service && !params.site) {
                params.metricName = 'site.service.tps';
                params.col3 = params.app;
                params.col4 = params.service;
                params.col5 = params.method;
            }
            // 只查询站点
            if (!params.service && params.site) {
                params.metricName = 'site.tps';
                params.col2 = params.site;
            }
            // 查询接口&站点
            if (params.service && params.site) {
                params.metricName = 'site.service.tps';
                params.col2 = params.site;
                params.col3 = params.app;
                params.col4 = params.service;
                params.col5 = params.method;
            }
            const {
                currentIndicators,
                threeDayIndicators,
                referenceIndicators,
                ...restParams
            } = params;
            const referenceLegend = params.referenceTime.format('YYYY-MM-DD');
            const res = await Promise.all([
                // 当前指标
                linkTrackingService.getMetricsWithSiteDetail({
                    ...restParams,
                    startEventTime: currentIndicators.startEventTime,
                    endEventTime: currentIndicators.endEventTime
                }),
                // 近三天指标
                linkTrackingService.getRecentSiteavg({
                    ...restParams,
                    startEventTime: threeDayIndicators.startEventTime,
                    endEventTime: threeDayIndicators.endEventTime
                }),
                // 参考指标
                linkTrackingService.getMetricsWithSiteDetail({
                    ...restParams,
                    startEventTime: referenceIndicators.startEventTime,
                    endEventTime: referenceIndicators.endEventTime
                })
            ]);
            const currentIndicatorsXAxisArr = [];
            const threeDayIndicatorsXAxisArr = [];
            const referenceIndicatorsXAxisArr = [];
            const currentIndicatorsQpsArr = [];
            const threeDayIndicatorsQpsArr = [];
            const referenceIndicatorsQpsArr = [];
            let todayTotal = 0;
            let threeDayTotal = 0;
            let referenceTotal = 0;
            res.forEach((item, index) => {
                // 当前指标
                if (index === 0 && item.code === '0') {
                    if (item.entry) {
                        item.entry.length > 0 && item.entry.forEach((it, i) => {
                            currentIndicatorsXAxisArr.push(it.eventTime);
                            currentIndicatorsQpsArr.push((it.data && it.data.avgqps) || 0);
                            todayTotal += (it.data && it.data.avgqps) || 0;
                        });
                    }
                }
                // 近三天指标
                if (index === 1 && item.code === '0') {
                    if (item.entry) {
                        item.entry.length > 0 && item.entry.forEach((it, i) => {
                            threeDayIndicatorsXAxisArr.push(it.eventTime);
                            threeDayIndicatorsQpsArr.push((it.data && it.data.avgqps) || 0);
                            threeDayTotal += (it.data && it.data.avgqps) || 0;
                        });
                    }
                }
                // 参考指标
                if (index === 2 && item.code === '0') {
                    if (item.entry) {
                        item.entry.length > 0 && item.entry.forEach((it, i) => {
                            referenceIndicatorsXAxisArr.push(it.eventTime);
                            referenceIndicatorsQpsArr.push((it.data && it.data.avgqps) || 0);
                            referenceTotal += (it.data && it.data.avgqps) || 0;
                        });
                    }
                }
            });
            this.setState({
                currentIndicatorsXAxisArr,
                threeDayIndicatorsXAxisArr,
                referenceIndicatorsXAxisArr,
                currentIndicatorsQpsArr,
                threeDayIndicatorsQpsArr,
                referenceIndicatorsQpsArr,
                todayTotal,
                threeDayTotal,
                referenceTotal,
                referenceLegend
            });
        }
    }
    // 开启自动刷新后，静止datePicker，并且验证参考时间
    changeSwitch = (checked) => {
        const { form } = this.historyRef.props;
        const { refresh } = form.getFieldsValue(['refresh']);
        this.judgePickerDisabled(refresh, checked);
    }
    changeSelect = (value) => {
        const { form } = this.historyRef.props;
        const { autoRefresh } = form.getFieldsValue(['autoRefresh']);
        this.judgePickerDisabled(value, autoRefresh);
    }
    judgePickerDisabled = (refresh, autoRefresh) => {
        const { form } = this.historyRef.props;
        if (autoRefresh && refresh) {
            message.success('已打开自动查询');
        }
        let flag = false;
        if (refresh !== '') {
            flag = true;
        }
        if (flag) {
            form.resetFields([
                'rangeTime'
            ]);
        }
        this.setState({
            datePickerDisabled: flag
        }, () => {
            form.validateFields(['rangeTime'], { force: true });
            if (autoRefresh && refresh) {
                form.validateFields(['referenceTime'], { force: true });
                this.getHistoryisInfo();
            } else {
                this.clearTimer();
            }
        });
    }
    // 触发日历组件的ok回调
    handleCurrentTimeRangeChange = () => {
        const { form } = this.historyRef.props;
        this.setState({
            datePickerDisabled: false
        }, () => {
            this.clearTimer();
            form.setFieldsValue({ autoRefresh: false, refresh: '' });
            form.validateFields(['rangeTime'], { force: true });
        });
    }
    // 时间验证规则
    validateToReferenceTime = (rule, value, callback) => {
        const { form } = this.historyRef.props;
        if (value && !this.state.datePickerDisabled) {
            if (value.length > 0 && value[1].unix() - value[0].unix() > 86400) {
                callback('当前时间范围最大限度不超过24个小时');
            } else {
                form.validateFields(['referenceTime'], { force: true });
            }
        }
        callback();
    }
    validateToCurrentTime = (rule, value, callback) => {
        const { form } = this.historyRef.props;
        const { refresh, rangeTime } = form.getFieldsValue(['refresh', 'rangeTime']);
        let startEventTime;
        let endEventTime;
        let diff;
        if (this.state.datePickerDisabled) {
            startEventTime = moment().subtract(+refresh, 'seconds');
            endEventTime = moment();
            diff = +refresh;
        } else {
            // 由于存在跨天的问题，默认取moment数组的第一项
            [startEventTime, endEventTime] = rangeTime;
            diff = endEventTime.unix() - startEventTime.unix();
        }
        if (startEventTime && value) {
            const cloneCurrentTime = moment(endEventTime);
            if (
                cloneCurrentTime.set({
                    hour: 0,
                    minute: 0,
                    second: 0,
                    millisecond: 0
                }).unix() - value.set({
                    hour: 0,
                    minute: 0,
                    second: 0,
                    millisecond: 0
                }).unix() < 86400
            ) {
                callback(`参考日期不能晚于当前时间，最晚为${endEventTime.subtract(1, 'day').format('YYYY-MM-DD')}`);
            }
            // 时间维度小于3H
            if (diff <= 10800) {
                const limitDate = moment().subtract(15, 'day').set({
                    hour: 0,
                    minute: 0,
                    second: 0,
                    millisecond: 0
                });
                if (value.isBefore(limitDate)) {
                    callback('参考日期最早不能早于当前系统时间的15天前');
                }
            }
            // 时间维度大于3H小于24H
            if (diff > 10800 && diff <= 86400) {
                const limitDate = moment().subtract(30, 'day').set({
                    hour: 0,
                    minute: 0,
                    second: 0,
                    millisecond: 0
                });
                if (value.isBefore(limitDate)) {
                    callback('参考日期最早不能早于当前系统时间的30天前');
                }
            }
        }
        callback();
    }
    // serviceName选择回调
    serviceChange = (value) => {
        this.setState({
            siteDisabled: value === '',
        }, () => {
            this.historyRef.props.form.validateFields(['site'], { force: true });
        });
    }
    // site选择回调
    siteChange = (value) => {
        this.setState({
            serviceNameOrMethodNameDisabled: value === ''
        }, () => {
            this.historyRef.props.form.validateFields(['service', 'method'], { force: true });
        });
    }
    render() {
        const {
            datePickerDisabled,
            serviceNameOrMethodNameDisabled,
            currentIndicatorsXAxisArr,
            threeDayIndicatorsXAxisArr,
            referenceIndicatorsXAxisArr,
            currentIndicatorsQpsArr,
            threeDayIndicatorsQpsArr,
            referenceIndicatorsQpsArr,
            todayTotal,
            threeDayTotal,
            referenceTotal,
            referenceLegend,
            siteDisabled
        } = this.state;
        const { options } = this;
        const baseFormItemsSetting = {
            site: {
                id: 'site',
                span: 2,
                options: {
                    initialValue: '',
                    rules: [{
                        required: siteDisabled,
                        message: '请选择站点'
                    }]
                },
                disabledShowAllSite: false,
                onChange: this.siteChange
            },
            app: {
                id: 'app',
                span: 3,
                options: {
                    initialValue: 'gateway',
                    rules: [{
                        required: true,
                        message: '应用必选'
                    }]
                },
                style: { display: 'none' }
            },
            service: {
                id: 'service',
                span: 3,
                options: {
                    initialValue: '',
                    rules: [{
                        required: serviceNameOrMethodNameDisabled,
                        message: '服务名必选'
                    }]
                },
                onChange: this.serviceChange
            },
            method: {
                id: 'method',
                span: 3,
                options: {
                    initialValue: '',
                    rules: [{
                        required: serviceNameOrMethodNameDisabled,
                        message: '方法名必选'
                    }]
                }
            },
            rangeTime: {
                span: 4,
                options: {
                    initialValue: [],
                    rules: [
                        {
                            type: 'array',
                            required: !datePickerDisabled,
                            message: '请输入当前时间范围'
                        },
                        {
                            validator: this.validateToReferenceTime
                        }
                    ]
                },
                extraProps: {
                    onOk: this.handleCurrentTimeRangeChange
                }
            },
            button: {
                span: 1
            }
        };
        const selectComponent = (<Select onChange={this.changeSelect}>
            {
                options.map((item, index) => {
                    return (<Option value={item.value} key={item.value}>{item.text}</Option>);
                })
            }
        </Select>);
        const extraFormItem = [
            {
                span: 2,
                id: 'referenceTime',
                options: {
                    initialValue: moment().subtract(1, 'day').set({
                        hour: 0,
                        minute: 0,
                        second: 0,
                        millisecond: 0
                    }),
                    rules: [
                        { required: true, message: '请输入参考时间' },
                        {
                            validator: this.validateToCurrentTime
                        }
                    ]
                },
                component: <DatePicker
                    placeholder="选择时间"
                    onChange={this.handleConfirmBlur}
                />
            },
            {
                span: 2,
                id: 'refresh',
                options: {
                    initialValue: ''
                },
                component: selectComponent
            },
            {
                span: 3,
                label: '自动更新',
                id: 'autoRefresh',
                options: {
                    valuePropName: 'checked',
                    initialValue: false
                },
                component: <Switch onChange={this.changeSwitch}/>
            }
        ];
        return (
            <div>
                <QueryForm className={styles.inlinForm} wrappedComponentRef={(ref) => { this.historyRef = ref; }} baseFormItemsSetting={baseFormItemsSetting} extraFormItem={extraFormItem} onSubmit={this.getHistoryisInfo} />
                <Row gutter={16}>
                    <Col span={18}>
                        <HistoryCompareLine
                            xAxis1={currentIndicatorsXAxisArr}
                            xAxis2={threeDayIndicatorsXAxisArr}
                            xAxis3={referenceIndicatorsXAxisArr}
                            series1={currentIndicatorsQpsArr}
                            series2={threeDayIndicatorsQpsArr}
                            series3={referenceIndicatorsQpsArr}
                        />
                    </Col>
                    <Col span={6}>
                        <TotalCompare series1={[todayTotal]} series2={[threeDayTotal]} series3={[referenceTotal]} referenceLegend={referenceLegend} />
                    </Col>
                </Row>
            </div>
        );
    }
}

export default withRef(HistoryCompare);
