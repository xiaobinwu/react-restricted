import React, { Component } from 'react';
import { Tabs } from 'antd';
import SiteFlow from './siteFlow';
import SiteOverview from './siteOverview';
import HistoryCompare from './historyCompare';

const { TabPane } = Tabs;

class InterfaceInfoList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            activeKey: '1'
        };
    }
    onChange = (activeKey) => {
        this.setState({
            activeKey
        });
    }
    render() {
        const { activeKey } = this.state;
        return (
            <div>
                <Tabs activeKey={activeKey} onChange={this.onChange}>
                    <TabPane tab="流量概览" key="1">
                        <SiteOverview activeKey={activeKey} />
                    </TabPane>
                    <TabPane tab="接口流量" key="2">
                        <SiteFlow activeKey={activeKey} />
                    </TabPane>
                    <TabPane tab="历史对比" key="3">
                        <HistoryCompare activeKey={activeKey} />
                    </TabPane>
                </Tabs>
            </div>
        );
    }
}

export default InterfaceInfoList;
