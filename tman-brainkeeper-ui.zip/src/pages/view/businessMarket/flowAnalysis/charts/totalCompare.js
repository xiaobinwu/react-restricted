import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class TotalCompare extends Component {
    render() {
        const {
            series1,
            series2,
            series3,
            referenceLegend
        } = this.props;
        const options = {
            title: {
                text: '调用量对比',
                textStyle: {
                    fontStyle: '18px'
                }
            },
            tooltip: {
                trigger: 'axis',
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '50',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['当前', '近三天', referenceLegend]
            },
            xAxis: [{
                type: 'category',
                axisLabel: {
                    show: false
                },
                data: ['调用量对比']
            }],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series: [
                {
                    name: '当前',
                    type: 'bar',
                    data: series1
                },
                {
                    name: '近三天',
                    type: 'bar',
                    data: series2
                },
                {
                    name: referenceLegend,
                    type: 'bar',
                    data: series3
                }
            ]
        };
        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%' }}/>
            </div>
        );
    }
}
