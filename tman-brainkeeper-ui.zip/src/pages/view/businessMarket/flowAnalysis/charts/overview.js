import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Overview extends Component {
    render() {
        const {
            xAxis,
            series,
            legend
        } = this.props;
        const options = {
            tooltip: {
                trigger: 'axis',
            },
            grid: {
                left: '40px',
                right: '20px',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: legend
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: xAxis
                }
            ],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%' }} />
            </div>
        );
    }
}
