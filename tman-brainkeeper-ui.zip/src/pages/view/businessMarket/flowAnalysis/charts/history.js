import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class HistoryCompareLine extends Component {
    render() {
        const {
            xAxis1,
            xAxis2,
            xAxis3,
            series1,
            series2,
            series3
        } = this.props;
        const options = {
            tooltip: {
                trigger: 'axis',
            },
            grid: {
                left: '80px',
                right: '20px'
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['当前QPS', '近3天QPS均值', '参考QPS']
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty',
                xAxisIndex: [0, 1, 2]
            }],
            xAxis: [
                {
                    type: 'category',
                    data: xAxis1
                },
                {
                    type: 'category',
                    show: false,
                    data: xAxis2
                },
                {
                    type: 'category',
                    show: false,
                    data: xAxis3
                }
            ],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series: [
                {
                    name: '当前QPS',
                    type: 'line',
                    xAxisIndex: 0,
                    smooth: true,
                    data: series1
                },
                {
                    name: '近3天QPS均值',
                    type: 'line',
                    smooth: true,
                    xAxisIndex: 1,
                    data: series2,
                    lineStyle: {
                        type: 'dotted',
                        width: 0.5
                    }
                },
                {
                    name: '参考QPS',
                    type: 'line',
                    smooth: true,
                    data: series3,
                    xAxisIndex: 2,
                    lineStyle: {
                        type: 'dotted',
                        width: 0.5
                    }
                }
            ]
        };
        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%' }}/>
            </div>
        );
    }
}
