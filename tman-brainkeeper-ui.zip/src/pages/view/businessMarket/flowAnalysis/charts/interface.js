import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Interface extends Component {
    chartReady = (echartObj) => {
        // 需要设置y坐标轴颜色
        echartObj.setOption({
            yAxis: [
                {
                    axisLine: {
                        lineStyle: {
                            color: echartObj.getModel().getSeriesByIndex(0).getData().getVisual('color')
                        }
                    }
                },
                {
                    axisLine: {
                        lineStyle: {
                            color: echartObj.getModel().getSeriesByIndex(1).getData().getVisual('color')
                        }
                    }
                }
            ]
        });
    }
    render() {
        const {
            xAxis,
            series1,
            series2,
            series3
        } = this.props;
        const options = {
            tooltip: {
                trigger: 'axis',
            },
            grid: {
                left: '100px',
                right: '20px'
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['耗时', 'QPS', '每秒错误数']
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            xAxis: [
                {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    data: xAxis
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '耗时(ms)',
                    position: 'left',
                    min: 0,
                    max: (value) => {
                        if (value.max <= 10) {
                            return 10;
                        }
                        return value.max * 1.5;
                    },
                    axisLabel: {
                        formatter: '{value}'
                    }
                },
                {
                    type: 'value',
                    name: 'QPS',
                    position: 'left',
                    offset: 50,
                    min: 0,
                    max: (value) => {
                        if (value.max <= 10) {
                            return 10;
                        }
                        return value.max;
                    },
                    axisLabel: {
                        formatter: '{value}'
                    }
                }
            ],
            series: [
                {
                    name: '耗时',
                    type: 'line',
                    smooth: true,
                    data: series1
                },
                {
                    name: 'QPS',
                    type: 'line',
                    smooth: true,
                    yAxisIndex: 1,
                    data: series2
                },
                {
                    name: '每秒错误数',
                    type: 'line',
                    smooth: true,
                    data: series3,
                    yAxisIndex: 1,
                    itemStyle: {
                        color: '#CC3333'
                    },
                    lineStyle: {
                        color: '#CC3333'
                    }
                },
            ]
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 500, width: '100%' }}
                    onChartReady={this.chartReady}/>
            </div>
        );
    }
}
