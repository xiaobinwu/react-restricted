import React, { Component } from 'react';
import { Card, Col, Row, Icon } from 'antd';
import { monitorService, businessMarketService } from 'service';
import moment from 'moment';
import { formatAmount, isNotEmptyObject } from 'js/util';
import AreaStack from './charts/areaStack';
import Pay from './charts/pay';
import Pie from './charts/pie';
import HeaderChart from './charts/headerChart';
import styles from './index.css';

const formatDate = 'YYYY-MM-DD HH:mm:ss';

class Overview extends Component {
    constructor(props) {
        super(props);
        this.state = {
            trends: {},
            pays: {},
            pies: [],
            loginToday: 0,
            loginYesterday: 0,
            registerToday: 0,
            registerYesterday: 0
        };
    }
    componentDidMount() {
        this.getTrendList();
        this.getPayOverview();
        this.getTrafficstat();
    }
    // 获取登录、注册趋势的配置
    getTrendList = async () => {
        const trends = {};
        const { entry, code } = await monitorService.getBusinessReport();
        if (code === '0') {
            const cartXAxisArr = [];
            const cartTotals = [];
            entry.cartHistory && Object.keys(entry.cartHistory).sort((a, b) => {
                return new Date(b).valueOf() - new Date(a).valueOf();
            }).forEach((item, index) => {
                cartXAxisArr.push(item);
                cartTotals.push(entry.cartHistory[item]);
            });
            trends.cart = {
                title: '添加购物车趋势',
                xAxisArr: cartXAxisArr.reverse(),
                totals: cartTotals.reverse()
            };
            const loginXAxisArr = [];
            const loginTotals = [];
            entry.loginHistory && Object.keys(entry.loginHistory).sort((a, b) => {
                return new Date(b).valueOf() - new Date(a).valueOf();
            }).forEach((item, index) => {
                loginXAxisArr.push(item);
                loginTotals.push(entry.loginHistory[item]);
            });
            trends.login = {
                title: '登录趋势',
                xAxisArr: loginXAxisArr.reverse(),
                totals: loginTotals.reverse()
            };
            const regXAxisArr = [];
            const regTotals = [];
            entry.regHistory && Object.keys(entry.regHistory).sort((a, b) => {
                return new Date(b).valueOf() - new Date(a).valueOf();
            }).forEach((item, index) => {
                regXAxisArr.push(item);
                regTotals.push(entry.regHistory[item]);
            });
            trends.reg = {
                title: '注册趋势',
                xAxisArr: regXAxisArr.reverse(),
                totals: regTotals.reverse()
            };
            this.setState({
                trends,
                loginToday: entry['login-today'],
                loginYesterday: entry['login-yesterday'],
                registerToday: entry['register-today'],
                registerYesterday: entry['register-yesterday']
            });
        }
    }
    // 获取首行统计
    getTrafficstat = async () => {
        const startEventTime = moment().set({ hour: 0, minute: 0, second: 0 }).format(formatDate);
        const endEventTime = moment().format(formatDate);
        const { entry, code } = await businessMarketService.getTrafficstat({ startEventTime, endEventTime });
        const series = [];
        if (code === '0') {
            Object.keys(entry.site).forEach((item, index) => {
                series.push({
                    value: entry.site[item], name: item
                });
            });
            this.setState({
                pies: series
            });
        }
    }
    // 支付概览
    getPayOverview = async () => {
        const params = {
            pageNum: 1,
            pageSize: 7,
            platForm: 'ALL',
            site: 'GB'
        };
        const { entry, code } = await monitorService.getOrderReportList(params);
        const orderCounts = [];
        const orderPayCounts = [];
        const orderPayAmounts = [];
        const orderPayRates = [];
        const dates = [];
        if (code === '0' && entry.list) {
            entry.list.reverse();
            entry.list.forEach((item, index) => {
                orderCounts.push(item.orderCount);
                orderPayCounts.push(item.orderPayCount);
                orderPayRates.push((item.orderPayRate * 100).toFixed(2));
                orderPayAmounts.push((item.orderPayAmount / 100).toFixed(4));
                dates.push(item.createDate);
            });
            this.setState({
                pays: {
                    orderCounts,
                    orderPayCounts,
                    orderPayAmounts,
                    orderPayRates,
                    dates
                }
            });
        }
    }
    render() {
        const {
            trends,
            pays,
            pies,
            loginToday,
            loginYesterday,
            registerToday,
            registerYesterday
        } = this.state;
        const loginDiff = loginToday - loginYesterday;
        const registerDiff = registerToday - registerYesterday;
        return (
            <div>
                <Row gutter={20}>
                    <Col span={8}>
                        <Card bordered={false} className={`${styles.cardBody} system-overview-border-color`}>
                            <div className={styles.cardTitle}>
                                今日站点流量
                            </div>
                            <Pie series={pies}/>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card bordered={false} className={`${styles.cardBody} system-overview-border-color`}>
                            <div className={styles.cardTitle}>
                                今日登录用户数
                            </div>
                            <div className={styles.cardContent}>
                                <span className={styles.cardMain}>{formatAmount(loginToday, 0)}</span>
                            </div>
                            <div className={styles.cardContentMessage}>
                                <Row>
                                    <Col span={12} style={{ textAlign: 'center' }}>
                                        <span>增量</span>
                                        <Icon type={loginDiff > 0 ? 'rise' : 'fall'} theme="outlined" className={loginDiff > 0 ? styles.sucessIcon : styles.errorIcon} />
                                        <span className={styles.equ}>{loginDiff}</span>
                                    </Col>
                                    <Col span={12} style={{ textAlign: 'center' }}>
                                        <span>同比</span>
                                        <Icon type={loginDiff > 0 ? 'rise' : 'fall'} theme="outlined" className={loginDiff > 0 ? styles.sucessIcon : styles.errorIcon} />
                                        <span className={styles.equ}>{((loginDiff ? ((loginYesterday ? (loginToday / loginYesterday) : 1) - 1) : 0) * 100).toFixed(2)}%</span>
                                    </Col>
                                </Row>
                                {/* TODO */}
                                {
                                    isNotEmptyObject(trends) ? <HeaderChart xAxis={trends.login.xAxisArr} series={trends.login.totals} type="bar"/> : null
                                }
                            </div>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card bordered={false} className={`${styles.cardBody} system-overview-border-color`}>
                            <div className={styles.cardTitle}>
                                今日注册用户数
                            </div>
                            <div className={styles.cardContent}>
                                <span className={styles.cardMain}>{formatAmount(registerToday, 0)}</span>
                            </div>
                            <div className={styles.cardContentMessage}>
                                <Row>
                                    <Col span={12} style={{ textAlign: 'center' }}>
                                        <span>增量</span>
                                        <Icon type={registerDiff > 0 ? 'rise' : 'fall'} theme="outlined" className={registerDiff > 0 ? styles.sucessIcon : styles.errorIcon} />
                                        <span className={styles.equ}>{registerDiff}</span>
                                    </Col>
                                    <Col span={12} style={{ textAlign: 'center' }}>
                                        <span>同比</span>
                                        <Icon type={registerDiff > 0 ? 'rise' : 'fall'} theme="outlined" className={registerDiff > 0 ? styles.sucessIcon : styles.errorIcon} />
                                        <span className={styles.equ}>{((registerDiff ? ((registerYesterday ? (registerToday / registerYesterday) : 1) - 1) : 0) * 100).toFixed(2)}%</span>
                                    </Col>
                                </Row>
                                {/* TODO */}
                                {
                                    isNotEmptyObject(trends) ? <HeaderChart xAxis={trends.reg.xAxisArr} series={trends.reg.totals} type="line"/> : null
                                }
                            </div>
                        </Card>
                    </Col>
                </Row>
                {
                    isNotEmptyObject(pays) ? <Row gutter={20} style={{ marginBottom: 20 }}><Col span={24}><Card className={styles.cardNoPadding} title="支付概览" bordered={false}>
                        <Pay xAxis={pays.dates} series1={pays.orderCounts} series2={pays.orderPayCounts} series3={pays.orderPayAmounts} series4={pays.orderPayRates} />
                    </Card></Col></Row> : null
                }
                {
                    isNotEmptyObject(trends) ? <Row gutter={20}>
                        {
                            Object.keys(trends).map((item, index) => {
                                return <Col span={8} key={index}>
                                    <Card title={trends[item].title} bordered={false} className={styles.cardNoPadding}>
                                        <AreaStack xAxis={trends[item].xAxisArr} data={trends[item].totals} />
                                    </Card>
                                </Col>;
                            })
                        }
                    </Row> : null
                }
            </div>
        );
    }
}

export default Overview;
