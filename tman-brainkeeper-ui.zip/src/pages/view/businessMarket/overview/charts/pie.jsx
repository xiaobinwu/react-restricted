import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';
import { formatAmount } from 'js/util';

export default class Pie extends Component {
    render() {
        const {
            series
        } = this.props;
        const options = {
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'item',
                formatter: (params, ticket, callback) => {
                    return `${params.seriesName}<br/> ${params.name} : ${formatAmount(params.value, 0)} (${params.percent}%)`;
                }
            },
            series: [
                {
                    name: '站点流量',
                    type: 'pie',
                    radius: '55%',
                    center: ['50%', '50%'],
                    data: series,
                    itemStyle: {
                        emphasis: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 203, width: '100%' }}/>
            </div>
        );
    }
}
