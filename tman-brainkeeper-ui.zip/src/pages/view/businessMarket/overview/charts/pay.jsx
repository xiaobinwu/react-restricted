import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Pay extends Component {
    render() {
        const {
            xAxis,
            series1,
            series2,
            series3,
            series4
        } = this.props;
        const options = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                },
                formatter: '{a0}: {c0}<br />{a1}: {c1}<br />{a2}: {c2}<br />{a3}: {c3}%'
            },
            grid: {
                left: '100px',
                right: '50px'
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['订单数', '订单支付数', '订单支付金额（单位：百/美元）', '订单支付率']
            },
            xAxis: [
                {
                    type: 'category',
                    data: xAxis,
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    splitLine: {
                        show: false
                    },
                },
                {
                    type: 'value',
                    min: 0,
                    max: 100,
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        formatter: '{value} %'
                    }
                }
            ],
            series: [
                {
                    name: '订单数',
                    type: 'bar',
                    barGap: '5%',
                    data: series1
                },
                {
                    name: '订单支付数',
                    type: 'bar',
                    barGap: '5%',
                    data: series2
                },
                {
                    name: '订单支付金额（单位：百/美元）',
                    type: 'bar',
                    barGap: '5%',
                    data: series3
                },
                {
                    name: '订单支付率',
                    type: 'line',
                    yAxisIndex: 1,
                    data: series4
                }
            ]
        };

        return (
            <div style={{ width: '100%' }}>
                <ReactEcharts
                    option={options}
                    style={{ height: 450, width: '100%' }} />
            </div>
        );
    }
}
