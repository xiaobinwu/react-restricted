import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class AreaStack extends Component {
    render() {
        const {
            xAxis,
            data,
        } = this.props;
        const options = {
            tooltip: {
                trigger: 'axis',
            },
            grid: {
                left: '40px',
                right: '20px',
                bottom: '20px',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true }
                }
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            xAxis: [
                {
                    type: 'category',
                    boundaryGap: false,
                    data: xAxis,
                    axisLabel: {
                        rotate: 45
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value'
                }
            ],
            series: [{
                data,
                type: 'line',
                areaStyle: {}
            }]
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 325, width: '100%' }} />
            </div>
        );
    }
}
