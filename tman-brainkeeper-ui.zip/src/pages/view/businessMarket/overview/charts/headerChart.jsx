import React, { Component } from 'react';
import PropTypes from 'prop-types';
import ReactEcharts from 'component/echarts-for-react';

export default class HeaderChart extends Component {
    chartReady = (echartObj) => {
        const { area, type } = this.props;
        const color = type === 'line' ? echartObj._theme.color[3] : echartObj._theme.color[2];
        echartObj.setOption({
            series: [{
                ...(area ? { areaStyle: { color } } : {}),
                lineStyle: {
                    color
                },
                itemStyle: {
                    color
                }
            }]
        });

    }
    render() {
        const {
            xAxis,
            series,
            type
        } = this.props;
        const options = {
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'axis'
            },
            grid: {
                left: 0,
                right: 0,
                bottom: 0,
                top: 0
            },
            xAxis: {
                type: 'category',
                show: false,
                axisLabel: {
                    show: false
                },
                splitLine: {
                    show: false
                },
                data: xAxis // x轴
            },
            yAxis: {
                type: 'value',
                show: false,
                splitLine: {
                    show: false
                },
                axisLabel: {
                    show: false
                }
            },
            series: [{
                data: series, // 数据
                type,
                smooth: true,
                symbolSize: 0
            }]
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{
                        height: 60,
                        width: '100%',
                        marginTop: 30,
                        marginBottom: 15
                    }}
                    onChartReady={this.chartReady}
                />
            </div>
        );
    }
}
HeaderChart.propTypes = {
    type: PropTypes.oneOf(['line', 'bar'])
};

HeaderChart.defaultProps = {
    area: true,
    type: 'line'
};
