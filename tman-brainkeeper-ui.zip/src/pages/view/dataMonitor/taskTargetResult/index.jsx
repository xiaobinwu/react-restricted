import React, { Component } from 'react';
import { Button, Table, message, Modal } from 'antd';
import { monitorService } from 'service';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import withFormModal from 'component/hoc/withFormModal';
import { getQueryString, deepCopy } from 'js/util';
import TaskTargetForm from './taskTargetForm';

const { confirm } = Modal;

const defaultTaskTargetFormOptions = {
    id: '',
    name: '',
    columnName: '',
    comparatorType: '',
    value: '',
    secValue: '',
    descr: ''
};

const comparatorSet = {
    GT: '大于',
    GTE: '大于等于',
    LT: '小于',
    LTE: '小于等于',
    EQ: '等于',
    NEQ: '不等于',
    NONE: '数据展示',
    RANK: '范围'
};

// 添加/修改任务
const TaskTargetFormModal = withFormModal(TaskTargetForm);

class TaskTargetResult extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            currentJobId: 0,
            taskTargetForm: deepCopy(defaultTaskTargetFormOptions),
            taskTargetVisible: false,
            taskTargetConfirmLoading: false
        };
    }
    componentDidMount() {
        const result = getQueryString();
        this.setState({
            currentJobId: result.id
        }, () => {
            this.getTaskTargetlist();
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getTaskTargetlist();
            });
        }
    }
    // 获取管理结果列表数据
    getTaskTargetlist = async (e) => {
        e && e.preventDefault();
        const { pagination, currentJobId } = this.state;
        this.setState({
            loading: true
        });
        const params = { jobSqlId: currentJobId, ...pagination };
        delete params.totalCount;
        const { entry, code } = await monitorService.getTaskTargetlist(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 新增修改目标结果管理
    setTaskTargetSend = async () => {
        this.setState({
            taskTargetConfirmLoading: true
        });
        const params = { ...this.taskTargetFormRef.props.form.getFieldsValue(), id: this.state.taskTargetForm.id };
        const res = await monitorService.setTaskTargetSend(params);
        if (res.code === '0') {
            this.setState({
                taskTargetConfirmLoading: false,
                taskTargetVisible: false
            }, () => {
                message.success(res.entry);
                this.taskTargetFormRef.props.form.resetFields();
                this.getTaskTargetlist();
            });
        } else {
            this.setState({
                taskTargetConfirmLoading: false
            });
        }
    }
    // 新增修改目标结果管理Modal
    setTaskTarget = (record) => {
        const { currentJobId } = this.state;
        let taskTargetFormObj = {};
        if (record) {
            taskTargetFormObj = {
                id: record.id,
                jobSqlId: currentJobId,
                name: record.name,
                columnName: record.columnName,
                comparatorType: record.comparatorType,
                value: record.value,
                secValue: record.secValue,
                descr: record.descr
            };
        } else {
            taskTargetFormObj = deepCopy(defaultTaskTargetFormOptions);
            taskTargetFormObj.jobSqlId = currentJobId;
        }
        this.setState({
            taskTargetForm: taskTargetFormObj,
            taskTargetVisible: true
        });
    }
    // 删除目标结果管理
    deleteTaskTarget = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.deleteTaskTarget({ id });
                    if (res.code === '0') {
                        message.success(res.message);
                        that.getTaskTargetlist();
                    }
                })();
            }
        });
    }
    // 获取目标管理任务ref
    getTaskTargetFormRef = (ref) => {
        this.taskTargetFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.taskTargetFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            taskTargetForm,
            taskTargetVisible,
            taskTargetConfirmLoading
        } = this.state;
        const columns = [{
            title: '名称',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '列名',
            dataIndex: 'columnName',
            key: 'columnName'
        }, {
            title: '关系',
            dataIndex: 'comparatorType',
            key: 'comparatorType',
            render: (text, record) => {
                return comparatorSet[text];
            }
        }, {
            title: '目标值1',
            dataIndex: 'value',
            key: 'value'
        }, {
            title: '目标值2',
            dataIndex: 'secValue',
            key: 'secValue'
        }, {
            title: '描述',
            dataIndex: 'descr',
            key: 'descr'
        }, {
            title: '操作',
            key: 'action',
            render: (text, record) => {
                const layout = { marginRight: '10px', marginBottom: '10px' };
                return (
                    <div>
                        <Button type="primary" size="small" style={layout} onClick={this.setTaskTarget.bind(this, record)}>修改</Button>
                        <Button type="primary" size="small" style={layout} onClick={this.deleteTaskTarget.bind(this, record)}>删除</Button>
                    </div>
                );
            }
        }];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <div style={{ marginBottom: 20 }}>
                    <Link to={{ pathname: this.props.paths.Task.linkPath }}> <Button type="primary" style={{ marginRight: 20 }}>返回任务管理列表</Button></Link>
                    <Button type="primary" onClick={this.setTaskTarget}>添加比较参数</Button>
                </div>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <TaskTargetFormModal
                    maskClosable={false}
                    injectForm={taskTargetForm}
                    getRef={this.getTaskTargetFormRef}
                    title="任务添加/修改"
                    visible={taskTargetVisible}
                    onOk={this.setTaskTargetSend}
                    onCancel={this.handleCancel.bind(this, 'taskTargetVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={taskTargetConfirmLoading} onClick={this.setTaskTargetSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        comparatorSet
                    }}
                />
            </div>
        );
    }
}


const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(TaskTargetResult);
