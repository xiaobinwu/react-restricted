import React, { Component } from 'react';
import { Form, Select, Input } from 'antd';

const FormItem = Form.Item;
const { Option } = Select;

class TaskTargetForm extends Component {
    constructor(props) {
        super(props);
        const comparatorTypeSet = [];
        const { comparatorSet } = this.props;
        for (const i in comparatorSet) {
            comparatorTypeSet.push(<Option value={i} key={i}>{ comparatorSet[i] }</Option>);
        }
        this.state = {
            comparatorTypeSet
        };
    }
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const { comparatorTypeSet } = this.state;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        getFieldDecorator('jobSqlId', { initialValue: injectForm.jobSqlId });
        return (
            <Form>
                <FormItem label="中文名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                    })(<Input />)}
                </FormItem>
                <FormItem label="字段名称" {...formItemLayout}>
                    {getFieldDecorator('columnName', {
                        initialValue: injectForm.columnName,
                    })(<Input />)}
                </FormItem>
                <FormItem label="比较类型" {...formItemLayout}>
                    {getFieldDecorator('comparatorType', {
                        initialValue: injectForm.comparatorType,
                    })(<Select placeholder="请选择比较类型">
                        { comparatorTypeSet }
                    </Select>)}
                </FormItem>
                <FormItem label="目标值1" {...formItemLayout}>
                    {getFieldDecorator('value', {
                        initialValue: injectForm.value,
                    })(<Input />)}
                </FormItem>
                <FormItem label="目标值2" {...formItemLayout}>
                    {getFieldDecorator('secValue', {
                        initialValue: injectForm.secValue,
                    })(<Input />)}
                </FormItem>
                <FormItem label="备注" {...formItemLayout}>
                    {getFieldDecorator('descr', {
                        initialValue: injectForm.descr,
                    })(<Input />)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(TaskTargetForm);
