import React, { Component } from 'react';
import { Input, Select, Row, Col, Button, Table, Tooltip, Divider } from 'antd';
import { monitorService } from 'service';

const { Option } = Select;

class BillResult extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            eventType: '',
            metric: '',
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            }
        };
    }
    componentDidMount() {
        this.getData();
    }
    // 操作类型
    changeSelect = (value) => {
        this.setState({
            eventType: value
        });
    }
    // 维度任务
    changeMetric = (e) => {
        this.setState({
            metric: e.target.value.replace(/(^\s*)|(\s*$)/g, '')
        });
    }
    // 获取数据
    getData = async (e) => {
        e && e.preventDefault();
        const {
            pagination,
            metric,
            eventType
        } = this.state;
        const params = {
            metric,
            eventType,
            ...pagination
        };
        delete params.totalCount;
        this.setState({
            loading: true
        });
        const { entry, code } = await monitorService.getSeerList(params);
        entry.list && entry.list.forEach((item, index) => {
            item.key = `${item.dbName}-${index}`;
        });
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    render() {
        const {
            pagination,
            loading,
            data
        } = this.state;
        const columns = [{
            title: '库名',
            dataIndex: 'dbName',
            key: 'dbName'
        }, {
            title: '表名',
            dataIndex: 'tbName',
            key: 'tbName'
        }, {
            title: '操作类型',
            dataIndex: 'eventType',
            key: 'eventType',
            render: (text) => {
                if (text === 'INSERT') {
                    return '新增';
                }
                return '修改';
            }
        }, {
            title: '任务',
            dataIndex: 'metric',
            key: 'metric'
        }, {
            title: '任务描述',
            dataIndex: 'description',
            key: 'description'
        }, {
            title: '事件时间',
            dataIndex: 'timestamp',
            key: 'timestamp'
        }, {
            title: '告警时间',
            dataIndex: 'createdTime',
            key: 'createdTime'
        }, {
            title: '源',
            dataIndex: 'origin',
            key: 'origin',
            render: (text, record) => {
                const obj = JSON.parse(text);
                const contentView = [];
                for (const key in obj) {
                    contentView.push(<div key={key}><span>{key}：</span><span>{obj[key]}</span></div>);
                }
                const content = (
                    <div style={{ padding: '10px' }}>
                        { contentView }
                    </div>
                );
                return (
                    <Tooltip placement="left" title={content}>
                        <a href="javascript:void(0);">查看</a>
                    </Tooltip>
                );
            }
        }, {
            title: '目标',
            dataIndex: 'targets',
            key: 'targets',
            render: (text, record) => {
                const arr = JSON.parse(text);
                const contentView = [];
                if (arr.length > 0) {
                    arr.forEach((item, index) => {
                        for (const key in item) {
                            contentView.push(<div key={`${key}-${index}`}><span>{key}：</span><span>{JSON.stringify(item[key])}</span></div>);
                        }
                        if (index !== arr.length - 1) {
                            contentView.push(<Divider key={index} style={{ margin: '5px 0' }}/>);
                        }
                    });
                }
                const content = (
                    <div style={{ padding: '10px' }}>
                        { contentView }
                    </div>
                );
                return (
                    <Tooltip placement="left" title={content}>
                        <a href="javascript:void(0);">查看</a>
                    </Tooltip>
                );
            }
        }];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 30 }}>
                    <Col span={4}>
                        <Select placeholder="请选择操作类型" onChange={this.changeSelect} style={{ width: '100%' }}>
                            <Option value="">全部</Option>
                            <Option value="INSERT">新增</Option>
                            <Option value="UPDATE">修改</Option>
                        </Select>
                    </Col>
                    <Col span={6}>
                        <Input onChange={this.changeMetric} placeholder="请填写任务"/>
                    </Col>
                    <Col span={14}>
                        <Button icon="search" type="primary" onClick={this.getData}>查询</Button>
                    </Col>
                </Row>
                <Table
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
            </div>
        );
    }
}

export default BillResult;
