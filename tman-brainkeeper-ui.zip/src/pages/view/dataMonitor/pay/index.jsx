import React, { Component } from 'react';
import { Form, Row, Col, Table, DatePicker, Button, Modal, message, Select } from 'antd';
import { monitorService, systemManagementService } from 'service';
import withPermission from 'component/hoc/withPermission';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { confirm } = Modal;
const { Option } = Select;

class PayReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            siteList: [],
            pagination: {
                pageNum: 1,
                pageSize: 10,
                totalCount: 0
            },
            orderCounts: [],
            orderPayRates: [],
            orderPayAmounts: [],
            dates: []
        };
    }
    componentDidMount() {
        this.getSiteList();
        this.getData();
    }
    // 获取站点
    getSiteList = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'site' }, true);
        if (code === '0') {
            this.setState({
                siteList: entry
            });
        }
    }
    // 获取数据源列表
    getData = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const { rangeDate, platForm, site } = this.props.form.getFieldsValue();
        let params;
        if (rangeDate) {
            params = {
                ...pagination,
                ...{
                    beginDate: rangeDate[0].format('YYYY-MM-DD'),
                    endDate: rangeDate[1].format('YYYY-MM-DD'),
                    platForm,
                    site
                }
            };
        } else {
            params = { ...pagination, platForm, site };
        }
        delete params.totalCount;
        const { entry, code } = await monitorService.getPayReportList(params);
        entry.list && entry.list.forEach((item, index) => {
            item.key = index;
        });
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 全量导入
    reportCheck = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量导入？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.payReportAllLoad();
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    // 指定时间导入
    loadDate = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量指定时间导入？</p></div>;
        const that = this;
        const { rangeDate } = this.props.form.getFieldsValue();
        let params = {};
        if (rangeDate) {
            params = { ...{ beginDate: rangeDate[0].format('YYYY-MM-DD'), endDate: rangeDate[1].format('YYYY-MM-DD') } };
        }
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.payReportDateLoad({ ...params });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            siteList
        } = this.state;
        const { getFieldDecorator } = this.props.form;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        // orderCount：订单数，orderPayCount：订单支付数，orderAmount：订单金额，orderPayAmount：订单支付金额，orderPayRate:订单支付率，你这里应该还有个时间做x轴
        const columns = [{
            title: '站点',
            dataIndex: 'site',
            key: 'site'
        }, {
            title: '端',
            dataIndex: 'platform',
            key: 'platform',
            render: (text, record) => {
                if (text === 1) {
                    return 'PC';
                } else if (text === 2) {
                    return 'WAP';
                } else if (text === 3) {
                    return 'IOS';
                }
                return 'Android';
            }
        }, {
            title: '日期',
            dataIndex: 'createDate',
            key: 'createDate'
        }, {
            title: '周',
            dataIndex: 'week',
            key: 'week'
        }, {
            title: '内部风控拒绝',
            dataIndex: 'riskNotThird',
            key: 'riskNotThird'
        }, {
            title: '第三方风控拒绝',
            dataIndex: 'riskThird',
            key: 'riskThird',
            render: (text, record) => {
                const riskThird = JSON.stringify(text);
                return riskThird !== '{}' ? riskThird : '';
            }
        }, {
            title: '回调成功时间',
            dataIndex: 'completeDate',
            key: 'completeDate',
            render: (text, record) => {
                const completeDate = JSON.stringify(text);
                if (completeDate !== '{}') {
                    const views = [];
                    for (const i in text) {
                        views.push(<p key={i}>{i} : {text[i]}</p>);
                    }
                    return (
                        <React.Fragment>
                            {views}
                        </React.Fragment>
                    );
                }
                return '';
            }
        }, {
            title: '未支付',
            dataIndex: 'payStatus_0',
            key: 'payStatus_0'
        }, {
            title: '处理中',
            dataIndex: 'payStatus_1',
            key: 'payStatus_1'
        }, {
            title: '已支付',
            dataIndex: 'payStatus_2',
            key: 'payStatus_2'
        }, {
            title: '退款中',
            dataIndex: 'payStatus_3',
            key: 'payStatus_3'
        }, {
            title: '退款成功',
            dataIndex: 'payStatus_4',
            key: 'payStatus_4'
        }, {
            title: '退款失败',
            dataIndex: 'payStatus_5',
            key: 'payStatus_5'
        }, {
            title: '支付失败',
            dataIndex: 'payStatus_6',
            key: 'payStatus_6'
        }, {
            title: '部分退款',
            dataIndex: 'payStatus_7',
            key: 'payStatus_7'
        }, {
            title: '成功率',
            dataIndex: 'payRate',
            key: 'payRate',
            render: (text, record) => {
                return `${(text * 100).toFixed(2)}%`;
            }
        }];
        return (
            <div>
                <Form onSubmit={this.getData} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('platForm', {
                                    initialValue: 'ALL'
                                })(<Select placeholder="请选择端">
                                    {
                                        systemManagementService.getPlatFormsList().map((item, index) => {
                                            return <Option key={item.value}>{item.text}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('site', {
                                    initialValue: 'GB'
                                })(<Select placeholder="请选择站点">
                                    {
                                        siteList.map((item, index) => {
                                            return <Option key={item.key}>{item.key}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeDate')(<RangePicker placeholder={['开始时间', '结束时间']} />)}
                            </FormItem>
                        </Col>
                        <Col span={13}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.reportCheck} style={{ marginRight: '10px' }}>全量导入</Button>, 'PermissionPayReportAllImport')
                                }
                                {
                                    withPermission(<Button type="primary" onClick={this.loadDate}>指定部分时间导入</Button>, 'PermissionPayReportTimeImport')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    loading={loading}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    columns={columns}
                />
            </div>
        );
    }
}

export default Form.create()(PayReport);
