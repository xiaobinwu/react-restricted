import React, { Component } from 'react';
import { monitorService } from 'service';
import { Button, Table, message, Modal } from 'antd';
import withPermission from 'component/hoc/withPermission';
import withFormModal from 'component/hoc/withFormModal';
import { deepCopy } from 'js/util';
import DataSourceForm from './dataSourceForm';
import styles from './index.css';

const { confirm } = Modal;

// 添加/修改任务
const DataSourceFormModal = withFormModal(DataSourceForm);

const defaultDataSourceFormOptions = {
    id: '',
    name: '',
    url: '',
    descr: '',
    prop: '',
    text: [],
    value: [],
    keys: []
};

class DataSoure extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            useJson: false,
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            dataSourcesForm: deepCopy(defaultDataSourceFormOptions),
            dataSourcesVisible: false,
            dataSourcesConfirmLoading: false
        };
    }
    componentDidMount() {
        this.getDataSourceData();
    }
    // 获取数据源列表
    getDataSourceData = async () => {
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination };
        delete params.totalCount;
        const { entry, code } = await monitorService.getDataSource(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getDataSourceData();
            });
        }
    }
    // 更改状态
    execStatus = (record) => {
        const status = record.status === 'NORMAL' ? 'DISABLE' : 'NORMAL';
        const content = <div style={{ marginTop: '20px' }}><p>确认是否变更状态？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.execDataSourceStatus({ id: record.id, status });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getDataSourceData();
                    }
                })();
            }
        });
    }
    // 新增修改数据源管理modal
    setDataSource = (record) => {
        let dataSourceFormObj = {};
        if (record) {
            dataSourceFormObj = {
                id: record.id,
                name: record.name,
                url: record.url,
                descr: record.descr,
                prop: record.prop
            };
            const texts = [];
            const values = [];
            if (record.prop) {
                const props = JSON.parse(record.prop);
                for (const item in props) {
                    texts.push(item);
                    values.push(props[item]);
                }
            }
            dataSourceFormObj.text = texts;
            dataSourceFormObj.value = values;
            dataSourceFormObj.keys = Array.from(new Array(texts.length), (val, index) => index);
        } else {
            dataSourceFormObj = deepCopy(defaultDataSourceFormOptions);
        }
        this.setState({
            dataSourcesForm: dataSourceFormObj,
            dataSourcesVisible: true
        });
    }
    // 保存
    setDataSourceSend = (e) => {
        e.preventDefault();
        const { useJson } = this.state;
        this.dataSourceFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                if (!useJson) {
                    const params = {};
                    const { text, value } = values;
                    text.forEach((item, index) => {
                        if (item) {
                            params[item] = value[index];
                        }
                    });
                    values.prop = JSON.stringify(params);
                }
                delete values.text;
                delete values.value;
                delete values.keys;
                this.setState({
                    dataSourcesConfirmLoading: true
                });
                const params = { ...values, id: this.state.dataSourcesForm.id };
                const res = await monitorService.setDataSourceSend(params);
                if (res.code === '0') {
                    this.setState({
                        dataSourcesConfirmLoading: false,
                        dataSourcesVisible: false
                    }, () => {
                        message.success(res.entry);
                        this.dataSourceFormRef.props.form.resetFields();
                        this.getDataSourceData();
                    });
                } else {
                    this.setState({
                        dataSourcesConfirmLoading: false
                    });
                }
            }
        });
    }
    // 加载连接池
    loadRecord = (record) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否加载{record.name}的连接池？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.loadRecord({ id: record.id });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getDataSourceData();
                    }
                })();
            }
        });
    }
    // 删除
    deleteDataSource = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.deleteDataSource({ id });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getDataSourceData();
                    }
                })();
            }
        });
    }
    // 获取ref
    getDataSourceFormRef = (ref) => {
        this.dataSourceFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.dataSourceFormRef.props.form.resetFields();
        this.setState({
            [type]: false,
            useJson: false
        });
    }
    // 改变是否使用连接池属性JSON
    handleUseJson = (useJson) => {
        this.setState({
            useJson
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            dataSourcesForm,
            dataSourcesVisible,
            dataSourcesConfirmLoading,
            useJson
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '连接池名称',
            dataIndex: 'name',
            key: 'name',
            width: '200px'
        }, {
            title: '连接池url',
            dataIndex: 'url',
            key: 'url',
            render(text) {
                return <div className={styles.url} title={text}>{text}</div>;
            }
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            width: '100px',
            render: (text, record) => {
                return text === 'NORMAL' ? '正常' : '禁用';
            }
        }, {
            title: '连接池描述',
            dataIndex: 'descr',
            key: 'descr',
            width: '250px'
        }, {
            title: '连接池属性',
            dataIndex: 'prop',
            key: 'prop',
            render(text) {
                return <div className={styles.prop} title={text}>{text}</div>;
            }
        }, {
            title: '操作',
            key: 'action',
            render: (text, record) => {
                const layout = { marginRight: '10px', marginBottom: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setDataSource.bind(this, record)}>修改</Button>, 'PermissionDataSourceEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteDataSource.bind(this, record)}>删除</Button>, 'PermissionDataSourceDelete')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.execStatus.bind(this, record)}>{ record.status === 'NORMAL' ? '禁用' : '启用'}</Button>, 'PermissionDataSourceStatus')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.loadRecord.bind(this, record)}>加载连接池</Button>, 'PermissionDataSourceLoad')
                        }
                    </div>
                );
            }
        }];
        return (
            <div>
                {
                    withPermission(<Button type="primary" onClick={this.setDataSource} style={{ marginBottom: 20 }}>添加数据源</Button>, 'PermissionDataSourceAdd')
                }
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <DataSourceFormModal
                    maskClosable={false}
                    injectForm={dataSourcesForm}
                    getRef={this.getDataSourceFormRef}
                    title="连接池/修改"
                    visible={dataSourcesVisible}
                    onOk={this.setDataSourceSend}
                    onCancel={this.handleCancel.bind(this, 'dataSourcesVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={dataSourcesConfirmLoading} onClick={this.setDataSourceSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        useJson,
                        handleUseJson: this.handleUseJson
                    }}
                />
            </div>
        );
    }
}

export default DataSoure;
