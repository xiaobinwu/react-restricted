import React, { Component } from 'react';
import { Row, Col, Form, Input, Checkbox, Button, Icon } from 'antd';

const FormItem = Form.Item;

let uuid = 0;
class DataSourceForm extends Component {
    // 添加
    add = () => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        const nextKeys = keys.concat(uuid);
        uuid++; // eslint-disable-line
        form.setFieldsValue({
            keys: nextKeys
        });
    }
    // 删除
    remove = (k) => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        if (keys.length === 1) {
            return;
        }
        form.setFieldsValue({
            keys: keys.filter(key => key !== k)
        });
    }
    onCheckboxChange = (e) => {
        const { handleUseJson } = this.props;
        handleUseJson(e.target.checked);
    }
    render() {
        const {
            form,
            injectForm,
            useJson
        } = this.props;
        const { getFieldDecorator, getFieldValue } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 6 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 }
            }
        };
        const formItemLayoutWithOutLabel = {
            wrapperCol: {
                xs: { span: 24, offset: 0 },
                sm: { span: 20, offset: 6 }
            }
        };
        getFieldDecorator('keys', { initialValue: injectForm.keys });
        const keys = getFieldValue('keys');
        const formItems = keys.map((k, index) => {
            return (
                <FormItem
                    label={`连接池属性${index}`}
                    {...formItemLayout}
                    key={index}
                >
                    <Row>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayoutWithOutLabel}
                                required={false}
                            >
                                {getFieldDecorator(`text[${k}]`, {
                                    initialValue: injectForm.text[k],
                                    validateTrigger: ['onChange', 'onBlur'],
                                    rules: [{
                                        required: true,
                                        whitespace: true,
                                        message: 'key不为空',
                                    }],
                                })(<Input placeholder="key" disabled={useJson} />)}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayoutWithOutLabel}
                                required={false}
                            >
                                {getFieldDecorator(`value[${k}]`, {
                                    initialValue: injectForm.value[k],
                                    validateTrigger: ['onChange', 'onBlur'],
                                    rules: [{
                                        required: true,
                                        whitespace: true,
                                        message: 'value不为空',
                                    }],
                                })(<Input placeholder="value" disabled={useJson} />)}
                            </FormItem>
                        </Col>
                        <Col span={8} style={{ textAlign: 'center' }}>
                            <Button type="primary" size="small" onClick={() => this.remove(k)} style={{ width: '60%' }} disabled={useJson}>
                                删除
                            </Button>
                        </Col>
                    </Row>
                </FormItem>
            );
        });
        return (
            <Form>
                <FormItem label="连接池名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true,
                            whitespace: true,
                            message: '连接池名称不为空',
                        }],
                    })(<Input />)}
                </FormItem>

                <FormItem label="连接池url" {...formItemLayout}>
                    {getFieldDecorator('url', {
                        initialValue: injectForm.url,
                    })(<Input />)}
                </FormItem>

                <FormItem label="连接池描述" {...formItemLayout}>
                    {getFieldDecorator('descr', {
                        initialValue: injectForm.descr,
                    })(<Input />)}
                </FormItem>

                <FormItem label="连接池属性JSON" {...formItemLayout} style={{ marginBottom: 0 }}>
                    <FormItem style={{ marginBottom: 0 }}>
                        {getFieldDecorator('useJson', {
                            valuePropName: 'checked',
                            initialValue: useJson
                        })(<Checkbox onChange={this.onCheckboxChange}>使用当前值更新</Checkbox>)}
                    </FormItem>
                    <FormItem>
                        {getFieldDecorator('prop', {
                            initialValue: injectForm.prop
                        })(<Input />)}
                    </FormItem>
                </FormItem>
                { formItems }
                <FormItem {...formItemLayoutWithOutLabel}>
                    <Button type="primary" onClick={() => this.add()} disabled={useJson} style={{ width: '60%' }}>
                        <Icon type="plus" /> 添加连接池属性
                    </Button>
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(DataSourceForm);
