import React, { Component } from 'react';
import { Table, Button, message, Modal } from 'antd';
import { systemManagementService, monitorService } from 'service';
import withPermission from 'component/hoc/withPermission';
import withFormModal from 'component/hoc/withFormModal';
import { fromJS } from 'immutable';
import { deepCopy } from 'js/util';
import AlarmUserForm from './alarmUserForm';
import ApplicationForm from './applicationForm';

// 添加/修改告警用户
const AlarmUserFormModal = withFormModal(AlarmUserForm);

// 绑定应用
const ApplicationFormModal = withFormModal(ApplicationForm);

const { confirm } = Modal;

const defaultAlarmUserFormOptions = {
    id: '',
    deptName: '',
    name: '',
    email: '',
    mobile: '',
    weixin: '',
    rtx: ''
};

class AlarmUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            applications: [],
            alarmUserForm: deepCopy(defaultAlarmUserFormOptions),
            alarmUserVisible: false,
            alarmConfirmLoading: false,
            applicationVisible: false,
            applicationConfirmLoading: false,
            selectedRowKeys: [],
            currentUserId: ''
        };
    }
    componentDidMount() {
        this.getApplications();
        this.getAlarmUser();
    }
    // 获取应用
    getApplications = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'business_domain' }, true);
        if (code === '0') {
            this.setState({
                applications: entry
            });
        }
    }
    // 获取列表数据
    getAlarmUser = async () => {
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination };
        delete params.totalCount;
        const { entry, code } = await monitorService.getAlarmUser(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getAlarmUser();
            });
        }
    }
    // 打开modal
    setAlarmUser = (record) => {
        let alarmUserFormObj = {};
        if (record) {
            alarmUserFormObj = {
                id: record.id,
                deptName: record.deptName,
                name: record.name,
                email: record.email,
                mobile: record.mobile,
                weixin: record.weixin,
                rtx: record.rtx
            };
        } else {
            alarmUserFormObj = deepCopy(defaultAlarmUserFormOptions);
        }
        this.setState({
            alarmUserForm: alarmUserFormObj,
            alarmUserVisible: true
        });
    }
    // 保存
    setAlarmUserSend = async () => {
        this.alarmUserFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    alarmConfirmLoading: true
                });
                const params = { ...this.alarmUserFormRef.props.form.getFieldsValue(), id: this.state.alarmUserForm.id };
                const res = await monitorService.setAlarmUserSend(params);
                if (res.code === '0') {
                    this.setState({
                        alarmConfirmLoading: false,
                        alarmUserVisible: false
                    }, () => {
                        message.success(res.entry);
                        this.alarmUserFormRef.props.form.resetFields();
                        this.getAlarmUser();
                    });
                } else {
                    this.setState({
                        alarmConfirmLoading: false
                    });
                }
            }
        });
    }
    // 删除
    deleteAlarmUser = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.deleteAlarmUser({ id });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getAlarmUser();
                    }
                })();
            }
        });
    }
    // 绑定应用
    bindAlarmUser = async ({ id }) => {
        const { code, entry } = await monitorService.getBindApplicId({ userId: id, pageNum: 1, pageSize: 1000 });
        const { applications } = this.state;
        const selectedRowKeys = [];
        if (code === '0') {
            const { content } = JSON.parse(entry);
            content && content.forEach((item, index) => {
                const resultItem = applications.find((aItem) => {
                    return aItem.id === item.applicationId;
                });
                resultItem && selectedRowKeys.push(resultItem.id);
            });
            this.setState({
                selectedRowKeys,
                applicationVisible: true,
                currentUserId: id
            });
        }
    }
    // 保存绑定应用
    bindAlarmUserSend = async () => {
        this.setState({
            applicationConfirmLoading: true
        });
        const { currentUserId } = this.state;
        const params = { id: currentUserId, appIds: this.applicationFormRef.getSelectedRowKeys().join('_') };
        const res = await monitorService.bindApplicId(params);
        if (res.code === '0') {
            this.setState({
                applicationConfirmLoading: false,
                applicationVisible: false,
                selectedRowKeys: []
            }, () => {
                message.success(res.entry);
                this.getAlarmUser();
            });
        } else {
            this.setState({
                applicationConfirmLoading: false
            });
        }
    }
    // 关闭modal
    handleCancel = (type) => {
        this.alarmUserFormRef && this.alarmUserFormRef.props.form.resetFields();
        this.setState({
            [type]: false,
            selectedRowKeys: []
        });
    }
    // 获取ref
    getAlarmUserFormRef = (ref) => {
        this.alarmUserFormRef = ref;
    }
    getApplicationFormRef = (ref) => {
        this.applicationFormRef = ref;
    }

    render() {
        const {
            pagination,
            loading,
            data,
            alarmUserForm,
            alarmUserVisible,
            alarmConfirmLoading,
            applicationVisible,
            applicationConfirmLoading,
            applications,
            selectedRowKeys
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '部门',
            dataIndex: 'deptName',
            key: 'deptName'
        }, {
            title: '姓名',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '邮箱',
            dataIndex: 'email',
            key: 'email'
        }, {
            title: '手机',
            dataIndex: 'mobile',
            key: 'mobile'
        }, {
            title: '微信',
            dataIndex: 'weixin',
            key: 'weixin'
        }, {
            title: 'RTX',
            dataIndex: 'rtx',
            key: 'rtx'
        }, {
            title: '操作',
            key: 'action',
            width: 300,
            render: (text, record) => {
                const layout = { marginRight: '10px', marginBottom: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setAlarmUser.bind(this, record)}>修改</Button>, 'PermissionAlarmUserEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteAlarmUser.bind(this, record)}>删除</Button>, 'PermissionAlarmUserDelete')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.bindAlarmUser.bind(this, record)}>绑定应用</Button>, 'PermissionAlarmUserBind')
                        }
                    </div>
                );
            }
        }];
        return (
            <div>
                {
                    withPermission(<div style={{ marginBottom: 20 }}><Button type="primary" onClick={this.setAlarmUser}>添加告警用户</Button></div>, 'PermissionAlarmUserAdd')
                }
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <AlarmUserFormModal
                    maskClosable={false}
                    injectForm={alarmUserForm}
                    getRef={this.getAlarmUserFormRef}
                    title="数据维护"
                    visible={alarmUserVisible}
                    onOk={this.setAlarmUserSend}
                    onCancel={this.handleCancel.bind(this, 'alarmUserVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={alarmConfirmLoading} onClick={this.setAlarmUserSend}>
                            确定
                        </Button>
                    ]}
                />
                <ApplicationFormModal
                    maskClosable={false}
                    getRef={this.getApplicationFormRef}
                    title="绑定应用"
                    visible={applicationVisible}
                    onOk={this.bindAlarmUserSend}
                    onCancel={this.handleCancel.bind(this, 'applicationVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={applicationConfirmLoading} onClick={this.bindAlarmUserSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        applications,
                        selectedRowKeys: fromJS(selectedRowKeys)
                    }}
                />

            </div>
        );
    }
}

export default AlarmUser;
