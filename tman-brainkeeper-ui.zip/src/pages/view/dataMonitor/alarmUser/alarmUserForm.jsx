import React, { Component } from 'react';
import { Form, Input } from 'antd';

const FormItem = Form.Item;

class AlarmUserForm extends Component {
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        return (
            <Form>
                <FormItem label="部门" {...formItemLayout}>
                    {getFieldDecorator('deptName', {
                        initialValue: injectForm.deptName,
                    })(<Input />)}
                </FormItem>
                <FormItem label="姓名" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true, message: '姓名不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="邮箱" {...formItemLayout}>
                    {getFieldDecorator('email', {
                        initialValue: injectForm.email,
                        rules: [{
                            type: 'email', message: '邮箱格式不对',
                        }, {
                            required: true, message: '邮箱不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="手机" {...formItemLayout}>
                    {getFieldDecorator('mobile', {
                        initialValue: injectForm.mobile
                    })(<Input />)}
                </FormItem>
                <FormItem label="微信" {...formItemLayout}>
                    {getFieldDecorator('weixin', {
                        initialValue: injectForm.weixin,
                    })(<Input />)}
                </FormItem>
                <FormItem label="RTX" {...formItemLayout}>
                    {getFieldDecorator('rtx', {
                        initialValue: injectForm.rtx,
                    })(<Input />)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(AlarmUserForm);
