import React, { Component } from 'react';
import { Table } from 'antd';
import { is } from 'immutable';

class ApplicationForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedRowKeys: this.props.selectedRowKeys.toJS()
        };
    }
    UNSAFE_componentWillReceiveProps(nextProps) { //eslint-disable-line
        if (!is(this.props.selectedRowKeys, nextProps.selectedRowKeys)) {
            this.setState({
                selectedRowKeys: nextProps.selectedRowKeys.toJS()
            });
        }
    }
    onSelectChange = (selectedRowKeys) => {
        this.setState({ selectedRowKeys });
    }
    getSelectedRowKeys = () => {
        return this.state.selectedRowKeys;
    }
    render() {
        const { applications } = this.props;
        const { selectedRowKeys } = this.state;
        const rowSelection = {
            selectedRowKeys,
            onChange: this.onSelectChange,
        };
        const columns = [{
            title: '应用名称',
            dataIndex: 'key',
            key: 'key'
        }, {
            title: '应用描述',
            dataIndex: 'value',
            key: 'value',
            width: 200,
            render: (text, record) => {
                return text && JSON.parse(text).cnName;
            }
        }];
        return (
            <div>
                <Table
                    rowKey="id"
                    columns={columns}
                    dataSource={applications}
                    pagination={false}
                    rowSelection={rowSelection}
                    scroll={{ y: 240 }}
                />
            </div>
        );
    }
}

export default ApplicationForm;
