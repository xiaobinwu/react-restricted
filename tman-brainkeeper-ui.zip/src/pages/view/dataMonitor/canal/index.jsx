import React, { Component } from 'react';
import { monitorService } from 'service';
import { Card, Col, Row, Divider } from 'antd';
import styles from './index.css';

class Canal extends Component {
    state = {
        delayList: {}
    }
    componentDidMount() {
        this.getMonitorDelay();
    }
    componentWillUnmount() {
        this.clearTimer();
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 获取canal仪表数据
    getMonitorDelay = async () => {
        this.clearTimer();
        const { code, entry } = await monitorService.getMonitorDelay();
        if (code === '0' && entry) {
            this.setState({
                delayList: entry
            });
        }
        this.timer = setTimeout(() => { this.getMonitorDelay(); }, 5000);
    }
    render() {
        const { delayList } = this.state;
        return (
            <div>
                <Row gutter={20} style={{ marginBottom: 20 }}>
                    {
                        Object.keys(delayList).map((item, index) => {
                            return (
                                <Col span={8} style={{ marginBottom: 30 }} key={item}>
                                    <Card title={item} bordered={false}>
                                        <div className={styles.cardContent}>
                                            <p><strong>消费速率：</strong><span>{ delayList[item].throughput }{ delayList[item]['delay.unit'] }</span></p>
                                            <p><strong>延迟时间：</strong><span>{ delayList[item]['delay.time'] }</span></p>
                                            <p>
                                                <strong>状态：</strong>
                                                <span>
                                                    <span className={styles[`status${delayList[item]['delay.status']}`]}></span>
                                                    {
                                                        delayList[item]['delay.status'] === 0 ? '正常' : (
                                                            delayList[item]['delay.status'] === 1 ? '轻度'
                                                                : '重度'
                                                        )
                                                    }
                                                </span>
                                            </p>
                                            <Divider dashed />
                                            <p><strong>canal.binlog：</strong><span>{ delayList[item]['canal.binlog'] }</span></p>
                                            <p><strong>canal.position：</strong><span>{ delayList[item]['canal.position'] }</span></p>
                                            <p><strong>master.binlog：</strong><span>{ delayList[item]['master.binlog'] }</span></p>
                                            <p><strong>master.position：</strong><span>{ delayList[item]['master.position'] }</span></p>
                                        </div>
                                    </Card>
                                </Col>
                            );
                        })
                    }
                </Row>
            </div>
        );
    }
}

export default Canal;
