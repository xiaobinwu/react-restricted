import React, { Component } from 'react';
import { Form, Row, Col, Table, DatePicker, Button, Modal, message } from 'antd';
import withPermission from 'component/hoc/withPermission';
import { monitorService } from 'service';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { confirm } = Modal;

class GoodsReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 10,
                totalCount: 0
            }
        };
    }
    componentDidMount() {
        this.getData();
    }
    // 获取数据源列表
    getData = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const { rangeDate } = this.props.form.getFieldsValue();
        let params;
        if (rangeDate) {
            params = {
                ...pagination,
                ...{
                    beginDate: rangeDate[0].format('YYYY-MM-DD'),
                    endDate: rangeDate[1].format('YYYY-MM-DD')
                }
            };
        } else {
            params = { ...pagination };
        }
        delete params.totalCount;
        const { entry, code } = await monitorService.getGoodsReportList(params);
        entry.list && entry.list.forEach((item, index) => {
            item.key = index;
        });
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 全量导入
    reportCheck = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量导入？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.goodsReportAllLoad();
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    // 指定时间导入
    loadDate = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量指定时间导入？</p></div>;
        const that = this;
        const { rangeDate } = this.props.form.getFieldsValue();
        let params = {};
        if (rangeDate) {
            params = { ...{ beginDate: rangeDate[0].format('YYYY-MM-DD'), endDate: rangeDate[1].format('YYYY-MM-DD') } };
        }
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.goodsReportDateLoad({ ...params });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    render() {
        const {
            pagination,
            loading,
            data
        } = this.state;
        const { getFieldDecorator } = this.props.form;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '创建日期',
            dataIndex: 'createDate',
            key: 'createDate'
        }, {
            title: '周',
            dataIndex: 'week',
            key: 'week'
        }, {
            title: '新品数量',
            dataIndex: 'syncNewGoodsNum',
            key: 'syncNewGoodsNum'
        }, {
            title: '渠道开/关数量',
            dataIndex: 'openPipelineGoodsNum',
            key: 'openPipelineGoodsNum'
        }, {
            title: '上下架数量',
            dataIndex: 'upOrDownGoodsNum',
            key: 'upOrDownGoodsNum'
        }, {
            title: '价格计算数量',
            dataIndex: 'goodsPriceNum',
            key: 'goodsPriceNum'
        }, {
            title: '库存类型修改数量',
            dataIndex: 'goodsStockTypeUpdateNum',
            key: 'goodsStockTypeUpdateNum'
        }, {
            title: '多语言翻译数量',
            dataIndex: 'multiLangGoodsNum',
            key: 'multiLangGoodsNum'
        }, {
            title: '存库扣减次数',
            dataIndex: 'realtimeStockSubNum',
            key: 'realtimeStockSubNum'
        }, {
            title: '同步库存次数',
            dataIndex: 'syncStockNum',
            key: 'syncStockNum'
        }, {
            title: '虚拟库存修改次数',
            dataIndex: 'virtualStockUpdateNum',
            key: 'virtualStockUpdateNum'
        }];
        return (
            <div>
                <Form onSubmit={this.getData} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeDate')(<RangePicker placeholder={['开始时间', '结束时间']} />)}
                            </FormItem>
                        </Col>
                        <Col span={13}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.reportCheck} style={{ marginRight: '10px' }}>全量导入</Button>, 'PermissionGoodsReportAllImport')
                                }
                                {
                                    withPermission(<Button type="primary" onClick={this.loadDate}>指定部分时间导入</Button>, 'PermissionGoodsReportTimeImport')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    loading={loading}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    columns={columns}
                />
            </div>
        );
    }
}

export default Form.create()(GoodsReport);
