import React, { Component } from 'react';
import { Form, Input, Select, Button, Icon, Row, Col } from 'antd';

const FormItem = Form.Item;
const { Option } = Select;
const { TextArea } = Input;

let uuid = 0;

class DataSourceForm extends Component {
    // 添加
    add = () => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        const nextKeys = keys.concat(uuid);
        uuid++; // eslint-disable-line
        form.setFieldsValue({
            keys: nextKeys
        });
    }
    // 删除
    remove = (k) => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        if (keys.length === 1) {
            return;
        }
        form.setFieldsValue({
            keys: keys.filter(key => key !== k)
        });
    }
    onCheckboxChange = (e) => {
        const { handleUseJson } = this.props;
        handleUseJson(e.target.checked);
    }
    render() {
        const {
            form,
            injectForm,
            sourceTypes
        } = this.props;
        const { getFieldDecorator, getFieldValue } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 6 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 }
            }
        };
        const formItemLayoutWithOutLabel = {
            wrapperCol: {
                xs: { span: 24, offset: 0 },
                sm: { span: 20, offset: 6 }
            }
        };
        getFieldDecorator('keys', { initialValue: injectForm.keys });
        const keys = getFieldValue('keys');
        const formItems = keys.map((k, index) => {
            return (
                <FormItem
                    label={`属性${index}`}
                    {...formItemLayout}
                    key={index}
                >
                    <Row>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayoutWithOutLabel}
                                required={false}
                            >
                                {getFieldDecorator(`text[${k}]`, {
                                    initialValue: injectForm.text[k],
                                    validateTrigger: ['onChange', 'onBlur'],
                                    rules: [{
                                        required: true,
                                        whitespace: true,
                                        message: 'key不为空',
                                    }],
                                })(<Input placeholder="key" />)}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayoutWithOutLabel}
                                required={false}
                            >
                                {getFieldDecorator(`value[${k}]`, {
                                    initialValue: injectForm.value[k],
                                    validateTrigger: ['onChange', 'onBlur'],
                                    rules: [{
                                        required: true,
                                        whitespace: true,
                                        message: 'value不为空',
                                    }],
                                })(<Input placeholder="value" />)}
                            </FormItem>
                        </Col>
                        <Col span={8} style={{ textAlign: 'center' }}>
                            <Button type="primary" size="small" onClick={() => this.remove(k)} style={{ width: '60%' }}>
                                删除
                            </Button>
                        </Col>
                    </Row>
                </FormItem>
            );
        });
        return (
            <Form>
                <FormItem label="数据源名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true,
                            whitespace: true,
                            message: '数据源名称不为空',
                        }],
                    })(<Input />)}
                </FormItem>

                <FormItem label="数据源类型" {...formItemLayout}>
                    {getFieldDecorator('sourceType', {
                        initialValue: injectForm.sourceType,
                        rules: [{
                            required: true,
                            message: '数据源类型不为空',
                        }],
                    })(<Select>
                        {
                            sourceTypes.map((item, index) => {
                                return (<Option key={index} value={item.value}>{item.text}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>

                <FormItem label="数据源url" {...formItemLayout}>
                    {getFieldDecorator('url', {
                        initialValue: injectForm.url,
                        rules: [{
                            required: true,
                            whitespace: true,
                            message: '数据源url不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="描述" {...formItemLayout}>
                    {getFieldDecorator('description', {
                        initialValue: injectForm.description,
                        rules: [{
                            required: true,
                            message: '描述不为空',
                        }],
                    })(<TextArea row={4} />)}
                </FormItem>
                {formItems}
                <FormItem {...formItemLayoutWithOutLabel}>
                    <Button type="primary" onClick={() => this.add()} style={{ width: '60%' }}>
                        <Icon type="plus" /> 添加属性
                    </Button>
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(DataSourceForm);
