import React, { Component } from 'react';
import { monitorService, systemManagementService } from 'service';
import { Row, Col, Select, Button, Table, message, Modal, Input } from 'antd';
import withPermission from 'component/hoc/withPermission';
import withFormModal from 'component/hoc/withFormModal';
import { deepCopy } from 'js/util';
import DataSourceForm from './dataSourceForm';

// 添加/修改任务
const DataSourceFormModal = withFormModal(DataSourceForm);

const { confirm } = Modal;
const { Option } = Select;

const defaultDataSourceFormOptions = {
    id: '',
    name: '',
    sourceType: '',
    description: '',
    url: '',
    text: [],
    value: [],
    keys: []
};


class ReconciliationDataSource extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            name: '',
            sourceType: '',
            dataSourcesForm: deepCopy(defaultDataSourceFormOptions),
            dataSourcesVisible: false,
            dataSourcesConfirmLoading: false,
            sourceTypes: []
        };
        this.columns = [{
            title: '名称',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '类型',
            dataIndex: 'sourceType',
            key: 'sourceType',
            render: (text, record) => {
                const { sourceTypes } = this.state;
                const filterItem = sourceTypes.find((item, index) => { return item.value === text; });
                return filterItem ? filterItem.text : '';
            }
        }, {
            title: 'url',
            dataIndex: 'url',
            key: 'url',
            width: 300,
            render: (text, record) => {
                return (<div style={{ wordBreak: 'break-all', wordWrap: 'break-word' }}>{text}</div>);
            }
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description'
        }, {
            title: '属性',
            dataIndex: 'options',
            key: 'options',
            width: 400,
            render: (text, record) => {
                return (<div style={{ wordBreak: 'break-all', wordWrap: 'break-word' }}>{text}</div>);
            }
        }, {
            title: '操作',
            key: 'action',
            render: (text, record) => {
                const layout = { marginRight: '10px', marginBottom: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setDataSource.bind(this, record)}>修改</Button>, 'PermissionReconciliationDataSourceEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteDataSource.bind(this, record)}>删除</Button>, 'PermissionReconciliationDataSourceDelete')
                        }
                    </div>
                );
            }
        }];
    }
    componentDidMount() {
        this.getSourceTypes();
        this.getDataSourceData();
    }
    // 获取数据源类型列表
    getSourceTypes = async () => {
        const { code, entry } = await systemManagementService.getConfigList({ scope: 'job_group', key: 'source_type' }, true);
        const sourceTypes = [];
        if (code === '0') {
            const entryArr = JSON.parse(entry[0].value);
            Object.keys(entryArr).forEach((item, index) => {
                sourceTypes.push({
                    value: Number(item),
                    text: entryArr[item]
                });
            });
        }
        this.setState({
            sourceTypes
        });
    }
    // 获取数据源列表
    getDataSourceData = async () => {
        const { pagination, name, sourceType } = this.state;
        this.setState({
            loading: true
        });
        const params = {
            ...pagination,
            name,
            sourceType,
            countSql: true
        };
        delete params.totalCount;
        const { entry, code } = await monitorService.getReconciliationDataSource(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 新增修改数据源管理modal
    setDataSource = (record) => {
        let dataSourceFormObj = {};
        if (record) {
            dataSourceFormObj = {
                id: record.id,
                name: record.name,
                sourceType: record.sourceType,
                url: record.url,
                description: record.description
            };
            const texts = [];
            const values = [];
            if (record.options) {
                const props = JSON.parse(record.options);
                for (const item in props) {
                    texts.push(item);
                    values.push(props[item]);
                }
            }
            dataSourceFormObj.text = texts;
            dataSourceFormObj.value = values;
            dataSourceFormObj.keys = Array.from(new Array(texts.length), (val, index) => index);
        } else {
            dataSourceFormObj = deepCopy(defaultDataSourceFormOptions);
        }
        this.setState({
            dataSourcesForm: dataSourceFormObj,
            dataSourcesVisible: true
        });
    }
    // 删除
    deleteDataSource = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.deleteReconciliationDataSource({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getDataSourceData();
                    }
                })();
            }
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getDataSourceData();
            });
        }
    }
    // 获取ref
    getDataSourceFormRef = (ref) => {
        this.dataSourceFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.dataSourceFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    // 保存
    setDataSourceSend = (e) => {
        e.preventDefault();
        this.dataSourceFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    dataSourcesConfirmLoading: true
                });
                const propParams = {};
                const { text, value } = values;
                text.forEach((item, index) => {
                    if (item) {
                        propParams[item] = value[index];
                    }
                });
                values.options = JSON.stringify(propParams);
                delete values.text;
                delete values.value;
                delete values.keys;
                const params = { ...values, id: this.state.dataSourcesForm.id };
                const res = await monitorService.setReconciliationDataSourceSend(params);
                if (res.code === '0') {
                    this.setState({
                        dataSourcesConfirmLoading: false,
                        dataSourcesVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.dataSourceFormRef.props.form.resetFields();
                        this.getDataSourceData();
                    });
                } else {
                    this.setState({
                        dataSourcesConfirmLoading: false
                    });
                }
            }
        });
    }
    // 数据源类型
    changeSelect = (value) => {
        this.setState({
            sourceType: value
        });
    }
    // 数据源名称
    changeName = (e) => {
        this.setState({
            name: e.target.value.replace(/(^\s*)|(\s*$)/g, '')
        });
    }
    render() {
        const {
            loading,
            data,
            pagination,
            dataSourcesForm,
            dataSourcesVisible,
            dataSourcesConfirmLoading,
            sourceTypes
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const { columns } = this;
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 30 }}>
                    <Col span={4}>
                        <Input onChange={this.changeName} placeholder="请填写数据源名称"/>
                    </Col>
                    <Col span={6}>
                        <Select placeholder="请选择数据源类型" onChange={this.changeSelect} style={{ width: '100%' }}>
                            <Option value="">全部</Option>
                            {
                                sourceTypes.map((item, index) => {
                                    return (<Option key={index} value={item.value}>{item.text}</Option>);
                                })
                            }
                        </Select>
                    </Col>
                    <Col span={14}>
                        <Button icon="search" type="primary" style={{ marginRight: 10 }} onClick={this.getDataSourceData}>查询</Button>
                        {
                            withPermission(<Button type="primary" onClick={this.setDataSource.bind(this, null)}>新增</Button>, 'PermissionReconciliationDataSourceAdd')
                        }
                    </Col>
                </Row>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <DataSourceFormModal
                    maskClosable={false}
                    injectForm={dataSourcesForm}
                    getRef={this.getDataSourceFormRef}
                    title="数据源添加/修改"
                    visible={dataSourcesVisible}
                    onOk={this.setDataSourceSend}
                    onCancel={this.handleCancel.bind(this, 'dataSourcesVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={dataSourcesConfirmLoading} onClick={this.setDataSourceSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp={{
                        sourceTypes
                    }}
                />
            </div>
        );
    }
}

export default ReconciliationDataSource;
