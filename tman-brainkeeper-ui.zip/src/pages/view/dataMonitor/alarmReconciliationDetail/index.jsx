import React, { Component } from 'react';
import { Row, Col, Spin, message, Button, Card, Input } from 'antd';
import { getQueryString } from 'js/util';
import { monitorService } from 'service';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import styles from './index.css';

const { TextArea } = Input;

const statusSet = {
    initialise: '未处理',
    doing: '处理中',
    finish: '已完成'
};

class AlarmReconciliationDetail extends Component {
    constructor(props) {
        super(props);
        const result = getQueryString();
        this.state = {
            currentId: result.id,
            loading: false,
            title: '',
            date: '',
            context: '',
            status: '',
            receive: '',
            processResult: '',
            descr: ''
        };
    }
    componentDidMount() {
        this.getAlarmReconciliationDetail();
    }
    getAlarmReconciliationDetail = async () => {
        this.setState({
            loading: true
        });
        const { entry, code } = await monitorService.getAlarmReconciliationDetail({ id: this.state.currentId });
        const finalEntry = JSON.parse(entry);
        const content = JSON.parse(finalEntry.content);
        if (code === '0') {
            this.setState({
                title: finalEntry.title,
                status: finalEntry.status,
                processResult: finalEntry.processResult,
                date: content.date,
                context: content.context,
                receive: content.receive,
                descr: content.descr,
                loading: false
            });
        }
    }
    process = async () => {
        const {
            currentId,
            processResult
        } = this.state;
        const res = await monitorService.processAlarmReconciliationDetail({ id: currentId, text: processResult });
        if (res.code === '0') {
            message.success('处理成功');
            this.getAlarmReconciliationDetail();
        }
    }
    changeProcessResult = (e) => {
        const val = e.target.value;
        this.setState({
            processResult: val
        });
    }
    render() {
        const {
            loading,
            title,
            status,
            processResult,
            date,
            receive,
            context
        } = this.state;
        const content = [];
        const layout = { marginRight: 10 };
        if (context) {
            const result = JSON.parse(context);
            for (const i in result) {
                content.push(<p key={i} style={{ paddingLeft: 72 }}>
                    <span style={layout}>{i}：</span>
                    <span className={styles.content}>
                        {result[i]}
                    </span>
                </p>);
            }
        }
        return (
            <Spin spinning={loading}>
                <Row>
                    <Col span={12} offset={6}>
                        <Card style={{ padding: 20 }}>
                            <p>
                                <span style={layout}>任务名称：</span>
                                <span>{title || '-'}</span>
                            </p>
                            <p>
                                <span style={layout}>告警（北京）时间：</span>
                                <span>{date || '-'}</span>
                            </p>
                            <div>
                                <span style={layout}>告警内容：</span>
                                {content}
                            </div>
                            <p>
                                <span style={layout}>处理状态：</span>
                                <span>
                                    {statusSet[status]}
                                </span>
                            </p>
                            <p>
                                <span style={layout}>接收人：</span>
                                <span>{receive || '-'}</span>
                            </p>
                            {
                                status !== 'initialise' ? <p>
                                    <span style={layout}>处理方案：</span>
                                    <span>{processResult || '-'}</span>
                                </p> : null
                            }
                            {
                                status === 'initialise' ? <p>
                                    <span style={layout}>处理结果：</span>
                                    <TextArea rows={5} onChange={this.changeProcessResult.bind(this)} style={{ marginTop: 10 }}/>
                                </p> : null
                            }
                            <p style={{ marginBottom: 20 }}>
                                <Link to={{ pathname: this.props.paths.AlarmReconciliation.linkPath }}> <Button type="primary" style={{ marginRight: 20 }}>返回</Button></Link>
                                {
                                    status === 'initialise' ?
                                        <Button type="primary" onClick={this.process}>处理</Button>
                                        : null
                                }
                            </p>
                        </Card>
                    </Col>
                </Row>
            </Spin>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(AlarmReconciliationDetail);

