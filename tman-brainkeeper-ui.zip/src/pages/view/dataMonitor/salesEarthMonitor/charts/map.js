import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';
import { Spin } from 'antd';
import { registerMap } from 'js/echarts.custom';
import { formatAmount } from 'js/util';

// http://gallery.echartsjs.com/editor.html?c=xrJZ60TVIg

const maxSymbolSize = 30; // 最大symbolSize
class Map extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true
        };
    }
    componentDidMount() {
        // 引入世界地图
        import(/* webpackChunkName: 'world' */ './world.json').then((worldJson) => {
            registerMap('world', worldJson);
            this.setState({
                loading: false
            });
        });
    }
    formatter = (params) => {
        return `
            国家：${params.name}<br />
            经纬度：[${params.value[0]}, ${params.value[1]}]<br />
            订单数：${formatAmount(params.value[2], 0)}<br />
            支付数：${formatAmount(params.value[3], 0)}<br />
            订单金额：${formatAmount(params.value[4])}<br />
            支付金额：${formatAmount(params.value[5])}<br />
        `;
    }
    render() {
        const {
            convertedTopPayData,
            categoryTopPayData,
            convertedTopCountData,
            categoryTopCountData,
            convertedTopPayEffectData,
            maxOrderPayAmount
        } = this.props;
        const {
            loading
        } = this.state;
        const options = {
            animation: true,
            animationDuration: 1000,
            animationEasing: 'cubicInOut',
            animationDurationUpdate: 1000,
            animationEasingUpdate: 'cubicInOut',
            title: [{
                text: '销售地图',
                left: 'center',
            }, {
                text: 'Top 15 订单数',
                right: 140,
                top: '6%',
                width: 100,
                textStyle: {
                    fontSize: 14
                }
            }, {
                text: 'Top 15 支付金额（$）',
                right: 120,
                top: '52%',
                width: 100,
                textStyle: {
                    fontSize: 14
                }
            }],
            grid: [{
                right: 40,
                top: '14%',
                bottom: '50%',
                width: '20%'
            }, {
                right: 40,
                top: '60%',
                bottom: '3%',
                width: '20%'
            }],
            geo: {
                map: 'world',
                left: 0,
                right: '35%',
                center: [-0.9, 15],
                label: {
                    emphasis: {
                        show: false
                    }
                }
            },
            tooltip: {
                trigger: 'item'
            },
            xAxis: [{
                type: 'value',
                scale: true,
                position: 'top',
                boundaryGap: false,
                splitLine: {
                    show: false
                },
                max: (value) => {
                    return value.max * 1.2;
                }
            }, {
                type: 'value',
                scale: true,
                position: 'top',
                boundaryGap: false,
                gridIndex: 1,
                splitLine: {
                    show: false
                },
                max: (value) => {
                    return value.max * 1.2;
                }
            }],
            yAxis: [{
                type: 'category',
                nameGap: 16,
                splitLine: {
                    show: false
                },
                data: categoryTopCountData
            }, {
                type: 'category',
                nameGap: 16,
                splitLine: {
                    show: false
                },
                gridIndex: 1,
                data: categoryTopPayData
            }],
            series: [{
                type: 'effectScatter',
                coordinateSystem: 'geo',
                data: convertedTopPayEffectData,
                symbolSize: (val) => {
                    return Math.floor(maxSymbolSize * (val[5] / maxOrderPayAmount));
                },
                showEffectOn: 'render',
                rippleEffect: {
                    brushType: 'stroke'
                },
                hoverAnimation: true,
                label: {
                    normal: {
                        formatter: '{b}',
                        position: 'right',
                        show: true
                    }
                },
                itemStyle: {
                    normal: {
                        shadowBlur: 50
                    }
                },
                tooltip: {
                    formatter: this.formatter
                },
                zlevel: 1
            }, {
                id: 'bar1',
                zlevel: 2,
                type: 'bar',
                label: {
                    normal: {
                        position: 'right',
                        show: true,
                        formatter: (params) => {
                            return formatAmount(params.value, 0);
                        }
                    },
                },
                data: convertedTopCountData
            }, {
                id: 'bar2',
                zlevel: 2,
                type: 'bar',
                xAxisIndex: 1,
                yAxisIndex: 1,
                label: {
                    normal: {
                        position: 'right',
                        show: true,
                        formatter: (params) => {
                            return `$${formatAmount(params.value)}`;
                        }
                    },
                },
                data: convertedTopPayData
            }]
        };

        return (
            <div>
                {
                    loading ?
                        <Spin spinning={loading} tip="Loading..." delay={500}>
                            <div style={{
                                minHeight: '500px'
                            }}></div>
                        </Spin>
                        : <ReactEcharts option={options} style={{ minHeight: 'calc(100vh - 254px)', width: '100%' }}/>
                }
            </div>
        );
    }
}

export default Map;
