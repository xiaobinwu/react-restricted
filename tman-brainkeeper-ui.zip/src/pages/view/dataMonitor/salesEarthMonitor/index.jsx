import React, { Component } from 'react';
import { monitorService } from 'service';
import { Icon } from 'antd';
import { toggleFullScreen, deepCopy } from 'js/util';
import Map from './charts/map';
import styles from './index.css';

class SalesEarthMonitor extends Component {
    constructor(props) {
        super(props);
        this.state = {
            convertedData: [],
            categoryData: [],
            convertedTopPayData: [],
            convertedTopCountData: [],
            maxOrderPayAmount: 0,
            isFullScreen: false
        };
        this.$main = document.querySelector('.system-main');
    }
    componentDidMount() {
        this.getBusinessOrdersReport();
    }
    getBusinessOrdersReport = async () => {
        this.clearTimer();
        const { code, entry } = await monitorService.getBusinessOrdersReport();
        if (code === '0' && entry) {
            const convertedData = [];
            let convertedTopPayEffectData;
            entry.length > 0 && entry.forEach((item, index) => {
                item.value.forEach((it, i) => {
                    item[it.type] = it.value;
                });
                convertedData.push({
                    name: item.name,
                    value: item.lnglat.concat([item.countNum, item.countPayNum, item.orderAmount, item.orderPayAmount]),
                    countNum: item.countNum,
                    orderPayAmount: item.orderPayAmount
                });
            });
            const handleTopData = (data, type, geoSplitNum = 50, barSplitNum = 15) => {
                const geoTopData = deepCopy(data).sort((a, b) => {
                    return b[type] - a[type];
                }).slice(0, geoSplitNum);
                const topData = geoTopData.slice(0, barSplitNum);
                if (type === 'orderPayAmount') {
                    convertedTopPayEffectData = deepCopy(geoTopData);
                }
                const categoryTopData = [];
                topData.forEach((t, idx) => {
                    t.value = t[type];
                    categoryTopData.push(t.name);
                });
                return [topData.reverse(), categoryTopData.reverse()];
            };
            const [convertedTopPayData, categoryTopPayData] = handleTopData(convertedData, 'orderPayAmount');
            const [convertedTopCountData, categoryTopCountData] = handleTopData(convertedData, 'countNum');
            this.setState({
                convertedData,
                convertedTopPayData,
                convertedTopPayEffectData,
                categoryTopPayData,
                convertedTopCountData,
                categoryTopCountData,
                maxOrderPayAmount: convertedTopPayEffectData[0].orderPayAmount
            });
        }
        this.timer = setTimeout(() => { this.getBusinessOrdersReport(); }, 60000);
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 放大
    zoomIn = () => {
        this.setState({
            isFullScreen: true
        }, () => {
            toggleFullScreen(this.state.isFullScreen, () => {
                this.$main.classList.add(styles.fixed);
            });
        });
    }
    // 缩小
    zoomOut = () => {
        this.setState({
            isFullScreen: false
        }, () => {
            toggleFullScreen(this.state.isFullScreen, () => {
                this.$main.classList.remove(styles.fixed);
            });
        });
    }
    componentWillUnmount() {
        // 移除定时器
        this.clearTimer();
    }
    render() {
        const {
            convertedData,
            convertedTopPayData,
            categoryTopPayData,
            convertedTopCountData,
            categoryTopCountData,
            convertedTopPayEffectData,
            isFullScreen,
            maxOrderPayAmount
        } = this.state;
        return (
            <React.Fragment>
                <div style={{ textAlign: 'right', marginBottom: '10px' }}>
                    {
                        isFullScreen ? <Icon type="zoom-out" theme="outlined" className={styles.icon} onClick={this.zoomOut} />
                            : <Icon type="zoom-in" theme="outlined" className={styles.icon} onClick={this.zoomIn} />
                    }
                </div>
                <Map
                    maxOrderPayAmount={maxOrderPayAmount}
                    convertedData={convertedData}
                    categoryTopPayData={categoryTopPayData}
                    convertedTopPayData={convertedTopPayData}
                    categoryTopCountData={categoryTopCountData}
                    convertedTopCountData={convertedTopCountData}
                    convertedTopPayEffectData={convertedTopPayEffectData}
                />
            </React.Fragment>
        );
    }
}

export default SalesEarthMonitor;
