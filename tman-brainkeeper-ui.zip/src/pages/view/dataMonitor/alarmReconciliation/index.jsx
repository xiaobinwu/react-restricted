import React, { Component } from 'react';
import { Table, Button } from 'antd';
import { monitorService } from 'service';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

const statusSet = {
    initialise: '未处理',
    doing: '处理中',
    finish: '已完成'
};

class AlarmReconciliation extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            }
        };
    }
    componentDidMount() {
        this.getAlarmReconciliation();
    }
    // 获取列表数据
    getAlarmReconciliation = async () => {
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination };
        delete params.totalCount;
        const { entry, code } = await monitorService.getAlarmReconciliation(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getAlarmReconciliation();
            });
        }
    }
    render() {
        const {
            pagination,
            loading,
            data
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '告警时间',
            dataIndex: 'creatDate',
            key: 'creatDate'
        }, {
            title: '标题',
            dataIndex: 'title',
            key: 'title'
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            render: (text, record) => {
                return statusSet[text];
            }
        }, {
            title: '处理结果',
            dataIndex: 'processResult',
            key: 'processResult'
        }];
        if (this.props.paths.AlarmReconciliationDetail) {
            columns.push({
                title: '操作',
                key: 'action',
                width: 200,
                render: (text, record) => {
                    return (
                        <Link to={{ pathname: this.props.paths.AlarmReconciliationDetail.linkPath, search: `?id=${record.uuid}` }}><Button type="primary">查看</Button></Link>
                    );
                }
            });
        }
        return (
            <div>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(AlarmReconciliation);
