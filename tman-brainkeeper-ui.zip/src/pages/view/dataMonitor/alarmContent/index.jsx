import React, { Component } from 'react';
import { Form, Row, Col, Table, Button, Select } from 'antd';
import { systemManagementService, monitorService } from 'service';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

const statusSet = {
    initialise: '未处理',
    doing: '处理中',
    finish: '已完成'
};

const { Option } = Select;
const FormItem = Form.Item;

class AlarmContent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            applications: [],
            applicationId: ''
        };
    }
    componentDidMount() {
        this.getApplications();
        this.getTaskData();
        this.getAlarmContent();
    }
    // 获取列表数据
    getAlarmContent = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination, ...this.props.form.getFieldsValue() };
        delete params.totalCount;
        const { entry, code } = await monitorService.getAlarmContent(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getAlarmContent();
            });
        }
    }
    // 获取应用
    getApplications = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'business_domain' }, true);
        if (code === '0') {
            this.setState({
                applications: entry
            });
        }
    }
    // 获取任务
    getTaskData = async () => {
        const { applicationId } = this.state;
        const { entry, code } = await monitorService.getTaskList({ pageNum: 1, pageSize: 10000, applicationId });
        if (code === '0') {
            this.setState({
                jobList: entry.list
            });
        }
    }
    // 设置当前选中的app ID
    changeAppId = (value) => {
        this.setState({
            applicationId: value
        }, () => {
            this.getTaskData();
        });
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const {
            pagination,
            loading,
            data,
            applications,
            jobList
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '告警时间',
            dataIndex: 'creatDate',
            key: 'creatDate'
        }, {
            title: '标题',
            dataIndex: 'title',
            key: 'title'
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            render: (text, record) => {
                return statusSet[text];
            }
        }, {
            title: '处理结果',
            dataIndex: 'processResult',
            key: 'processResult'
        }];
        if (this.props.paths.AlarmContentDetail) {
            columns.push({
                title: '操作',
                key: 'action',
                width: 200,
                render: (text, record) => {
                    return (
                        <Link to={{ pathname: this.props.paths.AlarmContentDetail.linkPath, search: `?id=${record.uuid}` }}><Button type="primary">查看</Button></Link>
                    );
                }
            });
        }
        return (
            <div>
                <Form onSubmit={this.getAlarmContent} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('appId')(<Select
                                    showSearch
                                    placeholder='请选择应用'
                                    optionFilterProp='children'
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                    onChange={this.changeAppId}
                                >
                                    <Option value="">全部</Option>
                                    {
                                        applications && applications.map((item, index) => {
                                            return (<Option value={item.id} key={item.id}>{item.key}</Option>);
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('jobId')(<Select
                                    showSearch
                                    placeholder='请选择任务'
                                    optionFilterProp='children'
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                >
                                    <Option value="">全部</Option>
                                    {
                                        jobList && jobList.map((item, index) => {
                                            return (<Option value={item.id} key={item.id}>{item.name}</Option>);
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('status')(<Select
                                    placeholder='选择状态'
                                >
                                    <Option value="">全部</Option>
                                    <Option value="initialise">未处理</Option>
                                    <Option value="finish">已完成</Option>
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={15}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(Form.create()(AlarmContent));
