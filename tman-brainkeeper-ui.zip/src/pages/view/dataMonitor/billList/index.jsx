import React, { Component } from 'react';
import { Input, Select, Row, Col, Button, Table, Form, Modal, message } from 'antd';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { monitorService } from 'service';
import { deepCopy } from 'js/util';
// import styles from './index.css';
import JobForm from './jobForm';

const JobFormModal = withFormModal(JobForm);

const FormItem = Form.Item;
const { Option } = Select;
const { confirm } = Modal;

const defaultJsonParams = {
    attachJar: 0,
    description: '',
    jarfile: [],
    jobId: '',
    currentEditId: '',
    text: [''],
    value: [''],
    keys: [0],
    name: '',
    metricName: '',
    sources: [],
    auditStatus: 0,
    jobClass: '',
    delay: 0,
    parallelism: 1
};
class BillList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            entry: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            visible: false,
            loading: false,
            jobConfirmLoading: false,
            jobForm: { ...defaultJsonParams }
        };
        this.columns = [{
            title: '名称',
            dataIndex: 'jobId',
            key: 'jobId'
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            render: (text) => {
                return text === 1 ? '运行中' : '已停止';
            }
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description'
        }, {
            title: '审核状态',
            dataIndex: 'auditStatus',
            key: 'auditStatus',
            render: (text, record) => {
                return text === 0 ? '待审核' : (text === 1 ? '审核通过' : '审核不通过');
            }
        }, {
            title: '创建信息',
            dataIndex: 'createInformation',
            key: 'createInformation',
            render: (text, record) => {
                return (
                    <div>
                        <span style={{ marginRight: '10px' }}> {record.createTime}</span>
                        <span>{record.createUser}</span>
                    </div>
                );
            }
        }, {
            title: '修改信息',
            dataIndex: 'modifyInformation',
            key: 'modifyInformation',
            render: (text, record) => {
                return (
                    <div>
                        <span style={{ marginRight: '10px' }}>{record.modifyTime}</span>
                        <span>{record.modifyUser}</span>
                    </div>
                );
            }
        }, {
            title: '操作',
            key: 'action',
            width: '300px',
            render: (text, record) => {
                return (
                    <div>
                        {
                            record.auditStatus === 1 ? (
                                withPermission(record.status === 1 ? <Button type="primary" size="small" onClick={this.changeStatus.bind(this, record, false)} style={{ marginRight: '10px' }}>停止</Button>
                                    : <Button type="primary" size="small" onClick={this.changeStatus.bind(this, record, true)} style={{ marginRight: '10px' }}>启动</Button>, 'PermissionReconciliationBillListStatus')
                            ) : null
                        }
                        {
                            withPermission(<Button type="primary" size="small" onClick={this.operate.bind(this, record, 2)} style={{ marginRight: '10px' }}>查看</Button>, 'PermissionReconciliationBillListReview')
                        }
                        {
                            record.status !== 1 ?
                                <React.Fragment>
                                    {
                                        withPermission(<Button type="primary" size="small" onClick={this.operate.bind(this, record, 1)} style={{ marginRight: '10px' }}>编辑</Button>, 'PermissionReconciliationBillListEdit')
                                    }
                                    {
                                        withPermission(<Button type="primary" size="small" onClick={this.remove.bind(this, record)}>删除</Button>, 'PermissionReconciliationBillListDelete')
                                    }
                                </React.Fragment>
                                : null
                        }
                    </div>
                );
            }
        }];
    }
    componentDidMount() {
        this.getJobList();
    }
    // 删除Job
    remove = (record) => {
        const content = <div style={{ marginTop: '20px' }}><p>删除{record.jobId}后将不可恢复，请确认操作</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.deleteReconciliationJob({ id: record.id, jobId: record.jobId });
                    if (res.code === '0') {
                        that.getJobList();
                        message.success('删除成功');
                    }
                })();
            }
        });
    }
    // 改变状态
    changeStatus = (record, flag) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否{flag ? '开启' : '关闭'}{record.jobId}</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.changeReconciliationJobStatus({ id: record.id, flag });
                    if (res.code === '0') {
                        that.getJobList();
                        message.success(flag ? '开启成功' : '关闭成功');
                    }
                })();
            }
        });
    }
    // 查看及编辑job
    operate = (record, status) => {
        const text = [];
        const value = [];
        const {
            columns,
            metricName,
            sourceName,
            delay
        } = record.source;
        if (columns) {
            const parseColumns = JSON.parse(columns);
            Object.keys(parseColumns).forEach((item, index) => {
                text.push(item);
                value.push(parseColumns[item]);
            });
        }
        this.setState({
            operateStatus: status,
            visible: true,
            jobForm: {
                currentEditId: record.id,
                description: record.description,
                attachJar: record.attachJar,
                jobId: record.jobId,
                jobClass: record.jobClass,
                parallelism: record.parallelism,
                metricName,
                delay,
                jarfile: [],
                sources: record.sources ? record.sources.split(',') : [],
                name: sourceName,
                keys: Array.from(new Array(text.length), (val, index) => index),
                auditStatus: record.auditStatus,
                text,
                value
            }
        });
    }
    // 新增job
    createJob = () => {
        this.setState({
            operateStatus: 0,
            visible: true,
            jobForm: deepCopy(defaultJsonParams)
        });
    }
    // 查询
    inquire = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
                this.getJobList();
            }
        });
    }
    // 获取Job列表
    getJobList = async (e) => {
        e && e.preventDefault(); // eslint-disable-line  
        this.props.form.validateFields(async (err, values) => {
            if (!err) {
                const { pagination } = this.state;
                const params = { ...this.props.form.getFieldsValue(), ...pagination };
                delete params.totalCount;
                this.setState({
                    loading: true
                });
                const { entry, code } = await monitorService.getReconciliationJobs(params);
                if (code === '0') {
                    this.setState({
                        loading: false,
                        pagination: { ...pagination, ...{ totalCount: entry.total } },
                        entry: entry.list
                    });
                }
            }
        });
    }
    // 新增及编辑Job
    handleOk = (e) => {
        e.preventDefault();
        this.jobFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    jobConfirmLoading: true
                });
                const columns = {};
                values.text.forEach((item, index) => {
                    columns[item] = values.value[index];
                });
                values.attachJar = values.attachJar ? 0 : 1;
                values.sources = values.sources.length > 0 ? values.sources.join(',') : '';
                values.parallelism = values.parallelism || 1;
                values.sourceJson = JSON.stringify({
                    jobId: values.jobId,
                    sourceName: values.name,
                    sourceType: values.sourceType,
                    metricName: values.metricName,
                    delay: values.delay,
                    columns: JSON.stringify(columns)
                });
                let params;
                if (this.state.operateStatus === 1 && this.state.jobForm.currentEditId) {
                    params = { ...values, operateStatus: this.state.operateStatus, id: this.state.jobForm.currentEditId };
                    if (params.attachJar === 1) {
                        delete params.attachJar;
                    }
                } else {
                    params = { ...values, operateStatus: this.state.operateStatus };
                }
                const { code } = await monitorService.operateReconciliationJob(params);
                this.setState({
                    jobConfirmLoading: false
                });
                if (code === '0') {
                    message.success('保存成功');
                    this.getJobList();
                    this.jobFormRef.props.form.resetFields();
                    this.setState({
                        visible: false
                    });
                }
            }
        });
    }
    // 关闭弹框
    handleCancel = () => {
        this.setState({
            visible: false
        }, () => {
            this.jobFormRef.props.form.resetFields();
        });
    }
    // 获取ref
    getJobFormRef = (ref) => {
        this.jobFormRef = ref;
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getJobList();
            });
        }
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const {
            entry,
            loading,
            visible,
            jobForm,
            operateStatus,
            jobConfirmLoading,
            pagination
        } = this.state;
        const { columns } = this;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const title = operateStatus === 0 ? '添加Job' : (operateStatus === 1 ? '编辑Job' : '查看Job');
        return (
            <div>
                <Form onSubmit={this.inquire}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('jobId', {
                                    initialValue: ''
                                })(<Input placeholder="输入名称"/>)}
                            </FormItem>
                        </Col>
                        <Col span={2}>
                            <FormItem>
                                {getFieldDecorator('status')(<Select placeholder='请选择状态'>
                                    <Option value="">全部</Option>
                                    <Option value="1">运行中</Option>
                                    <Option value="2">已停止</Option>
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('auditStatus')(<Select placeholder='请选择审核状态'>
                                    <Option value="">全部</Option>
                                    <Option value="0">待审核</Option>
                                    <Option value="1">审核通过</Option>
                                    <Option value="2">审核不通过</Option>
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={16}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.createJob}>创建</Button>, 'PermissionReconciliationBillListAdd')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <JobFormModal
                    maskClosable={false}
                    width="1000px"
                    injectForm={jobForm}
                    getRef={this.getJobFormRef}
                    title={title}
                    visible={visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    footer={
                        <React.Fragment>
                            {
                                operateStatus !== 2 ? [
                                    <Button key="submit" type="primary" loading={jobConfirmLoading} onClick={this.handleOk}>
                                        保存
                                    </Button>
                                ] : null
                            }
                        </React.Fragment>
                    }
                    wrappedProp= {{
                        operateStatus,
                        getJobList: this.getJobList.bind(this)
                    }}
                />
                <Table
                    rowKey="id"
                    columns={columns}
                    dataSource={entry}
                    loading={loading}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />

            </div>
        );
    }
}

export default Form.create()(BillList);
