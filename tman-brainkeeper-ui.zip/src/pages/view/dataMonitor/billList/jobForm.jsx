import React, { Component } from 'react';
import { Form, Row, Col, Upload, Input, Button, Icon, Checkbox, Select, Radio, message, InputNumber } from 'antd';
import { connect } from 'react-redux';
import { monitorService } from 'service';
import withPermission from 'component/hoc/withPermission';
import styles from './jobForm.css';

const RadioGroup = Radio.Group;
const FormItem = Form.Item;
const { Option } = Select;

const sourceType = 5; // 固定流数据类型

let uuid = 1;

class JobForm extends Component {
    state = {
        singleSourceList: [],
        sourceList: [],
        auditStatus: 0
    }
    componentDidMount() {
        this.getSourceTypes();
    }
    // 添加
    add = () => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        const nextKeys = keys.concat(uuid);
        uuid++; // eslint-disable-line
        form.setFieldsValue({
            keys: nextKeys
        });
    }
    // 删除
    remove = (k) => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        if (keys.length === 1) {
            return;
        }
        form.setFieldsValue({
            keys: keys.filter(key => key !== k)
        });
    }
    getSourceTypes = async () => {
        const { code, entry } = await monitorService.getReconciliationDataSourceList();
        let singleSourceList = [];
        if (code === '0' && entry) {
            singleSourceList = entry.filter((item, index) => {
                return item.sourceType === sourceType;
            });
            this.setState({
                sourceList: entry,
                singleSourceList
            });
        }
    }
    // onChange 的参数（如 event）转化为控件的值
    normFile = (e) => {
        if (Array.isArray(e)) {
            return e;
        }
        return e && [e.file];
    }
    // 审核提交
    updateAuditStatus = async () => {
        const { currentEditId } = this.props.injectForm;
        const { auditStatus } = this.state;
        const { form, getJobList } = this.props;
        if (!auditStatus) {
            message.error('请选择审核状态');
        } else {
            const res = await monitorService.auditReconciliationJob({ id: currentEditId, auditStatus });
            if (res.code === '0') {
                message.success('操作成功');
                form.setFieldsValue({ auditStatus });
                getJobList && getJobList(); // 更新列表
            }
        }
    }
    // 审核
    changeAuditStatus = (e) => {
        this.setState({
            auditStatus: e.target.value
        });
    }
    // 重新审核
    renewAuditStatus = (auditStatus) => {
        const { form } = this.props;
        this.setState({
            auditStatus
        });
        form.setFieldsValue({ auditStatus: 0 });
    }
    render() {
        const {
            form,
            injectForm,
            operateStatus,
            antd
        } = this.props;
        const { sourceList, singleSourceList, auditStatus } = this.state;
        const { getFieldDecorator, getFieldValue, setFieldsValue } = form;
        const uploadProps = {
            accept: '.jar',
            onRemove: (file) => {
                const jarfile = getFieldValue('jarfile');
                const index = jarfile.indexOf(file);
                const newAttachJar = jarfile.slice();
                newAttachJar.splice(index, 1);
                setFieldsValue({ jarfile: newAttachJar });
            },
            beforeUpload: (file) => {
                setFieldsValue({ jarfile: file });
                return false;
            },
            disabled: operateStatus === 2
        };
        getFieldDecorator('keys', { initialValue: injectForm.keys });
        getFieldDecorator('sourceType', { initialValue: sourceType });
        getFieldDecorator('auditStatus', { initialValue: injectForm.auditStatus });
        const keys = getFieldValue('keys');
        const injectAuditStatus = getFieldValue('auditStatus');
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 }
            }
        };
        const formItemLayoutWithOutLabel = {
            wrapperCol: {
                xs: { span: 24, offset: 0 },
                sm: { span: 21, offset: 3 }
            }
        };
        const formItems = keys.map((k, index) => {
            return (
                <FormItem
                    label={`流数据字段${index}`}
                    {...formItemLayout}
                    key={index}
                >
                    <Row>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayoutWithOutLabel}
                                required={false}
                            >
                                {getFieldDecorator(`text[${k}]`, {
                                    initialValue: injectForm.text[k],
                                    validateTrigger: ['onChange', 'onBlur'],
                                    rules: [{
                                        required: true,
                                        whitespace: true,
                                        message: '字段名不为空',
                                    }],
                                })(<Input placeholder="字段名" disabled={operateStatus === 2} />)}
                            </FormItem>
                        </Col>
                        <Col span={8}>
                            <FormItem
                                {...formItemLayoutWithOutLabel}
                                required={false}
                            >
                                {getFieldDecorator(`value[${k}]`, {
                                    initialValue: injectForm.value[k],
                                    validateTrigger: ['onChange', 'onBlur'],
                                    rules: [{
                                        required: true,
                                        whitespace: true,
                                        message: '字段类型不为空',
                                    }],
                                })(<Input placeholder="字段类型" disabled={operateStatus === 2} />)}
                            </FormItem>
                        </Col>
                        <Col span={8} style={{ textAlign: 'center' }}>
                            {
                                keys.length > 1 ? (
                                    <Button type="primary" size="small" onClick={() => this.remove(k)} style={{ width: '60%' }} disabled={operateStatus === 2}>
                                        删除
                                    </Button>
                                ) : null
                            }
                        </Col>
                    </Row>
                </FormItem>
            );
        });
        const auditRadioGroup = <div>
            {
                injectAuditStatus === 0 ? (
                    <React.Fragment>
                        <RadioGroup value={auditStatus} onChange={this.changeAuditStatus}>
                            <Radio value={1}>审核通过</Radio>
                            <Radio value={2}>审核不通过</Radio>
                        </RadioGroup>
                        <Button type="primary" onClick={this.updateAuditStatus} size="small">审核</Button>
                    </React.Fragment>
                ) : (<React.Fragment>
                    <strong style={{ marginLeft: 30 }} className={injectAuditStatus === 1 ? 'system-colony-count-color' : 'system-colony-caution-color'}> {
                        injectAuditStatus === 1 ? '审核通过' : '审核不通过'
                    } </strong>
                    <Button type="primary" size="small" onClick={this.renewAuditStatus.bind(this, injectAuditStatus)} style={{ marginLeft: 20 }}>重新审核</Button>
                </React.Fragment>)
            }
        </div>;
        return (
            <div>
                <Form>
                    <FormItem label="JobId" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('jobId', {
                            initialValue: injectForm.jobId,
                            rules: [{
                                required: true,
                                message: 'jobId不为空',
                            }],
                        })(<Input placeholder="输入JobId" disabled={operateStatus === 2}/>)}
                    </FormItem>
                    <FormItem label="描述" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('description', {
                            initialValue: injectForm.description,
                            rules: [{
                                required: true,
                                message: '描述不为空',
                            }],
                        })(<Input placeholder="输入描述" disabled={operateStatus === 2}/>)}
                    </FormItem>
                    {
                        injectForm.attachJar && operateStatus === 1 ?
                            <FormItem {...formItemLayoutWithOutLabel }>
                                {getFieldDecorator('attachJar', {
                                    valuePropName: 'checked'
                                })(<Checkbox>是否清空jar文件</Checkbox>)}
                            </FormItem>
                            : null
                    }
                    <FormItem label="Jar文件" {...formItemLayout} className={styles.formItem} extra={injectForm.attachJar === 1 ? <div><Icon type="info-circle" style={{ marginRight: '10px', color: '#279327' }} /><span>已上传了jar文件！</span></div> : ''}>
                        {getFieldDecorator('jarfile', {
                            initialValue: injectForm.jarfile,
                            valuePropName: 'fileList',
                            getValueFromEvent: this.normFile,
                        })(<Upload name="jar" {...uploadProps}>
                            <Button type={antd === 'light' ? 'default' : 'primary'}>
                                <Icon type="upload" /> 上传jar包
                            </Button>
                        </Upload>)}
                    </FormItem>
                    <FormItem label="流数据源类型" {...formItemLayout} className={styles.formItem}>
                        <strong style={{ marginLeft: 30 }} className="system-colony-notice-color"> Kafka </strong>
                    </FormItem>
                    <FormItem label="流数据源" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('name', {
                            initialValue: injectForm.name,
                            rules: [{
                                required: true,
                                message: '流数据源不为空',
                            }],
                        })(<Select disabled={operateStatus === 2}>
                            {
                                singleSourceList.map((item, index) => {
                                    return (<Option key={index} value={item.name}>{item.name}</Option>);
                                })
                            }
                        </Select>)}
                    </FormItem>
                    <FormItem label="表名" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('metricName', {
                            initialValue: injectForm.metricName,
                            rules: [{
                                required: true,
                                message: '表名不为空',
                            }],
                        })(<Input disabled={operateStatus === 2}/>)}
                    </FormItem>
                    <FormItem label="延迟时间" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('delay', {
                            initialValue: injectForm.delay,
                            rules: [{
                                pattern: new RegExp(/^\d+$/, 'g'), message: '只能填数字'
                            }],
                        })(<Input disabled={operateStatus === 2} style={{ width: '20%' }} addonAfter="ms"/>)}
                    </FormItem>
                    {formItems}
                    <FormItem {...formItemLayoutWithOutLabel} className={styles.formItem}>
                        <Button type="primary" onClick={() => this.add()} style={{ width: '60%' }} disabled={operateStatus === 2}>
                            <Icon type="plus" /> 添加流数据字段
                        </Button>
                    </FormItem>
                    <FormItem label="目标数据源" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('sources', {
                            initialValue: injectForm.sources
                        })(<Select disabled={operateStatus === 2} mode="multiple">
                            {
                                sourceList.map((item, index) => {
                                    return (<Option key={index} value={item.name}>{item.name}</Option>);
                                })
                            }
                        </Select>)}
                    </FormItem>
                    <FormItem label="执行类" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('jobClass', {
                            initialValue: injectForm.jobClass,
                            rules: [{
                                required: true,
                                message: '执行类不为空',
                            }],
                        })(<Input disabled={operateStatus === 2}/>)}
                    </FormItem>
                    <FormItem label="并行线程数" {...formItemLayout} className={styles.formItem}>
                        {getFieldDecorator('parallelism', {
                            initialValue: injectForm.parallelism,
                            rules: [{
                                pattern: new RegExp(/^\d+$/, 'g'), message: '只能填数字'
                            }],
                        })(<InputNumber disabled={operateStatus === 2} style={{ width: '20%' }}/>)}
                    </FormItem>
                    {
                        operateStatus === 2 ? withPermission(<FormItem label="审核操作" {...formItemLayout}>
                            { auditRadioGroup }
                        </FormItem>, 'PermissionReconciliationBillListAudit') : null
                    }
                </Form>
            </div>
        );
    }
}

const stateToProps = ({ themeState }) => ({
    antd: themeState.antd
});

export default connect(stateToProps)(Form.create()(JobForm));
