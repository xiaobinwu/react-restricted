import React, { Component } from 'react';
import { Form, Select, Button, Table, message, Modal } from 'antd';
import { monitorService, systemManagementService } from 'service';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { deepCopy } from 'js/util';
import TaskForm from './taskForm';
import SqlForm from './sqlForm';
import styles from './index.css';

const FormItem = Form.Item;
const { Option } = Select;
const { confirm } = Modal;

// 添加/修改任务
const TaskFormModal = withFormModal(TaskForm);

// sql检测
const SqlFormModal = withFormModal(SqlForm);

// 添加/修改任务的表单默认字段
const defaultTaskFormOptions = {
    id: '',
    applicationId: '',
    sqlCron: '',
    cron: '',
    name: '',
    descr: '',
    status: '',
    minuteNum: 0,
    dataSourcesId: '',
    warnCode: ''
};

class Task extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            dataSource: [],
            applications: [],
            taskForm: deepCopy(defaultTaskFormOptions),
            taskVisible: false,
            taskConfirmLoading: false,
            sqlForm: { sql: '' },
            sqlVisible: false,
            sqlConfirmLoading: false,
            sqlResult: ''
        };
    }
    componentDidMount() {
        this.getTaskData();
        this.getDataSource();
        this.getApplications();
    }
    // 获取连接池
    getDataSource = async () => {
        const { entry, code } = await monitorService.getDataSource({ pageNum: 1, pageSize: 1000 }, true);
        if (code === '0') {
            this.setState({
                dataSource: entry.list
            });
        }
    }
    // 获取应用
    getApplications = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'business_domain' }, true);
        if (code === '0') {
            this.setState({
                applications: entry
            });
        }
    }
    // 获取数据
    getTaskData = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...this.props.form.getFieldsValue(), ...pagination };
        delete params.totalCount;
        const { entry, code } = await monitorService.getTaskList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getTaskData();
            });
        }
    }
    // 获取监控任务ref
    getTaskFormRef = (ref) => {
        this.taskFormRef = ref;
    }
    // 获取sql检测ref
    getSqlFormRef = (ref) => {
        this.sqlFormRef = ref;
    }
    // 打开任务modal
    setTask = (record) => {
        let taskFormObj = {};
        if (record) {
            taskFormObj = {
                id: record.id,
                applicationId: record.applicationId,
                sqlCron: record.sqlCron,
                cron: record.cron,
                name: record.name,
                dataSourcesId: record.dataSourcesId,
                descr: record.descr,
                status: record.status,
                minuteNum: record.minuteNum,
                warnCode: record.warnCode
            };
        } else {
            taskFormObj = deepCopy(defaultTaskFormOptions);
        }
        this.setState({
            taskForm: taskFormObj,
            taskVisible: true
        });
    }
    // 保存任务
    setTaskSend = async () => {
        this.setState({
            taskConfirmLoading: true
        });
        const params = { ...this.taskFormRef.props.form.getFieldsValue(), id: this.state.taskForm.id };
        const res = await monitorService.setTaskSend(params);
        if (res.code === '0') {
            this.setState({
                taskConfirmLoading: false,
                taskVisible: false
            }, () => {
                message.success(res.entry);
                this.taskFormRef.props.form.resetFields();
                this.getTaskData();
            });
        } else {
            this.setState({
                taskConfirmLoading: false
            });
        }
    }
    // 删除任务
    deleteTask = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.deleteTask({ id });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getTaskData();
                    }
                })();
            }
        });
    }
    // 移除屏蔽
    removeMinute = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否移除屏蔽？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.removeMinute({ id });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getTaskData();
                    }
                })();
            }
        });
    }
    // 更改状态
    execStatus = (record) => {
        const status = record.status === 'NORMAL' ? 'DISABLE' : 'NORMAL';
        const content = <div style={{ marginTop: '20px' }}><p>确认是否变更状态？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.execStatus({ id: record.id, status });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getTaskData();
                    }
                })();
            }
        });
    }
    // 关闭modal
    handleCancel = (type, ref) => {
        this[ref].props.form.resetFields();
        this.setState({
            [type]: false,
            sqlResult: ''
        });
    }
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    // sql检测
    checkSql = () => {
        this.setState({
            sqlForm: { sql: '' },
            sqlVisible: true
        });
    }
    // 保存sql检测
    setSqlSend = async () => {
        this.setState({
            sqlConfirmLoading: true
        });
        const params = { ...this.sqlFormRef.props.form.getFieldsValue() };
        const { code, entry } = await monitorService.checkSql(params);
        if (code === '0') {
            this.setState({
                sqlConfirmLoading: false,
                sqlResult: JSON.parse(entry).join('<br/>')
            });
        } else {
            this.setState({
                sqlConfirmLoading: false
            });
        }
    }
    render() {
        const {
            applications,
            pagination,
            loading,
            data,
            dataSource,
            taskForm,
            taskVisible,
            taskConfirmLoading,
            sqlForm,
            sqlVisible,
            sqlConfirmLoading,
            sqlResult
        } = this.state;
        const { getFieldDecorator } = this.props.form;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '应用名称',
            dataIndex: 'applicationId',
            key: 'applicationId',
            width: '100px',
            render: (text, record) => {
                const itemResult = applications.find((item) => {
                    return item.id === text;
                });
                return itemResult ? itemResult.key : text;
            }
        }, {
            title: '名称',
            dataIndex: 'name',
            key: 'name',
            width: '150px'
        }, {
            title: '屏蔽分钟',
            dataIndex: 'minuteNum',
            key: 'minuteNum',
            width: '100px'
        }, {
            title: '执行时间',
            dataIndex: 'cron',
            key: 'cron',
            width: '100px'
        }, {
            title: '连接池',
            dataIndex: 'dataSourcesId',
            key: 'dataSourcesId',
            width: '100px',
            render: (text, record) => {
                const itemResult = dataSource.find((item) => {
                    return item.id === text;
                });
                return itemResult ? itemResult.name : text;
            }
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            width: '60px',
            render: (text, record) => {
                return text === 'NORMAL' ? '正常' : '禁用';
            }
        }, {
            title: '告警编码',
            dataIndex: 'warnCode',
            key: 'warnCode',
            width: '100px'
        }, {
            title: '应用描述',
            dataIndex: 'descr',
            key: 'descr',
            width: '120px',
        }, {
            title: '执行语句',
            dataIndex: 'sqlCron',
            key: 'sqlCron',
            width: '200px',
            render: (text, record) => {
                return <div className={styles.sql} title={text}>{text}</div>;
            }
        }, {
            title: '操作',
            key: 'action',
            width: 200,
            render: (text, record) => {
                const layout = { marginRight: '10px', marginBottom: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setTask.bind(this, record)}>修改</Button>, 'PermissionTaskEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteTask.bind(this, record)}>删除</Button>, 'PermissionTaskDelete')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.removeMinute.bind(this, record)}>移除屏蔽</Button>, 'PermissionTaskRemove')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.execStatus.bind(this, record)}>{ record.status === 'NORMAL' ? '禁用' : '启用'} </Button>, 'PermissionTaskStatus')
                        }
                        {
                            this.props.paths.TaskTargetResult.linkPath ?
                                <Link to={{ pathname: this.props.paths.TaskTargetResult.linkPath, search: `?id=${record.id}` }}><Button type="primary" size="small" style={layout}>目标结果管理</Button></Link>
                                : null
                        }
                    </div>
                );
            }
        }];
        return (
            <div>
                <Form layout="inline" onSubmit={this.getTaskData} style={{ marginBottom: '20px' }}>
                    <FormItem>
                        {getFieldDecorator('applicationId', {})(<Select style={{ width: 200 }} filterOption={this.filterOption} showSearch optionFilterProp="children" placeholder="选择应用">
                            <Option value="">全部</Option>
                            {
                                applications.map((item, index) => {
                                    return (<Option value={item.id} key={item.id}>{item.key}</Option>);
                                })
                            }
                        </Select>)}
                    </FormItem>
                    <FormItem>
                        <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: 20 }}>查询</Button>
                        {
                            withPermission(<Button type="primary" onClick={this.setTask.bind(this)} style={{ marginRight: 20 }}>添加监控任务</Button>, 'PermissionTaskAdd')
                        }
                        {
                            withPermission(<Button type="primary" onClick={this.checkSql.bind(this)}>SQL生成工具</Button>, 'PermissionTaskSql')
                        }
                    </FormItem>
                </Form>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <TaskFormModal
                    maskClosable={false}
                    injectForm={taskForm}
                    getRef={this.getTaskFormRef}
                    title="任务添加/修改"
                    visible={taskVisible}
                    onOk={this.setTaskSend}
                    onCancel={this.handleCancel.bind(this, 'taskVisible', 'taskFormRef')}
                    footer={[
                        <Button key="submit" type="primary" loading={taskConfirmLoading} onClick={this.setTaskSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        applications,
                        dataSource
                    }}
                />
                <SqlFormModal
                    maskClosable={false}
                    injectForm={sqlForm}
                    getRef={this.getSqlFormRef}
                    title="SQL生成工具"
                    visible={sqlVisible}
                    onOk={this.setSqlSend}
                    onCancel={this.handleCancel.bind(this, 'sqlVisible', 'sqlFormRef')}
                    footer={[
                        <Button key="submit" type="primary" loading={sqlConfirmLoading} onClick={this.setSqlSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp={{
                        sqlResult
                    }}
                />
            </div>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(Form.create()(Task));
