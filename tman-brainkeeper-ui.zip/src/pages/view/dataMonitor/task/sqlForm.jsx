import React, { Component } from 'react';
import { Form, Input } from 'antd';

const { TextArea } = Input;

const FormItem = Form.Item;

class SqlForm extends Component {
    render() {
        const {
            form,
            injectForm,
            sqlResult
        } = this.props;
        const { getFieldDecorator } = form;
        return (
            <div>
                <Form>
                    <FormItem>
                        {getFieldDecorator('sql', {
                            initialValue: injectForm.sql,
                        })(<TextArea rows={5} placeholder="粘贴SQL语句" />)}
                    </FormItem>
                </Form>
                {
                    sqlResult ? (
                        <div>
                            <h4>生成结果：</h4>
                            <div style={{ resize: 'vertical', height: '200px', overflow: 'auto' }} dangerouslySetInnerHTML={{ __html: sqlResult }}></div>
                        </div>
                    ) : null
                }
            </div>
        );
    }
}

export default Form.create()(SqlForm);
