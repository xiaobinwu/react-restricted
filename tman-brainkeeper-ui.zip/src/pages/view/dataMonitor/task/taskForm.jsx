import React, { Component } from 'react';
import { Form, Select, Input, InputNumber } from 'antd';

const FormItem = Form.Item;
const { Option } = Select;

class TaskForm extends Component {
    render() {
        const {
            form,
            injectForm,
            applications,
            dataSource
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        return (
            <Form>
                <FormItem label="应用" {...formItemLayout}>
                    {getFieldDecorator('applicationId', {
                        initialValue: injectForm.applicationId,
                    })(<Select placeholder="选择应用">
                        {
                            applications.map((item, index) => {
                                return (<Option value={item.id} key={item.id}>{item.key}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="执行时间" {...formItemLayout}>
                    {getFieldDecorator('cron', {
                        initialValue: injectForm.cron,
                    })(<Input />)}
                </FormItem>
                <FormItem label="执行语句" {...formItemLayout}>
                    {getFieldDecorator('sqlCron', {
                        initialValue: injectForm.sqlCron,
                    })(<Input />)}
                </FormItem>
                <FormItem label="任务名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                    })(<Input />)}
                </FormItem>
                <FormItem label="任务描述" {...formItemLayout}>
                    {getFieldDecorator('descr', {
                        initialValue: injectForm.descr,
                    })(<Input />)}
                </FormItem>
                <FormItem label="屏蔽分钟" {...formItemLayout}>
                    {getFieldDecorator('minuteNum', {
                        initialValue: injectForm.minuteNum,
                    })(<InputNumber />)}
                </FormItem>
                <FormItem label="状态" {...formItemLayout}>
                    {getFieldDecorator('status', {
                        initialValue: injectForm.status,
                    })(<Select placeholder="请选择状态">
                        <Option value="DISABLE">禁用</Option>
                        <Option value="NORMAL">正常</Option>
                    </Select>)}
                </FormItem>
                <FormItem label="数据源" {...formItemLayout}>
                    {getFieldDecorator('dataSourcesId', {
                        initialValue: injectForm.dataSourcesId,
                    })(<Select placeholder="请选择数据源">
                        {
                            dataSource.map((item, index) => {
                                return (<Option value={item.id} key={item.id}>{item.name}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="告警编码" {...formItemLayout}>
                    {getFieldDecorator('warnCode', {
                        initialValue: injectForm.warnCode,
                    })(<Input />)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(TaskForm);
