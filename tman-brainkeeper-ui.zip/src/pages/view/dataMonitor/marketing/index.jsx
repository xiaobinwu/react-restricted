import React, { Component } from 'react';
import { Form, Row, Col, Table, DatePicker, Button, Modal, message, Select } from 'antd';
import withPermission from 'component/hoc/withPermission';
import { systemManagementService, monitorService } from 'service';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { confirm } = Modal;
const { Option } = Select;

class MarketingReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            siteList: [],
            pagination: {
                pageNum: 1,
                pageSize: 10,
                totalCount: 0
            }
        };
    }
    componentDidMount() {
        this.getSiteList();
        this.getData();
    }
    // 获取站点
    getSiteList = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'site' }, true);
        if (code === '0') {
            this.setState({
                siteList: entry
            });
        }
    }
    // 获取数据源列表
    getData = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const { rangeDate, platForm, site } = this.props.form.getFieldsValue();
        let params;
        if (rangeDate) {
            params = {
                ...pagination,
                ...{
                    beginDate: rangeDate[0].format('YYYY-MM-DD'),
                    endDate: rangeDate[1].format('YYYY-MM-DD'),
                    platForm,
                    site
                }
            };
        } else {
            params = { ...pagination, platForm, site };
        }
        delete params.totalCount;
        const { entry, code } = await monitorService.getPromotionReportList(params);
        entry.list && entry.list.forEach((item, index) => {
            item.key = index;
        });
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 全量导入
    reportCheck = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量导入？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.promotionReportAllLoad();
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    // 指定时间导入
    loadDate = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量指定时间导入？</p></div>;
        const that = this;
        const { rangeDate } = this.props.form.getFieldsValue();
        let params = {};
        if (rangeDate) {
            params = { ...{ beginDate: rangeDate[0].format('YYYY-MM-DD'), endDate: rangeDate[1].format('YYYY-MM-DD') } };
        }
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.promotionReportDateLoad({ ...params });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            siteList
        } = this.state;
        const { getFieldDecorator } = this.props.form;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '日期',
            dataIndex: 'createDate',
            key: 'createDate'
        }, {
            title: '周',
            dataIndex: 'week',
            key: 'week'
        }, {
            title: '裂变用户数',
            dataIndex: 'userCount',
            key: 'userCount'
        }, {
            title: '裂变总次数',
            dataIndex: 'totalCount',
            key: 'totalCount'
        }, {
            title: '裂变完成次数',
            dataIndex: 'withdrawCount',
            key: 'withdrawCount'
        }, {
            title: '裂变完未成次数',
            dataIndex: 'notWithdrawCount',
            key: 'notWithdrawCount'
        }];
        return (
            <div>
                <Form onSubmit={this.getData} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('platForm', {
                                    initialValue: 'ALL'
                                })(<Select placeholder="请选择端">
                                    {
                                        systemManagementService.getPlatFormsList().map((item, index) => {
                                            return <Option key={item.value}>{item.text}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('site', {
                                    initialValue: 'GB'
                                })(<Select placeholder="请选择站点">
                                    {
                                        siteList.map((item, index) => {
                                            return <Option key={item.key}>{item.key}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeDate')(<RangePicker placeholder={['开始时间', '结束时间']} />)}
                            </FormItem>
                        </Col>
                        <Col span={13}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.reportCheck} style={{ marginRight: '10px' }}>全量导入</Button>, 'PermissionMarketingReportAllImport')
                                }
                                {
                                    withPermission(<Button type="primary" onClick={this.loadDate}>指定部分时间导入</Button>, 'PermissionMarketingReportTimeImport')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    loading={loading}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    columns={columns}
                />
            </div>
        );
    }
}

export default Form.create()(MarketingReport);
