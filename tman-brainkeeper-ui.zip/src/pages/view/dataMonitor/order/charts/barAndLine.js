import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class BarAndLine extends Component {
    render() {
        const {
            xAxis,
            series1,
            series2,
            height,
            legend
        } = this.props;
        const options = {
            tooltip: {
                trigger: 'axis',
                formatter: '{a0}: {c0}<br />{a1}: {c1}%'
            },
            grid: {
                left: '100px',
                right: '100px'
            },
            toolbox: {
                feature: {
                    saveAsImage: { show: true },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true }
                }
            },
            legend: {
                data: legend
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            xAxis: [
                {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisPointer: {
                        type: 'shadow'
                    },
                    splitLine: {
                        show: false
                    },
                    data: xAxis
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: legend[0]
                },
                {
                    type: 'value',
                    name: legend[1],
                    min: 0,
                    max: 100,
                    splitLine: {
                        show: false
                    },
                    axisLabel: {
                        formatter: '{value} %'
                    }
                }
            ],
            series: [
                {
                    name: legend[0],
                    type: 'bar',
                    smooth: true,
                    data: series1,
                    label: {
                        normal: {
                            show: true,
                            position: 'inside'
                        }
                    }
                },
                {
                    name: legend[1],
                    type: 'line',
                    smooth: true,
                    data: series2,
                    yAxisIndex: 1
                }
            ]
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height, width: '100%' }}/>
            </div>
        );
    }
}
