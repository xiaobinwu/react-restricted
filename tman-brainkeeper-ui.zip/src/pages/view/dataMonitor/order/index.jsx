import React, { Component } from 'react';
import { Form, Row, Col, Table, DatePicker, Button, Modal, message, Select, Spin } from 'antd';
import { monitorService, systemManagementService } from 'service';
import withPermission from 'component/hoc/withPermission';
import { formatAmount } from 'js/util';
import BarAndLine from './charts/barAndLine';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { confirm } = Modal;
const { Option } = Select;

class OrderReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            siteList: [],
            pagination: {
                pageNum: 1,
                pageSize: 10,
                totalCount: 0
            },
            orderCounts: [],
            orderPayRates: [],
            orderPayAmounts: [],
            amountPayRates: [],
            dates: [],
            hourOrderCounts: [],
            hourOrderPayRates: [],
            hourOrderPayAmounts: [],
            hourAmountPayRates: [],
            hourDates: [],
            hourData: [],
            expandedRowKeys: [],
            pipelineCodes: [],
            hourLoading: false
        };
    }
    componentDidMount() {
        this.getSiteList();
        this.getPipelineCode();
        this.getData();
    }
    // 获取渠道
    getPipelineCode = async (site = 'GB') => {
        const { entry, code } = await monitorService.getPipelineCode({ site });
        if (code === '0') {
            this.setState({
                pipelineCodes: entry
            });
        }
    }
    // 获取站点
    getSiteList = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'site' }, true);
        if (code === '0') {
            this.setState({
                siteList: entry
            });
        }
    }
    // 获取数据源列表
    getData = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const {
            rangeDate, platForm, site, pipelineCode
        } = this.props.form.getFieldsValue();
        let params;
        if (rangeDate) {
            params = {
                ...pagination,
                ...{
                    beginDate: rangeDate[0].format('YYYY-MM-DD'),
                    endDate: rangeDate[1].format('YYYY-MM-DD'),
                    platForm,
                    site,
                    pipelineCode
                }
            };
        } else {
            params = {
                ...pagination, platForm, site, pipelineCode
            };
        }
        delete params.totalCount;
        const { entry, code } = await monitorService.getOrderReportList(params);
        if (code === '0') {
            const orderCounts = [];
            const orderPayRates = [];
            const orderPayAmounts = [];
            const amountPayRates = [];
            const dates = [];
            entry.list && entry.list.forEach((item, index) => {
                item.id = index;
                orderCounts.push(item.orderCount);
                orderPayRates.push((item.orderPayRate * 100).toFixed(2));
                orderPayAmounts.push(item.orderPayAmount);
                const payRate = item.orderAmount ? ((item.orderPayAmount / item.orderAmount) * 100).toFixed(2) : '0.00';
                amountPayRates.push(payRate);
                dates.push(item.createDate);
            });
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list,
                orderCounts: orderCounts.reverse(),
                orderPayRates: orderPayRates.reverse(),
                orderPayAmounts: orderPayAmounts.reverse(),
                amountPayRates: amountPayRates.reverse(),
                dates: dates.reverse()
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 全量导入
    reportCheck = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量导入？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.reportAllLoad();
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    // 指定时间导入
    loadDate = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量指定时间导入？</p></div>;
        const that = this;
        const { rangeDate } = this.props.form.getFieldsValue();
        let params = {};
        if (rangeDate) {
            params = { ...{ beginDate: rangeDate[0].format('YYYY-MM-DD'), endDate: rangeDate[1].format('YYYY-MM-DD') } };
        }
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.reportDateLoad({ ...params });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    onExpandedRowsChange = async (expandedRows) => {
        const lastExpandedRows = expandedRows.pop();
        const { data } = this.state;
        const { platForm, site, pipelineCode } = this.props.form.getFieldsValue();
        if (data[lastExpandedRows]) {
            const params = {
                platForm,
                site,
                pipelineCode,
                pageNum: 1,
                pageSize: 24,
                beginDate: data[lastExpandedRows].createDate,
                endDate: data[lastExpandedRows].createDate
            };
            this.setState({
                expandedRowKeys: [lastExpandedRows],
                hourLoading: true
            });
            const { code, entry } = await monitorService.getHourOrderReport({ ...params });
            if (code === '0') {
                const orderCounts = [];
                const orderPayRates = [];
                const orderPayAmounts = [];
                const amountPayRates = [];
                const dates = [];
                entry.list && entry.list.forEach((item, index) => {
                    item.id = index;
                    orderCounts.push(item.orderCount);
                    orderPayRates.push((item.orderPayRate * 100).toFixed(2));
                    orderPayAmounts.push(item.orderPayAmount);
                    const payRate = item.orderAmount ? ((item.orderPayAmount / item.orderAmount) * 100).toFixed(2) : '0.00';
                    amountPayRates.push(payRate);
                    dates.push(item.houre);
                });
                this.setState({
                    hourOrderCounts: orderCounts.reverse(),
                    hourOrderPayRates: orderPayRates.reverse(),
                    hourOrderPayAmounts: orderPayAmounts.reverse(),
                    hourAmountPayRates: amountPayRates.reverse(),
                    hourDates: dates.reverse(),
                    hourData: entry.list,
                    hourLoading: false
                });
            }
        } else {
            this.setState({
                expandedRowKeys: [],
                hourLoading: false
            });
        }
    }
    getColumns = (type) => {
        // orderCount：订单数，orderPayCount：订单支付数，orderAmount：订单金额，orderPayAmount：订单支付金额，orderPayRate:订单付款率，你这里应该还有个时间做x轴
        const columns = type.concat([{
            title: '订单数',
            dataIndex: 'orderCount',
            key: 'orderCount'
        }, {
            title: '订单支付数',
            dataIndex: 'orderPayCount',
            key: 'orderPayCount'
        }, {
            title: '订单金额（$）',
            dataIndex: 'orderAmount',
            key: 'orderAmount',
            render: (text, record) => {
                return formatAmount(text);
            }
        }, {
            title: '订单支付金额（$）',
            dataIndex: 'orderPayAmount',
            key: 'orderPayAmount',
            render: (text, record) => {
                return formatAmount(text);
            }
        }, {
            title: '金额付款率',
            dataIndex: 'amountPayRate',
            key: 'amountPayRate',
            render: (text, record) => {
                return record.orderAmount ? `${((record.orderPayAmount / record.orderAmount) * 100).toFixed(2)}%` : '0%';
            }
        }, {
            title: '订单付款率',
            dataIndex: 'orderPayRate',
            key: 'orderPayRate',
            render: (text, record) => {
                return `${(text * 100).toFixed(2)}%`;
            }
        }]);
        return columns;
    }
    render() {
        const {
            pagination,
            loading,
            data,
            siteList,
            orderCounts,
            orderPayRates,
            orderPayAmounts,
            amountPayRates,
            dates,
            expandedRowKeys,
            hourOrderCounts,
            hourOrderPayRates,
            hourOrderPayAmounts,
            hourAmountPayRates,
            hourDates,
            hourData,
            hourLoading,
            pipelineCodes
        } = this.state;
        const { getFieldDecorator } = this.props.form;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = this.getColumns([{
            title: '日期',
            dataIndex: 'createDate',
            key: 'createDate'
        }, {
            title: '周',
            dataIndex: 'week',
            key: 'week'
        }]);
        const hourColumns = this.getColumns([{
            title: '小时',
            dataIndex: 'houre',
            key: 'houre'
        }]);
        return (
            <div>
                <Form onSubmit={this.getData} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('platForm', {
                                    initialValue: 'ALL'
                                })(<Select placeholder="请选择端">
                                    {
                                        systemManagementService.getPlatFormsList().map((item, index) => {
                                            return <Option key={item.value}>{item.text}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('site', {
                                    initialValue: 'GB'
                                })(<Select placeholder="请选择站点" onChange={this.getPipelineCode}>
                                    {
                                        siteList.map((item, index) => {
                                            return <Option key={item.key}>{item.key}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('pipelineCode', {
                                    initialValue: ''
                                })(<Select placeholder="请选择渠道" disabled={pipelineCodes.length === 0}>
                                    <Option value=''>全部</Option>
                                    {
                                        pipelineCodes.map((item, index) => {
                                            return <Option key={item.code} value={item.code}>{item.name}</Option>;
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeDate')(<RangePicker placeholder={['开始时间', '结束时间']} />)}
                            </FormItem>
                        </Col>
                        <Col span={10}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.reportCheck} style={{ marginRight: '10px' }}>全量导入</Button>, 'PermissionOrderReportAllImport')
                                }
                                {
                                    withPermission(<Button type="primary" onClick={this.loadDate}>指定部分时间导入</Button>, 'PermissionOrderReportTimeImport')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    rowKey="id"
                    loading={loading}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    columns={columns}
                    expandedRowRender={(record) => {
                        return (<div>
                            <Spin spinning={hourLoading}>
                                <BarAndLine height={250} xAxis={hourDates} series1={hourOrderCounts} series2={hourOrderPayRates} legend={['订单数', '订单付款率']}/>
                                <BarAndLine height={250} xAxis={hourDates} series1={hourOrderPayAmounts} series2={hourAmountPayRates} legend={['支付金额', '金额付款率']}/>
                                <Table
                                    style={{ marginTop: 12 }}
                                    size="small"
                                    rowKey="id"
                                    dataSource={hourData}
                                    pagination={false}
                                    columns={hourColumns}
                                />
                            </Spin>
                        </div>);
                    }}
                    expandedRowKeys={expandedRowKeys}
                    onExpandedRowsChange={this.onExpandedRowsChange}
                    footer={() => {
                        return <div>
                            <BarAndLine height={500} xAxis={dates} series1={orderCounts} series2={orderPayRates} legend={['订单数', '订单付款率']}/>
                            <BarAndLine height={500} xAxis={dates} series1={orderPayAmounts} series2={amountPayRates} legend={['支付金额', '金额付款率']}/>
                        </div>;
                    }}
                />
            </div>
        );
    }
}

export default Form.create()(OrderReport);
