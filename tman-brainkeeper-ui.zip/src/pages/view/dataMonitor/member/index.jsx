import React, { Component } from 'react';
import { Form, Row, Col, Table, DatePicker, Button, Modal, message } from 'antd';
import withPermission from 'component/hoc/withPermission';
import { monitorService } from 'service';

const { RangePicker } = DatePicker;
const FormItem = Form.Item;
const { confirm } = Modal;

class MemberReport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 10,
                totalCount: 0
            }
        };
    }
    componentDidMount() {
        this.getData();
    }
    // 获取数据源列表
    getData = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const { rangeDate } = this.props.form.getFieldsValue();
        let params;
        if (rangeDate) {
            params = {
                ...pagination,
                ...{
                    beginDate: rangeDate[0].format('YYYY-MM-DD'),
                    endDate: rangeDate[1].format('YYYY-MM-DD')
                }
            };
        } else {
            params = { ...pagination };
        }
        delete params.totalCount;
        const { entry, code } = await monitorService.getMemberReportList(params);
        entry.list && entry.list.forEach((item, index) => {
            item.key = index;
        });
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 全量导入
    reportCheck = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量导入？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.memberReportAllLoad();
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    // 指定时间导入
    loadDate = () => {
        const content = <div style={{ marginTop: '20px' }}><p>是否全量指定时间导入？</p></div>;
        const that = this;
        const { rangeDate } = this.props.form.getFieldsValue();
        let params = {};
        if (rangeDate) {
            params = { ...{ beginDate: rangeDate[0].format('YYYY-MM-DD'), endDate: rangeDate[1].format('YYYY-MM-DD') } };
        }
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await monitorService.memberReportDateLoad({ ...params });
                    if (res.code === '0') {
                        message.success(res.entry);
                        that.getData();
                    }
                })();
            }
        });
    }
    render() {
        const {
            pagination,
            loading,
            data
        } = this.state;
        const { getFieldDecorator } = this.props.form;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '日期',
            dataIndex: 'createDate',
            key: 'createDate'
        }, {
            title: '周',
            dataIndex: 'week',
            key: 'week'
        }, {
            title: '注册用户数',
            dataIndex: 'regUserCount',
            key: 'regUserCount',
            render: (text, record) => {
                return <div>
                    <div>PC：{record.regUserCountPC}</div>
                    <div>WAP：{record.regUserCountWAP}</div>
                    <div>IOS：{record.regUserCountIOS}</div>
                    <div>Android：{record.regUserCountAndroid}</div>
                    <div>Total：{record.regUserCountPC + record.regUserCountWAP + record.regUserCountIOS + record.regUserCountAndroid}</div>
                </div>;
            }
        }, {
            title: '登录用户数',
            dataIndex: 'loginUserCount',
            key: 'loginUserCount',
            render: (text, record) => {
                return <div>
                    <div>PC：{record.loginUserCountPC}</div>
                    <div>WAP：{record.loginUserCountWAP}</div>
                    <div>IOS：{record.loginUserCountIOS}</div>
                    <div>Android：{record.loginUserCountAndroid}</div>
                    <div>Total：{record.loginUserCountPC + record.loginUserCountWAP + record.loginUserCountIOS + record.loginUserCountAndroid}</div>
                </div>;
            }
        }, {
            title: '登录次数',
            dataIndex: 'loginCount',
            key: 'loginCount',
            render: (text, record) => {
                return <div>
                    <div>PC：{record.loginCountPC}</div>
                    <div>WAP：{record.loginCountWAP}</div>
                    <div>IOS：{record.loginCountIOS}</div>
                    <div>Android：{record.loginCountAndroid}</div>
                    <div>Total：{record.loginCountPC + record.loginCountWAP + record.loginCountIOS + record.loginCountAndroid}</div>
                </div>;
            }
        }, {
            title: '积分增加总数',
            dataIndex: 'pointsAddNum',
            key: 'pointsAddNum'
        }, {
            title: '积分消耗总数',
            dataIndex: 'pointsSubNum',
            key: 'pointsSubNum'
        }, {
            title: '商品收藏增加数',
            dataIndex: 'favoritesGoodsAddNum',
            key: 'favoritesGoodsAddNum'
        }, {
            title: '店铺收藏增加数',
            dataIndex: 'favoritesShopAddNum',
            key: 'favoritesShopAddNum'
        }, {
            title: '地址记录增加数',
            dataIndex: 'addressAddNum',
            key: 'addressAddNum'
        }, {
            title: '邮件订阅增加数',
            dataIndex: 'emailSubscribeAddNum',
            key: 'emailSubscribeAddNum'
        }, {
            title: '签到用户数',
            dataIndex: 'signUserNum',
            key: 'signUserNum'
        }, {
            title: '游客增加人数',
            dataIndex: 'visitorAddNum',
            key: 'visitorAddNum'
        }];
        return (
            <div>
                <Form onSubmit={this.getData} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeDate')(<RangePicker placeholder={['开始时间', '结束时间']} />)}
                            </FormItem>
                        </Col>
                        <Col span={13}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.reportCheck} style={{ marginRight: '10px' }}>全量导入</Button>, 'PermissionMemberReportAllImport')
                                }
                                {
                                    withPermission(<Button type="primary" onClick={this.loadDate}>指定部分时间导入</Button>, 'PermissionMemberReportTimeImport')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    loading={loading}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    columns={columns}
                />
            </div>
        );
    }
}

export default Form.create()(MemberReport);
