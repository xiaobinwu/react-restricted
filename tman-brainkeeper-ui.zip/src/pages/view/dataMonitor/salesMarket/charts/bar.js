import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Bar extends Component {
    getLastBarData = (series, xAxis) => {
        if (series) {
            for (let index = series.length - 1; index >= 0; index--) { // eslint-disable-line
                if (series[index] > 0) {
                    return {
                        value: series[index],
                        xAxis: index,
                        yAxis: Math.ceil(series[index])
                    };
                }
            }
        }
        return {
            value: 0,
            xAxis: 0,
            yAxis: 0
        };
    }
    render() {
        const {
            xAxis,
            series,
            color,
            legend
        } = this.props;
        const options = {
            backgroundColor: 'transparent',
            tooltip: {
                trigger: 'axis'
            },
            textStyle: {
                color: '#eeedf2',
            },
            grid: {
                left: '10%',
                right: '10%'
            },
            legend: {
                data: [legend],
                left: 20,
                textStyle: {
                    color
                }
            },
            xAxis: [
                {
                    type: 'category',
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisPointer: {
                        type: 'shadow'
                    },
                    axisLine: {
                        lineStyle: {
                            color
                        }
                    },
                    axisLabel: {
                        color
                    },
                    splitLine: {
                        show: false
                    },
                    data: xAxis
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    splitLine: {
                        show: false
                    },
                    axisLine: {
                        lineStyle: {
                            color
                        }
                    },
                    axisLabel: {
                        color
                    },
                },
            ],
            series: [
                {
                    name: legend,
                    type: 'bar',
                    smooth: true,
                    data: series,
                    markPoint: {
                        symbolSize: 60,
                        data: [
                            { name: '最后一个值', ...this.getLastBarData(series, xAxis) },
                        ]
                    },
                    itemStyle: {
                        color
                    }
                }
            ]
        };

        return (
            <div>
                <ReactEcharts
                    option={options}
                    style={{ height: 300, width: '100%', marginTop: '25px' }}/>
            </div>
        );
    }
}
