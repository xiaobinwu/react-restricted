const css = `
    .echarts-for-react {
        border: 1px solid transparent!important;
    }
    .ant-breadcrumb,
    .ant-breadcrumb-separator,
    .ant-breadcrumb > span:last-child {
        color: #fefefe!important;
    }
    .ant-layout,
    .system-main {
        background-color: #020228!important;
    }
    .system-main {
        position: relative;
    }
    .ant-layout-sider,
    .ant-menu-dark, .ant-menu-dark .ant-menu-sub,
    .system-header,
    .system-logo,
    .system-content,
    .system-footer,
    .stystem-trigger:hover {
        background: none!important;
    }
`;

export default css;
