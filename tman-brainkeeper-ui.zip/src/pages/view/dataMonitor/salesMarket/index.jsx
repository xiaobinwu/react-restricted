import React, { Component } from 'react';
import { monitorService } from 'service';
import { Col, Row, Icon } from 'antd';
import CountUp from 'react-countup';
import { formatAmount, toggleFullScreen } from 'js/util';
import Bar from './charts/bar';
import styles from './index.css';

class SalesMarket extends Component {
    constructor(props) {
        super(props);
        this.state = {
            oldOrderAmount: 0,
            orderAmount: 0,
            orderAmountOneDaySeries: {},
            oldOrderCount: 0,
            orderCount: 0,
            orderCountOneDaySeries: {},
            oldPayCount: 0,
            payCount: 0,
            payCountOneDaySeries: {},
            oldPayAmount: 0,
            payAmount: 0,
            payAmountOneDaySeries: {},
            isFullScreen: false
        };
        this.$main = document.querySelector('.system-main');
        this.$main.classList.add(styles.bg);

        this.screenHeight = window.screen.height;
    }
    componentDidMount() {
        // 引入自定义的css来覆盖，做特殊化处理
        import(/* webpackChunkName: 'coverCss' */ './coverCss.js').then((coverCss) => {
            this.createCustomCSS(coverCss.default);
        });
        this.getSalesMarketData();
    }
    componentWillUnmount() {
        // 移除定时器
        this.clearTimer();
        // 移除$main的背景
        this.$main.classList.remove(styles.bg);
        // 移除style标签
        this.styleDom.parentNode.removeChild(this.styleDom);
        this.styleDom = null;
    }

    canvasCode() {
        /* eslint-disable */
        const matrix = document.getElementById('matrix');
        const context = matrix.getContext('2d');
        matrix.height = window.innerHeight;
        matrix.width = window.innerWidth;
        const drop = [];
        const fontSize = 16;
        const columns = matrix.width / fontSize;

        for (let i = 0; i < columns; i++) {
            drop[i] = 1;
        }

        function drawMatrix() {
            context.fillStyle = '#020228';
            context.fillRect(0, 0, matrix.width, matrix.height);
            context.fillStyle = 'green';
            context.font = fontSize + 'px';
            for (let i=0; i < columns; i++) {
                context.fillText(Math.floor(Math.random() * 2), i * fontSize, drop[i] * fontSize);
                if(drop[i] * fontSize > (matrix.height*2/3) && Math.random() > 0.85){
                    drop[i] = 0;
                }
                drop[i] ++;
            }
        }

        setInterval(drawMatrix, 100);
    }

    // 放大
    zoomIn = () => {
        this.setState({
            isFullScreen: true
        }, () => {
            toggleFullScreen(this.state.isFullScreen, () => {
                this.$main.classList.add(styles.fixed);
            });
        });
    }
    // 缩小
    zoomOut = () => {
        this.setState({
            isFullScreen: false
        }, () => {
            toggleFullScreen(this.state.isFullScreen, () => {
                this.$main.classList.remove(styles.fixed);
            });
        });
    }
    // 创建自定义css标签
    createCustomCSS = (css) => {
        this.styleDom = document.createElement('style');
        this.styleDom.type = 'text/css';
        this.styleDom.appendChild(document.createTextNode(css));
        document.getElementsByTagName('head')[0].appendChild(this.styleDom);
    }
    // 自定义coutUp的时间滚动组件的格式展示
    formattingFn = (hasPrefix, value) => {
        let gmvDom = '';
        if (value) {
            let gmv = [];
            if (hasPrefix) {
                gmv = formatAmount(value).split('');
            } else {
                gmv = formatAmount(value, 0).split('');
            }
            gmv.forEach((item, index) => {
                if (item.match('^[0-9]*$')) {
                    gmvDom += `<div class='${styles.count}'>${item}</div>`;
                } else {
                    gmvDom += `<div class='${styles.character}'>${item}</div>`;
                }
            });
        }
        return hasPrefix ? `<div class='${styles.prefix} ${styles.count}'>$</div>${gmvDom}` : gmvDom;
    };
    handleSeries = (entry) => {
        const handledSeries = [];
        const { series } = entry;
        if (series && series.length > 0) {
            series.forEach((item) => {
                handledSeries.push(item.toFixed(2));
            });
            entry.series = handledSeries;
            return entry;
        }
        return entry;
    }
    clearTimer = () => {
        clearTimeout(this.timer);
        this.timer = null;
    }
    // 获取销售大盘数据
    getSalesMarketData = async () => {
        this.clearTimer();
        const { code, entry } = await monitorService.getSalesMarketData();
        if (code === 0) {
            const {
                orderAmount,
                orderCount,
                payCount,
                payAmount
            } = this.state;
            const oldOrderAmount = orderAmount;
            const oldOrderCount = orderCount;
            const oldPayCount = payCount;
            const oldPayAmount = payAmount;
            this.setState({
                oldOrderAmount,
                oldOrderCount,
                oldPayCount,
                oldPayAmount,
                orderAmount: entry.orderAmount,
                orderCount: entry.orderCount,
                payCount: entry.payCount,
                payAmount: entry.payAmount,
                orderAmountOneDaySeries: this.handleSeries(entry.orderAmountOneDaySeries),
                orderCountOneDaySeries: entry.orderCountOneDaySeries,
                payAmountOneDaySeries: this.handleSeries(entry.payAmountOneDaySeries),
                payCountOneDaySeries: entry.payCountOneDaySeries
            });
        }
        this.timer = setTimeout(() => { this.getSalesMarketData(); }, 1000);
    }
    render() {
        const {
            oldOrderAmount,
            orderAmount,
            oldOrderCount,
            orderCount,
            oldPayCount,
            payCount,
            oldPayAmount,
            payAmount,
            orderAmountOneDaySeries,
            orderCountOneDaySeries,
            payAmountOneDaySeries,
            payCountOneDaySeries,
            isFullScreen
        } = this.state;
        return (
            <React.Fragment>
                <canvas className={styles.bgCanvas} id="matrix"></canvas>
                <div>
                    <div className={styles.iconContainer}>
                        {
                            isFullScreen ? <Icon type="zoom-out" className={styles.icon} theme="outlined" onClick={this.zoomOut} />
                                : <Icon type="zoom-in" className={styles.icon} theme="outlined" onClick={this.zoomIn} />
                        }
                    </div>
                    <Row gutter={20}>
                        <Col span={12} style={{ marginBottom: 30 }} className={styles.col}>
                            <div className={styles.card}>
                                <div className={styles.cardContent}>
                                    <div className={styles.cardtitle}>Gearbest-订单数</div>
                                    <CountUp className={`${styles.countUp} ${styles.countUp1}`} start={oldOrderCount} end={orderCount} duration={1} formattingFn={this.formattingFn.bind(this, false)}/>
                                    <Bar xAxis={orderCountOneDaySeries.xAxis} series={orderCountOneDaySeries.series} legend="每小时订单数" color="#b57ddd"/>
                                </div>
                            </div>
                        </Col>
                        <Col span={12} style={{ marginBottom: 30 }} className={styles.col}>
                            <div className={styles.card}>
                                <div className={styles.cardContent}>
                                    <div className={styles.cardtitle}>Gearbest-订单金额</div>
                                    <CountUp className={`${styles.countUp} ${styles.countUp2}`} start={oldOrderAmount} end={orderAmount} duration={1} decimals={2} formattingFn={this.formattingFn.bind(this, true)}/>
                                    <Bar xAxis={orderAmountOneDaySeries.xAxis} series={orderAmountOneDaySeries.series} legend="每小时订单金额" color="#fdc500" />
                                </div>
                            </div>
                        </Col>
                        <Col span={12} className={styles.col}>
                            <div className={styles.card}>
                                <div className={styles.cardContent}>
                                    <div className={styles.cardtitle}>Gearbest-支付数</div>
                                    <CountUp className={`${styles.countUp} ${styles.countUp3}`} start={oldPayCount} end={payCount} duration={1} formattingFn={this.formattingFn.bind(this, false)}/>
                                    <Bar xAxis={payCountOneDaySeries.xAxis} series={payCountOneDaySeries.series} legend="每小时支付数" color="#32a3ff"/>
                                </div>
                            </div>
                        </Col>
                        <Col span={12} className={styles.col}>
                            <div className={styles.card}>
                                <div className={styles.cardContent}>
                                    <div className={styles.cardtitle}>Gearbest-支付金额</div>
                                    <CountUp className={`${styles.countUp} ${styles.countUp4}`} start={oldPayAmount} end={payAmount} duration={1} decimals={2} formattingFn={this.formattingFn.bind(this, true)}/>
                                    <Bar xAxis={payAmountOneDaySeries.xAxis} series={payAmountOneDaySeries.series} legend="每小时支付金额" color="#00c6d3"/>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </div>
            </React.Fragment>
        );
    }
}

export default SalesMarket;
