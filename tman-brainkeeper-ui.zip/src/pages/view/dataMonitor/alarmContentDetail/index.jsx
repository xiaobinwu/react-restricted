import React, { Component } from 'react';
import { Row, Col, Spin, message, Button, Card, Input } from 'antd';
import { getQueryString } from 'js/util';
import { monitorService } from 'service';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import styles from './index.css';

const { TextArea } = Input;

const statusSet = {
    initialise: '未处理',
    doing: '处理中',
    finish: '已完成'
};

class AlarmContentDetail extends Component {
    constructor(props) {
        super(props);
        const result = getQueryString();
        this.state = {
            currentId: result.id,
            loading: false,
            title: '',
            date: '',
            target: '',
            comparator: '',
            result: [],
            status: '',
            receive: '',
            processResult: '',
            descr: ''
        };
    }
    componentDidMount() {
        this.getAlarmContentDetail();
    }
    getAlarmContentDetail = async () => {
        this.setState({
            loading: true
        });
        const { entry, code } = await monitorService.getAlarmContentDetail({ id: this.state.currentId });
        const finalEntry = JSON.parse(entry);
        const content = JSON.parse(finalEntry.content);
        if (code === '0') {
            this.setState({
                title: finalEntry.title,
                status: finalEntry.status,
                processResult: finalEntry.processResult,
                date: content.date,
                target: content.target,
                comparator: content.comparator,
                result: content.result,
                receive: content.receive,
                descr: content.descr,
                loading: false
            });
        }
    }
    removeMinute = async () => {
        const res = await monitorService.removeWarnId({ id: this.state.currentId });
        if (res.code === '0') {
            message.success(res.entry);
            this.getAlarmContentDetail();
        }
    }
    process = async () => {
        const {
            currentId,
            processResult
        } = this.state;
        const res = await monitorService.processAlarmContentDetail({ id: currentId, text: processResult });
        if (res.code === '0') {
            message.success('处理成功');
            this.getAlarmContentDetail();
        }
    }
    changeProcessResult = (e) => {
        const val = e.target.value;
        this.setState({
            processResult: val
        });
    }
    render() {
        const {
            loading,
            title,
            status,
            processResult,
            date,
            target,
            comparator,
            result,
            receive,
            descr
        } = this.state;
        const layout = { marginRight: 10 };
        return (
            <Spin spinning={loading}>
                <Row>
                    <Col span={12} offset={6}>
                        <Card style={{ padding: 20 }}>
                            <p>
                                <span style={layout}>任务名称：</span>
                                <span>{title || '-'}</span>
                            </p>
                            <p>
                                <span style={layout}>告警（北京）时间：</span>
                                <span>{date || '-'}</span>
                            </p>
                            <p>
                                <span style={layout}>预期值：</span>
                                <span>{target || '-'}</span>
                            </p>
                            <p>
                                <span style={layout}>比较符：</span>
                                <span>{comparator || '-'}</span>
                            </p>
                            <div>
                                <span style={layout}>查询结果值：</span>
                                {
                                    result.map((item, index) => {
                                        return (<p key={index} style={{ paddingLeft: 72 }}>
                                            <span style={{ marginRight: 10 }}>值{index}：</span>
                                            <span className={styles.content}>
                                                {item}
                                            </span>
                                        </p>);
                                    })
                                }
                            </div>
                            <p>
                                <span style={layout}>处理状态：</span>
                                <span>
                                    {statusSet[status]}
                                </span>
                            </p>
                            <p>
                                <span style={layout}>接收人：</span>
                                <span>{receive || '-'}</span>
                            </p>
                            {
                                status !== 'initialise' ? <p>
                                    <span style={layout}>处理方案：</span>
                                    <span>{processResult || '-'}</span>
                                </p> : null
                            }
                            <p>
                                <span style={layout}>任务描述：</span>
                                <span>{descr || '-'}</span>
                            </p>
                            {
                                status === 'initialise' ? <p>
                                    <span style={layout}>处理结果：</span>
                                    <TextArea rows={5} onChange={this.changeProcessResult.bind(this)} style={{ marginTop: 10 }}/>
                                </p> : null
                            }
                            <p style={{ marginBottom: 20 }}>
                                <Link to={{ pathname: this.props.paths.AlarmContent.linkPath }}> <Button type="primary" style={{ marginRight: 20 }}>返回</Button></Link>
                                <Button type="primary" style={{ marginRight: 20 }} onClick={this.removeMinute}>清除告警屏蔽</Button>
                                {
                                    status === 'initialise' ?
                                        <Button type="primary" onClick={this.process}>处理</Button>
                                        : null
                                }
                            </p>
                            <p style={{ color: '#e24d42' }}>
                                清除告警屏蔽说明:每个任务告警后在指定的时间内不会再次告警，如配置屏蔽时间1个小时，则在收到当前告警开始一个小时内不会再收到告警，一个小时后可以再次收到。收到告警的时候点击“清除告警屏蔽”则不会有一个小时屏蔽限制（下次告警后屏蔽会再次生效，可再次点击清除屏蔽），可以能立马再次接收到告警
                            </p>
                        </Card>
                    </Col>
                </Row>
            </Spin>
        );
    }
}

const stateToProps = ({ routeState }) => ({
    paths: routeState.paths
});

export default connect(stateToProps)(AlarmContentDetail);
