import React, { Component } from 'react';
import { systemManagementService } from 'service';
import { Row, Col, Table, Button, Input, message, Modal } from 'antd';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import SettingForm from './settingForm';

const { confirm } = Modal;
// 添加/修改应用
const SettingFormModal = withFormModal(SettingForm);

const defaultSettingFormOptions = {
    id: '',
    key: '',
    remark: '',
    scope: '',
    sort: '',
    value: ''
};

class Setting extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            keyword: '',
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0,
                countSql: true
            },
            settingForm: deepCopy(defaultSettingFormOptions),
            settingVisible: false,
            settingConfirmLoading: false
        };
    }
    componentDidMount() {
        this.getData();
    }
    // 获取数据
    getData = async (e) => {
        e && e.preventDefault();
        const {
            pagination,
            keyword
        } = this.state;
        const params = {
            ...(keyword ? { keyword } : {}),
            countSql: true,
            ...pagination
        };
        delete params.totalCount;
        this.setState({
            loading: true
        });
        const { entry, code } = await systemManagementService.getSettingList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 添加、修改应用Modal
    setSetting = (record) => {
        let settingFormObj = {};
        if (record) {
            settingFormObj = {
                id: record.id,
                key: record.key,
                remark: record.remark,
                scope: record.scope,
                sort: record.sort,
                value: record.value
            };
        } else {
            settingFormObj = deepCopy(defaultSettingFormOptions);
        }
        this.setState({
            settingForm: settingFormObj,
            settingVisible: true
        });
    }
    // 保存
    setSettingSend = async () => {
        this.settingFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    settingConfirmLoading: true
                });
                let params = { ...this.settingFormRef.props.form.getFieldsValue() };
                if (this.state.settingForm.id) {
                    params = { ...params, ...{ id: this.state.settingForm.id } };
                }
                const res = await systemManagementService.setSettingSend(params);
                if (res.code === '0') {
                    this.setState({
                        settingConfirmLoading: false,
                        settingVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.settingFormRef.props.form.resetFields();
                        this.getData();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        settingConfirmLoading: false
                    });
                }
            }
        });
    }
    // 删除
    deleteSetting = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该站点？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await systemManagementService.deleteSetting({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getData();
                    }
                })();
            }
        });
    }
    // 改变Input
    changeInput = (type, e) => {
        this.setState({
            [type]: e.target.value.replace(/(^\s*)|(\s*$)/g, '')
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 获取应用表单ref
    getSettingFormRef = (ref) => {
        this.settingFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.settingFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            settingForm,
            settingVisible,
            settingConfirmLoading
        } = this.state;
        const columns = [{
            title: '编号',
            dataIndex: 'id',
            key: 'id'
        }, {
            title: '作用域',
            dataIndex: 'scope',
            key: 'scope'
        }, {
            title: '键',
            dataIndex: 'key',
            key: 'key'
        }, {
            title: '值',
            dataIndex: 'value',
            key: 'value',
            width: 300
        }, {
            title: '排序',
            dataIndex: 'sort',
            key: 'sort'
        }, {
            title: '备注',
            dataIndex: 'remark',
            key: 'remark'
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (text, record) => {
                const layout = { marginRight: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setSetting.bind(this, record)}>修改</Button>, 'PermissionSettingEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteSetting.bind(this, record)}>删除</Button>, 'PermissionSettingDelete')
                        }
                    </div>
                );
            }
        }];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 30 }}>
                    <Col span={3}>
                        <Input onChange={this.changeInput.bind(this, 'keyword')} placeholder="请填写关键字"/>
                    </Col>
                    <Col span={21}>
                        <Button icon="search" type="primary" onClick={this.getData} style={{ marginRight: 20 }}>查询</Button>
                        {
                            withPermission(<Button type="primary" onClick={this.setSetting.bind(this, null)}>新增</Button>, 'PermissionSettingAdd')
                        }
                    </Col>
                </Row>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <SettingFormModal
                    maskClosable={false}
                    injectForm={settingForm}
                    getRef={this.getSettingFormRef}
                    title="配置添加/修改"
                    visible={settingVisible}
                    onOk={this.setSettingSend}
                    onCancel={this.handleCancel.bind(this, 'settingVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={settingConfirmLoading} onClick={this.setSettingSend}>
                            确定
                        </Button>
                    ]}
                />

            </div>
        );
    }
}

export default Setting;
