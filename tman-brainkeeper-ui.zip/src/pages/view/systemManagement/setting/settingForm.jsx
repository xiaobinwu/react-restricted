import React, { Component } from 'react';
import { Form, Input, InputNumber } from 'antd';

const { TextArea } = Input;
const FormItem = Form.Item;

class SettingForm extends Component {
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        return (
            <Form>
                <FormItem label="Key" {...formItemLayout}>
                    {getFieldDecorator('key', {
                        initialValue: injectForm.key,
                        rules: [{
                            required: true, message: 'Key不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="Scope" {...formItemLayout}>
                    {getFieldDecorator('scope', {
                        initialValue: injectForm.scope,
                        rules: [{
                            required: true, message: 'Scope不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="值" {...formItemLayout}>
                    {getFieldDecorator('value', {
                        initialValue: injectForm.value,
                        rules: [{
                            required: true, message: '值不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="排序" {...formItemLayout}>
                    {getFieldDecorator('sort', {
                        initialValue: injectForm.sort,
                        rules: [{
                            required: true, message: '排序不为空',
                        }],
                    })(<InputNumber min={0}/>)}
                </FormItem>
                <FormItem label="备注" {...formItemLayout}>
                    {getFieldDecorator('remark', {
                        initialValue: injectForm.remark,
                        rules: [{
                            required: true, message: '备注不为空',
                        }]
                    })(<TextArea rows={4}/>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(SettingForm);
