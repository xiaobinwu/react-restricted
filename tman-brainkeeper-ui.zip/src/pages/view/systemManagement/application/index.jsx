import React, { Component } from 'react';
import { Table, Button, message, Modal, Form, Row, Col, Select } from 'antd';
import { systemManagementService } from 'service';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import AppForm from './appForm';

const { confirm } = Modal;
const FormItem = Form.Item;
const { Option } = Select;

// 添加/修改应用的表单默认字段
const defaultAppFormOptions = {
    id: '',
    name: '',
    owner: '',
    description: '',
    domain: '',
    type: ''
};

// 添加/修改应用
const AppFormModal = withFormModal(AppForm);

class Application extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            appForm: deepCopy(defaultAppFormOptions),
            appVisible: false,
            appConfirmLoading: false,
            domainList: [],
            typeList: []
        };
    }
    componentDidMount() {
        this.getApplications();
        this.getDomainList();
        this.getTypeList();
    }
    // 获取所属域
    getDomainList = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'business_domain' }, true);
        if (code === '0') {
            this.setState({
                domainList: entry
            });
        }
    }
    // 获取应用类型列表
    getTypeList = async () => {
        const { entry, code } = await systemManagementService.getConfigList({ scope: 'app_type' }, true);
        if (code === '0') {
            this.setState({
                typeList: entry
            });
        }
    }
    // 获取应用列表
    getApplications = async (e) => {
        e && e.preventDefault();
        const { pagination } = this.state;
        this.setState({
            loading: true
        });
        const params = { ...pagination, ...this.props.form.getFieldsValue() };
        delete params.totalCount;
        const { entry, code } = await systemManagementService.getAllApplicationsByPage(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getApplications();
            });
        }
    }
    // 添加、修改应用Modal
    setApplication = (record) => {
        let appFormObj = {};
        if (record) {
            appFormObj = {
                id: record.id,
                name: record.name,
                owner: record.owner,
                description: record.description,
                domain: record.domain,
                type: record.type
            };
        } else {
            appFormObj = deepCopy(defaultAppFormOptions);
        }
        this.setState({
            appForm: appFormObj,
            appVisible: true
        });
    }
    setApplicationSend = async () => {
        this.appFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    appConfirmLoading: true
                });
                let params = { ...this.appFormRef.props.form.getFieldsValue() };
                if (this.state.appForm.id) {
                    params = { ...params, ...{ id: this.state.appForm.id } };
                }
                const res = await systemManagementService.setApplicationSend(params);
                if (res.code === '0') {
                    this.setState({
                        appConfirmLoading: false,
                        appVisible: false
                    }, () => {
                        message.success(res.message);
                        this.appFormRef.props.form.resetFields();
                        this.getApplications();
                    });
                } else {
                    this.setState({
                        appConfirmLoading: false
                    });
                }
            }
        });
    }
    // 删除应用
    deleteApplication = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await systemManagementService.deleteApplication({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getApplications();
                    }
                })();
            }
        });
    }
    // 获取应用表单ref
    getAppFormRef = (ref) => {
        this.appFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.appFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const {
            pagination,
            loading,
            data,
            appVisible,
            appForm,
            appConfirmLoading,
            domainList,
            typeList
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        const columns = [{
            title: '应用名称',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '所属域',
            dataIndex: 'domain',
            key: 'domain'
        }, {
            title: '应用类型',
            dataIndex: 'type',
            key: 'type'
        }, {
            title: '应用负责联系人',
            dataIndex: 'owner',
            key: 'owner'
        }, {
            title: '应用描述',
            dataIndex: 'description',
            key: 'description'
        }, {
            title: '操作',
            key: 'action',
            width: 300,
            render: (text, record) => {
                const layout = { marginRight: '10px', marginBottom: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setApplication.bind(this, record)}>修改</Button>, 'PermissionApplicationEdit')
                        }
                        {/* {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteApplication.bind(this, record)}>删除</Button>, 'PermissionApplicationDelete')
                        } */}
                    </div>
                );
            }
        }];
        return (
            <div>
                <Form onSubmit={this.getApplications} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('domain')(<Select
                                    showSearch
                                    placeholder='请选择所属域'
                                    optionFilterProp='children'
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                >
                                    <Option value="">全部</Option>
                                    {
                                        domainList.map((item) => {
                                            return (<Option value={item.key} key={item.id}>{item.key}</Option>);
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('type')(<Select
                                    showSearch
                                    placeholder='请选择应用类型'
                                    optionFilterProp='children'
                                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                >
                                    <Option value="">全部</Option>
                                    {
                                        typeList.map((item) => {
                                            return (<Option value={item.key} key={item.id}>{item.key}</Option>);
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={18}>
                            <FormItem>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: '10px' }}>查询</Button>
                                {
                                    withPermission(<Button type="primary" onClick={this.setApplication}>创建应用</Button>, 'PermissionApplicationAdd')
                                }
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <AppFormModal
                    maskClosable={false}
                    injectForm={appForm}
                    getRef={this.getAppFormRef}
                    title="应用添加/修改"
                    visible={appVisible}
                    onOk={this.setApplicationSend}
                    onCancel={this.handleCancel.bind(this, 'appVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={appConfirmLoading} onClick={this.setApplicationSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        domainList,
                        typeList
                    }}
                />
            </div>
        );
    }
}

export default Form.create()(Application);
