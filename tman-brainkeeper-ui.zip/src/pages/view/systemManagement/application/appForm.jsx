import React, { Component } from 'react';
import { Form, Input, Select } from 'antd';

const FormItem = Form.Item;
const { Option } = Select;

class AppForm extends Component {
    render() {
        const {
            form,
            injectForm,
            domainList,
            typeList
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 6 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 },
            }
        };
        return (
            <Form>
                <FormItem label="应用名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true, message: '应用名称不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="应用负责联系人" {...formItemLayout}>
                    {getFieldDecorator('owner', {
                        initialValue: injectForm.owner,
                    })(<Input />)}
                </FormItem>
                <FormItem label="应用描述" {...formItemLayout}>
                    {getFieldDecorator('description', {
                        initialValue: injectForm.description,
                    })(<Input />)}
                </FormItem>
                <FormItem label="所属域" {...formItemLayout}>
                    {getFieldDecorator('domain', {
                        initialValue: injectForm.domain,
                        rules: [{
                            required: true, message: '所属域不为空',
                        }],
                    })(<Select
                        showSearch
                        placeholder='请选择所属域'
                        optionFilterProp='children'
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        {
                            domainList.map((item) => {
                                return (<Option value={item.key} key={item.id}>{item.key}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="应用类型" {...formItemLayout}>
                    {getFieldDecorator('type', {
                        initialValue: injectForm.type === 'click' ? undefined : injectForm.type,
                        rules: [{
                            required: true, message: '应用类型不为空',
                        }],
                    })(<Select
                        showSearch
                        placeholder='请选择应用类型'
                        optionFilterProp='children'
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        {
                            typeList.map((item) => {
                                return (<Option value={item.key} key={item.id}>{item.key}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(AppForm);
