import React, { Component } from 'react';
import { Form, Input, Switch } from 'antd';

const FormItem = Form.Item;

class SiteForm extends Component {
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        return (
            <Form>
                <FormItem label="应用名" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true, message: '应用名不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="应用码" {...formItemLayout}>
                    {getFieldDecorator('code', {
                        initialValue: injectForm.code,
                        rules: [{
                            required: true, message: '应用码不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="描述" {...formItemLayout}>
                    {getFieldDecorator('description', {
                        initialValue: injectForm.description,
                    })(<Input />)}
                </FormItem>
                <FormItem label="是否启用" {...formItemLayout}>
                    {getFieldDecorator('isEnable', {
                        initialValue: injectForm.isEnable,
                        valuePropName: 'checked'
                    })(<Switch style={{ marginLeft: 10 }}/>)}
                </FormItem>

            </Form>
        );
    }
}

export default Form.create()(SiteForm);
