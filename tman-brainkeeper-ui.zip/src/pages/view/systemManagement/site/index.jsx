import React, { Component } from 'react';
import { systemManagementService } from 'service';
import { Row, Col, Table, Button, Input, message, Modal } from 'antd';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import SiteForm from './siteForm';

const { confirm } = Modal;
// 添加/修改应用
const SiteFormModal = withFormModal(SiteForm);
// 添加/修改应用的表单默认字段
const defaultSiteFormOptions = {
    id: '',
    name: '',
    description: '',
    code: '',
    isEnable: false
};

class Site extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            name: '',
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0,
                countSql: true
            },
            siteForm: deepCopy(defaultSiteFormOptions),
            siteVisible: false,
            siteConfirmLoading: false
        };
    }
    componentDidMount() {
        this.getData();
    }
    // 获取数据
    getData = async (e) => {
        e && e.preventDefault();
        const {
            pagination,
            name
        } = this.state;
        const params = {
            name,
            ...pagination
        };
        delete params.totalCount;
        this.setState({
            loading: true
        });
        const { entry, code } = await systemManagementService.getAppList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 添加、修改应用Modal
    setSite = (record) => {
        let siteFormObj = {};
        if (record) {
            siteFormObj = {
                id: record.id,
                name: record.name,
                description: record.description,
                code: record.code,
                isEnable: record.isEnable === 1
            };
        } else {
            siteFormObj = deepCopy(defaultSiteFormOptions);
        }
        this.setState({
            siteForm: siteFormObj,
            siteVisible: true
        });
    }
    // 保存
    setSiteSend = async () => {
        this.siteFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    siteConfirmLoading: true
                });
                let params = { ...this.siteFormRef.props.form.getFieldsValue() };
                params.isEnable = params.isEnable ? 1 : 0;
                if (this.state.siteForm.id) {
                    params = { ...params, ...{ id: this.state.siteForm.id } };
                }
                const res = await systemManagementService.setAppSend(params);
                if (res.code === '0') {
                    this.setState({
                        siteConfirmLoading: false,
                        siteVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.siteFormRef.props.form.resetFields();
                        this.getData();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        siteConfirmLoading: false
                    });
                }
            }
        });
    }
    // 删除
    deleteApp = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该站点？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await systemManagementService.deleteApp({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getData();
                    }
                })();
            }
        });
    }
    // 改变Input
    changeInput = (type, e) => {
        this.setState({
            [type]: e.target.value.replace(/(^\s*)|(\s*$)/g, '')
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 更换状态
    changeAppEnable = async ({ id, isEnable }) => {
        const status = isEnable === 1 ? 0 : 1;
        const res = await systemManagementService.setAppSend({ id, isEnable: status });
        if (res.code === '0') {
            message.success('更改状态成功');
            this.getData();
        } else {
            message.error('更改状态失败');
        }
    }
    // 获取应用表单ref
    getSiteFormRef = (ref) => {
        this.siteFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.siteFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            siteForm,
            siteVisible,
            siteConfirmLoading
        } = this.state;
        const columns = [{
            title: '名称',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '应用码',
            dataIndex: 'code',
            key: 'code'
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description'
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (text, record) => {
                const layout = { marginRight: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.changeAppEnable.bind(this, record)}>{ record.isEnable === 1 ? '禁用' : '启用' }</Button>, 'PermissionSiteStatus')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setSite.bind(this, record)}>修改</Button>, 'PermissionSiteEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteApp.bind(this, record)}>删除</Button>, 'PermissionSiteDelete')
                        }
                    </div>
                );
            }
        }];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 30 }}>
                    <Col span={3}>
                        <Input onChange={this.changeInput.bind(this, 'name')} placeholder="请填写名称"/>
                    </Col>
                    <Col span={21}>
                        <Button icon="search" type="primary" onClick={this.getData} style={{ marginRight: 20 }}>查询</Button>
                        {
                            withPermission(<Button type="primary" onClick={this.setSite}>新增</Button>, 'PermissionSiteAdd')
                        }
                    </Col>
                </Row>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <SiteFormModal
                    maskClosable={false}
                    injectForm={siteForm}
                    getRef={this.getSiteFormRef}
                    title="应用添加/修改"
                    visible={siteVisible}
                    onOk={this.setSiteSend}
                    onCancel={this.handleCancel.bind(this, 'siteVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={siteConfirmLoading} onClick={this.setSiteSend}>
                            确定
                        </Button>
                    ]}
                />

            </div>
        );
    }
}

export default Site;
