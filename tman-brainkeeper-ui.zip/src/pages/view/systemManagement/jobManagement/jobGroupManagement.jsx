import React, { Component } from 'react';
import { Button, Table, message, Modal } from 'antd';
import { systemManagementService } from 'service';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import JobGroupForm from './jobGroupForm';

const JobGroupFormModal = withFormModal(JobGroupForm);

const { confirm } = Modal;

class JobGroupManagement extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            loading: false,
            jobGroupForm: {
                key: '',
                description: ''
            },
            visible: false,
            jobConfirmLoading: false,
            currentEditId: '',
        };
        this.columns = [{
            title: '名称',
            dataIndex: 'key',
            key: 'key'
        }, {
            title: '作业数量',
            dataIndex: 'jobCount',
            key: 'jobCount'
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description'
        }, {
            title: '创建信息',
            dataIndex: 'createInformation',
            key: 'createInformation',
            render: (text, record) => {
                return (
                    <div>
                        <span style={{ marginRight: '10px' }}> {record.createTime}</span>
                        <span>{record.createUser}</span>
                    </div>
                );
            }
        }, {
            title: '修改信息',
            dataIndex: 'modifyInformation',
            key: 'modifyInformation',
            render: (text, record) => {
                return (
                    <div>
                        <span style={{ marginRight: '10px' }}>{record.modifyTime}</span>
                        <span>{record.modifyUser}</span>
                    </div>
                );
            }
        }, {
            title: '操作',
            key: 'action',
            render: (text, record) => {
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" onClick={this.edit.bind(this, record)} style={{ marginRight: '10px' }}>编辑</Button>, 'PermissionGroupEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" onClick={this.remove.bind(this, record)}>删除</Button>, 'PermissionGroupDelete')
                        }
                    </div>
                );
            }
        }];
    }
    componentDidMount() {
        this.getGroupList();
    }
    // 新增
    add = () => {
        this.setState({
            visible: true,
            currentEditId: '',
            jobGroupForm: {
                key: '',
                description: ''
            }
        });
    }
    // 编辑
    edit = (record, status) => {
        this.setState({
            visible: true,
            currentEditId: record.id,
            jobGroupForm: {
                key: record.key,
                description: record.description
            }
        });
    }
    // 删除
    remove = (record) => {
        const content = <div style={{ marginTop: '20px' }}><p>删除{record.key}分组后将不可恢复，请确认操作</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await systemManagementService.deleteGroup({ id: record.id });
                    if (res.code === '0') {
                        that.getGroupList();
                        message.success('删除成功');
                    }
                })();
            }
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getGroupList();
            });
        }
    }
    // 获取分组
    getGroupList = async () => {
        const { pagination } = this.state;
        const params = { ...pagination };
        delete params.totalCount;
        this.setState({
            loading: true
        });
        const { entry, code } = await systemManagementService.getGroupPageList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                groupList: entry.list,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
            });
        }
    }
    getJobGroupFormRef = (ref) => {
        this.jobGroupFormRef = ref;
    }
    // 新增及编辑JobGroup
    handleOk = (e) => {
        e.preventDefault();
        this.jobGroupFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    jobConfirmLoading: true
                });
                let params;
                if (this.state.currentEditId) {
                    params = { ...values, id: this.state.currentEditId };
                } else {
                    params = { ...values };
                }
                const { code } = await systemManagementService.operateGroup(params);
                this.setState({
                    jobConfirmLoading: false
                });
                if (code === '0') {
                    message.success('保存成功');
                    this.getGroupList();
                    this.jobGroupFormRef.props.form.resetFields();
                    this.setState({
                        visible: false
                    });
                    this.props.onGroupListUpdate();
                }
            }
        });
    }
    // 关闭JobGroup弹窗
    handleCancel = () => {
        this.jobGroupFormRef.props.form.resetFields();
        this.setState({
            visible: false,
            currentEditId: ''
        });
    }
    render() {
        const {
            groupList,
            loading,
            pagination,
            jobGroupForm,
            visible,
            jobConfirmLoading
        } = this.state;
        const { columns } = this;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                {
                    withPermission(<Button type="primary" style={{ marginTop: '20px', marginBottom: '20px' }} onClick={this.add}>新增分组</Button>, 'PermissionGroupAdd')
                }
                <Table
                    columns={columns}
                    dataSource={groupList}
                    loading={loading}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <JobGroupFormModal
                    maskClosable={false}
                    width={500}
                    injectForm={jobGroupForm}
                    getRef={this.getJobGroupFormRef}
                    visible={visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    footer={[
                        <Button key="submit" type="primary" loading={jobConfirmLoading} onClick={this.handleOk}>
                            保存
                        </Button>
                    ]}
                />
            </div>
        );
    }
}

export default JobGroupManagement;
