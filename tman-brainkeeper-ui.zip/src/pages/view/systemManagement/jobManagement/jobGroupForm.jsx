import React, { Component } from 'react';
import { Input, Form } from 'antd';

const FormItem = Form.Item;
const { TextArea } = Input;

class JobGroupForm extends Component {
    render() {
        const {
            form,
            injectForm
        } = this.props;
        const { getFieldDecorator } = form;
        return (
            <div>
                <Form>
                    <FormItem label="分组名称">
                        {getFieldDecorator('key', {
                            initialValue: injectForm.key,
                        })(<Input placeholder="请输入分组名称" />)}
                    </FormItem>
                    <FormItem label="分组描述">
                        {getFieldDecorator('description', {
                            initialValue: injectForm.description,
                        })(<TextArea rows={4} placeholder="请输入分组描述" />)}
                    </FormItem>
                </Form>
            </div>
        );
    }
}

export default Form.create()(JobGroupForm);
