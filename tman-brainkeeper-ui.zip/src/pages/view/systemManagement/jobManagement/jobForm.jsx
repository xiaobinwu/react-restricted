import React, { Component } from 'react';
import Editor from 'component/jsonEditor';
import { Form, Row, Col, Select, Upload, Input, Button, Icon, Checkbox } from 'antd';
import { isNotEmptyObject } from 'js/util';
import { connect } from 'react-redux';
import styles from './jobForm.css';

const { Option } = Select;
const FormItem = Form.Item;


class JobForm extends Component {
    state = {
        jsonError: false,
        isLoaded: false,
        ajv: null
    }
    componentDidMount() {
        this.loadEditorSetting();
    }
    // 下载编辑器对应的ajv,ace配置
    loadEditorSetting = async () => {
        const ace = await import(/* webpackChunkName: 'ace' */ 'brace');
        const Ajv = await import(/* webpackChunkName: 'ajv' */ 'ajv');
        await import(/* webpackChunkName: 'brace-mode-json' */ 'brace/mode/json');
        await import(/* webpackChunkName: 'brace-theme-tomorrow' */ 'brace/theme/tomorrow');
        await import(/* webpackChunkName: 'brace-theme-tomorrow-night' */ 'brace/theme/tomorrow_night');
        const ajv = new Ajv({ allErrors: true, verbose: true });
        this.setState({
            ajv,
            ace,
            isLoaded: true
        });
    }
    // onChange 的参数（如 event）转化为控件的值
    normFile = (e) => {
        if (Array.isArray(e)) {
            return e;
        }
        return e && [e.file];
    }
    // 验证JSON格式
    handleConfirmJson = (rule, value, callback) => {
        if (!isNotEmptyObject(value) || value === null || this.state.jsonError) {
            callback('Job内容不能为空对象且格式要正确！');
            if (this.state.jsonError) {
                this.setState({
                    jsonError: false
                });
            }
        }
        callback();
    }
    // 捕捉错误
    handleError = (error) => {
        if (error) {
            this.setState({
                jsonError: true
            });
        }
    }
    render() {
        const {
            form,
            injectForm,
            operateStatus,
            groupList,
            getEditorRef,
            antd,
            ace,
            onLoad
        } = this.props;
        const {
            ajv,
            isLoaded
        } = this.state;
        const { getFieldDecorator, getFieldValue, setFieldsValue } = form;
        const uploadProps = {
            accept: '.jar',
            onRemove: (file) => {
                const jarfile = getFieldValue('jarfile');
                const index = jarfile.indexOf(file);
                const newAttachJar = jarfile.slice();
                newAttachJar.splice(index, 1);
                setFieldsValue({ jarfile: newAttachJar });
            },
            beforeUpload: (file) => {
                setFieldsValue({ jarfile: file });
                return false;
            },
            disabled: operateStatus === 2
        };
        return (
            <div>
                {
                    isLoaded ? <Form>
                        <Row gutter={16} style={{ marginTop: '20px', padding: '20px' }}>
                            <Col span={4}>
                                <FormItem label="分组" className={styles.formItem}>
                                    {getFieldDecorator('groupId', {
                                        initialValue: injectForm.groupId,
                                        rules: [{ required: true, message: '分组必选' }],
                                    })(<Select
                                        style={{ width: '180px' }}
                                        disabled={operateStatus === 2}
                                        showSearch
                                        placeholder='请选择分组'
                                        optionFilterProp='children'
                                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                    >
                                        {
                                            groupList.map((item) => {
                                                return (<Option value={item.id} key={item.id}>{item.key}</Option>);
                                            })
                                        }
                                    </Select>)}
                                </FormItem>
                            </Col>

                            <Col span={5}>
                                <FormItem label="描述" className={styles.formItem}>
                                    {getFieldDecorator('description', {
                                        initialValue: injectForm.description
                                    })(<Input placeholder="输入描述" style={{ width: '250px' }} disabled={operateStatus === 2}/>)}
                                </FormItem>
                            </Col>
                            {
                                injectForm.attachJar && operateStatus === 1 ?
                                    <Col span={3}>
                                        <FormItem className={styles.formItem}>
                                            {getFieldDecorator('attachJar', {
                                                valuePropName: 'checked'
                                            })(<Checkbox>是否清空jar文件</Checkbox>)}
                                        </FormItem>
                                    </Col>
                                    : null
                            }
                            <Col span={12}>
                                <FormItem label="Jar文件" className={styles.formItem} extra={injectForm.attachJar === 1 ? <div><Icon type="info-circle" style={{ marginRight: '10px', color: '#279327' }} /><span>已上传了jar文件！</span></div> : ''}>
                                    {getFieldDecorator('jarfile', {
                                        initialValue: injectForm.jarfile,
                                        valuePropName: 'fileList',
                                        getValueFromEvent: this.normFile,
                                    })(<Upload name="jar" {...uploadProps}>
                                        <Button type={antd === 'light' ? 'default' : 'primary'}>
                                            <Icon type="upload" /> 上传jar包
                                        </Button>
                                    </Upload>)}
                                </FormItem>
                            </Col>
                        </Row>
                        <FormItem className={styles.jsonInput}>
                            {getFieldDecorator('content', {
                                initialValue: injectForm.content,
                                rules: [
                                    {
                                        validator: this.handleConfirmJson
                                    }
                                ]
                            })(<Editor
                                mode="code"
                                ajv={ajv}
                                ace={ace}
                                themeType={antd}
                                onError={this.handleError}
                                onLoad={onLoad}
                                theme={
                                    antd === 'light'
                                        ? 'ace/theme/tomorrow'
                                        : 'ace/theme/tomorrow_night'
                                }
                                ref={getEditorRef}
                            />)}
                        </FormItem>
                    </Form> : null
                }
            </div>
        );
    }
}

const stateToProps = ({ themeState }) => ({
    antd: themeState.antd
});

export default connect(stateToProps)(Form.create()(JobForm));
