import React, { Component } from 'react';
import { Tabs } from 'antd';
import { systemManagementService } from 'service';
import withLazyComponent from 'component/hoc/withLazyComponent';

const jobManagementPromise = import(/* webpackChunkName: 'jobManagement' */ './jobManagement');
const jobGroupManagementPromise = import(/* webpackChunkName: 'jobGroupManagement' */ './jobGroupManagement');

const JobManagement = withLazyComponent(() => jobManagementPromise);
const JobGroupManagement = withLazyComponent(() => jobGroupManagementPromise);


const { TabPane } = Tabs;


class JobManageTab extends Component {
    state = {
        groupList: []
    }
    componentDidMount() {
        this.getGroupList();
    }
    // 获取分组
    getGroupList = async () => {
        const { code, entry } = await systemManagementService.getGroupList();
        if (code === '0') {
            this.setState({
                groupList: entry
            });
        }
    }
    // 更新groupList
    onGroupListUpdate = async () => {
        this.getGroupList();
        this.jobManagement.getJobList();
    }
    render() {
        const { groupList } = this.state;
        return (
            <div>
                <Tabs defaultActiveKey="1">
                    <TabPane tab="作业管理" key="1">
                        <JobManagement groupList={groupList} wrappedComponentRef={(ref) => { this.jobManagement = ref; }}/>
                    </TabPane>
                    <TabPane tab="分组管理" key="2">
                        <JobGroupManagement onGroupListUpdate={this.onGroupListUpdate}/>
                    </TabPane>
                </Tabs>
            </div>
        );
    }
}

export default JobManageTab;
