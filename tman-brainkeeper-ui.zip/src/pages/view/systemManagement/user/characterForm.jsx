import React, { Component } from 'react';
import { Table } from 'antd';
import { is } from 'immutable';

class CharacterForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedRowKeys: this.props.selectedCharacterRowKeys.toJS()
        };
    }
    UNSAFE_componentWillReceiveProps(nextProps) { //eslint-disable-line
        if (!is(this.props.selectedCharacterRowKeys, nextProps.selectedCharacterRowKeys)) {
            this.setState({
                selectedRowKeys: nextProps.selectedCharacterRowKeys.toJS()
            });
        } else {
            this.setState({
                selectedRowKeys: this.props.selectedCharacterRowKeys.toJS()
            });
        }
    }
    onSelectChange = (selectedRowKeys) => {
        this.setState({ selectedRowKeys });
    }
    getSelectedRowKeys = () => {
        return this.state.selectedRowKeys;
    }
    clearSelectedRowKeys = () => {
        this.setState({
            selectedRowKeys: []
        });
    }
    render() {
        const { characterList } = this.props;
        const { selectedRowKeys } = this.state;
        const rowSelection = {
            selectedRowKeys,
            onChange: this.onSelectChange,
        };
        const columns = [{
            title: '角色',
            dataIndex: 'name',
            key: 'name',
            width: 200
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description'
        }];
        return (
            <div>
                <Table
                    rowKey="id"
                    columns={columns}
                    dataSource={characterList}
                    pagination={false}
                    rowSelection={rowSelection}
                    scroll={{ y: 240 }}
                />
            </div>
        );
    }
}

export default CharacterForm;
