import React, { Component } from 'react';
import { Form, Input } from 'antd';

const FormItem = Form.Item;

class UserForm extends Component {
    render() {
        const {
            form,
            injectForm,
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        return (
            <Form>
                <FormItem label="账号" {...formItemLayout}>
                    {getFieldDecorator('account', {
                        initialValue: injectForm.account,
                        rules: [{
                            required: true, message: '账号不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="用户名" {...formItemLayout}>
                    {getFieldDecorator('userName', {
                        initialValue: injectForm.userName,
                        rules: [{
                            required: true, message: '用户名不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                {
                    !injectForm.password ? <FormItem label="密码" {...formItemLayout}>
                        {getFieldDecorator('password', {
                            initialValue: injectForm.password,
                            rules: [{
                                required: true, message: '密码不为空'
                            }, {
                                min: 6, message: '密码最少6位'
                            }],
                        })(<Input />)}
                    </FormItem> : null
                }
            </Form>
        );
    }
}

export default Form.create()(UserForm);
