import React, { Component } from 'react';
import { systemManagementService } from 'service';
import { Row, Col, Table, Button, Input, message, Modal, Select } from 'antd';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { fromJS } from 'immutable';
import { deepCopy } from 'js/util';
import { connect } from 'react-redux';
import UserForm from './userForm';
import CharacterForm from './characterForm';

const { confirm } = Modal;
const { Option } = Select;
// 添加/修改用户
const UserFormModal = withFormModal(UserForm);
// 绑定角色
const CharacterFormModal = withFormModal(CharacterForm);
// 添加/修改应用的表单默认字段
const defaultUserFormOptions = {
    id: '',
    account: '',
    userName: '',
    password: ''
};

class User extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            account: '',
            userName: '',
            roleId: '',
            isEnable: '',
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0,
                countSql: true
            },
            userForm: deepCopy(defaultUserFormOptions),
            userVisible: false,
            userConfirmLoading: false,
            resetPassword: '',
            characterList: [],
            characterVisible: false,
            characterConfirmLoading: false,
            selectedCharacterRowKeys: [],
            currentUserId: '',
        };
    }
    componentDidMount() {
        this.getAllCharacterList();
        this.getData();
    }
    // 获取角色列表
    getAllCharacterList = async () => {
        const { entry, code } = await systemManagementService.getAllCharacterList();
        if (code === '0') {
            this.setState({
                characterList: entry
            });
        }
    }
    // 获取数据
    getData = async (e) => {
        e && e.preventDefault();
        const {
            pagination,
            account,
            userName,
            roleId,
            isEnable
        } = this.state;
        const params = {
            roleId,
            isEnable,
            account,
            userName,
            ...pagination
        };
        delete params.totalCount;
        this.setState({
            loading: true
        });
        const { entry, code } = await systemManagementService.getUserList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 改变Input
    changeInput = (type, e) => {
        this.setState({
            [type]: e.target.value.replace(/(^\s*)|(\s*$)/g, '')
        });
    }
    // 改变Select
    changeSelect = (type, value) => {
        this.setState({
            [type]: value
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 添加、修改用户Modal
    setUser = (record) => {
        let userFormObj = {};
        if (record) {
            userFormObj = {
                id: record.id,
                account: record.account,
                userName: record.userName,
                password: record.password
            };
        } else {
            userFormObj = deepCopy(defaultUserFormOptions);
        }
        this.setState({
            userForm: userFormObj,
            userVisible: true
        });
    }
    // 保存
    setUserSend = async () => {
        this.userFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    userConfirmLoading: true
                });
                let params = { ...this.userFormRef.props.form.getFieldsValue() };
                if (this.state.userForm.id) {
                    params = { ...params, ...{ id: this.state.userForm.id } };
                }
                const res = await systemManagementService.setUserSend(params);
                if (res.code === '0') {
                    this.setState({
                        userConfirmLoading: false,
                        userVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.userFormRef.props.form.resetFields();
                        this.getData();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        userConfirmLoading: false
                    });
                }
            }
        });
    }
    // 添加角色Modal
    setCharacter = async ({ id }) => {
        const { code, entry } = await systemManagementService.getBindCharacterById({ userId: id });
        const { characterList } = this.state;
        const selectedCharacterRowKeys = [];
        if (code === '0') {
            entry.forEach((item, index) => {
                const resultItem = characterList.find((aItem) => {
                    return aItem.id === item;
                });
                resultItem && selectedCharacterRowKeys.push(resultItem.id);
            });
            this.setState({
                selectedCharacterRowKeys,
                characterVisible: true,
                currentUserId: id
            });
        }
    }
    // 保存角色绑定
    setCharacterSend = async () => {
        this.setState({
            characterConfirmLoading: true
        });
        const { currentUserId } = this.state;
        const params = { userId: currentUserId, roleIdList: this.characterFormRef.getSelectedRowKeys() };
        const res = await systemManagementService.bindRole(params);
        if (res.code === '0') {
            this.characterFormRef.clearSelectedRowKeys();
            this.setState({
                characterConfirmLoading: false,
                characterVisible: false,
                selectedCharacterRowKeys: []
            }, () => {
                message.success('绑定角色成功');
            });
        } else {
            this.setState({
                characterConfirmLoading: false
            });
        }
    }
    // 删除
    deleteUser = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该用户？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await systemManagementService.deleteUser({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getData();
                    }
                })();
            }
        });
    }
    // 更换状态
    changeUserEnable = async ({ id, isEnable }) => {
        const status = isEnable === 1 ? 0 : 1;
        const res = await systemManagementService.setUserSend({ id, isEnable: status });
        if (res.code === '0') {
            message.success('更改状态成功');
            this.getData();
        } else {
            message.error('更改状态失败');
        }
    }
    // 获取用户表单ref
    getUserFormRef = (ref) => {
        this.userFormRef = ref;
    }
    // 获取角色绑定表单ref
    getCharacterFormRef = (ref) => {
        this.characterFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.userFormRef && this.userFormRef.props.form.resetFields();
        this.characterFormRef && this.characterFormRef.clearSelectedRowKeys();
        this.setState({
            [type]: false
        });
    }
    // 重置密码
    resetPassword = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否重置密码？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const { code, entry } = await systemManagementService.resetPassword({ id });
                    if (code === '0') {
                        that.setState({
                            resetPassword: entry,
                            resetPasswordVisible: true
                        });
                    } else {
                        message.error('重置密码失败');
                    }
                })();
            }
        });
    }
    handleResetPasswordModal = () => {
        this.setState({
            resetPasswordVisible: false
        });
    }
    render() {
        const {
            pagination,
            loading,
            data,
            userForm,
            userVisible,
            userConfirmLoading,
            resetPassword,
            resetPasswordVisible,
            characterList,
            characterVisible,
            characterConfirmLoading,
            selectedCharacterRowKeys
        } = this.state;
        const { account } = this.props;
        const columns = [{
            title: '账号',
            dataIndex: 'account',
            key: 'account'
        }, {
            title: '用户名',
            dataIndex: 'userName',
            key: 'userName'
        }, {
            title: '角色',
            dataIndex: 'roleNameList',
            key: 'roleNameList',
            render: (text, record) => {
                return text ? text.join(',') : '';
            }
        }, {
            title: '最后登录IP',
            dataIndex: 'lastLoginIp',
            key: 'lastLoginIp'
        }, {
            title: '最后登录时间',
            dataIndex: 'lastLoginTime',
            key: 'lastLoginTime'
        }, {
            title: '登录次数',
            dataIndex: 'loginCount',
            key: 'loginCount'
        }, {
            title: '邮箱',
            dataIndex: 'email',
            key: 'email'
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (text, record) => {
                const layout = { marginRight: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.changeUserEnable.bind(this, record)}>{ record.isEnable === 1 ? '禁用' : '启用' }</Button>, 'PermissionUserStatus')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.resetPassword.bind(this, record)}>重置密码</Button>, 'PermissionUserResetPassword')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setUser.bind(this, record)}>修基本信息</Button>, 'PermissionUserBaseInfo')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setCharacter.bind(this, record)}>绑定角色</Button>, 'PermissionUserBindCharacter')
                        }
                        {
                            (record.account === 'admin' || record.account === account) ? null : withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteUser.bind(this, record)}>删除</Button>, 'PermissionUserDelete')
                        }
                    </div>
                );
            }
        }];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 30 }}>
                    <Col span={3}>
                        <Input onChange={this.changeInput.bind(this, 'account')} placeholder="请填写账号"/>
                    </Col>
                    <Col span={3}>
                        <Input onChange={this.changeInput.bind(this, 'userName')} placeholder="请填写用户名"/>
                    </Col>
                    <Col span={3}>
                        <Select placeholder="请选择角色" style={{ width: '100%' }} onChange={this.changeSelect.bind(this, 'roleId')}>
                            <Option value="">全部</Option>
                            {
                                characterList.map((item, index) => {
                                    return (<Option value={item.id} key={item.id}>{item.name}</Option>);
                                })
                            }
                        </Select>
                    </Col>
                    <Col span={3}>
                        <Select placeholder="请选择状态" style={{ width: '100%' }} onChange={this.changeSelect.bind(this, 'isEnable')}>
                            <Option value="">全部</Option>
                            <Option value="1">启用</Option>
                            <Option value="0">禁用</Option>
                        </Select>
                    </Col>
                    <Col span={12}>
                        <Button icon="search" type="primary" onClick={this.getData} style={{ marginRight: 20 }}>查询</Button>
                        {
                            withPermission(<Button type="primary" onClick={this.setUser}>新增</Button>, 'PermissionUserAdd')
                        }
                    </Col>
                </Row>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <UserFormModal
                    maskClosable={false}
                    injectForm={userForm}
                    getRef={this.getUserFormRef}
                    title="应用添加/修改"
                    visible={userVisible}
                    onOk={this.setUserSend}
                    onCancel={this.handleCancel.bind(this, 'userVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={userConfirmLoading} onClick={this.setUserSend}>
                            确定
                        </Button>
                    ]}
                />
                <CharacterFormModal
                    maskClosable={false}
                    getRef={this.getCharacterFormRef}
                    title="绑定角色"
                    visible={characterVisible}
                    onOk={this.setCharacterSend}
                    onCancel={this.handleCancel.bind(this, 'characterVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={characterConfirmLoading} onClick={this.setCharacterSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        characterList,
                        selectedCharacterRowKeys: fromJS(selectedCharacterRowKeys)
                    }}
                />
                <Modal
                    maskClosable={false}
                    title="获得重置后的密码"
                    visible={resetPasswordVisible}
                    onOk={this.handleResetPasswordModal}
                    onCancel={this.handleResetPasswordModal}
                    footer={[
                        <Button key="submit" type="primary" onClick={this.handleResetPasswordModal}>
                            确定
                        </Button>
                    ]}
                >
                    {resetPassword}
                </Modal>
            </div>
        );
    }
}

const stateToProps = ({ userState }) => ({
    account: userState.account
});

export default connect(stateToProps)(User);
