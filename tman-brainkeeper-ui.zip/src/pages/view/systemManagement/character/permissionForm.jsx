import React, { Component } from 'react';
import { Tree } from 'antd';
import { is } from 'immutable';

const { TreeNode } = Tree;

class PermissionForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            checkedKeys: this.props.checkedKeys.toJS()
        };
    }
    UNSAFE_componentWillReceiveProps(nextProps) { // eslint-disable-line
        if (!is(this.props.checkedKeys, nextProps.checkedKeys)) {
            this.setState({
                checkedKeys: nextProps.checkedKeys.toJS()
            });
        }
    }
    onCheck = (checkedKeys) => {
        this.setState({ checkedKeys });
    }
    getCheckedKeys = () => {
        return this.state.checkedKeys;
    }
    clearCheckedKeys = () => {
        this.setState({
            checkedKeys: []
        });
    }
    setCheckedKeys = (checkedKeys) => {
        this.setState({
            checkedKeys
        });
    }
    renderTreeNodes = (data) => {
        return data.map((item) => {
            if (item.children) {
                return (
                    <TreeNode title={item.name} key={`${item.id}-${item.allPermissionIdStr}`} dataRef={item}>
                        {this.renderTreeNodes(item.children)}
                    </TreeNode>
                );
            }
            return <TreeNode title={item.name} key={`${item.id}-${item.allPermissionIdStr}`} />;
        });
    }
    render() {
        const { permissionList } = this.props;
        const {
            checkedKeys,
        } = this.state;
        return (
            <div style={{ resize: 'vertical', maxHeight: '450px', overflow: 'auto' }}>
                { permissionList ? <Tree
                    checkable
                    defaultExpandAll
                    onCheck={this.onCheck}
                    checkedKeys={checkedKeys}
                >
                    {this.renderTreeNodes([permissionList])}
                </Tree> : null }
            </div>
        );
    }
}

export default PermissionForm;
