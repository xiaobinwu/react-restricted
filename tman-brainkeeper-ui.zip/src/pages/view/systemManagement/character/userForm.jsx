import React, { Component } from 'react';
import { Table } from 'antd';
import { is } from 'immutable';

class UserForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedRowKeys: this.props.selectedUserRowKeys.toJS()
        };
    }
    UNSAFE_componentWillReceiveProps(nextProps) { //eslint-disable-line
        if (!is(this.props.selectedUserRowKeys, nextProps.selectedUserRowKeys)) {
            this.setState({
                selectedRowKeys: nextProps.selectedUserRowKeys.toJS()
            });
        } else {
            this.setState({
                selectedRowKeys: this.props.selectedUserRowKeys.toJS()
            });
        }
    }
    onSelectChange = (selectedRowKeys) => {
        this.setState({ selectedRowKeys });
    }
    getSelectedRowKeys = () => {
        return this.state.selectedRowKeys;
    }
    clearSelectedRowKeys = () => {
        this.setState({
            selectedRowKeys: []
        });
    }
    render() {
        const { userList } = this.props;
        const { selectedRowKeys } = this.state;
        const rowSelection = {
            selectedRowKeys,
            onChange: this.onSelectChange,
        };
        const columns = [{
            title: '账号',
            dataIndex: 'account',
            key: 'account'
        }, {
            title: '用户名',
            dataIndex: 'name',
            key: 'name',
            width: 200
        }];
        return (
            <div>
                <Table
                    rowKey="id"
                    columns={columns}
                    dataSource={userList}
                    pagination={false}
                    rowSelection={rowSelection}
                    scroll={{ y: 240 }}
                />
            </div>
        );
    }
}

export default UserForm;
