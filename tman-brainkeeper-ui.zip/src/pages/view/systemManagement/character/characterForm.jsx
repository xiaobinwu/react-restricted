import React, { Component } from 'react';
import { Form, Input, Select } from 'antd';

const { Option } = Select;
const FormItem = Form.Item;

class CharacterForm extends Component {
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    render() {
        const {
            form,
            injectForm,
            appList
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        return (
            <Form>
                <FormItem label="名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true, message: '名称不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="描述" {...formItemLayout}>
                    {getFieldDecorator('description', {
                        initialValue: injectForm.description,
                    })(<Input />)}
                </FormItem>
                <FormItem label="应用" {...formItemLayout}>
                    {getFieldDecorator('appId', {
                        initialValue: injectForm.appId,
                    })(<Select showSearch optionFilterProp="children" filterOption={this.filterOption} placeholder="请选择应用">
                        {
                            appList && appList.map((item, index) => {
                                return (<Option value={item.id} key={item.id}>{item.name}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(CharacterForm);
