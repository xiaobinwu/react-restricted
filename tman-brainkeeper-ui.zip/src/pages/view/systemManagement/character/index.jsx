import React, { Component } from 'react';
import { systemManagementService } from 'service';
import { Row, Col, Table, Button, Input, message, Modal, Select } from 'antd';
import { fromJS } from 'immutable';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import CharacterForm from './characterForm';
import UserForm from './userForm';
import PermissionForm from './permissionForm';

const { confirm } = Modal;
const { Option } = Select;
// 添加/修改角色
const CharacterFormModal = withFormModal(CharacterForm);
// 添加用户
const UserFormModal = withFormModal(UserForm);
// 绑定权限
const PermissionFormModal = withFormModal(PermissionForm);

// 添加/修改角色的表单默认字段
const defaultCharacterFormOptions = {
    id: '',
    name: '',
    description: '',
    appId: ''
};

class Character extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            data: [],
            appList: [],
            userList: [],
            permissionList: null,
            name: '',
            appId: '',
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0,
                countSql: true
            },
            characterForm: deepCopy(defaultCharacterFormOptions),
            characterVisible: false,
            characterConfirmLoading: false,
            selectedUserRowKeys: [],
            currentUserId: '',
            userVisible: false,
            userConfirmLoading: false,
            permissionVisible: false,
            permissionConfirmLoading: false,
            currentPermissionId: '',
            checkedKeys: []
        };
    }
    componentDidMount() {
        this.getAllApp();
        this.getAllUser();
        this.getData();
    }
    // 获取所有用户
    getAllUser = async () => {
        const { entry, code } = await systemManagementService.getAllUser();
        if (code === '0') {
            this.setState({
                userList: entry
            });
        }
    }
    // 获取所有应用
    getAllApp = async () => {
        const { entry, code } = await systemManagementService.getAllApp();
        if (code === '0') {
            this.setState({
                appList: entry
            });
        }
    }
    // 获取数据
    getData = async (e) => {
        e && e.preventDefault();
        const {
            pagination,
            name,
            appId
        } = this.state;
        const params = {
            name,
            appId,
            ...pagination
        };
        delete params.totalCount;
        this.setState({
            loading: true
        });
        const { entry, code } = await systemManagementService.getCharacterList(params);
        if (code === '0') {
            this.setState({
                loading: false,
                pagination: { ...pagination, ...{ totalCount: entry.total } },
                data: entry.list
            });
        }
    }
    // 改变Input
    changeInput = (type, e) => {
        this.setState({
            [type]: e.target.value.replace(/(^\s*)|(\s*$)/g, '')
        });
    }
    // 改变Select
    changeSelect = (value) => {
        this.setState({
            appId: value
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getData();
            });
        }
    }
    // 添加、修改角色Modal
    setCharacter = (record) => {
        let characterFormObj = {};
        if (record) {
            characterFormObj = {
                id: record.id,
                name: record.name,
                description: record.description,
                appId: record.appId
            };
        } else {
            characterFormObj = deepCopy(defaultCharacterFormOptions);
        }
        this.setState({
            characterForm: characterFormObj,
            characterVisible: true
        });
    }
    // 保存
    setCharacterSend = async () => {
        this.characterFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    characterConfirmLoading: true
                });
                let params = { ...this.characterFormRef.props.form.getFieldsValue() };
                if (this.state.characterForm.id) {
                    params = { ...params, ...{ id: this.state.characterForm.id } };
                }
                const res = await systemManagementService.setCharacterSend(params);
                if (res.code === '0') {
                    this.setState({
                        characterConfirmLoading: false,
                        characterVisible: false
                    }, () => {
                        message.success('保存成功');
                        this.characterFormRef.props.form.resetFields();
                        this.getData();
                    });
                } else {
                    message.error('保存失败');
                    this.setState({
                        characterConfirmLoading: false
                    });
                }
            }
        });
    }
    // 删除
    deleteCharacter = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该角色？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await systemManagementService.deleteCharacter({ id });
                    if (res.code === '0') {
                        message.success('删除成功');
                        that.getData();
                    }
                })();
            }
        });
    }
    // 改变状态
    changeCharacterEnable = async ({ id, isEnable }) => {
        const status = isEnable === 1 ? 0 : 1;
        const res = await systemManagementService.setCharacterSend({ id, isEnable: status });
        if (res.code === '0') {
            message.success('更改状态成功');
            this.getData();
        } else {
            message.error('更改状态失败');
        }
    }
    // 获取角色表单ref
    getCharacterFormRef = (ref) => {
        this.characterFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.characterFormRef && this.characterFormRef.props.form.resetFields();
        this.permissionFormRef && this.permissionFormRef.clearCheckedKeys();
        this.userFormRef && this.userFormRef.clearSelectedRowKeys();
        this.setState({
            [type]: false
        });
    }
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    // 添加用户Modal
    setUser = async ({ id }) => {
        const { code, entry } = await systemManagementService.getBindUserById({ roleId: id });
        const { userList } = this.state;
        const selectedUserRowKeys = [];
        if (code === '0') {
            entry.forEach((item, index) => {
                const resultItem = userList.find((aItem) => {
                    return aItem.id === item.id;
                });
                resultItem && selectedUserRowKeys.push(resultItem.id);
            });
            this.setState({
                selectedUserRowKeys,
                userVisible: true,
                currentUserId: id
            });
        }
    }
    // 添加用户-保存
    setUserSend = async () => {
        this.setState({
            userConfirmLoading: true
        });
        const { currentUserId } = this.state;
        const params = { roleId: currentUserId, userIdList: this.userFormRef.getSelectedRowKeys() };
        const res = await systemManagementService.setBindUser(params);
        if (res.code === '0') {
            this.userFormRef.clearSelectedRowKeys();
            this.setState({
                userConfirmLoading: false,
                userVisible: false,
                selectedUserRowKeys: []
            }, () => {
                message.success('绑定用户成功');
            });
        } else {
            this.setState({
                userConfirmLoading: false
            });
        }
    }
    // 绑定权限Modal
    setPermission = async ({ id }) => {
        const { code, entry } = await systemManagementService.getPermissionResourceTree({ roleId: id });
        if (code === '0') {
            const checkedKeys = [];
            const walkPermission = (resourceTree) => {
                // 补充根节点Root
                !resourceTree.name && (resourceTree.name = 'Root');
                !resourceTree.allPermissionIdStr && (resourceTree.allPermissionIdStr = '0');
                if (resourceTree.isPermission && !resourceTree.children) {
                    checkedKeys.push(`${resourceTree.id}-${resourceTree.allPermissionIdStr}`);
                }
                if (resourceTree.children && resourceTree.children.length > 0) {
                    resourceTree.children.forEach((item) => {
                        walkPermission(item);
                    });
                }
            };
            walkPermission(entry);
            this.permissionFormRef && this.permissionFormRef.setCheckedKeys(checkedKeys);
            this.setState({
                permissionList: entry,
                permissionVisible: true,
                currentPermissionId: id,
                checkedKeys
            });
        }
    }
    // 绑定权限-保存
    setPermissionSend = async () => {
        this.setState({
            permissionConfirmLoading: true
        });
        const { currentPermissionId } = this.state;
        const checkedKeys = [];
        this.permissionFormRef.getCheckedKeys().forEach((item) => {
            const itemArr = item.split('-');
            checkedKeys.push(itemArr[1]);
        });
        const params = { roleId: currentPermissionId, allPermissionIdStrList: checkedKeys };
        const res = await systemManagementService.savePermissionResourceTree(params);
        if (res.code === '0') {
            this.permissionFormRef.clearCheckedKeys();
            this.setState({
                permissionConfirmLoading: false,
                permissionVisible: false,
                checkedKeys: []
            }, () => {
                message.success('绑定权限成功');
            });
        } else {
            this.setState({
                permissionConfirmLoading: false
            });
        }
    }
    getUserFormRef = (ref) => {
        this.userFormRef = ref;
    }
    getPermissionFormRef = (ref) => {
        this.permissionFormRef = ref;
    }
    render() {
        const {
            pagination,
            loading,
            data,
            characterForm,
            characterVisible,
            characterConfirmLoading,
            appList,
            userList,
            userVisible,
            userConfirmLoading,
            selectedUserRowKeys,
            permissionList,
            permissionVisible,
            permissionConfirmLoading,
            checkedKeys
        } = this.state;
        const columns = [{
            title: '名称',
            dataIndex: 'name',
            key: 'name'
        }, {
            title: '应用',
            dataIndex: 'appId',
            key: 'appId',
            render: (text, record) => {
                const findItem = appList.find((item, index) => item.id === Number(text));
                return findItem ? findItem.name : text;
            }
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description'
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (text, record) => {
                const layout = { marginRight: '10px' };
                return (
                    <div>
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.changeCharacterEnable.bind(this, record)}>{ record.isEnable === 1 ? '禁用' : '启用' }</Button>, 'PermissionCharacterStatus')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setCharacter.bind(this, record)}>修改</Button>, 'PermissionCharacterEdit')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.deleteCharacter.bind(this, record)}>删除</Button>, 'PermissionCharacterDelete')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setUser.bind(this, record)}>绑定用户</Button>, 'PermissionCharacterBindUser')
                        }
                        {
                            withPermission(<Button type="primary" size="small" style={layout} onClick={this.setPermission.bind(this, record)}>绑定权限</Button>, 'PermissionCharacterBindPermission')
                        }
                    </div>
                );
            }
        }];
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            showSizeChanger: true,
            total: pagination.totalCount
        };
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 30 }}>
                    <Col span={3}>
                        <Input onChange={this.changeInput.bind(this, 'name')} placeholder="请填写名称"/>
                    </Col>
                    <Col span={3}>
                        <Select onChange={this.changeSelect} showSearch optionFilterProp="children" filterOption={this.filterOption} style={{ width: '100%' }} placeholder="请选择应用">
                            <Option value="">全部</Option>
                            {
                                appList.map((item, index) => {
                                    return (<Option value={item.id} key={item.id}>{item.name}</Option>);
                                })
                            }
                        </Select>
                    </Col>
                    <Col span={18}>
                        <Button icon="search" type="primary" onClick={this.getData} style={{ marginRight: 20 }}>查询</Button>
                        {
                            withPermission(<Button type="primary" onClick={this.setCharacter}>新增</Button>, 'PermissionCharacterAdd')
                        }
                    </Col>
                </Row>
                <Table
                    rowKey="id"
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                />
                <CharacterFormModal
                    maskClosable={false}
                    injectForm={characterForm}
                    getRef={this.getCharacterFormRef}
                    title="角色添加/修改"
                    visible={characterVisible}
                    onOk={this.setCharacterSend}
                    onCancel={this.handleCancel.bind(this, 'characterVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={characterConfirmLoading} onClick={this.setCharacterSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp={{
                        appList
                    }}
                />
                <UserFormModal
                    maskClosable={false}
                    getRef={this.getUserFormRef}
                    title="绑定用户"
                    visible={userVisible}
                    onOk={this.setUserSend}
                    onCancel={this.handleCancel.bind(this, 'userVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={userConfirmLoading} onClick={this.setUserSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        userList,
                        selectedUserRowKeys: fromJS(selectedUserRowKeys)
                    }}
                />
                <PermissionFormModal
                    maskClosable={false}
                    getRef={this.getPermissionFormRef}
                    title="绑定权限"
                    visible={permissionVisible}
                    onOk={this.setPermissionSend}
                    onCancel={this.handleCancel.bind(this, 'permissionVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={permissionConfirmLoading} onClick={this.setPermissionSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        permissionList,
                        checkedKeys: fromJS(checkedKeys)
                    }}
                />

            </div>
        );
    }
}

export default Character;
