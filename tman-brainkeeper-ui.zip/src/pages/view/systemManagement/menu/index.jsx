import React, { Component } from 'react';
import { systemManagementService } from 'service';
import { Button, Select, Tree, Spin, Modal, message, Icon } from 'antd';
import ContextMenu from 'component/contextMenu';
import withFormModal from 'component/hoc/withFormModal';
import withPermission from 'component/hoc/withPermission';
import { deepCopy } from 'js/util';
import MenuForm from './menuForm';
import styles from './index.css';

const { Option } = Select;
const { TreeNode } = Tree;
const { confirm } = Modal;

const MenuFormModal = withFormModal(MenuForm);

// 添加/修改菜单的表单默认字段
const defaultMenuFormOptions = {
    id: '',
    parentId: 0,
    appId: 0,
    name: '',
    url: '',
    icon: '',
    type: '',
    sort: '',
    dependencyApi: ''
};
class Menu extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menuList: {},
            appList: [],
            appId: 1,
            loading: false,
            treeResource: null,
            checkedKeys: [],
            menuForm: deepCopy(defaultMenuFormOptions),
            menuVisible: false,
            menuConfirmLoading: false
        };
    }
    componentDidMount() {
        this.getAllApp();
        this.getResourceTree();
    }
    onCheck = (checkedKeys) => {
        this.setState({ checkedKeys });
    }
    // 获取所有应用
    getAllApp = async () => {
        const { entry, code } = await systemManagementService.getAllApp();
        if (code === '0') {
            this.setState({
                appList: entry
            });
        }
    }
    // 转化成平级菜单
    getSameLevelMenu = (menus) => {
        const menuList = {};
        const walkMenu = (menu) => {
            menuList[menu.id] = { id: menu.id, parentId: menu.parentId, type: menu.type || 0 };
            if (menu.children && menu.children.length > 0) {
                menu.children.forEach((item, index) => {
                    walkMenu(item);
                });
            }
        };
        walkMenu(menus);
        this.setState({
            menuList
        });
    }
    // 获取菜单树
    getResourceTree = async (e) => {
        e && e.preventDefault();
        const { appId } = this.state;
        this.setState({
            loading: true
        });
        const { entry, code } = await systemManagementService.getResourceTree({ appId });
        this.getSameLevelMenu(entry);
        if (code === '0') {
            entry.name = 'Root';
            entry.type = 0;
            this.setState({
                loading: false,
                treeResource: entry
            });
        }
    }
    // select搜索
    filterOption = (input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
    // 改变Select
    changeSelect = (value) => {
        this.setState({
            appId: value
        });
    }
    // 新增子菜单
    handleAddChildMenu = (e, record) => {
        const menuFormObj = { ...deepCopy(defaultMenuFormOptions), ...{ parentId: record.id, appId: record.appId } };
        this.setState({
            menuForm: menuFormObj,
            menuVisible: true
        });
    }
    // 修改菜单
    handleUpdateMenu = (e, record) => {
        const menuFormObj = {
            appId: record.appId,
            id: record.id,
            parentId: record.parentId,
            name: record.name,
            url: record.url,
            icon: record.icon,
            type: record.type,
            sort: record.sort,
            dependencyApi: record.dependencyApi
        };
        this.setState({
            menuForm: menuFormObj,
            menuVisible: true
        });
    }
    // 判断父节点中type===1的个数，系统只支持两级顶级菜单
    isMutilTopMenu = (id) => {
        const { menuList } = this.state;
        let parentMenuLength = 0;
        const getParentMenu = (mid) => {
            if (mid !== 0 && menuList[mid].type === 1) {
                parentMenuLength++; // eslint-disable-line
                getParentMenu(menuList[mid].parentId);
            }
        };
        getParentMenu(id);
        if (parentMenuLength >= 2) {
            return true;
        }
        return false;
    }
    // 保存
    setMenuSend = () => {
        this.menuFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    menuConfirmLoading: true
                });
                let params = { ...this.menuFormRef.props.form.getFieldsValue(), ...{ parentId: this.state.menuForm.parentId, appId: this.state.menuForm.appId } };
                // root节点下只能是type为1的节点
                if (params.parentId === 0 && (params.type === 2 || params.type === 3)) {
                    this.setState({
                        menuConfirmLoading: false
                    });
                    message.error('Root节点的直接子节点只能是顶部菜单');
                } else if (params.type === 1 && this.isMutilTopMenu(params.parentId)) {
                    this.setState({
                        menuConfirmLoading: false
                    });
                    message.error('不能连续存在3个及3个以上嵌套的顶部菜单');
                } else {
                    let res;
                    if (this.state.menuForm.id) {
                        params = { ...params, ...{ id: this.state.menuForm.id } };
                        res = await systemManagementService.updateResource(params);
                    } else {
                        res = await systemManagementService.saveResource(params);
                    }
                    if (res.code === '0') {
                        this.setState({
                            menuConfirmLoading: false,
                            menuVisible: false
                        }, () => {
                            message.success(res.message || '保存成功');
                            this.menuFormRef.props.form.resetFields();
                            this.getResourceTree();
                        });
                    } else {
                        this.setState({
                            menuConfirmLoading: false
                        });
                    }
                }
            }
        });
    }
    // 删除菜单
    handleDeleteMenu = (e, record) => {
        const content = <div style={{ marginTop: '20px' }}><p>{`确认是否删除[${record.name}]菜单？`}</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await systemManagementService.deleteResource({ resourceId: record.id });
                    if (res.code === '0') {
                        message.success(`删除[${record.name}]菜单成功`);
                        that.getResourceTree();
                    }
                })();
            }
        });
    }
    renderTreeNodes = (data) => {
        return data.map((item) => {
            let menuItem;
            // root节点
            if (item.id === 0) {
                menuItem = [
                    {
                        name: '新增子菜单',
                        prop: { ...item },
                        divider: false,
                        onClick: withPermission(true, 'PermissionMenuAdd') ? this.handleAddChildMenu : () => { message.error('没有新增子菜单的权限'); }
                    }
                ];
            } else {
                menuItem = [
                    {
                        name: '新增子菜单',
                        prop: { ...item },
                        divider: false,
                        onClick: withPermission(true, 'PermissionMenuAdd') ? this.handleAddChildMenu : () => { message.error('没有新增子菜单的权限'); }
                    },
                    {
                        name: '修改',
                        prop: { ...item },
                        divider: false,
                        onClick: withPermission(true, 'PermissionMenuEdit') ? this.handleUpdateMenu : () => { message.error('没有修改子菜单的权限'); }
                    },
                    {
                        name: '删除',
                        prop: { ...item },
                        divider: false,
                        onClick: withPermission(true, 'PermissionMenuDelete') ? this.handleDeleteMenu : () => { message.error('没有删除子菜单的权限'); }
                    }
                ];
            }
            const title = <ContextMenu
                id={`contextMenu${item.id}`}
                name={item.name}
                menuItem={menuItem}
            />;
            if (item.children) {
                return (
                    <TreeNode title={title} key={item.id} dataRef={item} icon={this.getIcon(item.type)}>
                        {this.renderTreeNodes(item.children)}
                    </TreeNode>
                );
            }
            return <TreeNode title={title} key={item.id} icon={this.getIcon(item.type)}/>;
        });
    }
    // 获取当前菜单的Icon
    getIcon = (type) => {
        switch (type) {
        case 1:
            return <Icon type="cluster" theme="outlined" className="system-menu-top"/>;
        case 2:
            return <Icon type="gold" theme="outlined" className="system-menu-left" />;
        case 3:
            return <Icon type="deployment-unit" theme="outlined" className="system-menu-app" />;
        case 4:
            return <Icon type="gateway" theme="outlined" className="system-menu-api" />;
        default: {
            return <Icon type="crown" theme="outlined" className="system-menu-root" />;
        }
        }
    }
    // 获取菜单表单ref
    getMenuFormRef = (ref) => {
        this.menuFormRef = ref;
    }
    // 关闭modal
    handleCancel = (type) => {
        this.menuFormRef && this.menuFormRef.props.form.resetFields();
        this.setState({
            [type]: false
        });
    }
    render() {
        const {
            appId,
            appList,
            loading,
            treeResource,
            checkedKeys,
            menuForm,
            menuVisible,
            menuConfirmLoading
        } = this.state;
        const layout = { marginRight: 20 };
        return (
            <div>
                <div style={{ marginBottom: 20 }} className="system-menu">
                    <Select onChange={this.changeSelect} showSearch optionFilterProp="children" value={appId} filterOption={this.filterOption} style={{ width: '200px', marginRight: '20px' }} placeholder="请选择应用">
                        {
                            appList.map((item, index) => {
                                return (<Option value={item.id} key={item.id}>{item.name}</Option>);
                            })
                        }
                    </Select>
                    <Button type="primary" onClick={this.getResourceTree} style={{ marginRight: 20 }}>查询</Button>
                    <span style={layout}>
                        <Icon type="crown" theme="outlined" className="system-menu-root" /> - Root
                    </span>
                    <span style={layout}>
                        <Icon type="cluster" theme="outlined" className="system-menu-top"/> - 顶部菜单
                    </span>
                    <span style={layout}>
                        <Icon type="gold" theme="outlined" className="system-menu-left" /> - 侧边菜单
                    </span>
                    <span style={layout}>
                        <Icon type="deployment-unit" theme="outlined" className="system-menu-app" /> - 页面级功能
                    </span>
                    <span>
                        <Icon type="gateway" theme="outlined" className="system-menu-api" /> - api权限
                    </span>
                </div>
                <Spin spinning={loading}>
                    { treeResource ? <Tree
                        className={styles.tree}
                        showLine
                        showIcon
                        defaultExpandAll
                        onCheck={this.onCheck}
                        checkedKeys={checkedKeys}
                    >
                        {this.renderTreeNodes([treeResource])}
                    </Tree> : null }
                </Spin>
                <MenuFormModal
                    maskClosable={false}
                    injectForm={menuForm}
                    getRef={this.getMenuFormRef}
                    title="菜单添加/修改"
                    visible={menuVisible}
                    onOk={this.setMenuSend}
                    onCancel={this.handleCancel.bind(this, 'menuVisible')}
                    footer={[
                        <Button key="submit" type="primary" loading={menuConfirmLoading} onClick={this.setMenuSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp={{
                        appList
                    }}
                />
            </div>
        );
    }
}

export default Menu;
