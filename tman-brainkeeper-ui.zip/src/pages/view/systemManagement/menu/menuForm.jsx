import React, { Component } from 'react';
import { Form, Input, Select, InputNumber } from 'antd';

const { Option } = Select;
const { TextArea } = Input;
const FormItem = Form.Item;

const types = [
    {
        type: 1,
        name: '顶部菜单'
    },
    {
        type: 2,
        name: '侧边栏菜单'
    },
    {
        type: 3,
        name: '功能性菜单'
    }
];

class MenuForm extends Component {
    render() {
        const {
            form,
            injectForm
        } = this.props;
        const { getFieldDecorator } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        return (
            <Form>
                <FormItem label="名称" {...formItemLayout}>
                    {getFieldDecorator('name', {
                        initialValue: injectForm.name,
                        rules: [{
                            required: true, message: '名称不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="url" {...formItemLayout}>
                    {getFieldDecorator('url', {
                        initialValue: injectForm.url,
                        rules: [{
                            required: true, message: 'url不为空',
                        }],
                    })(<Input />)}
                </FormItem>
                <FormItem label="图标" {...formItemLayout}>
                    {getFieldDecorator('icon', {
                        initialValue: injectForm.icon
                    })(<Input />)}
                </FormItem>
                <FormItem label="类型" {...formItemLayout}>
                    {getFieldDecorator('type', {
                        initialValue: injectForm.type,
                        rules: [{
                            required: true, message: '类型不为空',
                        }],
                    })(<Select placeholder="请选择类型">
                        {
                            types.map((item, index) => {
                                return (<Option value={item.type} key={item.type}>{item.name}</Option>);
                            })
                        }
                    </Select>)}
                </FormItem>
                <FormItem label="排序" {...formItemLayout}>
                    {getFieldDecorator('sort', {
                        initialValue: injectForm.sort
                    })(<InputNumber min={1} />)}
                </FormItem>
                <FormItem label="依赖API" {...formItemLayout}>
                    {getFieldDecorator('dependencyApi', {
                        initialValue: injectForm.dependencyApi,
                    })(<TextArea row={8} placeholder="多个Api以;分割开"/>)}
                </FormItem>
            </Form>
        );
    }
}

export default Form.create()(MenuForm);
