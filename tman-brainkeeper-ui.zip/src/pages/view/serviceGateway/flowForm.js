import React, { Component } from 'react';
import { Row, Col, Form, DatePicker, Radio, Button, Select } from 'antd';
import { gatewayService } from 'service';
import moment from 'moment';

const FormItem = Form.Item;
const { Option } = Select;

const times = [
    {
        text: '10秒',
        value: '10s'
    },
    {
        text: '1分钟',
        value: '1m'
    },
    {
        text: '15分钟',
        value: '15m'
    },
    {
        text: '30分钟',
        value: '30m'
    },
    {
        text: '近1小时',
        value: '3600'
    },
    {
        text: '1小时',
        value: '1h'
    }
];

class FlowForm extends Component {
    state = {
        serverList: [],
        serverId: ''
    }
    componentDidMount() {
        const { showServer } = this.props;
        if (showServer) {
            this.getServerList();
        }
    }
    // 获取服务列表
    getServerList = async () => {
        const { data } = await gatewayService.getServerList();
        if (data && data.length > 0) {
            const filterData = data.map((item, index) => {
                return {
                    ip: item.ip,
                    serverId: item.serverId
                };
            });
            this.setState({
                serverList: filterData,
                serverId: filterData[0].serverId || ''
            });
        }
    }
    // 设置不可选择日期
    disabledDate = (current) => {
        return current && (current.valueOf() < moment().subtract(7, 'days').valueOf() || current.valueOf() > moment().valueOf());
    }
    render() {
        const {
            form,
            onSubmit,
            showServer
        } = this.props;
        const {
            serverList
        } = this.state;
        const { getFieldDecorator } = form;
        return (
            <Form layout="inline">
                <Row>
                    <Col span={6}>
                        <FormItem>
                            {getFieldDecorator('date', {
                                initialValue: moment()
                            })(<DatePicker
                                size="small"
                                showTime
                                format="YYYY-MM-DD HH:mm:ss"
                                placeholder="请选择时间"
                                disabledDate={this.disabledDate}
                            />)}
                        </FormItem>
                    </Col>
                    <Col span={11}>
                        <FormItem>
                            {getFieldDecorator('ts', {
                                initialValue: '15m'
                            })(<Radio.Group size="small">
                                {
                                    times.map((item) => {
                                        return (<Radio.Button value={item.value} key={item.value}>{item.text}</Radio.Button>);
                                    })
                                }
                            </Radio.Group>)}
                        </FormItem>
                    </Col>
                    {
                        showServer ? <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('serverId', {})(<Select size="small" placeholder="请选择" style={{ width: '120px' }}>
                                    {
                                        serverList.map((item, index) => {
                                            return (<Option key={index} value={item.serverId}>{item.ip}-{item.serverId}</Option>);
                                        })
                                    }
                                </Select>)}
                            </FormItem>
                        </Col> : null
                    }

                    <Col span={2} style={{ paddingLeft: '10px' }}>
                        <FormItem>
                            <Button type="primary" size="small" icon="search" onClick={onSubmit} style={{ width: '100%' }}>查询</Button>
                        </FormItem>
                    </Col>
                </Row>
            </Form>
        );
    }
}

export default Form.create()(FlowForm);
