import React from 'react';
import { Button, Table, Modal, message, Input } from 'antd';
import { gatewayService } from 'service';
import withPermission from 'component/hoc/withPermission';
import styles from './index.css';

class Ipblacklist extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: false,
            visible: false,
            textAreaVal: ''
        };
    }
    // 请求列表数据
    async getBlackList() {
        this.setState({
            loading: true,
        });
        const res = await gatewayService.getBlackListService({});
        res.forEach((item, index) => {
            item.key = `${item.rule}-${index}`;
        });
        this.setState({
            data: res,
            loading: false
        });
    }
    // 新增
    addBlackList() {
        const ip = this.state.textAreaVal;
        Modal.confirm({
            title: '确认提示',
            content: `（加入黑名单客户端不能再进行连接）确认是否需要操作 ${ip}`,
            okText: '确定',
            cancelText: '取消',
            onOk: async () => {
                this.setState({
                    visible: false,
                    textAreaVal: '',
                });
                const res = await gatewayService.addBlackList({
                    clientIp: ip
                });
                if (res.code === 0) {
                    message.success(res.message);
                }
                this.getBlackList();
            }
        });
    }
    // 删除条目
    removeBlackList(ip) {
        Modal.confirm({
            title: '确认提示',
            content: `确认是否需要操作 ${ip}`,
            okText: '确认',
            cancelText: '取消',
            onOk: async () => {
                const res = await gatewayService.removeBlackList({
                    clientIp: ip
                });
                if (res.code === 0) {
                    message.success(res.message);
                }
                this.getBlackList();
            }
        });
    }
    // 双向绑定输入值
    changeTextAreaVal(e) {
        const val = e.target.value;
        this.setState({
            textAreaVal: val
        });
    }
    componentDidMount() {
        this.getBlackList.bind(this)();
    }
    render() {
        const { TextArea } = Input;
        const {
            data,
            loading,
        } = this.state;
        const columns = [{
            title: '#',
            key: 'index',
            width: 60,
            align: 'center',
            render(text, record, index) {
                return index;
            }
        }, {
            title: 'IP规则',
            dataIndex: 'rule',
            key: 'rule',
        }, {
            title: '操作',
            key: 'action',
            align: 'center',
            width: 200,
            render: (text, record) => withPermission(<Button type="primary" onClick={this.removeBlackList.bind(this, record.rule)}>移除</Button>, 'PermissionBlacklistRemove')
        }];

        return <div>
            {
                withPermission(<Button type="primary" icon="plus" size="small" onClick={() => {
                    this.setState({
                        visible: true,
                    });
                }} >增加黑名单</Button>, 'PermissionBlacklistAdd')
            }
            <div className={styles.tablewarp}>
                <Table columns={columns} dataSource={data} loading={loading} locale={ { emptyText: '暂无数据' } } />
            </div>
            <Modal
                visible={this.state.visible}
                onCancel={() => {
                    this.setState({
                        visible: false,
                    });
                }}
                footer={[
                    <Button type="primary" key="submit" onClick={this.addBlackList.bind(this, 123)}>保存到黑名单</Button>
                ]}
            >
                <p style={{
                    textAlign: 'center'
                }} className="system-backlist-modal-title">增加IP到黑名单</p>
                <p>多个地址用"分号"分隔，地址必需是0.0.0.0到255.255.255.255的IP地址</p>
                <TextArea
                    placeholder="请输入IP地址..."
                    value={this.state.textAreaVal}
                    onChange={this.changeTextAreaVal.bind(this)}
                />
            </Modal>
        </div>;
    }
}

export default Ipblacklist;
