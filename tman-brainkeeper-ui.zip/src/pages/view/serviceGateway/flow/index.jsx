import React, { Component } from 'react';
import { Card, Col, Row, Spin } from 'antd';
import { gatewayService } from 'service';
import FlowForm from '../flowForm';
import Traffic from './charts/traffic';
import Bar from './charts/bar';
import styles from './index.css';

class GetwayFlow extends Component {
    state = {
        trafficOptions: null,
        statisticsOptions: null,
        BarOptions: null,
        trafficLoading: false,
        statisticsLoading: false
    }
    componentDidMount() {
        this.queryTrafficToSum();
        this.queryTrafficToClassify();
    }
    queryTrafficToSum = async () => {
        this.setState({
            trafficLoading: true
        });
        const params = this.trafficAnalysisRef.props.form.getFieldsValue();
        params.date = params.date.toDate().toString();
        const data = await gatewayService.getTrafficToSum(params);
        const trafficXData = [];
        const trafficYData = [];
        const trafficY2Data = [];
        Array.isArray(data) && data.forEach((item) => {
            trafficXData.push(item.localTime);
            trafficYData.push(item.readKb ? item.readKb.toFixed(2) : 0);
            trafficY2Data.push(item.writeKb ? item.writeKb.toFixed(2) : 0);
        });
        const BarData = await gatewayService.getTrafficGroupByServerId(params);
        const barData = [];
        const barEnter = [];
        const barExit = [];
        Array.isArray(BarData) && BarData.forEach((item) => {
            barData.push(item.serverId);
            barEnter.push({ name: item.serverId, value: item.readKb ? item.readKb.toFixed(2) : 0 });
            barExit.push({ name: item.serverId, value: item.writeKb ? item.writeKb.toFixed(2) : 0 });
        });
        this.setState({
            trafficOptions: {
                xAxis: [
                    {
                        data: trafficXData
                    }
                ],
                series: [
                    {
                        data: trafficYData,
                        type: 'line',
                    },
                    {
                        data: trafficY2Data,
                        type: 'line'
                    }
                ]
            },
            BarOptions: {
                title: [{
                    text: '入站流量',
                    bottom: '10',
                    left: '120',
                }, {
                    text: '出站流量',
                    bottom: '10',
                    right: '85',
                }],
                series: [
                    {
                        name: '入站流量',
                        type: 'bar',
                        label: {
                            normal: {
                                show: true,
                                position: 'top',
                                textBorderColor: '#333',
                                textBorderWidth: 2
                            }
                        },
                        data: barEnter,
                    },
                    {
                        name: '出站流量',
                        type: 'bar',
                        data: barExit,
                        label: {
                            normal: {
                                show: true,
                                position: 'top',
                                textBorderColor: '#333',
                                textBorderWidth: 2
                            }
                        },
                    }
                ]
            },
            trafficLoading: false
        });
    }
    queryTrafficToClassify = async () => {
        this.setState({
            statisticsLoading: true
        });
        const params = this.trafficStatisticsRef.props.form.getFieldsValue();
        params.date = params.date.toDate().toString();
        const data = await gatewayService.getTrafficToClassify(params);
        const trafficXData = [];
        const trafficYData = [];
        const trafficY2Data = [];
        Array.isArray(data) && data.forEach((item) => {
            trafficXData.push(item.localTime);
            trafficYData.push(item.readKb ? item.readKb.toFixed(2) : 0);
            trafficY2Data.push(item.writeKb ? item.writeKb.toFixed(2) : 0);
        });
        this.setState({
            statisticsOptions: {
                title: {
                    subtext: `统计的服务器: ${params.serverId || '-'}`,
                    x: 'center',
                    align: 'right'
                },
                xAxis: [
                    {
                        data: trafficXData
                    }
                ],
                series: [
                    {
                        data: trafficYData,
                        type: 'line'
                    },
                    {
                        data: trafficY2Data,
                        type: 'line'
                    }
                ]
            },
            statisticsLoading: false
        });
    }
    render() {
        const {
            trafficOptions,
            statisticsOptions,
            BarOptions,
            trafficLoading,
            statisticsLoading
        } = this.state;
        return (
            <div className={styles.flow}>
                <Row gutter={16}>
                    <Col span={16}>
                        <Card title={<FlowForm wrappedComponentRef={(ref) => { this.trafficAnalysisRef = ref; }} showServer={false} onSubmit={this.queryTrafficToSum} />} bordered={false} style={{ marginBottom: '20px' }}>
                            <Spin spinning={trafficLoading}>
                                <Traffic setting={trafficOptions} title="Gateway集群流量分析" subTitle="统计所有gateway服务器的流量" />
                            </Spin>
                        </Card>
                        <Card title={<FlowForm wrappedComponentRef={(ref) => { this.trafficStatisticsRef = ref; }} showServer={true} onSubmit={this.queryTrafficToClassify} />} bordered={false}>
                            <Spin spinning={statisticsLoading}>
                                <Traffic setting={statisticsOptions} title="Gateway单台服务流量统计" />
                            </Spin>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card title="Gateway服务器流量比例分析" bordered={false}>
                            <Bar setting={BarOptions} />
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default GetwayFlow;
