import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Traffic extends Component {
    constructor(props) {
        super(props);
        this.state = this.getInitialState();
    }
    UNSAFE_componentWillReceiveProps(nextProps) { // eslint-disable-line
        if (nextProps && nextProps.setting) {
            this.setState({
                option: { ...this.getOption(), ...nextProps.setting }
            });
        }
    }
    getInitialState = () => ({ option: this.getOption() });
    getOption = () => ({
        title: {
            text: this.props.title,
            subtext: this.props.subTitle,
            x: 'center',
            align: 'right'
        },
        toolbox: {
            show: true,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                dataView: { readOnly: false, show: false },
                magicType: { type: ['line', 'bar'] },
                saveAsImage: {}
            }
        },
        dataZoom: [{
            type: 'inside',
            start: 0,
            end: 100
        }],
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['入站', '出站'],
            x: 'left'
        },
        xAxis: [
            {
                type: 'category',
                axisTick: {
                    alignWithLabel: false
                },
                axisLine: {
                    onZero: false,
                },
                data: []
            }
        ],
        yAxis: [
            {
                type: 'value'
            }
        ],
        series: [
            {
                name: '入站',
                type: 'line',
                smooth: true,
                data: [],
                markPoint: {
                    data: [
                        { type: 'max', name: '最高峰' }
                    ]
                }
            },
            {
                name: '出站',
                type: 'line',
                smooth: true,
                data: [],
            }
        ]
    });

    render() {
        return (
            <div>
                <ReactEcharts ref='echarts_react'
                    option={this.state.option}
                    style={{ height: 320, width: '100%' }} />
            </div>
        );
    }
}
