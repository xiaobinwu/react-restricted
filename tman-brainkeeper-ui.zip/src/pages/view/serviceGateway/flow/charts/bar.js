import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Bar extends Component {
    constructor(props) {
        super(props);
        this.state = this.getInitialState();
    }
    UNSAFE_componentWillReceiveProps(nextProps) { // eslint-disable-line
        if (nextProps && nextProps.setting) {
            this.setState({
                option: { ...this.getOption(), ...nextProps.setting }
            });
        }
    }
    getInitialState = () => ({ option: this.getOption() });
    getOption = () => ({
        legend: {
            data: ['入站流量', '出站流量']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '50',
            containLabel: true
        },
        xAxis: [{
            type: 'category',
            data: []
        }],
        yAxis: [{
            type: 'value'
        }],
        series: [
            {
                name: '入站流量',
                type: 'bar',
                data: []
            },
            {
                name: '出站流量',
                type: 'bar',
                data: []
            }
        ]
    });

    render() {
        return (
            <div>
                <ReactEcharts ref='echarts_react'
                    option={this.state.option}
                    style={{ height: 750, width: '100%' }} />
            </div>
        );
    }
}
