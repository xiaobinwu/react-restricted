import React, { Component } from 'react';
import { message, Card, Col, Row, Icon, Divider, Input, Button, Popover, Modal } from 'antd';
import { gatewayService } from 'service';
import Line from './charts/line';

const { confirm } = Modal;

class GetwayColony extends Component {
    state = {
        serverList: [],
        maxRequest: 0,
        btnLoading: false,
    }
    componentDidMount() {
        this.getServerList();
        this.connectWebSocket();
    }
    componentWillUnmount() {
        // 销毁socket连接
        this.io && this.io.close();
        this.io = null;
    }
    flushServers = async () => {
        this.setState({
            btnLoading: true
        });
        const res = await gatewayService.flushServers();
        message.success(res.message);
        this.setState({
            btnLoading: false
        });
    }
    // 获取服务列表
    getServerList = async () => {
        const { data } = await gatewayService.getServerList();
        if (data && data.length > 0) {
            this.setState({
                serverList: data
            });
        }
    }
    // popver显示隐藏
    visibleChange = (item, visible) => {
        if (visible) {
            this.setState({
                maxRequest: item.maxRequest || 0
            });
        }
    }
    // change 最大并发数
    changeMaxRequest = (e) => {
        const { value } = e.target;
        this.setState({
            maxRequest: value
        });
    }
    // 更新最大并发数
    updateMaxRequest = (serverId) => {
        const {
            maxRequest,
            serverList
        } = this.state;
        const content = <div style={{ marginTop: '20px' }}>
            <p>确认要修改服务器ID:{serverId}的并发数为：<span style={{ color: 'red', fontSize: '18px' }}>{maxRequest}</span></p>
        </div>;
        const that = this;
        confirm({
            zIndex: 2000,
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await gatewayService.updateMaxRequest({ serverId, maxRequest });
                    if (res.code === 0) {
                        let index;
                        const findItem = serverList.find((item, i) => {
                            if (item.serverId === serverId) {
                                index = i;
                                return true;
                            }
                            return false;
                        });
                        if (findItem) {
                            findItem.maxRequest = maxRequest;
                            serverList[index] = findItem;
                            that.setState({
                                serverList
                            });
                            message.success(res.message);
                        }
                    }
                })();
            }
        });
    }
    connectWebSocket() {
        this.io = gatewayService.getColonyWebSocket();
        this.io.onmessage = (e) => {
            let index;
            const data = JSON.parse(e.data);
            const {
                serverList
            } = this.state;
            const findItem = serverList.find((item, i) => {
                if (item.serverId === data.serverId) {
                    index = i;
                    return true;
                }
                return false;
            });
            if (findItem) {
                serverList[index] = data;
                this.setState({
                    serverList
                });
            }
        };
        this.io.onclose = (e) => {
            // console.log('webSocket Close!');
        };
    }
    render() {
        const {
            serverList,
            maxRequest,
            btnLoading
        } = this.state;
        return (
            <div>
                <Button
                    type="primary"
                    loading={btnLoading}
                    style={{ width: '100%', marginBottom: '10px' }}
                    onClick={this.flushServers.bind(this)}
                >刷新服务器</Button>
                <Row gutter={16}>
                    {
                        serverList.map((item, index) => {
                            const titleLayout = { marginRight: '15px' };
                            const colLayout = { textAlign: 'center' };
                            const titleComponent = <div>
                                <Icon type="tag" style={titleLayout}/>
                                <span style={titleLayout}>{item.ip}</span>
                                <span style={titleLayout}>{item.fireEyeStatus ? '链路开启' : '链路关闭'}</span>
                                <span>{item.systemRunTime}</span>
                            </div>;
                            const popoverComponent = <Row gutter={16}>
                                <Col span={16}><Input value={maxRequest} onChange={this.changeMaxRequest}/></Col>
                                <Col span={8}><Button type="primary" onClick={this.updateMaxRequest.bind(this, item.serverId)}>修改</Button></Col>
                            </Row>;
                            return (<Col span={8} key={index}>
                                <Card title={titleComponent}>
                                    <div style={{ padding: '20px' }}>
                                        <Row>
                                            <Col span={8} style={colLayout}>
                                                <div>在线服务</div>
                                                <div className="system-colony-normal-color">{item.serviceCount || 0}</div>
                                                <div className="system-colony-normal-color">{item.readKb}/Kb</div>
                                            </Col>
                                            <Col span={8} style={colLayout}>
                                                <div>当前连接数</div>
                                                <div className="system-colony-count-color">{item.connectionCount || 0}</div>
                                                <div className="system-colony-normal-color">{item.writeKb}/Kb</div>
                                            </Col>
                                            <Col span={8} style={colLayout}>
                                                <div>允许并发数</div>
                                                <div className="system-colony-count-color">{item.maxRequest || 0}</div>
                                                <div>
                                                    <Popover placement="rightTop" title="修改最大并发数" content={popoverComponent} trigger="click" onVisibleChange={this.visibleChange.bind(this, item)}>
                                                        <span style={{ cursor: 'pointer', color: '#39f' }}>修改</span>
                                                    </Popover>
                                                </div>
                                            </Col>
                                        </Row>
                                        <Divider className="system-colony-divider-color"/>
                                        <Row>
                                            <Col span={24}>
                                                <Line serverItem={item}/>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col span={6} style={colLayout}>
                                                <div>活动数</div>
                                                <div className="system-colony-count-color">{item.activeTasks || 0}</div>
                                            </Col>
                                            <Col span={6} style={colLayout}>
                                                <div>完成数</div>
                                                <div className="system-colony-notice-color">{item.completeTasks || 0}</div>
                                            </Col>
                                            <Col span={6} style={colLayout}>
                                                <div>空闲数</div>
                                                <div className="system-colony-caution-color">{item.pendingTasks || 0}</div>
                                            </Col>
                                            <Col span={6} style={colLayout}>
                                                <div>最大数</div>
                                                <div className="system-colony-notice-color">{item.maxPoolSize || 0}</div>
                                            </Col>
                                        </Row>
                                        <Divider className="system-colony-divider-color"/>
                                        <Row>
                                            <Col span={6} style={colLayout}>
                                                <div>使用率</div>
                                                <div className="system-colony-count-color">{item.memoryPercentage || 0}%</div>
                                            </Col>
                                            <Col span={6} style={colLayout}>
                                                <div>总量(MB)</div>
                                                <div className="system-colony-notice-color">{item.totalMemorySize || 0}</div>
                                            </Col>
                                            <Col span={6} style={colLayout}>
                                                <div>使用(MB)</div>
                                                <div className="system-colony-caution-color">{item.usedMemory || 0}</div>
                                            </Col>
                                            <Col span={6} style={colLayout}>
                                                <div>剩余(MB)</div>
                                                <div className="system-colony-notice-color">{item.freePhysicalMemorySize || 0}</div>
                                            </Col>
                                        </Row>
                                        <Divider className="system-colony-divider-color"/>
                                        <Row>
                                            <Col span={8} style={colLayout}>
                                                <div>堆大小(MB)</div>
                                                <div className="system-colony-notice-color">{item.totalMemory || 0}</div>
                                            </Col>
                                            <Col span={8} style={colLayout}>
                                                <div>JVM最大(MB)</div>
                                                <div className="system-colony-notice-color">{item.maxMemory || 0}</div>
                                            </Col>
                                            <Col span={8} style={colLayout}>
                                                <div>堆可用(MB)</div>
                                                <div className="system-colony-caution-color">{item.freeMemory || 0}</div>
                                            </Col>
                                        </Row>
                                        <Divider className="system-colony-divider-color"/>
                                    </div>
                                </Card>
                            </Col>);
                        })
                    }
                </Row>
            </div>
        );
    }
}

export default GetwayColony;
