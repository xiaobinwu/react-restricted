import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Line extends Component {
    constructor(props) {
        super(props);
        this.state = this.getInitialState();
    }
    UNSAFE_componentWillReceiveProps(nextProps) { // eslint-disable-line
        if (nextProps && nextProps.serverItem) {
            const thisOpt = this.state.option;
            const x = nextProps.serverItem.semaphore;
            const y = nextProps.serverItem.semaphoreRejected;
            // 删除数组中第一个
            thisOpt.xAxis[0].data.shift();
            thisOpt.xAxis[1].data.shift();
            thisOpt.series[0].data.shift();
            thisOpt.series[1].data.shift();
            // 追加数据
            thisOpt.xAxis[0].data.push(x);
            thisOpt.xAxis[1].data.push(y);
            thisOpt.series[0].data.push(x);
            thisOpt.series[1].data.push(y);

            this.setState({
                option: thisOpt
            });
        }
    }
    getInitialState = () => ({ option: this.getOption() });
    getOption = () => ({
        calculable: false,
        tooltip: {
            trigger: 'none',
            axisPointer: {
                type: 'cross'
            }
        },
        grid: {
            x: 2,
            y: 2,
            x2: 1,
            y2: 1,
            borderWidth: 0
        },
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                show: false,
                data: (() => {
                    const res = [];
                    let len = 20;
                    while (len--) { // eslint-disable-line
                        res.push(0);
                    }
                    return res;
                })()
            },
            {
                type: 'category',
                boundaryGap: false,
                show: false,
                data: (() => {
                    const res = [];
                    let len = 20;
                    while (len--) { // eslint-disable-line
                        res.push(0);
                    }
                    return res;
                })()
            },
        ],
        yAxis: [
            {
                type: 'value',
                scale: false,
                show: false
            }
        ],
        series: [
            {
                type: 'line',
                xAxisIndex: 1,
                smooth: true,
                data: (() => {
                    const res = [];
                    let len = 20;
                    while (len--) { // eslint-disable-line
                        res.push(0);
                    }
                    return res;
                })()
            },
            {
                type: 'line',
                smooth: true,
                data: (() => {
                    const res = [];
                    let len = 20;
                    while (len--) { // eslint-disable-line
                        res.push(0);
                    }
                    return res;
                })()
            }
        ]
    });

    render() {
        return (
            <div>
                <ReactEcharts ref='echarts_react'
                    option={this.state.option}
                    style={{ height: 100, width: '100%' }} />
            </div>
        );
    }
}
