import React, { Component } from 'react';
import { DatePicker, InputNumber, Button, Table } from 'antd';
import moment from 'moment';
import { gatewayService } from 'service';
import styles from './index.css';

class SlowService extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            ts: 10,
            date: new Date(),
            loading: false,
        };
    }
    // 请求数据
    async getSolwList() {
        this.setState({
            loading: true
        });
        const res = await gatewayService.getSlowService({
            date: this.state.date.toString(),
            ts: this.state.ts,
        });
        res.data && res.data.forEach((item, index) => {
            item.key = `${item.service}-${index}`;
        });
        this.setState({
            data: res.data,
            loading: false,
        });
    }
    componentDidMount() {
        this.getSolwList.bind(this)();
    }
    render() {
        const {
            date,
            ts,
            loading,
            data
        } = this.state;
        const columns = [{
            title: '服务KEY',
            dataIndex: 'service',
            key: 'service',
            width: '90%',
        }, {
            title: '耗时(MS)',
            dataIndex: 'times',
            key: 'times',
            width: '10%',
            redner(text) {
                return text.toFixed(2);
            }
        }];

        return <div>
            <div className={`${styles.topbar} system-slowService`}>
                <span className={`${styles.toplabe} system-slowService`}>日期选择:</span>
                <DatePicker
                    defaultValue={moment(date, 'YYYY/MM/DD')}
                    onChange={ dates => this.setState({ date: dates ? dates.toDate() : new Date() }) }
                    disabledDate={ current => current && ((current.valueOf() < Date.now() - (86400000 * 7)) || current.valueOf() > Date.now()) }
                />
                <span className={`${styles.toplabe} system-slowService`}>时间(MS):</span>
                <div className="system-input-number-container">
                    <InputNumber
                        min={0} max={100} defaultValue={ts}
                        onChange={ value => this.setState({ ts: value }) } />
                </div>
                <span className={`${styles.toplabe} system-slowService`}></span>
                <Button type="primary" icon="search" onClick={this.getSolwList.bind(this)}>搜索</Button>
            </div>
            <div className={styles.tablewarp}>
                <Table
                    columns={columns}
                    dataSource={data}
                    loading={loading}
                    locale={ { emptyText: '暂无数据' } }
                />
            </div>
        </div>;
    }
}

export default SlowService;
