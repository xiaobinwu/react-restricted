import React, { Component } from 'react';
import { Row, Col, Form, Input, Checkbox } from 'antd';

const FormItem = Form.Item;

class TokenForm extends Component {
    render() {
        const {
            form
        } = this.props;
        const { getFieldDecorator } = form;
        return (
            <Form layout="inline">
                <Row gutter={16}>
                    <Row style={{ marginBottom: '10px' }}>
                        <Col span={11}>
                            <FormItem label="ServerIP">
                                {getFieldDecorator('server', {
                                    rules: [{
                                        max: 15,
                                        message: '最长长度15'
                                    },
                                    {
                                        required: true,
                                        message: '请填写服务器IP'
                                    }]
                                })(<Input placeholder="server IP" />)}
                            </FormItem>
                        </Col>
                        <Col span={11} offset={2}>
                            <FormItem label="Notes">
                                {getFieldDecorator('notes', {
                                    rules: [{
                                        max: 10,
                                        message: '最长长度10'
                                    },
                                    {
                                        required: true,
                                        message: '请填写备注'
                                    }]
                                })(<Input placeholder="Notes 10 个字" />)}
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span={11}>
                            <FormItem label="Status">
                                {getFieldDecorator('status', {
                                    initialValue: true,
                                    valuePropName: 'checked'
                                })(<Checkbox />)}
                            </FormItem>
                        </Col>
                    </Row>
                </Row>
            </Form>
        );
    }
}

export default Form.create()(TokenForm);
