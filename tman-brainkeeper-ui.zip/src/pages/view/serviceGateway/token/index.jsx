import React, { Component } from 'react';
import { Table, Button, Tag, Modal, message } from 'antd';
import { gatewayService } from 'service';
import withPermission from 'component/hoc/withPermission';
import withFormModal from 'component/hoc/withFormModal';
import TokenForm from './tokenForm';

const { confirm } = Modal;
// 添加token表单
const TokenFormModal = withFormModal(TokenForm);
class GetwayToken extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: false,
            tokenVisible: false,
            tokenConfirmLoading: false
        };
        this.columns = [{
            title: '客户端IP',
            dataIndex: 'server',
            key: 'server'
        }, {
            title: 'TOKEN',
            dataIndex: 'key',
            key: 'key'
        }, {
            title: '状态',
            dataIndex: 'status',
            key: 'status',
            render: (text, record) => {
                if (record.status) {
                    return (<Tag className='system-online-detail-tag'>启用</Tag>);
                }
                return (<Tag className='system-online-detail-error-tag'>禁用</Tag>);
            }
        }, {
            title: '操作',
            key: 'action',
            render: (text, record) => {
                return (
                    <div>
                        {
                            withPermission(record.status ?
                                <Button type="primary" size="small" onClick={this.updateStatus.bind(this, record.server, false)} style={{ marginRight: '10px' }}>禁用</Button>
                                : <Button type="primary" size="small" onClick={this.updateStatus.bind(this, record.server, true)} style={{ marginRight: '10px' }}>启用</Button>, 'PermissionTokenStatus')
                        }
                        {
                            withPermission(<Button type="primary" size="small" onClick={this.remove.bind(this, record.server)}>删除</Button>, 'PermissionTokenDelete')
                        }
                    </div>
                );
            }
        }];
    }
    componentDidMount() {
        this.getData();
    }
    // 删除
    remove = (server) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除{server}的TOKEN信息,持有此TOKEN的客户端立即不能访问Gateway</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await gatewayService.removeToken({ server });
                    if (res.code === 0) {
                        that.getData();
                        message.success(res.message);
                    }
                })();
            }
        });
    }
    // 更新状态
    updateStatus = (server, status) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否{ status ? '启用' : '禁用' }{server}的TOKEN信息,持有此TOKEN的客户端立即不能访问Gateway</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await gatewayService.updateStatus({ server, status });
                    if (res.code === 0) {
                        that.getData();
                        message.success(res.message);
                    }
                })();
            }
        });
    }
    // 获取数据
    getData = async () => {
        this.setState({
            loading: true,
        });
        const data = await gatewayService.getToken();
        this.setState({
            loading: false,
            data
        });
    }
    // 添加token
    addToken = () => {
        this.setState({
            tokenVisible: true
        });
    }
    handleAddToken = (e) => {
        e.preventDefault();
        this.tokenFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                const res = await gatewayService.addToken(values);
                if (res.code === 0) {
                    this.setState({
                        tokenConfirmLoading: false,
                        tokenVisible: false
                    }, () => {
                        this.getData();
                        message.success(res.message);
                    });
                } else {
                    this.setState({
                        tokenConfirmLoading: false
                    });
                }

            }
        });
    }
    // 关闭token modal
    handleCancel = () => {
        this.setState({
            tokenVisible: false
        });
    }
    // 获取token表单ref
    getTokenFormRef = (ref) => {
        this.tokenFormRef = ref;
    }
    render() {
        const {
            data,
            loading,
            tokenVisible,
            tokenConfirmLoading
        } = this.state;
        const { columns } = this;
        return (
            <div>
                {
                    withPermission(<Button type="primary" style={{ marginBottom: '20px' }} icon="plus" onClick={this.addToken}>添加TOKEN</Button>, 'PermissionTokenAdd')
                }
                <Table
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                    pagination={false}
                />
                <TokenFormModal
                    maskClosable={false}
                    getRef={this.getTokenFormRef}
                    title="注册TOKEN"
                    visible={tokenVisible}
                    onOk={this.handleAddToken}
                    onCancel={this.handleCancel}
                    footer={[
                        <Button key="submit" type="primary" loading={tokenConfirmLoading} onClick={this.handleAddToken}>
                            注册
                        </Button>
                    ]}
                />
            </div>
        );
    }
}

export default GetwayToken;
