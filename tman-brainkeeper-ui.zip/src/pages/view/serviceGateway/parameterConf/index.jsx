import moment from 'moment';
import React, { Component } from 'react';
import { Button, Table, Input, Switch, DatePicker, Tag, Modal, message } from 'antd';
import { gatewayService } from 'service';
import withPermission from 'component/hoc/withPermission';
import styles from './index.css';

const { confirm } = Modal;

class Parameter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            status: '0',
            loading: false,
            confirmLoading: false,
        };
    }
    componentDidMount() {
        this.getData();
    }
    // 保存参数
    saveParams = async (dataSource) => {
        let value = '';
        const { key } = dataSource;
        if (dataSource.type === 1) {
            value = 1;
        } else if (dataSource.type === 3) {
            value = new Date(dataSource.val).format('yyyy-MM-dd');
        } else if (dataSource.type === 4) {
            value = new Date(dataSource.val).format('hh:mm:ss');
        } else {
            value = dataSource.val;
        }
        const res = await gatewayService.saveParamsService({ key, value });
        if (res.code === 0) {
            this.getData();
        }
    }
    // 更新默认参数输入框
    changeDefaultVal = (defaultVal, e) => {
        const { value } = e.target;
        const { data } = this.state;
        data[data[defaultVal.index - 1].index - 1].val = value;
        this.setState({
            data: this.state.data
        });
    }
    // 获取数据
    getData = async (e) => {
        e && e.preventDefault();
        const {
            status
        } = this.state;
        const params = {
            status,
        };

        this.setState({
            loading: true
        });

        const res = await gatewayService.getParameterService(params);
        if (res && res.length > 0) {
            res.forEach((item, index) => {
                item.index = index + 1;
                item.val = item.value;
            });
            this.setState({
                loading: false,
                data: res
            });
        }
    }
    // 初始化配置
    initProp = () => {
        const This = this;
        confirm({
            title: '确认提示',
            content: '确认需要初始化所有配置吗？',
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await gatewayService.initProps();
                    if (res.code === 0) {
                        message.info('初始化服务成功!');
                        This.getData();
                    } else {
                        message.info(res.message);
                    }
                })();
            },
        });
    }
    // 清除所有服务配置
    clearAllProp = () => {
        const This = this;
        confirm({
            title: '确认提示',
            content: '确认需要清除所有关于服务相关(信号量熔断、令牌桶熔断、服务超时)的参数吗？',
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await gatewayService.clearAllProps();
                    if (res.code === 0) {
                        message.info('初始化服务成功!');
                        This.getData();
                    } else {
                        message.info(res.message);
                    }
                })();
            },
        });
    }
    render() {
        const {
            loading,
            data,
        } = this.state;

        const columns = [{
            title: '#',
            dataIndex: 'index',
            key: 'group',
            width: 100
        }, {
            title: '配置信息',
            dataIndex: 'text',
            key: 'serviceKey'
        }, {
            title: '唯一KEY',
            dataIndex: 'key',
            key: 'service'
        }, {
            title: '当前值',
            dataIndex: 'value',
            key: 'method',
            width: 200
        }, {
            title: '修改值',
            key: 'parameter',
            render: (text, record) => {
                if (record.isUnUpdate === 0) return '';
                switch (record.typeIndex) {
                case 0:
                    return <Input defaultValue={record.value} style={{ width: '200px' }} />;
                case 1:
                    if (record.value === 1) {
                        return <Switch size="large" defaultChecked> <span slot="open">1</span>  <span slot="close">0</span> </Switch>;
                    }
                    return <Switch size="large" > <span slot="open">1</span>  <span slot="close">0</span> </Switch>;

                case 2:
                    return <Input defaultValue={record.value} style={{ width: '200px' }} />;

                case 3:
                    return <DatePicker defaultOpenValue={(record.value, 'yyyy-MM-dd')} format={'yyyy-MM-dd'} />;

                case 4:
                    return <TimePicker defaultOpenValue={moment(record.value, 'HH:mm:ss')} />;

                case 5:
                    return <Input type="password" defaultValue={record.value} style={{ width: '200px' }} />;

                default:
                    return <Tag color="red">禁止修改</Tag>;
                }

            }
        }];
        if (withPermission(true, 'PermissionParameterSave')) {
            columns.push({
                title: '操作',
                key: 'action',
                width: 150,
                render: (text, record) => {
                    if (record.isUnUpdate === 0) return '';
                    if (record.isUnUpdate === -1) {
                        return (
                            <Button icon="check" type="primary" disabled>保存修改</Button>
                        );
                    }
                    return (
                        <Button icon="check" type="primary" onClick={this.saveParams.bind(this, record)}>保存修改</Button>
                    );
                }
            });
        }
        return (
            <div>
                <div className={styles.btnGroup}>
                    {
                        withPermission(<Button type="primary" size="small" icon="retweet" onClick={this.initProp}>初始化配置</Button>, 'PermissionParameterInit')
                    }
                    {
                        withPermission(<Button type="primary" size="small" icon="retweet" onClick={this.clearAllProp}>清除所有服务配置</Button>, 'PermissionParameterClear')
                    }
                </div>

                <Table
                    loading={loading}
                    columns={columns}
                    dataSource={data}
                />
            </div>
        );
    }
}

export default Parameter;
