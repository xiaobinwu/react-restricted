import React, { Component } from 'react';
import { Switch, Modal, message } from 'antd';
import { gatewayService } from 'service';

const { confirm } = Modal;
class GetwayLinkstate extends Component {
    state = {
        checked: false
    };
    changeStatus = (status) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否关闭/打开链路数据收集!</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await gatewayService.closeFireEye({ status });
                    if (res.code === 0) {
                        that.setState({
                            checked: status
                        });
                        message.success(res.message);
                    }
                })();
            }
        });
    }
    render() {
        const {
            checked
        } = this.state;
        return (
            <div>
                <span className="system-linkstate">链路状态</span>
                <Switch checkedChildren="开" unCheckedChildren="关" checked={checked} onChange={this.changeStatus}/>
            </div>
        );
    }
}

export default GetwayLinkstate;
