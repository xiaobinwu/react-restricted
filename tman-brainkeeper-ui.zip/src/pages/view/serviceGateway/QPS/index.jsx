import React, { Component } from 'react';
import { Card, Col, Row, Spin } from 'antd';
import { gatewayService } from 'service';
import FlowForm from '../flowForm';
import Qps from './charts/qps';
import styles from './index.css';

class GetwayQPS extends Component {
    state = {
        analysisOptions: null,
        statisticsOptions: null,
        serverId: '',
        analysisLoading: false,
        statisticsLoading: false
    }
    componentDidMount() {
        this.queryQpsToSum();
        this.queryQpsToClassify();
    }
    queryQpsToSum = async () => {
        this.setState({
            analysisLoading: true
        });
        const params = this.qpsAnalysisRef.props.form.getFieldsValue();
        params.date = params.date.toDate().toString();
        const data = await gatewayService.getGlobalQpsToSum(params);
        const qpsXData = [];
        const qpsY1Data = [];
        const qpsY2Data = [];
        const qpsY3Data = [];
        const qpsY4Data = [];
        Array.isArray(data) && data.forEach((item, index) => {
            qpsXData.push(item.localTime);
            qpsY1Data.push(item.qps_mean ? item.qps_mean.toFixed(2) : 0);
            qpsY2Data.push(item.qps_1minute ? item.qps_1minute.toFixed(2) : 0);
            qpsY3Data.push(item.qps_5minute ? item.qps_5minute.toFixed(2) : 0);
            qpsY4Data.push(item.qps_15minute ? item.qps_15minute.toFixed(2) : 0);
        });
        this.setState({
            analysisOptions: {
                xAxis: [
                    {
                        data: qpsXData
                    }
                ],
                series: [
                    {
                        name: '平均',
                        type: 'line',
                        smooth: true,
                        data: qpsY1Data
                    },
                    {
                        name: '1分钟',
                        type: 'line',
                        smooth: true,
                        data: qpsY2Data
                    },
                    {
                        name: '5分钟',
                        type: 'line',
                        smooth: true,
                        data: qpsY3Data
                    },
                    {
                        name: '15分钟',
                        type: 'line',
                        smooth: true,
                        data: qpsY4Data
                    }
                ]
            },
            analysisLoading: false
        });
    }
    queryQpsToClassify = async () => {
        this.setState({
            statisticsLoading: true
        });
        const params = this.qpsStatisticsRef.props.form.getFieldsValue();
        params.date = params.date.toDate().toString();
        const data = await gatewayService.getGlobalQpsToClassify(params);
        const qpsXData = [];
        const qpsY1Data = [];
        const qpsY2Data = [];
        const qpsY3Data = [];
        const qpsY4Data = [];
        Array.isArray(data) && data.forEach((item, index) => {
            qpsXData.push(item.localTime);
            qpsY1Data.push(item.qps_mean ? item.qps_mean.toFixed(2) : 0);
            qpsY2Data.push(item.qps_1minute ? item.qps_1minute.toFixed(2) : 0);
            qpsY3Data.push(item.qps_5minute ? item.qps_5minute.toFixed(2) : 0);
            qpsY4Data.push(item.qps_15minute ? item.qps_15minute.toFixed(2) : 0);
        });
        this.setState({
            serverId: params.serverId,
            statisticsOptions: {
                xAxis: [
                    {
                        data: qpsXData
                    }
                ],
                series: [
                    {
                        name: '平均',
                        type: 'line',
                        smooth: true,
                        data: qpsY1Data
                    },
                    {
                        name: '1分钟',
                        type: 'line',
                        smooth: true,
                        data: qpsY2Data
                    },
                    {
                        name: '5分钟',
                        type: 'line',
                        smooth: true,
                        data: qpsY3Data
                    },
                    {
                        name: '15分钟',
                        type: 'line',
                        smooth: true,
                        data: qpsY4Data
                    }
                ]
            },
            statisticsLoading: false
        });
    }
    render() {
        const {
            analysisOptions,
            statisticsOptions,
            serverId,
            analysisLoading,
            statisticsLoading
        } = this.state;
        return (
            <div className={styles.qps}>
                <Row>
                    <Col span={24}>
                        <Card title={<FlowForm wrappedComponentRef={(ref) => { this.qpsAnalysisRef = ref; }} showServer={false} onSubmit={this.queryQpsToSum} />} bordered={false} style={{ marginBottom: '20px' }}>
                            <Spin spinning={analysisLoading}>
                                <Qps setting={analysisOptions} title="Gateway集群QPS分析" subTitle="统计所有gateway服务器的QPS" />
                            </Spin>
                        </Card>
                    </Col>
                    <Col span={24}>
                        <Card title={<FlowForm wrappedComponentRef={(ref) => { this.qpsStatisticsRef = ref; }} showServer={true} onSubmit={this.queryQpsToClassify} />} bordered={false}>
                            <Spin spinning={statisticsLoading}>
                                <Qps setting={statisticsOptions} title="Gateway单台服务QPS分析" subTitle={`统计的服务器: ${serverId || '-'}`} />
                            </Spin>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default GetwayQPS;
