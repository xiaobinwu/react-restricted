import React, { Component } from 'react';
import ReactEcharts from 'component/echarts-for-react';

export default class Qps extends Component {
    constructor(props) {
        super(props);
        this.state = this.getInitialState();
    }
    UNSAFE_componentWillReceiveProps(nextProps) { // eslint-disable-line
        if (nextProps && nextProps.setting) {
            this.setState({
                option: { ...this.getOption(), ...nextProps.setting }
            });
        }
    }
    getInitialState = () => ({ option: this.getOption() });
    getOption = () => ({
        title: {
            text: this.props.title,
            subtext: this.props.subTitle,
            x: 'center',
            align: 'right'
        },
        toolbox: {
            show: true,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                magicType: { type: ['line', 'bar'] },
                saveAsImage: {}
            }
        },
        dataZoom: [{
            type: 'inside',
            start: 0,
            end: 100
        }],
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['平均', '1分钟', '5分钟', '15分钟'],
            x: 'left'
        },
        grid: {
            top: 50,
            bottom: 30,
            right: 20,
            left: 60
        },
        xAxis: [
            {
                type: 'category',
                axisTick: {
                    alignWithLabel: false
                },
                axisLine: {
                    onZero: false,
                },
                data: []
            }
        ],
        yAxis: [
            {
                type: 'value'
            }
        ],
        series: [
            {
                name: '平均',
                type: 'line',
                smooth: true,
                data: []
            },
            {
                name: '1分钟',
                type: 'line',
                smooth: true,
                data: []
            },
            {
                name: '5分钟',
                type: 'line',
                smooth: true,
                data: []
            },
            {
                name: '15分钟',
                type: 'line',
                smooth: true,
                data: []
            }
        ]
    });

    render() {
        return (
            <div>
                <ReactEcharts ref='echarts_react'
                    option={this.state.option}
                    style={{ height: 320, width: '100%' }} />
            </div>
        );
    }
}
