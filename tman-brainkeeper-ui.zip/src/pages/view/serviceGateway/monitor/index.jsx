import React, { Component } from 'react';
import { Card, Col, Row, Select, Table, Icon, Divider } from 'antd';
import { gatewayService } from 'service';
import { roundNumber } from 'js/util';
import Load from './charts/load'; // 负载情况
import Qps from './charts/qps'; // QPS情况
import Line from './charts/line'; // 服务折线
import ThroughPut from './charts/throughPut'; // 流量实时情况
import styles from './index.css';

const { Option } = Select;

class Monitor extends Component {
    constructor(props) {
        super(props);
        this.state = {
            serverList: [],
            selectedServerValue: '',
            serverLineData: [
                {
                    span: 7,
                    type: 'countSuccess', // 总数(参考)
                    value: 0,
                    dec: '总数(参考)'
                },
                {
                    span: 4,
                    type: 'rollingCountSuccess', // 当前请求
                    value: 0,
                    dec: '当前请求'
                },
                {
                    span: 2,
                    type: 'rollingCountShortCircuited', // 熔断
                    value: 0,
                    dec: '熔断'
                },
                {
                    span: 2,
                    type: 'rollingCountSemaphoreRejected', // 拒绝
                    value: 0,
                    dec: '拒绝'
                },
                {
                    span: 2,
                    type: 'rollingCountFailure', // 降级
                    value: 0,
                    dec: '降级'
                },
                {
                    span: 2,
                    type: 'errorCount', // 错误
                    value: 0,
                    dec: '错误'
                },
                {
                    span: 2,
                    type: 'rollingMaxConcurrentExecutionCount', // 饱和
                    value: 0,
                    dec: '饱和'
                },
                {
                    span: 3,
                    type: 'errorPercentage', // 错误率
                    value: 0,
                    dec: '错误率',
                    suffix: '%'
                }
            ],
            serverLatencyData: [
                {
                    title: 'Mean',
                    type: 'latencyExecute_mean',
                    value: 0
                },
                {
                    title: 'Median',
                    type: 'latencyExecute_percentile_50',
                    value: 0
                },
                {
                    title: '90TH',
                    type: 'latencyExecute_percentile_90',
                    value: 0
                },
                {
                    title: '99TH',
                    type: 'latencyExecute_percentile_99',
                    value: 0
                },
                {
                    title: '995TH',
                    type: 'latencyExecute_percentile_995',
                    value: 0
                }
            ],
            loadOptions: null,
            qpsOptions: null,
            lineOptions: null,
            throughPutOptions: null,
            hotServiceData: [],
            errorServiceData: [],
            writeKb: 0,
            readKb: 0
        };
        this.hotServiceColumns = [
            {
                title: 'SERVICE',
                dataIndex: 'service',
                key: 'service'
            },
            {
                title: 'TO',
                key: 'totalCount',
                dataIndex: 'totalCount',
                width: 130
            }
        ];
        this.errorServiceColumns = [
            {
                title: 'SERVICE',
                dataIndex: 'service',
                key: 'service'
            },
            {
                title: 'TO',
                key: 'errorCount',
                dataIndex: 'errorCount',
                width: 130
            }
        ];
        this.initLineOptions = (() => {
            const res = [];
            let len = 20;
            while (len--) { // eslint-disable-line
                res.push(0);
            }
            return res;
        })();
        this.initQpsOptions = null;
        this.initThroughPutOptions = null;
    }
    componentDidMount() {
        this.getServerList();
        this.getQps();
        this.getHotService();
        this.getErrorService();
        this.connectWebSocket();
    }
    componentWillUnmount() {
        // 销毁socket连接
        this.io && this.io.close();
        this.io = null;
    }
    // QPS实时情况与流量实时情况初始化
    getQps = async () => {
        const { data } = await gatewayService.getQps();
        if (data && data.length > 0) {
            this.queryQps(data);
            this.getThroughPut(data);
        }
    }
    // 错误服务初始化
    getErrorService = async () => {
        const { data } = await gatewayService.getErrorService();
        if (data && data.length > 0) {
            this.errorService(data);
        }
    }
    // 流量实时情况初始化
    getThroughPut = (data) => {
        if (data && data.length > 0) {
            const times = [];
            const readKbs = [];
            const writeKbs = [];
            let readKb;
            let writeKb;
            data.forEach((item, index) => {
                times.splice(0, 0, item.localTime);
                readKbs.splice(0, 0, item.readKb);
                writeKbs.splice(0, 0, item.writeKb);
                if (index === 0 && item.readKb) {
                    readKb = item.readKb.toFixed(2);
                    writeKb = item.readKb.toFixed(2);
                }
            });
            this.initThroughPutOptions = {
                times,
                readKbs,
                writeKbs
            };
            this.setState({
                writeKb: writeKb || '0.00',
                readKb: readKb || '0.00',
                throughPutOptions: {
                    xAxis: [
                        {
                            show: false,
                            type: 'category',
                            axisTick: {
                                alignWithLabel: false
                            },
                            axisLine: {
                                onZero: false,
                            },
                            data: times
                        }
                    ],
                    series: [
                        {
                            name: '入站',
                            type: 'bar',
                            smooth: true,
                            data: readKbs
                        },
                        {
                            name: '出站',
                            type: 'line',
                            smooth: true,
                            data: writeKbs
                        }
                    ]
                }
            });
        }
    }
    // 热点服务初始化
    getHotService = async () => {
        const { data } = await gatewayService.getHotService();
        if (data && data.length > 0) {
            this.hotService(data);
        }
    }
    // 获取服务列表
    getServerList = async () => {
        const { data } = await gatewayService.getServerList();
        if (data && data.length > 0) {
            const filterData = data.map((item, index) => {
                return {
                    ip: item.ip,
                    serverId: item.serverId
                };
            });
            this.setState({
                serverList: filterData,
                selectedServerValue: `${filterData[0].ip || ''}-${filterData[0].serverId || ''}`
            });
        }
    }
    // 创建websocket
    connectWebSocket = () => {
        this.io = gatewayService.getWebSocket();
        this.io.onmessage = (e) => {
            const data = JSON.parse(e.data);
            const { type, value } = data;
            switch (type) {
            case 1: {
                this.traffic(value);
                break;
            }
            case 2: {
                this.errorService(value);
                break;
            }
            case 3: {
                this.hotService(value);
                break;
            }
            case 4: {
                this.load(value);
                break;
            }
            default:
                this.serverLine(value);
            }
        };
        this.io.onclose = (e) => {
            // console.log('webSocket Close!');
        };
    }
    // websockit下实时更新负载情况监控
    load = (data) => {
        const xAxisData = [];
        const seriesData = [];
        if (data && data.length > 0) {
            data.forEach((element) => {
                xAxisData.push(element.serverId);
                seriesData.push(element.totalCount);
            });
        }
        this.setState({
            loadOptions: {
                xAxis: [
                    {
                        data: xAxisData
                    }
                ],
                series: [
                    {
                        type: 'bar',
                        barWidth: '50%',
                        data: seriesData
                    }
                ]
            }
        });
    }
    // websockit下实时更新QPS
    queryQps = (data) => {
        const times = [];
        const meanQps = [];
        const meanQps1 = [];
        const meanQps5 = [];
        const meanQps15 = [];
        data.forEach((item) => {
            times.splice(0, 0, item.localTime);
            meanQps.splice(0, 0, item.qps_mean);
            meanQps1.splice(0, 0, item.qps_1minute);
            meanQps5.splice(0, 0, item.qps_5minute);
            meanQps15.splice(0, 0, item.qps_15minute);
        });
        this.initQpsOptions = {
            times,
            meanQps,
            meanQps1,
            meanQps5,
            meanQps15
        };
        this.setState({
            qpsOptions: {
                xAxis: [
                    {
                        data: times
                    }
                ],
                series: [
                    {
                        name: '平均',
                        type: 'line',
                        smooth: true,
                        data: meanQps
                    },
                    {
                        name: '1分钟',
                        type: 'line',
                        smooth: true,
                        data: meanQps1
                    },
                    {
                        name: '5分钟',
                        type: 'line',
                        smooth: true,
                        data: meanQps5
                    },
                    {
                        name: '15分钟',
                        type: 'line',
                        smooth: true,
                        data: meanQps15
                    }
                ]
            }
        });
    }
    // websockit下实时更新流量实时情况,以及QPS实时情况
    traffic = (data) => {
        const {
            qPS_mean,
            qPS_1minute,
            qPS_5minute,
            qPS_15minute,
            localTime,
            readKb,
            writeKb
        } = data;
        if (readKb === null) { return; }
        if (this.initQpsOptions) {
            const options = this.initQpsOptions;
            options.meanQps.shift();
            options.meanQps.push(qPS_mean);
            options.meanQps1.shift();
            options.meanQps1.push(qPS_1minute);
            options.meanQps5.shift();
            options.meanQps5.push(qPS_5minute);
            options.meanQps15.shift();
            options.meanQps15.push(qPS_15minute);
            options.times.shift();
            options.times.push(localTime);
            this.setState({
                qpsOptions: {
                    xAxis: [
                        {
                            data: options.times
                        }
                    ],
                    series: [
                        {
                            name: '平均',
                            type: 'line',
                            smooth: true,
                            data: options.meanQps
                        },
                        {
                            name: '1分钟',
                            type: 'line',
                            smooth: true,
                            data: options.meanQps1
                        },
                        {
                            name: '5分钟',
                            type: 'line',
                            smooth: true,
                            data: options.meanQps5
                        },
                        {
                            name: '15分钟',
                            type: 'line',
                            smooth: true,
                            data: options.meanQps15
                        }
                    ]
                }
            });
        }
        if (this.initThroughPutOptions) {
            const options = this.initThroughPutOptions;
            const data0 = options.readKbs;
            const data1 = options.writeKbs;
            const xAxis = options.times;
            data0.shift();
            data0.push(readKb);
            data1.shift();
            data1.push(writeKb);
            xAxis.shift();
            xAxis.push(localTime);
            this.setState({
                readKb: readKb.toFixed(2),
                writeKb: writeKb.toFixed(2),
                throughPutOptions: {
                    xAxis: [
                        {
                            show: false,
                            type: 'category',
                            axisTick: {
                                alignWithLabel: false
                            },
                            axisLine: {
                                onZero: false,
                            },
                            data: xAxis
                        }
                    ],
                    series: [
                        {
                            name: '入站',
                            type: 'bar',
                            smooth: true,
                            data: data0
                        },
                        {
                            name: '出站',
                            type: 'line',
                            smooth: true,
                            data: data1
                        }
                    ]
                }
            });
        }
    }
    // 错误服务实时情况
    errorService = (data) => {
        if (data && data.length > 0) {
            data.forEach((item, index) => {
                item.key = index;
            });
            this.setState({
                errorServiceData: data
            });
        }
    }
    // websockit下实时更新热点服务情况
    hotService = (data) => {
        if (data && data.length > 0) {
            data.forEach((item, index) => {
                item.key = index;
            });
            this.setState({
                hotServiceData: data
            });
        }
    }
    // websockit下实时更新服务请求情况
    serverLine = (data) => {
        const {
            selectedServerValue,
            serverLineData,
            serverLatencyData
        } = this.state;
        if (data.length === 0) {
            return;
        }
        if (selectedServerValue) {
            let currentData = data[0];  // eslint-disable-line
            data.some((item) => {
                if (item.serverId === selectedServerValue) {
                    currentData = item;
                    return true;
                }
                return false;
            });
            serverLineData.forEach((item) => {
                item.value = currentData[item.type];
            });
            serverLatencyData.forEach((item) => {
                item.value = currentData[item.type];
            });
            const totalThreadsExecuted = currentData.totalCount > 0 ? currentData.totalCount : 0;
            const ratePer = roundNumber(totalThreadsExecuted / 10);
            this.initLineOptions.shift();
            this.initLineOptions.push(ratePer);
            this.setState({
                serverLineData,
                serverLatencyData,
                lineOptions: {
                    graphic: [
                        {
                            id: 'showBack',
                            type: 'text',
                            left: 'center',
                            top: 'center',
                            z: 0,
                            style: {
                                fill: '#d8d9da',
                                text: `${ratePer}/S`,
                                font: '30px Microsoft YaHei'
                            }
                        }
                    ],
                    series: [
                        {
                            smooth: true,
                            type: 'line',
                            data: this.initLineOptions
                        }
                    ]
                }
            });
        }
    }
    // 生成布局
    constructClass = (index) => {
        return `${styles.title} system-monitor-title-${index}`;
    }
    // 服务切换
    serverChange = (value) => {
        this.setState({
            selectedServerValue: value
        });
    }
    render() {
        const {
            serverList,
            selectedServerValue,
            loadOptions,
            qpsOptions,
            lineOptions,
            throughPutOptions,
            serverLineData,
            serverLatencyData,
            hotServiceData,
            errorServiceData,
            readKb,
            writeKb
        } = this.state;

        const { hotServiceColumns, errorServiceColumns } = this;

        const serverListView = (
            <Select style={{ width: '100%' }} value={selectedServerValue} onChange={this.serverChange}>
                {
                    serverList.map((item, index) => {
                        return (<Option value={`${item.ip}-${item.serverId}`} key={index}>{item.ip}-{item.serverId}</Option>);
                    })
                }
            </Select>
        );

        const colLayout = { textAlign: 'center' };
        const latencyLeftLayout = { textAlign: 'left', margin: '10px 0' };
        const latencyRightLayout = { textAlign: 'right', margin: '10px 0' };

        const serverLatencyView = (
            <React.Fragment>
                {
                    serverLatencyData.map((item, index) => {
                        return (<Row key={index} className='system-monitor-border-bottom'>
                            <Col style={latencyLeftLayout} span={12}>{item.title}</Col>
                            <Col style={latencyRightLayout} span={12}>{item.value}Ms</Col>
                        </Row>);
                    })
                }
            </React.Fragment>
        );

        const serverMonitorView = (
            <Row style={{ marginBottom: '10px' }}>
                {
                    serverLineData.map((item, index) => {
                        return (<Col span={item.span} style={colLayout} key={index} className={index === 0 ? 'system-monitor-border-right' : ''}>
                            <div className={this.constructClass(index)}>{item.value}{item.suffix}</div>
                            <div className={styles.dec}>{item.dec}</div>
                        </Col>);
                    })
                }
            </Row>
        );
        return (
            <div>
                <Row gutter={16} style={{ marginBottom: 16 }}>
                    <Col span={6}>
                        <Card title="负载情况">
                            <Load setting={loadOptions} />
                        </Card>
                    </Col>
                    <Col span={10}>
                        <Card title={serverListView}>
                            <Row style={{ padding: '16px' }}>
                                {serverMonitorView}
                                <Row>
                                    <Col span={20} style={{ padding: '15px', paddingBottom: '5px' }}>
                                        <Line ref={(line) => { this.lineRef = line; }} setting={lineOptions} />
                                    </Col>
                                    <Col span={4}>
                                        {serverLatencyView}
                                    </Col>
                                </Row>
                            </Row>
                        </Card>
                    </Col>
                    <Col span={8}>
                        <Card title="QPS实时情况">
                            <Qps ref={(qps) => { this.qpsRef = qps; }} setting={qpsOptions}/>
                        </Card>
                    </Col>
                </Row>
                <Row gutter={16} style={{ marginBottom: 16 }}>
                    <Col span={8}>
                        <Card title="热点服务TOP-20/1D" className={styles.hotServiceCard}>
                            <Table
                                className={styles.table}
                                columns={hotServiceColumns}
                                dataSource={hotServiceData}
                                pagination={false}
                                scroll={{ y: 367 }}
                                showHeader={false}
                                locale={{ emptyText: '暂无数据' }}
                            />
                        </Card>
                    </Col>
                    <Col span={16}>
                        <Card title="流量实时情况">
                            <Row>
                                <Row>
                                    <Col span={2} className={styles.kb}>
                                        <div>
                                            <div className="system-monitor-top-kbnum">
                                                <Icon type="arrow-up" />
                                                <span>{writeKb}</span>
                                            </div>
                                            <div>KB</div>
                                        </div>
                                        <Divider className="system-monitor-divider" />
                                        <div>
                                            <div className="system-monitor-bottom-kbnum">
                                                <Icon type="arrow-down" />
                                                <span>{readKb}</span>
                                            </div>
                                            <div>KB</div>
                                        </div>
                                    </Col>
                                    <Col span={20} style={{ paddingLeft: '20px' }}>
                                        <ThroughPut ref={(throughPut) => { this.throughPutRef = throughPut; }} setting={throughPutOptions}/>
                                    </Col>
                                </Row>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <Row gutter={16}>
                    <Col span={24}>
                        <Card title="错误服务TOP-10/1D">
                            <Table
                                className={styles.table}
                                columns={errorServiceColumns}
                                dataSource={errorServiceData}
                                pagination={false}
                                scroll={{ y: 367 }}
                                showHeader={false}
                                locale={{ emptyText: '暂无数据' }}
                            />
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default Monitor;
