import React from 'react';
import Loadable from 'react-loadable';
import ErrorBoundary from 'component/error';
import Loading from './loading';

const generateLoadable = (component, props) => Loadable({
    loader: component,
    loading: () => <Loading {...props}/>,
    // 自定义渲染
    render(loaded, propsObj) {
        // 全局错误边界
        const Component = loaded.default;
        return (<ErrorBoundary>
            <Component {...propsObj}/>
        </ErrorBoundary>);
    },
    delay: 20000
});

export default {

    // 系统管理
    JobManagement: generateLoadable(() => import(/* webpackChunkName: 'JobManagement' */ 'view/systemManagement/jobManagement')), // 作业管理
    Application: generateLoadable(() => import(/* webpackChunkName: 'Application' */ 'view/systemManagement/application')), // 应用管理
    User: generateLoadable(() => import(/* webpackChunkName: 'User' */ 'view/systemManagement/user')), // 用户管理
    Character: generateLoadable(() => import(/* webpackChunkName: 'Character' */ 'view/systemManagement/character')), // 角色管理
    Menu: generateLoadable(() => import(/* webpackChunkName: 'Menu' */ 'view/systemManagement/menu')), // 菜单管理
    Site: generateLoadable(() => import(/* webpackChunkName: 'Site' */ 'view/systemManagement/site')), // 站点管理
    Setting: generateLoadable(() => import(/* webpackChunkName: 'Setting' */ 'view/systemManagement/setting')), // 配置管理

    // 概览报表
    BusinessReport: generateLoadable(() => import(/* webpackChunkName: 'BusinessReport' */ 'view/businessMarket/businessReport')), // 核心业务报表
    FlowAnalysis: generateLoadable(() => import(/* webpackChunkName: 'FlowAnalysis' */ 'view/businessMarket/flowAnalysis')), // 站点流量分析
    Overview: generateLoadable(() => import(/* webpackChunkName: 'Overview' */ 'view/businessMarket/overview')), // 业务概览
    AlarmSummary: generateLoadable(() => import(/* webpackChunkName: 'AlarmSummary' */ 'view/businessMarket/alarmSummary')), // 告警大盘

    // 数据监控
    BillResult: generateLoadable(() => import(/* webpackChunkName: 'BillResult' */ 'view/dataMonitor/billResult')), // 对账结果
    Task: generateLoadable(() => import(/* webpackChunkName: 'Task' */ 'view/dataMonitor/task')), // 任务管理
    TaskTargetResult: generateLoadable(() => import(/* webpackChunkName: 'TaskTargetResult' */ 'view/dataMonitor/taskTargetResult')), // 任务管理-目标结果管理
    DataSoure: generateLoadable(() => import(/* webpackChunkName: 'DataSoure' */ 'view/dataMonitor/dataSoure')), // 数据源管理
    AlarmContent: generateLoadable(() => import(/* webpackChunkName: 'AlarmContent' */ 'view/dataMonitor/alarmContent')), // 统计告警
    AlarmContentDetail: generateLoadable(() => import(/* webpackChunkName: 'AlarmContentDetail' */ 'view/dataMonitor/alarmContentDetail')), // 统计告警-详情
    AlarmReconciliation: generateLoadable(() => import(/* webpackChunkName: 'AlarmReconciliation' */ 'view/dataMonitor/alarmReconciliation')), // 对账告警
    AlarmReconciliationDetail: generateLoadable(() => import(/* webpackChunkName: 'AlarmReconciliationDetail' */ 'view/dataMonitor/alarmReconciliationDetail')), // 对账告警-详情
    AlarmUser: generateLoadable(() => import(/* webpackChunkName: 'AlarmUser' */ 'view/dataMonitor/alarmUser')), // 告警用户
    OrderReport: generateLoadable(() => import(/* webpackChunkName: 'OrderReport' */ 'view/dataMonitor/order')), // 订单报表
    PayReport: generateLoadable(() => import(/* webpackChunkName: 'PayReport' */ 'view/dataMonitor/pay')), // 支付报表
    MarketingReport: generateLoadable(() => import(/* webpackChunkName: 'MarketingReport' */ 'view/dataMonitor/marketing')), // 营销报表
    GoodsReport: generateLoadable(() => import(/* webpackChunkName: 'GoodsReport' */ 'view/dataMonitor/goods')), // 商品报表
    MemberReport: generateLoadable(() => import(/* webpackChunkName: 'MemberReport' */ 'view/dataMonitor/member')), // 会员报表
    SalesMarket: generateLoadable(() => import(/* webpackChunkName: 'SalesMarket' */ 'view/dataMonitor/salesMarket')), // 双十一销售大盘
    SalesEarthMonitor: generateLoadable(() => import(/* webpackChunkName: 'SalesEarthMonitor' */ 'view/dataMonitor/salesEarthMonitor')), // 销售区域分布趋势
    ReconciliationDataSource: generateLoadable(() => import(/* webpackChunkName: 'ReconciliationDataSource' */ 'view/dataMonitor/reconciliationDataSource')), // 数据源管理-业务对账
    BillList: generateLoadable(() => import(/* webpackChunkName: 'BillList' */ 'view/dataMonitor/billList')), // 对账作业列表
    Canal: generateLoadable(() => import(/* webpackChunkName: 'Canal' */ 'view/dataMonitor/canal')), // canal监控仪表

    // 火眼
    InterfaceInfo: generateLoadable(() => import(/* webpackChunkName: 'InterfaceInfo' */ 'view/linkTracking/interfaceInfo')), // 调用接口分析
    InterfaceInfoList: generateLoadable(() => import(/* webpackChunkName: 'InterfaceInfoList' */ 'view/linkTracking/interfaceInfoList')), // 应用实时报表
    TraceInfoList: generateLoadable(() => import(/* webpackChunkName: 'TraceInfoList' */ 'view/linkTracking/traceInfoList')), // 链路信息
    TraceInquire: generateLoadable(() => import(/* webpackChunkName: 'TraceInquire' */ 'view/linkTracking/traceInquire')), // 链路详情
    TopologyInfo: generateLoadable(() => import(/* webpackChunkName: 'TopologyInfo' */ 'view/linkTracking/topologyInfo')), // 应用拓扑
    ServiceList: generateLoadable(() => import(/* webpackChunkName: 'ServiceList' */ 'view/linkTracking/serviceList')), // 服务管理-服务列表
    FaultList: generateLoadable(() => import(/* webpackChunkName: 'FaultList' */ 'view/linkTracking/faultList')), // 告警管理-故障列表
    MonitorGroup: generateLoadable(() => import(/* webpackChunkName: 'MonitorGroup' */ 'view/linkTracking/monitorGroup')), // 告警管理-监控组
    MonitorPoint: generateLoadable(() => import(/* webpackChunkName: 'MonitorPoint' */ 'view/linkTracking/monitorPoint')), // 告警管理-监控点
    MonitorRule: generateLoadable(() => import(/* webpackChunkName: 'MonitorRule' */ 'view/linkTracking/monitorRule')), // 告警管理-规则管理
    MonitorMessage: generateLoadable(() => import(/* webpackChunkName: 'MonitorMessage' */ 'view/linkTracking/monitorMessage')), // 告警管理-告警消息
    ExceptionLog: generateLoadable(() => import(/* webpackChunkName: 'ExceptionLog' */ 'view/linkTracking/exceptionLog')), // 异常日志页面
    FavoriteService: generateLoadable(() => import(/* webpackChunkName: 'FavoriteService' */ 'view/linkTracking/favoriteService')), // 我收藏的接口

    // 网关服务系统
    GetwayDubbo: generateLoadable(() => import(/* webpackChunkName: 'GetwayDubbo' */ 'view/serviceGateway/dubbo')), // Dubbo服务
    GetwayOnline: generateLoadable(() => import(/* webpackChunkName: 'GetwayOnline' */ 'view/serviceGateway/online')), // Gateway在线服务
    GetwayOnlineDetail: generateLoadable(() => import(/* webpackChunkName: 'GetwayOnlineDetail' */ 'view/serviceGateway/onlineDetail')), // Gateway在线服务-服务详情
    GetwayConnect: generateLoadable(() => import(/* webpackChunkName: 'GetwayConnect' */ 'view/serviceGateway/connect')), // 连接管理
    GetwayMonitor: generateLoadable(() => import(/* webpackChunkName: 'GetwayMonitor' */ 'view/serviceGateway/monitor')), // 在线监控
    GetwayFlow: generateLoadable(() => import(/* webpackChunkName: 'GetwayFlow' */ 'view/serviceGateway/flow')), // 全局流量分析
    GetwayQPS: generateLoadable(() => import(/* webpackChunkName: 'GetwayQPS' */ 'view/serviceGateway/QPS')), // 全局QPS分析
    GetwaySlowService: generateLoadable(() => import(/* webpackChunkName: 'GetwaySlowService' */ 'view/serviceGateway/slowService')), // 慢服务查询
    GetwayColony: generateLoadable(() => import(/* webpackChunkName: 'GetwayColony' */ 'view/serviceGateway/colony')), // 集群概览
    GetwayIpblacklist: generateLoadable(() => import(/* webpackChunkName: 'GetwayIpblacklist' */ 'view/serviceGateway/ipblacklist')), // IP 黑名单
    GetwayToken: generateLoadable(() => import(/* webpackChunkName: 'GetwayToken' */ 'view/serviceGateway/token')), // TOKEN管理
    GetwayParameterConf: generateLoadable(() => import(/* webpackChunkName: 'GetwayParameterConf' */ 'view/serviceGateway/parameterConf')), // 参数配置
    GetwayLinkstate: generateLoadable(() => import(/* webpackChunkName: 'GetwayLinkstate' */ 'view/serviceGateway/linkstate')), // 链路状态

    // 延时调度平台
    ServiceNode: generateLoadable(() => import(/* webpackChunkName: 'ServiceNode' */ 'view/scheduling/serviceNode')), // 服务节点
    TaskQueue: generateLoadable(() => import(/* webpackChunkName: 'TaskQueue' */ 'view/scheduling/taskQueue')) // 任务队列
};
