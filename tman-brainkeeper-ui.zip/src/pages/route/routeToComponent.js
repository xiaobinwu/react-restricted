import permissions from './permission';

export default {
    /* 路由与组件名的映射关系 */

    // 系统管理
    '/system-management/jobManagement': 'JobManagement', // 作业管理
    '/system-management/application': 'Application', // 应用管理
    '/system-management/user-system/user': 'User', // 用户管理
    '/system-management/user-system/character': 'Character', // 角色管理
    '/system-management/user-system/menu': 'Menu', // 菜单管理
    '/system-management/user-system/site': 'Site', // 站点管理
    '/system-management/user-system/setting': 'Setting', // 配置管理

    // 概览报表
    '/business-market/businessReport': 'BusinessReport', // 核心业务报表
    '/business-market/flowAnalysis': 'FlowAnalysis', // 站点流量分析
    '/business-market/overview': 'Overview', // 业务概览
    '/business-market/alarmSummary': 'AlarmSummary', // 告警大盘

    // 火眼
    '/link-tracking/analysis/interfaceInfo': 'InterfaceInfo', // 调用接口分析
    '/link-tracking/analysis/interfaceInfoList': 'InterfaceInfoList', // 应用实时报表
    '/link-tracking/analysis/exceptionLog': 'ExceptionLog', // 异常日志
    '/link-tracking/analysis/appAnalysis': 'AppAnalysis', // app页面分析
    '/link-tracking/trace/traceInfoList': 'TraceInfoList', // 链路信息
    '/link-tracking/trace/traceInquire': 'TraceInquire', // 链路详情
    '/link-tracking/topology': 'TopologyInfo', // 应用拓扑
    '/link-tracking/service/serviceList': 'ServiceList', // 服务管理-服务列表
    '/link-tracking/alarm/faultList': 'FaultList', // 告警管理-故障列表
    '/link-tracking/alarm/monitorGroup': 'MonitorGroup', // 告警管理-监控组
    '/link-tracking/alarm/monitorPoint': 'MonitorPoint', // 告警管理-监控点
    '/link-tracking/alarm/monitorRule': 'MonitorRule', // 告警管理-规则管理
    '/link-tracking/alarm/monitorMessage': 'MonitorMessage', // 告警管理-告警消息
    '/link-tracking/favorite/service': 'FavoriteService', // 我收藏的接口

    // 数据监控
    '/common-system/monitor-management/reconciliation/billResult': 'BillResult', // 对账结果
    '/common-system/monitor-management/reconciliation/dataSoure': 'ReconciliationDataSource', // 数据源管理-业务对账
    '/common-system/monitor-management/reconciliation/billList': 'BillList', // 对账作业列表
    '/common-system/monitor-management/reconciliation/canal': 'Canal', // canal监控仪表
    '/common-system/monitor-management/reportForm/orderReport': 'OrderReport', // 订单报表
    '/common-system/monitor-management/reportForm/payReport': 'PayReport', // 支付报表
    '/common-system/monitor-management/reportForm/marketingReport': 'MarketingReport', // 营销报表
    '/common-system/monitor-management/reportForm/memberReport': 'MemberReport', // 会员报表
    '/common-system/monitor-management/reportForm/goodsReport': 'GoodsReport', // 商品报表
    '/common-system/monitor-management/ruleMonitor/task': 'Task', // 任务管理
    '/common-system/monitor-management/ruleMonitor/task/taskTargetResult': 'TaskTargetResult', // 任务管理-目标结果管理
    '/common-system/monitor-management/ruleMonitor/dataSoure': 'DataSoure', // 数据源管理
    '/common-system/monitor-management/ruleMonitor/alarmContent': 'AlarmContent', // 统计告警
    '/common-system/monitor-management/ruleMonitor/alarmContent/alarmContentDetail': 'AlarmContentDetail', // 统计告警-详情
    '/common-system/monitor-management/reconciliation/alarmReconciliation': 'AlarmReconciliation', // 对账告警
    '/common-system/monitor-management/reconciliation/alarmReconciliation/alarmReconciliationDetail': 'AlarmReconciliationDetail', // 对账告警-详情
    '/common-system/monitor-management/ruleMonitor/alarmUser': 'AlarmUser', // 告警用户
    '/common-system/monitor-management/reportForm/salesMarket': 'SalesMarket', // 双十一销售大盘
    '/common-system/monitor-management/reportForm/salesEarthMonitor': 'SalesEarthMonitor', // 销售区域分布趋势


    // 网关服务系统
    '/common-system/service-gateway/serviceManagement/service/dubbo': 'GetwayDubbo', // Dubbo服务
    '/common-system/service-gateway/serviceManagement/service/online': 'GetwayOnline', // Gateway在线服务
    '/common-system/service-gateway/serviceManagement/service/online/onlineDetail': 'GetwayOnlineDetail', // Gateway在线服务-服务详情
    '/common-system/service-gateway/serviceManagement/line/connect': 'GetwayConnect', // 连接管理
    '/common-system/service-gateway/monitoringManagement/live/monitor': 'GetwayMonitor', // 在线监控
    '/common-system/service-gateway/monitoringManagement/offline/flow': 'GetwayFlow', // 全局流量分析
    '/common-system/service-gateway/monitoringManagement/offline/QPS': 'GetwayQPS', // 全局QPS分析
    '/common-system/service-gateway/monitoringManagement/offline/slowService': 'GetwaySlowService', // 慢服务查询
    '/common-system/service-gateway/clusterManagement/manager/colony': 'GetwayColony', // 集群概览
    '/common-system/service-gateway/clusterManagement/manager/blacklist': 'GetwayIpblacklist', // IP 黑名单
    '/common-system/service-gateway/clusterManagement/manager/token': 'GetwayToken', // TOKEN管理
    '/common-system/service-gateway/clusterManagement/system/parameter': 'GetwayParameterConf', // 参数配置
    '/common-system/service-gateway/clusterManagement/system/link': 'GetwayLinkstate', // 链路状态

    // 延时调度平台
    '/common-system/scheduling/serviceNode': 'ServiceNode', // 服务节点
    '/common-system/scheduling/taskQueue': 'TaskQueue', // 任务队列

    // 个人设置
    '/setting/safecenter/googleVerification': 'GoogleVerification', // 谷歌双重验证

    /* 页面功能权限别名配置 */
    ...permissions
};
