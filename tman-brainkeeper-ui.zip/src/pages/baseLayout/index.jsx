import React, { Component } from 'react';
import { BrowserRouter } from 'react-router-dom';
import logo from 'src/logo.png';
import titleImg from 'img/title.png';
import { Layout, Icon, Spin, BackTop } from 'antd';
import SiderMenu from 'component/siderMenu';
import HeaderMenu from 'component/headerMenu';
import BreadGuide from 'component/breadGuide';
import AidNav from 'component/aidNav';
import ViewSet from 'component/viewSet';
import { MENUSLIST } from 'js/variable';
import { storage } from 'js/util';
import styles from './index.css';

const {
    Header, Sider, Content, Footer
} = Layout;

class BaseLayout extends Component {
    constructor(props) {
        super(props);
        this.state = {
            collapsed: false,
            loading: false
        };
    }
    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });
    }
    // 获取所有type为1的顶级菜单,以及化为平级的菜单
    getEqualedMenus = (navData) => {
        const equaledMenu = {};
        const walkTopMenu = (routes) => {
            if (routes.url) {
                equaledMenu[routes.id] = routes;
            }
            if (routes.children && routes.children.length > 0) {
                routes.children.forEach((item, index) => {
                    walkTopMenu(item);
                });
            }
        };
        walkTopMenu(navData);
        return equaledMenu;
    }
    render() {
        const {
            collapsed,
            loading
        } = this.state;

        const menusList = JSON.parse(storage.getStore(MENUSLIST)); // 获取菜单树，用于子组件生成菜单（由于antd菜单为树结构，因此生成菜单用树结构很合适）
        // 获取平级化的菜单对象（用于匹配url来找到指定菜单key很合适）
        const equaledMenu = this.getEqualedMenus(menusList);
        return (
            <Spin spinning={loading} size="large" wrapperClassName={styles.spin}>
                <BrowserRouter>
                    <Layout>
                        <Sider
                            trigger={null}
                            collapsible
                            collapsed={collapsed}
                            width="256"
                        >
                            <div className="system-logo">
                                <img src={logo} alt="logo" />
                                <h1>
                                    <img src={titleImg} alt="title" style={{ width: 168 }}/>
                                </h1>
                            </div>

                            <SiderMenu {...this.props} collapsed={collapsed} navData={menusList} equaledMenu={equaledMenu} />

                        </Sider>
                        <Layout>
                            <Header className="system-header">
                                <Icon
                                    className="stystem-trigger"
                                    type={collapsed ? 'menu-unfold' : 'menu-fold'}
                                    onClick={this.toggle}
                                />

                                <HeaderMenu {...this.props} navData={menusList} equaledMenu={equaledMenu} />

                                <AidNav />
                            </Header>

                            <Content className="system-content">
                                <BreadGuide />
                                <div className="system-main">
                                    <ViewSet navData={menusList} />
                                </div>
                            </Content>
                            <Footer className="system-footer">
                                BrainKeeper ©2018-2019 Created by the Platform Architecture Group of the Electronic Projects Division
                            </Footer>
                            <BackTop>
                                <Icon type="to-top" theme="outlined" />
                            </BackTop>
                        </Layout>
                    </Layout>
                </BrowserRouter>
            </Spin>
        );
    }
}

export default BaseLayout;
