import React, { Component } from 'react';
import { Route, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import { Spin } from 'antd';
import { userService } from 'service';
import { hanlePermission } from 'component/hoc/withPermission';
import store from 'rRedux/store';
import { MENUSLIST, GATEWAY } from 'js/variable';
import { base64, storage } from 'js/util';
// 登录状态认证组件
class AuthorizedRoute extends Component {
    componentDidMount() {
        // 获取用户信息
        (async () => {
            const { entry, code } = await userService.getUserInfo();
            if (code === '0') {
                const menuList = storage.getStore(MENUSLIST);
                const gateway = storage.getStore(GATEWAY);
                let res;
                if (menuList) {
                    res = JSON.parse(menuList);
                } else {
                    // 用户验证成功后，获取权限路由信息
                    const result = await userService.getResourceTree();
                    if (result.code === '0') {
                        storage.setStore(MENUSLIST, JSON.stringify(result.entry));
                        res = result.entry;
                    }
                }
                if (!gateway) {
                    const sys = await userService.getSysInfo();
                    if (sys.code === '0') {
                        storage.setStore(GATEWAY, base64.encode(JSON.stringify(sys.entry.gateway)));
                    }
                }
                hanlePermission(res); // 收集页面功能性操作展示权限
                store.dispatch({
                    type: 'SET_LOGGED_USER',
                    logged: true,
                    username: entry.username,
                    account: entry.account
                });
            } else {
                store.dispatch({
                    type: 'SET_LOGGED_USER',
                    logged: false,
                    username: '',
                    account: ''
                });
            }
        })();
    }
    render() {
        const {
            component: Component, loadThemePending, pending, logged, ...rest // eslint-disable-line
        } = this.props;
        return (
            <Route {...rest} render={(props) => {
                if (loadThemePending || pending) {
                    return (
                        <Spin size="large" tip="Loading..." style={{ minHeight: '100%' }}>
                            <div style={{
                                minHeight: '800px',
                                height: '100vh'
                            }}>
                            </div>
                        </Spin>
                    );
                }
                return logged ? (<Component {...props} />) : (<Redirect to="/auth" />);
            }} />
        );
    }
}

// 将state通过connect包装AuthorizedRoute组件，达到state以props方式传入组件
const stateToProps = ({ userState }) => ({
    pending: userState.pending,
    loadThemePending: userState.loadThemePending,
    logged: userState.logged
});

export default connect(stateToProps)(AuthorizedRoute);
