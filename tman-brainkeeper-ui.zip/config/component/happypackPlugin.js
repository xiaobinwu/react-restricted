const HappyPack = require('happypack');
const os = require('os');
const eslintFormatter = require('react-dev-utils/eslintFormatter');
const paths = require('./paths');
const happyThreadPool = HappyPack.ThreadPool({ size: os.cpus().length });

const createHappypack = (env) => {
    const isProduction = env.stringified['process.env'].NODE_ENV === '"production"';
    let cssHappypackAarry = [];
    if (isProduction) {
        // Source maps are resource heavy and can cause out of memory issue for large source files.
        const shouldUseSourceMap = process.env.GENERATE_SOURCEMAP !== 'false';
        cssHappypackAarry = [
            new HappyPack({
                id: 'css',
                threads: 4,
                loaders: [{
                    loader: 'css-loader',
                    options: {
                        importLoaders: 1,
                        minimize: true,
                        sourceMap: shouldUseSourceMap,
                        modules: true,
                        localIdentName: '[name]__[local]___[hash:base64:5]'
                    },
                },
                {
                    loader: 'postcss-loader'
                }
                ],
                threadPool: happyThreadPool
            }),
            new HappyPack({
                id: 'less',
                threads: 4,
                loaders: [{
                    loader: 'css-loader',
                    options: {
                        importLoaders: 1,
                        minimize: true,
                        sourceMap: shouldUseSourceMap,
                    },
                },
                {
                    loader: 'less-loader', // compiles Less to CSS
                    options: {
                        javascriptEnabled: true
                    }
                }
                ],
                // Note: this won't work without `new ExtractTextPlugin()` in `plugins`.
                threadPool: happyThreadPool
            })
        ];
    } else {
        cssHappypackAarry = [
            new HappyPack({
                id: 'css',
                threads: 4,
                loaders: [
                    {
                        loader: 'style-loader'
                    },
                    {
                        loader: 'css-loader',
                        options: {
                            importLoaders: 1,
                            modules: true,
                            localIdentName: '[name]__[local]___[hash:base64:5]'
                        },
                    },
                    {
                        loader: 'postcss-loader'
                    }
                ],
                threadPool: happyThreadPool
            }),
            new HappyPack({
                id: 'less',
                threads: 4,
                loaders: [
                    {
                        loader: 'style-loader'
                    },
                    {
                        loader: 'css-loader',
                        options: {
                            importLoaders: 1,
                        },
                    },
                    {
                        loader: 'less-loader',
                        options: {
                            javascriptEnabled: true
                        }
                    }
                ],
                threadPool: happyThreadPool
            })
        ];
    }
    return [
        new HappyPack({
            id: 'babel',
            threads: 4,
            loaders: [{
                loader: 'babel-loader',
                options: {
                    compact: isProduction,
                    cacheDirectory: !isProduction,
                },
            }],
            threadPool: happyThreadPool
        }),
        ...cssHappypackAarry,
        ...(!isProduction ? [
            new HappyPack({
                id: 'eslint',
                threads: 4,
                loaders: [{
                    loader: 'eslint-loader',
                    options: {
                        formatter: eslintFormatter,
                        eslintPath: require.resolve('eslint'),
                    },
                }],
                threadPool: happyThreadPool
            })
        ] : [])
    ];
}

module.exports = {
    createHappypack
};
