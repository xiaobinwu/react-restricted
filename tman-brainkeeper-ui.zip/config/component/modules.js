// const ModuleScopePlugin = require('react-dev-utils/ModuleScopePlugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const paths = require('./paths');

module.exports = (env) => {
    const isProduction = env.stringified['process.env'].NODE_ENV === '"production"';
    let cssLoaderAarry = [];
    if (isProduction) {
        // Webpack uses `publicPath` to determine where the app is being served from.
        // It requires a trailing slash, or the file assets will get an incorrect path.
        const publicPath = paths.servedPath;
        // Some apps do not use client-side routing with pushState.
        // For these, "homepage" can be set to "." to enable relative asset paths.
        const shouldUseRelativeAssetPaths = publicPath === './';

        // Note: defined here because it will be used more than once.
        const cssFilename = 'static/css/[name].[contenthash:8].css';
        // ExtractTextPlugin expects the build output to be flat.
        // (See https://github.com/webpack-contrib/extract-text-webpack-plugin/issues/27)
        // However, our output is structured with css, js and media folders.
        // To have this structure working with relative paths, we have to use custom options.
        const extractTextPluginOptions = shouldUseRelativeAssetPaths
            ? // Making sure that the publicPath goes back to to build folder.
            { publicPath: Array(cssFilename.split('/').length).join('../') }
            : {};
        cssLoaderAarry = [{
            test: /\.css$/,
            loader: ExtractTextPlugin.extract(Object.assign(
                {
                    fallback: {
                        loader: 'style-loader',
                        options: {
                            hmr: false,
                        },
                    },
                    use: 'happypack/loader?id=css',
                },
                extractTextPluginOptions
            )),
        },
        {
            test: /\.less$/,
            loader: ExtractTextPlugin.extract(Object.assign(
                {
                    fallback: {
                        loader: 'style-loader',
                        options: {
                            hmr: false,
                        },
                    },
                    use: 'happypack/loader?id=less',
                },
                extractTextPluginOptions
            ))
        }
        ];
    } else {
        cssLoaderAarry = [{
            test: /\.css$/,
            use: 'happypack/loader?id=css',
        },
        {
            test: /\.less$/,
            use: 'happypack/loader?id=less',
        }
        ];
    }
    return {
        strictExportPresence: true,
        rules: [
            // TODO: Disable require.ensure as it's not a standard language feature.
            // We are waiting for https://github.com/facebookincubator/create-react-app/issues/2176.
            // { parser: { requireEnsure: false } },

            // First, run the linter.
            // It's important to do this before Babel processes the JS.
            ...(!isProduction ? [
                {
                    test: /\.(js|jsx|mjs)$/,
                    enforce: 'pre',
                    use: [{
                        loader: 'happypack/loader?id=eslint'
                    }],
                    include: paths.appSrc,
                }
            ] : []),
            {
                oneOf: [{
                    test: [/\.bmp$/, /\.gif$/, /\.jpe?g$/, /\.png$/],
                    loader: 'url-loader',
                    options: {
                        limit: 10000,
                        name: 'static/media/[name].[hash:8].[ext]',
                    },
                },
                {
                    test: /\.(js|jsx|mjs)$/,
                    include: paths.appSrc,
                    loader: 'happypack/loader?id=babel'
                },
                ...cssLoaderAarry,
                {
                    exclude: [/\.html$/, /\.(js|jsx|mjs)$/, /\.(css|less)$/, /\.json$/, /\.bmp$/, /\.gif$/, /\.jpe?g$/, /\.png$/],
                    loader: 'file-loader',
                    options: {
                        name: 'static/media/[name].[hash:8].[ext]',
                    },
                },
                ],
            },
        ],
    };
};
