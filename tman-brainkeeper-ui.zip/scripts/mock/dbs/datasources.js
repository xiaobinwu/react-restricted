const data = {
     // 改变状态
     "datasources*execStatus": {
        "code": "0",
        "message": "修改状态成功"
    },
    // 保存目标结果管理数据
    "datasources*insertUpdate": {
        "code": "0",
        "message": "保存成功"
    },
    
    "datasources*loadRecord": {
        "code": "0",
        "message": "加载成功"
    },

    "datasources*delete": {
        "code": "0",
        "message": "删除成功"
    }

}
 
module.exports = data;

