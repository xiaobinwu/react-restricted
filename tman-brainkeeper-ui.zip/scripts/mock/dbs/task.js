const data = {
    // 任务管理列表
    "quartzjobsql*queryNoPage": {
        "code": "0",
        "entry": {
          "list": [{
            "id": 1,
            "creatDate": null,
            "updateDate": null,
            "sqlCron": "SELECT COUNT(1) countNum FROM goods_price_relation_$$Array(1-50)$$ WHERE rate = 0 AND sys_update_time >= CURDATE()",
            "status": "NORMAL",
            "applicationId": 1,
            "cron": "0 */5 * * * ?",
            "name": "价格计算利润率为0",
            "descr": "价格计算利润率为0",
            "lastExecDate": null,
            "sqlType": null,
            "dataSourcesId": 1,
            "minuteNum": 60
          }, {
            "id": 2,
            "creatDate": null,
            "updateDate": null,
            "sqlCron": "SELECT COUNT(1) countNum FROM goods_price_change_log_$$Date(yyyyMM)$$ WHERE change_status = 2 AND change_time >= unix_timestamp(CURDATE())",
            "status": "DISABLE",
            "applicationId": 1,
            "cron": "0 */5 * * * ?",
            "name": "价格计算失败",
            "descr": "价格计算失败",
            "lastExecDate": null,
            "sqlType": null,
            "dataSourcesId": 1,
            "minuteNum": 60
          }, {
            "id": 3,
            "creatDate": null,
            "updateDate": null,
            "sqlCron": "SELECT COUNT(1) countNum FROM goods_cutpic_result WHERE create_time >= unix_timestamp(CURDATE())",
            "status": "DISABLE",
            "applicationId": 1,
            "cron": "0 */5 * * * ?",
            "name": "切图大量失败",
            "descr": "切图大量失败",
            "lastExecDate": null,
            "sqlType": null,
            "dataSourcesId": 1,
            "minuteNum": 60
          }, {
            "id": 4,
            "creatDate": null,
            "updateDate": null,
            "sqlCron": "select a.ip,a.num from (select count(ip) as num,ip  from mem_reg_log where result_type=1 and create_time>=unix_timestamp(CURDATE()) GROUP BY ip)a where num >1",
            "status": "DISABLE",
            "applicationId": 2,
            "cron": "0 */5 * * * ?",
            "name": "单IP重复注册",
            "descr": "单IP重复注册",
            "lastExecDate": null,
            "sqlType": null,
            "dataSourcesId": 2,
            "minuteNum": 60
          }],
          page: 1,
          pages: 1,
          size: 20,
          total: 3
        }
      },

    // 数据源
    "datasources*queryNoPage": {
        "code": "0",
        "entry": {
          "list": [{
            "id": 1,
            "status": 'DISABLE',
            "name": "开发商品库",
            "url": "jdbc:mysql://10.60.46.206:3306/gb_goods?useUnicode=true&characterEncoding=UTF-8&useOldAliasMetadataBehavior=true&noAccessToProcedureBodies=true&serverTimezone=UTC&tinyInt1isBit=false&autoReconnect=true",
            "descr": "",
            "prop": "{\"username\":\"java-service\",\"password\":\"java123456\",\"initialSize\":\"1\",\"minIdle\":\"5\",\"maxActive\":\"20\"}"
          }, {
            "id": 2,
            "status": "NORMAL",
            "name": "开发会员",
            "url": "jdbc:mysql://10.60.46.206:3306/gb_member?useUnicode=true&characterEncoding=UTF-8&useOldAliasMetadataBehavior=true&noAccessToProcedureBodies=true&serverTimezone=UTC&tinyInt1isBit=false&autoReconnect=true",
            "descr": "",
            "prop": "{\"username\":\"java-service\",\"password\":\"java123456\",\"initialSize\":\"1\",\"minIdle\":\"5\",\"maxActive\":\"50\"}"
          }],
          page: 1,
          pages: 1,
          size: 20,
          total: 3
        }
      }, 

    // 应用列表
    "application*queryNoPage": {
        "code": "0",
        "entry": {
          "list": [{
            "id": 1,
            "status": null,
            "name": "goods",
            "owanName": "ddd",
            "descr": "ddd"
          }, {
            "id": 2,
            "status": null,
            "name": "member",
            "owanName": "",
            "descr": ""
          }]
        }
      },

    // 新增修改任务
    "quartzjobsql*insertUpdate": {
      "code": "0",
      "message": "保存成功"
    },

    // 删除任务
    "quartzjobsql*delete": {
      "code": "0",
      "message": "删除成功"
    },

    // 移除屏蔽
    "quartzjobsql*removeWarnId": {
      "code": "0",
      "message": "移除成功"
    },

    // 改变状态
    "quartzjobsql*execStatus": {
      "code": "0",
      "message": "修改状态成功"
    },

    // 获取目标结果管理数据
    "quartzjobcomparator*queryNoPage": {
      "code": "0",
      "entry": {
        "list": [{
          "id" : 2,
          "creatDate" : null,
          "status" : null,
          "jobSqlId" : 2,
          "name" : "计算失败数量",
          "columnName" : "countNum",
          "comparatorType" : "LT",
          "value" : 100.00,
          "descr" : "0"
        }],
        page: 1,
        pages: 1,
        size: 20,
        total: 3
      }
    },

    // 保存目标结果管理数据
    "quartzjobcomparator*insertUpdate": {
      "code": "0",
      "message": "保存成功"
    },

    // 删除目标结果管理数据
    "quartzjobcomparator*delete": {
      "code": "0",
      "message": "删除成功"
    }

}
 
module.exports = data;

