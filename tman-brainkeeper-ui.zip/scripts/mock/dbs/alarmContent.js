const data = {
    // 获取告警内容
    "warn*queryNoPage": {
       "code": "0",
       "entry": {
        "list": [ {
            "id" : 45,
            "creatDate" : "2018-08-17 09:10:50",
            "uuid" : "be443936dda04786bd35c3cc6ae25115",
            "title" : "北京时间：2018-08-17 09:10:50:1 价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":0}]]}",
            "processResult" : null
          }, {
            "id" : 44,
            "creatDate" : "2018-08-17 09:01:40",
            "uuid" : "b503b5a9776344d4a3b11b8350dd8bee",
            "title" : "北京时间：2018-08-17 09:01:40:1 价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":0}]]}",
            "processResult" : null
          }, {
            "id" : 43,
            "creatDate" : "2018-08-17 08:58:10",
            "uuid" : "796dff32e4d6485f82cbc0527f55a00d",
            "title" : "北京时间：2018-08-17 08:58:10:0 价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":0}]]}",
            "processResult" : null
          }, {
            "id" : 42,
            "creatDate" : "2018-08-17 08:56:11",
            "uuid" : "5b7b19542e614a24ade1b858b904e209",
            "title" : "北京时间：2018-08-17 08:56:10:8 价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":0}]]}",
            "processResult" : null
          }, {
            "id" : 41,
            "creatDate" : "2018-08-16 19:08:00",
            "uuid" : "fc4de57ef94a4a3f871859c2d28cfa92",
            "title" : "价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":41}]]}",
            "processResult" : null
          }, {
            "id" : 40,
            "creatDate" : "2018-08-16 19:07:00",
            "uuid" : "b38fe64ab7de4aac8248c1c2621609be",
            "title" : "价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":41}]]}",
            "processResult" : null
          }, {
            "id" : 39,
            "creatDate" : "2018-08-16 18:50:00",
            "uuid" : "17c8573abea84862b46c28d1066a4f9c",
            "title" : "价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":41}]]}",
            "processResult" : null
          }, {
            "id" : 38,
            "creatDate" : "2018-08-16 18:49:00",
            "uuid" : "15ad3841d76a4fd7b006481bc532bedf",
            "title" : "价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":41}]]}",
            "processResult" : null
          }, {
            "id" : 37,
            "creatDate" : "2018-08-16 18:47:00",
            "uuid" : "7851c2956b61422baab91ec35746f960",
            "title" : "价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":41}]]}",
            "processResult" : null
          }, {
            "id" : 36,
            "creatDate" : "2018-08-16 18:43:00",
            "uuid" : "29a9197f281b49e6a300e64de48a8524",
            "title" : "价格计算失败",
            "status" : "initialise",
            "jobId" : 14,
            "content" : "{\"columnNames\":[\"计算失败数量 等于 100.00\"],\"values\":[[{\"flag\":false,\"souces\":41}]]}",
            "processResult" : null
          } ],
          page: 1,
          pages: 1,
          size: 20,
          total: 3
       }
   },

   "warn*get": {
     code: '0',
     entry: {
      "id" : 27,
      "creatDate" : "2018-08-14 15:01:57",
      "uuid" : "14776ff12c044abab5a17812c9a7b7b5",
      "title" : "单IP重复注册",
      "status" : "initialise",
      "jobId" : 16,
      "content" : "{\"columnNames\":[\"ip 数据展示 -1.00\",\"num 等于 100.00\"],\"values\":[[{\"flag\":true,\"souces\":169935525},{\"flag\":false,\"souces\":6}],[{\"flag\":true,\"souces\":169935829},{\"flag\":false,\"souces\":2}],[{\"flag\":true,\"souces\":3232238081},{\"flag\":false,\"souces\":21}]]}",
      "processResult" : null
    }
   },

    "warn*removeWarnId": {
      "code": "0",
      "message": "清除当前阶段屏蔽成功"
   }

}

module.exports = data;

