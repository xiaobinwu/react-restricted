
const task = require('./task');
const datasources = require('./datasources');
const alarmContent = require('./alarmContent');

const data = {
    ...task,
    ...datasources,
    ...alarmContent
}

module.exports = data;