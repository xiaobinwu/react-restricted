const dbs = require('./dbs');

module.exports = function() {
    return dbs;
}