const Router = require('koa-router');

const router = new Router();
const Token = require('../controllers/token');
const Ctrl = require('../controllers/user');

router.post('/login', Ctrl.login);
router.get('/info', Token.checkToken, Ctrl.info);

module.exports = router.routes();
