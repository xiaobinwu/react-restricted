const Router = require('koa-router');

const router = new Router();
const Token = require('../../controllers/token');
const Ctrl = require('../../controllers/performance/weeklyData');

router.get('/list', Token.checkToken, Ctrl.findAll);
router.post('/create', Token.checkToken, Ctrl.create);
router.post('/update', Token.checkToken, Ctrl.update);
router.post('/delete', Token.checkToken, Ctrl.destroy);

module.exports = router.routes();