const Router = require('koa-router');

const router = new Router();
const Token = require('../../controllers/token');
const Ctrl = require('../../controllers/performance/speedCompare');

router.get('/compare-list', Token.checkToken, Ctrl.findAll);
router.post('/compare-add', Ctrl.create);
router.post('/compare-delete', Ctrl.destroy);
router.post('/compare-edit', Ctrl.update);

module.exports = router.routes();
