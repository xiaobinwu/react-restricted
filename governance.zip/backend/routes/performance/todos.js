const Router = require('koa-router');

const router = new Router();
const Token = require('../../controllers/token');
const Ctrl = require('../../controllers/performance/todos');

router.get('/list', Token.checkToken, Ctrl.findAll);
router.post('/add', Token.checkToken, Ctrl.create);
router.post('/edit', Token.checkToken, Ctrl.update);
router.post('/delete', Token.checkToken, Ctrl.destroy);

module.exports = router.routes();
