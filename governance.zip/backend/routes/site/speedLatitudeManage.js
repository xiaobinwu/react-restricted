const Router = require('koa-router');

const router = new Router();
const Token = require('../../controllers/token');
const Spla = require('../../controllers/site/speedLatitudeManage');

router.get('/list', Token.checkToken, Spla.findAll);
router.post('/add', Spla.create);
router.post('/delete', Spla.destroy);

module.exports = router.routes();
