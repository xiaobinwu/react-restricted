const Router = require('koa-router');

const router = new Router();
const Token = require('../../controllers/token');
const weekL = require('../../controllers/site/weekLatitudeManage');

router.get('/list', Token.checkToken, weekL.findAll);
router.post('/add', weekL.create);
router.post('/delete', weekL.destroy);

module.exports = router.routes();
