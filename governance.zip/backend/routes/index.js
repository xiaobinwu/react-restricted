module.exports = (router) => {
    router.prefix('/api');
    // 测试demo
    router.use('/todos', require('./performance/todos'));
    // 用户模块
    router.use('/user', require('./user'));
    // 性能管理模块
    router.use('/performance/speedCompare', require('./performance/speedCompare')); // GB与Zaful速度对比
    router.use('/performance/weeklyData', require('./performance/weeklyData')); // 每周加载速度录入
    // 日志系统模块
    router.use('/logdata/weekly', require('./logdata/weekly'));
    router.use('/logdata/record', require('./logdata/record'));

    // 维度管理模块
    router.use('/site/speedLatitudeManage', require('./site/speedLatitudeManage'));
    router.use('/site/weekLatitudeManage', require('./site/weekLatitudeManage'));
};
