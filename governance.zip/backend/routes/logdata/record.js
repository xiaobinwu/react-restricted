const Router = require('koa-router');

const router = new Router();
const Token = require('../../controllers/token');
const recordCtrl = require('../../controllers/logdata/record');

router.post('/', Token.checkToken, recordCtrl.findAll);
router.post('/add', Token.checkToken, recordCtrl.create);
router.post('/edit', Token.checkToken, recordCtrl.update);
router.post('/delete', Token.checkToken, recordCtrl.destroy);

module.exports = router.routes();
