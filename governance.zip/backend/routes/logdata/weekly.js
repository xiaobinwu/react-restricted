const Router = require('koa-router');

const router = new Router();
const Token = require('../../controllers/token');
const dailyCtrl = require('../../controllers/logdata/weekly');

router.get('/', Token.checkToken, dailyCtrl.findAll);
router.post('/add', Token.checkToken, dailyCtrl.create);
router.post('/edit', Token.checkToken, dailyCtrl.update);
router.post('/delete', Token.checkToken, dailyCtrl.destroy);

module.exports = router.routes();
