const WeekLatitude = require('../../models/site/weekLatitudeManage');
const utils = require('../utils');
// 默认维度
// const defaultData = [{ cnName: '全站', enName: 'sitePromotion', mark: 'site' },{ cnName: '首页', enName: 'indexPromotion', mark: 'index' },{ cnName: '分类', enName: 'categoryPromotion', mark: 'category' },{ cnName: '商祥', enName: 'detailPromotion', mark: 'detail' },{ cnName: '品牌页', enName: 'brandPromotion', mark: 'brand' },{ cnName: '活动', enName: 'activityPromotion', mark: 'activity' },{ cnName: '营销页面', enName: 'marketingPromotion', mark: 'marketing' },{ cnName: '注册登录', enName: 'loginPromotion', mark: 'login' },{ cnName: '个人中心', enName: 'userPromotion', mark: 'user' },{ cnName: '购物车', enName: 'cartPromotion', mark: 'cart' },{ cnName: '确认订单', enName: 'orderPromotion', mark: 'order' },{ cnName: '支付平台', enName: 'payPromotion', mark: 'pay' }];

const findAll = async (ctx) => {
    const {
        manage
    } = ctx.query;
    try {
        const res = await WeekLatitude.find({});
        const entryData = {};
        res.forEach((item) => {
            entryData[item.mark] = {
                id: item._id,
                cnName: item.cnName,
                enName: item.enName,
                mark: item.mark
            };
        });
        ctx.body = {
            entry: manage ? res : entryData,
            code: 0,
            message: 'success'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

const create = async (ctx) => {
    const newData = new WeekLatitude(ctx.request.body);
    try {
        const { mark } = ctx.request.body;
        const res = await WeekLatitude.findByMark(mark);
        if (res.length > 0) {
            ctx.body = utils.errorHandle('维度标识不能重复');
            return;
        }
        await newData.save();
        ctx.body = {
            code: 0,
            message: 'success'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

const destroy = async (ctx) => {
    const {
        id
    } = ctx.request.body;
    const wherestr = {
        _id: id
    };
    try {
        await WeekLatitude.remove(wherestr);
        ctx.body = {
            code: 0,
            message: 'success'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

module.exports = {
    findAll,
    create,
    destroy,
};
