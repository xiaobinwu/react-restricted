const SpeedLatitude = require('../../models/site/speedLatitudeManage');
const utils = require('../utils');

// 默认维度
// const defaultData = [{cnName: '全站',enName: 'sitePromotion',mark: 'sitePromotion',typeCode: 2},{cnName: '全站-排推广',enName: 'siteUnPromotion', mark: 'siteUnPromotion',typeCode: 1},{cnName: '首页',enName: 'indexPromotion', mark: 'indexPromotion',typeCode: 2}, {cnName: '首页-排推广',enName: 'indexUnPromotion',mark: 'indexUnPromotion', typeCode: 1 },{cnName: '商祥页',enName: 'detailPromotion',mark: 'detailPromotion',typeCode: 2 }, { cnName: '商祥页-排推广',enName: 'detailUnPromotion',mark: 'detailUnPromotion',typeCode: 1 },{cnName: '列表页', enName: 'listPromotion',mark: 'listPromotion',  typeCode: 2 },{cnName: '列表页-排推广',enName: 'listUnPromotion', mark: 'listUnPromotion', typeCode: 1}, { cnName: '活动页',enName: 'activityPromotion',mark: 'activityPromotion',typeCode: 2}, {cnName: '活动页-排推广',enName: 'activityUnPromotion',mark: 'activityUnPromotion',typeCode: 1 },{cnName: '购物车',enName: 'cartPromotion', mark: 'cartPromotion', typeCode: 2}];

const findAll = async (ctx) => {
    const {
        manage,
        typeCode
    } = ctx.query;
    const condition = typeCode ? { typeCode } : {};
    try {
        const res = await SpeedLatitude.find(condition);
        const entryData = {};
        res.forEach((item) => {
            entryData[item.mark] = {
                id: item._id,
                cnName: item.cnName,
                enName: item.enName,
                mark: item.mark
            };
        });
        ctx.body = {
            entry: manage ? res : entryData,
            code: 0,
            message: 'success'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

const create = async (ctx) => {
    const newData = new SpeedLatitude(ctx.request.body);
    try {
        const { mark } = ctx.request.body;
        const res = await SpeedLatitude.findByMark(mark);
        if (res.length > 0) {
            ctx.body = utils.errorHandle('维度标识不能重复');
            return;
        }
        await newData.save();
        ctx.body = {
            code: 0,
            message: 'success'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

const destroy = async (ctx) => {
    const {
        id
    } = ctx.request.body;
    const wherestr = {
        _id: id
    };
    try {
        await SpeedLatitude.remove(wherestr);
        ctx.body = {
            code: 0,
            message: 'success'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

module.exports = {
    findAll,
    create,
    destroy,
};
