
const jwt = require('jsonwebtoken');

// 创建token
const createToken = (userId) => {
    const token = jwt.sign({ userId }, process.env.SECRETKEY, { expiresIn: 60 * 3600 });
    return token;
};

// 检查token
const checkToken = async (ctx, next) => {
    const token = ctx.get('Authorization');
    if (token === '') {
        ctx.throw(401, 'no token detected in http headerAuthorization');
    }
    let tokenContent;
    try {
        tokenContent = await jwt.verify(token, process.env.SECRETKEY);
        console.log(tokenContent);
    } catch (err) {
        ctx.throw(401, 'invalid token');
    }
    await next();
};

module.exports = {
    createToken,
    checkToken
};
