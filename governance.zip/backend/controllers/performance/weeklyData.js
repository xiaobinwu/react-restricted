const WeeklyData = require('../../models/performance/weeklyData');
const utils = require('../utils');

const findAll = async (ctx) => {
    const {
        pageNo,
        pageSize,
        startEventTime,
        endEventTime,
        week,
        platform,
    } = ctx.query;
    const sql = {
        pageNo,
        pageSize,
        Model: WeeklyData,
        queryParams: {
            ...{
                ...(startEventTime && endEventTime ? {
                    createTime: {
                        $gte: Number(startEventTime),
                        $lte: Number(endEventTime)
                    }
                } : {})
            },
            ...{ ...(platform ? { platform } : {}) },
            ...{ ...(week ? { week } : {}) }
        },
        sortParams: {
            week: -1
        }
    };
    const res = await utils.pageQuery(sql);
    ctx.body = res;
};

const create = async (ctx) => {
    const weeklyData = new WeeklyData(ctx.request.body);
    try {
        await weeklyData.save();
        ctx.body = {
            code: 0,
            message: '创建成功'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

const update = async (ctx) => {
    const { _id } = ctx.request.body;
    if (_id) ctx.body = utils.errorHandle('Not Id');
    try {
        const entry = await WeeklyData.findByIdAndUpdate({ _id }, ctx.request.body, { new: true });
        ctx.body = {
            code: 0,
            entry,
            message: '保存成功'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

const destroy = async (ctx) => {
    const { _id } = ctx.request.body;
    if (_id) ctx.body = utils.errorHandle('Not Id');
    try {
        await WeeklyData.remove({ _id });
        ctx.body = {
            code: 0,
            _id,
            message: '删除成功'
        };
    } catch (e) {
        ctx.body = utils.errorHandle(e.message || '');
    }
};

module.exports = {
    findAll,
    create,
    update,
    destroy,
};
