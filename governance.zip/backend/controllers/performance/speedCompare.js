const {
    SpeedCompare
} = require('../../models/performance/speedCompare');
const { pageQuery } = require('../../controllers/utils');


const findAll = async (ctx) => {
    // Fetch all Todo's from the database and return as payload
    const condition = {};
    const {
        pageSize,
        pageNo,
        platform,
        week,
        startEventTime,
        endEventTime
    } = ctx.query;
    if (platform) {
        condition.platform = platform;
    }
    if (week) {
        condition.week = week;
    }
    if (startEventTime && endEventTime) {
        condition.startEventTime = {
            $gte: startEventTime,
            $lte: endEventTime
        };
    }
    const sortParams = {
        startEventTime: -1
    };
    const postData = {
        pageNo: Number(pageNo),
        pageSize: Number(pageSize),
        Model: SpeedCompare,
        queryParams: condition,
        sortParams,
        populate: ''
    };
    const queryData = await pageQuery(postData);
    const lists = [];
    queryData.entry.list.forEach((item) => {
        lists.push({
            id: item._id,
            platform: item.platform,
            startEventTime: item.startEventTime,
            endEventTime: item.endEventTime,
            week: item.week,
            speedLists: item.speedLists
        });
    });
    queryData.entry.list = lists;
    ctx.body = queryData;
};

const create = async (ctx) => {
    // EMPTY
    const dataList = ctx.request.body;
    const newData = new SpeedCompare(dataList);
    await newData.save()
        .then((res) => {
            ctx.body = {
                code: 0,
                message: 'success'
            };
        })
        .catch((err) => {
            ctx.body = {
                code: 1,
                message: err.message || ''
            };
        });
};

const destroy = async (ctx) => {
    const {
        id
    } = ctx.request.body;
    const wherestr = {
        _id: id
    };
    await SpeedCompare.remove(wherestr)
        .then((res) => {
            ctx.body = {
                code: 0,
                message: 'success'
            };
        })
        .catch((err) => {
            ctx.body = {
                code: 1,
                message: err.message || ''
            };
        });
};

const update = async (ctx) => {
    const {
        id
    } = ctx.request.body;
    const wherestr = {
        _id: id
    };
    const updatestr = ctx.request.body;
    delete updatestr.id;
    await SpeedCompare.update(wherestr, updatestr)
        .then((res) => {
            ctx.body = {
                code: 0,
                message: 'success'
            };
        })
        .catch((err) => {
            ctx.body = {
                code: 1,
                message: err.message || ''
            };
        });
};

module.exports = {
    findAll,
    create,
    destroy,
    update,
};
