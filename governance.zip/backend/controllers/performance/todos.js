const Todo = require('../../models/performance/todo');

const findAll = async (ctx) => {
    // Fetch all Todo's from the database and return as payload
    const todos = await Todo.find({});
    ctx.body = todos;
};

const create = async (ctx) => {
    // Create New Todo from payload sent and save to database
    const newTodo = new Todo(ctx.request.body);
    await newTodo.save();
    ctx.body = {
        code: '0',
        message: '创建成功'
    };
};

const destroy = async (ctx) => {
    // Get id from url parameters and find Todo in database
    const { id } = ctx.request.body;
    const todo = await Todo.findById(id);

    // Delete todo from database and return deleted object as reference
    await todo.remove();
    ctx.body = {
        code: '0',
        message: '创建成功'
    };
};

const update = async (ctx) => {
    // Find Todo based on id, then toggle done on/off
    const { id } = ctx.params;
    const todo = await Todo.findById(id);
    todo.done = !todo.done;

    // Update todo in database
    const updatedTodo = await todo.save();
    ctx.body = updatedTodo;
};

module.exports = {
    findAll,
    create,
    destroy,
    update
};
