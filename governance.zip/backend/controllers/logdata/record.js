const RecordLog = require('../../models/logdata/record');
const utils = require('../utils');

const findAll = async (ctx) => {
    const req = ctx.request.body;
    const {
        pageNo,
        pageSize,
        startTime,
        endTime,
        site,
        platform,
        tags
    } = req;
    let msgRegex;
    if (tags.length) {
        msgRegex = [];
        for (const tag of tags) {
            msgRegex.push({
                msg: {
                    $regex: tag,
                    $options: 'i',
                },
            });
        }
    }
    const sql = {
        pageNo,
        pageSize,
        Model: RecordLog,
        queryParams: {
            date: {
                $gte: startTime,
                $lte: endTime,
            },
            site,
            platform,
            $and: msgRegex,
        },
        showFileds: {
            _id: 1,
            platform: 1,
            route: 1,
            performance: 1,
            ua: 1,
            msg: 1,
            date: 1,
        }
    };
    const res = await utils.pageQuery(sql);
    ctx.body = res;
};

const create = async (ctx) => {

};

const update = async (ctx) => {

};

const destroy = async (ctx) => {

};

module.exports = {
    findAll,
    create,
    update,
    destroy,
};
