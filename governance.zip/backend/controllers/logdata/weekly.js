const dailyLog = require('../../models/logdata/weekly');

const findAll = async (ctx) => {
    const lists = await dailyLog.find({});
    ctx.body = lists;
};

const create = async (ctx) => {

};

const update = async (ctx) => {

};

const destroy = async (ctx) => {

};

module.exports = {
    findAll,
    create,
    update,
    destroy,
};
