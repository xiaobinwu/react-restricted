const pageQuery = async ({
    pageNo = 1,
    pageSize = 10,
    Model,
    queryParams = {},
    showFileds = null,
    sortParams = {
        date: 'desc'
    },
    populate = ''
}) => {
    const start = (pageNo - 1) * pageSize;
    if (!Model) {
        return errorHandle('Model');
    }
    try {
        queryParams = JSON.parse(JSON.stringify(queryParams));
        const [count, list] = await Promise.all([
            Model.count(queryParams),
            Model.find(queryParams, showFileds).skip(start).limit(Number(pageSize)).populate(populate)
                .sort(sortParams)
        ]);
        const pages = Math.round(count / pageSize);
        return {
            code: 0,
            message: 'success',
            entry: { list },
            page: pageNo, // 当前页
            pages, // 总页数
            size: pageSize, // 每页显示数据数
            total: count, // 数据总数
        };
    } catch (e) {
        return errorHandle(String(e));
    }
};

const errorHandle = (msg) => {
    return {
        code: 1,
        message: msg,
        entry: null,
    };
};

module.exports = {
    pageQuery,
    errorHandle,
};
