// const User = require('../models/user');
const Token = require('../controllers/token');

const login = (ctx) => {
    const { username, password } = ctx.request.body;
    if (username === 'admin' && password === 'admin') {
        const token = Token.createToken(username);
        ctx.status = 200;
        ctx.body = {
            code: 0,
            token,
            username
        };
    } else {
        ctx.status = 200;
        ctx.body = {
            code: 1,
            message: '用户名或是密码错误'
        };
    }
};

const info = (ctx) => {
    ctx.status = 200;
    ctx.body = {
        code: 0,
        entry: {
            admin: 'admin'
        }
    };
};

module.exports = {
    login,
    info
};
