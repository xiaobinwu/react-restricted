## What's in the package?

* Routing with koa-router.
* Parsing request with koa-bodyparser.
* CORS middleware with @koa/cors.
* koa-respond for helper functions on the context.
* koa-helmet for important security headers.
* nodemon for development to auto-restart when your files change.
* dotenv for environment variable management.

## Getting Started

install MongoDb

```
mongod --dbpath [table of Contents]
eg: mongod --dbpath E:\front-end-governance\data
```
You can use

```
mongod --dbpath "[table of Contents]" --logpath "[table of Log Contents]" --serviceName "mongodb" --serviceDisplayName "mongodb" --install
eg: mongod --dbpath "E:\front-end-governance\data" --logpath "E:\front-end-governance\data\log\mongodb.log" --serviceName "mongodb" --serviceDisplayName "mongodb" --install
```
and then use

```
net start mongodb
```

Visualization tool: Robo


```
mv .env.sample .env
npm run dev // or yarn dev
```

By default the API server starts on port 3000, http://localhost:3000.

### Prerequisites

* node >= v7.6.0
* *npm run dev* use nodemon

```
npm install -g nodemon
```
