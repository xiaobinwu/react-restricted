/* models/user.js */
const mongoose = require('mongoose');

// Declare Schema
const UserSchema = new mongoose.Schema({
    username: {
        type: String
    },
    password: {
        type: String
    },
    token: {
        type: String
    }
}, {
    timestamps: true
});

// Declare Model to mongoose with Schema
mongoose.model('User', UserSchema);

// Export Model to be used in Node
module.exports = mongoose.model('User');
