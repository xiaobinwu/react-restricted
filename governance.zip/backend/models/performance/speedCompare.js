/* models/speedCompare.js */
/* GB-Zaful网站速度对比列表 */

const mongoose = require('mongoose');

// Declare Schema
const SpeedCompareSchema = new mongoose.Schema({
    platform: String,
    startEventTime: Number,
    endEventTime: Number,
    week: String,
    speedLists: Array
}, {
    timestamps: true
});

// Declare Model to mongoose with Schema


// Export Model to be used in Node
exports.SpeedCompare = mongoose.model('speedCompare', SpeedCompareSchema);
