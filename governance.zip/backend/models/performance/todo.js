/* models/todo.js */
const mongoose = require('mongoose');

// Declare Schema
const TodoSchema = new mongoose.Schema({
    title: {
        type: String
    },
    description: {
        type: String
    }
}, {
    timestamps: true
});

// Declare Model to mongoose with Schema
mongoose.model('Todo', TodoSchema);

// Export Model to be used in Node
module.exports = mongoose.model('Todo');
