/* models/todo.js */
const mongoose = require('mongoose');

// Declare Schema
const WeeklyDataSchema = new mongoose.Schema({
    platform: {
        type: String,
        required: true
    },
    week: {
        type: String,
        required: true
    },
    createTime: {
        type: Date,
        default: Date.now,
        required: true
    },
    weekLists: {
        type: Array
    }
});

// Declare Model to mongoose with Schema
mongoose.model('WeeklyData', WeeklyDataSchema);

// Export Model to be used in Node
module.exports = mongoose.model('WeeklyData');
