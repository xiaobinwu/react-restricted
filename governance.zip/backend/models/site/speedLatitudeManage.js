
/* GB-Zaful网站速度维度管理 */

const mongoose = require('mongoose');


const SpeedLatitudeSchema = new mongoose.Schema({
    cnName: String,
    enName: String,
    typeName: String,
    typeCode: Number,
    mark: String
}, {
    timestamps: true
});

// 定义静态方法
SpeedLatitudeSchema.statics.findByMark = function (mark, cb) {
    return this.find({ mark }, cb);
};

module.exports = mongoose.model('SpeedLatitude', SpeedLatitudeSchema);
