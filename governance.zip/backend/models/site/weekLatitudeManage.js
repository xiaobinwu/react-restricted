/* 周数据维度管理 */

const mongoose = require('mongoose');


const WeekLatitudeSchema = new mongoose.Schema({
    cnName: String,
    enName: String,
    mark: String
}, {
    timestamps: true
});

// 定义静态方法
WeekLatitudeSchema.statics.findByMark = function (mark, cb) {
    return this.find({ mark }, cb);
};

module.exports = mongoose.model('WeekLatitude', WeekLatitudeSchema);
