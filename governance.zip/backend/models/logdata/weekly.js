const mongoose = require('mongoose');

const { Schema } = mongoose;
const { ObjectId } = Schema.Types;

const dailySchema = new mongoose.Schema({
    // 日志类型: 加载速度/报错信息
    cate: {
        type: ObjectId,
    },
    // 站点: gb zf
    site: {
        type: String,
    },
    // 端: pc/m
    plateform: {
        type: String,
    },
});

// 声明 Model
const modelLog = mongoose.model('dailylog', dailySchema, 'dailylog');

// 导出 Model
module.exports = modelLog;
