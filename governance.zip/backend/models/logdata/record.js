const mongoose = require('mongoose');

const { Schema } = mongoose;
const { ObjectId } = Schema.Types;

const RecordSchema = new mongoose.Schema({
    // 日志类型: 加载速度/报错信息
    id: {
        type: ObjectId,
    },
    // 站点: gb zf
    site: {
        type: String,
    },
    // 端: pc/m
    plateform: {
        type: String,
    },
    // 页面路由
    route: {
        type: String,
    },
    // performance 对象
    performance: {
        type: Object,
    },
    // userAgent
    ua: {
        type: String,
    },
    // 错误信息
    msg: {
        type: String,
    },
    // 创建日期
    date: {
        type: Date,
        default: Date.now
    },
});

// 声明 Model
const modelLog = mongoose.model('recordlog', RecordSchema, 'recordlog');

// 导出 Model
module.exports = modelLog;
