const chalk = require('chalk');
const path = require('path');
const fileSave = require('file-save');
const uppercamelcase = require('uppercamelcase');
const files = require('./files.json');

const { log } = console;

const config = {
    dir: process.env.npm_config_dir,
    file: process.env.npm_config_file,
    replace: process.env.npm_config_replace,
    dec: process.env.npm_config_dec
};

const routesFilePath = path.resolve(__dirname, './routes');
const modelsFilePath = path.resolve(__dirname, './models');
const controllersPath = path.resolve(__dirname, './controllers');

log(chalk.blue(`
    <---------------------------------------使用说明--------------------------------------->
    1、只传--dir，不传--file，报错
    2、不传--dir，只传--file，则创建非模块文件，如user相关的控制器、models、路由文件
    3、既传--dir，又传--file，则创建模块文件，如performance相关模块的控制器、models、路由文件
    4、有传--dec，则是文件的描述
    <------------------------------------------------------------------------------------->
`));

log(chalk.blue('开始生成...'));

const fistLetterUpper = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
};

const fistLetterLower = (str) => {
    return str.charAt(0).toLowerCase() + str.slice(1);
};

// 判断文件是否存在于file.json
const fileExistHanle = (fileName) => {
    if (files[fileName]) {
        log(chalk.red(`${fileName}已存在.`));
        process.exit();
    }
};

// 将文件写入file.json键值对
const writeFileHanle = (fileName) => {
    files[fileName] = `./routes/${fileName}.js`;
    fileSave(path.join(__dirname, './files.json'))
        .write(JSON.stringify(files, null, ' '), 'utf8')
        .end('\n');
};

// 获取写入的文件集合
const buildFiles = (fileName) => {
    const description = config.dec || config.file;
    const fileArr = fileName.split('/');
    const prefix = fileArr.length > 1 ? '../../' : '../';
    const name = fistLetterUpper(fileArr[fileArr.length - 1]);

    // 路由模板文件
    const routeContent = `/* ${description} */
const Router = require('koa-router');

const router = new Router();
const Token = require('${prefix}controllers/token');
const Ctrl = require('${prefix}controllers/${fileName}');

router.get('/list', Token.checkToken, Ctrl.findAll);
router.post('/add', Token.checkToken, Ctrl.create);
router.post('/update', Token.checkToken, Ctrl.update);
router.post('/delete', Ctrl.destroy);

module.exports = router.routes();`;
    // model模板文件
    const modelContent = `/* ${description} */
const mongoose = require('mongoose');

// Declare Schema
const ${name}Schema = new mongoose.Schema({
    name: {
        type: String
    },
    title: {
        type: String
    }
}, {
    timestamps: true
});

// Declare Model to mongoose with Schema
mongoose.model('${name}', ${name}Schema);

// Export Model to be used in Node
module.exports = mongoose.model('${name}');`;
    // controller模板文件
    const controllerContent = `/* ${description} */
const ${name} = require('${prefix}models/${fileName}');

const findAll = async (ctx) => {
    // empty
};

const create = async (ctx) => {
    // empty
};

const update = async (ctx) => {
    // empty
};

const destroy = async (ctx) => {
    // empty
};

module.exports = {
    findAll,
    create,
    update,
    destroy,
};`;

    const filesSet = [
        {
            filename: path.join(routesFilePath, `${fileName}.js`), // 路由route
            content: routeContent
        },
        {
            filename: path.join(modelsFilePath, `${fileName}.js`), // model
            content: modelContent
        },
        {
            filename: path.join(controllersPath, `${fileName}.js`), // 控制器controller
            content: controllerContent
        }
    ];
    filesSet.forEach((file, index) => {
        fileSave(file.filename).write(file.content, 'utf8').end('\n');
    });
    log(chalk.green(`${fileName}相关的路由、控制器、model文件生成完毕！`));
};

if (!config.file || config.file === 'true') {
    log(chalk.red('[文件名]必填 - Please enter new file name'));
    process.exit();
}

if (!config.dir || config.dir === 'true') {
    const fileName = fistLetterLower(uppercamelcase(config.file));
    fileExistHanle(fileName);
    writeFileHanle(fileName);
    buildFiles(fileName);
} else {
    const dirName = fistLetterLower(uppercamelcase(config.dir));
    const fileName = fistLetterLower(uppercamelcase(config.file));
    fileExistHanle(`${dirName}/${fileName}`);
    writeFileHanle(`${dirName}/${fileName}`);
    buildFiles(`${dirName}/${fileName}`);
}
