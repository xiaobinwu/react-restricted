# 前端服务系统

------
FrontEnd
> * 安装npm依赖
> * 运行`npm run start`，开启开发环境


Backend
> * 安装mongoDB
> * mongod --dbpath [mongodb数据存储目录]（可以在项目根目录创建一个data目录，执行命令，如：mongod --dbpath E:\front-end-governance\data）
> * 安装npm依赖，以及全局安装nodemon
> * 复制.env.exmple重命名为.env，存放可配置信息
> * 运行`npm run dev`， 开启开发环境

根目录
> * 安装npm依赖
> * 运行`npm run start`,直接运行上两步前后端开发环境的命令

MongoDB默认目录（linux）
> * 数据存储目录 /var/lib/mongodb/
> * 日志文件路径 /var/log/mongodb/mongodb.log
> * 可执行文件路径 /usr/bin/mongo
> * 可执行文件路径 /usr/bin/mongod