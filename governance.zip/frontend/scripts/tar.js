const targz = require('node-tar.gz');
const fs = require('fs');
const path = require('path');
const paths = require('../config/component/paths');
const version = require(paths.appPackageJson).version;

console.log(`创建governance-${version}文件夹...`);

// 复制文件夹 
const copyFolder = (srcDir, tarDir, cb) => {
    fs.readdir(srcDir, (err, files) => {
        let count = 0;
        const checkEnd = () => {
            ++count === files.length && cb && cb();
        }
        if (err) {
            checkEnd();
            return;
        }
        files.forEach((file) => {
            const srcPath = path.join(srcDir, file);
            const tarPath = path.join(tarDir, file);
            fs.stat(srcPath, (err, stats) => {
                if (stats.isDirectory()) {
                    fs.mkdir(tarPath, (err) => {
                        if (err) {
                            console.log(err)
                            return;
                        }
                        copyFolder(srcPath, tarPath, checkEnd);
                    })
                } else {
                    fs.copyFile(srcPath, tarPath, checkEnd);
                }
            });
        });
        //为空时直接回调
        files.length === 0 && cb && cb();
    });
}

// 删除文件夹
const emptyDir = (fold) => {
    const files = fs.readdirSync(fold);
    files.forEach((file) => {
        if (fs.statSync(`${fold}/${file}`).isDirectory()) {
            emptyDir(`${fold}/${file}`);
        } else {
            fs.unlinkSync(`${fold}/${file}`);
        }
    });
}
const rmEmptyDir = (fold) => {
    const files = fs.readdirSync(fold);
    if (files.length > 0) {
        let tempFile = 0;
        files.forEach((fileName) => {
            tempFile++;
            rmEmptyDir(`${fold}/${fileName}`);
        });
        if (tempFile === files.length) {
            fs.rmdirSync(fold);
        }
    } else {
        fs.rmdirSync(fold); 
    }
}


if(fs.existsSync(`governance-${version}`)) {
    emptyDir(`governance-${version}`);
    rmEmptyDir(`governance-${version}`);
}

fs.mkdirSync(`governance-${version}`);

copyFolder(paths.appBuild, `governance-${version}`, () => {
    console.log(`复制${paths.appBuild}至governance-${version}文件夹成功!`);
    console.log(`正在压缩governance-${version}文件夹...`);
    targz().compress(paths.resolveApp(`governance-${version}`), `governance-${version}-assembly.tar.gz`)
    .then(function(){
        console.log(`压缩governance-${version}文件夹成功!`);
        emptyDir(`governance-${version}`);
        rmEmptyDir(`governance-${version}`);
    })
    .catch(function(err){
        console.log('Something is wrong ', err.stack);
    });
})