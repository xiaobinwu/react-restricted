const data = {
    "page*list": {
        "code": '0',
        "entry": {
            1: { cnName: "全站", enName: "sitePromotion" },
            2: { cnName: "全站-排推广", enName: "siteUnPromotion" },
            3: { cnName: "首页", enName: "indexPromotion" },
            4: { cnName: "首页-排推广", enName: "indexUnPromotion" },
            5: { cnName: "商祥页", enName: "detailPromotion" },
            6: { cnName: "商祥页-排推广", enName: "detailUnPromotion"  },
            7: { cnName: "列表页", enName: "listPromotion" },
            8: { cnName: "列表页-排推广", enName: "listUnPromotion" },
            9: { cnName: "活动页", enName: "activityPromotion"  },
            10: { cnName: "活动页-排推广", enName: "activityUnPromotion" },
            11: { cnName: "购物车", enName: "cartPromotion" }
        }
    },
    "speedCompare*list": {
        "code": '0',
        "entry": {
            "list": [{
                "id": 1,
                "platform": "PC",
                startEventTime: 1542326400000,
                endEventTime: 1542931200000,
                "createTime": "2018-11-23 16:17:23",
                "week": "w37",
                "speedLists": [{
                    "pageType": 1,
                    "zafulValue": 4.25,
                    "zafulDec": "zaful描述424",
                    "gbValue": 5.55,
                    "gbDec": ""
                }, {
                    "pageType": 2,
                    "zafulValue": 2.44,
                    "zafulDec": "",
                    "gbValue": 1.75,
                    "gbDec": ""
                }, {
                    "pageType": 3,
                    "zafulValue": 33.44,
                    "zafulDec": "",
                    "gbValue": 65.75,
                    "gbDec": ""
                }, {
                    "pageType": 4,
                    "zafulValue": 4.44,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 5,
                    "zafulValue": 4.644,
                    "zafulDec": "",
                    "gbValue": 6.575,
                    "gbDec": ""
                }, {
                    "pageType": 6,
                    "zafulValue": 4.144,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 7,
                    "zafulValue": 5.44,
                    "zafulDec": "",
                    "gbValue": 6.05,
                    "gbDec": ""
                }, {
                    "pageType": 8,
                    "zafulValue": 4.44,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 9,
                    "zafulValue": 4.4784,
                    "zafulDec": "",
                    "gbValue": 6.78765,
                    "gbDec": ""
                }, {
                    "pageType": 10,
                    "zafulValue": 4.44,
                    "zafulDec": "zaful7描述",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 11,
                    "zafulValue": 4.44,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": "gb788描述"
                }]
            }, {
                "id": 2,
                "platform": "PC",
                startEventTime: 1541721600000,
                endEventTime: 1542326400000,
                "createTime": "2018-11-23 16:17:23",
                "week": "w38",
                "speedLists": [{
                    "pageType": 1,
                    "zafulValue": 4.25,
                    "zafulDec": "zaful描述424",
                    "gbValue": 5.55,
                    "gbDec": ""
                }, {
                    "pageType": 2,
                    "zafulValue": 2.44,
                    "zafulDec": "",
                    "gbValue": 1.75,
                    "gbDec": ""
                }, {
                    "pageType": 3,
                    "zafulValue": 33.44,
                    "zafulDec": "",
                    "gbValue": 65.75,
                    "gbDec": ""
                }, {
                    "pageType": 4,
                    "zafulValue": 4.44,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 5,
                    "zafulValue": 4.644,
                    "zafulDec": "",
                    "gbValue": 6.575,
                    "gbDec": ""
                }, {
                    "pageType": 6,
                    "zafulValue": 4.144,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 7,
                    "zafulValue": 5.44,
                    "zafulDec": "",
                    "gbValue": 6.05,
                    "gbDec": ""
                }, {
                    "pageType": 8,
                    "zafulValue": 4.44,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 9,
                    "zafulValue": 4.4784,
                    "zafulDec": "",
                    "gbValue": 6.78765,
                    "gbDec": ""
                }, {
                    "pageType": 10,
                    "zafulValue": 4.44,
                    "zafulDec": "zaful7描述",
                    "gbValue": 6.75,
                    "gbDec": ""
                }, {
                    "pageType": 11,
                    "zafulValue": 4.44,
                    "zafulDec": "",
                    "gbValue": 6.75,
                    "gbDec": "gb788描述"
                }]
            }],
            "page": 1,
            "pages": 1551,
            "size": 20,
            "total": 31015
        }
    }
};

module.exports = data;