const data = {
    "weeklyPage*list": {
        "code": 0,
        "entry": {
            1: { cnName: "全站", enName: "sitePromotion" },
            2: { cnName: "首页", enName: "indexPromotion" },
            3: { cnName: "分类", enName: "categoryPromotion" },
            4: { cnName: "商祥", enName: "detailPromotion" },
            5: { cnName: "品牌页", enName: "brandPromotion" },
            6: { cnName: "活动", enName: "activityPromotion"  },
            7: { cnName: "营销页面", enName: "marketingPromotion"  },
            8: { cnName: "注册登录", enName: "loginPromotion"  },
            9: { cnName: "个人中心", enName: "userPromotion"  },
            10: { cnName: "购物车", enName: "cartPromotion"  },
            11: { cnName: "确认订单", enName: "orderPromotion"  },
            11: { cnName: "支付平台", enName: "payPromotion"  }
        }
    },
    "weeklyData*list": {
        "code": 0,
        "entry": {
            "list": [{
                "id": 1,
                "platform": "PC",
                "createTime": 1542931200000,
                "week": "w37",
                "weekLists": [{
                    "pageType": 1,
                    "promotionValue": 4.25,
                    "promotionDec": "推广描述描述424",
                    "unPromotionValue": 5.55,
                    "unPromotionDec": ""
                }, {
                    "pageType": 2,
                    "promotionValue": 2.44,
                    "promotionDec": "",
                    "unPromotionValue": 1.75,
                    "unPromotionDec": ""
                }, {
                    "pageType": 3,
                    "promotionValue": 33.44,
                    "promotionDec": "",
                    "unPromotionValue": 65.75,
                    "unPromotionDec": ""
                }, {
                    "pageType": 4,
                    "promotionValue": 4.44,
                    "promotionDec": "",
                    "unPromotionValue": 6.75,
                    "unPromotionDec": ""
                }, {
                    "pageType": 5,
                    "promotionValue": 4.644,
                    "promotionDec": "",
                    "unPromotionValue": 6.575,
                    "unPromotionDec": ""
                }, {
                    "pageType": 6,
                    "promotionValue": 4.144,
                    "promotionDec": "",
                    "unPromotionValue": 6.75,
                    "unPromotionDec": ""
                }, {
                    "pageType": 7,
                    "promotionValue": 5.44,
                    "promotionDec": "",
                    "unPromotionValue": 6.05,
                    "unPromotionDec": ""
                }, {
                    "pageType": 8,
                    "promotionValue": 4.44,
                    "promotionDec": "",
                    "unPromotionValue": 6.75,
                    "unPromotionDec": ""
                }, {
                    "pageType": 9,
                    "promotionValue": 4.4784,
                    "promotionDec": "",
                    "unPromotionValue": 6.78765,
                    "unPromotionDec": ""
                }, {
                    "pageType": 10,
                    "promotionValue": 4.44,
                    "promotionDec": "推广描述7描述",
                    "unPromotionValue": 6.75,
                    "unPromotionDec": ""
                }, {
                    "pageType": 11,
                    "promotionValue": 4.44,
                    "promotionDec": "",
                    "unPromotionValue": 6.75,
                    "unPromotionDec": "非推广描述788描述"
                }]
            }],
            "page": 1,
            "pages": 1551,
            "size": 20,
            "total": 31015
        }
    }
};

module.exports = data;