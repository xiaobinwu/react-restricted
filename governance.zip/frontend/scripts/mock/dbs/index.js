const speedCompare = require('./speedCompare');
const weeklyData = require('./weeklyData');

const data = {
    ...speedCompare,
    ...weeklyData
};

module.exports = data;