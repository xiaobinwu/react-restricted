import React, { Component } from 'react';
// import CSSModules from 'react-css-modules';
import { BrowserRouter } from 'react-router-dom';
import logo from 'src/logo.png';
import { Layout, Icon, Spin, BackTop } from 'antd';
import routes from 'route/route'; // 后面由服务端下发
import SiderMenu from 'component/siderMenu';
import HeaderMenu from 'component/headerMenu';
import BreadGuide from 'component/breadGuide';
import AidNav from 'component/aidNav';
import ViewSet from 'component/viewSet';
import siteConfig from 'src/config/siteConfig.js';
import styles from './index.module.css';

const {
    Header, Sider, Content, Footer
} = Layout;

class BaseLayout extends Component {
    constructor(props) {
        super(props);
        this.state = {
            collapsed: false,
            loading: false
        };
    }
    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed,
        });
    }
    render() {
        const { collapsed, loading } = this.state;
        const { location } = this.props;
        return (
            <Spin spinning={loading} size="large" wrapperClassName={styles.spin}>
                <BrowserRouter>
                    <Layout>
                        <Sider
                            trigger={null}
                            collapsible
                            collapsed={collapsed}
                            width="256"
                        >
                            <div className={styles.logoContainer}>
                                <div className={styles.logo}>
                                    <img src={logo} alt="logo" />
                                </div>
                                <h1>{siteConfig.title}</h1>
                            </div>

                            <SiderMenu location={location} collapsed={collapsed} navData={routes} />

                        </Sider>
                        <Layout>
                            <Header className={styles.header}>
                                <Icon
                                    className={styles.trigger}
                                    type={collapsed ? 'menu-unfold' : 'menu-fold'}
                                    onClick={this.toggle}
                                />

                                <HeaderMenu location={location} navData={routes} />

                                <AidNav />
                            </Header>
                            <Content className={styles.content}>
                                <BreadGuide />
                                <div className={styles.main}>
                                    <ViewSet navData={routes} />
                                </div>
                            </Content>
                            <Footer className={styles.footer}>
                                环球易购电子项目部 前端组
                            </Footer>
                            <BackTop>
                                <Icon type="to-top" theme="outlined" />
                            </BackTop>
                        </Layout>
                    </Layout>
                </BrowserRouter>
            </Spin>
        );
    }
}

export default BaseLayout;
