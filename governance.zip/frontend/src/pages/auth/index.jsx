import React, { Component } from 'react';
import store from 'rRedux/store';
import logo from 'src/logo.png';
// import CSSModules from 'react-css-modules';
import { Form, Icon, Input, Button, Checkbox } from 'antd';
import { userService } from 'service';

import particles from './particles';
import styles from './index.module.css';
// console.log(styles);

const FormItem = Form.Item;

class Auth extends Component {

    state = {
        loading: false
    }

    handleSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    loading: true
                });
                const { username, password } = values;
                const data = await userService.login({ username, password });
                if (data.code === 0) {
                    sessionStorage.setItem('token', data.token);
                    store.dispatch({
                        type: 'SET_LOGGED_USER',
                        logged: true,
                        username
                    });
                    this.props.history.replace('/');
                }
            }
        });
    }

    componentDidMount() {
        // 引入particles
        import('js/particles').then((particlesJS) => {
            particlesJS.default('particles-js', particles);
        });
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const { loading } = this.state;
        // debugger;
        return (
            <div>
                <div id='particles-js' className={styles['particles-js']}></div>
                <div className={styles.container}>
                    <div className={styles.logo}>
                        <img alt="logo" className={styles.img} src={logo} />
                    </div>
                    <Form onSubmit={this.handleSubmit}>
                        <FormItem>
                            { getFieldDecorator('username', {
                                rules: [{ required: true, message: '请输入你的用户名!' }]
                            })(<Input className={styles.input} prefix={<Icon type="user" className={styles.icon} />} size="large" placeholder="Username" />)}

                        </FormItem>
                        <FormItem>
                            { getFieldDecorator('password', {
                                rules: [{ required: true, message: '请输入密码!' }]
                            })(<Input className={styles.input} prefix={<Icon type="lock" className={styles.icon} />} size="large" type="password" placeholder="Password" />)}
                        </FormItem>
                        <FormItem>
                            { getFieldDecorator('remember', {
                                valuePropName: 'checked',
                                initialValue: true,
                            })(<Checkbox className={styles.check}>记住我</Checkbox>)}
                            <a className={styles.forgot} href="">忘记密码？</a>
                            <Button type="primary" htmlType="submit" className={styles.button} size="large" loading={loading}>
                                登录
                            </Button>
                        </FormItem>
                    </Form>
                </div>
            </div>
        );
    }
}

const WrappedAuthForm = Form.create()(Auth);

export default WrappedAuthForm;
