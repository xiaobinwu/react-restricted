import React from 'react';
import Loadable from 'react-loadable';
import Loading from './loading';

const generateLoadable = (component, props) => Loadable({
    loader: component,
    loading: () => <Loading {...props}/>,
    delay: 20000
});

export default {
    // 性能管理
    // PerformanceReport: generateLoadable(() => import('view/performanceManagement/performanceReport')), // demo测试
    WeeklyData: generateLoadable(() => import('view/performanceManagement/weeklyData')), // 加载速度-GA周数据
    SpeedCompare: generateLoadable(() => import('view/performanceManagement/speedCompare')), // GB-Zaful网站速度对比列表
    Log: generateLoadable(() => import('view/performanceManagement/log')), // 日志
    SpeedLatitudeManage: generateLoadable(() => import('view/performanceManagement/speedLatitudeManage')), // 速度维度管理
    WeekLatitudeManage: generateLoadable(() => import('view/performanceManagement/weekLatitudeManage')), // 周数据维度管理
    elogAnalysis: generateLoadable(() => import('view/performanceManagement/elogAnalysis')), // elog 速度分析工具
};
