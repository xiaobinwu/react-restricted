import React from 'react';
import { Button, Table, Modal, message, Input } from 'antd';
import { performanceService } from 'service';
import styles from './index.module.css';

class PerformanceReport extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: false,
            visible: false,
            textAreaVal: '',
            inputVal: ''
        };
    }
    // 请求列表数据
    async getTodoList() {
        this.setState({
            loading: true,
        });
        const res = await performanceService.getTodoList();
        this.setState({
            data: res,
            loading: false
        });
    }
    // 新增
    addTodoList() {
        const description = this.state.textAreaVal;
        const title = this.state.inputVal;
        Modal.confirm({
            title: '确认提示',
            content: `（加入Todo）确认是否需要操作 ${title}`,
            okText: '确定',
            cancelText: '取消',
            onOk: async () => {
                this.setState({
                    visible: false,
                    textAreaVal: '',
                    inputVal: ''
                });
                const res = await performanceService.addTodoList({
                    description,
                    title
                });
                if (res.code === '0') {
                    message.success(res.message);
                    this.getTodoList();
                }
            }
        });
    }
    // 删除条目
    deleteTodoList(record) {
        Modal.confirm({
            title: '确认提示',
            content: `确认是否需要操作 ${record.title}`,
            okText: '确认',
            cancelText: '取消',
            onOk: async () => {
                const res = await performanceService.deleteTodoList({
                    id: record._id
                });
                if (res.code === '0') {
                    message.success(res.message);
                    this.getTodoList();
                }
            }
        });
    }
    changeTextAreaVal(e) {
        const val = e.target.value;
        this.setState({
            textAreaVal: val
        });
    }
    changeInputVal(e) {
        const val = e.target.value;
        this.setState({
            inputVal: val
        });
    }
    componentDidMount() {
        this.getTodoList.bind(this)();
    }
    render() {
        const { TextArea } = Input;
        const {
            data,
            loading,
        } = this.state;
        const columns = [{
            title: '#',
            key: '_id',
            dataIndex: '_id',
            align: 'center'
        }, {
            title: '标题',
            dataIndex: 'title',
            key: 'title',
        }, {
            title: '描述',
            dataIndex: 'description',
            key: 'description',
        }, {
            title: '操作',
            key: 'action',
            align: 'center',
            width: 200,
            render: (text, record) => (
                <Button type="primary" onClick={this.deleteTodoList.bind(this, record)}>移除</Button>
            )
        }];

        return <div>
            <Button type="primary" icon="plus" size="small" onClick={() => {
                this.setState({
                    visible: true,
                });
            }} >增加Todo</Button>
            <div className={styles.tablewarp}>
                <Table columns={columns} dataSource={data} loading={loading} locale={ { emptyText: '暂无数据' } } rowKey="_id" />
            </div>
            <Modal
                visible={this.state.visible}
                onCancel={() => {
                    this.setState({
                        visible: false,
                    });
                }}
                footer={[
                    <Button type="primary" key="submit" onClick={this.addTodoList.bind(this)}>保存Todo</Button>
                ]}
            >
                <p style={{
                    textAlign: 'center'
                }} className="system-backlist-modal-title">增加Todo</p>
                <p>Todo标题</p>
                <Input
                    placeholder="请输入标题"
                    value={this.state.inputVal}
                    onChange={this.changeInputVal.bind(this)}
                />
                <p>Todo描述</p>
                <TextArea
                    placeholder="请输入描述"
                    value={this.state.textAreaVal}
                    onChange={this.changeTextAreaVal.bind(this)}
                />
            </Modal>
        </div>;
    }
}

export default PerformanceReport;
