import React, { Component } from 'react';
import { Drawer } from 'antd';
import Line from './charts/line';

class SpeedDrawer extends Component {
    onClose = () => {
        const { onClose } = this.props;
        onClose && onClose(); // eslint-disable-line
    }
    render() {
        const {
            viewVisible,
            speedCompareList,
            pageList,
            selectedHandleRowKeys
        } = this.props;
        const xAxis = [];
        const series1 = {};
        const series2 = {};
        const series = [];
        const legends = [];
        if (JSON.stringify(pageList) !== '{}' && speedCompareList.length > 0) {
            Object.keys(pageList).forEach((item, index) => {
                if (pageList[item]) {
                    const pKey = pageList[item].cnName;
                    series1[`${pKey}（GB）`] = [];
                    series2[`${pKey}（Zaful）`] = [];
                }
            });
            speedCompareList.filter((item, index) => {
                return selectedHandleRowKeys.includes(String(item.id));
            }).forEach((it, inx) => {
                xAxis.push(it.week);
                const { speedLists } = it;
                if (speedLists.length > 0) {
                    speedLists.forEach((sit, idx) => {
                        if (pageList[sit.pageType]) {
                            const key = pageList[sit.pageType].cnName;
                            series1[`${key}（GB）`].push(sit.gbValue);
                            series2[`${key}（Zaful）`].push(sit.zafulValue);
                        }
                    });
                }
            });
            Object.keys(series1).forEach((item) => {
                series.push({
                    name: item,
                    type: 'line',
                    smooth: true,
                    data: series1[item]
                });
                legends.push(item);
            });
            Object.keys(series2).forEach((item) => {
                series.push({
                    name: item,
                    type: 'line',
                    smooth: true,
                    data: series2[item]
                });
                legends.push(item);
            });
        }
        return (
            <Drawer
                width="100%"
                height="100%"
                placement="top"
                maskClosable={false}
                title='速度对比趋势图'
                onClose={this.onClose}
                visible={viewVisible}
            >
                <Line series={series} legends={legends} xAxis={xAxis} />
            </Drawer>
        );
    }
}

export default SpeedDrawer;
