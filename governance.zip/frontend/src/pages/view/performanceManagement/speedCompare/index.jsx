import React, { Component } from 'react';
import { Table, Tooltip, Button, Form, Select, Row, Col, Input, Modal, DatePicker, message } from 'antd';
import fire from 'img/fire.svg';
import { performanceService, siteService } from 'service';
import withFormModal from 'component/hoc/withFormModal';
import moment from 'moment';
import SpeedDrawer from './speedDrawer';
import SpeedCompareForm from './speedCompareForm';
import styles from './index.module.css';

const SpeedCompareFormModal = withFormModal(SpeedCompareForm);

const FormItem = Form.Item;
const { Option } = Select;
const { RangePicker } = DatePicker;
const { confirm } = Modal;

let defaultFormOptions = {
    id: '',
    week: '',
    rangeTime: [null, null],
    platform: '',
    zafulDecs: [''],
    zafulValues: [''],
    gbDecs: [''],
    gbValues: [''],
    pageTypes: [''],
    keys: [0],
    isEdit: false
};

const type = {
    gb: 'GB',
    zaful: 'Zaful'
};
class SpeedCompare extends Component {
    constructor(props) {
        super(props);
        this.state = {
            pageList: {},
            speedCompareList: [],
            data: [],
            column: [],
            loading: false,
            pagination: {
                pageNum: 1,
                pageSize: 20,
                totalCount: 0
            },
            selectedHandleRowKeys: [],
            selectedRowKeys: [],
            viewVisible: false,
            confirmLoading: false,
            visible: false,
            speedCompareForm: JSON.parse(JSON.stringify(defaultFormOptions)),
        };
    }
    componentDidMount() {
        this.getPageList();
    }
    // 获取测速页面列表
    getPageList = async () => {
        const { code, entry } = await siteService.getSpeedLatitude();
        const renderContent = (text, record, index) => {
            const obj = {
                children: text,
                props: {},
            };
            if (index % 2 === 0) {
                obj.props.rowSpan = 2;
            }
            if (index % 2 === 1) {
                obj.props.rowSpan = 0;
            }
            return obj;
        };
        if (code === 0) {
            let column = [];
            const keys = [];
            const pageTypes = [];
            const zafulDecs = [];
            const zafulValues = [];
            const gbDecs = [];
            const gbValues = [];
            Object.keys(entry).forEach((item, index) => {
                keys.push(index);
                pageTypes.push(item);
                zafulDecs.push('');
                zafulValues.push('');
                gbDecs.push('');
                gbValues.push('');
                column.push({
                    title: entry[item].cnName,
                    key: entry[item].enName,
                    dataIndex: entry[item].enName,
                    render: (text, record) => {
                        return (<div>
                            <span style={{ marginRight: 10 }}>{text}</span>
                            {
                                record[`${entry[item].enName}Dec`] ? <Tooltip title={<div>描述：{record[`${entry[item].enName}Dec`]}</div>}>
                                    <img src={fire} style={{ width: '15px', height: 'auto' }} />
                                </Tooltip> : null
                            }
                        </div>);
                    }
                });
            });

            column = [
                {
                    title: '周',
                    key: 'week',
                    dataIndex: 'week',
                    render: (text, record, index) => {
                        return renderContent(text, record, index);
                    }
                },
                {
                    title: '时间范围',
                    key: 'rangeTime',
                    dataIndex: 'rangeTime',
                    render: (text, record, index) => {
                        return renderContent(`${moment(record.startEventTime).format('YYYY-MM-DD')}至${moment(record.endEventTime).format('YYYY-MM-DD')}`, record, index);
                    }
                },
                {
                    title: '站点',
                    key: 'site',
                    dataIndex: 'site',
                    render: (text, record, index) => {
                        return `${text}(${record.platform})`;
                    }
                }
            ].concat(column).concat({
                title: '操作',
                fixed: 'right',
                render: (text, record, index) => {
                    return renderContent(<React.Fragment>
                        <Button type="primary" size="small" style={{ marginRight: 10 }} onClick={this.setSpeed.bind(this, record)}>编辑</Button>
                        <Button type="primary" size="small" onClick={this.delete.bind(this, record)}>删除</Button>
                    </React.Fragment>, record, index);
                }
            });

            if (keys.length) {
                defaultFormOptions = {
                    ...defaultFormOptions,
                    ...{
                        keys,
                        pageTypes,
                        zafulDecs,
                        zafulValues,
                        gbDecs,
                        gbValues
                    }
                };
            }

            this.setState({
                pageList: entry,
                speedCompareForm: defaultFormOptions,
                column,
            }, () => {
                this.getSpeedCompareList();
            });
        }
    }
    // 编辑，新增Modal弹出
    setSpeed = (record) => {
        let speedCompareFormObj = {};
        if (record) {
            const { speedCompareList } = this.state;
            const filterData = speedCompareList.find((item) => {
                return item.id === record.id;
            });
            const pageTypes = [];
            const gbValues = [];
            const gbDecs = [];
            const zafulValues = [];
            const zafulDecs = [];
            if (filterData.speedLists.length > 0) {
                filterData.speedLists.forEach((item) => {
                    pageTypes.push(String(item.pageType));
                    gbValues.push(item.gbValue);
                    gbDecs.push(item.gbDec);
                    zafulValues.push(item.zafulValue);
                    zafulDecs.push(item.zafulDec);
                });
            }
            speedCompareFormObj = {
                id: record.id,
                rangeTime: [moment(record.startEventTime), moment(record.endEventTime)],
                platform: record.platform,
                week: record.week,
                keys: Array.from(new Array(filterData.speedLists.length), (val, index) => index),
                pageTypes,
                gbValues,
                gbDecs,
                zafulValues,
                zafulDecs,
                isEdit: true
            };
        } else {
            speedCompareFormObj = JSON.parse(JSON.stringify(defaultFormOptions));
        }
        this.setState({
            speedCompareForm: speedCompareFormObj,
            visible: true
        });
    }
    // 保存
    setSpeedSend = () => {
        this.speedFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    confirmLoading: true
                });
                let params = { ...this.speedFormRef.props.form.getFieldsValue() };
                if (params.rangeTime.length > 0 && params.rangeTime[0] && params.rangeTime[1]) {
                    params.startEventTime = params.rangeTime[0].valueOf();
                    params.endEventTime = params.rangeTime[1].valueOf();
                }
                params.speedLists = [];
                params.keys.forEach((item, index) => {
                    params.speedLists.push({
                        pageType: params.pageTypes[item] || '',
                        zafulValue: params.zafulValues[item] || 0,
                        zafulDec: params.zafulDecs[item] || '',
                        gbValue: params.gbValues[item] || 0,
                        gbDec: params.gbDecs[item] || ''
                    });
                });
                delete params.rangeTime;
                delete params.pageTypes;
                delete params.zafulValues;
                delete params.zafulDecs;
                delete params.gbValues;
                delete params.gbDecs;
                delete params.keys;
                if (this.state.speedCompareForm.id) {
                    params = { ...params, ...{ id: this.state.speedCompareForm.id } };
                }
                const res = await performanceService.setSpeedSend(params);
                if (res.code === 0) {
                    this.setState({
                        confirmLoading: false,
                        visible: false
                    }, () => {
                        message.success('保存成功');
                        this.getSpeedCompareList();
                        this.speedFormRef.props.form.resetFields();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        confirmLoading: false
                    });
                }
            }
        });
    }
    // 删除
    delete = ({ id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该条数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await performanceService.deleteSpeed({ id });
                    if (res.code === 0) {
                        message.success('删除成功');
                        that.getSpeedCompareList();
                    }
                })();
            }
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNum || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNum: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getSpeedCompareList();
            });
        }
    }
    // 获取列表数据
    getSpeedCompareList = (e) => {
        e && e.preventDefault(); // eslint-disable-line
        this.props.form.validateFields(async (err, values) => {
            const { pageList, pagination } = this.state;
            this.setState({
                loading: true
            });
            const params = {
                ...pagination,
                ...this.props.form.getFieldsValue()
            };
            if (params.rangeTime && params.rangeTime.length > 0) {
                const { rangeTime } = params;
                params.startEventTime = rangeTime[0].valueOf();
                params.endEventTime = rangeTime[1].valueOf();
            }
            delete params.rangeTime;
            delete params.totalCount;
            const { entry, code } = await performanceService.getSpeedCompareList(params);
            let data = [];
            const { list } = entry;
            if (code === 0) {
                if (list && list.length > 0) {
                    list.forEach((item, index) => {
                        const dataItem1 = {};
                        const dataItem2 = {};
                        const { speedLists } = item;
                        if (speedLists.length > 0) {
                            speedLists.forEach((it, idx) => {
                                if (JSON.stringify(pageList) !== '{}' && pageList[it.pageType]) {
                                    const key = pageList[it.pageType].enName;
                                    dataItem1[key] = it.gbValue;
                                    dataItem1[`${key}Dec`] = it.gbDec;
                                    dataItem2[key] = it.zafulValue;
                                    dataItem2[`${key}Dec`] = it.zafulDec;
                                }
                            });
                        }
                        const baseSetting = {
                            id: item.id,
                            platform: item.platform,
                            startEventTime: item.startEventTime,
                            endEventTime: item.endEventTime,
                            createTime: item.createTime,
                            week: item.week
                        };
                        data = data.concat([
                            {
                                ...baseSetting,
                                ...dataItem1,
                                ...{ site: type.gb, sId: `${type.gb}-${item.id}` }
                            },
                            {
                                ...baseSetting,
                                ...dataItem2,
                                ...{ site: type.zaful, sId: `${type.zaful}-${item.id}` }
                            }
                        ]);
                    });
                }
                this.setState({
                    speedCompareList: list,
                    data,
                    pagination: { ...pagination, ...{ totalCount: entry.total } },
                    loading: false
                });
            }
        });
    }
    // 打开速度对比趋势图的Drawer
    openDrawer = () => {
        const { selectedRowKeys } = this.state;
        const selectedHandleRowKeys = [];
        selectedRowKeys.forEach((item) => {
            const itemArr = item.split('-');
            if (itemArr[0] === type.gb && selectedHandleRowKeys.indexOf(itemArr[1]) === -1) {
                selectedHandleRowKeys.push(itemArr[1]);
            }
        });
        if (selectedHandleRowKeys.length === 0) {
            return message.warning('请选择记录');
        }
        return this.setState({
            viewVisible: true,
            selectedHandleRowKeys
        });
    }
    // table 可选择
    onSelectChange = (selectedRowKeys) => {
        this.setState({ selectedRowKeys });
    }
    // 抽屉回调
    onDrawerClose = () => {
        this.setState({
            viewVisible: false
        });
    }
    // 获取ref
    getSpeedFormRef = (ref) => {
        this.speedFormRef = ref;
    }
    // 关闭Modal
    handleCancel = () => {
        if (this.speedFormRef) {
            this.speedFormRef.props.form.resetFields();
        }
        this.setState({
            visible: false
        });
    }
    render() {
        const {
            column,
            data,
            loading,
            pagination,
            selectedRowKeys,
            viewVisible,
            selectedHandleRowKeys,
            speedCompareList,
            pageList,
            confirmLoading,
            visible,
            speedCompareForm
        } = this.state;
        const pageControl = {
            current: pagination.pageNum,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            total: pagination.totalCount
        };
        const rowSelection = {
            fixed: true,
            selectedRowKeys,
            onChange: this.onSelectChange
        };
        const { getFieldDecorator } = this.props.form;
        return (
            <div className={styles.speedCompareTable}>
                <Form onSubmit={this.getSpeedCompareList} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('platform', {
                                    initialValue: 'PC'
                                })(<Select>
                                    <Option value="PC">PC端</Option>
                                    <Option value="M">M端</Option>
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('week')(<Input placeholder="请填写周"/>)}
                            </FormItem>
                        </Col>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeTime')(<RangePicker
                                    format='YYYY/MM/DD'
                                    placeholder={['开始时间', '结束时间']}
                                />)}
                            </FormItem>
                        </Col>
                        <Col span={6}>
                            <FormItem style={{ textAlign: 'center' }}>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: 10 }}>查询</Button>
                                <Button type="primary" onClick={this.setSpeed.bind(this, null)} style={{ marginRight: 10 }}>新增</Button>
                                <Button type="primary" onClick={this.openDrawer.bind(this)}>速度对比趋势图</Button>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <SpeedDrawer viewVisible={viewVisible} onClose={this.onDrawerClose} selectedHandleRowKeys={selectedHandleRowKeys} speedCompareList={speedCompareList} pageList={pageList}/>
                <Table
                    rowKey="sId"
                    loading={loading}
                    columns={column}
                    dataSource={data}
                    bordered
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    rowSelection={rowSelection}
                    scroll={{ x: 1700 }}
                    title={() => <div style={{ textAlign: 'center' }}>GB与Zaful网页加载速度对比列表(单位/s)</div>}
                />
                <SpeedCompareFormModal
                    width={1100}
                    maskClosable={false}
                    injectForm={speedCompareForm}
                    getRef={this.getSpeedFormRef}
                    title="速度对比数据录入"
                    visible={visible}
                    onOk={this.setSpeedSend}
                    onCancel={this.handleCancel}
                    footer={[
                        <Button key="submit" type="primary" loading={confirmLoading} onClick={this.setSpeedSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        pageList
                    }}
                />
            </div>
        );
    }
}

export default Form.create()(SpeedCompare);
