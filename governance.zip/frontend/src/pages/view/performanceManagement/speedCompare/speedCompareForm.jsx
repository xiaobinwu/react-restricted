import React, { Component } from 'react';
import { Row, Col, Form, Input, DatePicker, Select, InputNumber, Icon, Button } from 'antd';

const { RangePicker } = DatePicker;
const { Option } = Select;
const FormItem = Form.Item;

let uuid = 15; // 定义一个相对来说比较大的数字,Todo
class SpeedCompareForm extends Component {
    // 添加
    add = () => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        const nextKeys = keys.concat(uuid);
        uuid++; // eslint-disable-line
        form.setFieldsValue({
            keys: nextKeys
        });
    }
    // 删除
    remove = (k) => {
        const { form } = this.props;
        const keys = form.getFieldValue('keys');
        if (keys.length === 1) {
            return;
        }
        form.setFieldsValue({
            keys: keys.filter(key => key !== k)
        });
    }
    render() {
        const {
            form,
            injectForm,
            pageList
        } = this.props;
        const { getFieldDecorator, getFieldValue } = form;
        const formItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 4 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 20 },
            }
        };
        const lineFormItemLayout = {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 3 },
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 21 },
            }
        };
        getFieldDecorator('keys', { initialValue: injectForm.keys });
        const keys = getFieldValue('keys');
        const formItem = keys.map((k, index) => {
            return (
                <React.Fragment key={k}>
                    <Col span={7}>
                        <FormItem {...formItemLayout}>
                            {getFieldDecorator(`pageTypes[${k}]`, {
                                initialValue: injectForm.pageTypes[k]
                            })(<Select showSearch optionFilterProp="children" filterOption={this.filterOption}>
                                {
                                    JSON.stringify(pageList) !== '{}' && Object.keys(pageList).map((item, idx) => {
                                        return (<Option key={item}>{pageList[item].cnName}</Option>);
                                    })
                                }
                            </Select>)}
                        </FormItem>
                    </Col>
                    <Col span={7}>
                        <Row>
                            <Col span={8}>
                                <FormItem {...formItemLayout}>
                                    {getFieldDecorator(`gbValues[${k}]`, {
                                        initialValue: injectForm.gbValues[k]
                                    })(<InputNumber />)}
                                </FormItem>
                            </Col>
                            <Col span={16}>
                                <FormItem {...formItemLayout}>
                                    {getFieldDecorator(`gbDecs[${k}]`, {
                                        initialValue: injectForm.gbDecs[k]
                                    })(<Input placeholder="请填写描述" />)}
                                </FormItem>
                            </Col>
                        </Row>
                    </Col>
                    <Col span={7}>
                        <Row>
                            <Col span={8}>
                                <FormItem {...formItemLayout}>
                                    {getFieldDecorator(`zafulValues[${k}]`, {
                                        initialValue: injectForm.zafulValues[k]
                                    })(<InputNumber />)}
                                </FormItem>
                            </Col>
                            <Col span={16}>
                                <FormItem {...formItemLayout}>
                                    {getFieldDecorator(`zafulDecs[${k}]`, {
                                        initialValue: injectForm.zafulDecs[k]
                                    })(<Input placeholder="请填写描述" />)}
                                </FormItem>
                            </Col>
                        </Row>
                    </Col>
                    <Col span={3} style={{ textAlign: 'right' }}>
                        {/* onClick={() => this.add()} 必须这样写，不然会报错, 存在立即执行的方法，循环触发更新 https://github.com/ckinmind/ReactCollect/issues/99 */}
                        {
                            (keys.indexOf(k) === keys.length - 1) ? <Button type="primary" style={{ marginRight: '5px' }} onClick={() => this.add()}><Icon type="plus" /></Button> : null
                        }
                        {
                            keys.length > 1 ? <Button type="primary" onClick={() => this.remove(k)}><Icon type="minus" /></Button> : null
                        }
                    </Col>
                </React.Fragment>
            );
        });
        return (
            <Form>
                <Row>
                    <Col span={12}>
                        <FormItem label="端" {...formItemLayout}>
                            {getFieldDecorator('platform', {
                                initialValue: injectForm.platform,
                                rules: [{
                                    required: true, message: '端不为空',
                                }],
                            })(<Select>
                                <Option value="PC">PC端</Option>
                                <Option value="M">M端</Option>
                            </Select>)}
                        </FormItem>
                    </Col>
                    <Col span={12}>
                        <FormItem label="周" {...formItemLayout}>
                            {getFieldDecorator('week', {
                                initialValue: injectForm.week,
                                rules: [{
                                    required: true, message: '周不为空',
                                }],
                            })(<Input placeholder="请填写周描述，如w01"/>)}
                        </FormItem>
                    </Col>
                    <Col span={24}>
                        <FormItem label="统计时间范围" {...lineFormItemLayout}>
                            {getFieldDecorator('rangeTime', {
                                initialValue: injectForm.rangeTime,
                                rules: [{
                                    type: 'array', required: true, message: '统计时间范围不为空',
                                }],
                            })(<RangePicker style={{ width: '100%' }} showTime format="YYYY-MM-DD" placeholder={['开始时间', '结束时间']}/>)}
                        </FormItem>
                    </Col>
                    <Col span={7}><h4 style={{ textAlign: 'center' }}>页面</h4></Col>
                    <Col span={7}><h4 style={{ textAlign: 'center' }}>GB</h4></Col>
                    <Col span={7}><h4 style={{ textAlign: 'center' }}>Zaful</h4></Col>
                    <Col span={3}><h4 style={{ textAlign: 'center' }}>&nbsp;</h4></Col>
                    {formItem}
                </Row>
            </Form>
        );
    }
}

export default Form.create()(SpeedCompareForm);
