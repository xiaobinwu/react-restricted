import React, { PureComponent } from 'react';
import { Row, Col, DatePicker, Table, Button, Pagination, Icon, Select } from 'antd';
import moment from 'moment';
import { performanceService, siteService } from 'service/index';
import styles from './index.module.css';
import EditableTagGroup from './EditableTagGroup';

const { RangePicker } = DatePicker;
const { Option } = Select;
export default class Log extends PureComponent {
    state = {
        logList: [],
        pageNo: 1,
        pageSize: 10,
        count: 0,
        loading: false,
        routes: {},
    }
    filter = {
        startTime: moment().subtract(7, 'days'),
        endTime: moment(),
        site: 'GB',
        tags: [],
    }
    componentWillMount() {
        this.getList();
        this.getRoutes();
    }
    render() {
        const dateFormat = 'YY/MM/DD H:mm';
        const {
            startTime,
            endTime,
            site,
        } = this.filter;
        const {
            logList,
            count,
            routes,
        } = this.state;
        const $this = this;
        const selectConfig = {
            className: `${styles.mgl20} ${styles.select}`,
            onChange(v) {
                const { name } = this;
                $this.filter[name] = v;
            }
        };
        const getTag = (v) => {
            this.filter.tags = v;
        };
        const getAllRoutes = (data) => {
            const res = [];
            for (const index in data) {
                const item = data[index];
                res.push(<Option value={item.enName} key={index}>{item.cnName}</Option>);
            }
            return res;
        };
        // eslint-disable-next-line array-callback-return
        logList.map((i) => { i.key = i._id; });
        return (
            <Row gutter={16}>
                <Col span={24}>
                    <RangePicker
                        showTime
                        defaultValue={[startTime, endTime]}
                        format={dateFormat}
                        onOk={this.handleRangeChange}
                        className={styles.dateFilter}
                    />
                    <Select defaultValue={site} {...selectConfig} name="site">
                        <Option value="GB" key="1">GB</Option>
                        <Option value="ZF" key="2">ZF</Option>
                    </Select>
                    <Select placeholder="平台" {...selectConfig} name="platform">
                        <Option value="" key="1">所有平台</Option>
                        <Option value="pc" key="2">PC</Option>
                        <Option value="m" key="3">M</Option>
                    </Select>
                    <Select placeholder="页面" {...selectConfig} name="route">
                        {getAllRoutes(routes)}
                    </Select>
                    <EditableTagGroup getTag={getTag}/>
                    <Button type="primary" onClick={this.handleSearch}><Icon type="search"/>查询</Button>
                </Col>
                <Col span={24}>
                    <Table columns={this.getColumns()}
                        className={styles.pdT20}
                        dataSource={logList}
                        bordered
                        pagination={false}
                        loading={this.state.loading}
                        size="small"/>
                    {count > 10 ?
                        <Pagination showSizeChanger onShowSizeChange={this.onShowSizeChange} onChange={this.onShowSizeChange} total={count} className={styles.page} />
                        : null
                    }
                </Col>
            </Row>
        );
    }
    onShowSizeChange = (current, pageSize) => {
        this.setState({
            pageNo: current,
            pageSize,
        });
        this.getList({
            pageNo: current,
            pageSize,
        });
    }
    getColumns() {
        const dateFormat = 'MM/DD H:mm:ss';
        return [
            {
                title: 'date',
                dataIndex: 'date',
                key: 'date',
                width: 100,
                render: v => moment(v).format(dateFormat),
            },
            {
                title: 'msg',
                dataIndex: 'msg',
                key: 'msg',
                // width: 100,
            },
            {
                title: 'route',
                dataIndex: 'route',
                key: 'route',
                width: 100,
            },
            {
                title: 'platform',
                dataIndex: 'platform',
                key: 'platform',
                width: 100,
            },
        ];
    }
    handleSearch = () => {
        this.getList();
    }
    handleRangeChange = (date) => {
        Object.assign(this.filter, {
            startTime: date[0],
            endTime: date[1],
        });
    }
    async getList(obj) {
        const param = Object.assign({
            pageNo: this.state.pageNo,
            pageSize: this.state.pageSize,
            ...this.filter,
        }, obj);
        this.setState({
            loading: true,
        });
        const res = await performanceService.getLogList(param);
        this.setState({
            loading: false,
        });
        // eslint-disable-next-line no-return-assign
        if (res.code === 0) {
            this.setState({
                logList: res.entry.list,
                count: res.total,
            });
        }
    }
    // 取所有卡种路由
    async getRoutes() {
        const res = await siteService.getWeekLatitude();
        if (res.code === 0) {
            this.setState({
                routes: res.entry
            });
        }
    }
}
