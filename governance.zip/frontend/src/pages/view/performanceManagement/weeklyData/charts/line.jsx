import React, { Component } from 'react';
import { Radio, Row, Col, Checkbox } from 'antd';
import ReactEcharts from 'component/echarts-for-react';

const RadioGroup = Radio.Group;
const CheckboxGroup = Checkbox.Group;

export default class Interface extends Component {
    state = {
        promotion: 'All',
        page: [],
        pageOptions: []
    }
    componentDidMount() {
        this.getPageList();
    }
    // 获取测速页面列表
    getPageList = () => {
        const page = [];
        const pageOptions = [];
        const { pageList } = this.props;
        if (JSON.stringify(pageList) !== '{}') {
            Object.keys(pageList).forEach((item, index) => {
                page.push(pageList[item].cnName);
                pageOptions.push({
                    label: pageList[item].cnName,
                    value: pageList[item].cnName
                });
            });
            this.setState({
                page,
                pageOptions
            });
        }
    }
    // 实例化后
    chartReady = (echartObj) => {
        this.echartObj = echartObj;
        this.changeLegends();
    }
    // 改变值
    onChange = (name, e) => {
        this.setState({
            [name]: e.target ? e.target.value : e
        }, () => {
            this.changeLegends();
        });
    }
    // 更改legend
    changeLegends = () => {
        const { legends } = this.props;
        const { promotion, page } = this.state;
        if (page.length > 0) {
            const strs = page.map((item, index) => {
                let str = item;
                if (promotion === 'All') {
                    str += '.*';
                } else if (promotion) {
                    str += `（${promotion}）`;
                }
                return str;
            }).join('|');
            const regex = new RegExp(strs, 'g');
            const selectedLegends = [];
            const unSelectedLegends = [];

            legends.forEach((item) => {
                if (item.search(regex) > -1) {
                    selectedLegends.push(item);
                } else {
                    unSelectedLegends.push(item);
                }
            });
            unSelectedLegends.forEach((item) => {
                this.echartObj.dispatchAction({
                    type: 'legendUnSelect',
                    name: item
                });
            });
            selectedLegends.forEach((item) => {
                this.echartObj.dispatchAction({
                    type: 'legendSelect',
                    name: item
                });
            });
        }
    }
    render() {
        const {
            series,
            xAxis,
            legends
        } = this.props;
        const { pageOptions } = this.state;
        const {
            promotion,
            page
        } = this.state;
        const options = {
            tooltip: {
                trigger: 'axis'
            },
            legend: {
                width: 280,
                right: 50,
                top: 50,
                itemWidth: 140,
                data: legends
            },
            dataZoom: [{
                type: 'inside',
                filterMode: 'empty'
            }],
            grid: {
                left: '3%',
                right: 500,
                bottom: '3%',
                containLabel: true
            },
            toolbox: {
                feature: {
                    saveAsImage: {},
                    restore: { show: true },
                    magicType: {
                        type: ['line', 'bar']
                    }
                }
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: xAxis
            },
            yAxis: {
                name: '耗时(s)',
                type: 'value'
            },
            series,
            animation: true,
        };
        return (
            <div style={{ textAlign: 'center' }}>
                <Row>
                    <Col span={14}>
                        <span>所属页面：</span>
                        <CheckboxGroup onChange={this.onChange.bind(this, 'page')} value={page}>
                            {
                                pageOptions.length > 0 && pageOptions.map((item, index) => {
                                    return <Checkbox value={item.value} key={index}>{item.label}</Checkbox>;
                                })
                            }
                        </CheckboxGroup>
                    </Col>
                    <Col span={10} style={{ marginBottom: 10 }}>
                        <span>是否排推广：</span>
                        <RadioGroup onChange={this.onChange.bind(this, 'promotion')} value={promotion}>
                            <Radio value="All">全部</Radio>
                            <Radio value="全部数据">全部数据</Radio>
                            <Radio value="排推广">排推广</Radio>
                        </RadioGroup>
                    </Col>
                </Row>
                <ReactEcharts
                    option={options}
                    style={{ height: 650, width: '100%', marginTop: 100 }}
                    onChartReady={this.chartReady}/>
            </div>
        );
    }
}
