import React, { Component } from 'react';
import { Table, Form, DatePicker, Select, message, Modal, Row, Col, Input, Button, Tooltip } from 'antd';
import { performanceService, siteService } from 'service';
import moment from 'moment';
import withFormModal from 'component/hoc/withFormModal';
import fire from 'img/fire.svg';
import WeeklyForm from './weeklyForm';
import WeeklyDrawer from './weeklyDrawer';
import styles from './index.module.css';

const WeeklyFormModal = withFormModal(WeeklyForm);
const { RangePicker } = DatePicker;

const FormItem = Form.Item;
const { Option } = Select;
const { confirm } = Modal;

let defaultFormOptions = {
    _id: '',
    week: '',
    createTime: null,
    platform: '',
    promotionValues: [''],
    promotionDecs: [''],
    unPromotionValues: [''],
    unPromotionDecs: [''],
    pageTypes: [''],
    keys: [0],
    isEdit: false
};

const type = {
    promotion: 'Promotion',
    unPromotion: 'UnPromotion'
};

class WeeklyData extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            column: [],
            loading: false,
            weeklyList: [],
            pagination: {
                pageNo: 1,
                pageSize: 20,
                totalCount: 0
            },
            selectedHandleRowKeys: [],
            selectedRowKeys: [],
            viewVisible: false,
            confirmLoading: false,
            visible: false,
            weeklyForm: JSON.parse(JSON.stringify(defaultFormOptions)),
        };
    }
    componentDidMount() {
        this.getPageList();
    }
    // 获取测速页面列表
    getPageList = async () => {
        const { code, entry } = await siteService.getWeekLatitude();
        const renderContent = (text, record, index) => {
            const obj = {
                children: text,
                props: {},
            };
            if (index % 2 === 0) {
                obj.props.rowSpan = 2;
            }
            if (index % 2 === 1) {
                obj.props.rowSpan = 0;
            }
            return obj;
        };
        if (code === 0) {
            let column = [];
            const keys = [];
            const pageTypes = [];
            const promotionValues = [];
            const promotionDecs = [];
            const unPromotionValues = [];
            const unPromotionDecs = [];
            Object.keys(entry).forEach((item, index) => {
                keys.push(index);
                pageTypes.push(item);
                promotionValues.push('');
                promotionDecs.push('');
                unPromotionValues.push('');
                unPromotionDecs.push('');
                column.push({
                    title: entry[item].cnName,
                    key: entry[item].enName,
                    dataIndex: entry[item].enName,
                    render: (text, record) => {
                        return (<div>
                            <span className={styles.whiteSpace} style={{ marginRight: 10 }}>{text}</span>
                            {
                                record[`${entry[item].enName}Dec`] ? <Tooltip title={<div>描述：{record[`${entry[item].enName}Dec`]}</div>}>
                                    <img src={fire} style={{ width: '15px', height: 'auto' }} />
                                </Tooltip> : null
                            }
                        </div>);
                    }
                });
            });
            column = [
                {
                    title: '周',
                    key: 'week',
                    dataIndex: 'week',
                    render: (text, record, index) => {
                        return renderContent(text, record, index);
                    }
                },
                {
                    title: '时间',
                    key: 'createTime',
                    dataIndex: 'createTime',
                    render: (text, record, index) => {
                        return renderContent(moment(record.createTime).format('YYYY-MM-DD'), record, index);
                    }
                },
                {
                    title: '类型',
                    key: 'type',
                    dataIndex: 'type',
                    render: (text, record) => {
                        return `${text}(${record.platform})`;
                    }
                }
            ].concat(column).concat({
                title: '操作',
                render: (text, record, index) => {
                    return renderContent(<React.Fragment>
                        <Button type="primary" size="small" style={{ marginRight: 10 }} onClick={this.setWeek.bind(this, record)}>编辑</Button>
                        <Button type="primary" size="small" onClick={this.delete.bind(this, record)}>删除</Button>
                    </React.Fragment>, record, index);
                }
            });

            if (keys.length) {
                defaultFormOptions = {
                    ...defaultFormOptions,
                    ...{
                        keys,
                        pageTypes,
                        promotionValues,
                        promotionDecs,
                        unPromotionValues,
                        unPromotionDecs
                    }
                };
            }

            this.setState({
                pageList: entry,
                weeklyForm: defaultFormOptions,
                column
            }, () => {
                this.getWeeklyList();
            });
        }
    }
    // 获取列表数据
    getWeeklyList = (e) => {
        e && e.preventDefault(); // eslint-disable-line
        this.props.form.validateFields(async (err, values) => {
            const { pageList, pagination } = this.state;
            this.setState({
                loading: true
            });
            const params = {
                ...pagination,
                ...this.props.form.getFieldsValue()
            };
            if (params.rangeTime && params.rangeTime.length > 0) {
                const { rangeTime } = params;
                params.startEventTime = rangeTime[0].valueOf(); // eslint-disable-line
                params.endEventTime = rangeTime[1].valueOf(); // eslint-disable-line
            }
            delete params.rangeTime;
            delete params.totalCount;
            const { entry, code } = await performanceService.getWeeklyList(params);
            let data = [];
            const { list } = entry;
            if (code === 0) {
                if (list && list.length > 0) {
                    list.forEach((item, index) => {
                        const dataItem1 = {};
                        const dataItem2 = {};
                        const { weekLists } = item;
                        if (weekLists.length > 0) {
                            weekLists.forEach((it, idx) => {
                                if (JSON.stringify(pageList) !== '{}' && pageList[it.pageType]) {
                                    const key = pageList[it.pageType].enName;
                                    dataItem1[key] = it.promotionValue;
                                    dataItem1[`${key}Dec`] = it.promotionDec;
                                    dataItem2[key] = it.unPromotionValue;
                                    dataItem2[`${key}Dec`] = it.unPromotionDec;
                                }
                            });
                        }
                        const baseSetting = {
                            _id: item._id,
                            platform: item.platform,
                            createTime: item.createTime,
                            week: item.week
                        };
                        data = data.concat([
                            {
                                ...baseSetting,
                                ...dataItem1,
                                ...{ type: '全部数据', tId: `${type.promotion}-${item._id}` }
                            },
                            {
                                ...baseSetting,
                                ...dataItem2,
                                ...{ type: '排推广', tId: `${type.unPromotion}-${item._id}` }
                            }
                        ]);
                    });
                }
                this.setState({
                    weeklyList: list,
                    data,
                    pagination: { ...pagination, ...{ totalCount: entry.total } },
                    loading: false
                });
            }
        });
    }
    // 监听表格变化
    handleTableChange = (page, filters, sorter) => {
        const { pagination } = this.state;
        if (page.current !== pagination.pageNo || page.pageSize !== pagination.pageSize) {
            this.setState({
                pagination: { ...pagination, ...{ pageNo: page.current, pageSize: page.pageSize } }
            }, () => {
                this.getWeeklyList();
            });
        }
    }
    // 打开modal
    setWeek = (record) => {
        let weeklyFormObj = {};
        if (record) {
            const { weeklyList } = this.state;
            const filterData = weeklyList.find((item) => {
                return item._id === record._id;
            });
            const pageTypes = [];
            const promotionValues = [];
            const promotionDecs = [];
            const unPromotionValues = [];
            const unPromotionDecs = [];
            if (filterData.weekLists.length > 0) {
                filterData.weekLists.forEach((item) => {
                    pageTypes.push(String(item.pageType));
                    promotionValues.push(item.promotionValue);
                    promotionDecs.push(item.promotionDec);
                    unPromotionValues.push(item.unPromotionValue);
                    unPromotionDecs.push(item.unPromotionDec);
                });
            }
            weeklyFormObj = {
                _id: record._id,
                createTime: moment(record.createTime),
                platform: record.platform,
                week: record.week,
                keys: Array.from(new Array(filterData.weekLists.length), (val, index) => index),
                pageTypes,
                promotionValues,
                promotionDecs,
                unPromotionValues,
                unPromotionDecs,
                isEdit: true
            };
        } else {
            weeklyFormObj = JSON.parse(JSON.stringify(defaultFormOptions));
        }
        this.setState({
            weeklyForm: weeklyFormObj,
            visible: true
        });
    }
    // 保存
    setWeekSend = () => {
        this.weekFormRef.props.form.validateFields(async (err, values) => {
            if (!err) {
                this.setState({
                    confirmLoading: true
                });
                let params = { ...this.weekFormRef.props.form.getFieldsValue() };
                params.createTime = params.createTime.valueOf();
                params.weekLists = [];
                params.keys.forEach((item, index) => {
                    params.weekLists.push({
                        pageType: params.pageTypes[item] || '',
                        promotionValue: params.promotionValues[item] || 0,
                        promotionDec: params.promotionDecs[item] || '',
                        unPromotionValue: params.unPromotionValues[item] || 0,
                        unPromotionDec: params.unPromotionDecs[item] || ''
                    });
                });
                delete params.pageTypes;
                delete params.promotionValues;
                delete params.promotionDecs;
                delete params.unPromotionValues;
                delete params.unPromotionDecs;
                delete params.keys;
                if (this.state.weeklyForm._id) {
                    params = { ...params, ...{ _id: this.state.weeklyForm._id } };
                }
                const res = await performanceService.setWeekSend(params);
                if (res.code === 0) {
                    this.setState({
                        confirmLoading: false,
                        visible: false
                    }, () => {
                        message.success('保存成功');
                        this.getWeeklyList();
                        this.weekFormRef.props.form.resetFields();
                    });
                } else {
                    message.error('保存错误');
                    this.setState({
                        confirmLoading: false
                    });
                }
            }
        });
    }
    // 删除
    delete = ({ _id }) => {
        const content = <div style={{ marginTop: '20px' }}><p>确认是否删除该条数据？</p></div>;
        const that = this;
        confirm({
            title: '确认提示',
            content,
            okText: '确定',
            cancelText: '取消',
            onOk() {
                (async () => {
                    const res = await performanceService.deleteWeek({ _id });
                    if (res.code === 0) {
                        message.success('删除成功');
                        that.getWeeklyList();
                    }
                })();
            }
        });
    }
    // 获取ref
    getWeekFormRef = (ref) => {
        this.weekFormRef = ref;
    }
    // 关闭Modal
    handleCancel = () => {
        if (this.weekFormRef) {
            this.weekFormRef.props.form.resetFields();
        }
        this.setState({
            visible: false
        });
    }
    // 打开速度对比趋势图的Drawer
    openDrawer = () => {
        const { selectedRowKeys } = this.state;
        const selectedHandleRowKeys = [];
        selectedRowKeys.forEach((item) => {
            const itemArr = item.split('-');
            if (itemArr[0] === type.promotion && selectedHandleRowKeys.indexOf(itemArr[1]) === -1) {
                selectedHandleRowKeys.push(itemArr[1]);
            }
        });
        if (selectedHandleRowKeys.length === 0) {
            return message.warning('请选择记录');
        }
        return this.setState({
            viewVisible: true,
            selectedHandleRowKeys
        });
    }
    // table 可选择
    onSelectChange = (selectedRowKeys) => {
        this.setState({ selectedRowKeys });
    }
    // 抽屉回调
    onDrawerClose = () => {
        this.setState({
            viewVisible: false
        });
    }
    render() {
        const {
            loading,
            column,
            data,
            pagination,
            weeklyForm,
            visible,
            confirmLoading,
            pageList,
            viewVisible,
            selectedRowKeys,
            selectedHandleRowKeys,
            weeklyList
        } = this.state;
        const pageControl = {
            current: pagination.pageNo,
            pageSize: pagination.pageSize,
            pageSizeOptions: ['10', '20', '30', '50'],
            showQuickJumper: true,
            total: pagination.totalCount
        };
        const rowSelection = {
            fixed: true,
            selectedRowKeys,
            onChange: this.onSelectChange
        };
        const { getFieldDecorator } = this.props.form;
        return (
            <div className={styles.weeklyTable}>
                <Form onSubmit={this.getWeeklyList} style={{ marginBottom: 20 }}>
                    <Row gutter={16}>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('platform', {
                                    initialValue: 'PC'
                                })(<Select>
                                    <Option value="PC">PC端</Option>
                                    <Option value="M">M端</Option>
                                </Select>)}
                            </FormItem>
                        </Col>
                        <Col span={3}>
                            <FormItem>
                                {getFieldDecorator('week')(<Input placeholder="请填写周"/>)}
                            </FormItem>
                        </Col>
                        <Col span={5}>
                            <FormItem>
                                {getFieldDecorator('rangeTime')(<RangePicker
                                    format='YYYY/MM/DD'
                                    placeholder={['开始时间', '结束时间']}
                                />)}
                            </FormItem>
                        </Col>
                        <Col span={6}>
                            <FormItem style={{ textAlign: 'center' }}>
                                <Button type="primary" icon="search" htmlType="submit" style={{ marginRight: 10 }}>查询</Button>
                                <Button type="primary" onClick={this.setWeek.bind(this, null)} style={{ marginRight: 10 }}>新增</Button>
                                <Button type="primary" onClick={this.openDrawer.bind(this)}>周数据对比趋势图</Button>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Table
                    rowKey="tId"
                    loading={loading}
                    columns={column}
                    dataSource={data}
                    rowSelection={rowSelection}
                    bordered
                    pagination={pageControl}
                    onChange={this.handleTableChange}
                    title={() => <div style={{ textAlign: 'center' }}>前端加载速度详细GA周数据(单位/s)</div>}
                />
                <WeeklyDrawer viewVisible={viewVisible} onClose={this.onDrawerClose} selectedHandleRowKeys={selectedHandleRowKeys} weeklyList={weeklyList} pageList={pageList}/>
                <WeeklyFormModal
                    width={1100}
                    maskClosable={false}
                    injectForm={weeklyForm}
                    getRef={this.getWeekFormRef}
                    title="GA每周数据录入/编辑"
                    visible={visible}
                    onOk={this.setWeekSend}
                    onCancel={this.handleCancel}
                    footer={[
                        <Button key="submit" type="primary" loading={confirmLoading} onClick={this.setWeekSend}>
                            确定
                        </Button>
                    ]}
                    wrappedProp= {{
                        pageList
                    }}
                />
            </div>
        );
    }
}

export default Form.create()(WeeklyData);
