import React, { Component } from 'react';
import { Drawer } from 'antd';
import Line from './charts/line';

class SpeedDrawer extends Component {
    onClose = () => {
        const { onClose } = this.props;
        onClose && onClose(); // eslint-disable-line
    }
    render() {
        const {
            viewVisible,
            weeklyList,
            pageList,
            selectedHandleRowKeys
        } = this.props;
        const xAxis = [];
        const series1 = {};
        const series2 = {};
        const series = [];
        const legends = [];
        if (JSON.stringify(pageList) !== '{}' && weeklyList.length > 0) {
            Object.keys(pageList).forEach((item, index) => {
                if (pageList[item]) {
                    const pKey = pageList[item].cnName;
                    series1[`${pKey}（全部数据）`] = [];
                    series2[`${pKey}（排推广）`] = [];
                }
            });
            weeklyList.filter((item, index) => {
                return selectedHandleRowKeys.includes(String(item._id));
            }).forEach((it, inx) => {
                xAxis.push(it.week);
                const { weekLists } = it;
                if (weekLists.length > 0) {
                    weekLists.forEach((sit, idx) => {
                        if (pageList[sit.pageType]) {
                            const key = pageList[sit.pageType].cnName;
                            series1[`${key}（全部数据）`].push(sit.promotionValue);
                            series2[`${key}（排推广）`].push(sit.unPromotionValue);
                        }
                    });
                }
            });
            Object.keys(series1).forEach((item) => {
                series.push({
                    name: item,
                    type: 'line',
                    smooth: true,
                    data: series1[item]
                });
                legends.push(item);
            });
            Object.keys(series2).forEach((item) => {
                series.push({
                    name: item,
                    type: 'line',
                    smooth: true,
                    data: series2[item]
                });
                legends.push(item);
            });
        }
        return (
            <Drawer
                width="100%"
                height="100%"
                placement="top"
                maskClosable={false}
                title='周数据对比趋势图'
                onClose={this.onClose}
                visible={viewVisible}
            >
                <Line series={series} legends={legends} xAxis={xAxis} pageList={pageList} />
            </Drawer>
        );
    }
}

export default SpeedDrawer;
