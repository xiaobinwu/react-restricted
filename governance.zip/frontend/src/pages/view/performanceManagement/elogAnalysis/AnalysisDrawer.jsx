import React, { Component } from 'react';
import PropTypes from 'prop-types';
// import { Drawer } from 'antd';

import TimeChart from './chart/TimeChart';

class AnalysisDrawer extends Component {
    static propTypes = {
        chartData: PropTypes.object,
        viewVisible: PropTypes.bool,
        viewTitle: PropTypes.string,
        onClose: PropTypes.func
    };

    static defaultProps = {
        chartData: {},
        viewVisible: false,
        viewTitle: 'elog 数据可视化分析'
    };

    onClose = () => {
        const { onClose } = this.props;
        if (onClose) {
            onClose();
        }
    };

    componentDidMount() {}

    render() {
        const {
            chartData,
        } = this.props;

        return (
            <TimeChart
                chartData={chartData}
            />
        );

        // return (
        //     <Drawer
        //         width="100%"
        //         height="530px"
        //         placement="top"
        //         maskClosable={true}
        //         title={viewTitle}
        //         visible={viewVisible}
        //         onClose={this.onClose}
        //     >
        //         <TimeChart
        //             chartData={chartData}
        //         />
        //     </Drawer>
        // );
    }
}

export default AnalysisDrawer;
