/**
 * Created by Liu.Jun on 2018/12/22.
 */

export default {
    line: [],
    mergeConfig: {
        column: [],
        startTime: 'starttime'
    },
};
