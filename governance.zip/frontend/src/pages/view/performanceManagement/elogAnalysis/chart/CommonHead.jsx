import React, { Component } from 'react';
import { Table } from 'antd';

class CommonHead extends Component {
    render() {
        const { commonData } = this.props;
        const columns = Object.entries(commonData).map(([key]) => ({
            title: key,
            dataIndex: key,
            key,
        }));
        const data = [commonData];
        return <Table rowKey="id" columns={ columns } pagination = { false } dataSource={ data } />;

    }
}
export default CommonHead;
