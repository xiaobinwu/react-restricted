import React, { Component } from 'react';
import PropType from 'prop-types';

import CommonHead from './CommonHead';
import ChartTable from './ChartTable';

class TimeChart extends Component {
    static propTypes = {
        chartData: PropType.object
    };

    static defaultsProp = {
        chartData: {
            commonData: [],
            chartData: [],
        }
    };

    comptuedStyle() {}

    render() {
        const { chartData } = this.props;

        const { common, chart, mergeConfig } = chartData;
        return <div>
            <div style={{ marginTop: '30px' }}>
                <h3>公共数据：</h3>
                <CommonHead commonData = {common}/>
            </div>
            <div style={{ marginTop: '30px' }}>
                <h3>页面时间瀑布数据：</h3>
                <ChartTable chartData = {chart} mergeConfig = {mergeConfig} />
            </div>
        </div>;
    }
}

export default TimeChart;
