import React, { Component } from 'react';
import { Table, Popover } from 'antd';


const lineColor = 'rgb(200, 200, 200)';

class ChartTable extends Component {
    getSplit(maxTime, showNum = true) {
        const lineNum = 1 / maxTime;
        return new Array(maxTime + 1).fill(1).map((k, i) => (
            <div key={i} style={{
                height: '100%',
                position: 'absolute',
                top: 0,
                left: `${i * lineNum * 100}%`,
                // borderLeft: `1px solid ${i === 0 ? 'none' : lineColor}`,
                borderLeft: `1px solid ${lineColor}`,
                fontSize: '12px',
                color: lineColor,
                paddingLeft: '2px',
                whiteSpace: 'nowrap',
                zIndex: 9
            }}>
                {showNum ? `${i}s` : ''}
            </div>
        ));
    }

    // th
    getTitle(title, maxTime) {
        const splitLine = this.getSplit(maxTime);

        return <div className={'title'} style={{
            position: 'relative',
            height: '21px'
        }}>
            <div style={{
                paddingLeft: '20px'
            }}>{ title }</div>
            { splitLine }
        </div>;
    }

    getTableData() {
        const { chartData, mergeConfig } = this.props;
        const { title, key } = mergeConfig;
        const columns = [];

        const arrSumTime = [];

        const dataSource = chartData.map((chartLine, chartLineIndex) => {
            arrSumTime.push(+chartLine[mergeConfig.start] + +chartLine[mergeConfig.count]);

            // 每一行
            return Object.entries(chartLine).reduce((preValue, [columnKey, columnValue]) => {
                if (mergeConfig.column.includes(columnKey) || [mergeConfig.start, mergeConfig.count].includes(columnKey)) {
                    // 需要合并列
                    if (!preValue[mergeConfig.key]) {
                        preValue[mergeConfig.key] = {};
                    }
                    preValue[mergeConfig.key][columnKey] = columnValue;

                } else {
                    if (chartLineIndex === 0 && columnKey !== 'key') {
                        // 第一行处理表头
                        columns.unshift({
                            title: columnKey,
                            dataIndex: columnKey,
                            key: columnKey,
                            width: 240
                        });
                    }
                    preValue[columnKey] = columnValue;
                }

                return {
                    ...preValue
                };
            }, {});
        }).sort((pre, next) => {
            return +pre.timeline[mergeConfig.start] - +next.timeline[mergeConfig.start];
        });

        const maxTime = this.getMaxTime(arrSumTime);

        const columns1 = [
            ...columns,
            {
                title: `${title}（0 - ${maxTime}s）`,
                dataIndex: key,
                key,
                render: data => JSON.stringify(data),
            }
        ];

        const TitleCom = this.getTitle(title, maxTime);

        columns.push({
            // title: `${title}（0 - ${maxTime}s）`,
            title: TitleCom,
            dataIndex: key,
            key,
            // render: data => JSON.stringify(data)
            render: (data) => {
                const content = <div style={{
                    width: '260px'
                }}>
                    {
                        mergeConfig.column.map((legend, index) => {
                            return <div key={legend} style={{
                                display: 'flex',
                                padding: '2px 0',
                                alignItems: 'center',
                                justifyContent: 'space-between'
                            }}>
                                <div style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                }}>
                                    <div style={{
                                        width: '10px',
                                        height: '10px',
                                        background: mergeConfig.color[index]
                                    }}/>
                                    <div style={{
                                        marginLeft: '5px',
                                        fontSize: '16px',
                                    }}>{legend}</div>
                                </div>
                                <div>
                                    {+data[legend]}ms
                                </div>
                            </div>;
                        })
                    }

                    <div style={{
                        display: 'flex',
                        padding: '4px 0',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        borderTop: '1px solid rgb(216, 216, 216)',
                        fontWeight: 'bold'
                    }}>
                        <div>{mergeConfig.count}</div>
                        <div>{+data[mergeConfig.count]}ms</div>
                    </div>
                </div>;

                return <div style={{
                    width: '100%',
                    position: 'relative',
                    height: '100%',
                    whiteSpace: 'nowrap'
                }}>
                    {
                        // 分割线
                        this.getSplit(maxTime, false)
                    }
                    <div style={{
                        width: `${(+data[mergeConfig.start] / (maxTime * 1000)) * 100}%`,
                        display: 'inline-block',
                        position: 'relative',
                        height: '100%'
                    }} >
                    </div>
                    {
                        mergeConfig.column.map((itemItem, index) => {
                            return <Popover key={itemItem} content={content}>
                                <div style={{
                                    width: `${(+data[itemItem] / (maxTime * 1000)) * 100}%`,
                                    height: '100%',
                                    display: 'inline-block',
                                    position: 'relative',
                                    background: mergeConfig.color[index],
                                    color: 'transparent'
                                }} >1</div>
                            </Popover>;
                        })
                    }
                </div>;
            }
        });

        return {
            columns,
            columns1,
            arrSumTime,
            dataSource,
        };
    }

    getMaxTime(arrSumTime) {
        return Math.ceil(window.Math.max.apply(Math, arrSumTime) / 1000);
    }

    render() {
        const { columns, columns1, dataSource } = this.getTableData();
        const { mergeConfig } = this.props;

        return <div>
            <div className={'legend'} style={{
                display: 'flex',
                alignItems: 'center',
                padding: '20px 0'
            }}>
                <div style={{
                    marginLeft: '5px',
                    fontSize: '16px',
                }}>Legend：</div>
                {
                    mergeConfig.column.map((legend, index) => {
                        return <div key={legend} style={{
                            display: 'flex',
                            alignItems: 'center',
                            marginRight: '15px'
                        }}>
                            <div style={{
                                width: '10px',
                                height: '10px',
                                background: mergeConfig.color[index]
                            }}/>
                            <div style={{
                                marginLeft: '5px',
                                fontSize: '16px',
                                // color: mergeConfig.color[index]
                            }}>{legend}</div>
                        </div>;
                    })
                }
            </div>
            <Table columns={ columns } pagination = { false } dataSource={ dataSource } />

            <Table columns={ columns1 } pagination = { false } dataSource={ dataSource } />
        </div>;
    }
}
export default ChartTable;
