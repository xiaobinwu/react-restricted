import React, { Component } from 'react';
import { Upload, Icon } from 'antd';
import csv from 'js/csv';
import AnalysisDrawer from './AnalysisDrawer';
import './index.css';

const { Dragger } = Upload;

class PerformanceReport extends Component {
    constructor(props) {
        super(props);

        this.state = {
            chartDat: {},
            viewVisible: false,
            viewTitle: 'elog 数据分析'
        };
    }
    // noinspection JSAnnotator
    draggerProps = {
        name: 'file',
        multiple: false,
        beforeUpload() {
            // 不上传文件，只做本地分析
            return false;
        },
        onChange: (info) => {
            const { file } = info;
            const reader = new FileReader();
            reader.readAsText(file);
            reader.onload = (event) => {
                const csvData = event.target.result;
                // const lines = csvData.split('\n').map(item => item.split(','));
                const lines = csv.parse(csvData);

                const chartData = {
                    chart: [],
                    common: {},
                    mergeConfig: {
                        start: 'starttime', // 起点字段
                        count: 'fileloadtime', // 总时间字段 对比加集 可能存在偏差值
                        key: 'timeline', // 合并后新字段key
                        title: '时间轴', // 合并后新字段 title
                        // 有序 [301， dns ，建立链接（ssl），TTFB, download]
                        column: ['fetchtime', 'domainlookuptime', 'connectinittime', 'waitingtime', 'downloadtime'],
                        color: ['#f4b355', '#f699c1', '#34c2d0', '#fde448', '#8ac730'],
                    }
                };

                const includeCommon = [
                    'logtime',
                    'ua',
                    'id',
                    'actiontype',
                    'domcontentloadedeventend',
                    'firstpaint',
                    'loadeventend',
                    'platform',
                    'pipeline',
                    'country',
                    'lang',
                ];

                const includeLines = [
                    'url',
                    'starttime',
                    'initiatortype', // 资源类型
                    'fetchtime', // 重定向时间
                    'domainlookuptime', // dns 查找时间
                    'connectinittime', // 连接建立时间（包含ssl）
                    'waitingtime', // TTFB
                    'downloadtime', // 下载时间
                    'fileloadtime' // 加载时间总和
                ];

                chartData.chart = lines.map((line, lineIndex) => {
                    return Object.entries(line).reduce((preColumn, [keyColumn, valueColumn], indexColumn) => {
                        const key = keyColumn.split('.')[1];
                        if (lineIndex === 0 && includeCommon.includes(key)) {
                            chartData.common[key] = valueColumn;
                        }

                        if (includeLines.includes(key)) {
                            preColumn[key] = valueColumn;
                        }
                        return preColumn;
                    }, {
                        key: line['gearbest_perf_logsss.url']
                    });
                });

                // 显示图表
                this.onShowDrawer({
                    chartData
                });
            };
        },
    };
    onShowDrawer = (params) => {
        const { chartData } = params;
        this.setState({
            viewVisible: true,
            chartData
        });
    };

    onCloseDrawer = () => {
        this.setState({
            viewVisible: false
        });
    };

    render() {
        const { chartData, viewVisible, viewTitle } = this.state;
        return (<div>
            <Dragger {...this.draggerProps}>
                <p className="ant-upload-drag-icon">
                    <Icon type="inbox" />
                </p>
                <p className="ant-upload-text">点击或者拖动到这里添加文件</p>
                <p className="ant-upload-hint">只支持单id数据分析，导入多id 也只以导入的第一个id为准</p>
            </Dragger>

            { viewVisible ? <AnalysisDrawer
                chartData={chartData}
                viewVisible={viewVisible}
                viewTitle={viewTitle}
                onClose={this.onCloseDrawer}
            /> : null }
        </div>);
    }
}

export default PerformanceReport;
