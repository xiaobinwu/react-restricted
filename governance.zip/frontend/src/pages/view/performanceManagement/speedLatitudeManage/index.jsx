import React from 'react';
import { Button, Table, Modal, message, Input, Select } from 'antd';
import { siteService } from 'service';
import styles from './index.module.css';

const { Option } = Select;

class PerformanceReport extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: false,
            visible: false,
            cnNameVal: '',
            enNameVal: '',
            typeCodeVal: Number,
            markVal: ''
        };
    }
    // 请求列表数据
    async getSpeedLatitude() {
        this.setState({
            loading: true,
        });
        const res = await siteService.getSpeedLatitude({ manage: true });
        this.setState({
            data: res.entry,
            loading: false
        });
    }
    // 新增
    addSpeedLatitude() {
        const cnName = this.state.cnNameVal;
        const enName = this.state.enNameVal;
        const typeCode = this.state.typeCodeVal;
        const mark = this.state.markVal;
        Modal.confirm({
            title: '确认提示',
            content: `（新增维度）确认是否需要操作 ${cnName}`,
            okText: '确定',
            cancelText: '取消',
            onOk: async () => {
                this.setState({
                    visible: false,
                    cnNameVal: '',
                    enNameVal: '',
                    typeCode: Number,
                    markVal: ''
                });
                const res = await siteService.addSpeedLatitude({
                    cnName,
                    enName,
                    typeCode,
                    mark
                });
                if (res.code === 0) {
                    message.success(res.message);
                    this.getSpeedLatitude();
                }
            }
        });
    }
    // 删除条目
    deleteSpeedLatitude(record) {
        Modal.confirm({
            title: '确认提示',
            content: `确认是否需要操作 ${record.title}`,
            okText: '确认',
            cancelText: '取消',
            onOk: async () => {
                const res = await siteService.deleteSpeedLatitude({
                    id: record._id
                });
                if (res.code === 0) {
                    message.success(res.message);
                    this.getSpeedLatitude();
                }
            }
        });
    }

    changeCnNameVal(e) {
        const val = e.target.value;
        this.setState({
            cnNameVal: val
        });
    }
    changeEnNameVal(e) {
        const val = e.target.value;
        this.setState({
            enNameVal: val
        });
    }
    changeTypeCodeVal(val) {
        this.setState({
            typeCodeVal: Number(val)
        });
    }
    changeMarkVal(e) {
        const val = e.target.value;
        this.setState({
            markVal: val
        });
    }
    componentDidMount() {
        this.getSpeedLatitude.bind(this)();
    }
    render() {
        const {
            data,
            loading,
        } = this.state;
        const columns = [{
            title: 'ID',
            key: '_id',
            dataIndex: '_id',
            align: 'center'
        }, {
            title: '类型',
            dataIndex: 'typeCode',
            key: 'typeCode',
            render: (text, record) => {
                return text === 1 ? '排推广' : '不排推广';
            }
        }, {
            title: '维度标识（唯一）',
            dataIndex: 'mark',
            key: 'mark',
        }, {
            title: '中文名称',
            dataIndex: 'cnName',
            key: 'cnName',
        }, {
            title: '英文名称',
            dataIndex: 'enName',
            key: 'enName',
        }, {
            title: '操作',
            key: 'action',
            align: 'center',
            width: 200,
            render: (text, record) => (
                <Button type="primary" onClick={this.deleteSpeedLatitude.bind(this, record)}>移除</Button>
            )
        }];

        return <div>
            <Button type="primary" icon="plus" onClick={() => {
                this.setState({
                    visible: true,
                });
            }} >增加速度对比维度</Button>
            <div className={styles.tablewarp}>
                <Table columns={columns} dataSource={data} loading={loading} locale={{ emptyText: '暂无数据' }} rowKey="_id" />
            </div>
            <Modal
                visible={this.state.visible}
                onCancel={() => {
                    this.setState({
                        visible: false,
                    });
                }}
                footer={[
                    <Button type="primary" key="submit" onClick={this.addSpeedLatitude.bind(this)}>保存</Button>
                ]}
            >
                <p style={{
                    textAlign: 'center'
                }} className="system-backlist-modal-title">增加速度对比维度</p>
                <p className={styles.itemTitle}>类型</p>
                <Select defaultValue="请选择" style={{ width: 120 }} onChange={this.changeTypeCodeVal.bind(this)}>
                    <Option value="1">排推广</Option>
                    <Option value="2">非排推广</Option>
                </Select>
                <p className={styles.itemTitle}>中文名称</p>
                <Input
                    placeholder="请输入中文名称"
                    value={this.state.cnNameVal}
                    onChange={this.changeCnNameVal.bind(this)}
                />
                <p className={styles.itemTitle}>英文名称</p>
                <Input
                    placeholder="请输入英文乐称"
                    value={this.state.enNameVal}
                    onChange={this.changeEnNameVal.bind(this)}
                />
                <p className={styles.itemTitle}>维度标识</p>
                <Input
                    placeholder="请输入维度标识"
                    value={this.state.markVal}
                    onChange={this.changeMarkVal.bind(this)}
                />
            </Modal>
        </div>;
    }
}

export default PerformanceReport;
