import React from 'react';
import { Button, Table, Modal, message, Input } from 'antd';
import { siteService } from 'service';
import styles from './index.module.css';

class PerformanceReport extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            loading: false,
            visible: false,
            cnNameVal: '',
            enNameVal: '',
            markVal: ''
        };
    }
    // 请求列表数据
    async getWeekLatitude() {
        this.setState({
            loading: true,
        });
        const res = await siteService.getWeekLatitude({ manage: true });
        this.setState({
            data: res.entry,
            loading: false
        });
    }
    // 新增
    addWeekLatitude() {
        const cnName = this.state.cnNameVal;
        const enName = this.state.enNameVal;
        const mark = this.state.markVal;
        Modal.confirm({
            title: '确认提示',
            content: `（新增维度）确认是否需要操作 ${cnName}`,
            okText: '确定',
            cancelText: '取消',
            onOk: async () => {
                this.setState({
                    visible: false,
                    cnNameVal: '',
                    enNameVal: '',
                    mark: ''
                });
                const res = await siteService.addWeekLatitude({
                    cnName,
                    enName,
                    mark
                });
                if (res.code === 0) {
                    message.success(res.message);
                    this.getWeekLatitude();
                }
            }
        });
    }
    // 删除条目
    deleteWeekLatitude(record) {
        Modal.confirm({
            title: '确认提示',
            content: `确认是否需要操作 ${record.title}`,
            okText: '确认',
            cancelText: '取消',
            onOk: async () => {
                const res = await siteService.deleteWeekLatitude({
                    id: record._id
                });
                if (res.code === 0) {
                    message.success(res.message);
                    this.getWeekLatitude();
                }
            }
        });
    }

    changeCnNameVal(e) {
        const val = e.target.value;
        this.setState({
            cnNameVal: val
        });
    }
    changeEnNameVal(e) {
        const val = e.target.value;
        this.setState({
            enNameVal: val
        });
    }
    changeMarkVal(e) {
        const val = e.target.value;
        this.setState({
            markVal: val
        });
    }
    componentDidMount() {
        this.getWeekLatitude.bind(this)();
    }
    render() {
        const {
            data,
            loading,
        } = this.state;
        const columns = [{
            title: 'ID',
            key: '_id',
            dataIndex: '_id',
            align: 'center'
        }, {
            title: '维度标识（唯一）',
            dataIndex: 'mark',
            key: 'mark',
        }, {
            title: '中文名称',
            dataIndex: 'cnName',
            key: 'cnName',
        }, {
            title: '英文名称',
            dataIndex: 'enName',
            key: 'enName',
        }, {
            title: '操作',
            key: 'action',
            align: 'center',
            width: 200,
            render: (text, record) => (
                <Button type="primary" onClick={this.deleteWeekLatitude.bind(this, record)}>移除</Button>
            )
        }];

        return <div>
            <Button type="primary" icon="plus" onClick={() => {
                this.setState({
                    visible: true,
                });
            }} >增加周数据维度</Button>
            <div className={styles.tablewarp}>
                <Table columns={columns} dataSource={data} loading={loading} locale={{ emptyText: '暂无数据' }} rowKey="_id" />
            </div>
            <Modal
                visible={this.state.visible}
                onCancel={() => {
                    this.setState({
                        visible: false,
                    });
                }}
                footer={[
                    <Button type="primary" key="submit" onClick={this.addWeekLatitude.bind(this)}>保存</Button>
                ]}
            >
                <p style={{
                    textAlign: 'center'
                }} className="system-backlist-modal-title">增加周数据维度</p>
                <p className={styles.itemTitle}>中文名称</p>
                <Input
                    placeholder="请输入中文名称"
                    value={this.state.cnNameVal}
                    onChange={this.changeCnNameVal.bind(this)}
                />
                <p className={styles.itemTitle}>英文名称</p>
                <Input
                    placeholder="请输入英文乐称"
                    value={this.state.enNameVal}
                    onChange={this.changeEnNameVal.bind(this)}
                />
                <p className={styles.itemTitle}>维度标识</p>
                <Input
                    placeholder="请输入维度标识，请保持唯一性"
                    value={this.state.markVal}
                    onChange={this.changeMarkVal.bind(this)}
                />
            </Modal>
        </div>;
    }
}

export default PerformanceReport;
