const initialState = {
    loadThemePending: true,
    pending: true,
    logged: false,
    username: '',
};

const userReducer = (state = initialState, action) => {
    if (action.type === 'SET_LOGGED_USER') {
        return Object.assign({}, state, {
            logged: action.logged,
            username: action.username,
            pending: false
        });
    }
    if (action.type === 'SET_THEME_PENDING') {
        return Object.assign({}, state, {
            loadThemePending: false
        });
    }
    return state;
};

export default userReducer;
