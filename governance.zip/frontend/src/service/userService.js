import Service from './service';

class UserService extends Service {
    // 登录
    login(params = {}) {
        return this.post('/user/login', params);
    }
    // 登出
    logout() {
        return this.get('/user/logout');
    }
    // 获取用户信息
    getUserInfo(params = {}) {
        return this.get('/user/info');
    }
}

export default new UserService();
