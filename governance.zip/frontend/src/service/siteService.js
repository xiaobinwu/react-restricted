import Service from './service';

class SiteService extends Service {
    // 获取速度对比的页面列表
    getSpeedLatitude(params = {}) {
        return this.get('/site/speedLatitudeManage/list', params);
    }

    // 添加速度对比的页面列表
    addSpeedLatitude(params = {}) {
        return this.post('/site/speedLatitudeManage/add', params);
    }

    // 删除速度对比的页面列表
    deleteSpeedLatitude(params = {}) {
        return this.post('/site/speedLatitudeManage/delete', params);
    }

    // 获取周数据的页面列表
    getWeekLatitude(params = {}) {
        return this.get('/site/weekLatitudeManage/list', params);
    }

    // 添加周数据的页面列表
    addWeekLatitude(params = {}) {
        return this.post('/site/weekLatitudeManage/add', params);
    }

    // 删除周数据的页面列表
    deleteWeekLatitude(params = {}) {
        return this.post('/site/weekLatitudeManage/delete', params);
    }
}

export default new SiteService();
