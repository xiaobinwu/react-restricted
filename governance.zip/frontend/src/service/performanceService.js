import Service from './service';

class PerformanceService extends Service {

    // 性能报告列表
    getTodoList(params = {}) {
        return this.get('/todos/list', params);
    }
    // 新增性能报告
    addTodoList(params = {}) {
        return this.post('/todos/add', params);
    }

    // 删除性能报告
    deleteTodoList(params = {}) {
        return this.post('/todos/delete', params);
    }

    /* GB-Zaful网站速度对比列表 */
    getSpeedCompareList(params = {}) {
        return this.get('/performance/speedCompare/compare-list', params);
    }

    /* GB-Zaful网站速度对比 新增更新 */
    setSpeedSend(params = {}) {
        if (params.id) {
            return this.post('/performance/speedCompare/compare-edit', params);
        }
        return this.post('/performance/speedCompare/compare-add', params);
    }
    /* GB-Zaful网站速度对比 删除 */
    deleteSpeed(params = {}) {
        return this.post('/performance/speedCompare/compare-delete', params);
    }
    /* 加载速度-GA周数据列表 */
    getWeeklyList(params = {}) {
        return this.get('/performance/weeklyData/list', params);
    }
    /* 加载速度-GA周数据删除 */
    deleteWeek(params = {}) {
        return this.post('/performance/weeklyData/delete', params);
    }
    /* 加载速度-GA周数据新增编辑 */
    setWeekSend(params = {}) {
        if (params._id) {
            return this.post('/performance/weeklyData/update', params);
        }
        return this.post('/performance/weeklyData/create', params);
    }
    /* log */
    getLogList(params = {}) {
        return this.post('/logdata/record', params);
    }
}

export default new PerformanceService();
