import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Icon } from 'antd';
import { connect } from 'react-redux';
import store from 'rRedux/store';
import styles from './index.module.css';

const { SubMenu } = Menu;

class SiderMenu extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menuItems: {},
            selectedKeys: ['0-0'],
            openKeys: ['0']
        };
        this.rootSubmenuKeys = [];
    }
    componentDidMount() { //eslint-disable-line
        // 组件挂载前格式化路由配置，将其变成左侧菜单
        const menuItems = {};
        this.props.navData.forEach((item, i) => {
            menuItems[item.site] = (item.children && item.children.length > 0) ? this.walkMenu(item.children, item.path, item.name) : [];
        });
        this.setState({
            menuItems
        });
        this.handleLocation(this.props.location, true);
    }
    UNSAFE_componentWillReceiveProps(nextProps) { //eslint-disable-line
        if (this.props.currentSite !== nextProps.currentSite) {
            this.handleLocation({ pathname: window.location.pathname }, false);
        }
    }
    // 初始状态根据{location}获取左侧菜单栏selectedKey和openKey
    handleLocation = ({ pathname }, isInitial) => {
        let siderMenuSelectedKey = '0';
        let siderMenuOpendedKey = [];
        const breadCrumb = [];
        if (pathname === '/') {
            let pathObj = JSON.parse(JSON.stringify(this.props.navData[0]));
            breadCrumb.push(this.props.navData[0].name);
            while (!pathObj.hasChildrenNotInMenuBar && pathObj.children && pathObj.children.length > 0) {
                pathObj.key && siderMenuOpendedKey.push(pathObj.key); //eslint-disable-line
                siderMenuSelectedKey = pathObj.children[0].key;
                breadCrumb.push(pathObj.children[0].name);
                pathObj = pathObj.children[0]; //eslint-disable-line
            }
        } else {
            const pathnameArr = pathname.split('/');
            pathnameArr.shift();
            const currentRoutes = this.props.navData.filter(item => item.path === `/${pathnameArr[0]}`);
            pathnameArr.shift();
            const keyPaths = [];
            let level = 0;
            let childrenRouteNotInMenuBarNum = 0;
            const walkRoute = (routes) => {
                if (routes.children && routes.children.length > 0) {
                    const matchItem = routes.children.find(item => item.path === pathnameArr[level]);
                    if (matchItem) {
                        keyPaths.push(matchItem.key);
                        breadCrumb.push(matchItem.name);
                        level++; //eslint-disable-line
                        routes.hasChildrenNotInMenuBar && childrenRouteNotInMenuBarNum++; //eslint-disable-line
                        walkRoute(matchItem);
                    }
                }
            };
            breadCrumb.push(currentRoutes[0].name);
            walkRoute(currentRoutes[0]);
            keyPaths.length > 0 && (siderMenuSelectedKey = keyPaths[keyPaths.length - 1 - childrenRouteNotInMenuBarNum]); //eslint-disable-line
            if (keyPaths.length > 0) {
                keyPaths.pop();
                siderMenuOpendedKey = keyPaths;
            }
        }
        // 初始状态获取面包屑
        store.dispatch({
            type: 'SET_BREADCRUMB',
            breadCrumb
        });
        const state = {};
        if (!isInitial) {
            this.menuRef.handleOpenChange(siderMenuOpendedKey);
        } else {
            state.openKeys = siderMenuOpendedKey;
        }
        state.selectedKeys = [siderMenuSelectedKey];
        this.setState(state);
    }
    // 递归获取左侧菜单栏结构
    walkMenu = (menuSet, path, name, index) => menuSet.map((item, i) => {
        const key = typeof (index) !== 'undefined' ? `${index}-${i}` : `${i}`;
        const linkPath = `${path}/${item.path}`;
        const linkName = `${name}/${item.name}`;
        if (!item.hasChildrenNotInMenuBar && item.children && item.children.length > 0) {
            // 获取根subMenu key值
            key.length === 1 ? (this.rootSubmenuKeys.push(key)) : ''; //eslint-disable-line
            return (
                <SubMenu key={key} title={
                    <span>
                        {item.icon && <Icon type={item.icon} />}
                        <span>{item.name}</span>
                    </span>
                }>
                    {
                        this.walkMenu(item.children, linkPath, linkName, key)
                    }
                </SubMenu>
            );
        }
        return (
            <Menu.Item key={key} breadcrumb={linkName}>
                {item.icon && <Icon type={item.icon} />}
                <span>{item.name}</span>
                <Link to={linkPath}></Link>
            </Menu.Item>
        );
    })
    // menu onClick触发多次
    // https://github.com/ant-design/ant-design/issues/10382
    // 点击左侧菜单栏更改面包屑
    changeBreadCrumb = (e) => {
        if (e.key) {
            store.dispatch({
                type: 'SET_BREADCRUMB',
                breadCrumb: e.item.props.breadcrumb.split('/')
            });
        } else if (e.domEvent) {
            e.domEvent.stopPropagation();
        }
    }
    // 切换选中项
    handleSelectedChange = (item) => {
        this.setState({
            selectedKeys: [item.key]
        });
    }
    render() {
        const { menuItems, selectedKeys, openKeys } = this.state;
        const { currentSite } = this.props;
        return (
            // 处理多站点左侧菜单的变化，使用props.openKeys,会导致Menu组件的this.inlineOpenKeys中间存储变量失效，就会出现收缩时的bug
            // 所以使用prop.defaultOpenKeys,可是defaultOpenKeys只会在初始化传入，导致不同系统切换左侧菜单栏打开定位不准，
            // 可以使用ref手动去修改Menu组件中的state.openKeys
            <Menu ref={(ref) => { this.menuRef = ref; }} theme="dark" mode="inline" onSelect={this.handleSelectedChange} selectedKeys={selectedKeys} defaultOpenKeys={openKeys} className={styles.sider} onClick={this.changeBreadCrumb}>
                { menuItems[currentSite] }
            </Menu>
        );
    }
}
const stateToProps = ({ routeState }) => ({
    currentSite: routeState.currentSite
});

export default connect(stateToProps)(SiderMenu);
