import echarts from 'echarts';
import { connect } from 'react-redux';
import EchartsReactCore from './core';

// export the Component the echarts Object.
class EchartsReact extends EchartsReactCore {
    constructor(props) {
        super(props);
        this.echartsLib = echarts;
    }
}
const stateToProps = ({ themeState }) => ({
    theme: themeState.theme
});

export default connect(stateToProps)(EchartsReact);
