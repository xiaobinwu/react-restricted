import React, { Component } from 'react';
import { Modal } from 'antd';

// 高阶函数，统一封装带表单Modal，以便获取多个由Form.create创建的表单Ref
const withFormModal = (WrappedComponent) => {
    return class extends Component {
        render() {
            const {
                injectForm,
                getRef,
                wrappedProp,
                ...restProp
            } = this.props;
            return (
                <Modal {...restProp}>
                    {
                        injectForm
                            ? <WrappedComponent wrappedComponentRef={getRef} injectForm={injectForm} {...wrappedProp}/>
                            : <WrappedComponent ref={getRef} {...wrappedProp}/>
                    }
                </Modal>
            );
        }
    };
};

export default withFormModal;
