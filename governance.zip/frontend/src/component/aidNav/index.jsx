import React, { Component } from 'react';
import { Icon, Menu } from 'antd';
import store from 'rRedux/store';
import styles from './index.module.css';

const { SubMenu } = Menu;

class AidNav extends Component {
    logout = () => {
        store.dispatch({
            type: 'SET_LOGGED_USER',
            logged: false,
            username: ''
        });
        sessionStorage.removeItem('token');
    }
    handleClick = (e) => {
        if (e.key) {
            switch (e.key) {
            case 'message':

                break;
            case 'usergroup-add':

                break;

            case 'user':
                this.logout();
                break;

            default: {
                // Impty
            }
            }

        } else if (e.domEvent) {
            e.domEvent.stopPropagation();
        }
    }
    // 阻止submenu默认行为
    titleClick = (e) => {
        e.domEvent.stopPropagation();
        e.domEvent.preventDefault();
    }
    render() {
        return (
            <Menu onClick={this.handleClick} mode="horizontal" theme="dark" className={styles.aidNav}>
                <SubMenu title={<span><Icon type="user" /></span>} onTitleClick={this.titleClick}>
                    <Menu.Item key="user">
                        退出
                    </Menu.Item>
                </SubMenu>
            </Menu>
        );
    }
}


export default AidNav;
