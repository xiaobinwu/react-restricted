import React, { Component } from 'react';
import { Route, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import { Spin } from 'antd';
import { userService } from 'service';
import store from 'rRedux/store';

// 登录状态认证组件
class AuthorizedRoute extends Component {
    componentDidMount() {
        // 获取用户信息
        this.init();
    }
    init = async () => {
        const { entry, code } = await userService.getUserInfo();
        if (code === 0) {
            store.dispatch({
                type: 'SET_LOGGED_USER',
                logged: true,
                username: entry.admin
            });
        }
    }
    render() {
        const {
            component: AuthComponent,
            pending,
            logged,
            ...rest
        } = this.props;
        return (
            <Route {...rest} render={(props) => {
                if (pending) {
                    return (
                        <Spin size="large" tip="Loading..." style={{ minHeight: '100%' }}>
                            <div style={{
                                minHeight: '800px',
                                height: '100vh'
                            }}>
                            </div>
                        </Spin>
                    );
                }
                return logged ? (<AuthComponent {...props} />) : (<Redirect to="/auth" />);
            }} />
        );
    }
}

// 将state通过connect包装AuthorizedRoute组件，达到state以props方式传入组件
const stateToProps = ({ userState }) => ({
    pending: userState.pending,
    logged: userState.logged
});

export default connect(stateToProps)(AuthorizedRoute);
