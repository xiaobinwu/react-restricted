import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import store from 'rRedux/store';
import { registerTheme } from 'echarts';
import theme from 'themes/echart/macarons';

// import registerServiceWorker from 'src/registerServiceWorker';

import 'antd/dist/antd.css';

import Auth from 'pages/auth';
import BaseLayout from 'pages/baseLayout';
import AuthorizedRoute from './authorizedRoute';

// 默认ehart主题
registerTheme('macarons', theme);

if (module.hot) {
    module.hot.accept();
}

class App extends Component {
    render() {
        return (
            <Provider store={store}>
                <BrowserRouter>
                    <Switch>
                        <Route path="/auth" component={Auth} />
                        <AuthorizedRoute path="/" component={BaseLayout} />
                    </Switch>
                </BrowserRouter>
            </Provider>
        );
    }
}

ReactDOM.render(
    <App />,
    document.getElementById('root')
);

// registerServiceWorker();
