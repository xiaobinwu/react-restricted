/**
 * Created by Liu.Jun on 2018/11/9.
 */

export default {
    title: 'GB 前端团队服务平台'
};
