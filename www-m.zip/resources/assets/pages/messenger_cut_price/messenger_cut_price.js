import 'js/lib/zepto/fx.js';
import 'js/bootstrap';

import Swiper from 'js/lib/swiper.js';
import layer from 'layer';
import { calcRemToPx } from 'js/utils';
import PubSub from 'pubsub-js';
import Timer from 'component/timer/timer';
import isLogin from 'js/core/user/isLogin';

import 'modules/header/header.js';
import 'modules/footer/footer.js';

import './messenger_cut_price.css';
import { trans } from '../../common/js/core/translate.js';

const $win = $(window);
const mIsLogin = isLogin();
const { DOMAIN_LOGIN } = GLOBAL;

// 更新货币
PubSub.publish('sysUpdateCurrency', {
    context: $('#app')[0]
});

// banner 轮播
function bannerSwiper() {
    if ($('.js-cutPriceSwiper').find('.swiper-slide').length > 1) {
        new Swiper('.js-cutPriceSwiper', {
            loop: true,
            // width: window.innerWidth,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
            },
            lazy: {
                loadPrevNext: true
            },
        });
    }
}
bannerSwiper();

// 怎么玩弹窗
$('.js-howPlayBtn').on('tap', () => {
    howplayer();
});
function howplayer() {
    layer.open({
        content: $('#js-howPlay')[0].outerHTML,
        className: 'play_info',
        btn: 'OK',
        closeBtn: 0,
        shadeClose: false,
    });
}

// 列表滚动事件
const $bargainersDiv = $('.js-bargainers');
const $ul = $bargainersDiv.find('ul');
if ($ul.height() > $bargainersDiv.height()) {
    marquee($ul, 40);
}
function marquee(obj, _speed) {
    let top = 0;
    let margintop;
    setInterval(() => {
        top += calcRemToPx(1);
        margintop = 0 - top;
        obj.animate({
            marginTop: margintop
        }, 0, function animation() {
            const s = Math.abs(parseInt($(this).css('margin-top'), 10));
            if (s >= calcRemToPx(100)) {
                top = 0;
                const $this = $(this);
                $this.css('margin-top', 0); // 确保每次都是从0开始，避免抖动
                $this.find('li').slice(0, 2).appendTo($(this));
            }
        });
    }, _speed);
}

// 普通版块 Deals 切换
const categorySwiper = new Swiper('#js-categorySwiper', {
    slidesPerView: 'auto',
    watchSlidesProgress: true,
    watchSlidesVisibility: true,
    on: {
        tap() {
            categoryContentSwiper.slideTo(categorySwiper.clickedIndex);
        }
    }
});
const categoryContentSwiper = new Swiper('#js-categoryContentSwiper', {
    autoHeight: true,
    touchMoveStopPropagation: true,
    on: {
        slideChangeTransitionStart() {
            updateNavPosition();
            PubSub.publish('sysUpdateLazyload');
        }
    }
});
function updateNavPosition() {
    $('#js-categorySwiper .active').removeClass('active');
    const activeNav = $('#js-categorySwiper .swiper-slide').eq(categoryContentSwiper.activeIndex).addClass('active');
    if (!activeNav.hasClass('swiper-slide-visible')) {
        categorySwiper.slideTo(activeNav.index());
    }
}

// 无砍价商品隐藏对应tab
const cateGoodsTab = $('.js-cateGoodsTab');
const commonTab = $('.js-commonTab');
if (cateGoodsTab.length === 1) {
    cateGoodsTab.closest('#js-catepriceSwiper').hide();
}
if (commonTab.length === 1) {
    commonTab.closest('#js-categorySwiper').hide();
}

// 砍价版块 Deals 切换
const catepriceSwiper = new Swiper('#js-catepriceSwiper', {
    slidesPerView: 'auto',
    watchSlidesProgress: true,
    watchSlidesVisibility: true,
    on: {
        tap() {
            catepriceContentSwiper.slideTo(catepriceSwiper.clickedIndex);
        }
    }
});
const catepriceContentSwiper = new Swiper('#js-catepriceContentSwiper', {
    autoHeight: true,
    touchMoveStopPropagation: true,
    on: {
        slideChangeTransitionStart() {
            cutNavPosition();
            PubSub.publish('sysUpdateLazyload');
        }
    }
});
function cutNavPosition() {
    $('#js-catepriceSwiper .active').removeClass('active');
    const cutNav = $('#js-catepriceSwiper .swiper-slide').eq(catepriceContentSwiper.activeIndex).addClass('active');
    if (!cutNav.hasClass('swiper-slide-visible')) {
        catepriceSwiper.slideTo(cutNav.index());
    }
}

// 加入购物车
$('.js-addToCart').on('tap', (e) => {
    const $this = $(e.currentTarget);
    PubSub.publish('sysAddToCart', {
        goods: {
            goodsSn: $this.attr('data-goodssn'),
            warehouseCode: $this.attr('data-warehousecode'),
            qty: 1,
        }
    });
});

// view more
$('.cateprice_cViewMore').on('click', (e) => {
    const $this = $(e.currentTarget);
    const catepriceContent = $this.closest('.cateprice_content');
    const $more = catepriceContent.find('.js-more');
    if (!$this.hasClass('show')) {
        $this.addClass('show');
        $this.children('span').html(trans('promotion.view_less'));
        $more.css('display', 'block');
    } else {
        const distance = $win.scrollTop() - $more.height();
        $this.removeClass('show');
        $this.children('span').html(trans('promotion.view_more'));
        $more.css('display', 'none');
        $win.scrollTop(distance);
    }
});


// 普通商品版块的buy now按钮跳转订单确认页
$(document).on('click', '.js-jumpOrder', async (e) => {
    if (mIsLogin) {
        const $this = $(e.currentTarget);
        const GOODSDATA = {
            goodsSn: $this.attr('data-goodssn'),
            warehouseCode: $this.attr('data-warehousecode'),
            price: $this.attr('data-price'),
            qty: 1,
        };
        PubSub.publish('sysBuyNow', {
            goods: [GOODSDATA],
        });
    } else {
        window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
    }
});

// 砍价版块倒计时
const timer = new Timer();
timer.add('.js-catePriceCutDown', {
    format: `${trans('promotion.start_in')} {dd}:{hh}:{mm}:{ss}`,
    interval: 'begin',
    onStart(target) {
    },
    onEnd(target) {
        timer.add(target, {
            format: `${trans('promotion.ends_in')} {dd}:{hh}:{mm}:{ss}`,
            interval: 'end',
        });
    },
});

// 关闭弹窗
$(document).on('tap', '.layer_content > .icon-closed', (e) => {
    layer.closeAll();
});

// 回到顶部
const $btnGoTop = $('#js-btnGoTop');

const btnToTop = {
    init() {
        this.bindEvent();
    },
    bindEvent() {
        $btnGoTop.on('tap', (e) => {
            this.goTop();
        });
        $(window).scroll(() => {
            this.goTopHandle();
        });
    },
    // 返回顶部显隐处理
    goTopHandle() {
        const currentScrollTop = $(window).scrollTop();
        if (currentScrollTop >= 60) {
            $btnGoTop.addClass('show');
        } else {
            $btnGoTop.removeClass('show');
        }
    },
    goTop() {
        $(window).scrollTop(0);
    }
};
btnToTop.init();
