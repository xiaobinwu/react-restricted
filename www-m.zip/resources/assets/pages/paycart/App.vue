<template lang="pug">
    .paycart_contain(:class="showApp")
        transition(name="avalon")
            #skeleton.skeleton(v-if="!showApp")
                #skeleton_cartimg.block
                #skeleton_cartTit.block
                ul.skeleton_cartUl
                    li.skeleton_cartItem.block(v-for="item in 6")
        router-view

</template>

<script>

    import PubSub from 'pubsub-js';

    export default {
        name: 'app',
        data() {
            return {
                showApp: '',
            };
        },
        created() {
            const vm = this;
            // 监听底部切换币种change事件
            PubSub.subscribe('sysUpdateCurrency', (msg, data) => {
                if (data !== undefined && data.currencyCode !== undefined) {
                    vm.$root.currenySign = data.currencyCode;
                }
            });
        },
        methods: {
            show() {
                this.showApp = 'showApp';
            }
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    @import 'common/css/skeleton.css';
    /* 购物车页面隐藏头部内容 */
    .paycart_step-1 .topHeader{
        display: none;
    }

    /* 结算页隐藏底部内容 */
    .paycart_step-2 .siteFooter {
        display: none;
    }
    .paycart_step-2 #skeleton {
        z-index: 8;
        margin-bottom: 0;
    }
    .paycart_step-2 #skeleton:before {
        content: '';
        position: fixed;
        bottom: 0;
        top: 0;
        left: 50%;
        margin-left: -5rem;
        width: 10rem;
        background: var(--color-main-bg);
    }
    .paycart_step-2 .showApp #skeleton:before {
        content: none;
    }

    #skeleton{
        padding:0 0 1.3rem 0;
        overflow: hidden;
        z-index: 10;
        margin-bottom: rem(20);
    }

    #skeleton_cartimg{
        width: 92%;
        height: 3rem;
        margin:.4rem auto .2rem;
    }
    #skeleton_cartTit{
        width: 3.7rem;
        height: .5rem;
        margin:.6rem auto .4rem;
    }
    .skeleton_cartUl{
        width: 96%;
        margin:0 auto;
    }
    .skeleton_cartItem{
        display: inline-block;
        vertical-align: top;
        width: 46%;
        height: 3rem;
        margin:0 2% .3rem;
    }

    .avalon-enter-active, .avalon-leave-active {
        transition: opacity .2s;
    }
    .avalon-enter, .avalon-leave-active {
        opacity: 0;
    }
</style>
