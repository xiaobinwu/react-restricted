
import staticAsset from 'js/core/staticAsset';
import { throttle } from 'js/utils';

export default (Vue, options = {}) => {
    let config = {
        retry: false,
        preload: 100,
        throttleWait: 300,
        preClass: 'load_err',
        loading: 'icon-loading',
        error: staticAsset('/img/site/error_img@.png')
    };

    config = Object.assign({}, config, options);

    const listenList = {};

    const loadEnd = (el) => {
        const parent = el.parentNode;
        if (parent.classList.contains(config.loading)) {
            parent.classList.remove(config.loading);
        }
    };

    // 检测图片是否可以加载，如果可以则进行加载
    const isCanShow = (el) => {
        const imgsrc = el.getAttribute('data-img');
        // 图片距离页面顶部的距离
        const elTop = el.getBoundingClientRect().top;
        // 页面可视区域的高度
        const windowHeight = window.innerHeight;
        // elTop - config.preload 已经提前进入了可视区域config.preload像素
        if (elTop - config.preload < windowHeight) {
            const image = new Image();
            image.src = imgsrc;
            image.onload = () => {
                el.src = imgsrc;
                el.classList.remove(config.preClass);
                loadEnd(el);
            };
            image.onerror = () => {
                el.src = config.error;
                el.classList.add(config.preClass);
                loadEnd(el);
            };
            return true;
        }
        return false;
    };

    const throttleFn = throttle(() => {
        if (JSON.stringify(listenList) !== '{}') {
            for (const key in listenList) {
                isCanShow(listenList[key]);
            }
        }
    }, config.throttleWait);

    window.addEventListener('scroll', throttleFn, false);

    // Vue 指令最终的方法
    const addListener = (el) => {
        const itemId = el.getAttribute('data-id');

        if (el.getAttribute('width')) {
            el.removeAttribute('width');
        }
        if (el.getAttribute('height')) {
            el.removeAttribute('height');
        }
        // 如果已经加载过，则无需重新加载，直接将src赋值(组件更新顺序时有问题)
        /* if (isAlredyLoad(imageSrc)) {
            el.src = imageSrc;
            return false;
        } */

        // 看看是否可以显示此图片
        if (isCanShow(el)) {
            return false;
        }
        // 否则将图片地址和元素均放入监听的lisenList里
        listenList[itemId] = el;
        return false;
    };

    Vue.directive('lazy', {
        inserted: addListener,
        componentUpdated: addListener,
    });
};
