<template lang="pug">

</template>

<script>
    export default {
        name: 'quickpay',
        methods: {
            // post请求跳转页面
            standardPost(url, args) {
                const formEl = document.createElement('form');
                formEl.method = 'post';
                formEl.action = url;
                // args.push({ name: '_token', value: $('meta[name="csrf-token"]').attr('content') });
                const inputStr = `
                    ${args.map(im => `
                        <input type="hidden" name="${im.name}" value="${im.value}">
                    `).join('')}
                `;
                formEl.innerHTML = inputStr;
                document.getElementsByTagName('body')[0].appendChild(formEl);
                formEl.submit();
                // document.getElementsByTagName('body')[0].removeChild(formEl);
            }
        },
        created() {
            const vm = this;
            // 保存当前页面上的值
            if (window.payVars.addressId) {
                vm.standardPost(`${GLOBAL.DOMAIN_ORDER}/checkout/index`, [
                    { name: 'addressId', value: window.payVars.addressId },
                    { name: 'isQuickPay', value: window.payVars.isQuickPay },
                    { name: 'quickPayToken', value: window.payVars.quickPayToken }
                ]);
            } else {
                const { DOMAIN_USER } = GLOBAL;
                // 去个人中心(确认订单页的标识)
                if (+window.payVars.isQuickPay === 1) {
                    // eslint-disable-next-line
                    window.location.href = `${DOMAIN_USER}/index#/cart/address?from=isQuickPay_${window.payVars.quickPayToken}&paypalInfo=1&token=${window.payVars.quickPayToken}`;
                } else if (+window.payVars.isQuickBuy === 1) {
                    window.location.href = `${DOMAIN_USER}/index#/cart/address?from=isQuickBuy`;
                } else {
                    window.location.href = `${DOMAIN_USER}/index#/cart/address?from=checkout`;
                }
            }
        }
    };
</script>