<template lang="pug">
    label.vue_checkbox(@touchstart.stop.prevent="startTime($event)", @touchend.stop.prevent="changeChecked($event)", @click.stop.prevent="changeChecked($event, 'click')", :class="isradio ? 'isradio' : 'ischeckbox'")
        span.vue_checkboxShape(:class="checkedThis === 0 ? 'icon-radiobox': (checkedThis === 1 ? (isradio ? 'icon-radio_checked' : 'icon-tick') : 'icon-radiobox_disabled')")
        span.vue_checkboxLabel(v-if="label", v-html="label")
</template>

<script>
    export default {
        /* eslint-disable */
        name: 'checkbox',
        props: {
            checked: 0,                         // 0: 可选   1: 选中   2: 禁用
            eventName: {                        // 触发事件的事件名
                default: 'checkboxSelected'
            },
            label: String,                      // 文案
            checkId: [String, Number],          // 组件id (可为列表坐标 / 数据驱动key)

            isradio: {                          // 样式   0：为checkbox 1：为radio单选
                default: 0,
            },
            autoReverse: false,                 // 自动反选状态
            checkData: Object,                  // 聚合数据 - 默认级 驱动数据
            associatedData: [Object, Array],    // 聚合数据 - 单选级 数据驱动（radio）
            mustCheck: {                        // radio 状态是否必须选中1个
                default: 0
            },
            inputName: '',                      // 类似原生input name属性
            dataKey: {                          // radio 数据中定位键值
                default: ''
            },
        },
        data() {
            return {
               startT: '',
               checkedThis: 0,
               mustCheckThis: 0,
            }
        },
        watch: {
            checked: {
                handler() {
                    this.checkedThis = this.checked;
                },
                deep: true
            }
        },
        /* eslint-enable */
        created() {
            const vm = this;
            vm.checkedThis = vm.checked;
            vm.mustCheckThis = vm.mustCheck;
            if (vm.associatedData) {
                if (!vm.mustCheckThis) {
                    vm.mustCheckThis = 1;
                }
            }
        },
        methods: {
            startTime(ev) {
                const vm = this;
                vm.startT = +new Date();
            },
            changeChecked(ev, eventName) {
                const vm = this; // 这里用v-finger有坑：多次点击敏感品或者预售商品时会不执行, 还会导致确认订单页弹窗无法多次弹出
                const endT = +new Date();
                if (eventName !== 'click' && endT - vm.startT > 250) return;
                if (+vm.checkedThis !== 2) {
                    if (vm.associatedData) {
                        // 多级联动数据处理
                        // 默认必须选中1个
                        if (+vm.mustCheckThis === 1 && vm.checkedThis) return;

                        for (const associatedItem in vm.associatedData) {
                            if (`${associatedItem}` === `${vm.checkId}`) {
                                vm.associatedData[associatedItem].isChecked = +!vm.associatedData[associatedItem].isChecked;
                            } else {
                                vm.associatedData[associatedItem].isChecked = 0;
                            }
                        }

                        vm.$bus.$emit(vm.eventName, {
                            checkId: vm.checkId,
                            inputName: vm.inputName,
                            associatedData: vm.associatedData,
                        });
                    } else { // 普通级checkbox事件
                        if (vm.autoReverse) {
                            vm.checkedThis = +!vm.checkedThis;
                        }

                        vm.$bus.$emit(vm.eventName, {
                            checkId: vm.checkId,
                            checked: vm.checkedThis,
                            checkData: vm.checkData,
                        });
                    }
                }
            }
        }
    };
</script>
