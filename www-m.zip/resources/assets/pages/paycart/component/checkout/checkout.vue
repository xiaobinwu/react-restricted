<template lang="pug">
    .checkout_page(v-if="PD.groupList.length > 0")
        //- 头部操作栏
        headnav(:headerConfig="headerConfig")

        //- 头部折扣标
        headdiscount

        //- 展示用户当前选中地址
        showaddress(:addressInfo="DS.addressInfo", :toEditAddress="toEditAddress")

        //- 订单列表展示及结算
        orderlist(:DS="DS", :PD="PD")

</template>

<script>
    import {
        serviceCheckoutGetCounponList,
        serviceGetPayRelate,
        serviceCheckoutPageData,
        serviceInsuranceType,
        serviceCheckoutQueryTax,
        serviceGetCategoryInfo,
        serviceGetShopList,
    } from 'js/service/paycart';
    import PubSub from 'pubsub-js';
    import { serviceGetAddressRule } from 'js/service/user';
    import { add, multiply } from 'js/core/currency';
    import { dateFormat } from 'js/utils';
    import { CheckoutTrack } from 'js/track/define/paycart'; // 大数据埋点

    // 预加载支付
    import preLoadPay from 'js/core/preload/preLoadPay.js';

    import headnav from './head_nav.vue';
    import headdiscount from './head_discount.vue';
    import showaddress from './show_address.vue';
    import orderlist from './order_list.vue';
    import secondaddress from './second_address.vue';

    export default {
        name: 'checkout',
        components: {
            headnav,
            headdiscount,
            showaddress,
            orderlist,
        },
        data() {
            return {
                headerConfig: { // 配置页面头部参数
                    isShow: true,
                    title: this.$trans('order.shipping_information'),
                    btn: {
                        left: {
                            href: `${GLOBAL.DOMAIN_CART}/cart/index`
                        }
                    }
                },
                DS: { // defaultSet
                    addressId: window.payVars.addressId, // 用户地址id
                    addressInfo: window.payVars.addressInfo, // 用户地址信息
                    isQuickBuy: window.payVars.isQuickBuy, // 一键购标识
                    isQuickPay: window.payVars.isQuickPay, // 快捷支付标识
                    quickPayToken: window.payVars.quickPayToken, // 快捷支付token
                    isVisitor: window.payVars.isVisitor, // 快捷购物 - 访客模式
                    couponCode: '', // 用户使用优惠券
                    integralNum: 0, // 用户使用积分
                    payChannelType: 1, // 1、线上支付方式(走支付平台模式)；2、cod(货到付款)；
                },
                PD: { // pageData
                    verifyRulesList: [], // 当前地址国家对应的地址规则列表
                    couponList: [], // 用户优惠券列表
                    discountList: [], // 快捷支付折扣信息
                    btsInfo: {}, // bts 数据
                    groupList: [], // 结算数据
                    total: {}, // 结算公共数据
                    shopInfo: {}, // 店铺信息
                    taxPriceTitle: this.$trans('order.tax_price'), // 税费名称
                    codShipping: {}, // cod 已有订单信息
                    taxSign: 0, // 税费接口调用计数
                },
            };
        },
        methods: {
            // ----- 逻辑处理流程 -----
            async firstStage() { // 第一阶段逻辑处理
                const vm = this;
                const fristDataArr = await Promise.all([
                    vm.getVerifyRules(vm.DS.addressInfo.countryCode),
                    vm.getCouponList(vm.DS.isVisitor),
                    vm.DS.isQuickPay ? vm.getPayRelate() : {}
                ]);
                // 地址规则校验拦截
                if (fristDataArr[0].status === 0) {
                    vm.PD.verifyRulesList = fristDataArr[0].data.list;
                    if (vm.verifyRules(vm.PD.verifyRulesList, vm.DS.addressInfo)) { // 验证不通过
                        vm.errorAlert({ type: 'addressVerify' });
                        return;
                    }
                }
                // 默认使用第一个优惠券
                if (fristDataArr[1].data && fristDataArr[1].data.length > 0) {
                    vm.PD.couponList = fristDataArr[1].data;
                    // vm.DS.couponCode = fristDataArr[1].data[0].couponCode;
                }
                // 挂载支付折扣信息
                if (fristDataArr[2].status === 0) vm.PD.discountList = fristDataArr[2].data.discountInfo;
                vm.secondStage();
            },
            async secondStage(reqData) { // 第二阶段逻辑处理
                const vm = this;
                // 组装请求参数
                const { status, data, msg } = await vm.getCheckoutData(vm.createdReq(reqData), vm.PD.groupList.length > 0);
                if (status !== 0) {
                    vm.errorAlert({ type: 'checkoutData', data, msg });
                } else {
                    vm.PD.total = data.total;
                    vm.PD.codShipping = {
                        num: data.codShippingNum || 0,
                        limit: data.codShippingLimit || 0,
                        forceCurrency: data.codForceCurrency || {}
                    };
                    const isFirst = !vm.PD.groupList.length > 0;
                    // 定金膨胀或访客模式拦截cod
                    if (vm.DS.isVisitor || vm.PD.total.advanceSwellInfo || vm.DS.isQuickPay) {
                        vm.PD.total.codTag = 0;
                    }
                    if (isFirst) {
                        // 首次载入数据完成关闭骨架屏
                        vm.$parent.show();
                        // 初始化数据
                        vm.PD.groupList = data.groupList;
                    } else {
                        const tepGroupList = data.groupList;
                        // 保存上一次操作状态
                        tepGroupList.forEach((groupItem, groupIndex) => {
                            // 添加默认保险字段
                            groupItem.logisticsInfo.inssuranceSelected = vm.PD.groupList[groupIndex].logisticsInfo.inssuranceSelected;
                            // 保持物流方式
                            groupItem.logisticsInfo.logisticsGroupList.forEach((logGroupItem, logGroupIndex) => {
                                logGroupItem.isDefault = vm.PD.groupList[groupIndex].logisticsInfo.logisticsGroupList[logGroupIndex].isDefault;

                                if (logGroupItem.logisticsModeList.length) {
                                    logGroupItem.logisticsModeList.forEach((logModeItem, logModeIndex) => {
                                        logModeItem.isDefault = vm.PD.groupList[groupIndex].logisticsInfo.logisticsGroupList[logGroupIndex].logisticsModeList[logModeIndex].isDefault; // eslint-disable-line
                                    });
                                }
                            });
                        });
                        vm.PD.groupList = tepGroupList;
                        // 优惠券使用默认需要提示
                        if (vm.PD.total.couponMessage !== '') {
                            vm.$toast({ msg: vm.couponMsg(vm.PD.total.couponMessage) });
                        }
                    }
                    // 根据当前payChannelType过滤物流方式
                    vm.filterLogMode();
                    // 选择物流方式
                    vm.useCurrentLogMode();
                    // 店铺名称组装
                    vm.shopNameMonted(isFirst);

                    // 埋点及第三方逻辑 - 只在首次数据载入后处理
                    if (isFirst) {
                        window.onloadOk = true;
                        // 大数据埋点
                        new CheckoutTrack({ page: true }).run();
                        // 第三方相关(GTM) 数据挂载
                        vm.mountData(data);
                    }
                }
            },
            // ----- 第三阶段 后续支线任务处理 -----
            async shopNameMonted(isFirst) {
                const vm = this;
                // 组装店铺信息查询
                const shopCodesArr = [];
                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    groupItem.shopList.forEach((shopItem, shopIndex) => {
                        if (!vm.PD.shopInfo[shopItem.shopInfo.shopCode] || !vm.PD.shopInfo[shopItem.shopInfo.shopCode].shopCode) {
                            vm.PD.shopInfo[shopItem.shopInfo.shopCode] = {};
                            if (!shopCodesArr.some(item => item === shopItem.shopInfo.shopCode)) shopCodesArr.push(shopItem.shopInfo.shopCode);
                        }
                    });
                });
                if (shopCodesArr.length > 0) {
                    const { status, data } = await vm.getShopInfo(shopCodesArr.join(','));
                    if (status === 0) vm.PD.shopInfo = data;
                }
                // 挂载店铺数据
                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    groupItem.shopList.forEach((shopItem, shopIndex) => {
                        if (vm.PD.shopInfo[shopItem.shopInfo.shopCode] && vm.PD.shopInfo[shopItem.shopInfo.shopCode].shopName) {
                            shopItem.shopInfo.shopName = vm.PD.shopInfo[shopItem.shopInfo.shopCode].shopName;
                        }
                    });
                });
                // 默认保费选择
                vm.insuranceSelect(isFirst);
            },
            async insuranceSelect(isFirst) { // 保险默认勾选
                const vm = this;
                if (isFirst) {
                    const { status, data } = await vm.getInsuranceType(vm.DS.addressInfo.countryCode, vm.PD.total.goodsAmount);
                    if (status === 0) {
                        vm.PD.groupList.forEach((groupItem, groupIndex) => {
                            groupItem.logisticsInfo.inssuranceSelected = data.inssuranceSelected;
                            groupItem.logisticsInfo.isInssuranceForceSelected = data.isInssuranceForceSelected;
                        });
                    }
                }
                // 价格变动请求税费
                vm.fillTaxFree();
            },
            async fillTaxFree() { // 根据物流方式请求税费
                const vm = this;
                const taxOrderListData = [];
                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    // 定金膨胀优惠项组装
                    let depSwell = 0;
                    groupItem.shopList.forEach((shopItem, shopIndex) => {
                        shopItem.goodsList.forEach((goodsItem, goodsIdnex) => {
                            depSwell = add(depSwell, multiply((goodsItem.skuAdvanceDetail ? goodsItem.skuAdvanceDetail.swellDiscontAmount : 0), goodsItem.qty)); // eslint-disable-line
                            goodsItem.accessoryList.forEach((accessoryItem, accessoryIndex) => {
                                depSwell = add(depSwell, multiply((accessoryItem.skuAdvanceDetail ? accessoryItem.skuAdvanceDetail.swellDiscontAmount : 0), accessoryItem.qty)); // eslint-disable-line
                            });
                        });
                    });

                    // 组装税费查询数据
                    taxOrderListData.push({
                        realWhCode: groupItem.logisticsInfo.realWarehouseCode,
                        goodsGroupId: groupItem.logisticsInfo.goodsGroupId,
                        orderPrice: groupItem.groupInfo.deliveryType === 0 ? add([
                            groupItem.groupInfo.totalGoodsAmount,
                            -groupItem.groupInfo.integralDeductAmount,
                            -groupItem.groupInfo.couponDeductAmount,
                            -groupItem.groupInfo.activityDeductAmount,
                            groupItem.logisticsInfo.defaultLogObj.logPrice,
                            (groupItem.logisticsInfo.inssuranceSelected ? groupItem.logisticsInfo.inssuranceAmount : 0),
                            -depSwell,
                            groupItem.logisticsInfo.defaultLogObj.codFee,
                        ]) : 0,
                    });
                });
                const { status, data } = await vm.getTaxPrice(vm.DS.addressInfo.countryCode, taxOrderListData);
                vm.PD.taxSign += 1;
                if (status === 0) {
                    vm.PD.groupList.forEach((groupItem, groupIndex) => {
                        groupItem.logisticsInfo.defaultLogObj.taxPrice = data.taxList[groupIndex].taxPrice;
                    });
                    vm.PD.taxPriceTitle = data.taxList[0].name ? data.taxList[0].name : vm.PD.taxPriceTitle;
                }
                window.stable = true;
            },
            // ----- 处理方法 -----
            createdReq(data) { // 格式化请求数据
                const vm = this;
                if (data) {
                    vm.DS.integralNum = data.integralNum;
                    vm.DS.couponCode = data.couponCode;
                }
                return JSON.parse(JSON.stringify(Object.assign({
                    addressId: vm.DS.addressId || undefined,
                    isQuickPay: vm.DS.isQuickPay || undefined,
                    integralNum: vm.DS.integralNum || undefined,
                    couponCode: vm.DS.couponCode || undefined,
                }, data)));
            },
            verifyRules(rulesList, addressInfo) { // 根据地址配置规则校验地址
                let flag = 0; // 验证结果类型：0、验证通过；1、值为空；2、正则匹配不正确；3、国家、省份错误字段为空；
                if (!addressInfo.countryCode || !addressInfo.provinceCode) flag = 3; // 校验国家字段
                if (!flag) { // 根据接口匹配其他字段
                    rulesList.forEach((rulesItem) => {
                        const addressItem = addressInfo[rulesItem.address_name];
                        if (!flag) {
                            if (!rulesItem.is_require && addressItem.length) { // 非必填字段
                                if (rulesItem.regex) flag = new RegExp(rulesItem.regex).test(addressItem) ? 0 : 2;
                            } else if (rulesItem.is_require) { // 必填字段
                                flag = !addressItem.length ? 1 : rulesItem.regex ? (!new RegExp(rulesItem.regex).test(addressItem) ? 2 : 0) : 0;
                            }
                        }
                    });
                }
                return flag;
            },
            toEditAddress() { // 去编辑地址
                const vm = this;
                const { DOMAIN_USER } = window.GLOBAL;
                // 去个人中心(确认订单页的标识)
                if (vm.DS.isVisitor) {
                    window.location.href = '/checkout/address/index#/cart/address?from=checkout';
                } else if (+vm.DS.isQuickPay === 1) {
                    window.location.href = `${DOMAIN_USER}/index#/cart/address?from=isQuickPay_${vm.DS.quickPayToken}`;
                } else if (+vm.DS.isQuickBuy === 1) {
                    window.location.href = `${DOMAIN_USER}/index#/cart/address?from=isQuickBuy`;
                } else {
                    window.location.href = `${DOMAIN_USER}/index#/cart/address?from=checkout`;
                }
            },
            filterLogMode() { // 根据当前选择的支付方式筛选物流 并 设置默认物流方式
                const vm = this;
                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    let yesIsDefault = 0;
                    groupItem.logisticsInfo.logisticsGroupList.forEach((logGroupItem, logGroupIndex) => {
                        // 判断当前组是否有子物流方式
                        if (logGroupItem.logisticsModeList.length) {
                            let childrShowSign = 0;
                            let cleanIsDefault = 0;
                            logGroupItem.logisticsModeList.forEach((logModeItem, logModeIndex) => {
                                const isShow = vm.DS.payChannelType === 1 ? (
                                    logModeItem.codType === 1 || logModeItem.codType === 2
                                ) : (
                                    logModeItem.codType === 3 || logModeItem.codType === 2
                                );
                                vm.$set(logModeItem, 'isShow', isShow);
                                if (isShow) childrShowSign += 1;
                                if (logModeItem.isDefault && !isShow) {
                                    logModeItem.isDefault = 0;
                                    cleanIsDefault += 1;
                                }
                            });
                            vm.$set(logGroupItem, 'isShow', childrShowSign > 0);
                            if (logGroupItem.isDefault && cleanIsDefault) logGroupItem.isDefault = 0;
                        } else {
                            vm.$set(logGroupItem, 'isShow', vm.DS.payChannelType === 1);
                            if (logGroupItem.isDefault && !logGroupItem.isShow) logGroupItem.isDefault = 0;
                        }
                        if (logGroupItem.isDefault) yesIsDefault += 1;
                    });
                    // 重新设置默认物流
                    if (!yesIsDefault) {
                        groupItem.logisticsInfo.logisticsGroupList.forEach((logGroupItem, logGroupIndex) => {
                            if (logGroupItem.isShow && !groupItem.logisticsInfo.logisticsGroupList.some(item => item.isDefault)) {
                                logGroupItem.isDefault = 1;
                                // 判断当前组是否有子物流方式
                                if (logGroupItem.logisticsModeList.length) {
                                    logGroupItem.logisticsModeList.forEach((logModeItem, logModeIndex) => {
                                        if (logModeItem.isShow && !logGroupItem.logisticsModeList.some(item => item.isDefault)) {
                                            logModeItem.isDefault = 1;
                                        }
                                    });
                                }
                            }
                        });
                    }
                });
            },
            useCurrentLogMode() { // 保存物流使用状态
                const vm = this;
                const checkTypeArr = [];

                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    vm.$set(groupItem.logisticsInfo, 'isShowInssuranceTip', false);
                    /* eslint-disable */
                    vm.$set(groupItem.logisticsInfo, 'defaultLogObj', {
                        logName: '',            // 物流方式名称
                        logTime: '',            // 物流时间
                        logPrice: 0,            // 物流费用
                        logCode: '',            // 物流码
                        checkType: 3,           // 是否验证第二地址
                        recommendPriority: 0,   // 物流类型
                        remoteFee: 0,           // 是否包含偏远费用
                        logGroupId: '',         // 物流分组ID
                        coordinate: [],         // 当前坐标
                        isTariffTip: 0,         // 是否展示关税提示语
                        tariffTip: vm.$trans('order.logistics_tariff_tip'), // 关税提示语
                        taxPrice: 0, // 当前子订单税费(根据当前物流方式获取)
                        shippingFeeType: 1, // 运费类型
                        feeShippingDiff: 0, // 免邮差额
                        codFee: 0, // cod手续费
                        tips: '', // 关税提示
                    });
                    /* eslint-enable */

                    // 临时校验关税提示条件
                    const tariffCountry = [
                        'FR', 'DE', 'IT', 'NL', 'BE', 'LU', 'DK', 'IE', 'GB', 'GR',
                        'ES', 'PT', 'AT', 'FI', 'SE', 'PL', 'CZ', 'HU', 'SK', 'SI',
                        'CY', 'MT', 'LV', 'LT', 'EE', 'BG', 'RO', 'HR'
                    ];
                    const tariffSticsMode = [
                        'CNDHL', 'DHLEXPEB', 'CNDHLR', 'HKDHLSZ', 'CNDHLEU', 'ATDHL',
                        'HKDHLYD', 'CNDHLPLUS', 'HKDHL', 'HKDHLYDHK', 'HKDHLYDQH'
                    ];

                    groupItem.logisticsInfo.logisticsGroupList.forEach((logGroupItem, logGroupIndex) => {
                        vm.$set(logGroupItem, 'isChecked', logGroupItem.isDefault);

                        // 判断当前组是否有子物流方式
                        if (logGroupItem.logisticsModeList.length) {
                            logGroupItem.logisticsModeList.forEach((logModeItem, logModeIndex) => {
                                vm.$set(logModeItem, 'isChecked', logModeItem.isDefault);

                                if (logGroupItem.isDefault && logModeItem.isDefault) {
                                    groupItem.logisticsInfo.defaultLogObj.logName = logModeItem.logisticsName;
                                    groupItem.logisticsInfo.defaultLogObj.logTime = logModeItem.deliveryTime;
                                    groupItem.logisticsInfo.defaultLogObj.logPrice = logModeItem.logisticsFee;
                                    groupItem.logisticsInfo.defaultLogObj.logCode = logModeItem.logisticsCode;
                                    groupItem.logisticsInfo.defaultLogObj.checkType = logModeItem.checkType;
                                    groupItem.logisticsInfo.defaultLogObj.recommendPriority = logGroupItem.recommendPriority;
                                    groupItem.logisticsInfo.defaultLogObj.logGroupId = logGroupItem.groupId;
                                    groupItem.logisticsInfo.defaultLogObj.remoteFee = logModeItem.remoteFee;
                                    groupItem.logisticsInfo.defaultLogObj.coordinate = [logGroupIndex, logModeIndex];
                                    groupItem.logisticsInfo.defaultLogObj.shippingFeeType = logModeItem.shippingFeeType;
                                    groupItem.logisticsInfo.defaultLogObj.feeShippingDiff = logModeItem.feeShippingDiff;
                                    groupItem.logisticsInfo.defaultLogObj.codFee = vm.DS.payChannelType === 2 ? logModeItem.codFee : 0; // 非cod 时强制为0
                                    groupItem.logisticsInfo.defaultLogObj.tips = logModeItem.tips;
                                }

                            });
                        } else if (logGroupItem.isDefault) {
                            groupItem.logisticsInfo.defaultLogObj.logName = logGroupItem.groupName;
                            groupItem.logisticsInfo.defaultLogObj.logTime = logGroupItem.groupDeliveryTime;
                            groupItem.logisticsInfo.defaultLogObj.logPrice = logGroupItem.groupLogisticsFee;
                            groupItem.logisticsInfo.defaultLogObj.logCode = '';
                            groupItem.logisticsInfo.defaultLogObj.checkType = 3;
                            groupItem.logisticsInfo.defaultLogObj.recommendPriority = logGroupItem.recommendPriority;
                            groupItem.logisticsInfo.defaultLogObj.logGroupId = logGroupItem.groupId;
                            groupItem.logisticsInfo.defaultLogObj.remoteFee = 0;
                            groupItem.logisticsInfo.defaultLogObj.coordinate = [logGroupIndex];
                            groupItem.logisticsInfo.defaultLogObj.shippingFeeType = 1;
                            groupItem.logisticsInfo.defaultLogObj.feeShippingDiff = 0;
                            groupItem.logisticsInfo.defaultLogObj.codFee = 0;
                            groupItem.logisticsInfo.defaultLogObj.tips = '';
                        }
                    });
                    checkTypeArr.push(groupItem.logisticsInfo.defaultLogObj.checkType);

                    // 临时校验是否针对物流方式展示
                    if (
                        tariffCountry.some(item => item === vm.DS.addressInfo.countryCode)
                        &&
                        tariffSticsMode.some(item => item === groupItem.logisticsInfo.defaultLogObj.logCode)
                        &&
                        +groupItem.groupInfo.totalGoodsAmount >= 25.8
                    ) {
                        groupItem.logisticsInfo.defaultLogObj.isTariffTip = 1;
                    }
                });

                vm.secondAddress(checkTypeArr);
            },
            secondAddress(checkTypeArr) { // 物流校验地址弹窗展示 --- 0、不显示(接口原为3) 1、税号 2、护照 3、税号+护照号(原为不展示) 4、税号+护照号+颁发机构 5、税号+护照号+颁发机构+公民信息
                const vm = this;
                // 根据校验类型组装字段数据
                let checkArr = [];
                const type1 = ['taxNumber'];
                const type2 = ['middleName', 'passportSerial', 'passportNo', 'passportIssueDate'];
                const type4 = ['issuingAgency'];
                // const type5 = ['firstName', 'lastName', 'birthDay', 'citizenCode'];
                const type5 = ['firstName', 'lastName', 'birthDay'];
                if (checkTypeArr.some(item => item === 5)) { // 含有5
                    checkArr = type1.concat(type2, type4, type5);
                } else if (checkTypeArr.some(item => item === 4)) { // 含有4
                    checkArr = type1.concat(type2, type4);
                } else if (checkTypeArr.some(item => item === 2) && checkTypeArr.some(item => item === 1)) { // 含有 1 和 2
                    checkArr = type1.concat(type2);
                } else if (checkTypeArr.some(item => item === 2)) { // 只含有2
                    checkArr = type2;
                } else if (checkTypeArr.some(item => item === 1)) { // 只含有1
                    checkArr = type1;
                } else { // 全是3
                    checkArr = [];
                }
                if (checkArr.length <= 0) return;
                vm.$confirm({
                    customClass: 'secondAddressAlert',
                    shadowClose: false,
                    component: secondaddress,
                    componentData: {
                        checkArr,
                        addressInfo: vm.DS.addressInfo,
                        verifyRulesList: vm.PD.verifyRulesList,
                    },
                });
            },
            couponMsg(msg) {
                const reg = /%\$(\S*)%/g;
                msg = msg.replace(reg, (res, $1) => {
                    const formatDate = dateFormat($1);
                    return formatDate;
                });
                return msg;
            },
            // ----- 请求数据 -----
            getVerifyRules(countryCode) { // 请求后台配置验证规则
                return serviceGetAddressRule.http({
                    errorPop: true,
                    loading: false,
                    params: {
                        country: countryCode || 'all',
                    }
                });
            },
            getCouponList(isVisitor) { // 获取优惠券
                return isVisitor ? {} : serviceCheckoutGetCounponList.http({
                    loading: false,
                });
            },
            getPayRelate() { // 快捷支付折扣信息
                return serviceGetPayRelate.http({
                    loading: false,
                });
            },
            getCheckoutData(reqData, isLoading) { // 结算页数据
                return serviceCheckoutPageData.http({
                    data: reqData,
                    loading: Boolean(isLoading),
                });
            },
            getTaxPrice(countryCode, orderList) {
                return serviceCheckoutQueryTax.http({
                    loading: false,
                    data: {
                        countryCode,
                        orderList
                    }
                });
            },
            getInsuranceType(countryCode, goodsAmount) {
                return serviceInsuranceType.http({
                    errorPop: false,
                    loading: false,
                    data: {
                        countryCode,
                        goodsAmount
                    }
                });
            },
            getShopInfo(shopCodes) {
                return serviceGetShopList.http({
                    loading: false,
                    errorPop: false,
                    params: { shopCodes }
                });
            },
            // ----- 特殊方法 -----
            mountData(resData) { // 第三方相关 数据挂载
                // --- 组装接入 GTM dataLayer 需要的数据 ---
                const vm = this;
                const pcatArray = [];
                const prodid = [];
                const dataLayerCheckout = {
                    list: [],
                    total: {},
                };
                const { CODE } = window.dataLayer[0];

                // --- 保存数据 ---
                resData.groupList.forEach((groupItem, groupIndex) => {
                    groupItem.shopList.forEach((shopItem, shopIndex) => {
                        shopItem.goodsList.forEach((goodsItem, goodsIndex) => {
                            // 组装接入 GTM dataLayer 需要的数据
                            dataLayerCheckout.list.push({
                                goods_title: goodsItem.goodTitle,
                                goods_sn: `${goodsItem.goodSn}${CODE}`,
                                goods_price: goodsItem.goodPrice,
                                goods_number: goodsItem.qty,
                                goods_type: goodsItem.goodType,
                                goods_thumb: goodsItem.goodImg,
                                goods_attr: goodsItem.tags,
                                goods_weight: goodsItem.realityWeight,
                                goods_categoryId: goodsItem.categoryId,
                                goods_categoryName: goodsItem.categoryName,
                            });
                            prodid.push(`${goodsItem.goodSn}${CODE}`);
                            pcatArray.push(goodsItem.categoryId);

                            if (goodsItem.accessoryList.length > 0) {
                                goodsItem.accessoryList.forEach((accessItem, accessIndex) => {
                                    // 组装接入 GTM dataLayer 需要的数据
                                    dataLayerCheckout.list.push({
                                        goods_title: accessItem.goodTitle,
                                        goods_sn: `${accessItem.goodSn}${CODE}`,
                                        goods_price: accessItem.goodPrice,
                                        goods_number: accessItem.qty,
                                        goods_type: accessItem.goodType,
                                        goods_thumb: accessItem.goodImg,
                                        goods_attr: accessItem.tags,
                                        goods_weight: accessItem.realityWeight,
                                        goods_categoryId: accessItem.categoryId,
                                        goods_categoryName: accessItem.categoryName,
                                    });
                                    prodid.push(`${accessItem.goodSn}${CODE}`);
                                    pcatArray.push(accessItem.categoryId);
                                });
                            }
                        });
                    });
                });

                dataLayerCheckout.total = {
                    goods_price: resData.total.goodsAmount
                };

                vm.getCategoryInfo(pcatArray, prodid, resData, dataLayerCheckout);
            },
            // 查询分类名称路径
            async getCategoryInfo(pcatArray, prodid, resData, dataLayerCheckout) {
                const pcatArrName = [];
                const resDatas = await serviceGetCategoryInfo.http({
                    params: {
                        categoryIds: pcatArray.join(','),
                    }
                });

                let { data } = resDatas;
                const { status } = resDatas;

                if (status !== 0 || (Array.isArray(data) && data.length === 0)) {
                    data = {};
                }

                pcatArray.forEach((item) => {
                    pcatArrName.push(data[item] ? data[item].catePathName : '');
                });

                this.dataLayer(pcatArrName, prodid, resData, dataLayerCheckout);
            },
            // dataLayer 存储
            dataLayer(pcatArray, prodid, resData, dataLayerCheckout) {
                window.dataLayer[0].google_tag_params.pcat = pcatArray;
                window.dataLayer[0].google_tag_params.prodid = prodid;
                window.dataLayer[0].google_tag_params.totalvalue = resData.total.goodsAmount;
                window.dataLayer[0].checkout = dataLayerCheckout; // 明细见上注释
                window.dataLayer.push({ google_tag_params: window.dataLayer[0].google_tag_params });
                window.dataLayer.push({ checkout: window.dataLayer[0].checkout });
                window.dataLayer.push({ event: 'triggerAdwordsRemarking' });
            },
            errorAlert(param) { // 错误弹窗
                const vm = this;
                if (param.type === 'checkoutData') { // 结算页数据报错
                    let confirmMsg = vm.$trans('order.error');
                    let confirmHref = `${GLOBAL.DOMAIN_CART}/cart/index`;
                    if (
                        param.data.innerCode === 60067 || param.data.innerCode === 60051 ||
                        param.data.innerCode === 60009 || param.data.innerCode === 60011 ||
                        param.data.innerCode === 60008 || param.data.innerCode === 60013
                    ) { // 属于地址信息错误
                        confirmMsg = param.msg;
                        confirmHref = '';
                    } else if (param.data.innerCode === 20019) {
                        window.location.href = confirmHref;
                        return;
                    } else {
                        confirmMsg = param.msg;
                    }
                    vm.$toast({
                        msg: `<div class="checkout_altDataError">${confirmMsg}</div>`,
                        ok() {
                            if (confirmHref === '') {
                                vm.toEditAddress();
                            } else {
                                window.location.href = confirmHref;
                            }
                        }
                    });
                } else if (param.type === 'addressVerify') {
                    vm.$confirm({
                        customClass: 'verifyRulesAddress',
                        shadowClose: false,
                        content: `<p class="verifyRulesAddressContent font-28">${vm.$trans('order.check_edit_to_address')}</p>`,
                        confirmText: vm.$trans('order.check_edit_btn'),
                        ok() {
                            vm.toEditAddress();
                        },
                        cancel() {
                            window.location.href = `${GLOBAL.DOMAIN_CART}/cart/index`;
                        }
                    });
                    const timer = setTimeout(() => {
                        vm.toEditAddress();
                        clearTimeout(timer);
                    }, 5000);
                }
            }
        },
        created() {
            const vm = this;
            if (!vm.DS.addressInfo || !vm.DS.addressInfo.addressId) { // 生单无地址拦截
                vm.toEditAddress();
                return;
            }

            vm.firstStage();

            // 监听page show
            window.addEventListener('pageshow', (event) => {
                if (window.onloadOk) {
                    vm.secondStage();
                }
            });

            // 监听更新数据请求
            vm.$bus.$on('updateList', (data) => {
                vm.secondStage(data);
            });

            // 切换支付方式类型
            vm.$bus.$on('switchChannelType', async (data) => {
                const currencyCode = vm.PD.codShipping.forceCurrency[vm.DS.addressInfo.countryCode];
                if (data === 2 && currencyCode) { // 选择cod时切换发货国家币种
                    PubSub.publish('sysUpdateCurrency', {
                        currencyCode,
                    });
                }
                vm.DS.payChannelType = data;
                vm.filterLogMode();
                vm.useCurrentLogMode();
                vm.fillTaxFree();
            });

            // 支付脚本预加载
            preLoadPay();
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    .checkout_page {
        padding-bottom: rem(112);
    }

    /* 地址校验错误弹窗样式 */
     .verifyRulesAddress .kdialog_close {
         display: none;
     }

     .verifyRulesAddressContent {
         padding: rem(40) 0 rem(10);
         line-height: rem(34);
         text-align: center;
     }
</style>
