<template lang="pug">
    .checkout_showAddress
        .checkout_addressContent(@click="toEditAddress")
            //- 图标
            i.checkout_addressIcon.icon-address.font-50
            //- 地址信息
            .checkout_addressInfo.font-30
                span.checkout_addressTitle {{ addressInfo.username }}
                span.checkout_addressTitle.right {{ addressInfo.phone }}
            p.checkout_addressTxt.font-30 {{ addressInfo.address }}
            .checkout_addressInfo.font-30
                span.checkout_addressTitle.gray [{{ addressInfo.postalCode }}]
                //- a.checkout_addressTitle.right.gray(href="javascript:;" v-finger:tap="toEditAddress") {{ this.$trans('order.edit') }}
            //- 右侧图标
            i.checkout_toAddressIcon.icon-arrow_tiny.font-44
        .checkout_addressBg

</template>

<script>
    export default {
        props: ['addressInfo', 'toEditAddress'],
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    .checkout_showAddress {
        background: var(--color-main-bg);
        margin-bottom: rem(20);
        margin-top: rem(20);
    }

    .checkout_addressContent {
        position: relative;
        padding: rem(20) rem(80) rem(20) rem(94);
    }

    .checkout_addressIcon {
        position: absolute;
        left: rem(30);
        top: 50%;
        margin-top: rem(-20);
        color: var(--color-text-secondary);
    }

    .checkout_addressInfo {
        line-height: rem(60);
        color: var(--color-text-primary);
    }

    .checkout_addressTitle.gray {
        color: var(--color-text-secondary);
    }

    .checkout_addressTitle.right {
        float: right;
    }

    .checkout_addressTxt {
        line-height: rem(40);
        display: -webkit-box !important;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
    }

    .checkout_addressBg {
        height: rem(8);
        background: url('./img/checkout_showAddressBg.png');
        background-size: auto rem(8);
    }

    .checkout_toAddressIcon {
        position: absolute;
        right: rem(30);
        top: 50%;
        height: rem(30);
        margin-top: rem(-15);
        color: var(--color-text-primary);
    }
</style>
