<template lang="pug">
    .headNav(v-if="hdConfig.isShow")
        .headNav_hdContent.font-36
            span.headNav_hdTxt {{ hdConfig.title }}
            a.headNav_hdBtn(v-for="btnItem in hdConfig.btn" v-if="btnItem.isShow", :class="btnItem.class", :href="btnItem.href")
                i(:class="btnItem.icon")
</template>

<script>
    export default {
        props: ['headerConfig'],
        data() {
            return {
                hdConfig: {
                    isShow: false,
                    title: '',
                    btn: {
                        left: {
                            isShow: true,
                            class: 'left-btn',
                            icon: 'icon-back',
                            href: 'javascript:;'
                        },
                        right: {
                            isShow: false,
                            class: 'right-btn',
                            icon: 'icon-edit_nor',
                            href: 'javascript:;'
                        }
                    }
                }
            };
        },
        created() {
            const vm = this;
            // 保存头部配置数据
            for (const objItem in vm.hdConfig) { // 基础设置
                if (vm.headerConfig[objItem] && objItem !== 'btn') {
                    vm.hdConfig[objItem] = vm.headerConfig[objItem];
                } else if (vm.headerConfig[objItem] && objItem === 'btn') {
                    for (const btnItems in vm.hdConfig[objItem]) { // 按钮设置
                        if (vm.headerConfig[objItem][btnItems]) {
                            for (const btnItem in vm.hdConfig[objItem][btnItems]) {
                                if (vm.headerConfig[objItem][btnItems][btnItem] !== undefined) {
                                    vm.hdConfig[objItem][btnItems][btnItem] = vm.headerConfig[objItem][btnItems][btnItem];
                                }
                            }
                        }
                    }
                }
            }
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    /*
    *   头部栏
    */
    .headNav_hdContent {
        position: relative;
        height: rem(90);
        line-height: rem(90);
        text-align: center;
        color: var(--color-text-primary);
        background: var(--color-main-bg);
    }

    .headNav_hdTxt{font-weight: bold;}

    .headNav_hdBtn {
        position: absolute;
        top: rem(25);
        width: rem(40);
        height: rem(40);
        line-height: rem(40);
    }

    .headNav_hdBtn.left-btn {
        left: rem(30);
    }

    .headNav_hdBtn.right-btn {
        right: rem(30);
    }
</style>
