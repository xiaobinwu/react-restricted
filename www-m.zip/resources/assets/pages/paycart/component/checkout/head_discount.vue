<template lang="pug">
    .headTip
        //- 支付优惠提示语
        .headDiscount(v-if="showDiscount && tipList.length")
            i.headDiscount_icon.icon-closed.font-24(@click="showDiscount = false")
            p.headDiscount_tip.font-28
                span(v-for="(tipItem, tipIndex) in tipList") {{ tipItem }}{{ tipIndex < tipList.length - 1 ? ',' : '' }}
        //- 漂浮提示语
        .headTopTip
            //- 发送消息提示语
            .sendEamilTip(v-show="sendEmail.show")
                i.sendEamilTip_icon.icon-warning_icon.font-36
                span.sendEamilTip_txt.font-28 {{ sendEmail.tip }}
                i.sendEamilTip_disicon.icon-closed.font-24(@click="sendEmail.show = false")
</template>

<script>
export default {
    data() {
        return {
            showDiscount: true,
            tipList: [],
            sendEmail: {
                tip: '', // 发送邮件提示语占位
                show: false
            }
        };
    },
    created() {
        const vm = this;
        vm.$bus.$on('showPaymentTip', (data) => {
            vm.$set(this, 'tipList', data);
        });
        // 结算页顶部提示语
        vm.$bus.$on('showTopTip', (data) => {
            if (data.type === 'sendEmail') {
                vm.sendEmail.tip = data.msg;
                vm.sendEmail.show = true;
                const timer = setTimeout(() => {
                    vm.sendEmail.tip = '';
                    vm.sendEmail.show = false;
                    clearTimeout(timer);
                }, 5000);
            }
        });
    }
};
</script>

<style>
    @import 'pages/paycart/mixins.css';
    .headDiscount {
        position: relative;
        padding: 0 rem(60) 0 rem(30);
        background: var(--color-cjfUser-48);
    }

    .headDiscount_icon {
        position: absolute;
        right: rem(30);
        top: 50%;
        transform: translateY(-50%);
        color: var(--color-text-secondary);
    }

    .headDiscount_tip {
        padding: rem(15) 0;
        line-height: rem(36);
        color: var(--color-warning);
    }

    /* 顶部提示语 */
    .headTopTip {
        position: fixed;
        top: rem(110);
        left: 0;
        width: 100%;
        z-index: 8;
    }

    /* 发送邮件提示语 */
    .sendEamilTip {
        position: relative;
        background: var(--color-cjfUser-48);
        padding: rem(20) rem(80);
    }

    .sendEamilTip_icon {
        position: absolute;
        left: rem(30);
        top: 50%;
        transform: translateY(-50%);
        color: var(--warningC);
    }

    .sendEamilTip_disicon {
        position: absolute;
        right: rem(30);
        top: 50%;
        margin-top: rem(-12);
        width: rem(24);
        height: rem(24);
        color: var(--warningC);
    }

    .sendEamilTip_txt {
        line-height: rem(36);
    }
</style>
