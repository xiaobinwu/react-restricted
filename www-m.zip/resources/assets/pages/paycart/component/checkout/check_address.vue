<template lang="pug">
    .checkAddressAlertBox
        h2.title.font-34 {{ $trans('order.check_edit_address') }}
        p.titleTip.font-24 {{ $trans('order.check_edit_tips') }}

        .content.siteScroll(:ref="`kdialog_scroll_wrap`")
            ul
                li.formItem(v-for="(checkItem, checkItemName) in checkObj")
                    .formItemBox(:class="{ 'error': !checkItem.status }")
                        h3.font-22 {{ checkItem.title }}:
                        input.font-30(type="text" v-model="checkItem.value" @focus="focusItem(checkItem, checkItemName)" @blur="blurItemCheck(checkItem, checkItemName)")
                    p.font-20
                        span(v-if="!checkItem.status") {{ checkItem.tips }}

        .footer
            a.footerBtn.font-34(href="javascript:" @click="btnOption('cancel')") {{ $trans('order.cancel') }}
            a.footerBtn.font-34(href="javascript:" @click="btnOption('submit')") {{ $trans('order.submit') }}

</template>

<script>
    import { serviceCheckoutAddressSave } from 'js/service/paycart';

    export default {
        data() {
            return {
                checkInfo: this.$parent.componentData.checkInfo,
                addressInfo: this.$parent.componentData.addressInfo,

                checkObj: {}, // 当前校验规则对象
            };
        },
        methods: {
            // ---- 动态方法 -----
            init() { // 根据数据组装校验规则对象
                const vm = this;
                const errFielArr = [];
                const rulesArr = vm.checkInfo.rules;
                vm.checkInfo.errorFields.forEach(((item) => { // 用户名字段特殊重组配置数组
                    const itemArr = item.split(',');
                    itemArr.forEach((subItem) => {
                        errFielArr.push(subItem);
                    });
                }));
                errFielArr.forEach((item) => { // 初始化校验规则对象
                    vm.$set(vm.checkObj, item, {
                        regex: '',
                        tips: '',
                        title: '',
                        status: false,
                        value: vm.addressInfo[item],
                    });
                    if (item === 'addressLine1') {
                        vm.checkObj[item].title = vm.$trans('user.street_address1');
                    } else if (item === 'addressLine2') {
                        vm.checkObj[item].title = vm.$trans('user.street_address2');
                    } else if (item === 'addressLine3') {
                        vm.checkObj[item].title = vm.$trans('user.street_address3');
                    } else if (item === 'addressLine4') {
                        vm.checkObj[item].title = vm.$trans('user.street_address4');
                    } else if (item === 'phone') {
                        vm.checkObj[item].title = vm.$trans('user.address_phone_number');
                    } else if (item === 'postalCode') {
                        vm.checkObj[item].title = vm.$trans('user.address_zip_code');
                    } else if (item === 'firstName') {
                        vm.checkObj[item].title = vm.$trans('user.address_first_name');
                    } else if (item === 'lastName') {
                        vm.checkObj[item].title = vm.$trans('user.address_last_name');
                    }
                });
                rulesArr.forEach((item) => {
                    const objItem = vm.checkObj[item.field];
                    if (objItem) {
                        objItem.regex = item.regex;
                        objItem.tips = item.tips;
                    } else if (item.field === 'firstName,lastName' && vm.checkObj.lastName) {
                        vm.checkObj.firstName.regex = item.regex;
                        vm.checkObj.lastName.regex = item.regex;
                        vm.checkObj.lastName.tips = item.tips;
                    }
                });
            },
            // ----- 静态方法 -----
            focusItem(checkItem, checkItemName) {
                const vm = this;
                if (checkItemName === 'firstName' || checkItemName === 'lastName') {
                    vm.checkObj.firstName.status = true;
                    vm.checkObj.lastName.status = true;
                } else {
                    checkItem.status = true;
                }
            },
            blurItemCheck(checkItem, checkItemName) { // 正则校验输入框
                const vm = this;
                const reg = new RegExp(checkItem.regex);

                if (checkItemName === 'firstName' || checkItemName === 'lastName') {
                    const username = `${vm.checkObj.firstName.value.trim()} ${vm.checkObj.lastName.value.trim()}`;
                    if (reg.test(username)) { // 校验通过
                        vm.checkObj.firstName.status = true;
                        vm.checkObj.lastName.status = true;
                    } else {
                        vm.checkObj.firstName.status = false;
                        vm.checkObj.lastName.status = false;
                    }
                } else {
                    checkItem.value = checkItem.value ? checkItem.value.trim() : '';
                    if (reg.test(checkItem.value)) { // 校验通过
                        checkItem.status = true;
                    } else {
                        checkItem.status = false;
                    }
                }
            },
            btnOption(type) {
                const vm = this;
                switch (type) {
                case 'cancel':
                    vm.$parent.close();
                    break;
                case 'submit':
                    vm.submitCheck();
                    break;
                default: vm.$parent.close();
                }
            },
            // ---- 动态方法 ----
            submitCheck() { // 校验整个表单
                const vm = this;
                let index = 0;
                let sign = 0;
                for (const item in vm.checkObj) {
                    index += 1;
                    if (vm.checkObj[item].status) {
                        sign += 1;
                    }
                }
                if (index === sign) {
                // 校验通过进行数据组装
                    vm.creatReqData();
                }
            },
            creatReqData() { // 格式化请求数据
                const vm = this;
                const reqData = {
                    addressId: vm.addressInfo.addressId,
                };
                for (const item in vm.checkObj) {
                    reqData[item] = vm.checkObj[item].value;
                }
                // 发送请求
                vm.saveAddress(reqData);
            },
            // ----- 请求数据 -----
            async saveAddress(reqData) {
                const vm = this;
                const responseTaxData = await serviceCheckoutAddressSave.http({
                    data: reqData,
                });

                if (responseTaxData.status === 0) {
                    vm.$parent.close();
                    vm.$bus.$emit('updateList', {});
                }
            },
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
        created() {
            const vm = this;
            vm.init();
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    /* 重置弹窗样式 */
    .checkAddressAlert .kdialog_wrap {
        overflow: hidden;
        width: rem(610);
        padding: 0;
    }
    .checkAddressAlert .kdialog_wrap .kdialog_content {
        padding: 0;
    }
    .checkAddressAlert .kdialog_wrap .kdialog_footer  {
        display: none;
    }

    .checkAddressAlertBox {
        padding-top: rem(30);
    }

    .checkAddressAlertBox .title {
        text-align: center;
        font-weight: bold;
        line-height: rem(70);
        color: var(--color-text-primary);
    }

    .checkAddressAlertBox .titleTip {
        text-align: center;
        line-height: rem(30);
        color: var(--color-text-primary);
        padding: 0 rem(40) rem(25);
    }

    .checkAddressAlertBox .content {
        padding: 0 rem(40);
        max-height: rem(690);
        overflow-y: scroll;
    }

    .checkAddressAlertBox .content .formItem .formItemBox {
        border: 1px solid var(--color-other-2);
        border-radius: rem(4);
        height: rem(100);
        padding: rem(10) rem(20);
    }

    .checkAddressAlertBox .content .formItem .formItemBox.error {
        border-color: var(--warningC);
    }

    .checkAddressAlertBox .content .formItem .formItemBox h3 {
        font-weight: normal;
        line-height: rem(40);
        color: var(--color-text-secondary);
    }

    .checkAddressAlertBox .content .formItem .formItemBox input {
        padding: 0;
        margin: 0;
        outline: none;
        border: 0;
        font-weight: bold;
        line-height: rem(40);
        color: var(--color-text-primary);
    }

    .checkAddressAlertBox .content p {
        min-height: rem(20);
        line-height: rem(34);
        color: var(--warningC);
    }

    .checkAddressAlertBox .footer {
        width: 100%;
        font-size: 0;
        border-top: 1px solid var(--color-other-lable);
    }

    .checkAddressAlertBox .footer .footerBtn {
        display: inline-block;
        width: 50%;
        line-height:  rem(90);
        text-align: center;
        color: var(--color-link);
    }

    .checkAddressAlertBox .footer .footerBtn:first-child {
        border-right: 1px solid var(--color-other-lable);
    }
</style>
