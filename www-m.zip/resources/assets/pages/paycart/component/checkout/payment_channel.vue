<template lang="pug">
    .paymentChannel(v-if="!isAbnormal")
        div#paymentChannelFocus
        h2.paymentChannel_title.font-34 {{ $trans('order.pay_channels_title') }}
        .paymentChannel_content(v-if="payChannelsData.onlinePayment.length > 0 || payChannelsData.codPayment.isShow")
            //- 线上支付方式(走支付平台模式)
            ul.paymentChannel_list(v-if="payChannelsData.onlinePayment.length > 0")
                li.paymentChannel_item(v-for="(onlinePaymentItem, onlinePaymentIndex) in payChannelsData.onlinePayment", v-show="listOpen || onlinePaymentIndex < 3", :class="{'active': onlinePaymentItem.isDefault}", @click="switchChannel('online', onlinePaymentItem)")
                    .vue_checkboxShape.icon-radiobox(:class="{'checked icon-tick': onlinePaymentItem.isDefault}")
                    .paymentChannel_top
                        span.paymentChannel_paymentIcon(v-for="channelInfoItem in onlinePaymentItem.channelInfo")
                            img(:src="channelInfoItem.payIcon")
                        .paymentChannel_paymentDiscount(v-if="onlinePaymentItem.payActivityInfo && (totalAmount - (payChannelsData.walletPayment.isDefault ? payChannelsData.walletPayment.walletInfo.effectiveAmount : 0) >= onlinePaymentItem.payActivityInfo.payAmount)")
                            .paymentChannel_paymentDiscountContent.font-24 ${{ onlinePaymentItem.payActivityInfo.discountAmount }} OFF
                    p.paymentChannel_note.font-28 {{ onlinePaymentItem.channelSubject }}

            //- cod (货到付款方式)
            .paymentChannel_item(v-if="payChannelsData.codPayment.isShow", :class="{'active': payChannelsData.codPayment.isDefault}", @click="switchChannel('cod', payChannelsData.codPayment)")
                .vue_checkboxShape.icon-radiobox(:class="{'checked icon-tick': payChannelsData.codPayment.isDefault, 'icon-radiobox_disabled': PD.codShipping.num >= PD.codShipping.limit}")
                .paymentChannel_top
                    i.paymentChannel_clickIcon.cod
                    h3.paymentChannel_clickTitle.font-28 {{ $trans('order.cod_cash_on_delivery') }}
                p.paymentChannel_note.font-28 {{ $trans('order.cod_cash_on_delivery_note') }}

            //- 更多按钮
            .paymentChannel_more(v-if="payChannelsData.onlinePayment.length > 3")
                .paymentChannel_moreBtn.font-28(@click="switchMoreList()")
                    | {{ listOpen ? $trans('order.payment_pre_online_retract') : $trans('order.payment_pre_online_more') }}
                    i.icon-arrow_up.font-26(v-if="listOpen")
                    i.icon-arrow_down.font-26(v-else)

        //- 无支付方式
        .paymentChannel_nothing(v-else-if="!isFirst")
            p.paymentChannel_nothingTxt.font-28(v-html="$trans('order.payment_pre_online_nothing', ['http://wap-support.gearbest.com/ticket/ticket/ticket-list'])")
            img(src="./img/payment_nothing.png")
        .paymentChannel_nothing(v-else)
            p.paymentChannel_nothingLoding
                i.icon-loading

        //- 电子钱包
        .paymentChannel_wallet(v-if="payChannelsData.walletPayment.isShow", :class="{'active': payChannelsData.walletPayment.isDefault}")
            .paymentChannel_walletTop
                .vue_checkboxShape.icon-radiobox(:class="{'checked icon-tick': payChannelsData.walletPayment.isDefault}", @click="switchChannel('wallet', payChannelsData.walletPayment)")
                .paymentChannel_walletTopName.font-28 {{ $trans('order.payment_pre_wallet_title') }}
                    span {{currency | $remainder_one(payChannelsData.walletPayment.walletInfo.effectiveAmount, 2)}}
                    i.paymentChannel_walletIcon.font-36.icon-question(@click="alertNote($trans('order.payment_pre_wallet_alert_note'))")

                p.paymentChannel_walletTopNote.font-28 {{ $trans('order.payment_pre_wallet_pay') }} {{currency | $remainder_one(payChannelsData.walletPayment.walletInfo.effectiveAmount >= totalAmount ? totalAmount : payChannelsData.walletPayment.walletInfo.effectiveAmount, 2)}}

            .paymentChannel_walletBottom(v-show="payChannelsData.walletPayment.isDefault && !payChannelsData.walletPayment.status")
                input.paymentChannel_walletInput(type="password", :placeholder="$trans('order.payment_pre_wallet_placetxt')", @focus="payChannelsData.walletPayment.errorTip = ''", v-model="payChannelsData.walletPayment.input")
                p.paymentChannel_walletErrTip.font-28 {{ payChannelsData.walletPayment.errorTip }}
                a.paymentChannel_walletLink.font-28(href="javascript:;", v-if="payChannelsData.walletPayment.emailSendTime <= 0")
                    span(@click="clickSend(+payChannelsData.walletPayment.walletInfo.pwdSetting)") {{ payChannelsData.walletPayment.walletInfo.pwdSetting ? $trans('order.payment_pre_wallet_send_set_email') : $trans('order.payment_pre_wallet_send_email') }}
                    i.paymentChannel_walletIcon.font-36.icon-question(@click="alertNote($trans('order.payment_pre_wallet_alert_reset'))")
</template>

<script>
    import { servicePaymentPreChannels, servicePaymentPreSendTrack } from 'js/service/paycart.js';
    import { serviceWalletBalance, serviceWalletSendEmail } from 'js/service/user.js';

    export default {
        props: ['totalAmount', 'PD', 'DS'],
        data() {
            return {
                isFirst: true,
                listOpen: false, // 展开列表
                isAbnormal: 0, // 是否数据异常
                payDiscount: 0, // 当前支付方式折扣
                payChannelsData: { // 可用支付方式对象
                    historyOnline: '', // 上一次状态
                    firstChannel: '', // 第一次默认值
                    onlinePayment: [], // 线上支付方式
                    codPayment: { // 货到付款
                        isShow: 0,
                        isDefault: false,
                    },
                    walletPayment: { // 电子钱包
                        isShow: 0,
                        isDefault: false,
                        errorTip: '',
                        walletInfo: null, // 电子钱包余额接口数据
                        input: '',
                        status: 0,
                        emailSendTime: 0
                    },
                },
            };
        },
        watch: {
            payChannelsData: {
                handler() {
                    this.$parent.acountShowGrand();
                    if (this.PD.total.advanceSwellInfo) {
                        this.$parent.depositGrandTotal();
                    }
                },
                deep: true
            }
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        methods: {
            // ----- 业务逻辑 -----
            async firstStage(isUseWallet) { // 第一步请求支付列表数据
                const vm = this;
                const walletAmount = isUseWallet ? (
                    vm.payChannelsData.walletPayment.walletInfo.effectiveAmount >= vm.totalAmount ? vm.totalAmount : (
                        vm.payChannelsData.walletPayment.walletInfo.effectiveAmount
                    )
                ) || 0 : 0;
                const { status, data } = await vm.getPayChannels(walletAmount);
                if (status === 0) {
                    if (data) {
                        // 合并处理电子钱包是否展示
                        if (data.isShowWallet && !vm.payChannelsData.walletPayment.walletInfo) {
                            const walletData = await vm.getWallet();
                            if (walletData.status === 0) vm.$set(vm.payChannelsData.walletPayment, 'walletInfo', walletData.data);
                        }
                        if (vm.payChannelsData.walletPayment.walletInfo && vm.payChannelsData.walletPayment.walletInfo.pwdSetting) {
                            vm.payChannelsData.walletPayment.errorTip = vm.$trans('order.payment_pre_wallet_error_setpwd');
                        }
                        vm.payChannelsData.walletPayment.isShow = +(
                            data.isShowWallet &&
                            vm.payChannelsData.walletPayment.walletInfo &&
                            vm.payChannelsData.walletPayment.walletInfo.exist &&
                            vm.payChannelsData.walletPayment.walletInfo.effectiveAmount > 0
                        );

                        // 重组支付平台数据结构
                        const onlinePayment = data.payChannelDto;
                        const defaultChannel = +data.hasDefault ? (data.defaultChannel || 1) : '';
                        const payActivityDto = data.payActivityDto || [];
                        vm.payDiscount = 0;
                        onlinePayment.forEach((payChannelItem, payChannelIndex) => {
                            // 支付方式活动信息绑定到支付方式
                            payActivityDto.forEach((payActivityItem) => {
                                if (payChannelItem.payChannel === payActivityItem.channelCode) {
                                    payChannelItem.payActivityInfo = payActivityItem;
                                }
                            });
                            // 记录第一次的默认值
                            if (!vm.payChannelsData.firstChannel && payChannelItem.isDefault && vm.payChannelsData.onlinePayment.length <= 0) {
                                vm.payChannelsData.firstChannel = payChannelItem.payChannel;
                            }
                            // 设置默认勾选支付方式
                            if (vm.payChannelsData.codPayment.isDefault) {
                                payChannelItem.isDefault = 0;
                            } else if (vm.payChannelsData.walletPayment.isDefault) {
                                if (vm.payChannelsData.walletPayment.walletInfo.effectiveAmount >= vm.totalAmount) {
                                    payChannelItem.isDefault = 0;
                                } else {
                                    payChannelItem.isDefault = +(payChannelItem.payChannel === vm.historyOnline);
                                }
                            } else {
                                payChannelItem.isDefault = vm.historyOnline ? +(payChannelItem.payChannel === vm.historyOnline) : (
                                    defaultChannel === 1 ? +(payChannelIndex === 0) : +(payChannelItem.payChannel === defaultChannel)
                                );
                            }
                            // 绑定支付折扣
                            if (
                                payChannelItem.isDefault && payChannelItem.payActivityInfo &&
                                (vm.totalAmount - (
                                    vm.payChannelsData.walletPayment.isDefault ? vm.payChannelsData.walletPayment.walletInfo.effectiveAmount : 0
                                )) >= payChannelItem.payActivityInfo.payAmount
                            ) {
                                vm.payDiscount = payChannelItem.payActivityInfo.discountAmount;
                            }
                        });
                        // 原支付方式不支持组合支付提示
                        if (
                            vm.payChannelsData.walletPayment.isDefault &&
                            vm.payChannelsData.walletPayment.walletInfo.effectiveAmount < vm.totalAmount &&
                            vm.historyOnline &&
                            !onlinePayment.some(item => item.isDefault)
                        ) {
                            vm.$toast({ timer: 2000, msg: vm.$trans('order.payment_pre_filter_onlaine') });
                        }
                        // 挂载新数据
                        vm.$set(vm.payChannelsData, 'onlinePayment', onlinePayment);

                        // 通知展示提示语
                        vm.$bus.$emit('showPaymentTip', data.tipsList);
                    } else {
                        vm.$set(vm.payChannelsData, 'onlinePayment', []);
                        vm.payChannelsData.walletPayment.isShow = 0;
                    }
                    // 完全没有支付方式时 或 有 cod 但是不可用
                    if (
                        !vm.payChannelsData.walletPayment.isShow &&
                        vm.payChannelsData.onlinePayment.length <= 0 &&
                        (!vm.payChannelsData.codPayment.isShow || vm.PD.codShipping.num >= vm.PD.codShipping.limit)
                    ) {
                        vm.$parent.yesCreated = false;
                        vm.$toast({ timer: 2000, msg: vm.$trans('order.payment_pre_no_paychannel') });
                    }
                }
                vm.isFirst = false;
                vm.isAbnormal = status;
            },
            // ----- 处理方法 -----
            switchMoreList() {
                const vm = this;
                vm.listOpen = !vm.listOpen;
                // 触发埋点 - 点击更多
                // vm.sendTrackData({
                //     actionCode: 'click',
                //     actionValue: 'm_more',
                // });
            },
            queryInfo() {
                const vm = this;
                // 判断当前使用的支付方式
                let payChannel = 0;
                if (vm.payChannelsData.codPayment.isDefault) {
                    payChannel = 'COD';
                } else if (vm.payChannelsData.walletPayment.isDefault && vm.payChannelsData.walletPayment.walletInfo.effectiveAmount >= vm.totalAmount) {
                    payChannel = 'WALLET';
                } else if (vm.payChannelsData.walletPayment.isDefault) {
                    payChannel = ['WALLET'];
                    vm.payChannelsData.onlinePayment.forEach((onlinePaymentItem) => {
                        if (onlinePaymentItem.isDefault) payChannel.push(onlinePaymentItem.payChannel);
                    });
                } else {
                    vm.payChannelsData.onlinePayment.forEach((onlinePaymentItem) => {
                        if (onlinePaymentItem.isDefault) payChannel = onlinePaymentItem.payChannel;
                    });
                }
                return {
                    payChannel,
                    walletAmount: vm.payChannelsData.walletPayment.walletInfo ? vm.payChannelsData.walletPayment.walletInfo.effectiveAmount || 0 : 0,
                    useWalletAmout: vm.payChannelsData.walletPayment.walletInfo ? (
                        vm.payChannelsData.walletPayment.walletInfo.effectiveAmount >= vm.totalAmount ? vm.totalAmount : (
                            vm.payChannelsData.walletPayment.walletInfo.effectiveAmount
                        )
                    ) || 0 : 0,
                    payDiscount: vm.payDiscount,
                    wallertPwd: vm.payChannelsData.walletPayment.input.trim(),
                    isAbnormal: vm.isAbnormal,
                    isFullAmount: +(
                        vm.payChannelsData.walletPayment.isDefault &&
                        vm.payChannelsData.walletPayment.walletInfo &&
                        vm.payChannelsData.walletPayment.walletInfo.effectiveAmount >= vm.totalAmount
                    ),
                    walletPwdStatus: vm.payChannelsData.walletPayment.status,
                };
            },
            async clickSend(type) {
                const vm = this;
                const { status } = await vm.sendResetEmail(+!type);
                if (status === 0) {
                    vm.payChannelsData.walletPayment.emailSendTime = 120;
                    const timer = setInterval(() => {
                        vm.payChannelsData.walletPayment.emailSendTime -= 1;
                        if (vm.payChannelsData.walletPayment.emailSendTime <= 0) {
                            vm.payChannelsData.walletPayment.emailSendTime = 0;
                            clearInterval(timer);
                        }
                    }, 1000);
                    // 顶部展示提示语
                    const email = window.USERINFO.email || '';
                    vm.$bus.$emit('showTopTip', {
                        type: 'sendEmail',
                        msg: type ? vm.$trans('order.payment_pre_set_tip', [email]) : vm.$trans('order.payment_pre_reset_tip', [email]),
                    });
                }
            },
            alertNote(msg) {
                const vm = this;
                vm.$alert({
                    customClass: 'paymentChannel_alertTip',
                    content: `<div class="paymentChannel_alertTipContent font-28">${msg}</div>`,
                    ok() {
                        this.close();
                    }
                });
            },
            switchChannel(type, clickItem) { // 切换支付方式
                const vm = this;
                switch (type) {
                case 'wallet':
                    vm.walletHandle(!clickItem.isDefault);
                    break;
                case 'cod':
                    // cod 订单在途拦截
                    if (vm.PD.codShipping.num >= vm.PD.codShipping.limit) {
                        vm.$toast({ timer: 3000, msg: vm.$trans('order.cod_shipping_limit_tip') });
                        return;
                    }
                    vm.codHandle(!clickItem.isDefault);
                    break;
                case 'online':
                    vm.onlineHandle(!clickItem.isDefault, clickItem);
                    break;
                default:
                    // console.log('正在使用:', type, ';变更后状态:', clickItem.isDefault);
                }
            },
            walletHandle(opt) { // 取消: X | 选中: 取消 cod \ 不支持组合支付的线上支付
                const vm = this;
                vm.payChannelsData.walletPayment.isDefault = +opt;
                vm.payChannelsData.walletPayment.errorTip = '';
                if (opt && vm.payChannelsData.codPayment.isDefault) vm.codHandle(false);
                // 保存online列表中选中的支付方式
                vm.historyOnline = '';
                vm.payChannelsData.onlinePayment.forEach((onlinePaymentItem) => {
                    if (onlinePaymentItem.isDefault) vm.historyOnline = onlinePaymentItem.payChannel;
                });
                // 根据电子钱包金额请求数据
                vm.firstStage(opt);
                // 触发埋点 - 选中 \ 取消电子钱包
                // vm.sendTrackData({
                //     actionCode: 'click',
                //     actionValue: opt ? 'checkWallet' : 'uncheckWallet',
                // });
            },
            codHandle(opt) { // 取消: X | 选中: 取消 电子钱包 \ 线上支付
                const vm = this;
                vm.payChannelsData.codPayment.isDefault = +opt;
                if (opt) {
                    if (vm.payChannelsData.walletPayment.isDefault) vm.walletHandle(false);
                    vm.onlineHandle(false);
                }
                vm.$bus.$emit('switchChannelType', opt ? 2 : 1);
            },
            onlineHandle(opt, selectWhy) { // 取消: X | 选中: 取消cod \ 不支持组合支付的电子钱包
                const vm = this;
                // 取消所有选中
                vm.payChannelsData.onlinePayment.forEach((onlinePaymentItem) => {
                    onlinePaymentItem.isDefault = 0;
                });
                vm.payDiscount = 0;
                if (opt) {
                    if (selectWhy) {
                        selectWhy.isDefault = 1;
                        vm.historyOnline = selectWhy.payChannel;
                        if (
                            selectWhy.payActivityInfo &&
                            (vm.totalAmount - (
                                vm.payChannelsData.walletPayment.isDefault ? vm.payChannelsData.walletPayment.walletInfo.effectiveAmount : 0
                            )) >= selectWhy.payActivityInfo.payAmount
                        ) {
                            vm.payDiscount = selectWhy.payActivityInfo.discountAmount;
                        } else {
                            vm.payDiscount = 0;
                        }
                    }
                    if (vm.payChannelsData.codPayment.isDefault) vm.codHandle(false);
                    if (
                        vm.payChannelsData.walletPayment.isDefault &&
                        vm.payChannelsData.walletPayment.walletInfo.effectiveAmount >= vm.totalAmount
                    ) vm.walletHandle(false);
                }
                // 触发埋点 - 选中支付方式
                // if (opt) {
                //     vm.sendTrackData({
                //         actionCode: 'click', // 操作类型对应关系见下表
                //         actionValue: 'channel', // 操作类型对应关系见下表
                //         channelCode: Array.isArray(vm.queryInfo().payChannel) ? vm.queryInfo().payChannel[1] : vm.queryInfo().payChannel,
                //         firstChannelCode: vm.payChannelsData.firstChannel
                //     });
                // }
            },
            // ----- 请求数据 -----
            getPayChannels(walletAmount) { // 前置获取支付方式
                const vm = this;
                const params = {
                    countryCode: vm.DS.addressInfo.countryCode,
                    currencyCode: vm.$root.currenySign,
                    amount: vm.totalAmount,
                    walletAmount,
                };
                if (vm.PD.total.advanceSwellInfo) {
                    params.ruleCode = 'DEPOSIT';
                } else if (vm.PD.total.ruleCode) {
                    params.ruleCode = vm.PD.total.ruleCode;
                }
                return servicePaymentPreChannels.http({
                    loading: false,
                    params,
                });
            },
            getWallet() { // 请求电子钱包
                return serviceWalletBalance.http({
                    loading: false,
                });
            },
            sendResetEmail(hasSetPwd) { // 发送重置邮件
                return serviceWalletSendEmail.http({
                    data: {
                        hasSetPwd,
                    }
                });
            },
            sendTrackData(reqData = {}) { // 发送埋点数据
                servicePaymentPreSendTrack.http({
                    loading: false,
                    errorTip: false,
                    data: Object.assign({
                        token: '', // 支付token 无
                        traceId: '', // 支付跟踪id 无
                        actionCode: '', // 操作类型对应关系见下表
                        actionValue: '', // 操作类型对应关系见下表
                        validateResult: '', // 校验操作的信息值
                        channelCode: '', // 支付方式
                        firstChannelCode: '', // 默认选中支付方式
                        userAgent: window.navigator.userAgent, // 请求信息
                        url: window.location.href, // 请求url
                        time: '', // 各种耗时参数
                        nativePayEvent: '', // 原生app埋点信息 2018-10-31
                        version: window.navigator.appVersion, // 浏览器版本
                    }, reqData)
                });
            }
        },
        created() {
            const vm = this;
            // COD 模式绑定 COD 支付方式
            if (vm.PD.total.codTag) vm.payChannelsData.codPayment.isShow = 1;

            // 稳定价格查询
            vm.$bus.$on('stableGetChannelList', (data) => {
                if (window.stable) {
                    if (vm.totalAmount > 0) {
                        this.firstStage();
                    } else {
                        vm.payDiscount = 0;
                        vm.isAbnormal = 1;
                    }
                    window.stable = false;
                }
            });

            // 提供查询内部信息监听
            vm.$bus.$on('queryPayPreInfo', (data) => {
                if (data) data(vm.queryInfo());
            });

            // 更新电子钱包密码验证状态
            vm.$bus.$on('updataWalletStatus', (data) => {
                vm.payChannelsData.walletPayment.status = data.status;
                vm.payChannelsData.walletPayment.errorTip = data.msg;
                // 触发埋点 - 电子钱包密码校验错误
                // const errorType = data.errorType;
                // if (!vm.payChannelsData.walletPayment.status && errorType) {
                //     vm.sendTrackData({
                //         actionCode: 'wallet',
                //         actionValue: errorType === 1 ? 'empty' : (errorType <= 5 ? `error_${errorType}` : 'lock'),
                //     });
                // }
            });
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';

    .paymentChannel .vue_checkboxShape{
        left: auto;
        right: .4rem;
        margin-top: -.24rem;
        transform: translateY(0);
    }

    /* 页面 */
    .paymentChannel {
        margin-bottom: rem(20);
    }

    .paymentChannel_title {
        border-bottom: 1px solid var(--color-other-lable);
        line-height: rem(90);
        padding: 0 rem(30);
        color: var(--color-text-primary);
        background: var(--color-main-bg);
    }

    .paymentChannel_content {
        background: var(--color-main-bg);
    }

    /* 线上支付方式 + cod 模式布局 */
    .paymentChannel_item {
        position: relative;
        padding: rem(30) rem(70) rem(30) rem(30);
        border-bottom: 1px solid var(--color-other-lable);
    }

    .paymentChannel_item.active {
        background: var(--color-cjfUser-48);
    }

    .paymentChannel_select {
        position: absolute;
        top: 50%;
        right: rem(30);
        margin-top: rem(-18);
    }

    .paymentChannel_top {
        font-size: 0;
        line-height: rem(44);
        margin-bottom: rem(10);
    }

    .paymentChannel_paymentIcon {
        display: inline-block;
        vertical-align: top;
        height: rem(72);
        border-radius: rem(5);
        margin: rem(5) rem(10) rem(5) 0;
        overflow: hidden;
        background: var(--color-main-bg);
    }

    .paymentChannel_paymentIcon img {
        width: auto;
        max-width: rem(620);
        height: 100%;
    }

    .paymentChannel_paymentDiscount {
        display: inline-block;
        vertical-align: top;
        height: rem(72);
        margin: rem(5) rem(10) rem(5) 0;
    }

    .paymentChannel_paymentDiscountContent {
        position: relative;
        padding: 0 rem(10);
        line-height: rem(36);
        margin-top: rem(18);
        margin-left: rem(10);
        color:var(--color-main-bg);
        background: var(--color-warning);
        border-radius: rem(2);
    }

    .paymentChannel_paymentDiscountContent::before {
        content: '';
        position: absolute;
        left: rem(-4);
        top: 50%;
        transform: translateY(-50%) rotate(45deg);
        width: rem(7);
        height: rem(7);
        background: var(--color-warning);
    }

    .paymentChannel_clickIcon {
        display: inline-block;
        vertical-align: top;
        width: rem(44);
        height: rem(44);
        margin-right: rem(10);
    }

    .paymentChannel_clickIcon.online {
        background: url('./img/payment_channel_online.png') no-repeat center;
        background-size: 100% rem(32);
    }

    .paymentChannel_clickIcon.cod {
        background: url('./img/payment_channel_cod.png') no-repeat center;
        background-size: cover;
    }

    .paymentChannel_clickTitle {
        display: inline-block;
        vertical-align: top;
        font-weight: bold;
    }

    .paymentChannel_note {
        line-height: rem(40);
    }

    /* 展开更多 */
    .paymentChannel_more {
        text-align: center;
    }

    .paymentChannel_moreBtn {
        line-height: rem(60);
        color: var(--color-link);
        padding: rem(10) rem(20);
    }

    .paymentChannel_moreBtn i {
        margin-left: rem(10);
    }

    /* 无支付方式 */
    .paymentChannel_nothing  {
        padding: rem(30) rem(50) rem(50);
        border-bottom: 1px solid var(--color-other-lable);
        text-align: center;
        background: var(--color-main-bg);
    }

    .paymentChannel_nothingTxt {
        line-height: rem(36);
        margin-bottom: rem(50);
        color: var(--color-text-primary);
    }

    .paymentChannel_nothingTxt a {
        color: var(--color-other-21);
        text-decoration: underline;
    }

    .paymentChannel_nothingLoding {
        text-align: center;
    }

    .paymentChannel_nothingLoding .icon-loading {
        position: static;
        transform: none;
        top: 0;
        left: 0;
        z-index: 1;
        border: 0;
    }

    /* 电子钱包布局 */
    .paymentChannel_wallet {
        margin-top: rem(20);
        padding: rem(30);
        background: var(--color-main-bg);
        border-bottom: 1px solid var(--color-other-lable);
    }

    .paymentChannel_walletTop {
        position: relative;
        padding-right: rem(40);
    }

    .paymentChannel_walletTop .vue_checkboxShape{
        right:0;
    }

    .paymentChannel_walletTopName,
    .paymentChannel_walletTopNote {
        line-height: rem(36);
        color: var(--color-text-primary);
    }

    .paymentChannel_walletTopName span {
        color: var(--color-price);
        margin-left: rem(10);
    }

    .paymentChannel_walletIcon {
        position: relative;
        top: rem(3);
        margin-left: rem(10);
        color:var(--color-text-secondary);
    }

    .paymentChannel_walletInput {
        display: block;
        width: 100%;
        border: 1px solid var(--disableC);
        padding: rem(19);
        height: rem(90);
        line-height: rem(50);
        border-radius: rem(5);
        margin-top: rem(15);
    }

    .paymentChannel_walletInput.error {
        border-color: var(--color-danger);
    }

    .paymentChannel_walletErrTip {
        line-height: rem(50);
        color: var(--color-danger);
    }

    .paymentChannel_walletLink {
        line-height: rem(50);
        color: var(--color-link);
    }

    /* 弹窗提示语 */
    .paymentChannel_alertTip .kdialog_close {
        display: none;
    }
    .paymentChannel_alertTip .kdialog_footer a {
        background: var(--color-main-bg) !important;
        color: var(--color-other-21);
        border: 1px solid var(--color-other-lable);
    }
    .paymentChannel_alertTipContent {
        padding: rem(40) rem(20) rem(30);
        line-height: rme(40);
        color: var(--color-text-primary);
    }
</style>
