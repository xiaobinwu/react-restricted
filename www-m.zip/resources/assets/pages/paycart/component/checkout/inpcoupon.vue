<template lang="pug">
    .ck_scInputAlert
        input.ck_scInputAlertInput.font-30(type="text", :placeholder="$trans('order.input_code_to_use_it')", v-model="inputVal", :change="changeInput()")
</template>

<script>
    export default {
        data() {
            return {
                inputVal: this.$parent.componentData.inputVal, // 用户输入的值
            };
        },
        methods: {
            changeInput() {
                const vm = this;
                vm.$bus.$emit('alertInput', {
                    inputVal: vm.inputVal
                });
            }
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    .ck_scInputAlert {
        margin-top: rem(23);
    }

    .ck_scInputAlertInput {
        outline: none;
        margin: 0;
        border: none;
        background: var(--color-fill-lable);
        border-radius: rem(6);
        color: var(--color-text-primary);
        display: block;
        width: 100%;
        line-height: rem(40);
        padding: rem(15) rem(24);
    }
</style>
