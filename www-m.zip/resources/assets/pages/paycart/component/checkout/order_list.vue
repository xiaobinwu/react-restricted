<template lang="pug">
    .checkout_orderlist
        //- 订单列表
        .ck_groupList(v-for="(groupItem, groupIndex) in PD.groupList" :class="{ bottom: groupItem.groupInfo.deliveryType == 0 || !PD.groupList[groupIndex + 1] || PD.groupList[groupIndex + 1].groupInfo.deliveryType == 0 || groupItem.shopList[0].shopInfo.shopCode != PD.groupList[groupIndex + 1].shopList[0].shopInfo.shopCode }")
            //- 仓库名
            .ck_warehouseName(v-if="groupItem.groupInfo.deliveryType == 0")
                .ck_title
                    //- 预设几个仓库图片进行替换
                    i.ck_titleIcon.font-50(:class="{'icon-warehouse': true}")
                    span.ck_titleTxt.font-32 {{ groupItem.groupInfo.warehouseName }} ({{ groupItem.groupInfo.totalGoodsNumber }})

            //- 子订单
            .ck_groupItem
                //- 店铺
                .ck_shop(v-for="(shopItem, shopIndex) in groupItem.shopList")
                    //- 店铺名
                    .ck_shopName(v-if="groupItem.groupInfo.deliveryType == 0 || !PD.groupList[groupIndex - 1] || PD.groupList[groupIndex - 1].groupInfo.deliveryType == 0 || groupItem.shopList[0].shopInfo.shopCode != PD.groupList[groupIndex - 1].shopList[0].shopInfo.shopCode")
                        .ck_title(v-show="shopItem.shopInfo.shopName")
                            i.ck_titleIcon.font-50(:class="true ? 'icon-store' : 'icon-store_gb'")
                            span.ck_titleTxt.font-32 {{ shopItem.shopInfo.shopName }}

                    //- 商品列表
                    .ck_goodsList(v-for="(goodsItem, goodsIndex) in shopItem.goodsList")
                        //- （多加一层结构防止后期店铺内添加活动分组）
                        ul.order_goods
                            //- 商品
                            li.order_goodsItem
                                .order_goodsHeader
                                    img.order_goodsImg(:src="goodsItem.goodImg")
                                    .order_goodsTagCorner.font-22(v-if="goodsItem.priceType == 1 || goodsItem.priceType == 2 || goodsItem.priceType == 7")
                                    .order_goodsTagCorner.font-22.type_clearance(v-else-if="goodsItem.saleMark == 3 || goodsItem.priceType == 10 || goodsItem.priceType == '6396395377285853184'") {{ $trans('order.goods_clearance') }}
                                    .order_goodsTagBot.font-24(v-if="goodsItem.priceType == 9") {{ $trans('order.goods_accessory') }}
                                .order_goodsInfo
                                    a.order_goodsTitle.font-28(href="JavaScript:;") {{ goodsItem.goodTitle }}
                                    p.order_goodsAttr.font-26
                                        span(v-for="(attrItem, attrIndex) in goodsItem.attr") {{ attrIndex != 0 ? ',' : '' }}{{ attrItem.value }}
                                    .order_goodsPriceNum.font-32
                                        span.order_price {{currency | $remainder_one(goodsItem.goodPrice)}}
                                        span.order_num ×
                                            span {{ goodsItem.qty }}

                                    //- 定金膨胀提示语
                                    .order_goodsDepositTip.font-32(v-if="goodsItem.skuAdvanceDetail")
                                        span(v-if="goodsItem.skuAdvanceDetail.swellDiscontAmount > 0") {{ $trans('order.depoist_goods') }} {{currency | $remainder_one(goodsItem.skuAdvanceDetail.advanceAmount)}} {{ $trans('order.depoist_goods_choose') }} {{currency | $remainder_one(goodsItem.skuAdvanceDetail.swellDiscontAmount, 0)}}
                                        span(v-else) {{ $trans('order.depoist_goods') }} {{currency | $remainder_one(goodsItem.skuAdvanceDetail.advanceAmount)}}

                            //- 赠品配件
                            li.order_goodsItem(v-for="(accessoryItem, accessoryIndex) in goodsItem.accessoryList")
                                .order_goodsHeader
                                    img.order_goodsImg(:src="accessoryItem.goodImg")
                                    .order_goodsTagCorner.font-22(v-if="accessoryItem.priceType == 1 || accessoryItem.priceType == 2 || accessoryItem.priceType == 7")
                                    .order_goodsTagCorner.font-22.type_clearance(v-else-if="accessoryItem.saleMark == 3 || accessoryItem.priceType == 10 || accessoryItem.priceType == '6396395377285853184'") {{ $trans('order.goods_clearance') }}
                                    .order_goodsTagBot.font-24(v-if="accessoryItem.priceType == 9") {{ $trans('order.goods_accessory') }}
                                .order_goodsInfo
                                    a.order_goodsTitle.font-28(href="JavaScript:;") {{ accessoryItem.goodTitle }}
                                    p.order_goodsAttr.font-26 {{ accessoryItem.attr.color }},{{ accessoryItem.attr.size }}
                                    .order_goodsPriceNum.font-32
                                        span.order_price {{currency | $remainder_one(accessoryItem.goodPrice)}}
                                        span.order_num ×
                                            span {{ accessoryItem.qty }}

                                    //- 定金膨胀提示语
                                    .order_goodsDepositTip.font-30(v-if="accessoryItem.skuAdvanceDetail")
                                        span(v-if="accessoryItem.skuAdvanceDetail.swellDiscontAmount > 0") {{ $trans('order.depoist_goods') }} {{currency | $remainder_one(accessoryItem.skuAdvanceDetail.advanceAmount)}} {{ $trans('order.depoist_goods_choose') }} {{currency | $remainder_one(accessoryItem.skuAdvanceDetail.swellDiscontAmount, 0)}}
                                        span(v-else) {{ $trans('order.depoist_goods') }} {{currency | $remainder_one(accessoryItem.skuAdvanceDetail.advanceAmount)}}

                //- 物流方式选择
                .ck_statistics
                    .ck_stConten
                        .ck_stShowConten.font-30(v-finger:tap="selectLogist.bind('', groupItem.logisticsInfo.logisticsGroupList, groupIndex)")
                            .ck_stBox
                                span.ck_stPrice.font-30 {{currency | $remainder_one(groupItem.logisticsInfo.defaultLogObj.logPrice)}}
                                i.ck_stIcon.icon-arrow_tiny.font-44
                            p.ck_stTitle {{ groupItem.logisticsInfo.defaultLogObj.logName ? groupItem.logisticsInfo.defaultLogObj.logName : 'Logistics is called empty' }}
                            p.ck_stTime {{ groupItem.logisticsInfo.defaultLogObj.logTime }} {{ $trans('order.business_days') }}
                        p.ck_stTip(v-if="groupItem.logisticsInfo.defaultLogObj.tips") {{ groupItem.logisticsInfo.defaultLogObj.tips }}
                        p.ck_stTip(v-if="groupItem.logisticsInfo.defaultLogObj.isTariffTip") {{ groupItem.logisticsInfo.defaultLogObj.tariffTip }}

                //- 保险选择
                .ck_insurance.font-30(v-if="groupItem.groupInfo.deliveryType == 0")
                    .ck_insuranceTxt {{ $trans('order.insurance') }}
                    .ck_insuranceRight
                        .ck_insuranceIconBox(@click.stop="switchInsuranceTip(!groupItem.logisticsInfo.isShowInssuranceTip, groupItem)")
                            i.ck_insuranceIcon.font-48.icon-warning_icon
                            p.ck_insuranceIconCon.font-22(:class="{'open': groupItem.logisticsInfo.isShowInssuranceTip}")
                                span {{ $trans('order.guide_insurance') }}
                        span.ck_insurancePrice {{currency | $remainder_one(groupItem.logisticsInfo.inssuranceAmount)}}
                        checkbox(v-if="!groupItem.logisticsInfo.isInssuranceForceSelected" label="", :autoReverse="1", :checked="groupItem.logisticsInfo.inssuranceSelected", eventName="insurance", :checkId="`${groupIndex}`")
                        .ck_forceCheck(v-else :class="{'checked': groupItem.logisticsInfo.inssuranceSelected}")

                //- 子订单结算
                .ck_groupTotal.font-32
                    span.ck_groupTotalTitle {{ $trans('order.total') }}:
                    span.ck_groupTotalPrice {{ currency | onlyAddSymbol(settlement.subTotalPrice[groupIndex]) }}

        //- 选择使用优惠方式
        .ck_discountChoice.font-30(v-if="!PD.total.advanceSwellInfo && !DS.isVisitor")
            //- 使用优惠券
            .ck_discountCoupon
                .ck_discountTitile.font-30
                    | {{ $trans('order.use_coupon') }}
                    p.ck_discountTitilePrice(v-if="discountObj.coupon.isDefault")
                        | {{ $trans('order.save') }}:
                        span {{currency | $remainder_one(PD.total.discountAmount, 0)}}
                checkbox(label="", isradio="1", :associatedData="discountObj", :checked="discountObj.coupon.isDefault", checkId="coupon", eventName="useDiscout", mustCheck="2")
            //- 使用积分
            .ck_discountPoint(:class="{'none': PD.total.maxIntegral <= 0}")
                .ck_discountTitile.font-30
                    | {{ $trans('order.use_points') }}
                    p.ck_discountTitilePrice(v-if="discountObj.point.isDefault")
                        | {{ $trans('order.save') }}:
                        span {{currency | $remainder_one(PD.total.integralDeductAmount, 0)}}
                    p(v-html="$trans('order.use_points_discount', [PD.total.maxIntegral, remainderRule.one(PD.total.maxIntegralDeductAmount, 0,)])")
                checkbox(label="", isradio="1",  :associatedData="discountObj", :checked="discountObj.point.isDefault", checkId="point", eventName="useDiscout", mustCheck="2")

        //- 支付方式选择区
        paymentchannel(v-if="!DS.isQuickPay", :totalAmount="notCodTotal", :PD="PD", :DS="DS")

        //- 针对巴西特殊费提示
        .ck_specialFee(v-if="DS.addressInfo.countryCode == 'BR'")
            .icon-warning_icon
            .font-24(v-html="$trans('order.special_fee_brazil')")

        //- 定金膨胀规则提示
        .ck_depositClause(v-if="PD.total.advanceSwellInfo" :class="{'active': yesCreatedAlert, 'red': depositClauseRed}")
            checkbox(:label="$trans('order.depoist_clause_text')", :checked="0" autoReverse="1" eventName="depositClause", checkId="depositClauseId")
            .ck_depositClauseBox(@click.stop="depositSettLement.isShowClause = !depositSettLement.isShowClause")
                i.ck_depositClauseIcon.font-36.icon-warning_icon
                .ck_depositClauseRules.font-22(v-html="$trans('order.depoist_rules')", :class="{'open': depositSettLement.isShowClause}")

        //- 订单确认结算区
        .ck_checkoutContainer(v-if="!PD.total.advanceSwellInfo")
            .ck_checkoutTitle.font-32
                | {{ $trans('order.total_ost') }}
                span.ck_checkoutTitleTip.font-26(v-if="PD.total.giveIntegral" v-html="$trans('order.total_giveintegral', [PD.total.giveIntegral])")

            ul.ck_confirmList
                li.ck_confirmItem.font-30(v-for="(priceItem, priceIndex) in settlement.priceItems" v-if="priceItem.value != 0 || priceItem.showValue != 0")
                    span.ck_confirmItemTitle {{ priceItem.title }}
                    span.ck_confirmItemPrice(:class="{'active': priceItem.ratio < 0}")
                        | {{ priceItem.ratio >= 0 || (priceItem.value == 0 && priceItem.showValue == 0) ? '' : '-' }}
                        | {{ currency | onlyAddSymbol(priceItem.showValue) }}

        //- 定金膨胀版 结算面板
        .ck_checkoutContainer(v-else)
            .ck_checkoutTitle.font-32 {{ $trans('order.total_ost') }}

            //- 定金展示
            .ck_depositTotal.red
                h4.ck_depositTotalStep.font-28 {{ $trans('order.depoist_stage') }} 1: {{ $trans('order.depoist_title') }}
                p.ck_depositTotalTime(v-if="depositSettLement.depositTotalCount")
                    i.icon-clock
                    span {{ depositSettLement.depositTotalCount }}

            .ck_confirmList.ckOl_depositTotalItem.bold
                .ck_confirmItem.font-28
                    span.ck_confirmItemTitle {{ $trans('order.depoist_title') }}
                    span.ck_confirmItemPrice {{currency | extraRemainder(depositSettLement.depositTotal)}}

            //- 尾款明细
            .ck_depositTotal
                h4.ck_depositTotalStep.font-28 {{ $trans('order.depoist_stage') }} 2: {{ $trans('order.depoist_final_payment') }}
                p.ck_depositTotalTime
                    i.icon-clock
                    span {{ PD.total.advanceSwellInfo.finalStartTime | templateDateFormat('yyyy-MM-dd hh:mm') }} -- {{ PD.total.advanceSwellInfo.finalEndTime | templateDateFormat('yyyy-MM-dd hh:mm') }}

            ul.ck_confirmList
                li.ck_confirmItem.font-28(v-for="(priceItem, priceIndex) in depositSettLement.priceItems" v-show="priceItem.showValue != 0")
                    span.ck_confirmItemTitle {{ priceItem.title }}
                    span.ck_confirmItemPrice(:class="{'active': priceItem.ratio < 0}")
                        | {{ priceItem.ratio >= 0 ? '' : '-' }}
                        | {{ currency | onlyAddSymbol(priceItem.showValue) }}

                li.ck_confirmItem.font-28.blod
                    span.ck_confirmItemTitle {{ $trans('order.depoist_actual_payment') }}
                    span.ck_confirmItemPrice {{currency | extraRemainder(depositSettLement.balanceDueGrand)}}

        //- 生单按钮
        .ck_checkoutTotal
            //- 默认总价展示
            .ck_checkoutTotalPrice(v-if="!PD.total.advanceSwellInfo")
                p.ck_cktPrice.font-32 {{ settlement.grandTotal.title }} :
                    span.ck_cktPrice-red
                        | {{ settlement.grandTotal.ratio >= 0 || settlement.grandTotal.value == 0 ? '' : '-' }}
                        | {{ currency | extraRemainder(settlement.grandTotal.showValue) }}
                p.ck_cktTip.font-28 {{ settlement.discountTotal.title }} :
                    span {{ currency | onlyAddSymbol(settlement.discountTotal.showValue) }}
            //- 定金膨胀版总价
            .ck_checkoutTotalPrice(v-else)
                p.ck_cktPrice.font-30.ck_depositCKTP {{ settlement.grandTotal.title }} :
                    span.ck_cktPrice-red
                        | {{ depositSettLement.depositTotal >= 0 ? '' : '-' }}
                        | {{currency | extraRemainder(depositSettLement.depositTotal)}}

            .ck_checkoutTotalBtn.font-32(v-finger:tap="createOrderData" :class="{'yesCreated': !yesCreated}")
                span {{ $trans('order.place_your_order') }}

        //- 底部版权标
        .ck_footer
            img(src="./img/moneyback.png")
            img(src="./img/McAfeeSECURE.png")

        //- 底部提示语
        .ck_footerTip.font-28 {{ $trans('order.payment_pre_bottom_tip') }}
</template>

<script>

    import {
        serviceCheckoutCreateOrder,
        serviceCheckoutGetCounponList,
        serviceCheckWalletPassword,
        serviceCheckCurrency,
    } from 'js/service/paycart';
    import { addSymbol, exp10, sub, transform, add, multiply } from 'js/core/currency';
    import { dateFormat } from 'js/utils';
    import rsaEncrypted from 'js/utils/rsaEncryption.js';
    import brushCheck from 'component/brushCheck/brushCheck.js';

    import checkbox from '../paycart_checkbox.vue';
    import shippingmethod from './shipping_method.vue';
    import selectcoupon from './select_coupon.vue';
    import checkaddress from './check_address.vue';
    import paymentchannel from './payment_channel.vue';
    import sendsmsg from './send_smsg.vue';
    import currencycheck from './currency_check.vue';

    export default {
        name: 'orderlist',
        components: {
            checkbox,
            paymentchannel,
        },
        props: ['PD', 'DS'],
        watch: {
            PD: {
                handler() {
                    this.priceItemInit();
                    this.updateDiscoutObj();
                },
                deep: true
            },
            currency: {
                handler() {
                    this.priceItemInit();
                },
                deep: true
            }
        },
        data() {
            return {
                smsInfo: null, // cod支付方式短信验证状态
                yesCreated: true,
                yesCreatedAlert: false, // 弹窗提示拦截生单
                depositClauseRed: false,
                isDropshipping: false, // 是否选择dropshipping
                notCodTotal: 0, // 排除cod金额总价
                toPayInfo: {}, // 去支付数据
                settlement: { // 总价展示对象
                    priceItems: {
                        itemSubTotal: {
                            title: this.$trans('order.item_sub_total'),
                            value: 0,
                            ratio: 1,
                            showValue: 0,
                        },
                        shppingCost: {
                            title: this.$trans('order.shipping_cost'),
                            value: 0,
                            ratio: 1,
                            showValue: 0,
                        },
                        insurance: {
                            title: this.$trans('order.insurance'),
                            value: 0,
                            ratio: 1,
                            showValue: 0,
                        },
                        counponDiscount: {
                            title: this.$trans('order.coupon'),
                            value: 0,
                            ratio: -1,
                            showValue: 0,
                        },
                        pointsDiscount: {
                            title: this.$trans('order.choose_points'),
                            value: 0,
                            ratio: -1,
                            showValue: 0,
                        },
                        promotion: {
                            title: this.$trans('order.promotion'),
                            value: 0,
                            ratio: -1,
                            showValue: 0,
                        },
                        paymentDiscount: {
                            title: this.$trans('order.payment_discount'),
                            value: 0,
                            ratio: -1,
                            showValue: 0,
                        },
                        taxPrice: {
                            title: this.PD.taxPriceTitle,
                            value: 0,
                            ratio: 1,
                            showValue: 0,
                        },
                        codFee: {
                            title: this.$trans('order.cod_cost'),
                            value: 0,
                            ratio: 1,
                            showValue: 0,
                        },
                        payDiscount: {
                            title: this.$trans('order.payment_discount'),
                            value: 0,
                            ratio: -1,
                            showValue: 0,
                        },
                        walletPayDiscount: {
                            title: this.$trans('order.wallet_pay_discount'),
                            value: 0,
                            ratio: -1,
                            showValue: 0,
                        }
                    },
                    grandTotal: {
                        title: this.$trans('order.grand_total'),
                        value: 0,
                        ratio: 1,
                        showValue: 0,
                    },
                    discountTotal: {
                        title: this.$trans('order.have_discount'),
                        value: 0,
                        ratio: 1,
                        showValue: 0,
                    },
                    subTotalPrice: [], // 子订单总价展示
                },
                discountObj: { // 预设优惠方式对象
                    point: {
                        isChecked: 0,
                        isDefault: 0,
                    },
                    coupon: {
                        isChecked: 0,
                        isDefault: 0,
                    }
                },
                depositSettLement: { // 定金膨胀版价格展示对象(临时只做展示用)
                    isShowClause: false,
                    depositTotalCount: '',
                    depositTotal: 0,
                    balanceDueGrand: 0,
                    priceItems: {
                        shppingCost: {
                            title: this.$trans('order.shipping_cost'),
                            ratio: 1,
                            showValue: 0,
                        },
                        insurance: {
                            title: this.$trans('order.insurance'),
                            ratio: 1,
                            showValue: 0,
                        },
                        taxPrice: {
                            title: this.PD.taxPriceTitle,
                            ratio: 1,
                            showValue: 0,
                        },
                        balanceDue: {
                            title: this.$trans('order.depoist_balance_due'),
                            ratio: 1,
                            showValue: 0,
                        },
                        depositDiscount: {
                            title: this.$trans('order.depoist_discount'),
                            ratio: -1,
                            showValue: 0,
                        },
                    },
                },
            };
        },
        created() {
            const vm = this;
            vm.priceItemInit();

            // 监听保费事件
            vm.$bus.$on('insurance', (data) => {
                vm.useInsurance(data);
            });

            // 监听物流方式
            vm.$bus.$on('logistics', (data) => {
                vm.updataLogMode();
            });

            // 监听优惠方式
            vm.$bus.$on('useDiscout', (data) => {
                vm.useDiscount(data);
            });

            // 监听勾选
            vm.$bus.$on('depositClause', (data) => {
                vm.yesCreatedAlert = data.checked;
            });

            // 非点击下拉框关闭所有下拉框
            vm.$bus.$on('domClick', ({ target }) => {
                vm.switchInsuranceTip(false);
                // 其他区域关闭 定金膨胀规则弹窗
                vm.depositSettLement.isShowClause = false;
            });

            // cod 生单短信验证成功 通知生单
            vm.$bus.$on('smsValidateSucess', (data) => {
                vm.smsInfo = data;
                vm.createOrderData();
            });

            // 定金膨胀开启倒计时
            if (vm.PD.total.advanceSwellInfo) {
                const depoistEnd = vm.PD.total.advanceSwellInfo.advanceEndTime * 1000;
                const thisTime = new Date().getTime();
                let countValue = depoistEnd - thisTime;
                if (countValue > 0) {
                    const depoistTimer = setInterval(() => {
                        countValue -= 1000;
                        if (countValue <= 0) {
                            clearInterval(depoistTimer);
                            vm.depositSettLement.depositTotalCount = '';
                        } else {
                            const day = Math.floor(countValue / 1000 / 60 / 60 / 24);
                            const hour = Math.floor((countValue / 1000 / 60 / 60) % 24);
                            const min = Math.floor((countValue / 1000 / 60) % 60);
                            const sec = Math.floor((countValue / 1000) % 60);
                            const countDownTime = `${hour < 0 ? `0${hour}` : hour}:${min < 0 ? `0${min}` : min}:${sec < 0 ? `0${sec}` : sec}`;

                            vm.depositSettLement.depositTotalCount = vm.$trans('order.depoist_count_down', [day, countDownTime]);
                        }
                    }, 1000);
                }
            }
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        filters: {
            extraRemainder: (...arg) => {
                let extraValue = arg[1];
                if (arg[0] === 'CLP') { // 目前该币种默认为整数
                    extraValue = exp10(arg[1], -1);
                    extraValue = multiply(sub(extraValue, Math.floor(extraValue)), 10) > 5 ? sub(Math.floor(extraValue) + 1) : Math.floor(extraValue);
                    extraValue = exp10(extraValue, 1);
                }
                return addSymbol(extraValue);
            },
            templateDateFormat(value, type) {
                return dateFormat(value, type);
            }
        },
        methods: {
            priceItemInit() { // 总价区初始化
                const vm = this;
                let tepInsurance = 0;
                let tepShppingCost = 0;
                let tepTaxPrice = 0;
                let tepCodCost = 0;

                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    // 保费总额
                    if (groupItem.logisticsInfo.inssuranceSelected) {
                        tepInsurance = add(tepInsurance, groupItem.logisticsInfo.inssuranceAmount);
                    }
                    // 税费总额
                    tepTaxPrice = add(tepTaxPrice, groupItem.logisticsInfo.defaultLogObj.taxPrice);

                    // 运费叠加
                    tepShppingCost = add(tepShppingCost, groupItem.logisticsInfo.defaultLogObj.logPrice);

                    // cod 手续费叠加
                    tepCodCost = add(tepCodCost, groupItem.logisticsInfo.defaultLogObj.codFee);
                });
                // 订单商品总额 (子订单商品总额叠加)
                vm.settlement.priceItems.itemSubTotal.value = vm.PD.total.goodsAmount;
                // 积分抵扣金额
                vm.settlement.priceItems.pointsDiscount.value = vm.PD.total.integralDeductAmount;
                // 优惠券折扣金额
                vm.settlement.priceItems.counponDiscount.value = vm.PD.total.discountAmount;
                // 保费总额
                vm.settlement.priceItems.insurance.value = tepInsurance;
                // 运费总额
                vm.settlement.priceItems.shppingCost.value = tepShppingCost;
                // 活动折扣
                vm.settlement.priceItems.promotion.value = vm.PD.total.activityDeductAmount;

                const tepTotal = add([
                    vm.settlement.priceItems.itemSubTotal.value,
                    -vm.settlement.priceItems.pointsDiscount.value,
                    -vm.settlement.priceItems.counponDiscount.value,
                    -vm.settlement.priceItems.promotion.value,
                    vm.settlement.priceItems.insurance.value,
                    vm.settlement.priceItems.shppingCost.value
                ]);
                // 快捷支付折扣
                if (
                    vm.PD.total.discountInfo &&
                    vm.PD.total.discountInfo.length > 0 &&
                    vm.PD.total.discountInfo[0] &&
                    tepTotal >= vm.PD.total.discountInfo[0].needPayAmount
                ) {
                    vm.settlement.priceItems.paymentDiscount.value = vm.PD.total.discountInfo[0].payDiscount;
                } else {
                    vm.settlement.priceItems.paymentDiscount.value = 0;
                }
                // 税费总额
                vm.settlement.priceItems.taxPrice.value = tepTaxPrice;
                // cod 手续费总额
                vm.settlement.priceItems.codFee.value = tepCodCost;
                // 总抵扣金额
                vm.settlement.discountTotal.value = add([
                    vm.PD.total.integralDeductAmount,
                    vm.PD.total.discountAmount,
                    vm.PD.total.activityDeductAmount,
                    vm.PD.total.payDiscountDeductAmount,
                ]);

                // 进行合计
                vm.acountGrandTotal();
                // 计算展示价格
                vm.acountShowGrand();
                // 标题动态更新
                vm.acountTitle();

                // 定金膨胀临时版价格展示计算
                if (vm.PD.total.advanceSwellInfo) {
                    vm.depositGrandTotal();
                }
            },
            acountGrandTotal() { // 计算总价
                const vm = this;
                let temporaryTotal = 0;
                for (const item in vm.settlement.priceItems) {
                    const mu = vm.settlement.priceItems[item].value * vm.settlement.priceItems[item].ratio;
                    temporaryTotal = add(temporaryTotal, mu);
                }
                vm.settlement.grandTotal.value = temporaryTotal;

                // 排除cod价格查询支付方式
                vm.notCodTotal = add([
                    vm.settlement.grandTotal.value,
                    -vm.settlement.priceItems.codFee.value,
                ]);
                // 定金膨胀修正支付金额
                if (vm.PD.total.advanceSwellInfo) vm.notCodTotal = vm.PD.total.advanceSwellInfo.advanceAmount || 0;
                vm.$bus.$emit('stableGetChannelList', {});
            },
            acountShowGrand() { // 计算页面展示价格 --- 通过前端转换
                const vm = this;
                // 每次重新计算页面展示价格
                vm.settlement.priceItems.itemSubTotal.showValue = 0;
                vm.settlement.priceItems.pointsDiscount.showValue = 0;
                vm.settlement.priceItems.counponDiscount.showValue = 0;
                vm.settlement.priceItems.shppingCost.showValue = 0;
                vm.settlement.priceItems.insurance.showValue = 0;
                vm.settlement.priceItems.promotion.showValue = 0;
                vm.settlement.priceItems.paymentDiscount.showValue = 0;
                vm.settlement.priceItems.taxPrice.showValue = 0;
                vm.settlement.priceItems.codFee.showValue = 0;
                vm.settlement.priceItems.payDiscount.showValue = 0;
                vm.settlement.priceItems.walletPayDiscount.showValue = 0;
                vm.settlement.grandTotal.showValue = 0;
                vm.settlement.discountTotal.showValue = 0;
                vm.settlement.subTotalPrice = [];

                const tempValueObj = {
                    joPriceArr: [],
                    joPointsDiscountArr: [],
                    joCounponDiscountArr: [],
                    joShppingCostArr: [],
                    joInsuranceArr: [],
                    joPromotionArr: [],
                    joPaymentDiscountArr: [], // 暂时未用到
                    joTaxPrce: [],
                    joCodCost: [],
                };

                // 循环数据结构
                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    // 税费总额
                    tempValueObj.joTaxPrce.push(transform({ price: groupItem.logisticsInfo.defaultLogObj.taxPrice, round: 2 }));
                    // cod 手续费总额
                    tempValueObj.joCodCost.push(transform({ price: groupItem.logisticsInfo.defaultLogObj.codFee, round: 2 }));
                    // 组装联合订单总物流费
                    tempValueObj.joShppingCostArr.push(vm.remainderRule.one(groupItem.logisticsInfo.defaultLogObj.logPrice, 2, false));
                    // 联合订单总保险费
                    if (groupItem.logisticsInfo.inssuranceSelected) {
                        tempValueObj.joInsuranceArr.push(vm.remainderRule.one(groupItem.logisticsInfo.inssuranceAmount, 2, false));
                    }
                    // 联合订单 积分优惠/coupon优惠/活动优惠 --- 创建二维数组
                    tempValueObj.joPointsDiscountArr[groupIndex] = [];
                    tempValueObj.joCounponDiscountArr[groupIndex] = [];
                    tempValueObj.joPromotionArr[groupIndex] = [];
                    // 计算子订单总价
                    const tempSubPricelArr = [];

                    /* eslint-disable */
                    groupItem.shopList.forEach((shopItem, shopIndex) => {
                        shopItem.goodsList.forEach((goodsItem, goodsIdnex) => {
                            // 组装联合订单总价
                            tempValueObj.joPriceArr.push(multiply(vm.remainderRule.one((goodsItem.price || goodsItem.goodPrice), 2, false), goodsItem.qty));
                            // 联合订单 积分优惠/coupon优惠/活动优惠 --- 取值
                            tempValueObj.joPointsDiscountArr[groupIndex].push(goodsItem.integralDeductAmount);
                            tempValueObj.joCounponDiscountArr[groupIndex].push(goodsItem.couponDeductAmount);
                            tempValueObj.joPromotionArr[groupIndex].push(goodsItem.activityDeductAmount);
                            // 子订单商品总价
                            tempSubPricelArr.push(vm.remainderRule.sum({ Symbol: false, prices: [{ price: (goodsItem.price || goodsItem.goodPrice), qty: goodsItem.qty }], discounts: [goodsItem.activityDeductAmount] }));

                            goodsItem.accessoryList.forEach((accessoryItem, accessoryIndex) => {
                                // 组装联合订单总价
                                tempValueObj.joPriceArr.push(multiply(vm.remainderRule.one((accessoryItem.price || accessoryItem.goodPrice), 2, false), accessoryItem.qty));
                                // 联合订单 积分优惠/coupon优惠/活动优惠 --- 取值
                                tempValueObj.joPointsDiscountArr[groupIndex].push(accessoryItem.integralDeductAmount);
                                tempValueObj.joCounponDiscountArr[groupIndex].push(accessoryItem.couponDeductAmount);
                                tempValueObj.joPromotionArr[groupIndex].push(accessoryItem.activityDeductAmount);
                                // 子订单商品总价
                                tempSubPricelArr.push(vm.remainderRule.sum({ Symbol: false, prices: [{ price: (accessoryItem.price || accessoryItem.goodPrice), qty: accessoryItem.qty }], discounts: [accessoryItem.activityDeductAmount] }));
                            });
                        });
                    });
                    /* eslint-enable */
                    // 计算子订单总价
                    const subPrice = add(tempSubPricelArr);
                    const shopCost = vm.remainderRule.one(groupItem.logisticsInfo.defaultLogObj.logPrice, 2, false);
                    let subInsurance = 0;
                    if (groupItem.logisticsInfo.inssuranceSelected) {
                        subInsurance = vm.remainderRule.one(groupItem.logisticsInfo.inssuranceAmount, 2, false);
                    }
                    // 挂载子订单总额数据
                    vm.settlement.subTotalPrice.push(add(subPrice, shopCost, subInsurance));
                });
                // 优惠项特殊处理
                tempValueObj.joPointsDiscountArr.forEach((item, index) => {
                    tempValueObj.joPointsDiscountArr[index] = vm.remainderRule.one(add(item), 0, false);
                });
                tempValueObj.joCounponDiscountArr.forEach((item, index) => {
                    tempValueObj.joCounponDiscountArr[index] = vm.remainderRule.one(add(item), 0, false);
                });
                tempValueObj.joPromotionArr.forEach((item, index) => {
                    tempValueObj.joPromotionArr[index] = vm.remainderRule.one(add(item), 0, false);
                });

                // 挂载展示
                vm.settlement.priceItems.itemSubTotal.showValue = add(tempValueObj.joPriceArr);
                vm.settlement.priceItems.pointsDiscount.showValue = add(tempValueObj.joPointsDiscountArr);
                vm.settlement.priceItems.counponDiscount.showValue = add(tempValueObj.joCounponDiscountArr);
                vm.settlement.priceItems.shppingCost.showValue = add(tempValueObj.joShppingCostArr);
                vm.settlement.priceItems.insurance.showValue = add(tempValueObj.joInsuranceArr);
                vm.settlement.priceItems.promotion.showValue = add(tempValueObj.joPromotionArr);
                vm.settlement.priceItems.paymentDiscount.showValue = transform({ price: vm.settlement.priceItems.paymentDiscount.value, round: 0 });
                vm.settlement.priceItems.taxPrice.showValue = add(tempValueObj.joTaxPrce);
                vm.settlement.priceItems.codFee.showValue = add(tempValueObj.joCodCost);
                // 支付前置特殊价格展示
                let payPreData = {};
                vm.$bus.$emit('queryPayPreInfo', (payPreInfoData) => { payPreData = payPreInfoData; });
                vm.settlement.priceItems.payDiscount.showValue = transform({ price: payPreData.payDiscount, round: 0 });
                if (
                    payPreData.payChannel === 'WALLET' ||
                    (Array.isArray(payPreData.payChannel) && payPreData.payChannel.some(item => item === 'WALLET'))
                ) {
                    vm.settlement.priceItems.walletPayDiscount.showValue = transform({ price: payPreData.useWalletAmout, round: 2 });
                }

                // 组合总价
                vm.settlement.grandTotal.showValue = add([
                    vm.settlement.priceItems.itemSubTotal.showValue,
                    vm.settlement.priceItems.shppingCost.showValue,
                    vm.settlement.priceItems.insurance.showValue,
                    -vm.settlement.priceItems.pointsDiscount.showValue,
                    -vm.settlement.priceItems.counponDiscount.showValue,
                    -vm.settlement.priceItems.promotion.showValue,
                    -vm.settlement.priceItems.paymentDiscount.showValue,
                    vm.settlement.priceItems.taxPrice.showValue,
                    vm.settlement.priceItems.codFee.showValue,
                    -vm.settlement.priceItems.payDiscount.showValue,
                    -vm.settlement.priceItems.walletPayDiscount.showValue,
                ]);
                // 组合总优惠
                vm.settlement.discountTotal.showValue = add([
                    vm.settlement.priceItems.pointsDiscount.showValue,
                    vm.settlement.priceItems.counponDiscount.showValue,
                    vm.settlement.priceItems.promotion.showValue,
                    vm.settlement.priceItems.paymentDiscount.showValue,
                    vm.settlement.priceItems.payDiscount.showValue
                ]);
                // 支付前置全额扣款情况特殊处理
                if (payPreData.isFullAmount) vm.settlement.grandTotal.showValue = 0;
            },
            depositGrandTotal() { // 定金膨胀临时版 --- 价格展示
                const vm = this;
                // 挂载已有数据 保费 \ 运费 \ 税费
                vm.depositSettLement.priceItems.shppingCost.showValue = vm.settlement.priceItems.shppingCost.showValue;
                vm.depositSettLement.priceItems.insurance.showValue = vm.settlement.priceItems.insurance.showValue;
                vm.depositSettLement.priceItems.taxPrice.showValue = vm.settlement.priceItems.taxPrice.showValue;

                // 多币种换算公式进行换算
                const tempValueObj = {
                    joDeposit: [],
                    joFinal: [],
                    joSwellDiscont: [],
                };
                // 循环数据结构
                vm.PD.groupList.forEach((groupItem, groupIndex) => {
                    // 联合订单优惠项 --- 创建二维数组
                    tempValueObj.joSwellDiscont[groupIndex] = [];
                    groupItem.shopList.forEach((shopItem, shopIndex) => {
                        shopItem.goodsList.forEach((goodsItem, goodsIdnex) => {
                            // 组装定金
                            tempValueObj.joDeposit.push(multiply(vm.remainderRule.one((goodsItem.skuAdvanceDetail ? goodsItem.skuAdvanceDetail.advanceAmount : 0), 2, false), goodsItem.qty)); // eslint-disable-line
                            // 组装尾款
                            tempValueObj.joFinal.push(multiply(vm.remainderRule.one(add(goodsItem.price, -(goodsItem.skuAdvanceDetail ? goodsItem.skuAdvanceDetail.advanceAmount : 0)), 2, false), goodsItem.qty)); // eslint-disable-line
                            // 组装定金优惠
                            tempValueObj.joSwellDiscont[groupIndex].push(multiply((goodsItem.skuAdvanceDetail ? goodsItem.skuAdvanceDetail.swellDiscontAmount : 0), goodsItem.qty)); // eslint-disable-line

                            goodsItem.accessoryList.forEach((accessoryItem, accessoryIndex) => {
                                // 组装定金
                                tempValueObj.joDeposit.push(multiply(vm.remainderRule.one((accessoryItem.skuAdvanceDetail ? accessoryItem.skuAdvanceDetail.advanceAmount : 0), 2, false), accessoryItem.qty)); // eslint-disable-line
                                // 组装尾款
                                tempValueObj.joFinal.push(multiply(vm.remainderRule.one(add(accessoryItem.price, -(accessoryItem.skuAdvanceDetail ? accessoryItem.skuAdvanceDetail.advanceAmount : 0)), 2, false), accessoryItem.qty)); // eslint-disable-line
                                // 组装定金优惠
                                tempValueObj.joSwellDiscont[groupIndex].push(multiply((accessoryItem.skuAdvanceDetail ? accessoryItem.skuAdvanceDetail.swellDiscontAmount : 0, accessoryItem.qty))); // eslint-disable-line
                            });
                        });
                    });
                });

                // 优惠项特殊计算
                tempValueObj.joSwellDiscont.forEach((item, index) => {
                    tempValueObj.joSwellDiscont[index] = vm.remainderRule.one(add(item), 0, false);
                });

                // 定金展示
                vm.depositSettLement.depositTotal = add(tempValueObj.joDeposit);
                // 尾款金额展示
                vm.depositSettLement.priceItems.balanceDue.showValue = add(tempValueObj.joFinal);
                // 定金优惠展示
                vm.depositSettLement.priceItems.depositDiscount.showValue = add(tempValueObj.joSwellDiscont);

                // 组合总价
                vm.depositSettLement.balanceDueGrand = add([
                    vm.depositSettLement.priceItems.shppingCost.showValue,
                    vm.depositSettLement.priceItems.insurance.showValue,
                    vm.depositSettLement.priceItems.taxPrice.showValue,
                    vm.depositSettLement.priceItems.balanceDue.showValue,
                    -vm.depositSettLement.priceItems.depositDiscount.showValue
                ]);
                // 支付前置特殊价格展示
                let payPreData = {};
                vm.$bus.$emit('queryPayPreInfo', (payPreInfoData) => { payPreData = payPreInfoData; });
                const payDiscount = transform({ price: payPreData.payDiscount, round: 0 });
                let walletPayAmount = 0;
                if (
                    payPreData.payChannel === 'WALLET' ||
                    (Array.isArray(payPreData.payChannel) && payPreData.payChannel.some(item => item === 'WALLET'))
                ) {
                    walletPayAmount = transform({ price: payPreData.useWalletAmout, round: 2 });
                }
                vm.depositSettLement.depositTotal = add([
                    vm.depositSettLement.depositTotal,
                    -payDiscount,
                    -walletPayAmount
                ]);
                // 支付前置全额扣款情况特殊处理
                if (payPreData.isFullAmount) vm.depositSettLement.depositTotal = 0;
            },
            acountTitle() {
                const vm = this;
                vm.settlement.priceItems.taxPrice.title = vm.PD.taxPriceTitle;
            },
            selectLogist(logisticsGroupList, coordinate) { // 选择物流方式
                const vm = this;
                vm.$alert({
                    title: `<b class="font-32" style="font-weight: bold;">${vm.$trans('order.shipping_method')}</b>`,
                    customClass: 'frombottom shipping_method',
                    // rollfrom: 'bottom',
                    modalName: 'upShow',
                    component: shippingmethod,
                    componentData: {
                        logisticsGroupList,
                        groupIndex: coordinate
                    },
                    okText: vm.$trans('order.submit'),
                    okEvent: 'shippingMethodOk',
                    cancel() {
                        // 清楚选择的物流方式
                        const logModeCDE = vm.PD.groupList[coordinate].logisticsInfo.defaultLogObj.coordinate;
                        vm.PD.groupList[coordinate].logisticsInfo.logisticsGroupList.forEach((logGroupItem, logisticsGroupIndex) => {
                            if (logModeCDE[0] !== undefined) { // 存在坐标1
                                if (+logModeCDE[0] === +logisticsGroupIndex) {
                                    logGroupItem.isChecked = 1;
                                    logGroupItem.isDefault = 1;

                                    if (logModeCDE[1] !== undefined) {
                                        logGroupItem.logisticsModeList.forEach((logisticsModeItem, logisticsModeIndex) => {
                                            if (+logModeCDE[1] === +logisticsModeIndex) {
                                                logisticsModeItem.isChecked = 1;
                                                logisticsModeItem.isDefault = 1;
                                            } else {
                                                logisticsModeItem.isChecked = 0;
                                                logisticsModeItem.isDefault = 0;
                                            }
                                        });
                                    }
                                } else {
                                    logGroupItem.isChecked = 0;
                                    logGroupItem.isDefault = 0;

                                    logGroupItem.logisticsModeList.forEach((logisticsModeItem, logisticsModeIndex) => {
                                        logisticsModeItem.isChecked = 0;
                                        logisticsModeItem.isDefault = 0;
                                    });
                                }
                            }
                        });
                        this.close();
                    }
                });
            },
            updataLogMode() { // 使用物流方式
                const vm = this;
                // 使用物流方式
                vm.$parent.useCurrentLogMode();
                // 价格变动请求税费
                vm.$parent.fillTaxFree();
            },
            useInsurance(data) { // 选择保险
                const vm = this;
                vm.PD.groupList[data.checkId].logisticsInfo.inssuranceSelected = data.checked;
                // 价格变动请求税费
                vm.$parent.fillTaxFree();
            },
            switchInsuranceTip(sign, item) { // 切换展示
                const vm = this;
                if (item) {
                    item.logisticsInfo.isShowInssuranceTip = sign;
                } else {
                    vm.PD.groupList.forEach((groupItem, groupIndex) => {
                        groupItem.logisticsInfo.isShowInssuranceTip = sign;
                    });
                }
            },
            useDiscount(data) { // 选择优惠方式
                const vm = this;
                if (data.checkId === 'coupon') { // 使用优惠券
                    vm.getCouponList().then((resData) => {
                        if (resData.status === 0) {
                            vm.$alert({
                                title: `<b class="font-32" style="font-weight: bold;">${vm.$trans('order.coupon')}</b>`,
                                customClass: 'frombottom',
                                // rollfrom: 'bottom',
                                modalName: 'upShow',
                                component: selectcoupon,
                                componentData: {
                                    couponList: resData.data,
                                },
                                okText: vm.$trans('order.submit'),
                                // okEvent: 'submitCoupon',
                                ok() {
                                    this.$children[0].okClick();
                                }
                            });
                        } else {
                            vm.discountObj[data.checkId].isChecked = +!vm.discountObj[data.checkId].isChecked;
                        }
                    });
                } else if (data.checkId === 'point') { // 使用的是积分
                    let usePoint = 0;
                    if (vm.discountObj.point.isChecked === 1) {
                        usePoint = vm.PD.total.maxIntegral;
                    }
                    vm.$bus.$emit('updateList', {
                        integralNum: usePoint,
                    });
                }
            },
            updateDiscoutObj() { // 更新优惠方式数据对象
                const vm = this;
                if (vm.PD.total.couponCode !== '') {
                    vm.discountObj.coupon.isChecked = 1;
                    vm.discountObj.point.isChecked = 0;
                } else if (vm.PD.total.integralDeductAmount > 0) {
                    vm.discountObj.point.isChecked = 1;
                    vm.discountObj.coupon.isChecked = 0;
                } else {
                    vm.discountObj.point.isChecked = 0;
                    vm.discountObj.coupon.isChecked = 0;
                }
                vm.discountObj.coupon.isDefault = vm.discountObj.coupon.isChecked;
                vm.discountObj.point.isDefault = vm.discountObj.point.isChecked;
            },
            standardPost(url, args) { // post请求跳转页面
                const formEl = document.createElement('form');
                formEl.method = 'post';
                formEl.action = url;
                // args.push({ name: '_token', value: $('meta[name="csrf-token"]').attr('content') });
                const inputStr = `
                    ${args.map(im => `
                        <input type="hidden" name="${im.name}" value='${im.value}'>
                    `).join('')}
                `;
                formEl.innerHTML = inputStr;
                document.getElementsByTagName('body')[0].appendChild(formEl);
                formEl.submit();
                // document.getElementsByTagName('body')[0].removeChild(formEl);
            },
            async createOrderData() { // 创建生单数据结构
                const vm = this;
                if (!vm.yesCreated) return;

                // 结算页生单动作GA埋点数据对比
                window.dataLayer.push({ event: 'triggerCheckout_generatingOrderAction' });

                // 支付前置生单前数据校验组装
                let payPreInfo = {
                    isQuickPay: 1
                };
                vm.$bus.$emit('queryPayPreInfo', (payPreInfoData) => { payPreInfo = payPreInfoData || {}; });
                vm.toPayInfo = {
                    selectPaymentType: 2, // 选择支付方式类型 1:走收银台 2:支付前置
                    channelCode: '', // Y 支付方式
                    currencyCode: vm.$root.currenySign, // Y 币种编码
                    currencyRate: vm.$root.currency.currencyRate, // Y 币种汇率
                    isUseWallet: 0, // N 是否使用电子钱包 1 是 0 否
                    walletPassword: '', // N 电子钱包密码 isUseWallet 必须传密码 否则报错
                    walletAmount: payPreInfo.useWalletAmout, // 电子钱包金额
                };
                if (payPreInfo.isAbnormal || payPreInfo.payChannel === 'COD' || payPreInfo.isQuickPay) { // 支付方式状态异常 或 cod 为传统支付
                    vm.selectPaymentType = 1;
                } else if (Array.isArray(payPreInfo.payChannel) ? payPreInfo.payChannel.length > 0 : payPreInfo.payChannel) { // 支付前置模式
                    if (Array.isArray(payPreInfo.payChannel) && payPreInfo.payChannel.length <= 1) {
                        vm.$toast({ timer: 2000, msg: vm.$trans('order.payment_pre_no_select_channel') });
                        // document.getElementById('paymentChannelFocus').focus();
                        const jump = document.getElementById('paymentChannelFocus');
                        const total = jump.offsetTop;
                        document.body.scrollTop = total;
                        document.documentElement.scrollTop = total;
                        window.pageYOffset = total;
                        return;
                    } else if (Array.isArray(payPreInfo.payChannel) || payPreInfo.payChannel === 'WALLET') { // 组合支付方式 || 电子钱包 需要校验电子钱包密码
                        if (payPreInfo.wallertPwd) {
                            const { status, data, msg } = await vm.checkWalletPwd(rsaEncrypted(payPreInfo.wallertPwd));
                            if (status === 0) { // 校验成功可以生单
                                vm.$bus.$emit('updataWalletStatus', { msg: '', status: 1, errorType: 0 });
                                vm.toPayInfo.channelCode = Array.isArray(payPreInfo.payChannel) ? payPreInfo.payChannel[1] || '' : 'WALLET';
                                vm.toPayInfo.isUseWallet = 1;
                                vm.toPayInfo.walletPassword = rsaEncrypted(payPreInfo.wallertPwd);
                            } else if (data.innerCode === 10040010 || data.innerCode === 10040011 || data.innerCode === 43014) { // 校验异常/失败 || 多次重试密码错误
                                vm.$bus.$emit('updataWalletStatus', { msg, status: 0, errorType: data.errorCount });
                                return;
                            } else {
                                vm.$toast({ timer: 2000, msg });
                                return;
                            }
                        } else {
                            vm.$bus.$emit('updataWalletStatus', { msg: vm.$trans('order.payment_pre_wallet_pwd_check_tip'), status: 0, errorType: 1 });
                            return;
                        }
                    } else { // 其他支付方式直接保存支付信息
                        vm.toPayInfo.channelCode = payPreInfo.payChannel;
                    }
                } else { // 缺失支付方式
                    vm.$toast({ timer: 2000, msg: vm.$trans('order.payment_pre_no_select_channel') });
                    // document.getElementById('paymentChannelFocus').focus();
                    const jump = document.getElementById('paymentChannelFocus');
                    const total = jump.offsetTop;
                    document.body.scrollTop = total;
                    document.documentElement.scrollTop = total;
                    window.pageYOffset = total;
                    return;
                }
                // 请求接口校验币种
                if (vm.toPayInfo.channelCode && vm.toPayInfo.channelCode !== 'WALLET') {
                    const { status, data, msg } = await vm.checkCurrency({
                        channelCode: vm.toPayInfo.channelCode,
                        currencyCode: vm.toPayInfo.currencyCode,
                        currencyRate: vm.toPayInfo.currencyRate,
                        orderCurrencyCode: vm.toPayInfo.currencyCode,
                        t: new Date().getTime()
                    });
                    if (status === 0 && data.errorCode === 46149) { // 币种校验不通过
                        vm.$alert({
                            customClass: 'frombottom currencyCheckAlert',
                            modalName: 'upShow',
                            shadowClose: false,
                            component: currencycheck,
                            componentData: {
                                currencyCode: vm.toPayInfo.currencyCode,
                                channelCode: vm.toPayInfo.channelCode,
                                payChannelCurrencyDtoList: data.payChannelCurrencyDtoList
                            },
                        });
                        return;
                    } else if (status !== 0 || data.errorCode !== 0) {
                        vm.$toast({ timer: 2000, msg });
                        return;
                    }
                }

                // cod 模式 拦截生单 - 发送短信弹窗
                if (vm.DS.payChannelType === 2 && !vm.smsInfo) {
                    vm.$confirm({
                        customClass: 'generateOrderSendSmsg',
                        component: sendsmsg,
                        componentData: {
                            amount: vm.settlement.grandTotal.showValue,
                            toEditAddress: vm.$parent.toEditAddress,
                            addressInfo: vm.DS.addressInfo,
                        },
                    });
                    return;
                }

                // 定金膨胀条款未勾选拦截生单 - 弹窗版
                if (vm.PD.total.advanceSwellInfo && !vm.yesCreatedAlert) {
                    vm.depositClauseRed = true;
                    vm.$toast({ timer: 4000, msg: vm.$trans('order.depoist_clause_tip') });
                    return;
                } else if (vm.PD.total.advanceSwellInfo && vm.DS.isVisitor) { // 定金膨胀商品、拦截访客购物
                    vm.$confirm({
                        title: vm.$trans('order.error'),
                        content: `<div class="checkout_altDataError.font-28">${vm.$trans('order.depoist_created_alert_tip')}</div>`,
                        confirmText: vm.$trans('order.depoist_created_alert_to_register'),
                        cancelText: vm.$trans('order.depoist_created_alert_later'),
                        ok() {
                            window.location.href = `${GLOBAL.DOMAIN_LOGIN}/m-users-a-join.html`;
                        },
                        cancel() {
                            window.location.href = `${GLOBAL.DOMAIN_CART}/cart/index`;
                        }
                    });
                    return;
                }

                vm.yesCreated = false;
                const reqCOD = {
                    addressId: vm.PD.total.addressId, // 地址ID
                    token: vm.PD.total.token, // 防重提交token [checkout 接口提供]
                    couponCode: vm.PD.total.couponCode, // 优惠券码
                    // logisticsCouponCode: '',                                         // 暂时不知道
                    // userRemark: '',                                                  // 用户留言
                    couponDeductAmount: vm.PD.total.discountAmount, // coupon总抵扣金额
                    // logisticCouponDeductAmount: '',                                  // coupon减免的总邮费
                    activityDeductAmount: vm.PD.total.activityDeductAmount, // 活动抵扣金额
                    shippingAmount: vm.settlement.priceItems.shppingCost.value, // 总运费
                    inssuranceAmount: vm.settlement.priceItems.insurance.value, // 总保险费用
                    integralDeductAmount: vm.PD.total.integralDeductAmount, // 积分减免金额
                    orderPayAmount: vm.settlement.grandTotal.value, // 订单应付金额
                    goodGroupList: [], // 商品列表相关信息 (子订单级生单数据)
                    isQuickPay: vm.DS.isQuickPay, // 是否是快捷支付1 是 0 否
                    isQuickBuy: vm.DS.isQuickBuy, // 是否是一键购
                    integralNum: vm.PD.total.availableDeductIntegral, // 使用积分数量
                    isDropShip: vm.isDropshipping, // 是否选择dropshipping
                    quickPayToken: vm.DS.quickPayToken, // 快捷支付时token
                    goodsInfo: [], // 商品列表信息
                    codHandlingFee: vm.settlement.priceItems.codFee.value, // cod 手续费
                    codToken: vm.smsInfo || '', // cod短信校验成功Token
                    billingMode: +(vm.DS.payChannelType === 2), // 结算模式: 0-先款后货 1-货到付款
                };

                // 定金膨胀 - 临时针对定金膨胀订单进行应付金额修正
                if (vm.PD.total.advanceSwellInfo) {
                    reqCOD.orderPayAmount = add(reqCOD.orderPayAmount, -(
                        vm.PD.total.advanceSwellInfo.swellDiscontAmount || 0
                    ));
                }

                vm.PD.groupList.forEach((gItem, gIndex) => {
                    const goodslistInfor = {
                        warehouseCode: gItem.groupInfo.warehouseCode, // 销售仓代码（虚拟仓）
                        goodsGroupId: gItem.logisticsInfo.goodsGroupId, // 商品分组编号
                        logisticsGroupId: gItem.logisticsInfo.defaultLogObj.logGroupId, // 物流分组ID
                        logisticsCode: gItem.logisticsInfo.defaultLogObj.logCode, // 当前使用物流方式编码
                        isInsurance: gItem.logisticsInfo.inssuranceSelected, // 是否使用保险
                    };
                    // 获取商品信息
                    gItem.shopList.forEach((shopItem, shopIndex) => {
                        shopItem.goodsList.forEach((goodsItem, goodsIndex) => {
                            reqCOD.goodsInfo.push({
                                goodSn: goodsItem.goodSn,
                                categoryId: goodsItem.categoryId,
                                qty: goodsItem.qty,
                                warehouseCode: gItem.groupInfo.warehouseCode,
                                saleMark: typeof goodsItem.saleMark !== 'undefined' ? goodsItem.saleMark : 1,
                                saleType: typeof goodsItem.saleType !== 'undefined' ? goodsItem.saleType : 0,
                            });
                            goodsItem.accessoryList.forEach((accessoryItem, accessoryIndex) => {
                                reqCOD.goodsInfo.push({
                                    goodSn: accessoryItem.goodSn,
                                    categoryId: accessoryItem.categoryId,
                                    qty: accessoryItem.qty,
                                    warehouseCode: gItem.groupInfo.warehouseCode,
                                    saleMark: typeof accessoryItem.saleMark !== 'undefined' ? accessoryItem.saleMark : 1,
                                    saleType: typeof accessoryItem.saleType !== 'undefined' ? accessoryItem.saleType : 0,
                                });
                            });
                        });
                    });
                    reqCOD.goodGroupList[gIndex] = goodslistInfor;
                });
                reqCOD.goodGroupList = JSON.stringify(reqCOD.goodGroupList);
                vm.reqCreateOrder(reqCOD);
            },
            // 请求数据 ===
            async getCouponList() { // 请求优惠券列表
                const responseCDS = await serviceCheckoutGetCounponList.http({
                    method: 'POST',
                    data: {},
                });
                return responseCDS;
            },
            async reqCreateOrder(reqData) {
                const vm = this;
                const responseCOD = await serviceCheckoutCreateOrder.http({
                    data: reqData,
                    loading: true
                });
                if (responseCOD.status === 0) {
                    // 生单成功 记录联合订单号写入哈希值
                    if (responseCOD.data.parentOrderSn) {
                        window.location.replace(`#orderSn=${responseCOD.data.parentOrderSn};`);
                    }
                    // 快捷支付
                    if (+vm.DS.isQuickPay !== 0) {
                        // eslint-disable-next-line
                        window.location.href = `${GLOBAL.DOMAIN_ORDER}/payment/express-pay-link?parentOrderSn=${responseCOD.data.parentOrderSn}&token=${vm.DS.quickPayToken}`;
                    } else if (vm.toPayInfo.selectPaymentType === 1) { // 默认方式
                        window.location.href = `${GLOBAL.DOMAIN_ORDER}/payment?parentOrderSn=${responseCOD.data.parentOrderSn}&isCheckout=1`;
                    } else if (vm.toPayInfo.selectPaymentType === 2) { // 支付前置方式
                        const psotData = {
                            channelCode: vm.toPayInfo.channelCode,
                            currencyCode: vm.toPayInfo.currencyCode,
                            currencyRate: vm.toPayInfo.currencyRate,
                            isUseWallet: vm.toPayInfo.isUseWallet,
                            walletPassword: vm.toPayInfo.walletPassword,
                            walletAmount: vm.toPayInfo.walletAmount,
                        };
                        vm.standardPost(`${GLOBAL.DOMAIN_ORDER}/payment?parentOrderSn=${responseCOD.data.parentOrderSn}&isCheckout=1`, [
                            { name: 'prepayInfo', value: JSON.stringify(psotData) },
                        ]);
                    }
                    return;
                } else if (responseCOD.status === 40373285) { // 防刷校验40373285,然后第二次调用登陆接口
                    const checkContent = await brushCheck({
                        action: responseCOD.data.action,
                        siteKey: responseCOD.data.siteKey,
                        recaptchaVersion: responseCOD.data.recaptchaVersion
                    });
                    vm.reqCreateOrder(Object.assign(reqData, {
                        userCenterSuffix: window.location.hash,
                        gbcaptcha: checkContent.gbcaptcha,
                        captchaType: checkContent.captchaType,
                        recaptchaVersion: checkContent.recaptchaVersion
                    }));
                    return;
                } else if (responseCOD.data.innerCode === 10020011) {
                    vm.$bus.$emit('updateList');
                } else if (responseCOD.data.innerCode === 10020021) { // 地址校验错误
                    vm.$confirm({
                        customClass: 'checkAddressAlert',
                        component: checkaddress,
                        componentData: {
                            checkInfo: responseCOD.data.checkData,
                            addressInfo: vm.DS.addressInfo,
                        },
                    });
                } else {
                    vm.$confirm({
                        title: vm.$trans('order.error'),
                        content: `<div class="checkout_altDataError.font-28">${responseCOD.msg}</div>`,
                        confirmText: vm.$trans('order.back_to_cart'),
                        cancelText: vm.$trans('order.cancel'),
                        ok() {
                            window.location.href = `${GLOBAL.DOMAIN_CART}/cart/index`;
                            return false;
                        },
                        cancel() {
                            return window.location.reload();
                        }
                    });
                }
                vm.yesCreated = true;
            },
            checkWalletPwd(password) {
                return serviceCheckWalletPassword.http({
                    errorPop: false,
                    data: {
                        password,
                        t: new Date().getTime()
                    }
                });
            },
            checkCurrency(reqData) {
                return serviceCheckCurrency.http({
                    errorPop: false,
                    params: reqData
                });
            }
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    /* 订单列表 */
    .ck_groupList {
        background: var(--color-main-bg);
    }

    .ck_groupList.bottom {
        margin-bottom: rem(20);
    }

    .ck_title {
        position: relative;
        padding-left: rem(65);
    }

    .ck_titleIcon {
        position: absolute;
        left: 0;
        top: 50%;
        margin-top: rem(-24);
        color: var(--color-text-secondary);
    }

    .ck_titleTxt {
        line-height: rem(90);
        color: var(--color-text-primary);
    }

    .ck_warehouseName {
        padding: 0 rem(30);
        border-bottom: 1px solid var(--color-border);
    }

    .ck_shopName {
        margin: 0 rem(30);
        border-bottom: 1px solid var(--color-border);
    }

    /* 单个商品维度 / 赠品 */
    .order_goodsItem {
        font-size: 0;
        padding: rem(20) rem(30);
    }

    .order_goodsHeader {
        position: relative;
        display: inline-block;
        vertical-align: top;
        width: rem(180);
        height: rem(180);
        margin-right: rem(25);
        overflow: hidden;
    }

    .order_goodsImg {
        width: 100%;
        height: 100%;
    }

    .order_goodsTagCorner {
        position:absolute;
        top: rem(40);
        left: rem(-40);
        width: rem(190);
        height: rem(30);
        line-height: rem(30);
        transform: rotate(-45deg);
        text-align: center;
        color:var(--color-main-bg);
        z-index: 2;
    }
    .order_goodsTagCorner.type_clearance {
        background:var(--color-price);
    }

    .order_goodsTagBot {
        position: absolute;
        left: 0;
        bottom: 0;
        width: 100%;
        height: rem(40);
        background: var(--color-cjf-1);
        color:var(--color-main-bg);
        text-align: center;
        line-height: rem(40);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .order_goodsInfo {
        display: inline-block;
        vertical-align: top;
        padding-top: rem(10);
        width: rem(485);
    }

    .order_goodsTitle {
        display: block;
        color: var(--color-text-primary);
        line-height: rem(30);
        height: rem(30);
        margin-bottom: rem(20);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .order_goodsAttr {
        color: var(--color-text-secondary);
        line-height: rem(30);
        margin-bottom: rem(40);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .order_goodsPriceNum {
        height: rem(50);
        text-align: left;
        line-height: rem(50);
    }

    .order_price {
        color: var(--color-price);
    }

    .order_num {
        float: right;
    }

    .order_goodsDepositTip {
        line-height: rem(50);
        color: var(--warningC);
    }

    /* 物流方式 */
    .ck_statistics {
        padding: rem(20) rem(30);
        border-bottom: 1px solid var(--color-other-lable);
    }

    .ck_stTip {
        margin-top: rem(10);
        line-height: rem(36);
        color: var(--warningC);
    }

    .ck_stShowConten.font-30 {
        line-height: rem(46);
    }

    .ck_stBox {
        float: right;
        font-size: 0;
        text-align: right;
        margin-top: rem(26);
    }

    .ck_stPrice {
        vertical-align: top;
        line-height: rem(40);
    }

    .ck_stIcon {
        vertical-align: top;
        line-height: rem(40);
    }

    .ck_stTitle {
        width:  rem(450);
        color: var(--color-text-primary);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .ck_stTime {
        width:  rem(450);
        color: var(--color-text-secondary);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .ck_stSelectedBox{
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        height: rem(200);
        background: var(--color-price);
    }

    /* 保险选择 */
    .ck_insurance {
        position: relative;
        padding: rem(27) rem(30);
        border-bottom: 1px solid var(--color-other-lable);
        line-height: rem(36);
        color: var(--color-text-primary);
    }

    .ck_insuranceTxt {
        max-width: rem(400);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .ck_insuranceRight {
        position: absolute;
        right: rem(30);
        top: 50%;
        height: rem(36);
        margin-top: rem(-18);
    }

    .ck_insuranceRight .vue_checkbox {
        vertical-align: top;
    }

    .ck_forceCheck {
        display: inline-block;
        vertical-align: top;
        line-height: .48rem;
        width: .48rem;
        height: .48rem;
        border-radius: 50%;
        border: 1px solid var(--color-text-secondary);
        background: var(--color-main-bg);
    }

    .ck_forceCheck.checked {
        position: relative;
        background: var(--color-primary);
        border: 0;
    }

    .ck_forceCheck.checked:before {
        position: absolute;
        left: rem(8);
        top: rem(21);
        content: '';
        display: block;
        width: rem(10);
        height: rem(2);
        background: var(--color-main-bg);
        transform: rotate(45deg);
    }

    .ck_forceCheck.checked:after {
        position: absolute;
        left: rem(14);
        top: rem(18);
        content: '';
        display: block;
        width: rem(15);
        height: rem(2);
        background: var(--color-main-bg);
        transform: rotate(-45deg);
    }

    .ck_insurancePrice {
        margin: 0 rem(20);
    }

    .ck_insuranceIconBox {
        position: relative;
        display: inline-block;
        vertical-align: top;
        width: rem(36);
        height: rem(36);
    }

    .ck_insuranceIconCon {
        display: none;
        position: absolute;
        right: rem(-110);
        top: rem(55);
        width: rem(545);
        padding: rem(15) rem(18);
        border: 1px solid var(--color-text-secondary);
        border-radius: rem(5);
        background: var(--color-main-bg);
        color: var(--color-text-secondary);
        line-height: rem(28);;
        text-align: left;
    }

    .ck_insuranceIconCon.open {
        display: block;
    }

    .ck_insuranceIconCon:before {
        position: absolute;
        right: rem(117);
        top:rem(-8);
        content: "";
        width: rem(15);
        height: rem(15);
        border-left: 1px solid var(--color-text-secondary);
        border-top: 1px solid var(--color-text-secondary);
        background: var(--color-main-bg);
        transform: rotate(45deg);
    }

    .ck_insuranceIconCon span:before {
        content: "*";
    }

    /* 子订单结算 */
    .ck_groupTotal {
        padding: 0 rem(30);
        line-height: rem(90);
        color: var(--color-text-primary);
        text-align: right;
    }

    .ck_groupTotalPrice {
        padding-left: rem(10);
        color: var(--color-price);
    }

    /*
    *   优惠方式选择
    */
    .ck_discountChoice {
        background: var(--color-main-bg);
        margin-bottom: rem(20);
    }

    .ck_discountChoice .vue_checkbox {
        position: absolute;
        right: rem(30);
        top: 50%;
        margin-top: rem(-18);
    }

    .ck_discountTitile {
        line-height: rem(36);
        color: var(--color-text-primary);
    }

    .ck_discountTitilePrice {
        display: inline-block;
        margin-left: rem(20);
    }

    .ck_discountTitilePrice span {
        color: var(--color-price);
    }

    .ck_discountCoupon,
    .ck_discountPoint {
        position: relative;
        padding: rem(25) rem(30);
        padding-right: rem(80);
    }

    .ck_discountCoupon {
        border-bottom: rem(2) solid var(--color-other-lable);
    }

    .ck_discountPoint.none {
        display: none;
    }


    /*
    *   特殊费用提示
    */
    .ck_specialFee {
        position: relative;
        background: var(--color-main-bg);
        padding: rem(30) rem(30) rem(30) rem(85);
        border: 1px solid var(--color-other-lable);
        color: var(--color-price);
        line-height: rem(32);
    }

    .ck_specialFee .icon-warning_icon {
        position: absolute;
        left: rem(30);
        top: 50%;
        transform: translateY(-50%);
        line-height: rem(36);
        color:var(--color-price);
        @mixin font 48;
    }

    .ck_specialFee a {
        color: var(--color-price);
        text-decoration: underline;
    }

    /*
    *   定金膨胀规则勾选
    */
    .ck_depositClause {
        position: relative;
        background: var(--color-main-bg);
        padding: rem(30);
        margin-bottom: rem(20);
    }

    .ck_depositClause .vue_checkboxLabel {
        max-width: rem(620);
        overflow: auto;
        white-space: normal;
    }

    .ck_depositClause .vue_checkboxLabel {
        color: var(--color-text-primary);
    }

    .ck_depositClause.red .vue_checkboxLabel {
        color: var(--color-price);
    }
    .ck_depositClauseBox {
        position: absolute;
        right: rem(40);
        top: 50%;
        transform: translateY(-50%);
        width: rem(36);
        height: rem(36);
    }

    .ck_depositClauseRules {
        display: none;
        position: absolute;
        right: rem(-15);
        bottom: rem(55);
        width: rem(620);
        padding: rem(10) rem(20) rem(20);
        border: 1px solid var(--color-text-secondary);
        border-radius: rem(5);
        background: var(--color-main-bg);
        color: var(--color-text-secondary);
        line-height: rem(28);
        text-align: left;
    }

    .ck_depositClauseRules.open {
        display: block;
    }

    .ck_depositClauseRules:before {
        position: absolute;
        right: rem(25);
        bottom: rem(-8);
        content: "";
        width: rem(15);
        height: rem(15);
        border-right: 1px solid var(--color-text-secondary);
        border-bottom: 1px solid var(--color-text-secondary);
        background: var(--color-main-bg);
        transform: rotate(45deg);
    }

    .ck_depositClauseRules h6 {
        font-weight: bold;
        color: var(--color-text-primary);
        padding: rem(20) 0;
        font-size: rem(30);
    }

    .ck_depositClauseRules ul {
        list-style: decimal;
        padding-left: rem(25);
    }


    /*
    *   结算价格展示区
    */
    .ck_checkoutTitle {
        background: var(--color-main-bg);
        padding: rem(20) rem(30);
        border: 1px solid var(--color-other-lable);
        line-height: rem(50);
        color: var(--color-text-primary);
    }

    .ck_checkoutTitleTip {
        color: var(--color-text-secondary);
    }

    .ck_checkoutTitleTip em {
        color: var(--color-warning);
    }

    .ck_confirmList {
        padding: rem(20) rem(30);
        background: var(--color-main-bg);
    }

    .ck_confirmItem {
        line-height: rem(50);
        color: var(--color-text-secondary);
    }

    .ck_confirmItemTitle {
        display: inline-block;
        max-width: rem(550);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .ck_confirmItemPrice {
        float: right;
        color: var(--color-text-primary);
    }

    .ck_confirmItemPrice.active {
        color: var(--color-price);
    }

    /*
    *   总结算按钮
    */
    .ck_checkoutTotal {
        position: fixed;
        left: 50%;
        bottom: 0;
        z-index: 2;
        width: rem(750);
        margin-left: rem(-375);
        border-top: 1px solid var(--color-border);
        background: var(--color-main-bg);
        font-size: 0;
    }

    .ck_checkoutTotalPrice {
        display: inline-block;
        vertical-align: top;
        padding: rem(20) rem(10) rem(20) rem(30);
        width: rem(450);
    }

    .ck_cktPrice {
        line-height: rem(40);
        color: var(--color-text-primary);
    }

    .ck_cktPrice-red {
        color: var(--color-price);
    }

    .ck_cktTip {
        line-height: rem(30);
        color: var(--color-text-secondary);
    }

    .ck_checkoutTotalBtn {
        position: relative;
        display: inline-block;
        vertical-align: top;
        width: rem(300);
        background: var(--color-primary);
        min-height: rem(110);
        text-align: center;
        font-weight: bold;
    }

    .ck_checkoutTotalBtn span {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: rem(280);
    }

    .ck_checkoutTotalBtn.yesCreated {
        background: var(--disableC);
    }

    /*
    *   提示信息弹窗内容样式
    */
    .checkout_altDataError.font-28 {
        word-break: break-all;
        text-align: center;
    }

    /*
    *   定金膨胀版 - 结算面板
    */
    .ck_depositCKTP.ck_cktPrice {
        line-height: rem(70);
    }

    .ck_depositTotal {
        padding: rem(20) rem(30);
        background: var(--attr-bg);
    }

    .ck_depositTotalStep {
        line-height: rem(44);
        font-weight: bold;
    }

    .ck_depositTotalTime {
        position: relative;
        line-height: rem(40);
        padding-left: rem(50)
    }

    .ck_depositTotalTime i {
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
    }

    .ck_depositTotal.red {
        color: var(--color-price);
        background: var(--color-cjfUser-50);
    }

    .ckOl_depositTotalItem {
        margin: 0;
    }

    .ckOl_depositTotalItem.bold,
    .ck_confirmItem.bold {
        font-weight: bold;
    }

    .ckOl_depositTotalItem.bold .ck_confirmItem {
        color: var(--color-text-primary);
    }

    /*
    *   底部版权标
    */
    .ck_footer {
        padding: rem(24) 0;
        text-align: center;
    }

    .ck_footer img {
        vertical-align: top;
        margin: 0 rem(10);
        width: rem(116);
        height: rem(72);
    }

    /* 底部提示语 */
    .ck_footerTip {
        line-height: rem(38);
        padding: rem(10) rem(30);
        color: var(--color-text-secondary);
    }
</style>
