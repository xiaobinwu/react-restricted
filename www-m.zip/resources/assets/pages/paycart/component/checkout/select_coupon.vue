<template lang="pug">
    .ck_selectCoupon
        //- 输入优惠券
        p.ck_scInput.font-30(v-finger:tap="inputCoupon") {{ $trans('order.type_coupon_code') }}
            i.ck_scInputIcon.icon-edit

        //- 优惠券列表
        .ck_scCouponList
            .ck_scCouponListTitle.font-30 {{ $trans('order.available_oupon') }}({{ couponList.length }})
            .ck_scCouponListCon(:ref="`kdialog_scroll_wrap`")
                p.ck_scCouponEmpty.font-32(v-if="couponList.length <= 0") {{ $trans('order.no_available_coupons') }}
                ul.ck_scCouponUl(v-if="couponList.length > 0")
                    li.ck_scCouponItem(v-for="couponItem in couponList" v-finger:tap="selectCouponItem.bind('', couponItem)")
                        .ck_scCouponItemPrice
                            //- 优惠金额
                            .ck_sccipBox(v-if="couponItem.discountForm == 1 || couponItem.discountForm == 2")
                                .ck_sccipCon(v-if="couponItem.type == 10 || couponItem.type == 14")
                                    .ck_sccipNum.font-40 {{currency | $remainder_one(couponItem.save, 0)}}
                                    .ck_sccipTxt.font-22 {{ $trans('order.fixed_price') }}
                                .ck_sccipCon(v-else-if="couponItem.type == 9 || couponItem.type == 13")
                                    .ck_sccipNum.font-40 {{currency | $remainder_one(couponItem.save, 0)}}
                                .ck_sccipCon(v-else-if="(couponItem.type == 8 || couponItem.type == 12) && couponItem.fullCondition == 1")
                                    .ck_sccipNum.font-40 {{currency | $remainder_one(couponItem.save, 0)}}
                                    .ck_sccipTxt.font-22 {{ $trans('order.subototal_over') }} {{currency | $remainder_one(couponItem.meetAmount)}}
                                .ck_sccipCon(v-else-if="(couponItem.type == 8 || couponItem.type == 12) && couponItem.fullCondition == 2")
                                    .ck_sccipNum.font-40 {{currency | $remainder_one(couponItem.save, 0)}}
                                    .ck_sccipTxt.font-22 {{ $trans('order.subototal_over') }} {{ couponItem.meetAmount }} {{ $trans('order.coupon_unit_s') }}

                            //- 优惠百分比
                            .ck_sccipBox(v-else-if="couponItem.discountForm == 3")
                                .ck_sccipCon(v-if="couponItem.type == 10 || couponItem.type == 14")
                                    .ck_sccipNum.font-40 {{couponItem.save}}%
                                    .ck_sccipTxt.font-22 {{ $trans('order.fixed_price') }}
                                .ck_sccipCon(v-else-if="couponItem.type == 9 || couponItem.type == 13")
                                    .ck_sccipNum.font-40 {{couponItem.save}}%
                                .ck_sccipCon(v-else-if="(couponItem.type == 8 || couponItem.type == 12) && couponItem.fullCondition == 1")
                                    .ck_sccipNum.font-40 {{couponItem.save}}%
                                    .ck_sccipTxt.font-22 {{ $trans('order.subototal_over') }} {{currency | $remainder_one(couponItem.meetAmount)}}
                                .ck_sccipCon(v-else-if="(couponItem.type == 8 || couponItem.type == 12) && couponItem.fullCondition == 2")
                                    .ck_sccipNum.font-40 {{couponItem.save}}%
                                    .ck_sccipTxt.font-22 {{ $trans('order.subototal_over') }} {{ couponItem.meetAmount }} {{ $trans('order.coupon_unit_s') }}

                        .ck_scCouponItemInfo
                            p.ck_scCouponItemInfoTxt.font-24 {{ $trans('order.for_select_items_only') }}
                            p.ck_scCouponItemInfoTxt.gray.font-24 {{ $trans('order.expried') }}:{{ couponItem.endTime | timeConversion}}

                        span.ck_scCouponItemActive(v-if="isUseCoupon && couponItem.isDefault")
                            i.ck_scCouponItemActiveIcon.icon-confirm.font-28

        //- 不使用优惠券
        p.ck_noUseCoupon.font-30
            checkbox(:label="$trans('order.no_use_coupon')", :checked="+!isUseCoupon", eventName="noUseCoupon")
</template>

<script>
    import { dateFormat } from 'js/utils';
    import checkbox from '../paycart_checkbox.vue';
    import inpcoupon from './inpcoupon.vue';

    export default {
        components: {
            checkbox,
            inpcoupon
        },
        data() {
            /* eslint-disable */
            return {
                couponList: this.$parent.componentData.couponList,  // 优惠券列表数据
                isUseCoupon: 1,                                     // 是否使用优惠券
                inputVal: '',                                       // 用户输入的值
                useCouponVal: '',                                   // 当前使用的
            }
            /* eslint-enable */
        },
        filters: {
            timeConversion: (value) => {
                const endTime = dateFormat(value, 'dd/MM/yyyy');
                return endTime;
            }
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        methods: {
            inputCoupon() { // 输入优惠码弹窗
                const vm = this;
                vm.$confirm({
                    title: vm.$trans('order.coupon'),
                    component: inpcoupon,
                    componentData: {
                        inputVal: vm.inputVal
                    },
                    confirmText: vm.$trans('order.submit'),
                    ok() {
                        // 绑定输入值到使用的地方
                        vm.applyCoupon(vm.inputVal);
                        this.close();
                    },
                    cancelText: vm.$trans('order.cancel'),
                });
            },
            applyCoupon(inputCode) { // 请求验证输入的优惠码
                const vm = this;
                const coupon = inputCode.trim();
                vm.useCoupon(coupon);
            },
            useCoupon(inputCode) {
                const vm = this;
                vm.$bus.$emit('updateList', {
                    couponCode: inputCode,
                });
                // 关闭弹窗
                vm.$parent.close();
            },
            selectCouponItem(couponItem) { // 单选优惠券
                const vm = this;
                if (couponItem.isDefault === 0) {
                    vm.couponList.forEach((item) => {
                        item.isDefault = 0;
                    });
                }
                couponItem.isDefault = !couponItem.isDefault;
                vm.isUseCoupon = couponItem.isDefault;
                vm.changeUseCoupon();
            },
            changeUseCoupon() { // 变更优惠券使用状态
                const vm = this;
                if (!vm.isUseCoupon) {
                    vm.couponList.forEach((item) => {
                        item.isDefault = 0;
                    });
                    vm.useCouponVal = '';
                } else {
                    vm.couponList.forEach((item) => {
                        if (item.isDefault) {
                            vm.useCouponVal = item.couponCode;
                        }
                    });
                }
            },
            okClick() {
                const vm = this;
                vm.useCoupon(vm.useCouponVal);
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
        created() {
            const vm = this;

            // 默认验证一次优惠券使用情况
            vm.changeUseCoupon();

            // 监听弹窗输入值
            vm.$bus.$on('alertInput', (data) => {
                vm.inputVal = data.inputVal;
            });

            // 监听弹窗点击事件
            // vm.$bus.$on('submitCoupon', () => {
            //     vm.useCoupon(vm.useCouponVal);
            // });

            // 监听选中请求
            vm.$bus.$on('noUseCoupon', (data) => {
                vm.isUseCoupon = data.chekced;
                vm.changeUseCoupon();
            });
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';

    .ck_scInput {
        height: rem(96);
        border-bottom: 1px solid var(--color-other-lable);
        color: var(--color-text-primary);
        line-height: rem(96);
    }

    .ck_scInputIcon {
        float: right;
    }

    .ck_scCouponList {
        border-bottom: 1px solid var(--color-other-lable);
    }

    .ck_scCouponListTitle {
        color: var(--color-text-primary);
        line-height: rem(96);
    }

    .ck_scCouponListCon {
        min-height: rem(295);
        max-height: rem(430);
        overflow-y: scroll;
    }

    .ck_scCouponEmpty {
        line-height: rem(295);
        text-align: center;
        color: var(--color-text-secondary);
    }

    .ck_scCouponItem {
        position: relative;
        margin: rem(10) 0;
        font-size: 0;
    }

    .ck_scCouponItem:before {
        position: absolute;
        left: rem(198);
        top: rem(0);
        content: '';
        display: block;
        width: rem(12);
        height: rem(6);
        border-radius: 0 0 50px 50px;
        background: var(--color-main-bg);
        border-bottom: 1px solid var(--color-coupon-border);
        border-left: 1px solid var(--color-coupon-border);
        border-right: 1px solid var(--color-coupon-border);
    }

    .ck_scCouponItem:after {
        position: absolute;
        left: rem(198);
        bottom: rem(-0.5);
        content: '';
        display: block;
        width: rem(12);
        height: rem(6);
        border-radius: 50px 50px 0 0;
        background: var(--color-main-bg);
        border-top: 1px solid var(--color-coupon-border);
        border-left: 1px solid var(--color-coupon-border);
        border-right: 1px solid var(--color-coupon-border);
    }

    .ck_scCouponItemActive {
        position: absolute;
        right: rem(2);
        top: 1px;
        width: 0;
        height: 0;
        border-radius: 0 rem(6) 0 0;
        border-top: rem(31) solid var(--secondaryC);
        border-right: rem(31) solid var(--secondaryC);
        border-bottom: rem(31) solid transparent;
        border-left: rem(31) solid transparent;
    }

    .ck_scCouponItemActive .ck_scCouponItemActiveIcon {
        position: absolute;
        top: rem(-22);
        right: rem(-26);
        font-weight: bold;
        color:var(--color-main-bg);
    }

    .ck_scCouponItemPrice {
        display: inline-block;
        vertical-align: top;
        height: rem(120);
        width: rem(205);
        background: var(--secondaryC);
        border: 1px solid var(--color-coupon-border);
        border-radius: rem(6) 0 0 rem(6);
    }

    .ck_sccipBox {
        width: 100%;
        height: 100%;
        display: table;
        text-align: center;
    }

    .ck_sccipCon {
        display: table-cell;
        vertical-align: middle;
        color:var(--color-main-bg);
    }

    .ck_sccipNum {
        line-break: rem(50);
    }

    .ck_sccipTxt {
        padding: 0 rem(5);
        line-break: rem(26);
    }

    .ck_scCouponItemInfo {
        display: inline-block;
        vertical-align: top;
        height: rem(120);
        width: rem(484);
        background: var(--color-cjfUser-8);
        border: 1px solid var(--color-coupon-border);
        border-radius:  0 rem(6) rem(6) 0;
        padding: rem(28);
    }

    .ck_scCouponItemInfoTxt {
        line-height: rem(32);
        color: var(--color-text-primary);
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .ck_scCouponItemInfoTxt.gray {
        color: var(--color-text-secondary);
    }

    .ck_noUseCoupon {
        line-height: rem(96);
    }
</style>
