<template lang="pug">
    .currencyCheck
        .currencyCheckTop.font-28 {{ $trans('order.payment_pre_check_currency_top', [currencyCode, channelCode]) }}
        .currencyCheckContent
            .currencyCheckListBox(:ref="`kdialog_scroll_wrap`")
                ul.currencyCheckList
                    li.currencyCheckItem(v-for="payChannelCurrencyDtoItem in payChannelCurrencyDtoList", @click="selectCurrency(payChannelCurrencyDtoItem)")
                        span.font-28 {{ payChannelCurrencyDtoItem.currencySign }}
                        span.font-28 {{ payChannelCurrencyDtoItem.currencyCode }}
</template>

<script>
    import PubSub from 'pubsub-js';

    export default {
        data() {
            return {
                currencyCode: this.$parent.componentData.currencyCode,
                channelCode: this.$parent.componentData.channelCode,
                payChannelCurrencyDtoList: this.$parent.componentData.payChannelCurrencyDtoList
            };
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
        methods: {
            selectCurrency(currnecyItem) {
                PubSub.publish('sysUpdateCurrency', {
                    currencyCode: currnecyItem.currencyCode,
                });
                this.$parent.close();
            }
        }
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    /* 重置弹窗样式 */
    .currencyCheckAlert .kdialog_wrap {
        border-radius: 0;
    }
    .currencyCheckAlert .kdialog_content {
        padding: 0;
    }
    .currencyCheckAlert .kdialog_footer {
        display: none;
    }

    /* 内容 */
    .currencyCheckTop {
        padding: rem(16) rem(50);
        line-height: rem(36);
        color: var(--color-text-primary);
        border-bottom: 1px solid var(--color-other-lable);
    }

    .currencyCheckContent {
        padding: rem(20) 0;
    }

    .currencyCheckListBox {
        overflow: hidden;
        max-height: rem(500);
    }

    .currencyCheckList {
        overflow-y: scroll;
    }

    .currencyCheckItem {
        font-size: 0;
        text-align: center;
    }

    .currencyCheckItem span {
        display: inline-block;
        text-align: center;
        width: rem(200);
        height: rem(60);
        line-height: rem(60);
        color: var(--color-text-primary);
    }
</style>
