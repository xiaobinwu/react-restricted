import { trans } from 'js/core/translate.js';
/*
 *  VUE表单验证字段配置对象 - @guoxiu
 *
 *   keyName: {                     // key值
 *       name: '',                  // 标题名
 *       placeholder: '',           // 字段默认背景文案
 *       tipTxt: '',                // 错误提示语 --- vue使用
 *       noteTxt: '',               // 字段说明
 *       verifyState: false,        // 验证是否通过状态
 *       isShow: false,             // 页面是否展示该字段
 *       value: '',                 // 字段值
 *       isOpen: '',                // 是否显示下拉框  国家 || 省份 需要
 *       selectName: '',            // 当前选择的code对应的name  国家 || 省份 需要
 *       validationRules: {         // 验证规则
 *           verifyTxt: {               // 验证规则对应提示语
 *               require: '',               // 该字段是否必填
 *               minlength: '',             // 是否满足最小长度
 *               maxlength: '',             // 是否最大长度
 *               extraReg: '',              // 正则验证规则
 *          },
 *           rules: {                   // 验证规则配置
 *               require: 0,                // 是否是必填字段 0 || 1
 *               minlength: false,          // 最小长度 --- false：不验证 int：验证数字 --- 该规则暂时弃用
 *               maxlength: false,          // 最大长度 --- false：不验证 int：验证数字 --- 该规则暂时弃用
 *               extraReg: '',              // 正则验证规则 --- ''：不验证 reg：正则验证规则
 *          },
 *      },
 *   },
*/

function ValidationConfigFn() {
    return {
        firstName: { // first name
            name: trans('user.address_first_name'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        lastName: { // first name
            name: trans('user.address_last_name'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        email: { // 邮箱
            name: trans('user.address_email_address'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        addressLine1: { // 详细地址
            name: trans('user.street_address1'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        addressLine2: { // 备用地址2    --- N
            name: trans('user.street_address2'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        addressLine3: { // 备用地址3    --- N
            name: trans('user.street_address3'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        addressLine4: { // 备用地址4   --- N
            name: trans('user.street_address4'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        country: { // 国家（使用：国家码 || 国家名）
            name: trans('user.address_country'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: true,
            value: '',
            isOpen: false,
            selectName: '',
            validationRules: {
                verifyTxt: {
                    require: `${trans('user.pleace_select')} ${trans('user.address_country')}`,
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 1,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        province: {// 省份或州（使用：州码 || 州名）
            name: trans('user.address_state'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: true,
            value: '',
            isOpen: false,
            selectName: '',
            validationRules: {
                verifyTxt: {
                    require: `${trans('user.pleace_select')} ${trans('user.address_state')}`,
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 1,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        nationalIdNumber: { // 身份证号
            name: trans('user.national_id_number'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        cityName: { // 城市名
            name: trans('user.address_city'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        phone: { // 手机号
            name: trans('user.address_phone_number'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        postalCode: { // 邮政编码
            name: trans('user.address_zip_code'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        middleName: { // 中间名
            name: trans('user.consignee_middle_name'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        taxNumber: { // 税号
            name: trans('user.tax_id'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        passportNo: { // 护照号
            name: trans('user.consignee_passport_number'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        passportSerial: { // 护照序列号
            name: trans('user.consignee_passport_serial'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        passportIssueDate: { // 护照签发时间
            name: trans('user.passport_issue_date'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        issuingAgency: { // 颁发机构
            name: trans('user.issued_by'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        birthDay: { // 生日
            name: trans('user.date_of_birth'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
        citizenCode: { // 护照国家码
            name: trans('user.citizen_code_name'),
            placeholder: '',
            tipTxt: '',
            noteTxt: '',
            verifyState: false,
            isShow: false,
            value: '',
            validationRules: {
                verifyTxt: {
                    require: '',
                    minlength: '',
                    maxlength: '',
                    extraReg: '',
                },
                rules: {
                    require: 0,
                    minlength: false,
                    maxlength: false,
                    extraReg: '',
                },
            },
        },
    };
}

export default ValidationConfigFn;
