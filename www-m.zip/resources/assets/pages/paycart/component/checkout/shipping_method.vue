<template lang="pug">
    .ck_selectLogistics(:ref="`kdialog_scroll_wrap`")
        .ck_slGroupItem(v-for="(logisticsGroupItem, logisticsGroupIndex) in logisticsGroupList" v-show="logisticsGroupItem.isShow")
            .ck_slGroupItemBox.font-30
                checkbox(:label="logisticsGroupItem.groupName ? logisticsGroupItem.groupName : '组物流方式名'", :associatedData="logisticsGroupList", isradio="1", :checkId="logisticsGroupIndex", :checked="logisticsGroupItem.isDefault", :eventName="'useLog_' + groupIndex" inputName="logGroup")
                p.ck_slGroupItemTime.font-26(v-if="logisticsGroupItem.logisticsModeList.length <= 0") {{ logisticsGroupItem.groupDeliveryTime }} {{ $trans('order.business_days') }}
                p.ck_slGroupItemPrice.font-30(v-if="logisticsGroupItem.logisticsModeList.length <= 0") {{currency | $remainder_one(logisticsGroupItem.groupLogisticsFee)}}

            ul.ck_slModeBox
                li.ck_slModeItem.font-26(v-for="(logisticsModeItem, logisticsModeIndex) in logisticsGroupItem.logisticsModeList" v-show="logisticsModeItem.isShow")
                    checkbox(:label="logisticsModeItem.logisticsName ? logisticsModeItem.logisticsName : '子物流方式名'" :associatedData="logisticsGroupItem.logisticsModeList" :checked="logisticsModeItem.isDefault" :eventName="'useLog_' + groupIndex" inputName="logMode" :checkId="logisticsModeIndex")
                    span.ck_slModeItemTime.font-26 {{ logisticsModeItem.deliveryTime }} {{ $trans('order.business_days') }}
                    div.ck_slModeItemRemoteFee.font-16(v-if="logisticsModeItem.remoteFee > 0" v-finger:tap="tipRemoteFee.bind(this, logisticsModeItem.remoteFee)") !
                    span.ck_slModeItemPrice.font-28 {{currency | $remainder_one(logisticsModeItem.logisticsFee)}}

</template>

<script>
    import { transformSymbol } from 'js/core/currency';
    import checkbox from '../paycart_checkbox.vue';

    export default {
        components: {
            checkbox
        },
        data() {
            return {
                logisticsGroupList: this.$parent.componentData.logisticsGroupList, // 物流方式数据列表
                groupIndex: this.$parent.componentData.groupIndex // 当前所在坐标
            };
        },
        methods: {
            linkageEngine(data) {
                const vm = this;
                vm.logisticsGroupList.forEach((logGroupItem, logisticsGroupIndex) => {
                    if (data.inputName === 'logGroup') { // 顶层
                        logGroupItem.isDefault = logGroupItem.isChecked;

                        // 有子物流方式
                        if (logGroupItem.logisticsModeList.length > 0) {
                            logGroupItem.logisticsModeList.forEach((logisticsModeItem, logisticsModeIndex) => {

                                if (data.checkId === logisticsGroupIndex && logisticsModeIndex === 0) {
                                    logisticsModeItem.isChecked = 1;
                                } else {
                                    logisticsModeItem.isChecked = 0;
                                }
                                logisticsModeItem.isDefault = logisticsModeItem.isChecked;

                            });
                        }

                    } else if (data.inputName === 'logMode') { // 底层
                        const parent = vm.getCurParent(data);
                        if (logisticsGroupIndex === parent) {
                            logGroupItem.isChecked = 1;

                            if (logGroupItem.logisticsModeList.length > 0) {
                                logGroupItem.logisticsModeList.forEach((logisticsModeItem, logisticsModeIndex) => {
                                    logisticsModeItem.isDefault = logisticsModeItem.isChecked;
                                });
                            }
                        } else {
                            logGroupItem.isChecked = 0;

                            if (logGroupItem.logisticsModeList.length > 0) {
                                logGroupItem.logisticsModeList.forEach((logisticsModeItem, logisticsModeIndex) => {
                                    logisticsModeItem.isChecked = 0;
                                    logisticsModeItem.isDefault = logisticsModeItem.isChecked;
                                });
                            }
                        }
                        logGroupItem.isDefault = logGroupItem.isChecked;
                    }
                });
            },
            getCurParent(data) { // 查询当前对象父级
                const vm = this;
                let res = null;
                vm.logisticsGroupList.some((logGroupItem, logGroupIndex) => {
                    if (logGroupItem.logisticsModeList === data.associatedData) {
                        res = logGroupIndex;
                        return true;
                    }
                    return false;
                });
                return res;
            },
            applyLogistics() {
                const vm = this;
                vm.$parent.close();
                vm.$bus.$emit('logistics', {
                    logisticsDataObj: vm.logisticsGroupList,
                    coordinate: vm.groupIndex
                });
            },
            tipRemoteFee(remoteFee) { // 偏远费提示
                const vm = this;
                const remoteTransFee = transformSymbol({ price: remoteFee });

                vm.$alert({
                    content: `<div class="ck_slModeItemRemoteFeeTip font-30">${vm.$trans('order.remote_fee')} ${remoteTransFee}</div>`,
                    okText: vm.$trans('cart.ok'),
                    ok() {
                        this.close();
                    }
                });
            }
        },
        created() {
            const vm = this;

            // 监听切换物流方式事件
            vm.$bus.$off(`useLog_${vm.groupIndex}`);
            vm.$bus.$on(`useLog_${vm.groupIndex}`, (data) => {
                vm.linkageEngine(data);
            });

            // 监听提交按钮触发事件
            vm.$bus.$on('shippingMethodOk', () => {
                vm.applyLogistics();
            });
        },
        beforeDestroy() {
            const vm = this;
            vm.$bus.$off('shippingMethodOk');
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    /*
    *   选择物流方式弹窗
    */
    .shipping_method .confirm {
        font-weight: bold;
    }
    .ck_selectLogistics {
        max-height:rem(750);
        overflow: auto;
    }

    .ck_slGroupItem {
        padding: rem(28) 0;
        border-bottom: 1px solid var(--color-other-lable);
    }

    .ck_slGroupItem:last-child {
        border-bottom: 0;
    }

    .ck_slGroupItemBox {
        position: relative;
    }

    /* 覆盖checkbox组件样式 */
    .ck_slGroupItemBox .vue_checkboxLabel {
        max-width: rem(570);
    }

    .ck_slGroupItemTime {
        padding-left: rem(56);
        margin-top: rem(10);
        line-height: rem(30);
        color: var(--color-text-secondary);
    }

    .ck_slGroupItemPrice {
        position: absolute;
        right: 0;
        top: 50%;
        margin-top: rem(-15);
        line-height: rem(30);
        color: var(--color-text-primary);
    }

    .ck_slModeBox {
        margin-top: rem(10);
    }

    /* 覆盖checkbox组件样式 */
    .ck_slModeItem {
        padding: rem(15) 0 rem(15) rem(56);
    }
    .ck_slModeItem .vue_checkboxLabel {
        max-width: rem(280);
    }

    .ck_slModeItemRemoteFee {
        margin-top: rem(10);
        margin-left: rem(10);
        display: inline-block;
        vertical-align: top;
        width: rem(26);
        height: rem(26);
        border: 1px solid var(--color-text-secondary);
        border-radius: 50%;
        line-height: rem(24);
        text-align: center;
        color: var(--color-text-secondary);
    }

    .ck_slModeItemTime {
        margin-left: rem(10);
        line-height: rem(36);
    }

    .ck_slModeItemRemoteFeeTip {
        padding-top: rem(30);
        text-align: center;
        line-height: rem(40);
    }

    .ck_slModeItemPrice {
        float: right;
    }
</style>
