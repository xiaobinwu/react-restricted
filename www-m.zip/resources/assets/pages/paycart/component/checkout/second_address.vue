<template lang="pug">
    .secondAddress
        .titlewrap
            h4.title.font-34 {{ $trans('order.pleace_include') }}
            p.tip.font-24 {{ $trans('order.second_address_tip') }}

        .content
            form(:ref="`kdialog_scroll_wrap`")
                .secondAddress_item(v-for="(keyItem, keyName) in secondAddressObj" :class="{'require': keyItem.validationRules.rules.require}")
                    label.secondAddress_label.font-34(:class="{'pr': keyName == 'citizenCode'}")
                        span {{ keyItem.name }}：

                    .secondAddress_con(:class="{'error': keyItem.tipTxt}")
                        //- 护照国家码
                        .secondAddress_checkbox(v-if="keyName == 'citizenCode'" :class="{'active': keyItem.value}" v-finger:tap="citizenCodeCheckBox.bind('', keyItem, keyName)")
                        //- 护照签发时间
                        input.secondAddress_conInp.font-30(v-else-if="keyName == 'passportIssueDate'" type="text" :name="keyName" :placeholder="keyItem.placeholder" v-model="keyItem.value" @blur="inpVerific(keyItem, keyName)")
                        //- 默认输入框
                        input.secondAddress_conInp.font-30(v-else type="text" :name="keyName" :placeholder="keyItem.placeholder" v-model="keyItem.value" @input="verification(keyItem.value, keyName)")

                    .secondAddress_tip.font-22 {{ keyItem.tipTxt }}

        .footer
            span.font-34(v-finger:tap="btnOption.bind('', 'cancel')") {{ $trans('order.cancel') }}
            span.font-34(v-finger:tap="btnOption.bind('', 'submit')") {{ $trans('order.submit') }}
</template>

<script>
    import { serviceGetAddressRule } from 'js/service/user';
    import { serviceCheckoutAddressSave } from 'js/service/paycart';
    import { dateFormat } from 'js/utils';
    import validationConfigFn from './validation_config';

    export default {
        data() {
            return {
                checkArr: this.$parent.componentData.checkArr,
                addressData: this.$parent.componentData.addressInfo,
                verifyRulesList: this.$parent.componentData.verifyRulesList,
                configure: null,
                isFirstLoad: true,
                secondAddressObj: {},
            };
        },
        methods: {
            // --- 特殊字段特殊处理 ---
            inpVerific(itemObj, keyName) { // 失效校验
                const vm = this;
                const value = itemObj.value.trim().substring(0, 10);
                // eslint-disable-next-line
                const reg = /((((0[1-9]|[12][0-9]|3[01])\/(0[13578]|1[02]))|((0[1-9]|[12][0-9]|30)\/(0[469]|11))|((0[1-9]|[1][0-9]|2[0-8])\/02))\/([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3}))|(29\/02\/(([0-9]{2})(0[48]|[2468][048]|[13579][26])|((0[48]|[2468][048]|[3579][26])00)))$/;
                if (reg.test(value)) {
                    itemObj.value = value;
                } else {
                    itemObj.value = '';
                }

                vm.verification(itemObj.value, keyName);
            },
            citizenCodeCheckBox(keyItem, keyName) {
                const vm = this;
                if (keyItem.value) {
                    keyItem.value = '';
                } else {
                    keyItem.value = 'RU';
                }
                vm.verification(keyItem.value, keyName);
            },
            // --- 静态方法 ---
            btnOption(type) {
                const vm = this;
                if (type === 'cancel') {
                    vm.$parent.close();
                    return;
                }

                // 当前表单提交校验
                if (!this.submitValidate()) { // 验证不通过不提交表单
                    return;
                }

                const resDataObj = {};
                for (const item in vm.secondAddressObj) {
                    const configureItem = vm.secondAddressObj[item];
                    if (configureItem.isShow) { // 显示的字段
                        if (item === 'country') {
                            resDataObj.countryCode = configureItem.value;
                            resDataObj.countryName = configureItem.selectName;
                        } else if (item === 'province') {
                            if (configureItem.value.length > 50) {
                                configureItem.value = configureItem.value.substring(0, 50);
                            }
                            resDataObj.provinceCode = configureItem.value;
                            if (!vm.provinceList) { // 当省份列表为空时输入的name = code
                                configureItem.selectName = configureItem.value;
                            }
                            resDataObj.provinceName = configureItem.selectName;
                        } else if (item === 'passportIssueDate') { // 针对护照颁发时间向后台传值为时间戳
                            const [M, d, y] = configureItem.value.split('/');
                            const date = new Date(`${d}/${M}/${y}`);
                            let pasDate = date.getTime() / 1000;
                            if (!pasDate) {
                                pasDate = '';
                            } else {
                                resDataObj.passportIssueDate = pasDate;
                            }
                        } else {
                            resDataObj[item] = configureItem.value;
                        }
                    }
                }
                resDataObj.addressId = vm.addressData.addressId;
                vm.editAddress(resDataObj);
            },
            // --- 动态方法 ---
            initKeyData(rulesList) { // 根据用户数据及后台校验规则 格式化 配置对象
                const vm = this;
                // 循环展示字段数据
                vm.checkArr.forEach((checkItem) => {
                    vm.$set(vm.secondAddressObj, checkItem, Object.assign(vm.configure[checkItem]));
                });

                // 循环基础数据更具动态配置更新状态
                for (const configItemKey in vm.secondAddressObj) {
                    const configItem = vm.secondAddressObj[configItemKey];

                    // 加载obs配置验证规则 不使用变异变量
                    let flag = false; // 匹配obs验证规则开关
                    rulesList.forEach((item) => {
                        if (item.address_name === configItemKey) {
                            flag = true;
                            // 匹配obs成功加载该字段数据到基础配置
                            /* eslint-disable */
                            configItem.isShow = true;
                            configItem.validationRules.rules.require = item.is_require;
                            configItem.validationRules.rules.extraReg = item.regex;
                            configItem.validationRules.verifyTxt.require = (item.empty_msg ? (item.empty_msg[vm.langugeSign] || item.empty_msg.en) : '') || '';
                            configItem.validationRules.verifyTxt.extraReg = (item.error_msg ? (item.error_msg[vm.langugeSign] || item.error_msg.en) : '') || '';
                            configItem.placeholder = (item.text_inside_msg ? (item.text_inside_msg[vm.langugeSign] || item.text_inside_msg.en) : '') || '';
                            configItem.noteTxt = (item.text_below_msg ? (item.text_below_msg[vm.langugeSign] || item.text_below_msg.en) : '') || '';
                            /* eslint-enable */
                        }
                    });
                    // 匹配obs规则失败字段清空配置
                    if (!flag && configItemKey !== 'country' && configItemKey !== 'province') {
                        configItem.isShow = false;
                        configItem.validationRules.rules.require = 0;
                        configItem.validationRules.rules.extraReg = false;
                        configItem.validationRules.verifyTxt.require = '';
                        configItem.validationRules.verifyTxt.extraReg = '';
                        configItem.placeholder = '';
                        configItem.noteTxt = '';
                    }

                    // 针对护照颁发时间添加默认值
                    if (configItemKey === 'passportIssueDate') {
                        configItem.placeholder = 'DD/MM/YYYY';
                    }

                    // 展示用户数据中已有的字段 并 首次载入保存用户数据
                    let dataKey = '';
                    let selectKey = '';
                    let isPassDate = false;
                    if (configItemKey === 'country') { // 国家、省份字段需要特殊处理
                        dataKey = 'countryCode';
                        selectKey = 'countryName';
                    } else if (configItemKey === 'province') {
                        dataKey = 'provinceCode';
                        selectKey = 'provinceName';
                    } else {
                        dataKey = configItemKey;
                    }

                    if (configItemKey === 'passportIssueDate') { // 针对护照颁发时间添加默认值
                        isPassDate = true;
                    }

                    if (vm.addressData[dataKey]) {
                        configItem.isShow = true;
                        if (vm.isFirstLoad) { // 首次加载时
                            configItem.value = vm.addressData[dataKey];
                            if (vm.addressData[selectKey]) { // 特殊code字段保存name值
                                configItem.selectName = vm.addressData[selectKey];
                            }

                            if (isPassDate) { // 针对护照颁发时间添加默认值
                                if (configItem.value) {
                                    configItem.value = dateFormat(configItem.value, 'dd/MM/yyyy').substring(0, 10);
                                }
                            }
                        }
                    }

                    // 展示数据结构已经填入的值
                    if (configItem.value) {
                        configItem.isShow = true;
                    }

                    // 特殊字段设置默认规则
                    if (
                        configItemKey === 'taxNumber' ||
                        configItemKey === 'middleName' ||
                        configItemKey === 'passportSerial' ||
                        configItemKey === 'passportNo' ||
                        configItemKey === 'passportIssueDate' ||
                        configItemKey === 'issuingAgency'
                    ) {
                        configItem.isShow = true;
                        configItem.validationRules.rules.require = true;
                        configItem.validationRules.verifyTxt.require = vm.$trans('order.passport_issue_tip');
                        switch (configItemKey) {
                        case 'taxNumber':
                            configItem.placeholder = vm.$trans('order.place_tax_id');
                            break;
                        case 'middleName':
                            configItem.placeholder = vm.$trans('order.place_middle_name');
                            break;
                        case 'passportSerial':
                            configItem.placeholder = vm.$trans('order.place_passport_serial');
                            break;
                        case 'passportNo':
                            configItem.placeholder = vm.$trans('order.place_passport_number');
                            break;
                        case 'passportIssueDate':
                            configItem.placeholder = 'DD/MM/YYYY';
                            break;
                        case 'issuingAgency':
                            configItem.placeholder = vm.$trans('order.place_issued_by');
                            break;
                        default:
                            configItem.placeholder = '';
                        }
                    }
                    configItem.isShow = true;
                }

                vm.isFirstLoad = false;
            },
            verification(value, field) { // 字段验证
                const vm = this;
                const validateObj = vm.secondAddressObj[field];
                value += '';
                value = value.trim();

                let flag = 0; // 验证结果类型：0、验证通过；1、值为空；2、正则匹配不正确

                if (validateObj.validationRules.rules.require) { // 判断字段是否必填
                    if (validateObj.validationRules.rules.extraReg) { // 判断字段是否有正则表达式
                        if (value.length) {
                            const reg = new RegExp(validateObj.validationRules.rules.extraReg);
                            if (reg.test(value)) {
                                flag = 0;
                            } else {
                                flag = 2;
                            }
                        } else {
                            flag = 1;
                        }
                    } else if (value.length) {
                        flag = 0;
                    } else {
                        flag = 1;
                    }
                } else { // 该字段可以不填
                    /* eslint-disable */
                    if (value.length) { // 不为空则需要判断正则验证
                        if (validateObj.validationRules.rules.extraReg) { // 判断字段是否有正则表达式
                            const reg = new RegExp(validateObj.validationRules.rules.extraReg);
                            if (reg.test(value)) {
                                flag = 0;
                            } else {
                                flag = 2;
                            }
                        } else {
                            flag = 0;
                        }
                    } else {
                        flag = 0;
                    }
                    /* eslint-enable */
                }

                // 更新验证结果状态
                if (flag) {
                    validateObj.verifyState = false;
                    if (flag === 1) {
                        validateObj.tipTxt = validateObj.validationRules.verifyTxt.require;
                    } else if (flag === 2) {
                        validateObj.tipTxt = validateObj.validationRules.verifyTxt.extraReg;
                    } else {
                        validateObj.tipTxt = '';
                    }
                } else {
                    validateObj.verifyState = true;
                    validateObj.tipTxt = '';
                }
            },
            submitValidate() {
                const vm = this;
                let index = 0;
                let falseSign = 0;

                for (const item in vm.secondAddressObj) {
                    const configureObj = vm.secondAddressObj[item];
                    index += 1;
                    vm.verification(configureObj.value, item);
                    if (configureObj.verifyState) {
                        falseSign += 1;
                    }
                }
                if (index === falseSign) {
                    return true;
                }
                return false;
            },
            // --- 请求数据 ---
            async getVerifyRules(countryCode) { // 请求后台配置验证规则
                const vm = this;
                vm.showLodding = true;
                let reqParam = 'all';
                if (countryCode) {
                    reqParam = countryCode;
                } else {
                    reqParam = 'all';
                }
                const resGetRules = await serviceGetAddressRule.http({
                    params: {
                        country: reqParam,
                    }
                });

                if (resGetRules.status === 0) { // 数据正常
                    vm.initKeyData(resGetRules.data.list);
                } else { // 数据异常
                    vm.initKeyData([]);
                }
            },
            async editAddress(resDataObj) { // 表单提交请求
                const vm = this;
                const responseTaxData = await serviceCheckoutAddressSave.http({
                    data: resDataObj,
                    loading: true,
                });
                if (responseTaxData.status === 0) {
                    vm.$parent.close();
                    vm.$bus.$emit('updateList', {});
                }
            },
        },
        created() {
            const vm = this;
            vm.configure = validationConfigFn();
            // 请求后台配置规则
            // vm.getVerifyRules(vm.addressData.countryCode);
            vm.initKeyData(vm.verifyRulesList);
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
    };
</script>

<style>
    @import 'pages/paycart/mixins.css';
    /* 重置弹窗样式 */
    .secondAddressAlert .kdialog_wrap {
        overflow: hidden;
        padding: 0;
        width: rem(610);
    }
    .secondAddressAlert .kdialog_content {
        padding: 0;
    }
    .secondAddressAlert .kdialog_close,
    .secondAddressAlert .kdialog_footer {
        display: none;
    }

    .secondAddress .titlewrap {
        text-align: center;
        padding: rem(45) rem(40) rem(20);
    }

    .secondAddress .titlewrap .title {
        line-height: rem(64);
        color: var(--color-text-primary);
    }

    .secondAddress .titlewrap .tip {
        line-height: rem(30);
        color: var(--color-text-primary);
    }

    .secondAddress .content {
        overflow: hidden;
    }

    .secondAddress .content form {
        max-height: rem(695);
        overflow-y: scroll;
        padding: 0 rem(40) rem(20);
    }

    .secondAddress .footer {
        border-top: 1px solid var(--color-other-lable);
        text-align: center;
    }

    .secondAddress .footer span {
        display: inline-block;
        vertical-align: top;
        width: 50%;
        line-height: rem(88);
        color: var(--color-text-primary);
    }

    .secondAddress .footer span:last-child {
        border-left: 1px solid var(--color-other-lable);
        color: var(--color-link);
    }

    .secondAddress_item {
        position: relative;
        margin-bottom: rem(5);
    }

    .secondAddress_item.require .secondAddress_label span:before {
        content: '*';
        color: var(--warningC);
    }

    .secondAddress_label {
        line-height: rem(52);
        color: var(--color-text-secondary);
    }

    .secondAddress_label.pr {
        max-width: rem(550);
    }

    .secondAddress_conInp {
        padding: 0 rem(20);
        line-height: rem(80);
        font-weight: bold;
        width: 100%;
        height: rem(80);
        border: 1px solid var(--color-other-lable);
        border-radius: rem(5);
    }

    .secondAddress_checkbox {
        position: absolute;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        width: rem(35);
        height: rem(35);
        border: 1px solid var(--color-other-lable);
        border-radius: rem(5);
    }

    .secondAddress_checkbox.active {
        border-color: var(--color-warning);
        background: var(--color-warning);
    }

    .secondAddress_checkbox.active:before {
        content: '';
        position: absolute;
        left: rem(8);
        top: rem(12);
        width: rem(4);
        height: rem(16);
        background: var(--color-main-bg);
        transform: rotate(-45deg);
    }

    .secondAddress_checkbox.active:after {
        content: '';
        position: absolute;
        right: rem(8);
        top: rem(5);
        width: rem(4);
        height: rem(22);
        background: var(--color-main-bg);
        transform: rotate(45deg);
    }

    .secondAddress_tip {
        line-height: rem(40);
        color: var(--warningC);
    }
</style>
