<template lang="pug">
    .sendSmsg
        h2.sendSmsg_title.font-34 {{ $trans('order.cod_sms_alert_title') }}
        .sendSmsg_content
            .sendSmsg_topTip.font-24 {{ $trans('order.cod_sms_alert_top', [amount]) }}
            .sendSmsg_info
                p.sendSmsg_infoItem.font-28
                    span {{ addressInfo.countryCode }}
                    span.br {{ phoneCode }}
                    span {{ phoneNum }}
                .sendSmsg_infoItemWrap
                    p.sendSmsg_infoItem.font-28
                        input(type="text" maxlength="10", :placeholder="$trans('order.cod_sms_alert_input_place')", v-model="inpSms" @focus="errTip = ''")
                    a.sendSmsg_sendBtn.btn.small.strong(href="javascript:;", :class="{'sending': sendTimeNum}", @click="sendBtn") {{ sendTimeNum ? `${sendTimeNum} S` : $trans('order.cod_sms_alert_send_btn') }}
            p.sendSmsg_errorTip.font-24(v-show="errTip") {{ errTip }}
            p.sendSmsg_btnTip1.font-24 {{ $trans('order.cod_sms_alert_note') }}
            a.sendSmsg_checkBtn.btn.middle.strong(href="javascript:;" @click="checkoutBtn()") {{ $trans('order.cod_sms_alert_check_btn') }}
            p.sendSmsg_btnTip.font-24 {{ $trans('order.cod_sms_alert_bottom') }}
            .sendSmsg_bottomTxt.font-28
                | {{ addressInfo.countryName }},
                | {{ addressInfo.provinceName }},
                | {{ addressInfo.cityName }},
                | {{ addressInfo.addressLine1 }}
                span(v-if="addressInfo.addressLine2") , {{ addressInfo.addressLine2 }}
            a.sendSmsg_editBtn.font-28(href="javascript:;" @click="toEditAddress()")
                span {{ $trans('order.edit') }}
                i.icon-arrow_tiny
</template>

<script>
import { serviceSendCodSMS, serviceCheckCodSMS } from 'js/service/paycart';

export default {
    data() {
        return {
            amount: this.$parent.componentData.amount,
            toEditAddress: this.$parent.componentData.toEditAddress,
            addressInfo: this.$parent.componentData.addressInfo,
            phoneCode: 0,
            phoneNum: 0,
            sendTimeNum: 0,
            errTip: '',
            inpSms: '',
        };
    },
    methods: {
        phoneNumberCut(value) {
            const vm = this;
            vm.phoneCode = value.match(/(\w*)-/) ? value.match(/(\w*)-/)[1] : 0;
            vm.phoneNum = value.match(/-(\w*)/) ? value.match(/-(\w*)/)[1] : value || 0;
        },
        sendBtn() {
            const vm = this;
            if (vm.sendTimeNum) return;
            vm.sendSMS();
        },
        checkoutBtn() {
            const vm = this;
            if (vm.inpSms.trim()) {
                vm.checkoutSMS(vm.inpSms.trim());
            } else {
                vm.errTip = vm.$trans('order.cod_sms_alert_err_empty');
            }
        },
        // ----- 请求接口 -----
        async sendSMS() {
            const vm = this;
            const { status, data, msg } = await serviceSendCodSMS.http({
                errorPop: false,
                data: {
                    addressId: vm.addressInfo.addressId,
                    phone: vm.addressInfo.phone,
                    t: new Date().getTime()
                }
            });
            if (status === 0 || data.innerCode === 10020101) { // 10020101 重复发送验证码
                vm.sendTimeNum = data.leftSeconds;
                const timer = setInterval(() => {
                    if (vm.sendTimeNum > 0) {
                        vm.sendTimeNum -= 1;
                    } else {
                        clearInterval(timer);
                    }
                }, 1000);
                if (data.innerCode === 10020101) vm.errTip = msg;
            } else {
                vm.$toast({ timer: 2000, msg });
            }
        },
        async checkoutSMS(verifyCode) {
            const vm = this;
            const { status, data, msg } = await serviceCheckCodSMS.http({
                errorPop: false,
                data: {
                    addressId: vm.addressInfo.addressId,
                    phone: vm.addressInfo.phone,
                    t: new Date().getTime(),
                    verifyCode,
                }
            });
            if (status === 0) {
                vm.$parent.close();
                vm.$bus.$emit('smsValidateSucess', data.codToken || '');
            } else if (data.innerCode === 10020103) { // 校验失败
                vm.errTip = data.innerMsg;
            } else {
                vm.$toast({ timer: 2000, msg });
            }
        },
    },
    created() {
        const vm = this;
        vm.phoneNumberCut(vm.addressInfo.phone);
    }
};
</script>

<style>
    @import 'common/css/variable.css';
    /* 重置弹窗样式 */
    .generateOrderSendSmsg .kdialog_content {
        padding: rem(50) rem(40);
    }
    .generateOrderSendSmsg .kdialog_footer {
        display: none;
    }

    .sendSmsg_title {
        color: var(--color-text-primary);
        line-height: rem(52);
        text-align: center;
        font-weight: bold;
    }

    .sendSmsg_content {
        position: relative;
        padding-bottom: rem(40);
    }

    .sendSmsg_topTip {
        font-size: 14px;
        line-height: rem(30);
        margin: rem(10) 0;
        color: var(--color-text-regular);
    }

    .sendSmsg_infoItemWrap {
        position: relative;
    }

    .sendSmsg_infoItemWrap .sendSmsg_infoItem {
        display: inline-block;
        width:rem(250);
    }

    .sendSmsg_infoItem {
        position: relative;
        border-bottom: 1px solid var(--color-border);
        padding: rem(10) 0;
        line-height: rem(40);
        color: var(--color-text-primary);
        margin-bottom: rem(20);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .sendSmsg_infoItem span {
        font-weight: bold;
    }

    .sendSmsg_infoItem span.br {
        padding: 0 rem(20);
        margin-right: rem(20);
        border-right: rem(2) solid var(--disableC);
    }

    .sendSmsg_infoItem input {
        width: 100%;
        padding: 0;
        margin: 0;
        line-height: rem(40);
        outline: none;
        border: none;
    }

    .sendSmsg_infoItem:last-child {
        margin-bottom: rem(10);
    }

    .sendSmsg_sendBtn.btn {
        position: absolute;
        right: 0;
        top: 0;
        height: rem(64);
        line-height: rem(64);
        width: auto;
    }

    .sendSmsg_sendBtn.sending {
        background: var(--color-fill-lable);
        color: var(--color-text-placeholder);
    }

    .sendSmsg_errorTip {
        line-height: rem(30);
        color: var(--warningC);
        margin: rem(5) 0;
    }

    .sendSmsg_btnTip1 {
        line-height: rem(30);
        color: var(--color-text-regular);
    }

    .sendSmsg_checkBtn {
        display: block;
        margin: rem(25) 0;
        line-height: rem(80);
    }

    .sendSmsg_btnTip {
        line-height: rem(30);
        padding-bottom: rem(25);
        color: var(--color-text-regular);
        border-bottom: 1px solid var(--disableC);
    }

    .sendSmsg_bottomTxt {
        margin-top: rem(25);
        line-height: rem(36);
        color: var(--color-text-primary);
    }

    .sendSmsg_editBtn {
        position: absolute;
        right: 0;
        bottom: 0;
        line-height: rem(40);
        color: var(--color-link);
    }

    .sendSmsg_editBtn i {
        vertical-align: top;
    }
</style>
