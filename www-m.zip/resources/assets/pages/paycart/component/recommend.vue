<template lang="pug">
    .recommendList
        h3.font-32 {{ $trans('cart.cart_recommends') }}
        ul.recommend_list
            li.gbGoodsItem(v-for="(item, index) in recommendList", :data-track-key="`${item.goodSn}_${item.warehouseCode}`", :data-index="index + 1")
                a.gbGoodsItem_thumb(:href="item.linkUrl")
                    img.gbGoodsItem_image(src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==", :data-id="`${item.goodSn}_${item.warehouseCode}_${index}`", :data-img="item.goodImg", v-lazy="item.goodImg")

                .gbGoodsItem_wrap
                    a.gbGoodsItem_title(:href="item.linkUrl", :title="item.goodTitle") {{item.goodTitle}}

                    span.gbGoodsItem_price {{currency | $remainder_one(item.displayPrice)}}
                    i.icon-cart_grey_list.gbGoodsItem_cart(v-finger:tap="addtoCart.bind(this, data = {postData:{ goodsSn:item.goodSn, qty:1, warehouseCode:item.warehouseCode }})")
</template>

<script>

    export default {
        props: {
            recommendList: Array,
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        methods: {
            // 添加到购物车
            addtoCart(data) {
                this.$bus.$emit('addtoCart', { postData: data.postData });
            },
        }
    };
</script>

<style>
@import 'pages/paycart/mixins.css';
.recommend_list{
    display: flex;
    justify-content: space-between;
    padding: 0 rem(24);
    flex-wrap: wrap;
    .gbGoodsItem_title{
        height:rem(35);
        line-height:rem(35);
        margin-bottom:rem(20);
    }
    .cart_btn{
        width:rem(700);
        height:rem(80);
        line-height:rem(80);
        margin:rem(40) rem(24);
    }
}

.gbGoodsItem {
    display: flex;
    justify-content: space-between;
    flex-direction: column;
    background: var(--color-main-bg);
    border-radius: rem(8);
    margin-bottom: rem(20);
    width: rem(342);
}

.gbGoodsItem_thumb {
    padding: rem(20);
    height: rem(335);
    display: block;
    position: relative;
    overflow: hidden;
}

.gbGoodsItem_wrap{
    padding: rem(20);
}

.gbGoodsItem_title{
    @mixin font 28;
    height:rem(56);
    line-height:rem(56);
    display: block;
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
}

.gbGoodsItem_image {
    display: block;
    width: 100%;
}

.gbGoodsItem_price{
    @mixin font 32;
    color: var(--color-price);
    width: rem(220);
    height: rem(45);
    line-height: rem(45);
    display: inline-block;
}

.gbGoodsItem_cart{
    float:right;
    width: rem(45);
    height: rem(45);
    line-height: rem(45);
    color: var(--color-text-secondary);
    @mixin font 40;
}

</style>
