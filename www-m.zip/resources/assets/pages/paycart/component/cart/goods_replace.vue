<template lang="pug">
    //- 编辑商品属性
    .goodsReplace
        .goodsPreview
            p.goodsReplace_img
                img(:src="goodsInfo.goodImg", alt="")
            p.goodsName {{goodsInfo.goodTitle}}
            p.price.font-30 {{currency | $remainder_one(goodsInfo.goodPrice)}}
        .scrollArea(:ref="`kdialog_scroll_wrap`")
            dl(v-for="(row, rowIndex) in attrList", :key="rowIndex")
                dt {{row.attrName | capitalize}}:
                dd
                    span.attr(v-for="(item, index) in row.list", :class="curSelect.indexOf(item.prime) > -1 ? 'on' : !item.canSelect ? 'notmatch' : ''", v-finger:tap="switchAttr.bind(this, item, rowIndex)") {{item.attrValue}}

        .footerPreview
            .dl {{ $trans('cart.cart_same_qty') }}:
                changeStock(:goods="goodsInfo", :updateList="false", :cannotMatch="cannotMatch")
            .addToCart.font-32(v-finger:tap="confirmAttr", :class="submitStatus") {{ $trans('cart.add_to_cart') }}

</template>

<script>

    import { serviceCartReplace } from 'js/service/paycart';
    import MultipleAttrSku from '../MultipleAttrSku';

    const changeStock = () => import('../cart/change_stock');

    export default {
        /* eslint-disable */
        data() {
            return {
                cannotMatch: false,     // 选中后是否存在组合
                goodSnQty: '',          // 选中后组合的库存
                goodsInfo: {},          // 存储商品信息
                attrList: [],           // 存储商品属性列表
                goodsList: [],          // 存储商品列表
                postData: {},           // 提交异步请求的数据
                curSelect: [],          // 当前选中的
                submitStatus: '',       // 加入购物车状态
            };
        },
        /* eslint-enable */
        components: {
            changeStock,
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        filters: {
            capitalize(value) {
                if (!value) return '';
                value = value.toString();
                return value.charAt(0).toUpperCase() + value.slice(1);
            }
        },
        created() {
            const vm = this;
            const parent = vm.$parent;
            vm.goodsInfo = parent.goodsInfo;
            vm.goodsList = parent.goodsList;
            vm.goodSnQty = vm.goodsInfo.goodSnQty;
            vm.setMatchAttr();

            // 监听商品数量变更
            vm.$bus.$on('changestock', (data) => {
                vm.goodSnQty = data.num;
            });
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
        methods: {
            computedCurSelect() {
                const status = this.multipleAttrSku.getStatusByAttr(this.curSelect);
                // 合并每个button

                this.attrList.forEach((row, index) => {
                    row.list.forEach((subItem, subIndex) => {
                        subItem.canSelect = status[index][subIndex];
                    });
                });
            },
            getAttrValueByName(list, arrt) {
                let reData;
                list.some((item) => {
                    if (item.name === arrt) {
                        reData = item.value;
                        return true;
                    }
                    return false;
                });

                return reData;

            },
            setMatchAttr() {
                // 只做数据结构初始化
                const parent = this.$parent;

                const goodsList = this.goodsList.map(item => item.primeProduct);
                const attrList = [];
                const curSelect = [];
                const curAttr = this.goodsInfo.attr;

                // 初始化数组结构
                this.attrList = parent.attrList.map((group, groupIndex) => {
                    attrList.push([]);
                    const { attrName } = group;
                    const attrValue = curAttr[attrName] || this.getAttrValueByName(curAttr, attrName);

                    return {
                        attrName,
                        list: group.list.map((attr) => {
                            attrList[groupIndex].push(attr.prime);

                            if (String(attrValue) === String(attr.attrValue)) {
                                curSelect.push(attr.prime);
                            }
                            return {
                                ...attr,
                                canSelect: 1,
                            };
                        })
                    };
                });
                this.curSelect = curSelect;
                this.multipleAttrSku = new MultipleAttrSku(attrList, goodsList);

                this.computedCurSelect();
            },

            removeItem(target, item) {
                const index = target.indexOf(item);
                if (~index) { // eslint-disable-line
                    return !!target.splice(index, 1).length;
                }
                return false;
            },
            switchAttr(item, index) {
                // attrName, attrValue, prime, checked
                let curSelect = [...this.curSelect];

                if (~curSelect.indexOf(item.prime)) { // eslint-disable-line
                    // 有选中直接取消
                    // this.removeItem(curSelect, item.prime);

                    return;
                } else if (item.canSelect) {
                    // 判断同行是否存在
                    const temp = this.attrList[index].list.map(t => t.prime);
                    // 移除当前行的所有选择
                    curSelect.forEach((oldAttr) => {
                        if (~temp.indexOf(oldAttr)) { // eslint-disable-line
                            this.removeItem(curSelect, oldAttr);
                        }
                    });
                } else {
                    // disabled
                    curSelect = [];
                }
                curSelect.push(item.prime);
                if (!(curSelect.length === this.attrList.length)) {
                    this.submitStatus = 'disabled';
                }

                this.curSelect = curSelect;
                this.computedCurSelect();
                this.updateStock();
            },
            // 更新匹配属性的商品信息到库存计算组件
            updateStock() {
                const vm = this;
                const curPrime = vm.curSelect.reduce((res, item) => res * item, 1);
                const canmatch = vm.goodsList.some((item) => {
                    if (item.primeProduct === curPrime) {
                        vm.goodsInfo = Object.assign({}, vm.goodsInfo, item);
                        vm.goodsInfo.goodPrice = item.price;
                        if (vm.goodsInfo.stockNum <= 0 || vm.goodsInfo.allowBuy === 0) {
                            vm.submitStatus = 'disabled';
                        } else {
                            if (vm.goodsInfo.stockNum < vm.goodSnQty) {
                                vm.goodSnQty = vm.goodsInfo.stockNum;
                            }
                            // 更新商品数量组件数据显示
                            vm.goodsInfo.goodSnQty = vm.goodSnQty;
                            vm.submitStatus = '';
                        }
                        vm.cannotMatch = false;
                        return true;
                    }
                    return false;
                });
                if (!canmatch) {
                    vm.cannotMatch = true;
                    vm.submitStatus = 'disabled';
                }
            },
            // 确认更换商品属性
            async confirmAttr() {
                const vm = this;
                if (vm.submitStatus === 'waiting' || vm.submitStatus === 'disabled') { return; }
                vm.submitStatus = 'waiting';
                vm.updateStock();
                if (vm.submitStatus === 'disabled') { return; }

                const postData = {
                    itemId: vm.goodsInfo.itemId,
                    goods: JSON.stringify({
                        activityId: vm.activityId || '',
                        warehouseCode: vm.goodsInfo.virWhCode,
                        goodsSn: vm.goodsInfo.goodSn,
                        qty: vm.goodSnQty,
                    })
                };
                const res = await serviceCartReplace.http({
                    data: postData
                });

                vm.submitStatus = '';
                if (res.status === 0) {
                    // 关闭编辑和滑动
                    // vm.$parent.editGoods(true);
                    // vm.$parent.closeSlideMode();
                    vm.$parent.close();
                    vm.$bus.$emit('getCartList');
                    vm.$toast({ msg: vm.$trans('cart.add_to_cart_success') });
                } else {
                    vm.$toast({ msg: res.msg });
                }
            }
        }
    };
</script>

<style>
@import 'pages/paycart/component/cart/goods_replace.css';
</style>
