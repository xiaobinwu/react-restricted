<template lang="pug">
    .act_list(:ref="`kdialog_scroll_wrap`")
        compCheckbox(v-for="(item, index) in componentData.activityList", :key="index", :checkId='componentData.itemId', :label="item.activityId === 0? $trans('cart.not_join_activity') : item.activityName", :checked="item.activityId === componentData.activityId ? 1:0", :autoReverse="1", :eventName="componentData.eventName", :checkData="{activityId: item.activityId, dialog: parent}")
</template>

<script>

    const compCheckbox = () => import('../paycart_checkbox');
    export default {
        data() {
            return {
                parent: this.$parent,
                componentData: this.$parent.componentData
            };
        },
        components: {
            compCheckbox
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
    };
</script>
