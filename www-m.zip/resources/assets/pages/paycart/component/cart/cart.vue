<template lang='pug'>

    //- 购物车列表
    .cartlist

        //- 购物车为空
        .cart_empty(v-if="nogoods == 2")
            nav#cart_nav.cart_nav.whitebg
                span.back(v-finger:tap="backPrevOrHome")
                    i.icon-back
                h1.font-36 {{ $trans('cart.nav_cart') }}
            p.cart_emptyTxt.font-28 {{$trans('cart.shopping_cart_empty')}}
            .recommend_goods
                h3.font-32 {{ $trans('cart.cart_daily_recommends') }}
                .cart_daily
                    a.cc(:href="vueGlobal.payVars.couponCenter") {{ $trans('cart.cart_coupon_center') }}
                    a.fs(:href="vueGlobal.payVars.flashSale") {{ $trans('cart.cart_flash_sale') }}

                recommendList(v-show="recommendGoods.length > 0", :recommendList="recommendGoods")
                    a.btn.middle.cart_btn.font-32(:href="vueGlobal.payVars.index") {{ $trans('cart.go_shopping') }}

        .cart_table(v-if="nogoods == 0", :class="{'discountTipsCont': showDiscountTip && list.total.discountInfo && list.total.discountInfo.length > 0}")

            //- 购物车导航
            nav#cart_nav.cart_nav.whitebg
                span.back(v-finger:tap="backPrevOrHome")
                    i.icon-back
                h1.font-36 {{ $trans('cart.nav_cart') }}
                span.btn_edit(:class="{'editAll': allEditChecked}", v-show="nogoods == 0")
                    i.icon-edit(v-finger:tap="editMode")
                    i.icon-complete(v-finger:tap="exitEdit")

            nav.cart_discount(v-if="showDiscountTip && list.total.discountInfo && list.total.discountInfo.length > 0")
                h1.font-28 {{ list.total.discountInfo[0] }}
                i.icon-closed.font-28(@click="closeDiscountTip")

            //- 商品列表
            .cart_group(v-if="list.warehouseList.length > 0", v-for="(item, wareIndex) in list.warehouseList", :class="{'expired_group': item.warehouseInfo.code === '0000'}")
                //- 无效仓
                .cart_stock(v-if="item.warehouseInfo.code === '0000'")
                    //- editCheckbox(v-show="allEditChecked", :checkType="'ware'", :checkId="`${wareIndex}_0_0_0`", :checked="item.warehouseInfo.feEditChecked")
                    | {{ $trans('cart.unavailable') }} ({{item.warehouseInfo.goodsNumber}})
                    i.clear_expried.icon-delete_tiny(v-finger:tap="toDelGoods.bind(this, { itemId: '0000', wareIndex })")
                //- 有效仓
                .cart_stock(v-else)
                    compCheckbox(v-show="!allEditChecked", :checkId="`${wareIndex}_0_0_0`", :checked="item.warehouseInfo.isSelected", :checkData="{itemcode: item.warehouseInfo.code, wareIndex:wareIndex, shopIndex:0, groupIdx:0, goodsIndex:0, partsIndex:''}", :eventName="'cartlistSelected'")
                    editCheckbox(v-show="allEditChecked", :checkType="'ware'", :checkId="`${wareIndex}_0_0_0`", :checked="item.warehouseInfo.feEditChecked")
                    i.icon-warehouse
                    | {{item.warehouseInfo.name}} ({{item.warehouseInfo.goodsNumber}})

                //- .cart_shiptip <i class="icon-warning_icon"></i> {{ $trans('cart.warehouse_cannot_ship') }}
                //- 店铺列表
                .cart_shoplist(v-for="(shopItem, shopIndex) in item.shopList")
                    .cart_shoptop(v-if="item.warehouseInfo.code !== '0000'")
                        i.icon-store_gb(v-if="item.warehouseInfo.shopType === 1")
                        i.icon-store(v-else)
                        a.cart_shoptitle.inlinetop(:href="shopItem.shopInfo.shopUrl" v-if="shopItem.shopInfo.isShow") {{shopItem.shopInfo.shopName}}
                        span.cart_shoptitle.inlinetop(v-else="") {{shopItem.shopInfo.shopName}}
                        i.icon-arrow_tiny(v-if="shopItem.shopInfo.isShow")
                        span.cart_coupon(v-if="shopItem.shopInfo.couponList && shopItem.shopInfo.couponList.length > 0", v-finger:tap="getCouponList.bind(this, shopItem.shopInfo.couponList)") {{ $trans('cart.shop_coupon') }}

                    //- 活动列表
                    .cart_actsgroup(v-for='(groupListItem, groupIdx) in shopItem.groupList', :class="[{'noborder' : item.warehouseInfo.code === '0000'}, {'activity': groupListItem.groupInfo.tag}]")
                        .cart_acts(v-if="item.warehouseInfo.code !== '0000' && groupListItem.groupInfo.activity && ((groupListItem.groupInfo.returnCoupon && groupListItem.groupInfo.returnCoupon.length > 0) || groupListItem.groupInfo.text.length > 0)")
                            .cart_acttype
                                //- 活动标签
                                span.cart_actlabel(v-if='groupListItem.groupInfo.tag') {{ $trans('cart.cart_activity') }}
                                i.icon-shops(v-if="groupListItem.groupInfo.activity.isAcrossShop")

                                //- 返券提示文案
                                .cart_actdesc(v-if='groupListItem.groupInfo.returnCoupon && groupListItem.groupInfo.returnCoupon.length > 0')
                                    p.cart_actdescs(v-html="returnCouponRule(groupListItem.groupInfo.returnCoupon)")

                                //- 满减
                                a.cart_actdesc(v-if='groupListItem.groupInfo.returnCoupon.length === 0 && groupListItem.groupInfo.activity.activityType === 1', :href="groupListItem.groupInfo.url")
                                    p.cart_actdescs {{ groupListItem.groupInfo.isJoined? $trans('cart.act_rule_mj_y', currencyChange(currency, [groupListItem.groupInfo.activity.matchedRule.meetAmount, groupListItem.groupInfo.activity.matchedRule.preferentialValue])): $trans('cart.act_rule_mj_n', currencyChange(currency, [(groupListItem.groupInfo.activity.matchedRule.meetAmount - groupListItem.groupInfo.groupSelectedAmount), groupListItem.groupInfo.activity.matchedRule.preferentialValue])) }}
                                    i.icon-arrow_tiny

                                //- 满赠
                                a.cart_actdesc(v-if='groupListItem.groupInfo.returnCoupon.length === 0 && groupListItem.groupInfo.activity.activityType === 2', :href="groupListItem.groupInfo.url")
                                    p.cart_actdescs {{ groupListItem.groupInfo.isJoined ? $trans('cart.act_rule_mz_y', [currencyChange(currency, groupListItem.groupInfo.activity.matchedRule.meetAmount), groupListItem.groupInfo.activity.maxGiftCount]) : $trans('cart.act_rule_mz_n', [currencyChange(currency, groupListItem.groupInfo.activity.matchedRule.meetAmount - groupListItem.groupInfo.groupSelectedAmount), groupListItem.groupInfo.activity.maxGiftCount]) }}
                                    i.icon-arrow_tiny

                                //- 加价购
                                a.cart_actdesc(v-if='groupListItem.groupInfo.returnCoupon.length === 0 && groupListItem.groupInfo.activity.activityType === 4', :href="groupListItem.groupInfo.url")
                                    p.cart_actdescs {{ groupListItem.groupInfo.isJoined? $trans('cart.act_rule_jjg_y', [currencyChange(currency, groupListItem.groupInfo.activity.matchedRule.meetAmount), groupListItem.groupInfo.activity.maxGiftCount]): $trans('cart.act_rule_jjg_n', [currencyChange(currency, groupListItem.groupInfo.activity.matchedRule.meetAmount - groupListItem.groupInfo.groupSelectedAmount), groupListItem.groupInfo.activity.maxGiftCount]) }}
                                    i.icon-arrow_tiny
                                //- 买即赠
                                .cart_actdesc(v-if='groupListItem.groupInfo.returnCoupon.length === 0 && groupListItem.groupInfo.activity.activityType === 5')
                                    p.cart_actdescs {{ groupListItem.groupInfo.text }}
                                //- m元n件
                                a.cart_actdesc(v-if='groupListItem.groupInfo.returnCoupon.length === 0 && groupListItem.groupInfo.activity.activityType === 6', :href="groupListItem.groupInfo.url")
                                    p.cart_actdescs {{groupListItem.groupInfo.isJoined ? $trans('cart.act_rule_mn_y', [currencyChange(currency, groupListItem.groupInfo.activity.matchedRule.meetAmount), groupListItem.groupInfo.activity.matchedRule.meetQty, currencyChange(currency,groupListItem.groupInfo.groupSelectedSave)]): $trans('cart.act_rule_mn_n', [currencyChange(currency, groupListItem.groupInfo.activity.matchedRule.meetAmount), groupListItem.groupInfo.activity.matchedRule.meetQty]) }}
                                    i.icon-arrow_tiny

                                //- M件Y折
                                a.cart_actdesc(v-if='groupListItem.groupInfo.returnCoupon.length === 0 && groupListItem.groupInfo.activity.activityType === 8', :href="groupListItem.groupInfo.url")
                                    p.cart_actdescs(v-if='groupListItem.groupInfo.isJoined') {{ groupListItem.groupInfo.text }}
                                    p.cart_actdescs(v-else) {{ groupListItem.groupInfo.text }}, {{ $trans('cart.add_more_items') }}

                                    i.icon-arrow_tiny

                            p.cart_actbtns(v-if="groupListItem.groupInfo.returnCoupon.length === 0")
                                //- 选择加价购商品
                                span.cart_actbtn(v-if='(groupListItem.groupInfo.activity.activityType === 4 || groupListItem.groupInfo.activity.activityType === 2) && groupListItem.groupInfo.isJoined', v-finger:tap="checkGift.bind(this, groupListItem, item.warehouseInfo.code, groupListItem.groupInfo.activity.activityId)") {{ $trans('cart.items_redeemed') }}

                        //- 商品列表
                        goodsgroup(v-for="(goods, goodsIndex) in groupListItem.goodsList", :key="goodsIndex", :goods="goods", :goodsgroup="groupListItem.groupInfo", :wareIndex="wareIndex", :shopIndex="shopIndex", :groupIdx="groupIdx", :goodsIndex="goodsIndex", :info="item.warehouseInfo", :allEditChecked.sync="allEditChecked")

            //- 总计
            .cart_form-subtotal.font-32(:class="{'shift': allEditChecked}")
                i.batch_act
                p.cart_total {{ $trans('cart.cart_subtotal') }}
                    strong {{currency | $remainder_sum({ prices: list.selectedTotal.amount, discounts: list.selectedTotal.discount, orig: list.total.settleAmount })}}

                //- 支付按钮
                .cart_checkout
                    a.checkout(href="javascript:;", v-finger:tap="checkout.bind(this, 'checkout')") {{ $trans('cart.to_checkout') }}

                    a.quickPay(v-if="pipeline !== 'GBTR'" href="javascript:;", v-for="(qpmItem, qpmIndex) in list.expressChannels", v-finger:tap="checkout.bind(this, qpmItem.payChannel)", :class="{'oneBtn' : qpmIndex == 0}")
                        img(v-if="qpmItem.payChannel === 'PP_Credit_E'", :src="PP_Credit_E")
                        img(v-if="qpmItem.payChannel === 'PP_Express'", :src="pp_Express")
                    a.quickPay.oneBtn(v-if="pipeline !== 'GBTR'" href="javascript:;", v-show="list.expressChannels.length <= 0")
                        img(:src="pp_Express")

            //- 批量编辑
            .cart_editbar.font-30(:class="{'editAll': allEditChecked}")
                editCheckbox(:label="$trans('cart.all')", :checkType="'all'", :checked="batchItems.feEditChecked", :checkId="'all'")
                span.editbarbtn(v-finger:tap="wishlist")
                    i {{ $trans('cart.oper_wishlist') }}
                span.editbarbtn.editbar_del(v-finger:tap="toDelGoods.bind(this, 'editMode')")
                    i {{ $trans('cart.oper_del') }}

        .recommend_goods
            recommendList(v-if="nogoods == 0 && recommendGoods.length > 0", :recommendList="recommendGoods")

</template>

<script>

    import {
        serviceCartList,
        serviceCartChange,
        serviceCartSelect,
        serviceCartGift,
        serviceCartDelete,
        serviceCartSaveActs,
        serviceCartSendQuickPay,
        serviceGetCategoryInfo,
        serviceShipCheck,
        serviceCartCoupon
    } from 'js/service/paycart';
    import Cookies from 'js/utils/cookie';
    import { add } from 'js/core/currency';
    import { COOKIE_UID } from 'js/variables';
    import { getULike } from 'js/service/other';
    import backPrevOrHome from 'js/core/backPrevOrHome';
    import { Paycart, RULES } from 'js/track/define/paycart'; // 埋点js
    import { serviceAddToCart, serviceCollectAdd } from 'js/service/common.js';
    import compCheckbox from '../paycart_checkbox.vue';
    import editCheckbox from './edit_checkbox.vue';
    import recommendList from '../recommend.vue';
    import goodsgroup from './goodsgroup.vue';

    const cartShopCoupon = () => import('./cartShopCoupon.vue');
    const checkgift = () => import('./checkgift.vue');
    const win = window;

    export default {
        components: {
            compCheckbox,
            recommendList,
            cartShopCoupon,
            editCheckbox,
            goodsgroup,
        },
        /* eslint-disable */
        data() {
            return {
                nogoods: 1,                                 // 购物车为空
                recommendGoods: [],                         // 推荐位商品
                loading: false,                             // loading 动画
                allEditChecked: false,                      // 底部全选悬浮按钮
                batchItems: {                               // 编辑状态批量选中
                    feEditChecked: false,
                    list: []
                },
                list: {
                    warehouseList: [],                      // 仓库列表
                    paypalStatus: {},                       // PayPal支付
                    total: {},                              // 价格总计
                    expressChannels: {},                    // 快捷支付方式
                    selectedTotal: {
                        floorPrice: {},                     // 减免字段
                        discount: [],                       // 仓库勾选商品优惠
                        amount: [],                         // 勾选商品单价数组
                    },
                },
                showDiscountTip: 1,                         // 是否显示折扣提示
                temp: {
                    total: {
                        discountInfo: ['st 2800 Newcomers Daily Get $50-$5 on PayPal']
                    }
                },
                cormatCouponData: [],                       // 返券数据暂存数组

                PP_Credit_E: '',                            // 快捷支付图标占位
                pp_Express: '',                             // 快捷支付图标占位
                pipeline: window.GLOBAL.PIPELINE            // 访问国家
            };
        },
        /* eslint-enable */
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        created() {
            const vm = this;
            Object.assign(vm, {
                backPrevOrHome,
                shipCheckIds: {},
            });

            // 默认请求购物车列表
            vm.getCartList('init');

            // 底部悬浮全选/取消选中按钮
            vm.$bus.$on('checkAllEdit', (data) => {
                vm.selectGoods(data);
            });

            // 刷新购物车列表
            vm.$bus.$on('getCartList', (data) => {
                vm.getCartList(data);
            });

            // 变更商品参与活动
            vm.$bus.$on('changeGoodsAct', (data) => {
                vm.changeGoodsAct(data);
            });

            // 加入购物车
            vm.$bus.$on('addtoCart', (data) => {
                vm.addtoCart(data);
            });

            // 收藏商品
            /* vm.$bus.$on('goodsFavor', (data) => {
                vm.favorGoods(data);
            }); */

            // 勾选商品
            vm.$bus.$on('cartlistSelected', (data) => {
                vm.selectGoods(data);
            });

            // 删除商品弹窗
            vm.$bus.$on('delDialog', (data) => {
                vm.toDelGoods(data);
            });
            // 确认删除
            vm.$bus.$on('deleteGoods', (data) => {
                vm.deleteGoods(data);
            });
            // 编辑状态
            vm.$bus.$on('batchSelect', (data) => {
                vm.batchSelect(data);
            });

            // 监听 onload
            vm.onloadLock = false;
            win.addEventListener('load', () => {
                vm.onload();
            }, false);
            setTimeout(() => {
                vm.onload();
            }, 4000);
        },
        methods: {
            // 显示 toast 弹窗
            showToast(msg) {
                if (msg.length) {
                    this.$toast({ msg });
                }
            },
            // 获取购物车列表
            async getCartList(data) {
                const vm = this;
                const body = $('body');

                // 组装埋点数据
                const TrackDataList = {};
                // 组装接入 GTM dataLayer 需要的数据
                const { CODE } = win.dataLayer[0];
                const pcatArray = [];
                const prodidArray = [];
                const gtmCart = {
                    total: {},
                    list: [],
                };

                const { DOMAIN_CART } = GLOBAL;
                const res = await serviceCartList.http({
                    url: `${DOMAIN_CART}/cart/list?t=${+new Date()}`,
                }).catch(() => {
                    // 移除根组件下的 loading
                    if (data === 'init') {
                        vm.$root.$children[0].show();
                    }
                    // 自动关闭弹窗
                    if (data && data.$dialog) {
                        data.$dialog.close();
                    }
                    vm.nogoods = 2;
                    return false;
                });
                // 移除根组件下的 loading
                if (data === 'init') {
                    vm.$root.$children[0].show();
                }

                if (res.status === 0) {
                    const resData = res.data;
                    // 自动关闭弹窗
                    if (data && data.$dialog) {
                        data.$dialog.close();
                    }
                    if (resData && resData.warehouseList.length) {
                        // 有商品
                        vm.nogoods = 0;
                        body.addClass('hasPad-b');
                        const { list } = vm;
                        const selectedDiscount = {};
                        list.expressChannels = resData.expressChannels;
                        list.warehouseList = resData.warehouseList;
                        list.paypalStatus = resData.paypalStatus;
                        list.total = resData.total;
                        list.selectedTotal = {
                            floorPrice: {},
                            discount: [],
                            amount: [],
                        };
                        list.total.floorFields.forEach((item) => {
                            list.selectedTotal.floorPrice[item] = 1;
                        });

                        if (list.expressChannels.length > 0) {

                            // 快捷支付多语言图片
                            const thisLang = GLOBAL.LANG;

                            try {
                                vm.PP_Credit_E = require(`./img/paypal/paypal_credit_${thisLang}.png`); // eslint-disable-line
                            } catch (err) {
                                vm.PP_Credit_E = require('./img/paypal/paypal_credit_en.png'); // eslint-disable-line
                            }
                            try {
                                vm.pp_Express = require(`./img/paypal/buynow_${thisLang}.png`); // eslint-disable-line
                            } catch (err) {
                                vm.pp_Express = require('./img/paypal/buynow_en.png'); // eslint-disable-line
                            }
                        } else {
                            try {
                                vm.pp_Express = require(`./img/paypal/buynow_${thisLang}_dis.png`); // eslint-disable-line
                            } catch (err) {
                                vm.pp_Express = require('./img/paypal/buynow_en_dis.png'); // eslint-disable-line
                            }
                        }

                        // 异步加载优惠券
                        vm.getShopCoupon();

                        // 组装接入 GTM dataLayer 需要的数据 (暂时字段数据取值未知)
                        gtmCart.total = {
                            free_goods_number: '',
                            free_shipping_volume_weight: '',
                            free_shipping_weight: '',
                            free_total_fee: '',
                            goods_amount: 0, // 商品总数量
                            goods_price: list.total.settleAmount, // 结算总金额
                            market_price: list.total.goodsAmount, // 商品总金额
                            no_goods_number: '',
                            real_goods_count: '',
                            save_rate: `${((list.total.discountAmount / list.total.goodsAmount) * 100).toFixed(2)}%`, // 优惠率
                            saving: list.total.discountAmount, // 优惠金额
                            shipping_volume_weight: '',
                            shipping_weight: '',
                        };

                        // 同步购物车数据到aff平台
                        const affCartArray = [];
                        const cookieLinkId = Cookies.get('linkid');

                        list.warehouseList.forEach((wareItem) => {
                            const wareCode = wareItem.warehouseInfo.code;
                            selectedDiscount[wareCode] = [];
                            // 编辑状态
                            this.$set(wareItem.warehouseInfo, 'feEditChecked', false);

                            wareItem.shopList.forEach((shopItem) => {
                                // 编辑状态
                                this.$set(shopItem.shopInfo, 'feEditChecked', false);

                                // 返券按钮
                                const couponList = vm.cormatCouponData[`${wareItem.warehouseInfo.code}_${shopItem.shopInfo.shopCode}`];
                                if (couponList && couponList.length > 0) {
                                    couponList.forEach((item, index) => {
                                        vm.$set(shopItem.shopInfo.couponList, index, item);
                                    });
                                }
                                shopItem.groupList.forEach((group) => {
                                    group.goodsList.forEach((goods) => {

                                        // 编辑状态
                                        this.$set(goods, 'feEditChecked', false);

                                        // 保存禁运状态
                                        const goodsKey = `${goods.goodSn}_${goods.warehouseCode}`;
                                        const canship = vm.shipCheckIds[goodsKey];

                                        vm.shipCheckIds[goodsKey] = canship || 1;
                                        // goods.isCanShip = canship;

                                        let key = `${goods.goodSn}_${goods.activityId}_${goods.warehouseCode}`;
                                        TrackDataList[key] = {
                                            sku: goods.goodSn, // sku
                                            pc: goods.categoryId, // 分类id
                                            k: goods.warehouseCode, // 仓库id
                                            pam: goods.goodSnQty, // 数量
                                        };

                                        // 组装接入 GTM dataLayer 需要的数据
                                        gtmCart.list.push({
                                            goods_id: '', // php数据无商品id
                                            goods_name: goods.goodTitle, // 商品名称
                                            goods_number: goods.goodSnQty, // 商品数量
                                            goods_price: goods.goodPrice, // 商品显示的单价
                                            goods_sn: `${goods.goodSn}${CODE}`, // 商品sku
                                            market_price: goods.linePrice, // 商品划线价格
                                            rec_id: goods.itemId, // 购物车中该记录的唯一标识
                                            categoryId: goods.categoryId, // 商品分类id
                                            categoryName: goods.categoryName, // 商品分类名
                                            isSelected: goods.isSelected, // 当前商品是否勾选
                                        });

                                        // 同步购物车数据到aff平台
                                        if (cookieLinkId) {
                                            affCartArray.push({
                                                link_id: cookieLinkId, // 当前cookie中的 lkid
                                                goods_sku: goods.goodSn, // 商品sku
                                                shop_price: goods.goodPrice, // 商品的单价
                                                add_time: goods.addTime, // 加入购物车时间
                                                user_id: Cookies.get(COOKIE_UID), // 用户id
                                                cart_id: goods.itemId, // 购物车中该记录的唯一标识
                                                quantity: goods.goodSnQty, // 商品数量数量
                                            });
                                        }

                                        // 批量收藏数据组装
                                        if (goods.isSelected) {
                                            // 组装埋点数据
                                            TrackDataList[key].isSelected = true;

                                            // 组装接入 GTM dataLayer 需要的数据
                                            // const webskuWhcode = goods.webGoodSn + wareItem.warehouseInfo.name;
                                            pcatArray.push(goods.categoryId);
                                            prodidArray.push(`${goods.goodSn}${CODE}`);

                                            // 定金膨胀优惠金额
                                            if (goods.skuAdvanceDetail) {
                                                list.selectedTotal.amount.push({
                                                    price: goods.skuAdvanceDetail.advanceAmount,
                                                    Qty: goods.goodSnQty
                                                });
                                                if (goods.goodSnQty > goods.buyLimit) {
                                                    vm.$toast({ msg: vm.$trans('cart.canot_add_number', [goods.buyLimit]) });
                                                }
                                                // eslint-disable-next-line
                                                // selectedDiscount[wareCode].push(multiply(access.skuAdvanceDetail.swellDiscontAmount, access.goodSnQty));
                                            } else {
                                                // 价格计算
                                                goods.priceList.forEach((item) => {
                                                    list.selectedTotal.amount.push({
                                                        price: item.price,
                                                        Qty: item.qty
                                                    });
                                                    if (list.selectedTotal.floorPrice.activityDeductAmount && item.activityDeductAmount > 0) {
                                                        selectedDiscount[wareCode].push(item.activityDeductAmount);
                                                    }
                                                });
                                            }
                                        }

                                        // 设置配件
                                        if (goods.accessoryList.length > 0) {
                                            goods.accessoryList.forEach((access) => {
                                                // 编辑状态
                                                this.$set(access, 'feEditChecked', false);

                                                // 保存禁运状态
                                                const accessKey = `${access.goodSn}_${access.warehouseCode}`;
                                                const iscanship = vm.shipCheckIds[accessKey];

                                                vm.shipCheckIds[accessKey] = iscanship || 1;
                                                // access.isCanShip = iscanship;

                                                key = `${access.goodSn}_${access.activityId}_${access.warehouseCode}`;
                                                TrackDataList[key] = {
                                                    sku: access.goodSn, // sku
                                                    pc: access.categoryId, // 分类id
                                                    k: access.warehouseCode, // 仓库id
                                                    pam: access.goodSnQty, // 数量
                                                };

                                                // 组装接入 GTM dataLayer 需要的数据
                                                gtmCart.list.push({
                                                    goods_id: '', // php数据无商品id
                                                    goods_name: access.goodTitle, // 商品名称
                                                    goods_number: access.goodSnQty, // 商品数量
                                                    goods_price: access.goodPrice, // 商品显示的单价
                                                    goods_sn: `${access.goodSn}${CODE}`, // 商品sku
                                                    market_price: '', // 未知字段
                                                    rec_id: access.itemId, // 购物车中该记录的唯一标识
                                                    categoryId: access.categoryId, // 商品分类id
                                                    categoryName: access.categoryName, // 商品分类名
                                                    isSelected: access.isSelected, // 当前商品是否勾选
                                                });

                                                // 同步购物车数据到aff平台
                                                if (cookieLinkId) {
                                                    affCartArray.push({
                                                        link_id: cookieLinkId, // 当前cookie中的 lkid
                                                        goods_sku: access.goodSn, // 商品sku
                                                        shop_price: access.goodPrice, // 商品的单价
                                                        add_time: access.addTime, // 加入购物车时间
                                                        user_id: Cookies.get(COOKIE_UID), // 用户id
                                                        cart_id: access.itemId, // 购物车中该记录的唯一标识
                                                        quantity: access.goodSnQty, // 商品数量数量
                                                    });
                                                }

                                                // 批量收藏数据组装
                                                if (access.isSelected) {
                                                    // 组装埋点数据
                                                    TrackDataList[key].isSelected = true;

                                                    // 组装接入 GTM dataLayer 需要的数据
                                                    // const webskuWhcode = access.webGoodSn + wareItem.warehouseInfo.name;
                                                    pcatArray.push(access.categoryId);
                                                    prodidArray.push(`${access.goodSn}${CODE}`);

                                                    // 定金膨胀优惠金额
                                                    if (access.skuAdvanceDetail) {
                                                        list.selectedTotal.amount.push({
                                                            price: access.skuAdvanceDetail.advanceAmount,
                                                            Qty: access.goodSnQty
                                                        });

                                                        if (access.goodSnQty > access.buyLimit) {
                                                            vm.$toast({ msg: vm.$trans('cart.canot_add_number', [access.buyLimit]) });
                                                        }
                                                        // eslint-disable-next-line
                                                        // selectedDiscount[wareCode].push(multiply(access.skuAdvanceDetail.swellDiscontAmount, access.goodSnQty));
                                                    } else {
                                                        // 价格计算
                                                        access.priceList.forEach((item) => {
                                                            list.selectedTotal.amount.push({
                                                                price: item.price,
                                                                Qty: item.qty
                                                            });
                                                            if (list.selectedTotal.floorPrice.activityDeductAmount && item.activityDeductAmount > 0) {
                                                                selectedDiscount[wareCode].push(item.activityDeductAmount);
                                                            }
                                                        });
                                                    }
                                                }
                                            });
                                        }
                                    });
                                });
                            });
                        });

                        // 取 pricelist中， 单个商品的活动优惠金额按仓库维度相加后进行多币种换算向下取整
                        for (const code in selectedDiscount) {
                            const arr = selectedDiscount[code];
                            if (arr.length > 0) {
                                list.selectedTotal.discount.push(add(arr));
                            }
                        }

                        if (data === 'init') {
                            vm.categoryInfo = [pcatArray, prodidArray, list, gtmCart];
                            // vm.getCategoryInfo(pcatArray, prodidArray, list, gtmCart);
                        }
                        // 不通邮检查
                        vm.shipCheck();

                        // 组装埋点数据
                        win.TrackData.TrackDataList = TrackDataList;
                        vm.$nextTick(() => {
                            vm.trackLog(data, TrackDataList); // 埋点js
                            if (data === 'init') {
                                // 同步购物车访问日志到aff平台
                                if (cookieLinkId) {
                                    const affCartArrayJson = JSON.stringify(affCartArray);
                                    const img = new Image(1, 1);
                                    img.src = `${GLOBAL.AFF_URL}/?data=${affCartArrayJson}`;
                                }
                            }
                        });

                        // 更新编辑状态数据
                        vm.batchItems.list = vm.list.warehouseList;

                    } else {
                        // 无商品
                        vm.nogoods = 2;
                        // 关闭底部操作栏
                        vm.allEditChecked = false;
                        vm.trackLog(data); // 埋点js
                    }
                } else {
                    // 无商品
                    vm.nogoods = 2;
                    // 关闭底部操作栏
                    vm.allEditChecked = false;
                    vm.showToast(res.msg);
                    vm.trackLog(data); // 埋点js
                }
                /* if (data !== 'init') {
                    // 更新header购物车右上角显示数量
                    PubSub.publish('sysUpdateUserStatus');
                } */
            },
            // 页面曝光
            trackLog(data, TrackDataList) {
                if (data === 'init') {
                    // 推荐位商品
                    this.goodsRecommand(TrackDataList);

                    new Paycart({
                        config: RULES,
                        page: true,
                    }).run();
                }
            },
            // 推荐位商品
            goodsRecommand(list) {
                const goodsinfo = [];
                const vm = this;
                if (list !== undefined) {
                    for (const key in list) {
                        const value = list[key];
                        goodsinfo.push({
                            sku: value.sku,
                            categoryid: value.pc,
                        });
                    }
                }
                getULike({
                    params: {
                        goodsinfo
                    },
                    recommendType: '1030101'
                }).then((res) => {
                    if (res.status === 0) {
                        if (res.data.length > 0) {
                            vm.recommendGoods = res.data;
                        }
                    }
                });
            },
            // 异步加载优惠券
            async getShopCoupon() {
                const vm = this;
                const { list } = vm;
                const { readyState } = document;
                if (readyState === 'complete') {
                    // 组装优惠券请求参数
                    const reqCouponData = [];
                    list.warehouseList.forEach((warehouseItem, warehouseIndex) => {
                        if (warehouseItem.warehouseInfo.code !== '0000') {
                            warehouseItem.shopList.forEach((shopItem, shopIndex) => {
                                shopItem.groupList.forEach((groupItem, groupIndex) => {
                                    groupItem.goodsList.forEach((goodsItem, goodsIndex) => {
                                        reqCouponData.push(`${warehouseItem.warehouseInfo.code}_${shopItem.shopInfo.shopCode}_${goodsItem.goodSn}`);
                                        // 配件
                                        goodsItem.accessoryList.forEach((accessoryItem, accessoryIndex) => {
                                            reqCouponData.push(`${warehouseItem.warehouseInfo.code}_${shopItem.shopInfo.shopCode}_${accessoryItem.goodSn}`); // eslint-disable-line
                                        });
                                    });
                                });
                            });
                        }
                    });
                    // 请求优惠券数据
                    const resCouponList = await serviceCartCoupon.http({
                        data: {
                            goodList: reqCouponData.join(','),
                        }
                    });
                    if (resCouponList.status === 0) {
                        // 格式话优惠券数据
                        resCouponList.data.forEach((resCouponItem, resCouponIndex) => {
                            vm.cormatCouponData[`${resCouponItem.warehouseCode}_${resCouponItem.shopCode}`] = resCouponItem.list;
                        });
                        // 挂载优惠券数据
                        list.warehouseList.forEach((warehouseItem, warehouseIndex) => {
                            warehouseItem.shopList.forEach((shopItem, shopIndex) => {
                                shopItem.shopInfo.couponList = [];

                                const couponList = vm.cormatCouponData[`${warehouseItem.warehouseInfo.code}_${shopItem.shopInfo.shopCode}`];
                                if (couponList && couponList.length > 0) {
                                    couponList.forEach((item, index) => {
                                        vm.$set(shopItem.shopInfo.couponList, index, item);
                                    });
                                }
                            });
                        });
                    }
                }
            },
            returnCouponRule(params) {
                const vm = this;
                const rules = params.map((item) => {
                    let discountVal = '';
                    if (+item.discountForm === 3) {
                        if ((+item.type === 8 || +item.type === 12) && +item.fullCondition === 1) {
                            discountVal = `${item.save}% ${vm.$trans('cart.coupon_off_over')} ${vm.remainderRule.one(item.meetAmount)}`;
                        } else if ((+item.type === 8 || +item.type === 12) && +item.fullCondition === 2) {
                            discountVal = `${item.save}% ${vm.$trans('cart.coupon_off_over')} ${vm.remainderRule.one(item.meetAmount)} ${vm.$trans('cart.coupon_unit_s')}`; // eslint-disable-line
                        } else if (+item.type === 9 || +item.type === 13) {
                            discountVal = `${item.save}% ${vm.$trans('cart.coupon_off_x')}`;
                        } else if (+item.type === 10 || +item.type === 14) {
                            discountVal = `${item.save}% ${vm.$trans('cart.coupon_after')}`;
                        }
                    } else if (+item.discountForm === 1 || +item.discountForm === 2) {
                        if (+item.type === 10 || +item.type === 14) {
                            discountVal = `${vm.remainderRule.one(item.save, 0)}`;
                        } else if (+item.type === 9 || +item.type === 13) {
                            discountVal = `${vm.remainderRule.one(item.save, 0)} ${vm.$trans('cart.coupon_off_x')}`;
                        } else if (+item.type === 8 || +item.type === 12) {
                            discountVal = `${vm.remainderRule.one(item.save, 0)} ${vm.$trans('cart.coupon_off_over')} ${vm.remainderRule.one(item.meetAmount)}`; // eslint-disable-line
                        }
                    }
                    return `<i class="cart_couponTip">${discountVal}</i>`;
                });
                return vm.$trans('cart.earn_coupons', [rules]);
            },
            // 查询分类名称路径
            async getCategoryInfo() {
                const pcatArrName = [];
                const [pcatArray, prodidArray, list, gtmCart] = [...this.categoryInfo];
                const resData = await serviceGetCategoryInfo.http({
                    params: {
                        categoryIds: pcatArray.join(','),
                    }
                });
                const { status } = resData;
                let { data } = resData;

                if (status !== 0 || (Array.isArray(data) && data.length === 0)) {
                    data = {};
                }

                pcatArray.forEach((item) => {
                    pcatArrName.push(data[item] ? data[item].catePathName : '');
                });

                this.dataLayer(pcatArrName, prodidArray, list, gtmCart);
            },
            // dataLayer 存储
            dataLayer(pcatArray, prodidArray, list, gtmCart) {
                // 组装接入 GTM dataLayer 需要的数据
                win.dataLayer[0].google_tag_params.pcat = pcatArray; // 当前勾选商品分类
                win.dataLayer[0].google_tag_params.prodid = prodidArray; // 当前勾选商品 外部sku + (仓库名？)
                win.dataLayer[0].google_tag_params.totalvalue = list.total.settleAmount; // 当前购物车总价 （需要前端计算？）
                win.dataLayer[0].cart = gtmCart; // 明细见上注释

                win.dataLayer.push({ google_tag_params: win.dataLayer[0].google_tag_params });
                win.dataLayer.push({ cart: win.dataLayer[0].cart });
                win.dataLayer.push({ event: 'triggerAdwordsRemarking' });
            },
            onload() {
                const vm = this;
                if (!vm.onloadLock) {
                    vm.onloadLock = true;
                    if (vm.list.warehouseList.length > 0) {
                        // 不通邮检查
                        vm.shipCheck();
                        // 异步加载优惠券
                        vm.getShopCoupon();
                        // 查询分类名称路径
                        vm.getCategoryInfo();
                    }
                }

            },
            // 不通邮检查
            async shipCheck() {
                const vm = this;
                const ids = Object.keys(vm.shipCheckIds);
                const { readyState } = document;

                if (readyState === 'complete' && win.payVars.isLogin && ids.length) {

                    const { status, data } = await serviceShipCheck.http({
                        params: {
                            goods: ids.join(','),
                        }
                    });

                    if (status === 0 && Array.isArray(data) && data.length > 0) {
                        data.forEach((item) => {
                            vm.shipCheckIds[`${item.goodSn}_${item.warehouseCode}`] = 0;
                        });

                        for (const wareIdx in vm.list.warehouseList) {
                            const wareItem = vm.list.warehouseList[wareIdx];
                            for (const shopIdx in wareItem.shopList) {
                                const shopItem = wareItem.shopList[shopIdx];
                                for (const groupIdx in shopItem.groupList) {
                                    const group = shopItem.groupList[groupIdx];
                                    for (const goodsIdx in group.goodsList) {
                                        const goods = group.goodsList[goodsIdx];
                                        const key = `${goods.goodSn}_${goods.warehouseCode}`;
                                        if (+vm.shipCheckIds[key] === 0) {
                                            goods.isCanShip = 0;
                                        }

                                        if (goods.accessoryList.length) {
                                            for (const accessIdx in goods.accessoryList) {
                                                const access = goods.accessoryList[accessIdx];
                                                const accesskey = `${access.goodSn}_${access.warehouseCode}`;
                                                if (+vm.shipCheckIds[accesskey] === 0) {
                                                    access.isCanShip = 0;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            // 变更商品参与活动
            async changeGoodsAct(data) {
                const vm = this;
                const itemList = [];
                if (data.checked !== 1) {
                    return;
                }
                const loading = vm.$loading();
                // 更新选中的活动状态
                data.checkData.dialog.componentData.activityId = data.checkData.activityId;
                itemList.push({
                    itemId: data.checkId,
                    activityId: data.checkData.activityId,
                });

                const res = await serviceCartChange.http({
                    data: {
                        itemList: JSON.stringify(itemList)
                    }
                });

                loading.close();
                if (res.status === 0) {
                    vm.getCartList({ $dialog: data.checkData.dialog });
                } else {
                    vm.showToast(res.msg);
                }
            },
            // 添加到购物车
            async addtoCart(data) {
                const vm = this;
                const res = await serviceAddToCart.http({
                    errorPop: false,
                    loading: false,
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    data: { goods: JSON.stringify(data.postData) }
                });

                if (res.status === 0) {
                    if (data.$dialog) {
                        data.$dialog.close();
                        vm.$bus.$emit('getCartList', { $dialog: data.$dialog });
                    } else {
                        vm.$bus.$emit('getCartList');
                    }
                    vm.$toast({ msg: vm.$trans('cart.add_to_cart_success') });
                } else {
                    if (data.$dialog) {
                        data.$dialog.submiting = false;
                    }
                    vm.$toast({ msg: res.msg });
                }
            },
            // 选中/取消选中商品
            async selectGoods(data) {
                const vm = this;
                const itemIds = [];
                const checked = +!data.checked;
                const { checkData } = data;

                if (checkData.itemId === undefined) {

                    // 更新仓库全选状态
                    vm.$set(vm.list.warehouseList[checkData.wareIndex].warehouseInfo, 'isSelected', checked);

                    // --- 店铺级 ---
                    for (const shopIndex in vm.list.warehouseList[checkData.wareIndex].shopList) {
                        const shopItem = vm.list.warehouseList[checkData.wareIndex].shopList[shopIndex];

                        // --- 活动分组 ---
                        for (const groupIndex in shopItem.groupList) {
                            const groupItem = shopItem.groupList[groupIndex];

                            // --- 商品列表 ---
                            for (const goodsIndex in groupItem.goodsList) {
                                const goodsItem = groupItem.goodsList[goodsIndex];
                                const accessorys = goodsItem.accessoryList;

                                if (+goodsItem.goodType !== 2 && +goodsItem.goodType !== 21) {
                                    goodsItem.isSelected = checked;
                                    itemIds.push(goodsItem.itemId);
                                }
                                // 配件列表
                                if (accessorys.length > 0) {
                                    for (const acceIndex in accessorys) {
                                        const accessory = accessorys[acceIndex];
                                        accessory.isSelected = checked;
                                        itemIds.push(accessory.itemId);
                                    }
                                }
                            }
                        }
                    }

                } else if (checkData.mainAccessory !== undefined) {
                    // 勾选 buy together
                    const goodsItem = vm.list.warehouseList[checkData.wareIndex].shopList[checkData.shopIndex].groupList[checkData.groupIdx].goodsList[checkData.goodsIndex]; // eslint-disable-line
                    if (goodsItem.stockNum <= 0) {
                        goodsItem.isSelected = 0;
                        return vm.$toast({ msg: vm.$trans('cart.notice_out_of_stock') });

                    } else if (+goodsItem.goodType !== 2 && +goodsItem.goodType !== 21) {
                        goodsItem.mainAccessorySelected = checked;
                        goodsItem.isSelected = checked;
                        itemIds.push(goodsItem.itemId);

                        if (goodsItem.accessoryList.length > 0) {
                            for (const acceIndex in goodsItem.accessoryList) {
                                const accessory = goodsItem.accessoryList[acceIndex];
                                if (accessory.stockNum > 0) {
                                    accessory.isSelected = checked;
                                    itemIds.push(accessory.itemId);
                                } else {
                                    accessory.isSelected = 0;
                                    return vm.$toast({ msg: vm.$trans('cart.notice_out_of_stock') });
                                }
                            }
                        }
                    }

                } else if (!(parseInt(checkData.partsIndex, 10) >= 0)) {
                    // 勾选单个主件
                    // console.log('主件');
                    const goodsItem = vm.list.warehouseList[checkData.wareIndex].shopList[checkData.shopIndex].groupList[checkData.groupIdx].goodsList[checkData.goodsIndex]; // eslint-disable-line
                    if (goodsItem.stockNum <= 0) {
                        goodsItem.isSelected = 0;
                        return vm.$toast({ msg: vm.$trans('cart.notice_out_of_stock') });
                    } else if (goodsItem.goodType !== 2 && goodsItem.goodType !== 21) {
                        goodsItem.isSelected = checked;
                        itemIds.push(goodsItem.itemId);
                    }
                } else {
                    // 勾选配件
                    // console.log('配件');
                    const goodsItem = vm.list.warehouseList[checkData.wareIndex].shopList[checkData.shopIndex].groupList[checkData.groupIdx].goodsList[checkData.goodsIndex]; // eslint-disable-line
                    const accessory = goodsItem.accessoryList[checkData.partsIndex];
                    if (goodsItem.isSelected) {
                        accessory.isSelected = checked;
                        itemIds.push(accessory.itemId);
                    } else {
                        accessory.isSelected = 0;
                        return vm.$toast({ msg: vm.$trans('cart.check_main_first') });
                    }
                }

                // 显示loading图标
                const loading = vm.$loading();
                if (itemIds.length > 0) {
                    const res = await serviceCartSelect.http({
                        data: {
                            itemId: itemIds.join(','),
                            isSelected: checked
                        },
                        errorCall: loading.close
                    });
                    vm.getCartList({ $dialog: loading });
                    if (res.status !== 0) {
                        vm.$toast({ msg: res.msg });
                    }
                } else {
                    // 关闭loading
                    loading.close();
                }
                return false;
            },
            // 获取加价购商品/赠品
            async checkGift(groupListItem, warehouseCode, activityId) {
                const vm = this;
                const res = await serviceCartGift.http({
                    params: {
                        warehouseCode,
                        activityId
                    }
                });

                if (res.status === 0) {
                    const responseData = res.data;
                    const title = +groupListItem.groupInfo.activity.activityType === 2 ? vm.$trans('cart.change_gift') : vm.$trans('cart.popout_add_on');
                    // 加入购物车弹窗
                    vm.$alert({
                        title,
                        customClass: 'pickGoods',
                        rollfrom: 'bottom',
                        okEvent: 'checkgift',
                        component: checkgift,
                        componentData: {
                            txttip: +groupListItem.groupInfo.activity.activityType === 2 ? vm.$trans('cart.gift') : vm.$trans('cart.popout_add_on'),
                            groupListItem,
                            responseData,
                            activityId,
                            type: groupListItem.groupInfo.activity.activityType === 2 ? 'gift' : ''
                        },
                        okText: vm.$trans('cart.confirm')
                    });
                } else {
                    vm.showToast(res.msg);
                }
            },
            // 获取选中商品 id
            getSelectedId(data, datafilter) {
                const vm = this;
                const itemIds = [];
                // 失效仓 delete All
                if (data.itemId === '0000') {
                    for (const item in vm.list.warehouseList) {
                        const wareItem = vm.list.warehouseList[item];
                        if (wareItem.warehouseInfo.code === '0000') {
                            wareItem.shopList.forEach((shopItem) => {
                                shopItem.groupList.forEach((group) => {
                                    group.goodsList.forEach((goods) => {
                                        itemIds.push(goods.itemId);
                                        // 配件
                                        if (goods.accessoryList.length > 0) {
                                            goods.accessoryList.forEach((access) => {
                                                itemIds.push(access.itemId);
                                            });
                                        }
                                    });
                                });
                            });
                        }
                    }
                } else if (data.itemId === undefined) {
                    // 针对有效仓底部批量操作:
                    for (const item in vm.list.warehouseList) {
                        const wareItem = vm.list.warehouseList[item];
                        wareItem.shopList.forEach((shopItem) => {
                            shopItem.groupList.forEach((group) => {
                                group.goodsList.forEach((goods) => {
                                    if (goods.isSelected) {
                                        if (datafilter.event === 'delete') {
                                            // 删除
                                            itemIds.push(goods.itemId);
                                        } else if (datafilter.event === 'favor') {
                                            // 收藏
                                            itemIds.push(`${goods.goodSn}_${goods.warehouseCode}`);
                                        }
                                    }
                                    // 配件
                                    if (goods.accessoryList.length > 0) {
                                        goods.accessoryList.forEach((access) => {
                                            if (access.isSelected) {
                                                if (datafilter.event === 'delete') {
                                                    // 删除
                                                    itemIds.push(access.itemId);
                                                } else if (datafilter.event === 'favor') {
                                                    // 收藏
                                                    itemIds.push(`${access.goodSn}_${access.warehouseCode}`);
                                                }
                                            }
                                        });
                                    }
                                });
                            });
                        });
                    }
                } else {
                    // 单个id
                    itemIds.push(data.itemId);
                }

                if (itemIds.length === 0) {
                    return vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
                return itemIds;
            },
            // 删除商品
            toDelGoods(data) {
                const vm = this;
                let itemIds = [];

                if (data === 'editMode') {
                    this.getEditCheckedId();
                    itemIds = vm.batchItems.itemIds;
                } else {
                    itemIds = vm.getSelectedId(data, { event: 'delete' });
                }

                if (itemIds.length) {
                    vm.$confirm({
                        itemIds,
                        okEvent: 'deleteGoods',
                        content: `<p style="text-align:center;padding-top:1rem;font-size:.5rem;line-height:.7rem;">
                            ${vm.$trans('cart.to_delete_tip')}
                        </p>`,
                        ok(dialog) {
                            vm.deleteGoods(dialog);
                        },
                        confirmText: vm.$trans('cart.confirm'),
                        cancelText: vm.$trans('cart.cancel'),
                    });
                } else {
                    vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
            },
            // 收藏商品
            async favorGoods(itemIds) {
                const vm = this;
                const res = await serviceCollectAdd.http({
                    data: {
                        goods: itemIds
                    }
                });

                if (res.status === 0) {
                    vm.$toast({ msg: vm.$trans('cart.move_success') });

                    // 删除商品
                    vm.deleteGoods('editMode');

                } else if (res.data.redirectUrl) {
                    win.location.href = res.data.redirectUrl;
                } else {
                    vm.$toast({ msg: res.msg });
                }
            },
            // 确认删除
            async deleteGoods(dialog) {
                const vm = this;
                let itemIds = [];

                if (dialog === 'editMode') {
                    this.getEditCheckedId();
                    itemIds = vm.batchItems.itemIds;
                } else {
                    itemIds = dialog.itemIds;
                }

                const res = await serviceCartDelete.http({
                    data: {
                        itemId: itemIds.join(','),
                    }
                });

                if (dialog !== 'editMode') {
                    dialog.submiting = false;
                }

                if (res.status === 0) {
                    vm.checkStat = {};
                    if (dialog !== 'editMode') {
                        vm.getCartList({ $dialog: dialog });
                    } else {
                        vm.getCartList();
                    }

                } else {
                    vm.$toast({ msg: res.msg });
                }
            },
            // 店铺领取优惠券
            async getCouponList(couponList) {
                const vm = this;
                vm.$alert({
                    shadowClose: true,
                    title: vm.$trans('cart.shop_coupon'),
                    customClass: 'cartShopCoupon',
                    component: cartShopCoupon,
                    rollfrom: 'bottom',
                    couponList,
                });
            },
            async checkout(payChannel) { // 保存购物车数据
                const vm = this;
                let itemList = [];
                // 显示loading图标
                const loading = vm.$loading();

                let skuAdvanceDetail = false;

                vm.list.warehouseList.forEach((wareItem) => {
                    if (wareItem.warehouseInfo.code !== '0000') {
                        wareItem.shopList.forEach((shopItem) => {
                            shopItem.groupList.forEach((group) => {
                                group.goodsList.forEach((goods) => {
                                    if (goods.isSelected) {
                                        if (goods.skuAdvanceDetail) {
                                            skuAdvanceDetail = true;
                                        }
                                        itemList.push({
                                            itemId: goods.itemId,
                                            activityId: goods.activityId
                                        });
                                    }
                                });
                            });
                        });
                    }
                });

                if (itemList.length === 0) {
                    loading.close();
                    return vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
                itemList = [];

                vm.list.warehouseList.forEach((wareItem) => {
                    if (wareItem.warehouseInfo.code !== '0000') {
                        wareItem.shopList.forEach((shopItem) => {
                            shopItem.groupList.forEach((group) => {
                                if (group.groupInfo.isJoined) {
                                    group.goodsList.forEach((goods) => {
                                        if (goods.isSelected) {
                                            itemList.push({
                                                itemId: goods.itemId,
                                                activityId: goods.activityId
                                            });
                                        }
                                    });
                                }
                            });
                        });
                    }
                });

                // 提交商品列表
                const resCS = await serviceCartSaveActs.http({
                    loading: false,
                    data: {
                        itemList
                    }
                });

                if (payChannel !== 'checkout' && resCS.status === 0) {
                    const resQPD = await serviceCartSendQuickPay.http({
                        loading: false,
                        params: {
                            channelCode: payChannel
                        },
                    }).catch(() => {
                        loading.close();
                    });

                    const { redirectUrl } = resQPD.data;
                    if (redirectUrl) {
                        loading.close();
                        win.location.href = redirectUrl;
                        return false;
                    }
                    loading.close();
                } else if (resCS.status === 0) {
                    const doc = document;
                    const formEl = doc.createElement('form');
                    const isDeposit = skuAdvanceDetail ? '?isDeposit=1' : '';
                    loading.close();
                    formEl.method = 'post';
                    formEl.action = `${GLOBAL.DOMAIN_ORDER}/checkout/index${isDeposit}`;
                    doc.body.appendChild(formEl);
                    formEl.submit();
                } else {
                    loading.close();
                    vm.$toast({
                        timer: 1500,
                        msg: resCS.msg,
                        ok() {
                            setTimeout(() => win.location.reload(), 1000);
                        }
                    });
                }
                return false;
            },
            closeDiscountTip() {
                this.showDiscountTip = 0;
            },
            exitEdit() {
                this.allEditChecked = false;
                this.$bus.$emit('batchSelect', {
                    type: 'all',
                    checked: false,
                    checkId: '',
                });
                this.batchItems.itemIds = [];
            },
            editMode() {
                import('./batch_edit.js');
                this.allEditChecked = true;
                this.checkStat = {};
            },
            // 心愿单
            wishlist() {
                const vm = this;
                this.getEditCheckedId('favor');

                if (this.batchItems.itemIds.length) {
                    vm.favorGoods(this.batchItems.itemIds);
                } else {
                    vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
            },
            async batchSelect(data) {
                try {
                    const call = await import('./batch_edit.js');
                    call.default(this, data);
                } catch (e) {
                    console.log(e);
                }

            },
            getEditCheckedId(type) {

                this.batchItems.itemIds = [];
                if (Object.keys(this.checkStat).length) {
                    for (const key in this.checkStat) {
                        const item = this.checkStat[key];
                        const wareCode = key.split('_')[0];
                        if (item.checked) {
                            if (type === 'favor') {
                                this.batchItems.itemIds.push(`${item.goodSn}_${wareCode}`);
                            } else {
                                this.batchItems.itemIds.push(item.id);
                            }

                        }
                    }
                }

            }
        }
    };
</script>

<style>
    @import 'pages/paycart/component/cart/cart.css';
</style>
