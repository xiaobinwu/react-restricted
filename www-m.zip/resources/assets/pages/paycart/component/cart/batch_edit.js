export default (vm, data) => {

    const { list } = vm.batchItems;
    const { type, checked, checkId } = data;
    const checkIndex = checkId.split('_');
    const wareIndex = checkIndex[0];
    const checkStat = vm.checkStat;

    if (type === 'all') {
        // 全选
        vm.batchItems.feEditChecked = checked;

        list.forEach((ware, wareIdx) => {

            if (ware.warehouseInfo.code !== '0000') {

                ware.warehouseInfo.feEditChecked = checked;
                vm.$set(list, wareIdx, ware);
                ware.shopList.forEach((shop, shopIndex) => {
                    shop.shopInfo.feEditChecked = checked;
                    vm.$set(list[wareIdx].shopList, shopIndex, shop);

                    shop.groupList.forEach((group, groupIndex) => {
                        group.groupInfo.feEditChecked = checked;
                        vm.$set(list[wareIdx].shopList[shopIndex].groupList, groupIndex, group);

                        group.goodsList.forEach((goods, goodsIndex) => {
                            // goods.feEditMergeChecked = checked;
                            goods.feEditChecked = checked;
                            vm.$set(list[wareIdx].shopList[shopIndex].groupList[groupIndex].goodsList, goodsIndex, goods);

                            checkStat[`${ware.warehouseInfo.code}_${goods.itemId}`] = {
                                checked,
                                goodSn: goods.goodSn,
                                id: goods.itemId,
                            };

                            // 设置配件
                            /* eslint-disable */
                            /* const accesses = goods.accessoryList;
                            if (accesses.length) {
                                accesses.forEach((access, acceIndex) => {
                                    access.feEditChecked = checked;
                                    vm.$set(list[wareIdx].shopList[shopIndex].groupList[groupIndex].goodsList[goodsIndex].accessoryList, acceIndex, access); // eslint-disable-line

                                    checkStat[`${ware.warehouseInfo.code}_${access.itemId}`] = {
                                        checked,
                                        goodSn: access.goodSn,
                                        id: access.itemId,
                                    };
                                });
                            } */
                            /* eslint-enable */
                        });
                    });
                });
            }
        });

    } else if (type === 'ware') {
        // 仓库
        const ware = list[wareIndex];
        ware.warehouseInfo.feEditChecked = checked;
        vm.$set(list, wareIndex, ware);

        list[wareIndex].shopList.forEach((shop, shopIndex) => {
            shop.shopInfo.feEditChecked = checked;
            vm.$set(list[wareIndex].shopList, shopIndex, shop);

            shop.groupList.forEach((group, groupIndex) => {
                group.groupInfo.feEditChecked = checked;
                vm.$set(list[wareIndex].shopList[shopIndex].groupList, groupIndex, group);

                group.goodsList.forEach((goods, goodsIndex) => {
                    // goods.feEditMergeChecked = checked;
                    goods.feEditChecked = checked;
                    vm.$set(list[wareIndex].shopList[shopIndex].groupList[groupIndex].goodsList, goodsIndex, goods);

                    checkStat[`${ware.warehouseInfo.code}_${goods.itemId}`] = {
                        checked,
                        goodSn: goods.goodSn,
                        id: goods.itemId,
                    };

                    // 设置配件
                    /* eslint-disable */
                    /* const accesses = goods.accessoryList;
                    if (accesses.length) {
                        accesses.forEach((access, acceIndex) => {
                            access.feEditChecked = checked;
                            vm.$set(list[wareIndex].shopList[shopIndex].groupList[groupIndex].goodsList[goodsIndex].accessoryList, acceIndex, access); // eslint-disable-line

                            checkStat[`${ware.warehouseInfo.code}_${access.itemId}`] = {
                                checked,
                                goodSn: access.goodSn,
                                id: access.itemId,
                            };
                        });
                    } */
                    /* eslint-enable */
                });
            });
        });
        /* } else if (type === 'buytogether') {
            // buytogether
            const shopIndex = checkIndex[1];
            const groupIndex = checkIndex[2];
            const goodsIndex = checkIndex[3];
            const ware = list[wareIndex];
            const curGoods = ware.shopList[shopIndex].groupList[groupIndex].goodsList[goodsIndex];

            curGoods.feEditChecked = checked;
            curGoods.feEditMergeChecked = checked;

            checkStat[`${ware.warehouseInfo.code}_${curGoods.itemId}`] = {
                checked,
                goodSn: curGoods.goodSn,
                id: curGoods.itemId,
            };

            // 设置配件
            const accesses = curGoods.accessoryList;
            if (accesses.length) {
                accesses.forEach((access, acceIndex) => {
                    access.feEditChecked = checked;
                    vm.$set(list[wareIndex].shopList[shopIndex].groupList[groupIndex].goodsList[goodsIndex].accessoryList, acceIndex, access);

                    checkStat[`${ware.warehouseInfo.code}_${access.itemId}`] = {
                        checked,
                        goodSn: access.goodSn,
                        id: access.itemId,
                    };
                });
            } */

    } else if (type === 'goods') {
        // 单个商品
        const shopIndex = checkIndex[1];
        const groupIndex = checkIndex[2];
        const goodsIndex = checkIndex[3];
        // const accessIndex = checkIndex[4];
        const ware = list[wareIndex];
        const goodsList = ware.shopList[shopIndex].groupList[groupIndex].goodsList;
        const curGoods = goodsList[goodsIndex];
        /* if (accessIndex !== undefined) {
            // 点击配件
            const access = curGoods.accessoryList[accessIndex];
            access.feEditChecked = checked;

            checkStat[`${ware.warehouseInfo.code}_${access.itemId}`] = {
                checked,
                goodSn: access.goodSn,
                id: access.itemId,
            };
            if (!checked) {
                curGoods.feEditMergeChecked = checked;
                vm.$set(goodsList, goodsIndex, curGoods);
            }
            vm.$set(list[wareIndex].shopList[shopIndex].groupList[groupIndex].goodsList[goodsIndex].accessoryList, accessIndex, access);
        } else { */

        // 点击主件
        curGoods.feEditChecked = checked;

        checkStat[`${ware.warehouseInfo.code}_${curGoods.itemId}`] = {
            checked,
            goodSn: curGoods.goodSn,
            id: curGoods.itemId,
        };
        // 设置配件
        /* eslint-disable */
        /* if (!checked) {
            // buy together
            // curGoods.feEditMergeChecked = checked;
            // 设置配件
            const accesses = curGoods.accessoryList;
            if (accesses.length) {
                accesses.forEach((access, acceIndex) => {
                    access.feEditChecked = checked;
                    vm.$set(list[wareIndex].shopList[shopIndex].groupList[groupIndex].goodsList[goodsIndex].accessoryList, acceIndex, access); // eslint-disable-line

                    checkStat[`${ware.warehouseInfo.code}_${access.itemId}`] = {
                        checked,
                        goodSn: access.goodSn,
                        id: access.itemId,
                    };
                });
            }
        } */
        /* eslint-enable */

        vm.$set(goodsList, goodsIndex, curGoods);

    }

    // 关联全选
    let goodsNum = 0;
    let checkedNum = 0;
    list.forEach((ware, wareIdx) => {
        if (ware.warehouseInfo.code !== '0000') {

            ware.shopList.forEach((shop) => {
                shop.groupList.forEach((group) => {
                    group.goodsList.forEach((goods) => {
                        if (goods.goodType === 0) {
                            goodsNum += 1;
                            if (goods.feEditChecked) {
                                checkedNum += 1;
                            }
                        }
                    });
                });

                ware.warehouseInfo.feEditChecked = checkedNum >= goodsNum;

            });
        }
    });

    vm.batchItems.feEditChecked = checkedNum >= goodsNum;

};
