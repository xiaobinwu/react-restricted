<template lang="pug">
    label.vue_checkbox.ischeckbox(v-finger:tap.stop.prevent="changeChecked")
        span.vue_checkboxShape(:class="{'checked icon-tick': checked, 'disabled': disable}")
        span.vue_checkboxLabel(v-if="label", v-html="label")
</template>

<script>
    export default {
        name: 'editCheckbox',
        data() {
            return {
                checkedStat: this.checked,
            };
        },
        props: {
            checkId: '',
            checked: false,
            disable: false,
            checkType: {
                default: 'goods',
            },
            label: String,
        },
        methods: {
            changeChecked() {

                if (!this.disable) {
                    this.$bus.$emit('batchSelect', {
                        type: this.checkType,
                        checked: !this.checked,
                        checkId: this.checkId,
                    });
                }

            }
        }
    };
</script>
