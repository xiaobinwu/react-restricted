<template lang="pug">
    .cart_changestock(:class="{'disabled': disable}")
        i.icon-fold.cart_changebtn(:class="{'disabled': disable || inputVal <= 1 || cannotMatch}", v-finger:tap='reduceNum')
        input.cart_stockNum(type="text", v-model.number.trim="inputVal", @focus="getOrig", @blur="change_stock('blur')", @keyup="onenter($event)", :disabled="disable || goods.stockNum <= 1 || cannotMatch")
        i.icon-unfold.cart_changebtn(:class="{'disabled': disable || inputVal >= goods.stockNum || inputVal >= goods.buyLimit || cannotMatch || showlimitTip}", v-finger:tap='addNum')

</template>

<script>

    import { serviceCartUpdate } from 'js/service/paycart';

    export default {
        /* eslint-disable */
        data() {
            return {
                disable: false,
                lastStock: '',                          // 存储上次输入的数值
                showlimitTip: this.goods.stockNum <= 0, // 是否显示库存不足等提示
                inputRules: /^\+?[1-9][0-9]*$/,         // 正整数正则表达式
                inputVal: this.goods.stockNum <= 0 ? 0 : this.goods.goodSnQty
            };
        },
        props: {
            goods: Object,
            cannotMatch: false,
            parentData: Object,
            goodsgroup: Object,
            updateList: { // 是否更新购物车列表
                default: false,
            },
            liveUpdate: { // 是否实时请求数量
                default: true,
            },
        },
        /* eslint-enable */
        created() {
            const vm = this;
            if (vm.parentData) {
                vm.showlimitTip = vm.inputVal >= vm.parentData.goodSnQty;
            }

            if (vm.goods.allowBuy === 0 || vm.goods.stockNum <= 0 || vm.goods.goodType === 2 || vm.goods.goodType === 21 || vm.goods.goodType === 3) { // eslint-disable-line
                vm.disable = true;
            }
        },
        watch: {
            goods: {
                handler() {
                    if (this.goods.stockNum <= 0) {
                        this.showlimitTip = true;
                        this.inputVal = 0;
                    } else {
                        this.showlimitTip = false;
                        if (this.goods.stockNum >= this.goods.goodSnQty) {
                            this.inputVal = this.goods.goodSnQty;
                        } else {
                            this.inputVal = this.goods.stockNum;
                        }
                    }
                },
                deep: true
            },
            parentData: {
                handler() {
                    if (this.parentData) {
                        this.showlimitTip = this.inputVal >= this.parentData.goodSnQty;
                    }
                }
            }
        },
        methods: {
            testValue(value) {
                if (this.inputRules.test(value || this.inputVal)) {
                    return value || this.inputVal;
                }
                this.inputVal = 1;
                return 1;
            },
            addNum() {
                const vm = this;
                if (vm.disable) return false;
                if (vm.parentData && vm.inputVal >= vm.parentData.goodSnQty) {
                    vm.inputVal = vm.parentData.goodSnQty;
                    return false;
                }
                if (!vm.cannotMatch && vm.testValue()) {
                    vm.inputVal += 1;
                    if (vm.inputVal > vm.goods.stockNum) {
                        vm.inputVal = vm.goods.stockNum;
                    }
                    // 定金膨胀
                    if (vm.goods.buyLimit > 0 && vm.inputVal > vm.goods.buyLimit) {
                        vm.$toast({ msg: vm.$trans('cart.canot_add_number', [vm.goods.buyLimit]) });
                        vm.inputVal -= 1;
                    }
                    vm.change_stock();
                }
                return false;
            },
            reduceNum() {
                const vm = this;
                if (vm.disable) return false;
                if (this.goods.stockNum <= 0) {
                    this.inputVal = 0;
                    return false;
                }
                if (!vm.cannotMatch && vm.testValue() && vm.testValue() > 1) {
                    vm.inputVal -= 1;
                    vm.change_stock();
                }
                return false;
            },
            getOrig() {
                this.lastStock = this.inputVal;
            },
            onenter(ev) {
                if (ev.keyCode === 13) {
                    ev.currentTarget.blur();
                } else if (this.liveUpdate) {
                    this.change_stock();
                }
            },
            change_stock(blur) {
                const vm = this;
                // 定金膨胀
                if (vm.goods.buyLimit > 0 && vm.inputVal > vm.goods.buyLimit) {
                    vm.$toast({ msg: vm.$trans('cart.canot_add_number', [vm.goods.buyLimit]) });
                    if (blur) {
                        if (vm.goods.buyLimit < vm.goods.stockNum) {
                            vm.inputVal = vm.goods.buyLimit;
                        } else {
                            vm.inputVal = vm.goods.stockNum;
                        }
                    } else {
                        return false;
                    }
                }
                // 库存不足直接拒绝
                if (vm.goods.stockNum <= 0) {
                    vm.inputVal = 0;
                    return false;
                }
                // 配件数量不能超过主件数量 && 不能超过单次购买数量
                if (vm.parentData && vm.inputVal >= vm.parentData.goodSnQty) {
                    vm.inputVal = vm.parentData.goodSnQty;
                }
                // 不允许编辑时 || 手输的数字没变化时直接拒绝
                if (vm.cannotMatch || +vm.inputVal === +vm.lastStock) return false;

                // 正则匹配输入的值是否合法
                if (!vm.inputRules.test(vm.inputVal) && vm.inputVal !== '') {
                    vm.inputVal = 1;
                    if (+vm.inputVal === +vm.lastStock) return false;
                }
                // 输入的值大于库存 || 单次购买数量时时立即修正
                if (vm.inputVal > vm.goods.stockNum) {
                    vm.inputVal = vm.goods.stockNum;
                    vm.$toast({ msg: vm.$trans('cart.no_more_than', [vm.inputVal]) });
                } else {
                    vm.showlimitTip = false;
                }

                // 针对购物车商品 M元N件 进行库存判断
                if (
                    vm.goodsgroup &&
                    +vm.goodsgroup.activity.activityType === 6 &&
                    vm.goods.remainderCount !== 0 &&
                    vm.inputVal > vm.goods.remainderCount
                ) {
                    vm.$toast({ msg: vm.$trans('cart.notice_out_of_active_stock', [vm.goods.remainderCount]) });
                }

                if (blur === 'blur' && vm.inputVal === '') {
                    vm.inputVal = 1;
                }

                // 更新父级数量显示
                if (vm.updateList) {
                    vm.changestockEvent();
                } else {
                    vm.$parent.goodSnQty = vm.inputVal || 1;
                }
                return false;
            },
            // 更改商品数量
            async changestockEvent(data) {
                const vm = this;
                const res = await serviceCartUpdate.http({
                    data: {
                        itemId: vm.goods.itemId,
                        qty: vm.inputVal,
                    }
                });
                if (res.status === 0) {
                    vm.$bus.$emit('getCartList');
                } else {
                    vm.$toast({ msg: res.msg });
                }
            },
        }
    };
</script>
