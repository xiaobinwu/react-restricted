<template lang="pug">
ul.pickcoupons(:ref="`kdialog_scroll_wrap`")
    li(v-for="(item, index) in couponList", :class="{'couponGot': item.got}")
        //- 百分比
        .pick_amount(v-if="item.discountForm == 3")
            .amount_type
                p.pick_type {{ item.save }}%
                p.coupon_off {{ $trans('cart.coupon_off_x_m') }}
        //- 优惠金额
        .pick_amount(v-if="item.discountForm == 1 || item.discountForm == 2")
            p.amount_type(v-if="item.type == 10 || item.type == 14") {{ currency | $remainder_one(item.save, 0) }}
            .amount_type(v-if="item.type == 9 || item.type == 13 || item.type == 8 || item.type == 12")
                p.pick_type {{ currency | $remainder_one(item.save, 0) }}
                p.coupon_off {{ $trans('cart.coupon_off_x_m') }}

        .pick_coupon
            i.icon-confirm
            .pick_title(v-if="item.discountForm == 3")
                p(v-if="(item.type == 8 || item.type == 12) && item.fullCondition == 2") {{item.save}}% {{$trans('cart.coupon_off_over_m')}} {{ item.meetAmount }} {{$trans('cart.coupon_unit_s')}}
                p(v-else) {{item.save}}% {{$trans('cart.coupon_off_over_m')}}{{currency | $remainder_one(item.meetAmount)}}
            .pick_title(v-if="item.discountForm == 1 || item.discountForm == 2")
                p(v-if="item.type == 10 || item.type == 14") {{$trans('cart.fixed_price')}}
                p(v-if="item.type == 9 || item.type == 13") {{currency | $remainder_one(item.save, 0)}} {{$trans('cart.coupon_off_x_m')}}
                p(v-if="item.type == 8 || item.type == 12") {{currency | $remainder_one(item.save, 0)}} {{$trans('cart.coupon_off_over_m')}} {{currency | $remainder_one(item.meetAmount)}}
            p.pick_expried {{ $trans('cart.goods_expired') }}:{{item.endTime | dateFormat}}
            span.pick_getit(v-if="!item.got", v-finger:tap="getCoupons.bind(this, { templateCode: item.templateCode, index })") {{ $trans('cart.get_coupon') }}
            a.pick_getit(v-if="item.got && item.useLink", :href="item.useLink") {{ $trans('user.coupon_use_link') }}

</template>

<script>
    import { dateFormat } from 'js/utils';
    import getCouponItem from 'js/core/goods/getCouponItem.js';

    export default {
        data() {
            return {
                couponList: this.$parent.couponList,
            };
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        filters: {
            dateFormat(time) {
                return dateFormat(time, 'dd/MM/yyyy');
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
        methods: {
            // 店铺领取优惠券
            getCoupons({ templateCode, index }) {
                const vm = this;
                const loading = vm.$loading();
                getCouponItem({ templateCode, erropPop: false }).then(({ status, msg, data }) => {
                    loading.close();
                    if ((status === 0 || status === 1 || status === 10052071) && !data.redirectUrl) {
                        vm.couponList[index].got = 1;
                        vm.$set(vm.couponList, index, vm.couponList[index]);
                        if (status === 10052071) {
                            vm.$toast({ msg });
                        }
                    } else {
                        vm.$toast({ msg });
                    }
                });
            }
        }
    };
</script>

<style>
@import 'pages/paycart/component/cart/cartShopCoupon.css';
</style>