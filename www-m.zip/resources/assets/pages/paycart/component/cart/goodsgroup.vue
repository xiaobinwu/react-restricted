<template lang="pug">
.cart_actsitem
    //- Buy together
    .cart_buyall(v-if="info.code !== '0000' && goods.accessoryList.length")
        compCheckbox(:label="$trans('cart.buy_together')", :checked="allEditChecked ? 2 : goods.mainAccessorySelected", :checkId="wareIndex +'_'+ shopIndex +'_'+ groupIdx +'_'+ goodsIndex + (partsIndex >=0 ? '_'+partsIndex : '')", :checkData="{itemcode: info.code, itemId: goods.itemId, wareIndex:wareIndex, shopIndex:shopIndex, groupIdx:groupIdx, goodsIndex:goodsIndex, partsIndex:partsIndex, mainAccessory:goods.mainAccessorySelected}", :eventName="'cartlistSelected'")
    //- 商品循环
    //- .cart_goodsgroup(:class="{'expired_group':goods.isCanShip === 0 || goods.stockNum <= 0}", v-finger:touch-start="touchStart.bind(this, id)", v-finger:touch-move="touchMove", v-finger:touch-end="touchEnd")
    .cart_goodsgroup(:class="{'expired_group': info.code === '0000' || goods.stockNum <= 0}")
        .cart_itemlist(:class="{'cart_giftGoods': goods.goodType === 2 || goods.goodType === 3 || goods.goodType === 21}", :data-customtrack="goods.goodSn +'_' + goods.categoryId +'_'+ goods.warehouseCode")
            compCheckbox(v-show="info.code !== '0000' ? !allEditChecked : 1", v-if="goods.goodType != 2 && goods.goodType != 21 && goods.goodType != 3", :checkId="wareIndex +'_'+ shopIndex +'_'+ groupIdx +'_'+ goodsIndex + (partsIndex >=0 ? '_'+partsIndex : '')", :checked="info.code !== '0000' ? isSelected : 2", :checkData="{itemcode: info.code, canCheck: goods.isCanShip, itemId: goods.itemId, wareIndex:wareIndex, shopIndex:shopIndex, groupIdx:groupIdx, goodsIndex:goodsIndex, partsIndex:partsIndex}", :eventName="'cartlistSelected'")
            editCheckbox(v-if="info.code !== '0000' && goods.goodType != 2 && goods.goodType != 21 && goods.goodType != 3 && partsIndex === undefined", v-show="allEditChecked", :checkId="wareIndex +'_'+ shopIndex +'_'+ groupIdx +'_'+ goodsIndex + (partsIndex >=0 ? '_'+partsIndex : '')", :checked="goods.feEditChecked")
            span.vue_checkbox(v-if="partsIndex !== undefined", v-show="allEditChecked")
            //- 图片
            a.cart_img(:href="allEditChecked? 'javascript:;': goods.linkUrl")
                span.cart_pricetype(v-if="goods.goodsStatus == 4 || goods.priceType == 1 || goods.priceType == 2 || goods.priceType == 7", :class="[goods.goodsStatus == 4? 'type_arrive': (goods.priceType == 1? 'type_emailOnly': (goods.priceType == 2? 'type_presale': (goods.priceType == 7? 'type_flashsale': ''))), {'giftGoods':goods.goodType === 2 || goods.goodType === 3 || goods.goodType === 21}]") {{goods.goodsStatus | priceTypeFilter(this, goods.priceType)}}
                span.cart_pricetype.type_clearance(v-else-if="goods.saleMark == 3 || goods.priceType == 10 || goods.priceType == '6396395377285853184'") {{ $trans('cart.clearance') }}
                .cart_canotship(v-if="goods.isCanShip === 0")
                    .cart_cell
                        p {{ $trans('cart.canot_ship') }}
                img(src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", v-lazy='goods.goodImg')
                p.cart_imgText(v-if="goods.goodType === 1") {{ $trans('cart.cart_accessory') }}
                p.cart_imgText(v-if="goods.goodType === 2 || goods.goodType === 21") {{ $trans('cart.gift') }}
                p.cart_imgText(v-if="goods.goodType === 3") {{ $trans('cart.redeem') }}
            //- 商品信息
            .cart_goodsbox
                .cart_info
                    a.cart_link(:href="allEditChecked? 'javascript:;': goods.linkUrl") {{goods.goodTitle}}
                    //- 商品属性
                    .cart_attrs(v-finger:tap="editAttrs.bind(this, goods)", :class="{'disabled': goods.goodType === 1 || goods.goodType === 2 || goods.goodType === 21 || goods.goodType === 3}")
                        p.cart_props {{goods.attr | attrFilter}}
                        i.icon-arrow_down

                    //- 敏感品标识
                    p.tip_float(v-if="goods.property != 1", v-finger:tap="showtip", :class="{'tip_show': tip_float}")
                        i.icon-warning_icon
                        span.tip_detail {{ $trans('cart.popout_sensitive_tips') }}

                    .cart_other
                        //- 更改数量
                        changeStock(:updateList="true", :liveUpdate="false", :goods='goods', :parentData="parentData", :goodsgroup="goodsgroup")

                        p.cart_price(v-if="goods.stockNum > 0 && info.code !== '0000'") {{currency | $remainder_one(goods.goodPrice)}}
                        //- 商品状态
                        //- p.cart_instalment(v-if="goods.instalment > 0", v-finger:tap="showInstalment.bind(this, goods.instalmentTips)") {{ $trans('cart.instalments') }}
                        p.cart_priceReminderBox(v-if="goods.diffAddPrice")
                            span.cart_priceReminder
                                i.icon-arrowdown
                                | {{ currency | $remainder_one(goods.diffAddPrice) }} {{ $trans('cart.coupon_off') }}
                        p.cart_deposit(v-if="goods.skuAdvanceDetail") {{ deposit(goods) }}

                        p.cart_status(v-if="!goods.allowBuy") {{ $trans('cart.goods_expired') }}
                        p.cart_status(v-if="goods.allowBuy && goods.stockNum <= 0") {{ $trans('cart.notice_out_of_stock') }}
                        //- p.cart_status(v-if="goods.isCanShip === 0") {{ $trans('cart.canot_ship') }}
                        //- 编辑按钮
                        //- .cart_action(:class="{'outstock': goods.isCanShip === 0 || goods.stockNum <= 0 || info.code === '0000'}")
                            p.tip_float(v-if="goods.property != 1", v-finger:tap="showtip", :class="{'tip_show': tip_float}")
                                i.icon-warning_icon
                                span.tip_detail {{ $trans('cart.popout_sensitive_tips') }}
                            p.cart_edit(v-finger:tap="editGoods")
                                i.icon-edit
                            p.cart_number x{{goods.goodSnQty}}
                    .cart_codInfo(v-if="goods.isCod === 1")
                        a.cart_codIcon(:href="mainUrl + '/cod.html'" target="_special") COD
                        i.icon-question(@click="showCodTip")


                //- 编辑按钮
                //- .cart_editbox(v-if="info.code != '0000'", :class="{'noEditAttr': goods.goodType == 1 || goods.goodType == 2 || goods.goodType == 21 || goods.attr.length <= 0}")
                    changeStock(:goods='goods', :parentData="parentData", :goodsgroup="goodsgroup")
                    .cart_editattrs(v-finger:tap="editAttrs")
                        p.cart_hasattrs {{goods.attr | attrFilter}}
                        i.icon-arrow_down
                    i.icon-confirm(v-finger:tap="confirmEdit")
            //- 删除/收藏按钮
            //- .cart_actions
                i.icon-delete_tiny(v-finger:tap="todelete")
                i.icon-favourite_grey_list.icon-favorItem(v-finger:tap="favor", :ref="`favorbtn`", :data-customtrack="goods.goodSn +'_' + goods.categoryId +'_'+ goods.warehouseCode")
        //- 价格阶梯展示
        p.cart_moredesc(v-if='goods.priceList.length > 1') {{ $trans('cart.muilty_prices') }} {{currency | $remainder.pricesList(goods.priceList) | pricesFilter}}
        //- 切换活动
        .cart_moredesc(v-if="info.code != '0000' && goods.canJoinActivityList && goods.canJoinActivityList.length", v-finger:tap="changeActs")
            p.cart_descs {{ $trans('cart.change_activity') }}
            i.icon-arrow_tiny

    goodsgroup(v-if="goods.accessoryList && goods.accessoryList.length", v-for='(parts, partsindex) in goods.accessoryList', :key="partsindex", :goods='parts', :wareIndex='wareIndex', :shopIndex="shopIndex", :groupIdx="groupIdx", :goodsIndex='goodsIndex', :partsIndex="partsindex", :info='info', :parentData="goods", :allEditChecked="allEditChecked")

</template>

<script>

    // import PubSub from 'pubsub-js';
    import layer from 'layer';
    import { serviceCartUpdate, serviceCartSameGoods } from 'js/service/paycart';
    import compCheckbox from '../paycart_checkbox.vue'; // 复选框
    import changeStock from './change_stock.vue'; // 商品输入框组件
    import editCheckbox from './edit_checkbox.vue';

    const goodsReplace = () => import('./goods_replace.vue'); // 商品输入框组件
    const changeAct = () => import('./change_act.vue'); // 切换活动组件

    export default {
        name: 'goodsgroup',
        /* eslint-disable */
        data() {
            return {
                /* id: '',                             // 滑动元素
                el: '',                             // 滑动元素
                favorbtn: '',                       // 收藏按钮
                startX: 0,
                startY: 0,
                slidedis: 0,                        // 滑动距离
                maxslidedis: 0,                     // 最大滑动距离
                slidemode: false,                   // 滑动商品
                editmode: false,                    // 编辑商品 */
                mouseDown: false,                   // PC鼠标状态
                tip_float: false,                   // 商品提示信息
                goodOrigQty: this.goods.goodSnQty,  // 商品原始数量
                goodSnQty: this.goods.goodSnQty,    // 商品实时数量
                isSelected: this.goods.isSelected,   // 商品勾选状态
                mainUrl: window.GLOBAL.DOMAIN_MAIN,
            };
        },
        /* eslint-enable */
        components: {
            compCheckbox,
            changeStock,
            editCheckbox,
        },
        props: {
            goods: Object,
            goodsgroup: Object,
            wareIndex: Number,
            shopIndex: Number,
            groupIdx: Number,
            goodsIndex: Number,
            partsIndex: Number,
            parentData: Object,
            allEditChecked: Boolean,
            info: '',
        },
        filters: {
            attrFilter(attrs) {
                const arr = [];
                for (const item in attrs) {
                    arr.push(attrs[item].value);
                }
                return arr.join(', ');
            },
            pricesFilter(priceList) {
                return priceList.map(item => `${item.price} x ${item.qty}`).join(', ');
            },
            priceTypeFilter(...args) {
                let text = '';
                if (+args[0] === 4) {
                    text = args[1].$trans('cart.mark_arrival_notice');
                } else if (+args[2] === 1) {
                    text = args[1].$trans('cart.email_only');
                } else if (+args[2] === 2) {
                    text = args[1].$trans('cart.mark_presale');
                } else if (+args[2] === 7) {
                    text = args[1].$trans('cart.mark_flash_sale');
                }
                return text;
            }
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        watch: {
            goods: {
                handler(val) {
                    // this.editmode = false;
                    this.isSelected = val.isSelected;
                    this.goodOrigQty = val.goodSnQty; // 更新原始库存
                },
                deep: true
            }
        },
        /* created() {
            const vm = this;
            vm.id = `slide_${vm.wareIndex}_${vm.shopIndex}_${vm.groupIdx}_${vm.goodsIndex}${(vm.partsIndex >= 0 ? `_${vm.partsIndex}` : '')}`;
            vm.$bus.$on('closeSlideMode', (data) => {
                if (data !== vm.id) {
                    vm.closeSlideMode();
                }
            });
        },
        mounted() {
            const vm = this;
            vm.$nextTick(() => {
                if (!vm.el) {
                    vm.el = vm.$refs[vm.id];
                    vm.favorbtn = vm.$refs.favorbtn;
                    vm.maxslidedis = window.lib.flexible.rem2px(3.2);
                }
            });
        }, */
        methods: {
            // 滑动编辑商品
            /* touchStart(id, evt) {
                const vm = this;
                const startPoint = evt.touches ? evt.touches[0] : evt;
                vm.mouseDown = true;
                vm.startX = startPoint.pageX;
                vm.startY = startPoint.pageY;

                vm.$bus.$emit('closeSlideMode', id);

                if (vm.el) {
                    vm.el.classList.remove('transformed');
                    vm.favorbtn.classList.remove('transformed');
                }
            },
            touchMove(evt) {
                const vm = this;
                evt.cancelBubble = true;
                if (evt.touches === undefined && vm.mouseDown) {
                    return false;
                }
                const movePoint = evt.touches ? evt.touches[0] : evt;
                let disx = movePoint.pageX - vm.startX;
                const angle = Math.atan((vm.startY - movePoint.pageY) / disx) / (Math.PI * 180); // 滑动角度

                if (Math.abs(angle) <= 7 && Math.abs(disx) >= vm.maxslidedis / 3) {
                    evt.preventDefault();
                    if (disx > 0) {
                        // 向右滑动
                        if (!vm.slidemode) {
                            // if(disx >= 40){
                            //     disx = 40;
                            // }
                            // vm.slidedis = disx;
                            return false;
                        } else if (vm.slidedis > 0) {
                            vm.slidedis = -vm.slidedis;
                        }
                        disx = vm.slidedis + disx;
                        if (disx >= 5) {
                            disx = 5;
                        }
                        vm.fixTranslateX(vm.el, disx);
                    } else {
                        // 向左滑动
                        if (evt.deltaX < 0) {
                            if (vm.slidedis >= vm.maxslidedis) {
                                disx = -vm.maxslidedis - Math.abs(disx / 30);
                            }
                        } else if (vm.slidedis >= vm.maxslidedis) {
                            disx = -vm.maxslidedis;
                        }

                        vm.slidedis = Math.abs(disx);
                        vm.fixTranslateX(vm.favorbtn, -disx / 2);
                        vm.fixTranslateX(vm.el, disx);
                    }
                }
                return false;
            },
            touchEnd(evt) {
                const vm = this;
                if (evt.changedTouches === undefined && vm.mouseDown) {
                    return false;
                }
                const endPoint = evt.changedTouches ? evt.changedTouches[0] : evt;
                const disx = endPoint.pageX - vm.startX;
                const angle = Math.atan((endPoint.pageY - vm.startY) / disx) / (Math.PI * 180); // 滑动角度

                vm.el.classList.add('transformed');
                vm.favorbtn.classList.add('transformed');

                if (Math.abs(angle) <= 10 && disx < 0 && -disx >= vm.maxslidedis / 3) {
                    vm.slidedis = vm.maxslidedis;
                    vm.fixTranslateX(vm.el, -vm.maxslidedis);
                    vm.fixTranslateX(vm.favorbtn, vm.maxslidedis / 2);
                    vm.slidemode = true;
                } else if (Math.abs(disx) >= 5) {
                    vm.closeSlideMode();
                }
                vm.mouseDown = false;
                return false;
            },
            // 取消滑动
            closeSlideMode() {
                const vm = this;
                vm.slidedis = 0;
                // vm.favorbtn.classList.remove('transformed');
                vm.fixTranslateX(vm.el, 0);
                vm.slidemode = false;
            }, */
            // 编辑单个商品
            /* editGoods(close) {
                this.editmode = true;
            }, */
            // fix translateX
            /* fixTranslateX(el, disx) {
                el.style.webkitTransform = `translateX(${disx}px)`;
                el.style.mozTransform = `translateX(${disx}px)`;
                el.style.oTransform = `translateX(${disx}px)`;
                el.style.msTransform = `translateX(${disx}px)`;
                el.style.transform = `translateX(${disx}px)`;
            }, */
            // 确认编辑更新商品数量
            async confirmEdit() {
                const vm = this;
                /* if (vm.goodSnQty === vm.goodOrigQty) {
                    vm.editmode = false;
                } else { */
                const res = await serviceCartUpdate.http({
                    data: {
                        itemId: vm.goods.itemId,
                        qty: vm.goodSnQty,
                    }
                });

                if (res.status === 0) {
                    // vm.editmode = false;
                    vm.$bus.$emit('getCartList');
                } else {
                    vm.$toast({ msg: res.msg });
                }
            },
            // 切换商品分期提示信息
            /* showInstalment(info) {
                this.$alert({
                    content: info,
                    title: this.$trans('cart.tips'),
                    okText: this.$trans('cart.ok')
                });
            }, */
            // 切换商品提示信息
            showtip() {
                this.tip_float = !this.tip_float;
            },
            // 编辑商品属性弹窗
            async editAttrs(goods) {
                const vm = this;
                if (goods.allowBuy === 0 || goods.stockNum <= 0 || goods.goodType === 1 || goods.goodType === 2 || goods.goodType === 21 || goods.goodType === 3) return; // eslint-disable-line

                const res = await serviceCartSameGoods.http({
                    params: {
                        goodSn: vm.goods.goodSn,
                        virWhCode: vm.goods.warehouseCode
                    }
                });
                if (res.status === 0) {
                    vm.$alert({
                        shadowClose: true,
                        rollfrom: 'bottom',
                        customClass: 'goods_replace',
                        component: goodsReplace,
                        goodsInfo: vm.goods,
                        attrList: res.data.attrList,
                        goodsList: res.data.goodsList,
                        closeSlideMode: vm.closeSlideMode,
                        editGoods: vm.editGoods
                    });
                } else {
                    vm.$toast({ msg: res.msg });
                }
            },
            // 切换商品活动弹窗
            changeActs() {
                const vm = this;
                vm.$alert({
                    title: vm.$trans('cart.choose_activity'),
                    customClass: 'changeActDialog',
                    rollfrom: 'bottom',
                    shadowClose: true,
                    component: changeAct,
                    componentData: {
                        activityList: vm.goods.canJoinActivityList,
                        activityId: vm.goods.activityId,
                        eventName: 'changeGoodsAct',
                        itemId: vm.goods.itemId,
                    },
                });
            },
            // 收藏商品
            /* favor() {
                this.closeSlideMode();
                this.$bus.$emit('goodsFavor', { itemId: `${this.goods.goodSn}_${this.goods.warehouseCode}` });
            }, */
            // 确认删除
            /* async todelete() {
                const vm = this;
                const loading = vm.$loading();
                const res = await serviceCartDelete.http({
                    data: {
                        itemId: vm.goods.itemId
                    }
                }).catch(() => {
                    loading.close();
                });

                if (res.status === 0) {
                    vm.closeSlideMode();
                    // 更新header购物车右上角显示数量
                    PubSub.publish('sysUpdateUserStatus');

                    vm.$bus.$emit('getCartList', { $dialog: loading });
                } else {
                    loading.close();
                    vm.$toast({ msg: res.msg });
                }
            }, */
            deposit(goods) {
                const { skuAdvanceDetail } = goods;
                const { advanceAmount, swellDiscontAmount } = skuAdvanceDetail;

                return swellDiscontAmount > 0 ? this.$trans('cart.deposit_discount', [this.remainderRule.one(advanceAmount), this.remainderRule.one(swellDiscontAmount, 0)]) : this.$trans('cart.deposit_mount', [this.remainderRule.one(advanceAmount)]); // eslint-disable-line
            },
            showCodTip() {
                layer.open({
                    content: `
                        <div class="dropbox_cod_content">
                            <p class="cod_tips">${this.$trans('cart.cod_tips')}</p>
                            <div class="close_cod_tips js-closeCodTips">OK</div>
                        </div>
                    `,
                    success() {
                        $(document).on('click', '.dropbox_cod_content .js-closeCodTips', () => {
                            layer.closeAll();
                        });
                    }
                });
            }
        }
    };
</script>

<style>
@import 'pages/paycart/component/cart/goodsgroup.css';
</style>
