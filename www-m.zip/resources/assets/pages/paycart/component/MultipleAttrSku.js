/**
 * Created by Liu.Jun on 2018/2/6.
 */

// 简单质数相乘整除
export default class MultipleAttrSku {
    constructor(attrPrimeList, skuList) {
        this.skuList = MultipleAttrSku.copyArr(skuList);
        this.attrPrimeList = MultipleAttrSku.copyArr(attrPrimeList);
    }

    static copyArr(arr) {
        return JSON.parse(JSON.stringify(arr));
    }

    getStatusByAttr(selectAttr = []) {
        const { attrPrimeList } = this;

        // 先分析出 所选中的属性 分别在哪个维度 ，计算的时候同维度需要跳过计算
        const indexMap = selectAttr.map((item) => {
            const re = {
                index: (function getIndex(list) {
                    let index = 0;
                    list.some((cate, cateIndex) => {
                        if (cate.indexOf(item) > -1) {
                            index = cateIndex;
                            return true;
                        }
                        return false;
                    });
                    return index;
                }(attrPrimeList)),
                key: item,
            };
            return re;
        });

        return attrPrimeList.map((cate, cateIndex) => {
            const re = cate.map((item) => {
                let baseNum = 1;

                indexMap.forEach((selectItem) => {
                    if (selectItem.index !== cateIndex) {
                        // 不同行直接相乘
                        baseNum *= selectItem.key;
                    }
                });
                baseNum *= item;

                return +this.skuList.some(skuItem => skuItem % baseNum === 0);
            });
            return re;
        });
    }
}
