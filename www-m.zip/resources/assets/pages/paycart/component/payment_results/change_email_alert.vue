<template lang="pug">
    .qbChangeEmail
        .qbChangeEmail_title.font-34 {{ $trans('order.quickbuy_alert_title') }}

        .qbChangeEmail_form
            .qbChangeEmail_formItem(v-for="(formItem, formKey) in formInfo")
                .qbCEFormItem_lable.font-26
                    span {{ formItem.title }}:
                .qbCEFormItem_enter
                    .qbCEFormItem_enter-box(:class="{'err': formItem.errorTip}")
                        input(:type="formKey == 'newEmail' ? 'text' : 'password'", :name="formKey", :placeholder="formItem.placeholder" v-model="formItem.value" @blur="valited" @focus="formItem.errorTip = ''")
                    .qbCEFormItem_enterTip.font-24
                        span {{ formItem.errorTip }}

            //- 保存按钮
            a.btn.middle.strong.qbChangeEmail_formBtn.font-36(href="javascript:;" @click="saveBtn") {{ $trans('order.quickbuy_config_save') }}
</template>

<script>
import { servicePaymetResultsReplaceEmail } from 'js/service/paycart';

export default {
    data() {
        return {
            formInfo: {
                oldPassword: {
                    title: this.$trans('order.quickbuy_alert_oldpwd_title'),
                    placeholder: '',
                    errorTip: '',
                    reg: 1,
                    value: '',
                    errorTxt: {
                        require: this.$trans('order.quickbuy_alert_oldpwd_require'),
                        reg: '',
                    }
                },
                newEmail: {
                    title: this.$trans('order.quickbuy_alert_newemail_title'),
                    placeholder: '',
                    errorTip: '',
                    reg: /^\w+[\w-]*(\.[\w-]+)*@\w+[\w-]*(\.[\w-]+)+$/,
                    value: '',
                    errorTxt: {
                        require: this.$trans('order.quickbuy_alert_newemail_require'),
                        reg: this.$trans('order.quickbuy_alert_newemail_reg'),
                    }
                },
            }
        };
    },
    methods: {
        valited() {
            const vm = this;
            let regNum = 0;

            for (const keyName in vm.formInfo) {
                const keyItem = vm.formInfo[keyName];
                let testSign = false;

                if (typeof keyItem.reg === 'object') {
                    testSign = keyItem.reg.test(keyItem.value.trim());
                } else if (keyItem.reg === 1 && keyItem.value.trim()) {
                    testSign = true;
                } else {
                    testSign = false;
                }

                if (testSign) {
                    regNum += 1;
                    keyItem.errorTip = '';
                } else if (keyItem.value.trim()) {
                    keyItem.errorTip = keyItem.errorTxt.reg;
                } else {
                    keyItem.errorTip = keyItem.errorTxt.require;
                }
            }
            if (regNum < 2) return false;
            return true;
        },
        // 请求数据
        async saveBtn() {
            const vm = this;
            if (!vm.valited()) return;

            const { status, data } = await servicePaymetResultsReplaceEmail.http({
                data: {
                    oldEmail: this.$parent.componentData.oldEmail,
                    oldPassword: vm.formInfo.oldPassword.value.trim(),
                    newEmail: vm.formInfo.newEmail.value.trim()
                }
            });

            if (status === 0) {
                vm.$bus.$emit('changeEmail', vm.formInfo.newEmail.value.trim());
                vm.$parent.close();
            } else if (data.innerCode === 70009) { // 密码错误
                vm.formInfo.oldPassword.errorTip = vm.$trans('order.quickbuy_alert_oldpwd_err');
            } else if (data.innerCode === 70016) { // 邮箱不存在
                vm.formInfo.newEmail.errorTip = vm.$trans('order.quickbuy_alert_newemail_err');
            } else {
                vm.$toast({ timer: 2000, msg: data.innerMsg });
            }
        }
    }
};
</script>

<style>
@import 'pages/paycart/mixins.css';
/* 重置弹窗样式 */
.quickBuyChangeEmail .kdialog_box .kdialog_content {
    max-height: 1000px;
    padding: 0;
}

.quickBuyChangeEmail .kdialog_box .kdialog_footer,
.quickBuyChangeEmail .kdialog_box .kdialog_close  {
    display: none;
}

.qbChangeEmail {padding: rem(40);}

.qbChangeEmail_title {
    text-align: center;
    color: var(--color-text-primary);
    line-height: rem(40);
}

.qbChangeEmail_form {padding: rem(20) 0 rem(10);}

.qbCEFormItem_lable {line-height: rem(60);}

.qbCEFormItem_enter-box {
    border: 1px solid var(--color-other-18);
    border-radius: rem(4);
}

.qbCEFormItem_enter-box.err {border-color: var(--color-danger);}

.qbCEFormItem_enter-box input {
    margin: 0;
    border: 0;
    outline: none;
    height: rem(78);
    width: 100%;
    padding: 0 rem(20);
}

.qbCEFormItem_enterTip {
    margin-bottom: rem(10);
    line-height: rem(60);
    color: var(--color-danger);
}

.qbChangeEmail_formBtn.btn.middle {
    margin-top: rem(20);
    line-height: rem(80);
    height: rem(80);
}
</style>
