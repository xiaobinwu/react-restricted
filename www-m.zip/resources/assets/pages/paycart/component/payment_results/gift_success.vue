<template lang="pug">
    .giftInfoContainer 
        .gic_title(v-html="giftInfo.prizeDescInfo.prizeTips") 
        .gic_content(v-html="giftInfo.prizeDescInfo.prizeDesc")
        .gic_footer
            ul.gic_share
                li.gic_shareItem.js-fb(href="javascript:;")
                    img(:src="$staticAsset('/img/site/facebook@.png')")
                li.gic_shareItem.js-google(href="javascript:;")
                    img(:src="$staticAsset('/img/site/google+@.png')")
                li.gic_shareItem.js-tw(href="javascript:;")
                    img(:src="$staticAsset('/img/site/twitter@.png')")
                li.gic_shareItem.js-vk(href="javascript:;")
                    img(:src="$staticAsset('/img/site/vkontakte@.png')")
                li.gic_shareItem.js-reddit(href="javascript:;")
                    img(:src="$staticAsset('/img/site/reddit@.png')")   
            p.gic_shareTip {{ giftInfo.prizeDescInfo.prizeShareText }}

</template>

<script>

    import Share from '../../../../component/share/share';

    export default {
        data() {
            return {
                giftInfo: this.$parent.componentData.giftData,
            };
        },
        created() {
            const vm = this;

            const shareExample = new Share();
            shareExample.facebook({
                appId: 900125666754558,
                selector: '.js-fb',
                url: vm.giftInfo.shareConfig.shareUrl,
            });
            shareExample.twitter({
                desc: vm.giftInfo.shareConfig.shareContent,
                url: vm.giftInfo.shareConfig.shareUrl,
                selector: '.js-tw',
            });
            shareExample.vk({
                selector: '.js-vk',
                url: vm.giftInfo.shareConfig.shareUrl,
                title: vm.giftInfo.shareConfig.shareTitle,
                img: vm.giftInfo.shareConfig.shareImage,
            });

            shareExample.google({
                selector: '.js-google',
                url: vm.giftInfo.shareConfig.shareUrl,
                title: vm.giftInfo.shareConfig.shareTitle,
            });

            shareExample.reddit({
                selector: '.js-reddit',
                url: vm.giftInfo.shareConfig.shareUrl,
                title: vm.giftInfo.shareConfig.shareTitle,
            });
        }
    };
</script>
