<template lang="pug">
    .quickBuy
        //- 支付信息
        .quickBuy_payinfo
            h3.qbPayInfo_title.font-40 {{ $trans('order.payment_successful') }}
            p.qbPayInfo_order.font-28
                span {{ $trans('order.payment_paid') }} :
                span.red {{ quickBuyInfo.orderInfo.orderAmountText }}
            p.qbPayInfo_order.font-28
                span {{ $trans('order.payment_order_no') }} :
                span {{ quickBuyInfo.orderInfo.orderSn }}

            .qbPayInfo_btnBox
                a.qbPayInfo_btn(href="javascript:;") {{ $trans('order.quickbuy_payinfo_copy') }}
            p.qbPayInfo_copyTip.font-28 {{ $trans('order.quickbuy_payinfo_copy_tip') }}

        //- 注册账户
        .quickBuy_account.font-28(v-if="!quickBuyInfo.visitorInfo.isValidateEmail")
            //- 设置账户email
            .qbAccount_config(v-if="!visitorInfo.activeUser")
                .qbAcConfig_title {{ $trans('order.quickbuy_config_title') }}
                .qbAcConfig_errTip(v-if="configInfoObj.registered") {{ $trans('order.quickbuy_config_err_tip') }}
                .qbAcConfig_changeEmail(v-if="!configInfoObj.formInfo.email.isShow")
                    span {{ $trans('order.quickbuy_config_email') }}：
                    b {{ visitorInfo.email }}
                    a(href="javascript:;" @click="configChangeEamil()") {{ $trans('order.quickbuy_config_change') }}

                .qbAcConfig_form
                    .qbAcConfig_formItem(v-for="(formItem, formKey) in configInfoObj.formInfo" v-if="formItem.isShow")
                        .qbAcConfig_formItemBox(:class="{'focus': formItem.isFocus}")
                            i.qbAcConfig_formItemIconType(:class="{'icon-password': formKey != 'email', 'icon-mail': formKey == 'email'}")
                            input.qbAcConfig_formItemInput(:type="formKey == 'email' ? 'text' : 'password'" :name="formKey" :placeholder="formItem.placeholder" v-model="formItem.value" @blur="configValidate(formItem)" @focus="configFocus(formItem)")
                            i.qbAcConfig_formItemIconClear.icon-closed(v-if="formItem.value" @click="formItem.value = ''")
                        .qacFormItem_enterTip {{ formItem.errorTip }}

                    //- 法律条款
                    .qbAcConfig_formItem
                        .qbAcConfig_formItemClause
                            i.qacFormItem_checkbox.font-22(:class="{'icon-tick': configInfoObj.clause.checked}" @click="configInfoObj.clause.checked = !configInfoObj.clause.checked")
                            .qacFormItem_cehckTxt.font-26(v-html="$trans('order.quickbuy_config_clause', [DOMAIN_MAIN, DOMAIN_MAIN])")
                        .qacFormItem_enterTip(v-if="!configInfoObj.clause.checked") {{ configInfoObj.clause.errorTip }}
                    //- 欧盟法案
                    .qbAcConfig_formItem(v-if="configInfoObj.clauseEU.isEU")
                        .qbAcConfig_formItemClause
                            i.qacFormItem_checkbox.font-22(:class="{'icon-tick': configInfoObj.clauseEU.checked}" @click="configInfoObj.clauseEU.checked = !configInfoObj.clauseEU.checked")
                            .qacFormItem_cehckTxt.font-26(v-html="$trans('order.quickbuy_config_clause_eu', [DOMAIN_MAIN])")
                        .qacFormItem_enterTip(v-if="!configInfoObj.clauseEU.checked") {{ configInfoObj.clauseEU.errorTip }}

                    //- 保存按钮
                    a.btn.middle.strong.qbAcConfig_formBtn.font-36(href="javascript:;" @click="configSave()") {{ $trans('order.quickbuy_config_save') }}

                .qbAcConfig_tip.font-24
                    b {{ $trans('order.quickbuy_config_tips') }}：
                    span {{ $trans('order.quickbuy_config_tip_txt') }}

            //- 设置成功
            .qbAccount_finish(v-else)
                .qbAcFinish_title.font-36 {{ $trans('order.quickbuy_finish_title') }}
                .qbAcFinish_txt {{ $trans('order.quickbuy_finish_section') }}
                .qbAcFinish_email
                    | {{ $trans('order.quickbuy_finish_email_address') }}：
                    b {{ visitorInfo.email }}

                a.btn.middle.strong.qbAcFinish_btn.font-36(href="javascript:;" :class="{'disable' : finishObj.resendCount > 0}" @click="finishResend()") {{ finishObj.resendCount > 0 ? $trans('order.quickbuy_finish_count_down', [finishObj.resendCount]) : $trans('order.quickbuy_finish_btn_resend') }}
                a.btn.middle.line1.qbAcFinish_btn.font-36(href="javascript:;" @click="finishChangeEmail()") {{ $trans('order.quickbuy_finish_btn_change') }}
</template>

<script>
import { servicePaymetResultsVisitorReplace } from 'js/service/paycart';
import { sendActivationEmail } from 'js/service/auth';
import { testPassword } from 'js/utils/regExp';

import changeemailalert from './change_email_alert.vue';

export default {
    props: ['quickBuyInfo'],
    data() {
        return {
            DOMAIN_MAIN: window.GLOBAL.DOMAIN_MAIN, // 网站主域名
            visitorInfo: this.quickBuyInfo.visitorInfo, // 是否成为正式用户
            configInfoObj: { // ----- 设置账户 -----
                registered: 0, // 邮箱是否已经注册
                clause: { // 是否勾选条款
                    checked: 0,
                    errorTip: this.$trans('order.quickbuy_config_clause_error'),
                },
                clauseEU: { // 是否勾选欧盟法案
                    isEU: window.payVars.isEU, // 是否为欧盟地区
                    checked: 0,
                    errorTip: this.$trans('order.quickbuy_config_clause_eu_error'),
                },
                formInfo: { // 表单内容数据
                    email: {
                        isShow: 1,
                        isFocus: 0,
                        title: this.$trans('order.quickbuy_config_email_title'),
                        placeholder: this.$trans('order.quickbuy_config_email_title'),
                        errorTip: '',
                        reg: /^\w+[\w-]*(\.[\w-]+)*@\w+[\w-]*(\.[\w-]+)+$/,
                        value: '',
                        errorTxt: {
                            require: this.$trans('order.quickbuy_config_email_require'),
                            reg: this.$trans('order.quickbuy_config_email_reg'),
                        }
                    },
                    newPassword: {
                        isShow: 1,
                        isFocus: 0,
                        title: this.$trans('order.quickbuy_config_psd_title'),
                        placeholder: this.$trans('order.quickbuy_config_psd_title'),
                        errorTip: '',
                        reg: testPassword,
                        value: '',
                        errorTxt: {
                            require: this.$trans('order.quickbuy_config_psd_require'),
                            reg: this.$trans('order.quickbuy_config_psd_reg'),
                        }
                    },
                    towNewPassword: {
                        isShow: 1,
                        isFocus: 0,
                        title: this.$trans('order.quickbuy_config_psd2_title'),
                        placeholder: this.$trans('order.quickbuy_config_psd2_title'),
                        errorTip: '',
                        reg: 'newPassword',
                        value: '',
                        errorTxt: {
                            require: this.$trans('order.quickbuy_config_psd2_require'),
                            reg: this.$trans('order.quickbuy_config_psd2_reg'),
                        }
                    }
                }
            },
            finishObj: { // ----- 激活 更改邮箱 -----
                resendCount: 0,
            }
        };
    },
    async created() {
        const Clipboard = await import('clipboard');
        const vm = this;

        // 绑定剪切板事件
        const clipboard = new Clipboard('.qbPayInfo_btn', {
            text() {
                let copyMsg = vm.$trans(
                    'order.quickbuy_payinfo_content',
                    [vm.quickBuyInfo.orderInfo.orderSn, vm.quickBuyInfo.orderInfo.orderAmountText]
                );
                copyMsg = copyMsg.replace('<b>', '');
                copyMsg = copyMsg.replace('</b>', '');
                copyMsg = copyMsg.replace('<b class="org">', '');
                copyMsg = copyMsg.replace('</b>', '');
                return copyMsg;
            }
        });
        clipboard.on('success', () => vm.$toast({ timer: 2000, msg: vm.$trans('order.quickbuy_payinfo_copy_success') }));

        if (!vm.visitorInfo.activeUser) { // 是否是正式用户
            vm.configInit();
        }

        if (window.payVars.step !== 31) {
            vm.enterAlert();
        }

        vm.$bus.$on('changeEmail', (data) => {
            vm.finishChangeAcount();
            vm.visitorInfo.email = data;
        });
    },
    methods: {
        // ----- 基础方法 -----
        enterAlert() {
            const vm = this;
            vm.$alert({
                customClass: 'quickBuy_fristAlert',
                content: `
                    <div class="quickBuy_fristAlertCon">
                        <h5 class="font-32">${vm.$trans('order.quickbuy_alert_enter_title')}</h5>
                        <p class="font-28">${vm.$trans('order.quickbuy_alert_enter_conten')}</p>
                    </div>
                `
            });
        },
        configInit() { // 不是正式用户
            const vm = this;
            // 绑定邮箱状态 及 数据
            vm.configInfoObj.registered = vm.visitorInfo.isEmailRegister;
            vm.configInfoObj.formInfo.email.isShow = vm.visitorInfo.isEmailRegister;
            vm.configInfoObj.formInfo.email.value = vm.visitorInfo.email;
        },
        configChangeEamil() {
            const vm = this;
            vm.configInfoObj.formInfo.email.isShow = 1;
            vm.configInfoObj.formInfo.email.value = '';
        },
        configFocus(item) { // 表单获焦事件
            item.errorTip = '';
            item.isFocus = 1;
        },
        configValidate(item) { // 校验表单规则
            if (item) item.isFocus = 0; // 失焦事件处理

            const vm = this;
            const validateForm = vm.configInfoObj.formInfo;

            let regNum = 0;

            for (const keyName in validateForm) {
                const keyItem = validateForm[keyName];
                let testSign = false;

                if (typeof keyItem.reg === 'object') {
                    testSign = keyItem.reg.test(keyItem.value.trim());
                } else if (typeof keyItem.reg === 'string') {
                    if (validateForm[keyItem.reg].value.trim()) {
                        testSign = keyItem.value.trim() === validateForm[keyItem.reg].value.trim();
                    } else {
                        testSign = false;
                    }
                } else {
                    testSign = keyItem.reg(keyItem.value);
                }

                if (testSign) {
                    regNum += 1;
                    keyItem.errorTip = '';
                } else if (keyItem.value.trim()) {
                    keyItem.errorTip = keyItem.errorTxt.reg;
                } else {
                    keyItem.errorTip = keyItem.errorTxt.require;
                }

                // 针对邮箱字段特殊处理
                if (keyName === 'email' && testSign) {
                    vm.configInfoObj.registered = 0;
                }
            }

            if (vm.configInfoObj.clause.checked) { // 判断是否勾选法律条款
                regNum += 1;
            }

            if (vm.configInfoObj.clauseEU.isEU && vm.configInfoObj.clauseEU.checked) { // 欧盟地区需要勾选欧盟法案
                regNum += 1;
            }

            if (regNum < 4 + vm.configInfoObj.clauseEU.isEU) return false;
            return true;
        },
        finishChangeEmail() {
            const vm = this;
            vm.$confirm({
                customClass: 'quickBuyChangeEmail',
                component: changeemailalert,
                componentData: {
                    oldEmail: vm.visitorInfo.email,
                },
            });
        },
        finishChangeAcount(acountNum = 60) {
            const vm = this;
            vm.finishObj.resendCount = acountNum;
            const timer = setInterval(() => {
                vm.finishObj.resendCount -= 1;
                if (vm.finishObj.resendCount <= 0) {
                    vm.finishObj.resendCount = 0;
                    clearInterval(timer);
                }
            }, 1000);
        },
        // ----- 异步接口 -----
        async configSave() {
            const vm = this;
            if (!vm.configValidate()) return; // 不可提交数据状态

            const { status, data, msg } = await servicePaymetResultsVisitorReplace.http({
                data: {
                    visitorId: vm.visitorInfo.visitorId,
                    newEmail: vm.configInfoObj.formInfo.email.value.trim(),
                    newPassword: vm.configInfoObj.formInfo.newPassword.value.trim()
                }
            });

            if (status === 0) {
                // 接口请求成功转换为正式用户 未激活邮箱状态
                vm.visitorInfo.activeUser = 1;
                vm.visitorInfo.email = vm.configInfoObj.formInfo.email.value.trim();
                // 创建倒计时状态按钮置灰
                vm.finishChangeAcount();
            } else if (data.innerCode === 70016) {
                vm.configInfoObj.registered = 1;
            } else {
                vm.$toast({ timer: 2000, msg });
            }
        },
        async finishResend() { // 发送激活邮件
            const vm = this;
            if (vm.finishObj.resendCount > 0) return;

            const { status, data } = await sendActivationEmail.http({
                data: {
                    email: vm.visitorInfo.email
                }
            });
            if (status === 0) {
                vm.finishChangeAcount(data.ttl);
            }
        },
    }
};
</script>

<style>
    @import 'common/css/variable.css';
    .quickBuy {
        background: var(--color-main-bg);
        padding: rem(60) rem(30) rem(40);
        color: var(--color-text-primary);
    }

    .quickBuy b {
        font-weight: bold;
    }

    /*
    * 支付信息
    */
    .quickBuy_payinfo {
        padding-bottom: rem(30);
        border-bottom: 1px solid var(--color-other-2);
    }

    .qbPayInfo_title {
        text-align: center;
        font-weight: 400;
        margin: 0;
        line-height: rem(60);
        margin-bottom: rem(20);
    }

    .qbPayInfo_order {
        text-align: center;
        color: var(--disableC);
        line-height: rem(34);
    }

    .qbPayInfo_order .red {
        color: var(--color-price);
    }

    .qbPayInfo_btnBox {
        margin: rem(20) 0;
        font-size: 0;
        text-align: center;
    }

    .qbPayInfo_btnBox .qbPayInfo_btn {
        display: inline-block;
        background: var(--color-main-bg);
        border: 1px solid var(--color-text-primary);
        border-radius: rem(5);
        margin: 0 rem(16);
        padding: 0 rem(20);
        height: rem(64);
        line-height: rem(64);
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
        @mixin font 28;
    }

    .qbPayInfo_copyTip {
        text-align: center;
        line-height: rem(34);
    }

    /*
    * 注册信息
    */
    .quickBuy_account {
        padding: rem(30) 0;
    }

    /* 设置账户 */
    .qbAcConfig_title,
    .qbAcConfig_errTip,
    .qbAcConfig_changeEmail {
        line-height: rem(40);
        padding: rem(10) 0;
    }

    .qbAcConfig_errTip {
        color: var(--color-price);
    }

    .qbAcConfig_changeEmail a {
        color: var(--color-link);
        float: right;
    }

    .qbAcConfig_form {
        padding: rem(25) 0;
    }

    .qbAcConfig_formItem {
        margin-bottom: 20px;
    }

    .qbAcConfig_formItemBox {
        position: relative;
        border: 1px solid var(--color-border);
        border-radius: rem(6);
    }

    .qbAcConfig_formItemBox.focus {
        border-color: var(--color-primary);
    }

    .qbAcConfig_formItemBox.active {
        border-color: var(--color-primary);
    }

    .qbAcConfig_formItemIconType {
        position: absolute;
        left: rem(22);
        top: 50%;
        transform: translateY(-50%);
        width: rem(40);
        height: rem(40);
        color: var(--color-text-secondary);
    }

    .qbAcConfig_formItemIconClear {
        position: absolute;
        right: rem(20);
        top: 50%;
        transform: translateY(-50%);
        font-size: rem(24);
        width: rem(30);
        height: rem(30);
        line-height: rem(30);
        text-align: center;
        color: var(--color-float-btn);
        border-radius: 50%;
        background-color: var(--color-text-placeholder);
    }

    .qbAcConfig_formItemInput {
        display: block;
        width: 100%;
        margin: 0;
        border: 0;
        outline: none;
        padding: 0 rem(90);
        height: rem(88);
    }

    .qacFormItem_enterTip {
        padding: rem(20) rem(20) rem(10);
        line-height: rme(30);
        color: var(--color-price);
    }

    .qbAcConfig_formItemClause {
        padding: 0 rem(22);
        font-size: 0;
    }

    .qacFormItem_checkbox {
        display: inline-block;
        margin: rem(2) rem(34) 0 0;
        width: rem(36);
        height: rem(36);
        line-height: rem(38);
        text-align: center;
        border-radius: 50%;
        border: 2px solid var(--color-border);
    }

    .qacFormItem_checkbox.icon-tick {
        color: var(--color-text-primary);
        background-color: var(--color-primary);
        border: none;
    }

    .qacFormItem_cehckTxt {
        display: inline-block;
        vertical-align: top;
        max-width: rem(570);
        line-height: rem(34);
        color: var(--color-text-secondary);
    }

    .qacFormItem_cehckTxt a {
        text-decoration: underline;
        color: var(--color-text-regular);
    }

    .qbAcConfig_formBtn.btn.middle {
        line-height: rem(90);
        height: rem(90);
    }

    .qbAcConfig_tip {
        line-height: rem(30);
        color: var(--color-text-secondary);
    }

    .qbAcConfig_tip b {
        color: var(--color-text-primary);
    }

    /* 注册完成 */
    .qbAcFinish_title {
        color: var(--color-danger);
        padding: rem(10) 0;
        line-height: rem(40);
    }

    .qbAcFinish_txt,
    .qbAcFinish_email {
        line-height: rem(36);
        padding: rem(10) 0;
    }

    .qbAcFinish_btn.btn.middle {
        line-height: rem(90);
        height: rem(90);
        margin-top: rem(20);
    }

    .qbAcFinish_btn.btn.middle.line1 {
        background: var(--color-main-bg);
        border: 1px solid var(--color-text-primary);
        color: var(--color-text-primary);
    }

    .qbAcFinish_btn.btn.middle.disable {
        color: var(--color-text-placeholder);
        background: var(--color-fill-lable);
    }

    /*
    *   重置弹窗样式
    */
    .quickBuy_fristAlert .kdialog_footer {
        display: none;
    }

    .quickBuy_fristAlert .kdialog_content {
        padding: 0;
    }

    .quickBuy_fristAlertCon {
        padding: rem(50);
    }

    .quickBuy_fristAlertCon h5 {
        line-height: rem(40);
        margin-bottom: rem(20);
        font-weight: bold;
    }

    .quickBuy_fristAlertCon p {
        line-height: rem(40);
        color: var(--color-text-secondary);
    }
</style>
