<template lang="pug">
    .bankInfoBox
        .bankInfo_title 
            span(v-if="payChannelCode === 'BANK_TRANSFER'") {{ $trans('order.wire_transfer_bankinfo_title') }}
            span(v-else) {{ $trans('order.payment_line_bankinfo_title', [paymentInfo.payChannelName]) }}

        ul.bankInfo_content(v-if="payChannelCode === 'BankTransfer'")
            li.bankInfo_item(v-if="bankInfo.paymentReference")
                s {{ $trans('order.payment_reference') }}: 
                span {{ bankInfo.paymentReference }}
            li.bankInfo_item(v-if="bankInfo.swiftCode")
                s {{ $trans('order.swiftcode') }}: 
                span {{ bankInfo.swiftCode }}
            li.bankInfo_item(v-if="bankInfo.iban")
                s {{ $trans('order.iban') }}: 
                span {{ bankInfo.iban }}
            li.bankInfo_item(v-if="bankInfo.countryName")
                s {{ $trans('order.country') }}: 
                span {{ bankInfo.countryName }}
            li.bankInfo_item(v-if="bankInfo.city")
                s {{ $trans('order.city') }}: 
                span {{ bankInfo.city }}
            li.bankInfo_item(v-if="bankInfo.bankName")
                s {{ $trans('order.bank_name') }}: 
                span {{ bankInfo.bankName }}
            li.bankInfo_item(v-if="bankInfo.bankAccountNumber")
                s {{ $trans('order.bank_account') }}: 
                span {{ bankInfo.bankAccountNumber }}
            li.bankInfo_item(v-if="bankInfo.accountHolder")
                s {{ $trans('order.account_holder') }}: 
                span {{ bankInfo.accountHolder }}
            //- GC银行specialid字段展示数据
            li.bankInfo_item(v-if="bankInfo.specialid")
                s {{ $trans('order.country_specific_bank_key') }}: 
                span {{ bankInfo.specialid }}
            //- li.bankInfo_item(v-for="spItem in gcShowSpecialid")
                s {{ spItem[0] }}
                span {{ spItem[1] }}

        ul.bankInfo_content(v-else-if="payChannelCode === 'ADN_PTMB'")
            li.bankInfo_item(v-if="multibancoInfo.amount")
                s {{ $trans('order.payable_amount_val') }}: 
                span {{ multibancoInfo.amount }}
            li.bankInfo_item(v-if="multibancoInfo.deadLine")
                s {{ $trans('order.expiry_date') }}: 
                span {{ multibancoInfo.deadLine }} {{ $trans('order.payment_company_days') }}

        ul.bankInfo_content(v-else-if="payChannelCode === 'BANK_TRANSFER'")
            li.bankInfo_item.wireTransfer_item
                span(:title="$trans('order.wire_transfer_acc_name')") {{ $trans('order.wire_transfer_acc_name') }}: 
                p(:title="$trans('order.wire_transfer_acc_nameval')") {{ $trans('order.wire_transfer_acc_nameval') }}
            li.bankInfo_item.wireTransfer_item
                span(:title="$trans('order.wire_transfer_acc_number')") {{ $trans('order.wire_transfer_acc_number') }}: 
                p(:title="$trans('order.wire_transfer_acc_numberval')") {{ $trans('order.wire_transfer_acc_numberval') }}
            li.bankInfo_item.wireTransfer_item
                span(:title="$trans('order.wire_transfer_bank_name')") {{ $trans('order.wire_transfer_bank_name') }}: 
                p(:title="$trans('order.wire_transfer_bank_nameval')") {{ $trans('order.wire_transfer_bank_nameval') }}
            li.bankInfo_item.wireTransfer_item
                span(:title="$trans('order.wire_transfer_acc_add')") {{ $trans('order.wire_transfer_acc_add') }}: 
                p(:title="$trans('order.wire_transfer_acc_addval')") {{ $trans('order.wire_transfer_acc_addval') }}
            li.bankInfo_item.wireTransfer_item
                span(:title="$trans('order.wire_transfer_swift_code')") {{ $trans('order.wire_transfer_swift_code') }}: 
                p(:title="$trans('order.wire_transfer_swift_codeval')") {{ $trans('order.wire_transfer_swift_codeval') }}

        p.bankInfo_tip(v-if="payChannelCode === 'BankTransfer'" v-html="$trans('order.bank_transfer_desc')")
        p.bankInfo_tip(v-else-if="payChannelCode === 'ADN_PTMB'" v-html="$trans('order.multibanco_tips', [3])")
        p.bankInfo_tip(v-if="payChannelCode === 'BANK_TRANSFER'" v-html="$trans('order.wire_transfer_conten_m_tip', ['https://wap-support.gearbest.com/ticket/ticket/ticket-list'])")
</template>

<script>
    export default {
        data() {
            return {
                bankInfo: this.$parent.componentData.bankInfo,
                gcShowSpecialid: this.$parent.componentData.gcShowSpecialid,
                multibancoInfo: this.$parent.componentData.multibancoInfo,
                payChannelCode: this.$parent.componentData.payChannelCode,
                paymentInfo: this.$parent.componentData.paymentInfo
            };
        },
    };
</script>