<template lang="pug">
    .payment_result
        //- 快捷购物版支付结果页
        quickbuy(v-if="isShowQuickBuy", :quickBuyInfo="quickBuyInfo")

        //- 默认版本支付结果页
        .payment_content(v-else)
            h3.payment_title

                //- COD 支付结果title
                span(v-if="paymentInfo.checkoutType == 1") {{ $trans('order.payment_submit') }}

                span(v-else-if="paymentInfo.payStatus == 1") {{ $trans('order.payment_successful') }}
                span(v-else-if="paymentInfo.payStatus == 2") {{ $trans('order.payment_pending') }}
                span(v-else-if="paymentInfo.payStatus == 3") {{ $trans('order.payment_failed') }}
                span(v-else-if="paymentInfo.payStatus == 4") {{ $trans('order.payment_refund') }}

            p.payment_orderInfo
                span
                    | {{ paymentInfo.payStatus == 1 ? $trans('order.payment_paid') : ''}}
                    | {{ paymentInfo.payStatus == 2 ? $trans('order.payment_paid') : ''}}
                    | {{ paymentInfo.payStatus == 3 ? $trans('order.payment_need_to_pay') : ''}}
                    | {{ paymentInfo.payStatus == 4 ? $trans('order.payment_paid') : ''}} :
                span.red {{ paymentInfo.orderAmountText }}

            p.payment_orderInfo(v-if="paymentInfo.checkoutType === 1")
                span {{ $trans('cod_discount') }} :
                span.red {{ paymentInfo.currencySign }}{{ (paymentInfo.codInfo.codDiscountAmount).toFixed(2) }}

            p.payment_orderInfo
                span {{ $trans('order.payment_order_no') }} :
                span {{ paymentInfo.parentOrderSn }}

            .payment_btnBox
                //- 支付成功
                a(:href="onlineBtn.src" target="_blank" v-finger:tap="openBankInfo") {{ onlineBtn.txt }}

                //- 支付失败
                a.strong(v-if="paymentInfo.payStatus == 3", :href="continueToPayment" target="_self") {{ $trans('order.payment_continue_to_payment') }}

            //- 商品返券
            p.payment_couponTip(v-if="paymentInfo.isCouponTip && !paymentInfo.isCancelled")
                i.icon-gift
                | {{ $trans('order.payment_coupon_tip') }}

            //- 线上pending状态 支付超时优化
            p.payment_lineTip(v-if="(paymentInfo.payChannelType == 0 || paymentInfo.payChannelType == 2) && paymentInfo.payStatus == 2 && paymentInfo.isPenddingOvertime") {{ $trans('order.pending_tip') }}

            //- 线下支付提示语
            p.payment_lineTip(v-if="paymentInfo.payChannelType == 1") {{ $trans('order.payment_line_tip_text') }}

            //- 订单取消提示语
            p.payment_cancleTip(v-if="paymentInfo.isCancelled")
                span(v-if="paymentInfo.payStatus == 1")
                    | {{ $trans('order.payment_cancelled_tip') }}
                span(v-else-if="paymentInfo.payStatus == 2 && paymentInfo.payChannelType == 1")
                    | {{ $trans('order.payment_cancelled_tip') }}

            .payment_borderBox(v-if="paymentInfo.payChannelType == 1")
                //- 区分支付方式展示不同提示语 (智利：EBX_SVPG  阿根廷：EBX_AGPC)
                p.payment_lineTip.nopad(v-if="paymentInfo.payChannelCode === 'EBX_SVPG'")
                    | {{ $trans('order.payment_offline_zl_tip') }}
                p.payment_lineTip.nopad(v-else-if="paymentInfo.payChannelCode === 'EBX_AGPC'")
                    | {{ $trans('order.payment_offline_agt_tip') }}
                p.payment_lineTip.nopad(v-else)
                    | {{ $trans('order.payment_line_tip_content') }}
                //- 印尼ADN_IDATM（Indonesia ATM）、ADN_IDACS（Alfamart） 补充提示语
                p.payment_lineTip.nopad(v-if="['ADN_IDATM', 'ADN_IDACS'].includes(paymentInfo.payChannelCode)") {{ $trans('order.payment_offline_in_tip') }}
            
            .payment_borderBox
                p.payment_toMessenger
                    span {{ $trans('order.payment_click_to_mes') }}
                    a(:href="goToMessenger")
                        i.icon-msg
                        | {{ $trans('order.payment_to_messenger') }}

            //- 支付成功后置功能（后置礼包 || banner） --- 线上支付成功
            .payment_borderBox(v-if="afterInfo.type")
                //- 抽奖
                .payment_giftBox(v-if="afterInfo.type == 'giftBag'")
                    .payment_giftImg(v-finger:tap="giftGame")
                        img(:src="afterInfo.bannerImage")

                    .payment_giftNote
                        .payment_noteBtn(v-finger:tap="changeNoteFlag")
                            p {{ $trans('order.payment_special_notes') }}
                            p(v-if="!noteFlag")
                                i.payment_noteBtn-icon.icon-arrow_down
                            p(v-if="noteFlag")
                                i.payment_noteBtn-icon.up.icon-arrow_down

                        .payment_noteCon(:class="{'active': noteFlag}" v-html="afterInfo.ruleDesc")

                //- banner 图
                a.payment_banner(v-else-if="afterInfo.type == 'banner'" :href="afterInfo.bannerLink" title="" v-finger:tap="isOpenApp")
                    img(:src="afterInfo.bannerUrl")
</template>

<script>

    import { servicePaymetResultsGiftNum, servicePaymetResultsGift } from 'js/service/paycart';
    import { toAppLink } from 'js/utils/appMethod.js';
    import giftsuccess from './gift_success.vue';
    import bankinfo from './bank_info.vue';

    import quickbuy from './quick_buy.vue';

    const win = window;

    export default {
        components: {
            quickbuy
        },
        data() {
            /* eslint-disable */
            return {
                isShowQuickBuy: false, // 是否展示 快捷购物 - 支付结果页
                quickBuyInfo: {}, // 快捷购物 依赖数据

                continueToPayment: '',      // 去支付平台链接
                goToMessenger: win.GLOBAL.MESSENGER_URL,
                paymentInfo: null,          // 支付结果信息
                gcShowSpecialid: [],        // GC银行specialid字段展示数据

                onlineBtn: {
                    src: '',
                    txt: '',
                    flag: false,
                },

                afterInfo: {}, // 线上支付成功后置信息接口
                noteFlag: false, // 后置礼包收缩标识
            }
            /* eslint-enable */
        },
        methods: {
            changeNoteFlag() { // 收放notes
                const vm = this;
                vm.noteFlag = !vm.noteFlag;
            },
            jugeBtn() { // 判断支付按钮显示情况
                const vm = this;
                if (
                    vm.paymentInfo.payChannelCode === 'OXXO'
                    ||
                    vm.paymentInfo.payChannelCode === 'BOLETO'
                    ||
                    vm.paymentInfo.payChannelCode === 'PagoEfectivo'
                    ||
                    vm.paymentInfo.payChannelCode === 'EBX_AGPC'
                ) { // 支付方式为 oxxo或boleto或PagoEfectivo时
                    vm.onlineBtn.src = vm.paymentInfo.ebanxUrl;
                    vm.onlineBtn.txt = `${vm.$trans('order.payment_print')} ${vm.paymentInfo.payChannelName} ${vm.$trans('order.payment_info')}`;
                } else if (
                    vm.paymentInfo.payChannelCode === 'BankTransfer'
                    ||
                    vm.paymentInfo.payChannelCode === 'ADN_PTMB'
                    ||
                    vm.paymentInfo.payChannelCode === 'BANK_TRANSFER'
                ) { // 支付方式为GC 银行付款时
                    vm.onlineBtn.txt = vm.$trans('order.payment_bank_btn', [vm.paymentInfo.payChannelName]);
                    vm.onlineBtn.src = 'javascript:;';
                    vm.onlineBtn.flag = true;
                } else if (vm.paymentInfo.payChannelType === 1) {
                    vm.onlineBtn.txt = vm.$trans('order.payment_contact_us');
                    vm.onlineBtn.src = `${GLOBAL.DOMAIN_MAIN}/about/contact-us`;
                } else {
                    vm.onlineBtn.txt = vm.$trans('order.payment_check_my_order');
                    vm.onlineBtn.src = `${GLOBAL.DOMAIN_USER}/index#/order/detail?sn=${vm.paymentInfo.parentOrderSn}`;
                }
            },
            openBankInfo() { // 弹窗收款账户信息
                const vm = this;
                if (vm.onlineBtn.flag) {
                    if (vm.paymentInfo.payChannelCode === 'BANK_TRANSFER') {
                        vm.$confirm({
                            title: '',
                            customClass: 'giftalert',
                            component: bankinfo,
                            componentData: {
                                payChannelCode: vm.paymentInfo.payChannelCode,
                                paymentInfo: vm.paymentInfo
                            },
                        });
                    } else {
                        vm.$confirm({
                            title: '',
                            customClass: 'giftalert',
                            component: bankinfo,
                            componentData: {
                                bankInfo: vm.paymentInfo.bankTransferAccount,
                                gcShowSpecialid: vm.gcShowSpecialid,
                                multibancoInfo: vm.paymentInfo.multibancoInfo,
                                payChannelCode: vm.paymentInfo.payChannelCode,
                                paymentInfo: vm.paymentInfo
                            },
                        });
                    }
                }
            },
            isOpenApp() { // 判断链接是否调整app
                toAppLink(() => {
                    win.location.href = `${GLOBAL.DOMAIN_MAIN}/spread-app.html`;
                });
            },
            // ----- 请求接口 -----
            async getGiftNum() {
                const vm = this;
                const responseGiftNum = await servicePaymetResultsGiftNum.http({
                    data: {
                        orderSn: vm.paymentInfo.parentOrderSn
                    }
                });

                if (responseGiftNum.status === 0 && responseGiftNum.data.type) {
                    vm.afterInfo = responseGiftNum.data;
                }
            },
            async giftGame() {
                const vm = this;
                const resultGiftData = await servicePaymetResultsGift.http({
                    data: {
                        activityId: vm.afterInfo.activityId
                    }
                });

                if (resultGiftData.status === 0) {
                    vm.$confirm({
                        title: '',
                        customClass: 'giftalert',
                        component: giftsuccess,
                        componentData: {
                            giftData: resultGiftData.data
                        },
                    });
                }
            }
        },
        created() {
            const vm = this;
            // 移除根组件下的 loading
            vm.$root.$children[0].show();
            vm.paymentInfo = win.payVars.payInfo;

            if (+win.payVars.step === 31) { // 访客模式特殊路由进入
                vm.quickBuyInfo.visitorPaySuceess = true;
                vm.quickBuyInfo.orderInfo = {
                    orderSn: vm.paymentInfo.orderSn,
                    orderAmountText: vm.paymentInfo.orderAmountText,
                };
            } else {
                // 单独瓶接字段
                vm.paymentInfo.orderAmountText = vm.paymentInfo.currencyPosition ? vm.paymentInfo.payCurrencyAmount + vm.paymentInfo.currencySign : vm.paymentInfo.currencySign + vm.paymentInfo.payCurrencyAmount; // eslint-disable-line

                vm.quickBuyInfo.visitorPaySuceess = +vm.paymentInfo.payStatus === 1;
                vm.quickBuyInfo.orderInfo = {
                    orderSn: vm.paymentInfo.parentOrderSn,
                    orderAmountText: vm.paymentInfo.orderAmountText,
                };
            }

            if (win.payVars.isVisitor && vm.quickBuyInfo.visitorPaySuceess) { // 访客模式 并且 支付状态为成功时
                vm.quickBuyInfo.visitorInfo = win.payVars.visitorInfo;
                vm.isShowQuickBuy = true;
            } else {
                // 保存去支付平台的链接
                vm.continueToPayment = `${GLOBAL.DOMAIN_ORDER}/payment?parentOrderSn=${vm.paymentInfo.parentOrderSn}`;

                vm.jugeBtn();
                if ((+vm.paymentInfo.payChannelType === 0 || +vm.paymentInfo.payChannelType === 2) && +vm.paymentInfo.payStatus === 1) {
                    vm.getGiftNum();
                }

                // GC银行展示信息特殊字段处理
                if (vm.paymentInfo.bankTransferAccount.specialid) {
                    const specialidArry = vm.paymentInfo.bankTransferAccount.specialid.split('||');
                    specialidArry.forEach((item) => {
                        const itemArr = item.split('|');
                        vm.gcShowSpecialid.push(itemArr);
                    });
                }
            }
        }
    };
</script>

<style>
@import 'pages/paycart/component/payment_results/payment_results.css';
</style>
