<template lang="pug">
//- 购物车列表
.cartlist

    //- 购物车为空
    .cart_empty(v-if="nogoods == 2")
        nav#cart_nav.cart_nav.whitebg
            span.back(v-finger:tap="backPrevOrHome")
                i.icon-back
            h1.font-36 {{ $trans('cart.nav_cart') }}
        p.cart_emptyTxt.font-28 {{$trans('cart.shopping_cart_empty')}}
        .recommend_goods
            h3.font-32 {{ $trans('cart.cart_daily_recommends') }}
            .cart_daily
                a.cc(:href="vueGlobal.payVars.couponCenter") {{ $trans('cart.cart_coupon_center') }}
                a.fs(:href="vueGlobal.payVars.flashSale") {{ $trans('cart.cart_flash_sale') }}

            recommendList(v-show="recommendGoods.length", :recommendList="recommendGoods")
                a.btn.middle.cart_btn.font-32(:href="vueGlobal.payVars.index") {{ $trans('cart.go_shopping') }}

    //- 有商品
    .cart_table(v-if="nogoods == 0", :class="{'discountTipsCont': showDiscountTip && payDiscountInfo.length}")
        //- 购物车导航
        nav#cart_nav.cart_nav.whitebg
            span.back(v-finger:tap="backPrevOrHome")
                i.icon-back
            h1.font-36 {{ $trans('cart.nav_cart') }}
            span.btn_edit(:class="{'editAll': allEditChecked}", v-show="nogoods == 0")
                i.icon-edit(v-finger:tap="editMode")
                i.icon-complete(v-finger:tap="exitEdit")

        nav.cart_discount(v-if="showDiscountTip && payDiscountInfo.length")
            h1.font-28 {{ payDiscountInfo[0] }}
            i.icon-closed.font-28(@click="closeDiscountTip")

        //- 商品列表
        .cart_group(v-for="(group, idx) in groupList", :key="idx", :class="{'expired_group': group[0] && !group[0].$feActInfo && group[0].$feExpired}")
            //- 活动信息 || 主配件
            .cart_groupInfo.act_groupInfo(v-if="group[0] && group[0].$feActInfo && group[0].$feActInfo.groupType > 0")

                .act_block
                    //- 活动标签
                    compCheckbox(v-show="!allEditChecked", :label="group[0].$feActInfo.groupType === 2 ? $trans('cart.buy_together') : ''", :checked="group[0].$feActInfo.isSelected", :checkId="group[0].$feGroupIndex", :checkData="{groupType: group[0].$feActInfo.groupType}", :eventName="'cartlistSelected'")
                    editCheckbox(v-show="allEditChecked", :checkType="'group'", :label="group[0].$feActInfo.groupType === 2 ? $trans('cart.buy_together') : ''", :checked="group[0].$feActInfo.$feGroupEditChecked", :checkId="group[0].$feGroupIndex + ''", :checkData="{groupType: group[0].$feActInfo.groupType}", :eventName="'batchSelect'")
                    .cart_acts(v-if="group[0].$feActInfo.groupType === 1")
                        //- 活动标签
                        p.cart_actlabel(v-if="group[0].$feActInfo.activity ? group[0].$feActInfo.activity.activityName: ''") {{ group[0].$feActInfo.activity ? group[0].$feActInfo.activity.activityName: '' }}
                        i.icon-shops(v-if="group[0].$feActInfo.isAcrossShop")

                        //- 返券提示文案
                        .cart_actdesc(v-if="group[0].$feActInfo.returnCoupon && group[0].$feActInfo.returnCoupon.length")
                            p.cart_actdescs(v-html="returnCouponRule(group[0].$feActInfo.returnCoupon)")

                        //- 满减活动
                        a.cart_actdesc(v-if="group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.activity.activityType == 1", :href='group[0].$feActInfo.url')
                            p.cart_actdescs {{group[0].$feActInfo.isJoined ? $trans('cart.act_rule_mj_y', currencyChange(currency, [group[0].$feActInfo.activity.matchedRule.meetAmount, group[0].$feActInfo.activity.matchedRule.preferentialValue])) : $trans('cart.act_rule_mj_n', currencyChange(currency, [(group[0].$feActInfo.activity.matchedRule.meetAmount - group[0].$feActInfo.actMergeAmount), group[0].$feActInfo.activity.matchedRule.preferentialValue]))}}
                            i.icon-arrow_tiny

                        //- m元n件
                        a.cart_actdesc(v-if='group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.activity.activityType == 6', :href="group[0].$feActInfo.url")
                            p.cart_actdescs {{group[0].$feActInfo.isJoined ? $trans('cart.act_rule_mn_y', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), group[0].$feActInfo.activity.matchedRule.meetQty, currencyChange(currency,group[0].$feActInfo.actSave)]): $trans('cart.act_rule_mn_n', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), group[0].$feActInfo.activity.matchedRule.meetQty, group[0].$feActInfo.activity.matchedRule.meetQty - group[0].$feActInfo.groupSelectNum]) }}
                            i.icon-arrow_tiny

                        //-满赠
                        a.cart_actdesc(v-if="group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.activity.activityType == 2", :href="group[0].$feActInfo.url")
                            p.cart_actdescs {{group[0].$feActInfo.isJoined ? $trans('cart.act_rule_mz_y', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), group[0].$feActInfo.activity.maxGiftCount]) : $trans('cart.act_rule_mz_n', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), group[0].$feActInfo.activity.maxGiftCount])}}
                            i.icon-arrow_tiny

                        //- 加价购
                        a.cart_actdesc(v-if="group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.activity.activityType == 4", :href="group[0].$feActInfo.url")
                            p.cart_actdescs {{ group[0].$feActInfo.isJoined? $trans('cart.act_rule_jjg_y', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), group[0].$feActInfo.activity.maxGiftCount]): $trans('cart.act_rule_jjg_n', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount - group[0].$feActInfo.actMergeAmount), group[0].$feActInfo.activity.maxGiftCount])}}
                            i.icon-arrow_tiny

                        //- 买即赠
                        .cart_actdesc(v-if='group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.activity.activityType == 5 && group[0].$feActInfo.text')
                            p.cart_actdescs {{ group[0].$feActInfo.text}}

                        //- M件Y折
                        a.cart_actdesc(v-if='group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.activity.activityType === 8', :href="group[0].$feActInfo.url")
                            p.cart_actdescs(v-if='group[0].$feActInfo.isJoined')
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 0") {{ group[0].$feActInfo.text }}, {{ $trans('cart.njy_qualified', [group[0].$feActInfo.activity.matchedRule.meetQty]) }}, {{ $trans('cart.nyj_buy_now') }}
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 1") {{$trans('cart.act_rule_mnm_y', [group[0].$feActInfo.activity.matchedRule.meetQty, `${group[0].$feActInfo.activity.matchedRule.preferentialValue * 100}%`, group[0].$feActInfo.activity.matchedRule.meetQty ]) }}
                            p.cart_actdescs(v-else)
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 0") {{ group[0].$feActInfo.text }}, {{ $trans('cart.add_more_items') }}
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 1") {{$trans('cart.act_rule_mnm_n', [group[0].$feActInfo.activity.matchedRule.meetQty - group[0].$feActInfo.groupSelectNum, `${group[0].$feActInfo.activity.matchedRule.preferentialValue * 100}%` ]) }}
                            i.icon-arrow_tiny


                        //- 满额减免折扣
                        a.cart_actdesc(v-if='group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.activity.activityType === 9', :href="group[0].$feActInfo.url")
                            p.cart_actdescs(v-if='group[0].$feActInfo.isJoined')
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 0") {{$trans('cart.act_rule_fm_y', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), currencyChange(currency, group[0].$feActInfo.activity.matchedRule.preferentialValue), currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount) ]) }}
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 1") {{$trans('cart.act_rule_fm_y', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), `${group[0].$feActInfo.activity.matchedRule.preferentialValue * 100}%`, currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount) ]) }}
                            p.cart_actdescs(v-else)
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 0") {{$trans('cart.act_rule_fm_n', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), currencyChange(currency, group[0].$feActInfo.activity.matchedRule.preferentialValue) ]) }}
                                span(v-if="group[0].$feActInfo.activity.matchedRule.preferentialType === 1") {{$trans('cart.act_rule_fm_n', [currencyChange(currency, group[0].$feActInfo.activity.matchedRule.meetAmount), `${group[0].$feActInfo.activity.matchedRule.preferentialValue * 100}%` ]) }}
                            i.icon-arrow_right

                p.cart_actbtns(v-if="group[0] && group[0].$feActInfo.returnCoupon.length === 0 && group[0].$feActInfo.isJoined && (group[0].$feActInfo.activity.activityType === 2 || group[0].$feActInfo.activity.activityType === 4)")
                    //- 选择加价购商品
                    span.cart_actbtn(v-finger:tap="checkGift.bind(this, group, group[0].$feActInfo, group[0].$feActInfo.activity.activityId)") {{ $trans('cart.items_redeemed') }}

            //- 无活动 && 无主配件 店铺信息
            .cart_groupInfo.car_noAcMainGroup(v-else-if="group[0] && !group[0].$feActInfo && !group[0].$feExpired")
                compCheckbox(v-show="!allEditChecked", :checked="group[0].$feShopInfo ? group[0].$feShopInfo.isSelected : 0", :checkData="{groupType: 0}", :checkId="group[0].$feGroupIndex + '_' + group[0].shopCode", :eventName="'cartlistSelected'")
                editCheckbox(v-show="allEditChecked", :checkType="'shop'", :checked="group[0].$feShopInfo ? group[0].$feShopInfo.$feGroupEditChecked : 0", :checkId="group[0].$feGroupIndex + ''", :eventName="'batchSelect'")
                i.icon-store_gb(v-if="group[0].shopType === 1")
                i.icon-store(v-else)
                a.cart_shoptitle(v-if="group[0] && group[0].$feShopInfo.isShow", :href="group[0].$feShopInfo.shopUrl") {{ group[0].$feShopInfo.shopName }}
                    i.icon-arrow_tiny
                span.cart_shoptitle(v-else) {{ group[0] ? group[0].$feShopInfo.shopName : '' }}
                span.cart_coupon(v-if="group[0] && group[0].$feShopInfo.couponList && group[0].$feShopInfo.couponList.length", v-finger:tap="getCouponList.bind(this, group[0].$feShopInfo.couponList)") {{ $trans('cart.shop_coupon') }}

            //- 失效分组
            .cart_groupInfo.car_noAcMainGroup(v-else-if="group[0] && !group[0].$feActInfo && group[0].$feExpired") {{ group[0].$feExpiredLable }}({{unValidGoodsNum}})
                i.clear_expried.icon-delete_tiny(v-finger:tap="toDelGoods.bind(this, 'expried')")

            //- 商品列表
            .cart_goodsList
                goodsgroup(v-for="(goods, key) in group", :goods="goods", :key="key",:groupsType="group[0] && group[0].$feActInfo ? group[0].$feActInfo.groupType : -1", :allEditChecked.sync="allEditChecked", :parentData="parentData(goods.goodType === 1 ? goods.$feMainPartsId : '')", :actInfo="group[0] ? group[0].$feActInfo : {}")

        //- 总计
        .cart_form-subtotal.font-32(:class="{'shift': allEditChecked}")
            i.batch_act
            p.cart_total {{ $trans('cart.cart_subtotal') }}
                strong {{currency | $remainder_sum({ prices: selectedTotal.amount, discounts: selectedTotal.discount, orig: total.settleAmount })}}

            //- 支付按钮
            .cart_checkout
                a.checkout(href="javascript:;", v-finger:tap="checkout.bind(this, 'checkout')") {{ $trans('cart.to_checkout') }}

                .cart_quickPay
                    a.quickPay(href="javascript:;", v-for="(qpmItem, qpmIndex) in expressChannels", v-finger:tap="checkout.bind(this, qpmItem.payChannel)", :class="{'oneBtn' : qpmIndex == 0}")
                        //- img(v-if="qpmItem.payChannel === 'PP_Credit_E'", :src="PP_Credit_E")
                        img(v-if="qpmItem.payChannel === 'PP_Express'", :src="pp_Express")
                    a.quickPay.oneBtn(href="javascript:;", v-show="expressChannels.length <= 0")
                        img(:src="pp_Express")

        //- 批量编辑
        .cart_editbar.font-30(:class="{'editAll': allEditChecked}")
            editCheckbox(:label="$trans('cart.all')", :checkType="'all'", :checked="batchItems.$feEditChecked", :checkId="'all'")
            span.editbarbtn(v-finger:tap="wishlist")
                i {{ $trans('cart.oper_wishlist') }}
            span.editbarbtn.editbar_del(v-finger:tap="toDelGoods.bind(this, 'editMode')")
                i {{ $trans('cart.oper_del') }}

    .recommend_goods
        recommendList(v-if="nogoods == 0 && recommendGoods.length > 0", :recommendList="recommendGoods")
</template>

<script>

    import {
        serviceCartList,
        serviceCartChange,
        serviceCartSelect,
        serviceCartGift,
        serviceCartDelete,
        serviceCartCoupon,
        serviceShipCheck,
        serviceCartSaveActs,
        serviceGetCategoryInfo,
        serviceCartPayrelate,
        serviceCartSendQuickPay
    } from 'js/service/paycart';
    import {
        serviceAddToCart,
        serviceCollectAdd,
    } from 'js/service/common.js';
    import Cookies from 'js/utils/cookie';
    import { COOKIE_UID } from 'js/variables';
    import { getULike } from 'js/service/other';
    import { Paycart, RULES } from 'js/track/define/paycart'; // 埋点js
    import backPrevOrHome from 'js/core/backPrevOrHome';
    import compCheckbox from '../paycart_checkbox.vue';
    import editCheckbox from './edit_checkbox.vue';
    import recommendList from '../recommend.vue';
    import goodsgroup from './goodsgroup.vue';

    const coupons = () => import('./coupons.vue');
    const checkgift = () => import('./checkgift.vue');
    const win = window;

    export default {
        /* eslint-disable */
        data() {
            return {
                nogoods: 1,                                 // 购物车为空
                recommendGoods: [],                         // 推荐位商品
                loading: false,                             // loading 动画
                allEditChecked: false,                      // 底部全选悬浮按钮
                batchItems: {                               // 编辑状态批量选中
                    $feEditChecked: false,
                    list: []
                },
                $actInf: {},                                // 活动信息
                $shopInf: {},                               // 店铺信息
                selectAll: 0,                               // 是否全选
                groupList: {},                              // 商品列表
                paypalStatus: {},                           // PayPal支付
                total: {                                    // 价格总计
                    goodsAmount: 0,
                    settleAmount: 0,
                    discountAmount: 0,
                },
                payDiscountInfo: [],
                unValidGoodsNum: 0,
                expressChannels: [],                        // 过滤后快捷支付方式
                deExpressChannels: [],                      // 接口获取到的快捷支付方式
                selectedTotal: {
                    floorPrice: {},                         // 减免字段
                    discount: [],                           // 仓库勾选商品优惠
                    amount: [],                             // 勾选商品单价数组
                },
                cormatCouponData: {},                       // 返券数据暂存数据
                showDiscountTip: 1,                         // 是否显示折扣提示
                temp: {
                    total: {
                        discountInfo: ['st 2800 Newcomers Daily Get $50-$5 on PayPal']
                    }
                },

                PP_Credit_E: '',                            // 快捷支付图标占位
                pp_Express: '',                             // 快捷支付图标占位
            };
        },
        /* eslint-enable */
        components: {
            compCheckbox,
            recommendList,
            editCheckbox,
            goodsgroup,
            coupons,
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            },
        },
        created() {
            const vm = this;
            Object.assign(vm, {
                backPrevOrHome,
                shipCheckIds: {},
            });

            // 默认请求购物车列表
            vm.getCartList('init');

            // 底部悬浮全选/取消选中按钮
            vm.$bus.$on('checkAllEdit', (data) => {
                vm.selectGoods(data);
            });

            // 刷新购物车列表
            vm.$bus.$on('getCartList', (data) => {
                vm.getCartList(data);
            });

            // 变更商品参与活动
            vm.$bus.$on('changeGoodsAct', (data) => {
                vm.changeGoodsAct(data);
            });

            // 加入购物车
            vm.$bus.$on('addtoCart', (data) => {
                vm.addtoCart(data);
            });

            // 收藏商品
            /* vm.$bus.$on('goodsFavor', (data) => {
                vm.favorGoods(data);
            }); */

            // 勾选商品
            vm.$bus.$on('cartlistSelected', (data) => {
                vm.selectGoods(data);
            });

            // 删除商品弹窗
            vm.$bus.$on('delDialog', (data) => {
                vm.toDelGoods(data);
            });
            // 确认删除
            vm.$bus.$on('deleteGoods', (data) => {
                vm.deleteGoods(data);
            });
            // 编辑状态
            vm.$bus.$on('batchSelect', (data) => {
                vm.batchSelect(data);
            });

            // 监听 onload
            vm.onloadLock = false;
            win.addEventListener('load', () => {
                vm.onload();
            }, false);
            setTimeout(() => {
                vm.onload();
            }, 5000);

            this.getPayRelate();
        },
        methods: {
            // 显示 toast 弹窗
            showToast(msg) {
                this.$toast({ msg });
            },
            // 获取购物车列表
            async getCartList(argv) {
                const vm = this;
                const { DOMAIN_CART } = GLOBAL;
                const { status, data, msg } = await serviceCartList.http({
                    url: `${DOMAIN_CART}/cart/list?t=${+new Date()}`,
                }).catch(() => {
                    // 移除根组件下的 loading
                    if (argv === 'init') {
                        vm.$root.$children[0].show();
                    }
                    // 自动关闭弹窗
                    if (argv && argv.$dialog) {
                        argv.$dialog.close();
                    }
                    vm.nogoods = 2;
                    return false;
                });

                // 移除根组件下的 loading
                if (argv === 'init') {
                    vm.$root.$children[0].show();
                }

                if (status === 0) {
                    // 自动关闭弹窗
                    if (argv && argv.$dialog) {
                        argv.$dialog.close();
                    }

                    if (data && data.groupList.length) {
                        // 有商品
                        vm.nogoods = 0;
                        $('body').addClass('hasPad-b');

                        vm.dataTransform(data);

                        // 组装埋点数据
                        vm.trackData(argv);

                    } else {
                        vm.nogoods = 2;
                        // 关闭底部操作栏
                        vm.allEditChecked = false;
                        vm.trackLog(argv); // 埋点js
                    }
                } else {
                    // 无商品
                    vm.nogoods = 2;
                    // 关闭底部操作栏
                    vm.allEditChecked = false;
                    vm.showToast(msg);
                    vm.trackLog(argv); // 埋点js
                }
            },
            dataTransform(argv) {
                const vm = this;
                const tempList = {};
                let groupIndex = -1;
                const {
                    groupList,
                    cdnCountryCode,
                    unValidGoodsList,
                    hasLimitGoods,
                    total,
                } = argv;

                // 如果变量名有$符要在此定义，否则报错
                Object.assign(vm, {
                    hasLimitGoods,
                    $shopInf: {},
                    $actInf: {},
                    $mainParts: {},
                    total,
                });

                vm.groupList = {};
                groupList.forEach((group, togGroupIndex) => {
                    const { groupInfo, shopList } = group;
                    let groupSelectNum = 0;
                    let mainPartsId = null;
                    shopList.forEach((shop) => {
                        const { goodsList, shopInfo } = shop;
                        let index = 0;
                        goodsList.forEach((goods) => {
                            const { activityId, shopCode } = goods;
                            const { groupType } = groupInfo;
                            let key = '';
                            if (goods.isSelected) {
                                groupSelectNum += goods.goodSnQty;
                            }
                            groupInfo.groupSelectNum = groupSelectNum;

                            if (groupType === 1) {
                                // 活动组
                                key = `${groupType}_${activityId}`;
                                const shopKey = `${key}_${shopCode}`;

                                if (!vm.$actInf[shopKey] || !vm.$actInf[shopKey].$ferender) {
                                    // 存储活动信息(切断数据响应)
                                    const $groupInfo = JSON.parse(JSON.stringify(groupInfo));
                                    vm.$actInf[key] = $groupInfo;
                                    vm.$actInf[shopKey] = $groupInfo;
                                    vm.$actInf[shopKey].$ferender = 1;
                                    goods.$feActInfo = $groupInfo;
                                }

                            } else if (groupType === 2) {
                                // 主配件
                                key = `${togGroupIndex}_${groupType}`;
                                const shopKey = `${key}_${shopCode}`;

                                if (!vm.$actInf[shopKey] || !vm.$actInf[shopKey].$ferender) {
                                    // 存储活动信息(切断数据响应)
                                    const $groupInfo = JSON.parse(JSON.stringify(groupInfo));
                                    vm.$actInf[key] = $groupInfo;
                                    vm.$actInf[shopKey] = $groupInfo;
                                    vm.$actInf[shopKey].$ferender = 1;
                                    goods.$feActInfo = $groupInfo;
                                }
                            } else {
                                // 普通商品
                                key = `${groupType}_${shopCode}`;
                                // 存储店铺信息
                                vm.$shopInf[key] = shopInfo || {};
                                if (!vm.$shopInf[key].$ferender) {
                                    vm.$shopInf[key].$ferender = 1;
                                    vm.$shopInf[key].shopCode = shopCode;
                                }
                            }


                            if (!tempList[key]) {
                                groupIndex += 1;
                                tempList[key] = 1;
                                vm.$set(vm.groupList, groupIndex, []);
                            }

                            // 配件添加主件标识
                            if (goods.goodType === 1) {
                                const mainIndex = vm.groupList[groupIndex].length - 1;
                                if (vm.groupList[groupIndex][mainIndex].goodType !== 1) {
                                    vm.groupList[groupIndex][mainIndex].isMainAndAccessory = 1;
                                    mainPartsId = vm.groupList[groupIndex][mainIndex].itemId;
                                    const mainKey = `${key}_${vm.groupList[groupIndex][mainIndex].itemId}`;
                                    if (!vm.$mainParts[mainKey]) {
                                        vm.$mainParts[mainKey] = vm.groupList[groupIndex][mainIndex];
                                    }
                                }
                                goods.isMainAndAccessory = 1;
                                goods.$feMainPartsId = mainPartsId;
                            }

                            Object.assign(goods, {
                                $fekey: key,
                                $feIndex: index, // 店铺维度下商品的下标
                                $feShopInfo: shopInfo,
                                $feShopName: shopInfo.shopName,
                                $feGroupIndex: groupIndex, // 组下标
                                $feGroupType: groupType,
                            });

                            if (goods.$feShopInfo) {
                                // 店铺返券按钮 // 防止闪烁
                                const couponList = vm.cormatCouponData[goods.shopCode];
                                if (couponList && couponList.length) {
                                    goods.$feShopInfo.couponList = couponList;
                                }
                            }

                            index += 1;

                            // 存储商品列表
                            vm.groupList[groupIndex].push(goods);

                            // 存储配件
                            const accesses = goods.accessoryList;
                            if (accesses.length) {
                                accesses.forEach((access) => {
                                    Object.assign(access, {
                                        $fekey: key,
                                        $feIndex: index, // 店铺维度下商品的下标
                                        $feShopInfo: shopInfo,
                                        $feShopName: shopInfo.shopName,
                                        $feGroupIndex: groupIndex, // 组下标
                                        $feGroupType: groupType,
                                    });
                                    if (access.isSelected) {
                                        groupSelectNum += access.goodSnQty;
                                    }
                                    groupInfo.groupSelectNum = groupSelectNum;

                                    // 配件添加主件标识
                                    const mainIndex = vm.groupList[groupIndex].length - 1;
                                    if (vm.groupList[groupIndex][mainIndex].goodType === 0) {
                                        vm.groupList[groupIndex][mainIndex].isMainAndAccessory = 1;
                                        mainPartsId = vm.groupList[groupIndex][mainIndex].itemId;
                                        const mainKey = `${key}_${vm.groupList[groupIndex][mainIndex].itemId}`;
                                        if (!vm.$mainParts[mainKey]) {
                                            vm.$mainParts[mainKey] = vm.groupList[groupIndex][mainIndex];
                                        }
                                    }
                                    access.isMainAndAccessory = 1;
                                    access.$feMainPartsId = mainPartsId;

                                    vm.groupList[groupIndex].push(access);

                                    index += 1;
                                });
                            }

                        });
                    });
                });

                // 失效分组添加复选框
                const expiredGroup = groupIndex + 1;
                if (unValidGoodsList.length) {
                    vm.unValidGoodsNum = unValidGoodsList.length;
                    unValidGoodsList[0].$feGroupIndex = expiredGroup;
                    unValidGoodsList[0].$feExpiredLable = vm.$trans('cart.unavailable');
                    unValidGoodsList.forEach((goods) => {
                        goods.$feExpired = 1;
                    });

                    // 合并失效分组
                    vm.$set(vm.groupList, expiredGroup, unValidGoodsList);
                }

                vm.PayRelate({
                    cdnCountryCode,
                    hasLimitGoods,
                    settleAmount: total.settleAmount
                });
            },
            // 设置并获取选中商品 id
            setSelectedId(argv, datafilter = { event: 'delete' }) {
                const vm = this;
                const itemIds = [];
                const { event } = datafilter;
                const {
                    checkId,
                    checkData,
                    checked,
                } = argv;
                const idxs = checkId !== undefined ? String(checkId).split('_') : [];
                const selectGroup = vm.groupList[idxs[0]];
                const { itemId, goodsType } = checkData || {};

                if (itemId) {
                    // 单个id
                    if (goodsType === 1) {
                        const goodSeleList = {};
                        let mainPartsId = '';
                        selectGroup.forEach((goods, index) => {
                            goodSeleList[goods.itemId] = goods.isSelected;
                            if (goods.itemId === itemId) {
                                mainPartsId = goods.$feMainPartsId;
                            }
                        });
                        if (goodSeleList[mainPartsId] === 0) {
                            return vm.$toast({ msg: vm.$trans('cart.check_main_first') });
                        }
                    }

                    itemIds.push(itemId);
                    selectGroup.forEach((goods, index) => {
                        if (goods.itemId === itemId) {
                            goods.isSelected = checked;
                            vm.$set(vm.groupList[idxs[0]], index, goods);
                        }
                    });

                } else if (idxs[0] === 'all') {
                    // 全选
                    vm.selectAll = checked;
                    for (const key in vm.groupList) {
                        const group = vm.groupList[key];
                        group.forEach((goods, index) => {
                            goods.isSelected = checked;
                            if (event === 'favor') {
                                itemIds.push(`${goods.goodSn}_${goods.warehouseCode}`);
                            } else {
                                itemIds.push(goods.itemId);
                            }

                            if (goods.$feShopInfo) {
                                goods.$feShopInfo.isSelected = checked;
                            }

                            vm.$set(vm.groupList[key], index, goods);
                        });
                    }

                } else if (idxs.length === 1) {
                    // 活动组
                    console.log('活动组');
                    selectGroup.forEach((goods, index) => {
                        goods.isSelected = checked;
                        if (event === 'favor') {
                            itemIds.push(`${goods.goodSn}_${goods.warehouseCode}`);
                        } else {
                            itemIds.push(goods.itemId);
                        }

                        if (goods.$feShopInfo) {
                            goods.$feShopInfo.isSelected = checked;
                        }

                        if (goods.$feActInfo) {
                            goods.$feActInfo.isSelected = checked;
                        }

                        vm.$set(vm.groupList[idxs[0]], index, goods);
                    });

                } else {
                    // 店铺组
                    console.log('店铺组');
                    const shopCode = idxs[1];
                    // if (goodsType === 1 && checked === 1) {
                    //     const goodSeleList = {};
                    //     let mainPartsId = '';
                    //     selectGroup.forEach((goods, index) => {
                    //         goodSeleList[goods.itemId] = goods.isSelected;
                    //         if (goods.shopCode === shopCode && !mainPartsId) {
                    //             mainPartsId = goods.$feMainPartsId;
                    //         }
                    //     });
                    //     if (goodSeleList[mainPartsId] === 0) {
                    //         return vm.$toast({ msg: vm.$trans('cart.check_main_first') });
                    //     }
                    // }
                    selectGroup.forEach((goods, index) => {
                        if (goods.shopCode === shopCode) {

                            goods.isSelected = checked;
                            if (event === 'favor') {
                                itemIds.push(`${goods.goodSn}_${goods.warehouseCode}`);
                            } else {
                                itemIds.push(goods.itemId);
                            }

                            if (goods.$feShopInfo) {
                                goods.$feShopInfo.isSelected = checked;
                            }

                            vm.$set(vm.groupList[idxs[0]], index, goods);
                        }
                    });
                }

                if (itemIds.length === 0) {
                    vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
                return itemIds;
            },
            // 获取已勾选商品
            getSelectedId(argv, event = 'favor') {
                const vm = this;
                const itemIds = [];
                const { itemId } = argv;

                if (argv === 'expried') {
                    // 清空失效组
                    const length = Object.keys(vm.groupList).length - 1;
                    const expiredGroup = vm.groupList[length];
                    expiredGroup.forEach((goods) => {
                        itemIds.push(goods.itemId);
                    });
                } else if (itemId) {
                    // 单个id
                    itemIds.push(itemId);
                } else {
                    // 多个id
                    for (const key in vm.groupList) {
                        const group = vm.groupList[key];

                        for (let index = 0, length = group.length; index < length; index += 1) {
                            const goods = group[index];
                            if (goods.isSelected) {
                                if (event === 'favor') {
                                    itemIds.push(`${goods.goodSn}_${goods.warehouseCode}`);
                                } else {
                                    itemIds.push(goods.itemId);
                                }
                            }
                        }
                    }
                }

                return itemIds;
            },
            trackData(argv) {
                const vm = this;
                // 组装埋点数据
                const TrackDataList = {};
                const selectedDiscount = [];
                const { CODE } = window.dataLayer[0];

                // 组装接入 GTM dataLayer 需要的数据
                const pcatArray = [];
                const prodidArray = [];
                const gtmCart = {
                    total: {},
                    list: [],
                };

                vm.selectedTotal = {
                    floorPrice: {},
                    discount: [],
                    amount: [],
                };
                vm.total.floorFields.forEach((item) => {
                    vm.selectedTotal.floorPrice[item] = 1;
                });

                // 异步加载优惠券
                vm.getShopCoupon();

                // 组装接入 GTM dataLayer 需要的数据 (暂时字段数据取值未知)
                gtmCart.total = {
                    free_goods_number: '',
                    free_shipping_volume_weight: '',
                    free_shipping_weight: '',
                    free_total_fee: '',
                    goods_amount: 0, // 商品总数量
                    goods_price: vm.total.settleAmount, // 结算总金额
                    market_price: vm.total.goodsAmount, // 商品总金额
                    no_goods_number: '',
                    real_goods_count: '',
                    save_rate: `${((vm.total.discountAmount / vm.total.goodsAmount) * 100).toFixed(2)}%`, // 优惠率
                    saving: vm.total.discountAmount, // 优惠金额
                    shipping_volume_weight: '',
                    shipping_weight: '',
                };

                // 同步购物车数据到aff平台
                const affCartArray = [];
                const cookieLinkId = Cookies.get('linkid');

                let goodsAmount = 0;

                for (const groupIdx in vm.groupList) {
                    const group = vm.groupList[groupIdx];

                    for (let index = 0, length = group.length; index < length; index += 1) {
                        const goods = group[index];

                        // 编辑状态
                        vm.$set(goods, '$feEditChecked', false);
                        goodsAmount += goods.goodSnQty;
                        // 保存禁运状态
                        const goodsKey = `${goods.goodSn}_${goods.warehouseCode}`;

                        vm.shipCheckIds[goodsKey] = 1;

                        const key = `${goods.goodSn}_${goods.activityId}_${goods.warehouseCode}`;

                        TrackDataList[key] = {
                            sku: goods.goodSn, // sku
                            pc: goods.categoryId, // 分类id
                            k: goods.warehouseCode, // 仓库id
                            pam: goods.goodSnQty, // 数量
                        };

                        // 组装接入 GTM dataLayer 需要的数据
                        gtmCart.list.push({
                            goods_id: '', // php数据无商品id
                            goods_name: goods.goodTitle, // 商品名称
                            goods_number: goods.goodSnQty, // 商品数量
                            goods_price: goods.goodPrice, // 商品显示的单价
                            goods_sn: `${goods.goodSn}${CODE}`, // 商品sku
                            market_price: goods.linePrice, // 商品划线价格
                            rec_id: goods.itemId, // 购物车中该记录的唯一标识
                            categoryId: goods.categoryId, // 商品分类id
                            categoryName: goods.categoryName, // 商品分类名
                            isSelected: goods.isSelected, // 当前商品是否勾选
                        });

                        // 同步购物车数据到aff平台
                        if (cookieLinkId) {
                            affCartArray.push({
                                link_id: cookieLinkId, // 当前cookie中的 lkid
                                goods_sku: goods.goodSn, // 商品sku
                                shop_price: goods.goodPrice, // 商品的单价
                                add_time: goods.addTime, // 加入购物车时间
                                user_id: Cookies.get(COOKIE_UID), // 用户id
                                cart_id: goods.itemId, // 购物车中该记录的唯一标识
                                quantity: goods.goodSnQty, // 商品数量数量
                            });
                        }

                        // 批量收藏数据组装
                        if (goods.isSelected) {
                            // 组装埋点数据
                            TrackDataList[key].isSelected = true;
                            // 组装接入 GTM dataLayer 需要的数据
                            pcatArray.push(goods.categoryId);
                            prodidArray.push(`${goods.goodSn}${CODE}`);
                            // 定金膨胀优惠金额
                            if (goods.skuAdvanceDetail) {
                                vm.selectedTotal.amount.push({
                                    price: goods.skuAdvanceDetail.advanceAmount,
                                    Qty: goods.goodSnQty
                                });

                                if (goods.goodSnQty > goods.buyLimit) {
                                    vm.$toast({ msg: vm.$trans('cart.canot_add_number', [goods.buyLimit]) });
                                }
                            } else {
                                // 价格计算
                                for (const idx in goods.priceList) {
                                    const item = goods.priceList[idx];
                                    vm.selectedTotal.amount.push({
                                        price: item.price,
                                        Qty: item.qty
                                    });
                                    if (vm.selectedTotal.floorPrice.activityDeductAmount && item.activityDeductAmount > 0) {
                                        selectedDiscount.push(item.activityDeductAmount);
                                    }
                                }
                            }

                        }
                    }

                }
                // 取 pricelist中， 单个商品的活动优惠金额按仓库维度相加后进行多币种换算向下取整
                for (const code in selectedDiscount) {
                    const arr = selectedDiscount[code];
                    vm.selectedTotal.discount.push(arr);
                }

                gtmCart.total.goods_amount = goodsAmount;

                if (argv === 'init') {
                    vm.categoryInfo = [pcatArray, prodidArray, gtmCart];
                }

                // 不通邮检查
                vm.shipCheck();

                // 组装埋点数据
                window.TrackData.TrackDataList = TrackDataList;

                // 更新编辑状态数据
                vm.batchItems.list = vm.groupList;

                vm.$nextTick(() => {
                    vm.trackLog(argv, TrackDataList); // 埋点js
                    if (argv === 'init') {
                        // 同步购物车访问日志到aff平台
                        if (cookieLinkId) {
                            const affCartArrayJson = JSON.stringify(affCartArray);
                            const img = new Image(1, 1);
                            img.src = `${GLOBAL.AFF_URL}/?data=${affCartArrayJson}`;
                        }
                    }
                });
            },
            // 获取配件的主件对象
            parentData(itemId) {
                for (const key in this.$mainParts) {
                    if (this.$mainParts[key].itemId === itemId) {
                        return this.$mainParts[key];
                    }
                }
                return { itemId };
            },
            // 页面曝光
            trackLog(argv, TrackDataList) {
                if (argv === 'init') {
                    // 推荐位商品
                    this.goodsRecommand(TrackDataList);

                    new Paycart({
                        config: RULES,
                        page: true,
                    }).run();
                }
            },
            // 推荐位商品
            goodsRecommand(list) {
                const goodsinfo = [];
                const vm = this;
                if (list !== undefined) {
                    for (const key in list) {
                        const value = list[key];
                        goodsinfo.push({
                            sku: value.sku,
                            categoryid: value.pc,
                        });
                    }
                }
                getULike({
                    params: {
                        goodsinfo
                    },
                    recommendType: '1030101'
                }).then(({ status, data }) => {
                    if (status === 0) {
                        if (data.length) {
                            vm.recommendGoods = data;
                        }
                    }
                });
            },
            // 异步加载优惠券
            async getShopCoupon() {
                const vm = this;
                const { groupList } = vm;
                // 组装优惠券请求参数
                const couponData = [];

                for (const groupIdx in groupList) {
                    const group = groupList[groupIdx];
                    for (const index in group) {
                        const goods = group[index];
                        couponData.push(`${goods.warehouseCode}_${goods.shopCode}_${goods.goodSn}`);
                    }
                }

                // 请求优惠券数据
                const { status, data } = await serviceCartCoupon.http({
                    data: {
                        goodList: couponData.join(','),
                    }
                });

                if (status === 0) {
                    // 格式化优惠券数据
                    for (const index in data) {
                        const couponItem = data[index];
                        vm.cormatCouponData[couponItem.shopCode] = couponItem.list;
                    }

                    // 挂载优惠券数据
                    for (const groupIndex in groupList) {
                        const group = groupList[groupIndex];
                        for (const index in group) {
                            const goods = group[index];
                            if (goods.$feShopInfo) {
                                const couponList = vm.cormatCouponData[goods.shopCode];
                                if (couponList && couponList.length) {
                                    for (const idx in couponList) {
                                        const item = couponList[idx];
                                        vm.$set(goods.$feShopInfo.couponList, idx, item);
                                    }
                                }
                            }
                        }
                    }
                }
            },
            returnCouponRule(params) {
                const vm = this;
                const rules = params.map((item) => {
                    let discountVal = '';
                    const {
                        discountForm,
                        fullCondition,
                        meetAmount,
                        save,
                    } = item;
                    let { type } = item;
                    type = +type;

                    if (discountForm === 3) {
                        if ((type === 8 || type === 12) && fullCondition === 1) {
                            discountVal = `${save}% ${vm.$trans('cart.coupon_off_over')} ${vm.remainderRule.one(meetAmount)}`;
                        } else if ((type === 8 || type === 12) && fullCondition === 2) {
                            discountVal = `${save}% ${vm.$trans('cart.coupon_off_over')} ${vm.remainderRule.one(meetAmount)} ${vm.$trans('cart.coupon_unit_s')}`; // eslint-disable-line
                        } else if (type === 9 || type === 13) {
                            discountVal = `${save}% ${vm.$trans('cart.coupon_off_x')}`;
                        } else if (type === 10 || type === 14) {
                            discountVal = `${save}% ${vm.$trans('cart.coupon_after')}`;
                        }
                    } else if (discountForm === 1 || discountForm === 2) {
                        if (type === 10 || type === 14) {
                            discountVal = `${vm.remainderRule.one(save, 0)}`;
                        } else if (type === 9 || type === 13) {
                            discountVal = `${vm.remainderRule.one(save, 0)} ${vm.$trans('cart.coupon_off_x')}`;
                        } else if (type === 8 || type === 12) {
                            discountVal = `${vm.remainderRule.one(save, 0)} ${vm.$trans('cart.coupon_off_over')} ${vm.remainderRule.one(meetAmount)}`;
                        }
                    }
                    return `<i class="cart_couponTip">${discountVal}</i>`;
                });
                return vm.$trans('cart.earn_coupons', [rules]);
            },
            // 查询分类名称路径
            async getCategoryInfo() {
                const pcatArrName = [];
                const [pcatArray, prodidArray, list, gtmCart] = [...this.categoryInfo];
                const resData = await serviceGetCategoryInfo.http({
                    params: {
                        categoryIds: pcatArray.join(','),
                    }
                });
                const { status } = resData;
                let { data } = resData;

                if (status !== 0 || (Array.isArray(data) && data.length === 0)) {
                    data = {};
                }

                pcatArray.forEach((item) => {
                    pcatArrName.push(data[item] ? data[item].catePathName : '');
                });

                this.dataLayer(pcatArrName, prodidArray, list, gtmCart);
            },
            // dataLayer 存储
            dataLayer(pcatArray, prodidArray, gtmCart) {
                // 组装接入 GTM dataLayer 需要的数据
                win.dataLayer[0].google_tag_params.pcat = pcatArray; // 当前勾选商品分类
                win.dataLayer[0].google_tag_params.prodid = prodidArray; // 当前勾选商品 外部sku + (仓库名？)
                win.dataLayer[0].google_tag_params.totalvalue = this.total.settleAmount; // 当前购物车总价 （需要前端计算？）
                win.dataLayer[0].cart = gtmCart; // 明细见上注释

                win.dataLayer.push({ google_tag_params: win.dataLayer[0].google_tag_params });
                win.dataLayer.push({ cart: win.dataLayer[0].cart });
                win.dataLayer.push({ event: 'triggerAdwordsRemarking' });
            },
            onload() {
                const vm = this;
                if (!vm.onloadLock) {
                    vm.onloadLock = true;
                    if (vm.groupList.length) {
                        // 不通邮检查
                        vm.shipCheck();
                        // 异步加载优惠券
                        vm.getShopCoupon();
                        // 查询分类名称路径
                        vm.getCategoryInfo();
                    }
                }

            },
            // 不通邮检查
            async shipCheck() {
                const vm = this;
                const ids = Object.keys(vm.shipCheckIds);

                if (win.payVars.isLogin && ids.length) {
                    const { status, data } = await serviceShipCheck.http({
                        params: {
                            goods: ids.join(','),
                        }
                    });

                    if (status === 0 && data && data.length) {
                        const dataObj = {};
                        data.forEach((item) => {
                            dataObj[`${item.goodSn}_${item.warehouseCode}`] = 1;
                        });
                        for (const groupIdx in vm.groupList) {
                            const group = vm.groupList[groupIdx];
                            for (const index in group) {
                                const goods = group[index];
                                const key = `${goods.goodSn}_${goods.warehouseCode}`;
                                if (dataObj[key] === 1) {
                                    goods.isCanShip = 0;
                                }
                            }
                        }
                    }
                }
            },
            // 变更商品参与活动
            async changeGoodsAct(argv) {
                const vm = this;
                const itemList = [];
                if (argv.checked !== 1) {
                    return;
                }
                const loading = vm.$loading();
                // 更新选中的活动状态
                argv.checkData.dialog.componentData.activityId = argv.checkData.activityId;
                itemList.push({
                    itemId: argv.checkId,
                    activityId: argv.checkData.activityId,
                });

                const res = await serviceCartChange.http({
                    data: {
                        itemList: JSON.stringify(itemList)
                    }
                });

                loading.close();

                if (res.status === 0) {
                    vm.getCartList({ $dialog: argv.checkData.dialog });
                } else {
                    vm.showToast(res.msg);
                }
            },

            // 添加到购物车
            async addtoCart(argv) {
                const vm = this;
                const { status, msg } = await serviceAddToCart.http({
                    errorPop: false,
                    loading: false,
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    data: { goods: JSON.stringify(argv.postData) }
                });

                if (status === 0) {
                    if (argv.$dialog) {
                        argv.$dialog.close();
                        vm.$bus.$emit('getCartList', { $dialog: argv.$dialog });
                    } else {
                        vm.$bus.$emit('getCartList');
                    }
                    vm.$toast({ msg: vm.$trans('cart.add_to_cart_success') });
                } else {
                    if (argv.$dialog) {
                        argv.$dialog.submiting = false;
                    }
                    vm.$toast({ msg });
                }
            },
            // 选中/取消选中商品
            async selectGoods(argv) {
                const vm = this;
                const { checked } = argv;
                // 此处取反
                argv.checked = +!checked;
                const itemIds = vm.setSelectedId(argv);

                if (itemIds.length) {
                    const { status, msg } = await serviceCartSelect.http({
                        loading: true,
                        data: {
                            itemId: itemIds.join(','),
                            isSelected: argv.checked,
                        }
                    });

                    vm.getCartList();

                    if (status !== 0) {
                        vm.showToast(msg);
                    }
                }
            },
            // 获取加价购商品/赠品
            async checkGift(goodsList, groupListItem, activityId) {
                const vm = this;
                const { status, data, msg } = await serviceCartGift.http({
                    params: {
                        activityId
                    }
                });

                if (status === 0) {
                    const title = +groupListItem.activity.activityType === 2 ? vm.$trans('cart.change_gift') : vm.$trans('cart.popout_add_on');
                    // 加入购物车弹窗
                    vm.$alert({
                        title,
                        customClass: 'pickGoods',
                        rollfrom: 'bottom',
                        okEvent: 'checkgift',
                        component: checkgift,
                        componentData: {
                            txttip: +groupListItem.activity.activityType === 2 ? vm.$trans('cart.gift') : vm.$trans('cart.popout_add_on'),
                            goodsList,
                            groupListItem,
                            data,
                            activityId,
                            type: groupListItem.activity.activityType === 2 ? 'gift' : ''
                        },
                        okText: vm.$trans('cart.confirm')
                    });
                } else {
                    vm.showToast(msg);
                }
            },
            // 删除弹窗
            toDelGoods(argv) {
                const vm = this;
                let itemIds = [];

                if (argv === 'editMode') {
                    itemIds = vm.getEditCheckedId();
                } else {
                    itemIds = vm.getSelectedId(argv, { event: 'delete' });
                }

                if (itemIds.length) {
                    vm.$confirm({
                        itemIds,
                        okEvent: 'deleteGoods',
                        content: `<p style="text-align:center;padding-top:1rem;font-size:.5rem;line-height:.7rem;">
                            ${vm.$trans('cart.to_delete_tip')}
                        </p>`,
                        ok(dialog) {
                            vm.deleteGoods(dialog);
                        },
                        confirmText: vm.$trans('cart.confirm'),
                        cancelText: vm.$trans('cart.cancel'),
                    });
                } else {
                    vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
            },
            // 收藏商品
            async favorGoods(itemIds) {
                const vm = this;
                const { status, data, msg } = await serviceCollectAdd.http({
                    data: {
                        goods: itemIds
                    }
                });

                if (status === 0) {
                    vm.$toast({ msg: vm.$trans('cart.move_success') });

                    // 删除商品
                    vm.deleteGoods('editMode');

                } else if (data.redirectUrl) {
                    win.location.href = data.redirectUrl;
                } else {
                    vm.$toast({ msg });
                }
            },
            // 确认删除
            async deleteGoods(argv) {
                const vm = this;
                let itemIds = [];

                if (argv === 'editMode') {
                    this.getEditCheckedId();
                    itemIds = vm.batchItems.itemIds;
                } else {
                    itemIds = argv.itemIds;
                }

                const { status, msg } = await serviceCartDelete.http({
                    data: {
                        itemId: itemIds.join(','),
                    }
                });

                if (argv !== 'editMode') {
                    argv.submiting = false;
                }

                if (status === 0) {
                    vm.checkStat = {};
                    if (argv !== 'editMode') {
                        vm.getCartList({ $dialog: argv });
                    } else {
                        vm.getCartList();
                    }

                } else {
                    vm.$toast({ msg });
                }
            },
            // 店铺领取优惠券
            async getCouponList(couponList) {
                const vm = this;
                vm.$alert({
                    shadowClose: true,
                    title: vm.$trans('cart.shop_coupon'),
                    customClass: 'cartShopCoupon',
                    component: coupons,
                    rollfrom: 'bottom',
                    couponList,
                });
            },
            // 保存购物车数据
            async checkout(payChannel) {
                const vm = this;
                let itemList = [];
                // 显示loading图标
                const loading = vm.$loading();

                let skuAdvanceDetail = false;

                for (const groupIdx in vm.groupList) {
                    const group = vm.groupList[groupIdx];
                    for (const goodIdx in group) {
                        const goods = group[goodIdx];
                        if (goods.isSelected) {
                            if (goods.skuAdvanceDetail) {
                                skuAdvanceDetail = true;
                            }
                            itemList.push({
                                itemId: goods.itemId,
                                activityId: goods.activityId
                            });
                        }
                    }
                }

                if (itemList.length === 0) {
                    loading.close();
                    return vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
                itemList = [];

                for (const groupIdx in vm.groupList) {
                    const group = vm.groupList[groupIdx];
                    for (const goodIdx in group) {
                        const goods = group[goodIdx];
                        if (goods.isSelected && group[0].$feActInfo && group[0].$feActInfo.isJoined) {
                            itemList.push({
                                itemId: goods.itemId,
                                activityId: goods.activityId,
                            });
                        }
                    }
                }

                // 提交商品列表
                const resCS = await serviceCartSaveActs.http({
                    loading: false,
                    data: {
                        itemList
                    }
                });

                if (payChannel !== 'checkout' && resCS.status === 0) {
                    const resQPD = await serviceCartSendQuickPay.http({
                        loading: false,
                        params: {
                            channelCode: payChannel
                        },
                    }).catch(() => {
                        loading.close();
                    });

                    const { redirectUrl } = resQPD.data;
                    if (redirectUrl) {
                        loading.close();
                        win.location.href = redirectUrl;
                        return false;
                    }
                    loading.close();
                } else if (resCS.status === 0) {
                    const doc = document;
                    const formEl = doc.createElement('form');
                    const isDeposit = skuAdvanceDetail ? '?isDeposit=1' : '';
                    loading.close();
                    formEl.method = 'post';
                    formEl.action = `${GLOBAL.DOMAIN_ORDER}/checkout/index${isDeposit}`;
                    doc.body.appendChild(formEl);
                    formEl.submit();
                } else {
                    loading.close();
                    vm.$toast({
                        timer: 1500,
                        msg: resCS.msg,
                        ok() {
                            setTimeout(() => win.location.reload(), 1000);
                        }
                    });
                }
                return false;
            },
            closeDiscountTip() {
                this.showDiscountTip = 0;
            },
            // 批量选择
            async batchSelect(data) {
                // const { list } = vm.batchItems;
                // const { type, checked, checkId } = data;
                try {
                    const call = await import('./batch_edit.js');
                    call.default(this, data);
                } catch (e) {
                    console.log(e);
                }
            },
            // 进入关闭模式
            editMode() {
                const vm = this;
                // const { list } = vm.batchItems;
                // const { type, checked, checkId } = data;

                vm.allEditChecked = true;
                vm.checkStat = {};
            },
            // 退出关闭模式
            exitEdit() {
                this.allEditChecked = false;
                this.$bus.$emit('batchSelect', {
                    type: 'all',
                    checked: false,
                    checkId: '',
                });
                this.batchItems.itemIds = [];
            },
            // 心愿单
            wishlist() {
                const vm = this;
                const itemIds = vm.getEditCheckedId('favor');

                if (itemIds.length) {
                    vm.favorGoods(itemIds);
                } else {
                    vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }
            },
            getEditCheckedId(type) {
                const vm = this;
                vm.batchItems.itemIds = [];
                if (Object.keys(vm.checkStat).length) {
                    for (const key in vm.checkStat) {
                        const item = vm.checkStat[key];
                        const wareCode = key.split('_')[0];
                        if (item.checked) {
                            if (type === 'favor') {
                                vm.batchItems.itemIds.push(`${item.goodSn}_${wareCode}`);
                            } else {
                                vm.batchItems.itemIds.push(item.id);
                            }
                        }
                    }
                }

                return this.batchItems.itemIds;
            },

            // 支付折扣
            async getPayRelate() {
                const vm = this;
                const { status, data } = await serviceCartPayrelate.http();
                if (status === 0) {
                    vm.deExpressChannels = data.expressChannels;
                    vm.payDiscountInfo = data.discountInfo;
                }
            },

            PayRelate(data) {
                const vm = this;
                vm.expressChannels = [];
                vm.deExpressChannels.forEach((item) => {
                    if (item.payChannel === 'PP_Express') {
                        if (data.settleAmount >= 1 && data.settleAmount <= 1500 && data.hasLimitGoods === 0) {
                            vm.expressChannels.push(item);
                        }
                    }
                });
                if (vm.expressChannels.length > 0) {

                    // 快捷支付多语言图片
                    const thisLang = GLOBAL.LANG;

                    try {
                        vm.pp_Express = require(`./img/paypal/buynow_${thisLang}.png`); // eslint-disable-line
                    } catch (err) {
                        vm.pp_Express = require('./img/paypal/buynow_en.png'); // eslint-disable-line
                    }
                } else {
                    try {
                        vm.pp_Express = require(`./img/paypal/buynow_${thisLang}_dis.png`); // eslint-disable-line
                    } catch (err) {
                        vm.pp_Express = require('./img/paypal/buynow_en_dis.png'); // eslint-disable-line
                    }
                }
            },
        },
    };
</script>

<style>
@import 'pages/paycart/component/cart-v2/cart.css';
</style>
