<template lang="pug">
label.vue_checkbox.ischeckbox(v-finger:tap.stop.prevent="changeChecked")
    span.vue_checkboxShape(:class="{'icon-radiobox': !checked, 'icon-tick': checked, 'icon-radiobox_disabled': disable}")
    span.vue_checkboxLabel(v-if="label", v-html="label")
</template>

<script>

    export default {
        name: 'editCheckbox',
        data() {
            return {
                checkedStat: this.checked,
            };
        },
        props: {
            checkId: '',
            checked: false,
            disable: false,
            checkData: {},
            checkType: {
                default: 'goods',
            },
            label: String,
        },
        methods: {
            changeChecked() {

                if (!this.disable) {
                    this.$bus.$emit('batchSelect', {
                        type: this.checkType,
                        checked: !this.checked,
                        checkId: this.checkId,
                        checkData: this.checkData,
                    });
                }

            }
        }
    };
</script>
