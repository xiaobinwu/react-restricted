<template lang="pug">
.cart_goods(:class="[{'mainAccessory-back': groupsType === 1 && goods.isMainAndAccessory === 1, 'main-margin': groupsType === 1 && goods.isMainAndAccessory === 1 && goods.goodType === 0}]")
    //- 店铺复选框
    .cart_shop(v-if="goods.allowBuy && goods.$feActInfo && goods.$feActInfo.groupType > 0")
        i.icon-store_gb(v-if="goods.shopType === 1")
        i.icon-store(v-else)
        a.cart_shoptitle(v-if="goods.$feShopInfo.isShow", :href="goods.$feShopInfo.shopUrl") {{ goods.$feShopInfo.shopName }}
            i.icon-arrow_tiny
        span.cart_shoptitle(v-else) {{ goods.$feShopInfo.shopName }}
        span.cart_coupon(v-if="goods.$feShopInfo.couponList && goods.$feShopInfo.couponList.length", v-finger:tap="getCouponList.bind(this, goods.$feShopInfo.couponList)") {{ $trans('cart.shop_coupon') }}

    .cart_goodsgroup
        .cart_itemlist(:class="{'cart_giftGoods': goods.goodType === 1 || goods.goodType === 2 || goods.goodType === 3 || goods.goodType === 21}", :data-customtrack="goods.goodSn +'_'+ goods.categoryId +'_'+ goods.warehouseCode")
            compCheckbox(v-if="goods.goodType != 2 && goods.goodType != 21", v-show="goods.allowBuy ? !allEditChecked : 1", :checkId="goods.$feGroupIndex + '_' + goods.$feIndex", :checked="!goods.$feExpired ? goods.isSelected : 2", :checkData="{itemId: goods.itemId, goodsType: goods.goodType}", :eventName="'cartlistSelected'")
            span.vue_checkbox(v-if="goods.allowBuy && (goods.goodType === 2)", v-show="!allEditChecked")
            editCheckbox(v-if="goods.allowBuy && goods.goodType != 1 && goods.goodType != 21", v-show="allEditChecked", :checkId="goods.$feGroupIndex + '_' + goods.$feIndex", :checked="goods.$feEditChecked", :checkData="{itemId: goods.itemId, goodsType: goods.goodType}", :eventName="'batchSelect'", :disable="goods.$feExpired")
            span.vue_checkbox(v-if="goods.allowBuy && (goods.goodType === 1)", v-show="allEditChecked")
            //- 图片
            a.cart_img(:href="allEditChecked? 'javascript:;': goods.linkUrl")
                span.cart_pricetype(v-if="goods.goodsStatus == 4 || goods.priceType == 1 || goods.priceType == 2 || goods.priceType == 7", :class="[goods.goodsStatus == 4? 'type_arrive': (goods.priceType == 1? 'type_emailOnly': (goods.priceType == 2? 'type_presale': (goods.priceType == 7? 'type_flashsale': ''))), {'giftGoods':goods.goodType === 2 || goods.goodType === 3 || goods.goodType === 21}]") {{goods.goodsStatus | priceTypeFilter(this, goods.priceType)}}
                .cart_canotship(v-if="goods.isCanShip === 0")
                    .cart_cell
                        p {{ $trans('cart.canot_ship') }}
                img(src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", :data-id="goods.itemId", :data-img="goods.goodImg", v-lazy="goods.goodImg")
                p.cart_imgText(v-if="goods.goodType === 1") {{ $trans('cart.cart_accessory') }}
                p.cart_imgText(v-if="goods.goodType === 2 || goods.goodType === 21") {{ $trans('cart.gift') }}
                p.cart_imgText(v-if="goods.goodType === 3") {{ $trans('cart.redeem') }}
            //- 商品信息
            .cart_goodsbox
                .cart_info
                    a.cart_link(:href="allEditChecked? 'javascript:;': goods.linkUrl", :class="{'hasMargin': goods.property != 1}")
                        span.type_clearance(v-if="goods.saleMark == 3 || goods.priceType == 10 || goods.priceType == '6396395377285853184'") {{ $trans('cart.clearance') }}
                        | {{goods.goodTitle}}

                    //- 敏感品标识
                    p.sensitiveTip(v-if="goods.property != 1", v-finger:tap="showtip")
                        i.icon-warning_icon

                    //- 商品属性
                    .cart_attrs(v-if="goods.attr.length", v-finger:tap="editAttrs.bind(this, goods)", :class="{'disabled': goods.goodType === 1 || goods.goodType === 2 || goods.goodType === 21 || goods.goodType === 3 || !goods.allowBuy}")
                        p.cart_props {{goods.attr | attrFilter}}
                        i.icon-arrow_down
                    //- 所属仓库
                    p.cart_ware {{goods.warehouseName}}

                    //- 切换活动
                    //- .cart_moredesc(v-if="!goods.$feExpired && goods.canJoinActivityList && goods.canJoinActivityList.length", v-finger:tap="changeActs")
                        p.cart_descs {{ actInfo && actInfo.activity ? actInfo.activity.activityName: $trans('cart.change_activity') }}
                        i.icon-arrow_down

                    .cart_other
                        //- 更改数量
                        changeStock(:updateList="true", :liveUpdate="false", :goods="goods", :parentData="parentData", :goodsgroup="actInfo")

                        p.cart_price(v-if="goods.stockNum > 0 && goods.allowBuy") {{currency | $remainder_one(goods.goodPrice)}}
                    p.cart_priceReminderBox(v-if="goods.diffAddPrice")
                        span.cart_priceReminder
                            i.icon-arrowdown
                            | {{ currency | $remainder_one(goods.diffAddPrice) }} {{ $trans('cart.coupon_off') }}
                    p.cart_deposit(v-if="goods.skuAdvanceDetail") {{ deposit(goods) }}

                    p.cart_status(v-if="goods.allowBuy && goods.stockNum <= 0") {{ $trans('cart.notice_out_of_stock') }}
                    p.cart_status(v-if="!goods.allowBuy") {{ $trans('cart.goods_expired') }}

                    .cart_codInfo(v-if="goods.isCod === 1")
                        a.cart_codIcon(:href="mainUrl + '/cod.html'" target="_special") COD
                        i.icon-question(@click="showCodTip")

        //- 价格阶梯展示
        p.muilty_prices(v-if='goods.priceList.length > 1') {{ $trans('cart.muilty_prices') }} {{currency | $remainder.pricesList(goods.priceList) | pricesFilter}}

        p.accessory_acNote(v-if='goods.$feGroupType === 1 && goods.goodType === 1') {{ $trans('cart.accessory_not_acNote') }}

        //- 切换活动
        .cart_moredesc(v-if="!goods.$feExpired && goods.canJoinActivityList && goods.canJoinActivityList.length", v-finger:tap="changeActs")
            p.cart_descs {{ actInfo && actInfo.activity ? actInfo.activity.activityName: $trans('cart.change_activity') }}
            p.cart_select {{ $trans('cart.select') }}
                i.icon-arrow_down

</template>

<script>

    import layer from 'layer';
    import { serviceCartUpdate, serviceCartSameGoods } from 'js/service/paycart';
    import compCheckbox from '../paycart_checkbox.vue'; // 复选框
    import changeStock from './change_stock.vue'; // 商品输入框组件
    import editCheckbox from './edit_checkbox.vue';

    const coupons = () => import('./coupons.vue');
    const goodsReplace = () => import('./goods_replace.vue'); // 商品输入框组件
    const changeAct = () => import('./change_act.vue'); // 切换活动组件

    export default {
        name: 'goodsgroup',
        /* eslint-disable */
        data() {
            return {
                tip_float: false,                   // 商品提示信息
                goodOrigQty: this.goods.goodSnQty,  // 商品原始数量
                goodSnQty: this.goods.goodSnQty,    // 商品实时数量
                isSelected: this.goods.isSelected,   // 商品勾选状态
                mainUrl: window.GLOBAL.DOMAIN_MAIN   // 主域名
            };
        },
        /* eslint-enable */
        props: {
            goods: Object,
            parentData: Object,
            allEditChecked: Boolean,
            actInfo: Object,
            groupsType: Number,
        },
        components: {
            compCheckbox,
            changeStock,
            editCheckbox,
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        filters: {
            attrFilter(attrs) {
                const arr = [];
                for (const item in attrs) {
                    arr.push(attrs[item].value);
                }
                return arr.join(', ');
            },
            pricesFilter(priceList) {
                return priceList.map(item => `${item.price} x ${item.qty}`).join(', ');
            },
            priceTypeFilter(...args) {
                let text = '';
                const result = {
                    4: 'cart.mark_arrival_notice',
                    1: 'cart.email_only',
                    2: 'cart.mark_presale',
                    7: 'cart.mark_flash_sale',
                };

                if (+args[0] === 4) {
                    text = args[1].$trans(result[args[0]]);
                } else {
                    text = args[1].$trans(result[args[2]]);
                }
                return text;
            }
        },
        methods: {
            // 店铺领取优惠券
            async getCouponList(couponList) {
                const vm = this;
                vm.$alert({
                    shadowClose: true,
                    title: vm.$trans('cart.shop_coupon'),
                    customClass: 'cartShopCoupon',
                    component: coupons,
                    rollfrom: 'bottom',
                    couponList,
                });
            },
            // 确认编辑更新商品数量
            async confirmEdit() {
                const vm = this;

                const { status, msg } = await serviceCartUpdate.http({
                    data: {
                        itemId: vm.goods.itemId,
                        qty: vm.goodSnQty,
                    }
                });

                if (status === 0) {
                    vm.$bus.$emit('getCartList');
                } else {
                    vm.$toast({ msg });
                }
            },
            // 切换商品提示信息
            showtip() {
                this.$alert({
                    customClass: 'sensitiveTips',
                    content: this.$trans('cart.popout_sensitive_tips'),
                });
            },
            // 编辑商品属性弹窗
            async editAttrs(goods) {
                const vm = this;
                if (!goods.allowBuy || goods.goodType === 1 || goods.goodType === 2 || goods.goodType === 21 || goods.goodType === 3) return;

                const { status, data, msg, } = await serviceCartSameGoods.http({
                    params: {
                        goodSn: vm.goods.goodSn,
                        virWhCode: vm.goods.warehouseCode
                    }
                });
                if (status === 0) {
                    vm.$alert({
                        shadowClose: true,
                        rollfrom: 'bottom',
                        customClass: 'goods_replace',
                        component: goodsReplace,
                        goodsInfo: vm.goods,
                        attrList: data.attrList,
                        goodsList: data.goodsList,
                        closeSlideMode: vm.closeSlideMode,
                        editGoods: vm.editGoods
                    });
                } else {
                    vm.$toast({ msg });
                }
            },
            // 切换商品活动弹窗
            changeActs() {
                const vm = this;
                vm.$alert({
                    title: vm.$trans('cart.choose_activity'),
                    customClass: 'changeActDialog',
                    rollfrom: 'bottom',
                    shadowClose: true,
                    component: changeAct,
                    componentData: {
                        activityList: vm.goods.canJoinActivityList,
                        activityId: vm.goods.activityId,
                        eventName: 'changeGoodsAct',
                        itemId: vm.goods.itemId,
                    },
                });
            },
            deposit(goods) {
                const { skuAdvanceDetail } = goods;
                const { advanceAmount, swellDiscontAmount } = skuAdvanceDetail;

                return swellDiscontAmount > 0 ? this.$trans('cart.deposit_discount', [this.remainderRule.one(advanceAmount), this.remainderRule.one(swellDiscontAmount, 0)]) : this.$trans('cart.deposit_mount', [this.remainderRule.one(advanceAmount)]); // eslint-disable-line
            },
            showCodTip() {
                layer.open({
                    content: `
                        <div class="dropbox_cod_content">
                            <p class="cod_tips">${this.$trans('cart.cod_tips')}</p>
                            <div class="close_cod_tips js-closeCodTips">OK</div>
                        </div>
                    `,
                    success() {
                        $(document).on('click', '.dropbox_cod_content .js-closeCodTips', () => {
                            layer.closeAll();
                        });
                    }
                });
            }
        }
    };
</script>

<style>
@import 'pages/paycart/component/cart-v2/goodsgroup.css';
</style>
