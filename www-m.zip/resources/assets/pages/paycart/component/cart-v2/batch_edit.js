export default (vm, data) => {

    const { list } = vm.batchItems;
    const {
        type,
        checked,
        checkId,
        checkData
    } = data;
    const checkIndex = checkId.split('_');
    const groupIndex = checkIndex[0];
    const checkStat = vm.checkStat;

    if (type === 'all') {
        // 全选
        vm.batchItems.$feEditChecked = checked;

        for (const groupIdx in list) {
            const group = list[groupIdx];
            for (const goodIdx in group) {
                const goods = group[goodIdx];
                if (!goods.$feExpired) {
                    goods.$feEditChecked = checked;
                    vm.$set(list[groupIdx], goodIdx, goods);
                    checkStat[`${goods.$feGroupIndex}_${goods.itemId}`] = {
                        checked,
                        goodSn: goods.goodSn,
                        id: goods.itemId,
                    };
                }
            }
        }


    } else if (type === 'group' || type === 'shop') {
        // 活动
        console.log('活动');
        const group = list[groupIndex];
        if (type === 'group') {
            group[0].$feActInfo.$feGroupEditChecked = checked;
        } else if (type === 'shop') {
            group[0].$feShopInfo.$feGroupEditChecked = checked;
        }
        vm.$set(list, groupIndex, group);
        for (const goodIdx in group) {
            const goods = group[goodIdx];
            goods.$feEditChecked = checked;
            vm.$set(list[groupIndex], goodIdx, goods);
            checkStat[`${goods.$feGroupIndex}_${goods.itemId}`] = {
                checked,
                goodSn: goods.goodSn,
                id: goods.itemId,
            };
        }


    } else if (type === 'goods') {
        // 单个商品
        if (checkData) {
            const itemId = checkData.itemId;
            for (const goodIdx in list[groupIndex]) {
                const goods = list[groupIndex][goodIdx];
                if (goods.itemId === itemId) {
                    goods.$feEditChecked = checked;
                    vm.$set(list[groupIndex], goodIdx, goods);
                    checkStat[`${goods.$feGroupIndex}_${goods.itemId}`] = {
                        checked,
                        goodSn: goods.goodSn,
                        id: goods.itemId,
                    };
                }
            }
        }

    }

    // 关联全选
    let goodsNum = 0;
    let checkedNum = 0;
    let groupGoodsNum = 0;
    let groupCheckedNum = 0;
    for (const groupIdx in list) {
        const group = list[groupIdx];
        groupGoodsNum = 0;
        groupCheckedNum = 0;
        for (const goodIdx in group) {
            const goods = group[goodIdx];
            if (goods.goodType === 0 && !goods.$feExpired) {
                goodsNum += 1;
                groupGoodsNum += 1;
                if (goods.$feEditChecked) {
                    checkedNum += 1;
                    groupCheckedNum += 1;
                }
            }
        }
        if (list[groupIdx][0].$feActInfo) {
            list[groupIdx][0].$feActInfo.$feGroupEditChecked = groupCheckedNum >= groupGoodsNum;
        } else if (list[groupIdx][0].$feShopInfo) {
            list[groupIdx][0].$feShopInfo.$feGroupEditChecked = groupCheckedNum >= groupGoodsNum;
        }
    }
    vm.batchItems.$feEditChecked = checkedNum >= goodsNum;
};
