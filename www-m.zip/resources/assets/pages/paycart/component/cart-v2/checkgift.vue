<template lang="pug">
.pickgoodswrap
    ul.dialogScrollArea(:ref="`kdialog_scroll_wrap`")
        //- 切换加价购商品/选择赠品
        li(v-for="(item, index) in datamodal")
            label.vue_checkbox(v-finger:tap="changePick.bind('', item, index)")
                span.vue_checkboxShape(:class="item.checked === 1 ? 'icon-tick': (item.checked === 2 ? 'icon-radiobox_disabled':'icon-radiobox')")

            .pickitem
                a.pickimg(:href="item.linkUrl")
                    img(:src="item.goodImg")
                    p.pickname {{(item.stockNum <= 0 || item.canGive <= 0 || item.remaindCount <= 0) ? $trans('cart.notice_out_of_stock'): comData.txttip}}
                .pickinfo
                    a.picktitle(:href="item.linkUrl") {{item.goodTitle}}
                    p.pickattrs {{item.attr | attrFormat}}
                    p.linePrice {{currency | $remainder_one(item.linePrice)}}
                    p.picktotal
                        span.pickprice {{currency | $remainder_one(item.price)}}
                        span.picknumber x{{item.singleCount}}

    p.checkNumber {{checkedNum}}/{{maxGiftCount}}

</template>

<script>

    import { serviceCartChange } from 'js/service/paycart';

    export default {
        /* eslint-disable */
        data() {
            return {
                checkedNum: this.$parent.componentData.checkedNum || 0,             // 已选数量
                comData: this.$parent.componentData, // 弹窗前传入的数据对象
                cartGoodsList: this.$parent.componentData.goodsList, // 购物车组商品列表
                datamodal: this.$parent.componentData.data.goodsList, // 赠品数据列表
                maxGiftCount: this.$parent.componentData.data.maxGiftCount, // 最大可添加到赠品SKU数量
            };
        },
        /* eslint-enable */
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        filters: {
            attrFormat(list) {
                return list.map(item => item.value).join(', ');
            }
        },
        created() {
            const vm = this;
            // 已经在购物车的不可勾选
            const skuList = vm.comData.groupListItem.actJoinedSkuList;

            vm.checkedNum = 0;
            for (const n in vm.datamodal) {
                const item = vm.datamodal[n];
                // 优先判断是否勾选主件状态
                if (item.meetAmount > vm.comData.groupListItem.actMergeAmount || item.canGive <= 0 || item.remaindCount <= 0 || item.stockNum <= 0) { // eslint-disable-line
                    item.checked = 2;
                } else {
                    // 判断是否已勾选过此商品/赠品
                    for (const i in skuList) {
                        if (skuList[i] === item.goodSn) {
                            item.checked = 2;
                            item.hasChecked = 1;
                            vm.checkedNum += 1;
                            console.log(3333333);
                        }
                        vm.$set(vm.datamodal, n, item);
                    }
                }
                if (+item.checked !== 2) {
                    item.checked = 0;
                }
                vm.$set(vm.datamodal, n, item);
            }

            vm.$bus.$on('checkgift', (data) => {
                // 变更商品参与活动
                vm.checkgift(data);
            });
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.touchScroll(this.$refs.kdialog_scroll_wrap);
            });
        },
        methods: {
            changePick(item, index) {
                const vm = this;
                const $parent = vm.comData;

                // 库存不足不可勾选并提示
                if (item.stockNum <= 0 || item.canGive <= 0 || item.remaindCount <= 0) {
                    item.checked = 2;
                    vm.$set(vm.datamodal, index, item);
                    return vm.$toast({ msg: vm.$trans('cart.notice_out_of_stock') });
                }

                if (item.checked === 2 || !$parent.groupListItem.isJoined) {
                    if (item.hasChecked) {
                        return vm.$toast({ msg: vm.$trans('cart.already_got') });
                    } else if (item.meetAmount > vm.comData.groupListItem.actMergeAmount) {
                        return vm.$toast({ msg: vm.$trans('cart.cannot_to_got', [vm.remainderRule.one(item.meetAmount)]) });
                    }
                }
                // 获取当前以及勾选的数量
                vm.datamodal[index].checked = +!item.checked;
                vm.$set(vm.datamodal, index, vm.datamodal[index]);
                vm.checkedNum = 0;
                vm.datamodal.forEach(($item) => {
                    if (+$item.checked === 1 || $item.hasChecked) {
                        vm.checkedNum += 1;
                    }
                });

                // 勾选数量不可大于最大可勾选数量
                if (vm.maxGiftCount < vm.checkedNum) {
                    item.checked = 0;
                    vm.checkedNum -= 1;
                    vm.$set(vm.datamodal, index, item);
                    return vm.$toast({ msg: vm.$trans('cart.over_max_num') });
                }
                return false;
            },
            // 选择加价购/赠品
            async checkgift(data) {
                const vm = this;

                const itemCheckd = [];
                vm.datamodal.forEach((item, index) => {
                    if (item.checked === 1) {
                        itemCheckd.push({
                            activityId: vm.comData.activityId || '',
                            warehouseCode: item.warehouseCode,
                            goodsSn: item.goodSn,
                            qty: item.singleCount
                        });
                    }
                });

                if (itemCheckd.length === 0) {
                    data.$dialog.submiting = false;
                    return vm.$toast({ msg: vm.$trans('cart.check_one_least') });
                }

                // 加入购物车前保存活动
                const itemList = [];
                vm.cartGoodsList.forEach((item) => {
                    if (item.isSelected) {
                        itemList.push({
                            itemId: item.itemId,
                            activityId: item.activityId
                        });
                    }
                });

                const res = await serviceCartChange.http({
                    data: {
                        itemList,
                    }
                });

                console.log(res);

                if (res.status === 0) {
                    // 判断是赠品还是加价购商品
                    let addType = 2;
                    if (data.$dialog.componentData.type !== 'gift') {
                        addType = 3;
                    }
                    itemCheckd.forEach((item, index) => {
                        vm.$set(item, 'goodsType', addType);
                    });
                    data.$dialog.close();
                    vm.$bus.$emit('addtoCart', { postData: itemCheckd });
                } else {
                    vm.$toast({ msg: res.msg });
                }
                return false;
            },
        }
    };
</script>
