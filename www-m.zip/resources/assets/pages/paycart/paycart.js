import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import Vue from 'vue';
import {
    add,
    addSymbol,
    getCurrency,
    transformSymbol,
    transform,
    multiply,
} from 'js/core/currency';
import VueRouter from 'vue-router';
import { trans } from 'js/core/translate.js';
import staticAsset from 'js/core/staticAsset';
import AlloyFinger from 'lib/alloyfinger/alloy_finger';
import alloyfingerPlugin from 'lib/alloyfinger/alloy_finger_vue';
import kdialog from './component/dialog/keydialog';
import lazyload from './vuelazyload';
import App from './App.vue';

import './paycart.css';

const win = window;

// 订单确认页 去订单详情拦截
const hasValue = win.location.hash;
const orderSn = hasValue.match(/orderSn=(\d+);/) ? hasValue.match(/orderSn=(\d+);/)[1] || '' : '';
if (orderSn) {
    win.location.href = `${win.GLOBAL.DOMAIN_USER}/index#/order/detail?sn=${orderSn}`;
}

const cart = () => import('./component/cart-v2/cart.vue'); // 购物车列表
const checkout = () => import('./component/checkout/checkout.vue'); // 订单确认页
const payResult = () => import('./component/payment_results/payment_results.vue'); // 支付结果页
const quickpay = () => import('./component/quick_pay/quick_pay.vue'); // 快捷支付中转页

const routes = [
    {
        path: '/cart/index',
        name: 'cart',
        component: cart,
    },
    {
        path: '/checkout/index',
        name: 'checkout',
        component: checkout,
    },
    {
        path: '/payment/express-address',
        name: 'quickpay',
        component: quickpay,
    },
    {
        path: '/payment/result',
        name: 'paymentresults',
        component: payResult,
    },
    { // 访客模式 - 支付结果页
        path: '/payment/visitor-result',
        name: 'visitor-result',
        component: payResult,
    },
];

Vue.config.devtools = true; // 开启浏览器 devtools 调试

const router = new VueRouter({
    mode: 'history',
    fallback: false,
    routes,
});

Vue.use(VueRouter);
Vue.use(kdialog);
Vue.use(lazyload, {
    loading: 'icon-lazy',
});
Vue.use(alloyfingerPlugin, {
    AlloyFinger
});

kdialog.eventbus();
kdialog.setLanguage('en');
kdialog.setRunTime('m'); // 使用kdialog插件设置平台

// 监听全局点击事件
win.addEventListener('click', (e) => {
    new Vue().$bus.$emit('domClick', {
        target: e.target
    });
}, false);

// 货币转换向上/向下取整规则
Vue.prototype.remainderRule = {
    // 向上取整
    currencyChange: (...arg) => {
        let newArrObj = null;
        if (!Array.isArray(arg[1])) {
            // 单个价格
            const priceObj = transformSymbol({ price: arg[1] });
            newArrObj = priceObj;
        } else {
            newArrObj = [];
            // 多个价格对象数组
            arg[1].forEach((item) => {
                let itemPrice;
                let result = '';
                if (item.price !== undefined) {
                    itemPrice = item.price;
                } else {
                    itemPrice = item;
                }
                result = transformSymbol({ price: itemPrice });
                newArrObj.push(result);
            });
        }
        return newArrObj;
    },
    // 单个价格(round: 0-向下取整、1-四舍五入、2-向上取整)
    one: (price, round = 2, Symbol = true) => (Symbol ? transformSymbol : transform)({
        price,
        round,
    }),
    // 价格数组其余求和，求差
    sum: (...arg) => {
        const {
            prices, // 单个sku原价 prices[0] = {price, qty}
            discounts, // 单个sku优惠总计 discounts = [1, 2, 3]
            ladderPrices, // 单个sku总价 ladderPrices[0] = {price, qty, ...优惠项}
            Symbol = arg[0].Symbol === undefined ? true : arg[0].Symbol, // 输出是否要带货币符号
            // orig // 原始PHP值
        } = arg[0];

        let amount = 0;
        let discount = 0;
        let total = 0;

        if (ladderPrices && ladderPrices.length > 0) {
            ladderPrices.forEach((item) => {
                const skusum = add(multiply(item.price, item.qty), -item.activityDeductAmount);
                total = add(total, transform({
                    price: skusum,
                    round: 2,
                }));
            });
        } else {
            if (prices.length > 0) {
                prices.forEach((item) => {
                    amount = add(amount, multiply(transform({
                        price: item.price,
                        round: 2,
                    }), item.Qty || item.qty || 1));
                });
            }
            if (discounts.length > 0) {
                discounts.forEach((item) => {
                    discount = add(discount, transform({
                        price: item,
                        round: 0,
                    }));
                });
            }
            total = Math.abs(add(amount, -discount));
        }
        if (Symbol) {
            return addSymbol(total);
        }
        return total;
    }
};

Vue.prototype.$trans = trans;

Vue.prototype.$staticAsset = staticAsset;

Vue.prototype.currencyChange = Vue.prototype.remainderRule.currencyChange;

Vue.prototype.vueGlobal = { // 从网站读取到的全局配置信息
    payVars: win.payVars,
    GLOBAL
};

Vue.filter('onlyAddSymbol', (...arg) => addSymbol(arg[1]));

// 向上取整
Vue.filter('currencyChange', (...arg) => Vue.prototype.remainderRule.currencyChange.apply(null, [...arg]));

// 单个价格(arg[2] == 0 时向下取整， 默认向上取整)
Vue.filter('$remainder_one', (...arg) => {
    const round = arg[2] === undefined ? 2 : +arg[2];
    return Vue.prototype.remainderRule.one.call(null, arg[1], round);
});

// 价格求和
Vue.filter('$remainder_sum', (...arg) => Vue.prototype.remainderRule.sum.call(null, arg[1]));

// pricesList
Vue.filter('$remainder.pricesList', (...arg) => {
    const priceList = [];
    arg[1].forEach((item) => {
        const calcPrice = add(item.price, -item.activityDeductAmount, -item.couponDeductAmount, -item.integralDeductAmount);
        priceList.push({
            qty: item.qty,
            price: Vue.prototype.remainderRule.one.call(null, calcPrice)
        });
    });
    return priceList;
});

(async () => {
    getCurrency().then((currency) => {
        win.vuePayCart = new Vue({
            router,
            data: {
                currency,
                currenySign: currency.currencyCode
            },
            render: h => h(App),
        }).$mount('#app');
    });
})();
