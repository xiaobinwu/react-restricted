/**
 * Created by Liu Jun on 2019/3/14
 */

import generatorCookiePolicy from 'modules/cookie_policy/cookie_policy';
import indexSwiper from './component/indexSwiper/indexSwiper.js';
import indexScroll from './common/js/scrollHeaderTop';

export default () => {
    // 底部 cookie 提示
    generatorCookiePolicy();

    // swiper 初始化
    indexSwiper.init();

    // 滚动位置监听
    setTimeout(() => {
        indexScroll.init();
    }, 0);
};
