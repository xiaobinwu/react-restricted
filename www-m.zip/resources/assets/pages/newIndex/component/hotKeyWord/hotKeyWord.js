import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate';
import './hotKeyWord.css';
import hotKeyTemp from './hotKeyWord.art';

runtime.trans = trans;

const hotKeyModule = {
    $hotKeyHiden: $('.js-hotKey_hidden'),
    init(scrollAppend = true) {
        if (this.$hotKeyHiden.length) {
            const str = hotKeyTemp({
                relatedSearchText: this.$hotKeyHiden.data('relatedText'),
                lists: this.$hotKeyHiden.data('word')
            });
            if (scrollAppend) {
                $('.indexRecommend_list').append(str);
            } else {
                const $needHotPlace = $('.indexRecommend_list').find('.js-gbGoodsItem').eq(29);
                if ($needHotPlace.length) $needHotPlace.after(str);
            }
            this.hotKeyOperator();
        }
    },
    hotKeyOperator() {
        const $hotBody = $('.js-hotKeyWord_body');
        const $linkList = $('.js-hotKeyWord_linkList');
        const $hotKeyArrow = $('.js-hotKey_arrow');
        if ($linkList.height() > $hotBody.height()) {
            $hotKeyArrow.css('display', 'inline-block');
            $('.js-hotKeyWord_header').click((e) => {
                $hotBody.toggleClass('hide');
                $hotKeyArrow.toggleClass('rotating');
            });
        }
    }
};

export default hotKeyModule;
