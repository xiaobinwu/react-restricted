import 'component/star/star.js';
import layer from 'layer';
import { serviceCollectAdd, serviceGoodlistCollectRemove } from 'js/service/common';
import render from './indexRecommend_list.art';

const GoodsItemApp = {
    init({
        container = $(document),
        list = [],
    }) {
        if (list && list.length > 0) {
            container.append(render({ list }));
        }
        /**
         * 星星评分
         * @param {Object} rateCounte
         */
        const rateCounte = $('.js-star');
        if (typeof rateCounte !== typeof undefined && rateCounte !== false) {
            rateCounte.star();
        }

        // 避免多次调用
        if (!this.$isInit) {
            this.$isInit = true;
            container.on('click', '.js-opera', (e) => {
                e.preventDefault();
                const $this = $(e.currentTarget);
                GoodsItemApp.toggleCollect($this); // 切换收藏
            });
        }
    },
    /**
     * 添加收藏
     * @param {Object} $btn 操作按钮
     */
    async collect($btn) {
        const $likeCount = $btn.find('.js-likeCount');
        const dataSn = $btn.data('sku');
        const dataWid = $btn.data('wid');
        const viewStrNum = parseInt($likeCount.text(), 10);

        const data = await serviceCollectAdd.http({
            errorPop: false,
            data: {
                goods: [`${dataSn}_${dataWid}`],
            },
        });

        if (+data.status === 0) {
            if (!$btn.hasClass('isCollection')) {
                $btn.addClass('isCollection');
                if (viewStrNum >= 999) {
                    $likeCount.text('999+');
                } else {
                    $likeCount.text(`${viewStrNum + 1}`);
                }
            }
        } else if (data.data && data.data.redirectUrl) {
            window.location.href = data.data.redirectUrl;
        } else {
            layer.msg(data.msg);
        }
    },

    /**
     * 取消收藏
     * @param {Object} $btn 操作按钮
     */
    async cancelCollect($btn) {
        const $likeCount = $btn.find('.js-likeCount');
        const dataSn = $btn.data('sku').toString();
        const virCodex = $btn.data('vircode').toString();
        const viewStrNum = parseInt($likeCount.text(), 10);

        const data = await serviceGoodlistCollectRemove.http({
            errorPop: false,
            data: {
                goodSn: dataSn,
                virCode: virCodex,
            },
        });

        if (+data.status === 0) {
            $btn.removeClass('isCollection');
            if (viewStrNum >= 999) {
                $likeCount.text('999+');
            } else {
                $likeCount.text(`${viewStrNum - 1}`);
            }
        } else if (data.data && data.data.redirectUrl) {
            window.location.href = data.data.redirectUrl;
        } else {
            layer.msg(data.msg);
        }
    },

    /**
     * 切换收藏
     * @param {Object} $btn 操作按钮
     */
    toggleCollect($btn) {
        if ($btn.hasClass('isCollection')) {
            GoodsItemApp.cancelCollect($btn);
        } else {
            GoodsItemApp.collect($btn);
        }
    },
};
export default GoodsItemApp;
