import { throttle } from 'js/utils';
import PubSub from 'pubsub-js';

import { getRecom, showFilter, applyFilter } from '../filter/filter.js';
import staticRecom from '../../common/js/staticRecom';
import './indexRecommend.css';
import { appendRecomGoods } from '../../common/js/recomCore';
import hotKeyModule from '../hotKeyWord/hotKeyWord';

const singleCase = {
    async init() {
        const renderResult = staticRecom.pageShow();
        let initLength = 0;
        if (renderResult) {
            this.pageIndex = renderResult.page;
            this.totalPage = renderResult.totalPage;
        } else {
            initLength = await this.handleData();
        }
        if (renderResult || initLength) {
            $('.indexRecommend_headerWrap').addClass('active');
        }
        this.bindEvent();
    },
    $window: $(window),
    $document: $(document),
    pageIndex: 0, // 用于下次调取接口的页数
    reloading: true,
    totalPage: 0,
    $preLoading: $('.js-pageLoading'),
    screenHeight: $(window).height(),
    bindEvent() {
        const $recommendList = $('.indexRecommend_body .indexRecommend_list');
        $('.js-changeList').click((e) => {
            const $currentTarget = $(e.currentTarget);
            if ($recommendList.hasClass('indexRecommend_list-column')) {
                $recommendList.removeClass('indexRecommend_list-column');
                $currentTarget.addClass('icon-grid_small').removeClass('icon-grid_list_small');
            } else {
                $recommendList.addClass('indexRecommend_list-column');
                $currentTarget.addClass('icon-grid_list_small').removeClass('icon-grid_small');
            }
        });
        // 点击推荐商品保存当前推荐商品到session
        $recommendList.on('click', '.js-gbGoodsItem', () => {
            staticRecom.save();
            const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            staticRecom.historyReplace(scrollTop);
        });
        // 显示筛选
        $('.js-refineFilter').click(async () => {
            showFilter();
        });
        // apply筛选
        $('.filterGs_apply').click(async () => {
            this.pageIndex = 0;
            applyFilter();
            await this.handleData();
        });
        // 下拉加载
        PubSub.subscribe('nativeScroll', throttle(this.upFresh.bind(this), 300));
    },
    // 下拉加载操作
    async upFresh() {
        if (this.reloading && (this.pageIndex < this.totalPage) && this.$window.scrollTop() + this.screenHeight > this.$document.height() - 300) {
            await this.handleData();
        }
    },
    // service获取数据并插入
    async handleData() {
        this.reloading = false;
        this.$preLoading.show();
        const {
            goodsList, aggsData, status
        } = await getRecom(this.pageIndex);
        this.reloading = true;
        if (status === 0) {
            this.totalPage = aggsData.pagecount;
            if (!this.pageIndex) {
                staticRecom.remove();
            }
            staticRecom.set({
                aggsData,
                goodsList
            });
            this.pageIndex += 1;
            appendRecomGoods({
                goodsList,
                num: -30
            });
            if (this.pageIndex === 1) hotKeyModule.init();
            if (this.pageIndex >= this.totalPage) {
                this.$preLoading.hide();
            }
        }
        return goodsList ? goodsList.length : 0;
    }
};
export default singleCase;
