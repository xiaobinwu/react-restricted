import './indexAd.css';

