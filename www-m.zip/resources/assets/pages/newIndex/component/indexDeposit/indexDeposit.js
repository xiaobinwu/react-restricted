import layer from 'layer';
import PubSub from 'pubsub-js';
import Cookies from 'js/utils/cookie';
import runtime from 'art-template/lib/runtime';
import Timer from 'component/timer/timer';
import { trans } from 'js/core/translate.js';
import { serviceDepositRemind } from 'js/service/common';
import { COOKIE_IS_VIEW, COOKIE_MUID } from 'js/variables';
import renderDeposit from './indexDeposit_tpl.art';

import './indexDeposit.css';

runtime.trans = trans;

const depositCase = {
    init() {
        this.bindEvent();
    },
    timerHandle() {
        const timer = new Timer();
        const depositTimer = $('.js-indexDepositTimer');
        if (depositTimer.length) {
            timer.add(depositTimer, {
                format: `<em class="font_normal">${trans('base.deposit_index_order_tips')}</em> {dd}:{hh}:{mm}:{ss}`,
                interval: 'end',
            });
        }
    },
    reBindEvent() {
        this.timerHandle();
    },
    bindEvent() {
        try {
            if (Cookies.get(COOKIE_MUID) && !Cookies.get(COOKIE_IS_VIEW)) {
                serviceDepositRemind.http({
                    errorPop: false,
                }).then((res) => {
                    if (+res.status === 0) {
                        if (res.data && typeof res.data.orderSn !== typeof undefined && res.data.orderSn !== false) {
                            layer.open({
                                content: renderDeposit({
                                    renderTimer: res.data.endTime,
                                    renderSn: res.data.orderSn,
                                    renderImg: res.data.goodsImg,
                                    renderNumber: res.data.orderCount
                                }),
                                area: '400px',
                                btn: [trans('base.deposit_index_pay_now'), trans('base.deposit_index_later')],
                                shadeClose: false,
                                skin: 'siteFooter_amountCenter',
                                shade: 'background-color: rgba(0,0,0,.8)',
                                yes: (index) => {
                                    window.location.href = `${GLOBAL.DOMAIN_USER}/index#/order/list?index=1`;
                                },
                                no: (index) => {
                                    layer.close(index);
                                }
                            });
                            this.reBindEvent();
                            Cookies.set(COOKIE_IS_VIEW, 'true', { expires: 1 });
                        }
                    } else {
                        layer.msg(res.msg);
                    }
                });
                console.warn('cookie expire!');
            } else {
                console.warn('cookie exists!');
            }
        } catch (error) {
            // error...
        }
    }
};

PubSub.subscribe('nativeLoad', () => {
    depositCase.init();
});
