import { serviceIPBanner } from 'js/service/common';
import { getSelectorAll, getSelector } from 'js/utils/similarjQ';
import { getCdnCountryCode } from 'js/core/currency.js';
import getUserStatus from 'js/core/user/getUserStatus.js';
import { EMPTY_IMG } from 'js/variables.js';

/**
 * 广告位根据IP来显示
 * 通过异步请求广告位数据
 * 顶部横幅：9-10
 * 首页大banner：1-4
 * 首页背景:1-5
 * 首页中: 1-2  4个广告位
 * 首页活动广告位：1-40: 1个
 * 闪购banner:13-16
 */

function removeLoading(dom) {
    dom.classList.remove('box-loading');
}

// 数据为空的时候回退到原数据
const renderByPosition = {
    '1-4': function banner14(bannerData) {
        if (bannerData.length <= 0) return;
        // 首页大banner '1-4' 需要根据order来排序
        const banObj = {};
        bannerData.forEach((value) => {
            const str = `
                            <a data-order="${value.order}" href="${value.banner_link}" class="indexSwiper_item swiper-slide indexBan_slickItem"
                            data-track-key="${value.id}" data-track-module="A_1">
                                <img class="swiper-lazy"
                                src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
                                data-src="${value.banner_url}" />
                            </a>`;
            if (banObj[value.order]) {
                banObj[value.order].push(str);
            } else {
                banObj[value.order] = [str];
            }
        });
        getSelectorAll('.indexBan_slickItem').forEach((ele) => {
            const order = ele.dataset.order;
            if (banObj[order]) {
                banObj[order].push(ele);
            } else {
                banObj[order] = [ele];
            }
        });
        const fragment = getSelector('.js-indexSwiper .swiper-wrapper');
        fragment.innerHTML = '';
        Object.entries(banObj).reverse().forEach(([key, eleArr]) => {
            eleArr.forEach((currentEle) => {
                if (currentEle.nodeType === 1) {
                    fragment.insertAdjacentElement('beforeend', currentEle);
                } else {
                    fragment.insertAdjacentHTML('beforeend', currentEle);
                }
            });
        });
    },
    '1-40': function banner140(bannerData) {
        // 首页活动广告位
        const domBanner = getSelector('.js_indexBannerLink');
        if (!domBanner) return;

        // 测试数据
        // bannerData[0].order = 10085;

        if (domBanner && bannerData.length > 0 && bannerData[0].order > Number(domBanner.dataset.order)) {
            const curBanner = bannerData[0];

            // reset dataset
            domBanner.dataset.order = curBanner.order;
            domBanner.dataset.trackKey = curBanner.id;

            // reset attr
            domBanner.href = curBanner.banner_link;
            getSelector('.indexBanner_img', domBanner).src = curBanner.banner_url;
        }

        // remove loading;
        removeLoading(domBanner);
    },
    '1-2': function banner12(bannerData) {
        // 首页中,4个
        const domParent = getSelector('.js_idnexAd');
        if (!domParent) return;

        if (bannerData.length > 0) {
            // order 对比
            const maxNum = 4;
            const domLinks = getSelectorAll('.indexAd_item', domParent);

            // 执行替换或者插入
            const fragment = document.createDocumentFragment();
            const orderDomObj = {};

            // 旧的dom节点
            domLinks.forEach((item) => {
                getSelector('.js_idnexAdImg', item).classList.add('js-lazyload');
                orderDomObj[+item.dataset.order] = item;
            });

            // 生成新的元素
            bannerData.forEach((item) => {
                const itemStr = `<a class="indexAd_item box-loading" href="${item.banner_link}"
                            data-order="${item.order}"
                            data-track-key="${item.id}">
                        <img class="js_idnexAdImg js-lazyload" data-lazy="${item.banner_url}" src="${EMPTY_IMG}">
                    </a>`;
                orderDomObj[+item.order] = itemStr;
            });

            // 插入元素
            Object.entries(orderDomObj).reverse().slice(0, maxNum).forEach(([order, value]) => {
                if (value.nodeType === 1) {
                    fragment.appendChild(value);
                } else {
                    fragment.appendChild(document.createRange().createContextualFragment(value));
                }
            });

            domParent.innerHTML = '';
            domParent.appendChild(fragment);
        }

        getSelectorAll('.js_idnexAdImg', domParent).forEach((domItem) => {
            domItem.classList.add('js-lazyload');
        });
    },
};

async function pipeline() {
    // if (GLOBAL.PIPELINE !== 'GB') return;
    const curPosition = ['1-4', '1-40', '1-2'];

    try {
        const country = await getCdnCountryCode();
        const userStatus = getUserStatus({
            toLogin: false
        });

        const { status, data } = await serviceIPBanner.http({
            params: {
                position: curPosition.join('_'),
                count: '5_1_4',
                tab_id: $('.cateTopLists_item.active').find('.js-cateTop').data('id'),
                country,
                user_status: userStatus.isLogin ?
                    (userStatus.user ? (undefined === userStatus.user.isNewUser ? '' : userStatus.user.isNewUser) : '')
                    : ''
            }
        });

        if (status === 0) {
            // 按模块执行对应的render方法
            Object.entries(data).forEach(([posi, value]) => {
                renderByPosition[posi].call(renderByPosition, value);
            });
        } else {
            throw new Error('异步banner接口异常');
        }
    } catch (e) {
        console.log(e);
        // fallback
        curPosition.forEach((item) => {
            renderByPosition[item].call(renderByPosition, []);
        });
    }
}

export default pipeline;
