import { throttle } from 'js/utils';
import PubSub from 'pubsub-js';
import './indexSwiper.css';

const singleCase = {
    init() {
        this.bindEvent();
    },
    async bindEvent() {
        const $indexBan = $('.indexBan_slickItem');
        if ($indexBan.length > 1) {
            const { default: Swiper } = await import('js/lib/swiper.js');
            const indexSwiper = new Swiper('.js-indexSwiper', {
                pagination: {
                    el: '.swiper-pagination',
                },
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                loop: true,
                lazy: {
                    loadPrevNext: true
                }
            });

            const $indexSwiper = $('.js-indexSwiper');
            // 大banner底部距页面顶部距离
            const bannerBottomPos = $indexSwiper.offset().top + $indexSwiper.height();

            PubSub.subscribe('nativeScroll', throttle(() => {
                const scrollTop = $(window).scrollTop();
                if (scrollTop < bannerBottomPos) { // banner在可视区 要开启自动轮播
                    if (!indexSwiper.autoplay.running) {
                        indexSwiper.autoplay.start();
                    }
                } else if (indexSwiper.autoplay.running) {
                    indexSwiper.autoplay.stop();
                }
            }), 300);
        }
    },
};

export default singleCase;
