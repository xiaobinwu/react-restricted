import './indexSale.css';

// 秒杀倒计时
async function spkieTimer() {
    if ($('#js-timerSpike').length) {
        const { default: Timer } = await import('component/timer/timer');
        new Timer('#js-timerSpike', {
            format: '<b>{hh}</b>:<b>{mm}</b>:<b>{ss}</b>',
            interval: 'end'
        });
    }
}
spkieTimer();
