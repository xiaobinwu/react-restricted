import GoodsViewHistory from 'js/core/goods/goodsViewHistory.js';
import { getCurrency, divide, transform, toFixed } from 'js/core/currency.js';
import { layerHide, layerShow } from 'component/toggleLayer/toggleLayer';
import { getIndexRecommend } from 'js/service/other.js'; // AI推荐接口
import borderStopScroll from 'component/borderStopScroll';

import { getFilter } from '../../common/js/recomCore';
import './filter.css';

const $brandFilter = $('.js-brandFilter');
const $cateFilter = $('.js-cateFilter');

// 筛选框显示隐藏操作
function filterShowHandle() {
    const $sideContai = $('.js-sideContainer');
    const $jsFilterItemClose = $('.js-filterItemClose');
    // 筛选项的子分类隐藏
    function closeFilterItem() {
        $jsFilterItemClose.hide();
        layerHide($('.filterItem_wrap.active'), 'active');
    }
    function closeFilter() {
        layerHide($sideContai, 'active');
        closeFilterItem();
    }
    $('.js-filterClose').click((e) => {
        closeFilter();
    });
    $sideContai.click(() => {
        closeFilter();
    });
    $sideContai.find('.filterGs_wrap').click((e) => {
        e.stopPropagation();
    });
    $('.js-filterGs_item').click((e) => {
        const $this = $(e.currentTarget);
        layerShow($this.find('.filterItem_wrap'), 'active');
        $jsFilterItemClose.show();
    });
    $jsFilterItemClose.click(() => {
        closeFilterItem();
    });
}

// 获取推荐商品
let cateSelected = {};
let brandSelected = {};
const id = window.indexTabId;
const $hideLowPrice = $('.js-hideLowPrice');
const $hideHighPrice = $('.js-hideHighPrice');
const userCateId = GoodsViewHistory.get().slice(0, 3).map(value => value.categoryId);
let firstGeneratorFilter = false;
function getDollarNum($ele) {
    let result = Number(toFixed($ele.data('currency'), 2));
    if (result === 0) {
        result = '';
    }
    return result;
}
async function getRecom(page) {
    // 设置货币符号
    const priceMin = getDollarNum($hideLowPrice);
    const priceMax = getDollarNum($hideHighPrice);
    const res = await getIndexRecommend({
        pageindex: page,
        ortherparams: {
            id,
            cat_id: Object.keys(cateSelected).join(','),
            brand_code: Object.keys(brandSelected).join(','),
            price_min: priceMin || '',
            price_max: priceMax || '',
            user_cat_id: userCateId.join(','),
        }
    });
    if (res.status === 0) {
        const {
            aggsData = {}, data = {}
        } = res;
        const goodsList = data;

        if (!firstGeneratorFilter) {
            firstGeneratorFilter = true;
            getFilter(aggsData);
        }
        return {
            goodsList, aggsData, status: res.status
        };
    }
    return {};
}

// 更新筛选输入框货币
async function updateFilterInput() {
    const currentCurrency = await getCurrency();
    $('.js-filter_currencySign').html(currentCurrency.currencySign);
    const $lowPrice = $('.js-lowPrice');
    if ($lowPrice.val().trim() !== '') {
        $lowPrice.val(transform({ price: toFixed($hideLowPrice.data('currency'), 5, 0) }));
    }
    const $highPrice = $('.js-HighPrice');
    if ($highPrice.val().trim() !== '') {
        $highPrice.val(transform({ price: toFixed($hideHighPrice.data('currency'), 5, 0) }));
    }
}
// 显示筛选框
function showFilter() {
    layerShow('.js-sideContainer', 'active');
    updateFilterInput();
}

// apply
function applyFilter() {
    $('.indexRecommend_list').empty();
    layerHide('.js-sideContainer', 'active');
    $('.js-filterItemClose').hide();
    $('.filterItem_wrap.active').removeClass('active').css('display', 'none');
}

const singleCase = {
    syncFilterPrice() {
        function updateHidePrice(event) {
            const $this = $(event.target);
            const val = $this.val();
            getCurrency().then((data) => {
                const dollarVal = divide(val, data.currencyRate);
                $this.next().attr('data-currency', dollarVal);
            });
        }

        $('.js-lowPrice').on('input', (e) => {
            updateHidePrice(e);
        });
        $('.js-HighPrice').on('input', (e) => {
            updateHidePrice(e);
        });
    },
    init() {
        this.bindEvent();
        this.syncFilterPrice();
    },
    bindEvent() {
        filterShowHandle();
        borderStopScroll({
            wrapEle: document.querySelector('.js-filterGs_wrap')
        });
        borderStopScroll({
            wrapEle: $brandFilter[0]
        });
        borderStopScroll({
            wrapEle: $cateFilter[0]
        });
        // 选中分类
        $cateFilter.on('click', '.js-check_filterItem', (e) => {
            if (e.target.type !== 'checkbox') {
                const $this = $(e.currentTarget);
                const cateId = $this.data('cat_id');
                if (cateSelected[cateId]) delete cateSelected[cateId];
                else cateSelected[cateId] = 1;
            }
        });
        // 选中品牌
        $brandFilter.on('click', '.js-check_filterItem', (e) => {
            if (e.target.type !== 'checkbox') {
                const $this = $(e.currentTarget);
                const brandCode = $this.data('brand_code');
                if (brandSelected[brandCode]) delete brandSelected[brandCode];
                else brandSelected[brandCode] = 1;
            }
        });
        // reset
        const $lowPrice = $('.js-lowPrice');
        const $highPrice = $('.js-HighPrice');
        $('.filterGs_reset').click(() => {
            cateSelected = {};
            brandSelected = {};
            $lowPrice.val('');
            $highPrice.val('');
            $hideLowPrice.attr('data-currency', '0');
            $hideHighPrice.attr('data-currency', '0');
            $('.js-filterGs_item').find('.js-filterCheckbox:checked').prop('checked', false);
        });
    },
};
singleCase.init();
export {
    getRecom,
    showFilter,
    applyFilter,
};

