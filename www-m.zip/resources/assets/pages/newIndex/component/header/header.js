import PubSub from 'pubsub-js';
import headerCateNav from 'modules/header/header_cate_nav';
import { reviewsABTest } from 'js/core/goods/reviewsABtest.js';
import './header.css';

function scrollCate() {
    // 头部分类
    const $cateActive = $('.cateTopLists_item.active');
    if ($cateActive.length === 0) return;
    const cateCenterOffsetX = $cateActive.offset().left + ($cateActive.width() / 2); // 选中元素中心距离容器(UL)距离
    const screenWidth = $('body').width(); // 屏幕宽度
    const scrollX = cateCenterOffsetX - (screenWidth / 2); // 应该滚动的距离
    const cateListsWidth = $('.cateTopLists').width(); // 容器元素宽度
    const cateTopEle = document.querySelector('.cateTop');
    if (cateListsWidth - cateCenterOffsetX > (screenWidth / 2)) {
        cateTopEle.scrollLeft = scrollX;
    } else {
        cateTopEle.scrollLeft = cateListsWidth - screenWidth;
    }
}
// 分类馆所有Id 存储在localStorage
function setLocalCateIds() {
    const $jsCateTop = $('.js-cateTop');
    const objs = {
        urls: [],
        catIds: []
    };
    $jsCateTop.each((index, value) => {
        objs.urls.push(value.getAttribute('href'));
        objs.catIds.push(value.getAttribute('data-cat_ids'));
    });
    window.sessionStorage.setItem('catIdsUrls', JSON.stringify(objs));
}

const singleCase = {
    init() {
        this.bindEvent();
        this.nextEvent();
        PubSub.publish('sysUpdateUserStatus');
        setLocalCateIds();
        reviewsABTest.init();
    },
    bindEvent() {
        scrollCate();

        // 设置顶部高度
        const $fixedHeader = $('.js-fixedHeader');
        $fixedHeader.addClass('fixedHeader');
        $('.topHeader').css('height', $fixedHeader.height());

        // 馆区跳转加lang
        $('.js-cateTop').each((index, value) => {
            const $this = $(value);
            const preHref = $this.attr('href');
            const href = `${preHref}?lang=${window.GLOBAL.LANG}`;
            $this.attr('href', href);
        });

        // 分类栏加载资源，针对首页
        // let firstTimeCate = 0;
        // $('.js-cateBtn').click(() => {
        //     if (!firstTimeCate) {
        //         firstTimeCate = 1;
        //         import('common/css/footerFontIcon/iconfont.css');
        //     }
        // });
    },
    nextEvent() {
        setTimeout(() => {
            headerCateNav.init();
        }, 0);
    },
};
export default singleCase;
