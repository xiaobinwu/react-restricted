import './component/indexAd/indexAd.js';
import './component/indexBanner/indexBanner.js';
import './component/indexCategory/indexCategory.js';
import './component/indexSale/indexSale.js';
import './component/indexDeposit/indexDeposit.js';

