import asyncPriceDiscount from 'js/core/goods/asyncPriceDiscount';
import GoodsItemApp from '../../component/indexRecommend/component/indexRecommend_list';

export function appendRecomGoods({
    goodsList,
    num,
}) {
    const $indexRecommendList = $('.indexRecommend_list');
    GoodsItemApp.init({
        container: $indexRecommendList,
        list: goodsList
    });
    let asyncElement = $indexRecommendList.find('.js-asyncPrice');
    if (num) {
        asyncElement = asyncElement.slice(num);
    }
    asyncPriceDiscount({
        elementLists: asyncElement,
        shopPriceClassName: '.gbGoodsItem_oldPrice',
        callback({ $eleShopPrice }) {
            $eleShopPrice.removeClass('hide');
        }
    });
}

export function getFilter(aggsData) {
    // 分类
    let categoryStr = '';
    if (aggsData.catlist) {
        aggsData.catlist.forEach((value, index) => {
            categoryStr += `
                <li class="filterItem js-check_filterItem" data-cat_id="${value.catId}">
                    <label class="filterItem_checkboxItem">
                        <span class="checkSale_txt font-28">${value.catName}</span>
                        
                        <input type="checkbox" class="js-filterCheckbox">
                        <span class="cate_checkBox check_shape"></span>
                        <!--<span class="checkSale_btn"></span>-->
                    </label>
                </li>
            `;
        });
        $('.js-cateFilter').html(categoryStr);
    }
    if (!categoryStr) {
        $('.js-filterGs_item').eq(0).remove();
    }

    // 品牌
    let brandStr = '';
    if (aggsData.brandlist) {
        aggsData.brandlist.forEach((value, index) => {
            brandStr += `
            <li class="filterItem js-check_filterItem" data-brand_code="${value.brandCode}">
                <label class="filterItem_checkboxItem">
                    <span class="checkSale_txt font-28">${value.brandName}</span>
                
                    <input type="checkbox" class="js-filterCheckbox">
                    <span class="cate_checkBox check_shape"></span>
                    <!--<span class="checkSale_btn"></span>-->
                </label>
            </li>
        `;
        });
        $('.js-brandFilter').html(brandStr);
    }
    if (!brandStr) {
        $('.js-filterGs_item').eq(1).remove();
    }
}
