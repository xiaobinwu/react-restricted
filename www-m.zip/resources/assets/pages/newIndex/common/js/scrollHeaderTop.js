import { throttle } from 'js/utils';
import PubSub from 'pubsub-js';
import StateBuffer from 'js/utils/StateBuffer';

import Extension from '../../../goods/component/extension/extension';

const indexScroll = {
    top: 0, // 滚动距离
    scrollLock: false,
    init() {
        this.scrollHeaderTop();
        this.initExtension();
    },
    initExtension() {
        const that = this;
        new Extension({
            callback: (self) => {
                $('.topHeader').css('height', $('.js-fixedHeader').height());
                const headerHeight = self.$box.height();
                const domFixedHeader = document.querySelector('.fixedHeader');
                const TRANSFORM = ['transform', 'webkitTransform', 'MozTransform', 'msTransform', 'OTransform'];

                const statusAppDown = new StateBuffer('show');
                const throttleIndexFn = () => {
                    if (self.$box.data('close') === 1 || that.scrollLock) return;
                    if ($(window).scrollTop() >= headerHeight) {
                        statusAppDown.on('hide', () => {
                            TRANSFORM.forEach((item) => {
                                domFixedHeader.style[item] = `translateY(-${headerHeight}px)`;
                            });
                        });
                    } else {
                        statusAppDown.on('show', () => {
                            TRANSFORM.forEach((item) => {
                                domFixedHeader.style[item] = 'translateY(0)';
                            });
                        });
                    }
                };
                PubSub.subscribe('nativeScroll', throttle(throttleIndexFn, 80));
            },
            pageType: 'index'
        });
    },
    // 滚动头部置顶
    scrollHeaderTop() {
        const self = this;
        const indexSwiperEle = document.querySelector('.indexSwiper');
        const $toTop = $('.js-bottomTopBtn');
        let toTopY = 400;
        const headerHeight = $('.siteHeader').height();
        const totalHeadMoveHigh = $('.js-openAppBox').height() + headerHeight;
        const $cateTop = $('.js-cateTop_nav');
        const cateTopHeight = $cateTop.height() || 0;
        const $indexRecommend = $('.indexRecommend');
        const $indexRecommendHeader = $('.indexRecommend_header');
        // const $jsFixedHeader = $('.js-fixedHeader');
        let recommendY;

        function recomAddClass(className) {
            $indexRecommendHeader.attr('class', `indexRecommend_header ${className}`);
            // $jsFixedHeader.addClass('noShadow');
        }
        function recomRemoveClass() {
            $indexRecommendHeader.attr('class', 'indexRecommend_header');
            // $jsFixedHeader.removeClass('noShadow');
        }

        function topMove() {
            $cateTop.removeClass('hide');
            recomRemoveClass();
        }

        if (indexSwiperEle) {
            const react = indexSwiperEle.getBoundingClientRect();
            toTopY = react.bottom + window.pageYOffset;
        }

        const stateToTop = new StateBuffer('hide');
        const stateCateTop = new StateBuffer('show');
        const stateRecom = new StateBuffer('relative');

        PubSub.subscribe('nativeScroll', throttle(() => {
            if (self.scrollLock) return;
            const scrollTop = window.pageYOffset;
            if (scrollTop > toTopY) {
                stateToTop.on('show', () => {
                    $toTop.addClass('show');
                });
            } else {
                stateToTop.on('hide', () => {
                    $toTop.removeClass('show');
                });
            }

            if (scrollTop <= totalHeadMoveHigh) {
                stateCateTop.on('show', () => {
                    topMove();
                });
            } else {
                recommendY = $indexRecommend.offset().top;
                const dire = self.scrollDirection(scrollTop);
                if (dire === 'stop') return;
                if (dire === 'down') {
                    stateCateTop.on('hide', () => {
                        $cateTop.addClass('hide');
                    });
                    if (recommendY - scrollTop <= headerHeight) {
                        stateRecom.on('fixed', () => {
                            recomAddClass('indexRecommend_header-fixed');
                        });
                    } else {
                        stateRecom.on('relative', () => {
                            recomRemoveClass();
                        });
                    }
                } else {
                    stateCateTop.on('show', () => {
                        $cateTop.removeClass('hide');
                    });
                    if (recommendY - scrollTop <= headerHeight + cateTopHeight) {
                        stateRecom.on('fixedUp', () => {
                            if (cateTopHeight) {
                                recomAddClass('indexRecommend_header-fixedNav');
                            } else {
                                recomAddClass('indexRecommend_header-fixed');
                            }
                        });
                    } else {
                        stateRecom.on('relative', () => {
                            recomRemoveClass();
                        });
                    }
                }
            }
        }, 80));

        // 置頂
        $toTop.on('tap', () => {
            const scrollTop = window.pageYOffset;
            self.scrollLock = true;
            document.body.style.transform = `translate3d(0, ${scrollTop}px, 0)`;

            $toTop.removeClass('show');
            $('.fixedHeader').css('transform', 'translateY(0)');
            topMove();
            setTimeout(() => {
                document.body.style.transform = 'initial';
                if (document.documentElement.scrollTop) {
                    document.documentElement.scrollTop = 0;
                } else {
                    document.body.scrollTop = 0;
                }
            }, 0);
            setTimeout(() => {
                self.scrollLock = false;
            }, 50);
        });

    },
    // 判断滚动方向
    scrollDirection(scrollTop) {
        if (scrollTop > this.top) {
            this.top = scrollTop;
            return 'down';
        } else if (scrollTop === this.top) {
            return 'stop';
        }
        this.top = scrollTop;
        return 'up';
    },
};

export default indexScroll;
