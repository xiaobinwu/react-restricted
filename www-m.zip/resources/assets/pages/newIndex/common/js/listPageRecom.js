import { STORAGE_INDEX_RECOM } from 'common/js/variables';

import GoodsItem from '../../../category/component/goods_item/goods_item';
import tempaddon from '../../../../pages/addon/addon.art';

class StaticRecom {
    page = 0;

    pool = [];

    set(recom) {
        this.page += 1;
        this.pool.push(recom);
    }

    get() {
        return this.pool;
    }

    remove() {
        this.page = 0;
        this.pool = [];
    }

    save() {
        window.sessionStorage.setItem(STORAGE_INDEX_RECOM, JSON.stringify(this.pool));
    }

    out() {
        return JSON.parse(window.sessionStorage.getItem(STORAGE_INDEX_RECOM) || '[]');
    }

    historyReplace(scrollTop) {
        window.history.replaceState('', '', `#recomIndex_${scrollTop}`);
    }

    pageShow(type, activityId) {
        const self = this;
        let renderResult = false;
        const currentHash = window.location.hash;
        if (currentHash.includes('recomIndex_')) {
            renderResult = self.renderRecom(type, activityId);
            const scrollTop = currentHash.split('_')[1] || 0;
            setTimeout(() => {
                $(window).scrollTop(scrollTop);
            }, 0);
            window.location.hash = '';
        }
        return renderResult;
    }

    renderRecom(type = '', activityId = '') {
        const indexRecom = this.out();
        let $panelList = $('.js-panelList');

        if (+type === 2) {
            $panelList = $('.js-catelistWrap');
        }

        let goodsList = [];
        this.pool = indexRecom;
        this.page = indexRecom.length + 1;
        if (this.page <= 1) return false;
        let totalPage = 0;
        indexRecom.forEach((value) => {
            totalPage = value.totalPage;
            goodsList = [].concat(goodsList, value.listDate);
        });

        // 向当前分类容器追加数据
        if (type === 'addon') {
            const addonBox = $('.js-addonItemBox');
            addonBox.append(tempaddon({
                goodsList,
                activityId,
            }));
        } else {
            GoodsItem.init({
                container: $panelList,
                type,
                list: goodsList,
                append: true,
            });
        }

        return {
            page: this.page,
            totalPage
        };
    }
}

export default new StaticRecom();
