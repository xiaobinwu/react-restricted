import { STORAGE_INDEX_RECOM } from 'common/js/variables';

import { appendRecomGoods, getFilter } from './recomCore';
import hotKeyModule from '../../component/hotKeyWord/hotKeyWord';

class StaticRecom {
    page = 0;

    pool = [];

    set(recom) {
        this.page += 1;
        this.pool.push(recom);
    }

    get() {
        return this.pool;
    }

    remove() {
        this.page = 0;
        this.pool = [];
    }

    save() {
        window.sessionStorage.setItem(STORAGE_INDEX_RECOM, JSON.stringify(this.pool));
    }

    out() {
        return JSON.parse(window.sessionStorage.getItem(STORAGE_INDEX_RECOM) || '[]');
    }

    historyReplace(scrollTop) {
        window.history.replaceState('', '', `#recomIndex_${scrollTop}`);
    }

    pageShow() {
        const self = this;
        let renderResult = false;
        const currentHash = window.location.hash;
        if (currentHash.includes('recomIndex_')) {
            renderResult = self.renderRecom();
            const scrollTop = currentHash.split('_')[1] || 0;
            setTimeout(() => {
                $(window).scrollTop(scrollTop);
            }, 0);
            window.location.hash = '';
        }
        return renderResult;
    }

    renderRecom() {
        const indexRecom = this.out();
        let goodsList = [];
        let totalPage = 0;
        this.pool = indexRecom;
        this.page = indexRecom.length;
        if (this.page === 0) return false;
        indexRecom.forEach((value) => {
            totalPage = value.aggsData.pagecount;
            goodsList = [].concat(goodsList, value.goodsList);
        });

        appendRecomGoods({
            goodsList
        });
        hotKeyModule.init(false);
        getFilter(indexRecom[0].aggsData);
        return {
            page: this.page,
            totalPage,
        };
    }
}

export default new StaticRecom();
