import 'js/bootstrap';
import { trans } from 'js/core/translate';
import runtime from 'art-template/lib/runtime';
import PubSub from 'pubsub-js';
import newIndexTrack from 'js/track/define/newIndex';
import pipeline from './component/pipeline/pipeline.js'; // 广告位根据IP来显示
import header from './component/header/header.js';
import indexRecommend from './component/indexRecommend/indexRecommend.js';

import './newIndex.css';
import './mixIndex';

/**
 * 首屏样式
 */

import './component/header/headerFirstView.css';

import './component/indexSwiper/indexSwiperFirstView.css';

import './component/indexRecommend/indexRecommendFirstView.css';

runtime.trans = trans;

// 根据ip做动态banner 调整
const doPipeline = pipeline().then(() => {
    // 大数据埋点  推荐位需要突变
    newIndexTrack();

    // 推荐位
    indexRecommend.init();
});

// DOMContentLoad
PubSub.subscribe('nativeReady', () => {
    // 头部操作异步加载
    header.init();
});

PubSub.subscribe('nativeLoad', async () => {
    // 处理好dom节点再做 swiper轮播
    await doPipeline;
    const { default: asyncNewIndex } = await import('./asyncNewIndex.js');
    asyncNewIndex();
});
