import 'js/bootstrap';
import 'modules/header/header.js';
import Track from 'js/track/track';
import './brand_wall.css';

const brandWallTrack = new Track({
    page: true
});
brandWallTrack.run();

$('.js-chooseSec').on('tap', '.brandAside_item', (e) => {
    const $this = $(e.currentTarget);
    const $contain = $('.js-brandContain');
    const index = $this.index();
    const $target = $contain.find('section').eq(index);
    const siteHeaderH = $('.siteHeader').height();
    const offsetTop = $target.offset().top - siteHeaderH;
    $(window).scrollTop(offsetTop);
    $this.addClass('brandAside_item-active').siblings('.brandAside_item').removeClass('brandAside_item-active');
});
