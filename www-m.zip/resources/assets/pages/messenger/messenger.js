import 'js/lib/zepto/fx.js';
import 'js/bootstrap';
import Share from 'component/share/share.js';
import Swiper from 'js/lib/swiper.js';
import layer from 'layer';
import { calcRemToPx } from 'js/utils';
import 'component/simple_rotate/simple_rotate.js';
import Clipboard from 'clipboard';
import PubSub from 'pubsub-js';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import isLogin from 'js/core/user/isLogin';
import 'modules/header/header.js';
import 'modules/footer/footer.js';

// 异步请求
import { serviceMessengerChance, serviceMessengerShare } from 'js/service/promotion.js';

import './messenger.css';

const { DOMAIN_LOGIN } = GLOBAL;
const mIsLogin = isLogin();

/* 开始转盘 */
let isRunning = 0; // 设定一个flag,防止转盘在转动时，用户还可以抽奖  0表示转盘不转，1表示转
$('.js-start').on('tap', (event) => {
    const $this = $(event.currentTarget);
    if (mIsLogin) {
        if (!isRunning) {
            isRunning = 1;
            $this.css('transform', 'scale(1.2)'); // 放大开始按钮
            new Promise((resolve, reject) => {
                setTimeout(async () => {
                    $this.css('transform', 'scale(1)'); // 还原开始按钮
                    const activityId = $('.js-start').data('lottery');
                    const { data, status } = await getPrize(activityId); // 异步接口获取获奖结果
                    if (status === 0 && data.prizeDescInfo) {
                        const rotateAngle = getRotateAngle(data.prizeDescInfo.giftIndex); // 根据奖品结果计算旋转角度
                        startRunRotate(rotateAngle, data.prizeDescInfo.prizeTips, resolve); // 开始旋转
                    } else {
                        resolve();
                    }
                }, 500);
            }).then(() => {
                isRunning = 0;
            });
        }
    } else {
        window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
    }
});

async function getPrize(activityId) {
    try {
        const res = await serviceMessengerChance.http({
            method: 'POST',
            loading: false,
            errorPop: true,
            data: {
                activityId
            }
        });
        return res;
    } catch (error) {
        throw new Error(error);
    }
}

function getRotateAngle(prizeId) {
    const firstDeg = 22.5;
    const baseDeg = 45;
    const times = 2;
    let angle = 0;
    switch (prizeId) {
    case 0:
        angle = (360 * times) + (baseDeg * 2) + firstDeg;// first prize
        break;
    case 1:
        angle = (360 * times) + firstDeg;// coupon(黄)
        break;
    case 2:
        angle = (360 * times) + baseDeg + firstDeg; // 5 Point
        break;
    case 3:
        angle = (360 * times) + (baseDeg * 6) + firstDeg; // coupon(蓝)
        break;
    case 4:
        angle = (360 * times) + (baseDeg * 5) + firstDeg; // second prize
        break;
    case 5:
        angle = (360 * times) + (baseDeg * 4) + firstDeg; //  coupon(红)
        break;
    case 6:
        angle = (360 * times) + (baseDeg * 3) + firstDeg; // 10 GB points
        break;
    case 7:
        angle = (360 * times) + (baseDeg * 7) + firstDeg; // good lucky next time
        break;
    default:
        angle = 0;
    }
    return angle;
}

function startRunRotate(angle, tip, resolve) {
    $('.messengerWrap_img-table').simpleRotate({
        duration: 3000,
        // animateTo: roData[Math.floor(Math.random() * roData.length)] + 3600,
        animateTo: angle,
        async callback() {
            const prizeSuccessTemp = await import('./component/winning.art');
            layer.open({
                content: prizeSuccessTemp({ msg: tip }),
                className: 'play_info',
                btn: false,
                closeBtn: 0,
                shadeClose: false,
            });
            resolve();
        }
    });
}

/* 怎么玩弹窗 */
$('.js-howPlayBtn').on('tap', () => {
    howplayer();
});
function howplayer() {
    layer.open({
        content: $('#js-howPlay')[0].outerHTML,
        className: 'play_info',
        btn: false,
        closeBtn: 0,
        shadeClose: false,
    });
}

/* 列表滚动事件 */
const $winnerDiv = $('.js-winner');
const $ul = $winnerDiv.find('ul');
if ($ul.height() > $winnerDiv.height()) {
    marquee($ul, 40);
}
function marquee(obj, _speed) {
    let top = 0;
    let margintop;
    setInterval(() => {
        top += calcRemToPx(1);
        margintop = 0 - top;
        obj.animate({
            marginTop: margintop
        }, 0, function animation() {
            const s = Math.abs(parseInt($(this).css('margin-top'), 10));
            if (s >= calcRemToPx(100)) {
                top = 0;
                const $this = $(this);
                $this.css('margin-top', 0); // 确保每次都是从0开始，避免抖动
                $this.find('li').slice(0, 2).appendTo($(this));
            }
        });
    }, _speed);
}

/* Deals 切换 */
const categorySwiper = new Swiper('#js-categorySwiper', {
    slidesPerView: 'auto',
    watchSlidesProgress: true,
    watchSlidesVisibility: true,
    spaceBetween: calcRemToPx(60),
    slidesOffsetBefore: calcRemToPx(30),
    slidesOffsetAfter: calcRemToPx(30),
    on: {
        tap() {
            categoryContentSwiper.slideTo(categorySwiper.clickedIndex);
        }
    }
});

const categoryContentSwiper = new Swiper('#js-categoryContentSwiper', {
    autoHeight: true,
    touchMoveStopPropagation: true,
    on: {
        slideChangeTransitionStart() {
            updateNavPosition();
        }
    }
});

new Swiper('.js-categoryContentItemSwiper', {
    autoHeight: true,
    touchMoveStopPropagation: true,
    // 如果需要分页器
    pagination: {
        el: '.js-swiperPagination',
        clickable: true,
        bulletClass: 'my-bullet',
        bulletActiveClass: 'my-bullet-active',
        renderBullet(index, className) {
            return `<span class="${className}"></span>`;
        },
    },
});

function updateNavPosition() {
    $('#js-categorySwiper .active').removeClass('active');
    const activeNav = $('#js-categorySwiper .swiper-slide').eq(categoryContentSwiper.activeIndex).addClass('active');
    if (!activeNav.hasClass('swiper-slide-visible')) {
        categorySwiper.slideTo(activeNav.index());
    }
}


/* 分享 */
const share = {
    init() {
        this.insUrlShare = new Share();
        this.bindEvent();
    },
    bindEvent() {
        const self = this;
        if (mIsLogin) {
            this.insUrlShare.messenger({
                selector: '#js-messenger',
                url: window.location.href,
                appId: '255455184838968',
                onClick() {
                    const shareCallback = self.callback(1);
                    return shareCallback;
                }
            });

            this.insUrlShare.facebook({
                selector: '#js-facebook',
                url: window.location.href,
                platform: 'mobile',
                appId: '900125666754558',
                onClick: () => self.callback(2)
            });

            this.insUrlShare.vk({
                selector: '#js-vk',
                url: window.location.href,
                onClick() {
                    const shareCallback = self.callback(3);
                    return shareCallback;
                }
            });

            this.insUrlShare.twitter({
                selector: '#js-twitter',
                url: window.location.href,
                onClick() {
                    const shareCallback = self.callback(4);
                    return shareCallback;
                }
            });

            this.insUrlShare.google({
                selector: '#js-google',
                url: window.location.href,
                onClick() {
                    const shareCallback = self.callback(5);
                    return shareCallback;
                }
            });
        } else {
            $('.js-login').click(() => {
                window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
            });
        }
    },
    async callback(typeIndex) {
        if (mIsLogin) { // 判断登录
            try {
                const activityId = $('.js-start').data('lottery');
                const { status, data } = await serviceMessengerShare.http({
                    method: 'POST',
                    data: {
                        fackType: typeIndex,
                        activityId
                    }
                });
                if (status === 0) {
                    const shareSuccessTemp = await import('./component/common_tip.art');
                    setTimeout(() => {
                        layer.open({
                            content: shareSuccessTemp({ msg: data.shareTips }),
                            className: 'play_info',
                            btn: false,
                            closeBtn: 0,
                            shadeClose: true
                        });
                    }, 1800);
                    return false;
                }
            } catch (error) {
                throw new Error(error);
            }
        } else {
            window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
        }
        return true;
    }
};
share.init();

/* 领取券 */
$('.js-grab').on('tap', (event) => {
    const $this = $(event.currentTarget);
    const eventTargetParent = $this.closest('.coupon_item');
    if (!eventTargetParent.hasClass('disabled')) { // 已领，过期不可点击
        if (mIsLogin) { // 判断登录
            const templateId = $this.data('templatecode');
            try {
                getCouponItem({ templateCode: templateId }).then(async ({ status, msg, data }) => {
                    if (status === 0 || status === 10052071) {
                        eventTargetParent.addClass('disabled');
                        if (status === 0) {
                            const getCouponTemp = await import('./component/getCoupon_success.art');
                            layer.open({
                                content: getCouponTemp({ couponId: data.couponCode }),
                                className: 'play_info',
                                btn: false,
                                closeBtn: 0,
                                shadeClose: false,
                            });
                        }
                    }
                });
            } catch (error) {
                throw new Error(error);
            }
        } else {
            window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
        }
    }
});

// 剪切板
$(document).on('tap', '.js-popCopy', (event) => {
    clipHandle(event.target);
});

function clipHandle(item) {
    const clip = new Clipboard(item, {
        text(trigger) {
            return trigger.dataset.code;
        },
    });
    clip.on('success', () => {
        layer.open({
            content: 'Copy Succeed',
            skin: 'msg',
            time: 2
        });
    });
}

/* 加入购物车 */

$('.js-addToCart').on('tap', (e) => {
    const $this = $(e.currentTarget);
    PubSub.publish('sysAddToCart', {
        goods: {
            goodsSn: $this.attr('data-goodssn'),
            warehouseCode: $this.attr('data-warehousecode'),
            qty: 1,
        }
    });
});


/* 所有弹窗关闭 */
$(document).on('tap', '.layer_content > .icon-closed', (e) => {
    layer.closeAll();
});

/* 按钮回到顶部 */
const $btnGoTop = $('#js-btnGoTop');

const btnToTop = {
    init() {
        this.bindEvent();
    },
    bindEvent() {
        $btnGoTop.on('tap', (e) => {
            this.goTop();
        });
        $(window).scroll(() => {
            this.goTopHandle();
        });
    },
    // 返回顶部显隐处理
    goTopHandle() {
        const currentScrollTop = $(window).scrollTop();
        if (currentScrollTop >= 60) {
            $btnGoTop.addClass('show');
        } else {
            $btnGoTop.removeClass('show');
        }
    },
    goTop() {
        $(window).scrollTop(0);
    }
};
btnToTop.init();

