import 'js/bootstrap.js';
import layer from 'layer';
import WebUploader from 'webuploader';
import { regEmail } from 'js/utils/regExp';
import { trans } from 'js/core/translate.js';
import { serviceFeedBack } from 'js/service/common';
import GoodsInfo from 'js/core/goods/goodsInfo';
import getUserStatus from 'js/core/user/getUserStatus';
import './errorReport.css';

const { DOMAIN_UPLOAD } = GLOBAL;
const $errorForm = $('.js-errorForm');
const addImgEle = document.querySelector('.js-imgBlock_item');
const $userEmail = $('.errorRecord_input-email');

const fileWrap = [];

function uploadImage() {
    const uploader = new WebUploader.Uploader({
        server: `${DOMAIN_UPLOAD}/avatar/upload?tos3=1`,
        mimeTypes: 'image/*',
        fileVal: 'files',
        auto: true,
        formData: { site: 'gearbest' },
        pick: '.js-imgBlock_item',
        extensions: 'gif,jpg,jpeg,bmp,png',
        thumb: {
            quality: 100, // 图片质量dpi
            allowMagnify: false, // 不允许放大，但是可以缩小
            crop: false, // 不允许裁剪
        },
    });
    uploader.on('fileQueued', (file) => {
        uploader.makeThumb(file, (error, ret) => {
            if (!error) {
                const str = `<span class="uploadImg" style="background-image: url(${ret})"></span>`;
                addImgEle.insertAdjacentHTML('beforebegin', str);
            }
        });
    });

    uploader.on('uploadSuccess', (file, data) => {
        // 这个接口当status === 1时表示成功
        if (data.status) {
            const imagePath = data.file;
            fileWrap.push(imagePath);
        } else if (data.msg) {
            layer.error({ text: data.msg });
        }
    });
}


function regForm() {
    const emailVal = $userEmail.val().trim();
    const detailsVal = $('.errorRecord_input-details').val().trim();
    if (emailVal && (!regEmail.test(emailVal))) { // 邮箱正则验证
        layer.msg(trans('login.sign_email_error'));
    } else if (detailsVal.length < 5 || detailsVal.length > 1000) {
        layer.msg(trans('base.character'));
    } else {
        return true;
    }
    return false;
}

function backUrl() {
    window.history.back();
}

function preventDefault(e) {
    if (e.cancelable) {
        e.preventDefault();
    }
}

async function onSubmit(e) {
    preventDefault(e);
    if (!regForm()) return;
    const formdata = new FormData($errorForm[0]);
    const selectNum = $("input[name='errorSelect']:checked").val();
    const pageType = 'goodsDetail';
    if (pageType === 'goodsDetail') {
        formdata.append('sku', GoodsInfo.get().goodsSn);
    }
    formdata.append('platform', 2);
    formdata.append('pipeline', window.GLOBAL.PIPELINE);
    formdata.append('lang', window.GLOBAL.LANG);
    formdata.append('source_url', document.referrer);
    formdata.append('source_type', pageType);
    formdata.append('error_type', selectNum);
    if (fileWrap.length) {
        formdata.append('file', fileWrap.join(','));
    }
    const res = await serviceFeedBack.http({
        data: formdata,
    });
    if (res.msg) {
        layer.msg(res.msg, {
            end() {
                if (res.status === 0) {
                    backUrl();
                }
            }
        });

    }
}

const singleCase = {
    init() {
        uploadImage();
        this.bindEvent();
    },
    bindEvent() {
        const userInfo = getUserStatus();
        if (userInfo.user) $userEmail.val(userInfo.user.email);
        $('.errorReport_back').click(backUrl);
        $errorForm.on('submit', onSubmit);
    }
};

singleCase.init();
