import Swiper from 'swiper/dist/js/swiper.js';
import { calcRemToPx, dateFormat, throttle } from 'js/utils';
import lazyObserver from 'js/utils/lazyObserver';
import { serviceGetConcentrateGoods } from 'js/service/goods';
import staticAsset from 'js/core/staticAsset';
import appSdk from 'js/core/app.sdk.js';
import PubSub from 'pubsub-js';
import 'swiper/dist/css/swiper.css';
import 'js/bootstrap.js';
import 'modules/header/header.js';
import 'modules/footer/footer.js';

// 多语言相关
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';

import './global_launch.css';
import tempSelectGoods from './component/good_item.art';


runtime.trans = trans;

function importCommonJs() {
    Promise.all([import('modules/header/header.js'), import('modules/footer/footer.js')]);
}

if (!appSdk.IS_APP) {
    importCommonJs();
}

const tabPage = [1, 0, 0, 0, 0]; // 固定5个选项卡，产品确认的，代表每个tab目前已经已经获得的页数
const pageId = $('.js-pageId').val(); // 页面id
const launchApp = {
    $window: $(window),
    $categorySwiperOut: $('.js-categorySwiperOut'),
    $categorySwiper: $('.js-categorySwiper'),
    morePreviousGood: true,
    init() {
        this.bindEvent();
        this.formatTime();
        this.errImg();
        this.scrollTopControl();
    },
    bindEvent() {
        // 点击viewmore往期商品
        $(document).on('click', '.js-morePreviousGoods', (e) => {
            if (this.morePreviousGood) {
                $('.js_otherGoodsItem').css('display', 'block');
                $('.js-viewMorePreviousGoods').text(trans('promotion.view_less'));
                $(e.currentTarget).addClass('launch_morePreviousGoods');
                this.morePreviousGood = false;
                $(window).scrollTop($(window).scrollTop() + 1); // 懒加载bug解决
            } else {
                $('.js_otherGoodsItem').css('display', 'none');
                $('.js-viewMorePreviousGoods').text(trans('promotion.view_more'));
                $(e.currentTarget).removeClass('launch_morePreviousGoods');
                this.morePreviousGood = true;
            }
        });
        // 置顶
        this.$window.scroll(throttle(() => {
            const fixedHeaderHeight = $('.fixedHeader').height();
            const categorySwiperOutTop = this.$categorySwiperOut.offset().top;
            const windowScrollTop = this.$window.scrollTop();
            const sperateScrollDistance = categorySwiperOutTop - fixedHeaderHeight;
            if (windowScrollTop >= sperateScrollDistance) {
                this.$categorySwiper.css({ position: 'fixed', top: fixedHeaderHeight || 0 });
            } else {
                this.$categorySwiper.css('position', 'static');
            }
        }, 50));
    },
    // 格式化时间
    formatTime() {
        const $comingTime = $('.js-commingTime');
        $.each($comingTime, (index, value) => {
            const timeStamp = $(value).data('comingtime');
            const formatTime = dateFormat(timeStamp, 'yyyy-MM-dd');
            $(value).text(formatTime);
        });
    },
    // 图片加载错误
    errImg() {
        $('.js-img').on('error', (e) => {
            const placement = `<figure class="tearImage"><img src="${staticAsset('/img/site/error_img@.png')}"></img></figure>`;
            $(e.currentTarget).after(placement);
            $(e.currentTarget).remove();
        });
    },
    // 回到顶部
    scrollTopControl() {
        const topBtn = $('.js-bottomTopBtn');
        const clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
        PubSub.subscribe('nativeScroll', () => {
            const osTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
            if (typeof osTop !== typeof undefined && osTop !== false) {
                if (osTop >= clientHeight) {
                    topBtn.addClass('show');
                } else {
                    topBtn.removeClass('show');
                }
            }
        });
        topBtn.on('click', () => {
            $(window).scrollTop(0);
        });
    },
};
launchApp.init();

/**
 * swiper事件
 */
// 最近的首发
lazyObserver({
    callBack: (observerTarget) => {
        let isLatestOne = true;
        const $latestSwiperItem = $('.latestSwiper_item');
        if ($latestSwiperItem.length <= 1) {
            isLatestOne = false;
        }
        new Swiper('.js-latestSwiper', {
            loop: true,
            pagination: {
                el: isLatestOne ? '.js-latestSwiperPagination' : '',
            },
            lazy: {
                loadPrevNext: true
            },
            effect: 'coverflow',
            centeredSlides: true,
            slidesPerView: 'auto',
            coverflowEffect: {
                rotate: 0,
                stretch: calcRemToPx(-120),
                depth: 360,
                slideShadows: false
            },
        });
    },
    observeDom: document.querySelectorAll('.js-latestSwiper'),
});

// 即将首发
lazyObserver({
    callBack: (observerTarget) => {
        new Swiper('.js-comingSwiper', {
            lazy: {
                loadPrevNext: true,
                loadPrevNextAmount: 4
            },
            slidesPerView: 'auto',
        });
    },
    observeDom: document.querySelectorAll('.js-comingSwiper'),
});

// 精选商品
lazyObserver({
    callBack: (observerTarget) => {
        // 种类滑动
        const categorySwiper = new Swiper('.js-categorySwiper', {
            slidesPerView: 'auto',
            watchSlidesProgress: true,
            watchSlidesVisibility: true,
            spaceBetween: calcRemToPx(60),
            slidesOffsetBefore: calcRemToPx(30),
            slidesOffsetAfter: calcRemToPx(30),
            on: {
                tap() {
                    // 不知道为什么内嵌ios会有一个闪的动作，临时用定时器处理
                    setTimeout(() => {
                        categoryContentSwiper.slideTo(categorySwiper.clickedIndex);
                    }, 50);
                }
            }
        });
        // 种类商品滑动
        const categoryContentSwiper = new Swiper('.js-categoryContentSwiper', {
            autoHeight: true,
            touchMoveStopPropagation: true,
            lazy: true,
            observer: true,
            observeParents: true,
            on: {
                slideChangeTransitionStart() {
                    if (tabPage[this.activeIndex] === 0) {
                        $('.js-categoryContentSwiper .swiper-wrapper').addClass('categoryContentSwiper_height');
                    }
                },
                async slideChangeTransitionEnd() {
                    await updateNavPosition();
                    reloadHeight();
                    $(window).scrollTop($(window).scrollTop() + 1); // 切换tab懒加载bug解决
                }
            }
        });
        async function updateNavPosition() {
            const categoryContentSwiperIndex = categoryContentSwiper.activeIndex;
            $('.js-categorySwiper .swiper-slide.active').removeClass('active');
            const activeNav = $('.js-categorySwiper .swiper-slide').eq(categoryContentSwiperIndex).addClass('active');
            if (!activeNav.hasClass('swiper-slide-visible')) {
                categorySwiper.slideTo(activeNav.index());
            }
            if (tabPage[categoryContentSwiperIndex] === 0) {
                const goodsList = await getData(categoryContentSwiperIndex);
                if (goodsList && goodsList.length) {
                    insertDom(goodsList, categoryContentSwiperIndex);
                    categoryContentSwiper.update();
                    $('.launch_itemBanner-img').on('load', () => {
                        reloadHeight();
                    });
                }
                if (goodsList.length < 30) {
                    $('.js-categoryContentSwiper .swiper-slide').eq(categoryContentSwiperIndex).find('.js-moreSelctGoods').css('display', 'none');
                }
                $('.js-categoryContentSwiper .swiper-wrapper').removeClass('categoryContentSwiper_height');
            }
        }
        function bindEvent() {
            // 点击精选商品viewmore
            $(document).on('click', '.js-moreSelctGoods', async (e) => {
                const slideIndex = $(e.currentTarget).data('categoryindex');
                const goodsList = await getData(slideIndex);
                if (goodsList && goodsList.length) {
                    if (goodsList.length < 30 || tabPage[slideIndex] >= 4) {
                        $(e.currentTarget).css('display', 'none');
                    }
                    insertDom(goodsList, slideIndex);
                }
            });
            // 更多关键字
            $(document).on('click', '.js-moreRelated', (e) => {
                const $parentCurrent = $(e.currentTarget).closest('.launch_itemRelate');
                const hasDown = $parentCurrent.hasClass('down');
                if (hasDown) {
                    $parentCurrent.removeClass('down');
                } else {
                    $parentCurrent.addClass('down');
                }
            });
            $('.launch_itemBanner-img').on('load', () => {
                reloadHeight();
            });
        }
        /**
         * @param slideIndex 传过来的slideIndex
         * @returns {Promise<*>}
         */
        async function getData(slideIndex) {
            try {
                const newIndex = tabPage[slideIndex] + 1; // 当网络请求错误时，页数回到上一页
                tabPage[slideIndex] = newIndex;
                const { status, data } = await serviceGetConcentrateGoods.http({
                    params: {
                        tab: slideIndex + 1,
                        page: tabPage[slideIndex],
                        pageSize: 30,
                        id: pageId,
                        type: appSdk.IS_APP ? 'app' : ''
                    },
                });
                if (status === 0) {
                    return data;
                }
                const oldIndex = tabPage[slideIndex] - 1; // 当网络请求错误时，页数回到上一页
                tabPage[slideIndex] = oldIndex;
            } catch (err) {
                const oldIndex = tabPage[slideIndex] - 1; // 当网络请求错误时，页数回到上一页
                tabPage[slideIndex] = oldIndex;
            }
            return false;
        }
        // 异步插入dom
        function insertDom(goodsList, index) {
            const html = tempSelectGoods({ list: goodsList });
            const $launchGoodsList = $('.js-categoryContentSwiper .swiper-slide .launch_goodsList').eq(index);
            $launchGoodsList.append(html);
            PubSub.publish('sysUpdateCurrency', {
                context: $launchGoodsList[0]
            });
            launchApp.errImg();
            reloadHeight();
        }
        // 高度变化，重新定义swiper-wrapper高度
        function reloadHeight() {
            const $swiperSlide = $('.js-categoryContentSwiper .swiper-slide').eq(categoryContentSwiper.activeIndex);
            $('.js-categoryContentSwiper .swiper-wrapper').css('height', $swiperSlide.find('.launch_goodsList').height()
                + $swiperSlide.find('.js-moreSelctGoods').height());
        }
        bindEvent();
    },
    observeDom: document.querySelectorAll('.js-categoryContentSwiper'),
});
