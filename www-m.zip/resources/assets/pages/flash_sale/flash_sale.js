import PubSub from 'pubsub-js';
import Swiper from 'js/lib/swiper.js';
import Timer from 'component/timer/timer.js';
import Loader from 'component/loader/loader';
import runtime from 'art-template/lib/runtime';
import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';

import { serviceFlashSalePage } from 'js/service/promotion';
import { trans } from 'js/core/translate.js';
import pageExplore from 'js/track/define/pageExplore';

import temp from './artTpl/list';
import './flash_sale.css';

// art模板挂载语言包方法
runtime.trans = trans;

pageExplore();

const $body = $('body');
const $labelFilterWrap = $('#js-labellFilterWrap');
const $panelFilterWrap = $('#js-panelFilterWrap');
const $labelsFilter = $labelFilterWrap.find('.js-labelFilter');
const $panelsFilter = $panelFilterWrap.find('.js-panelFilter');
const $panelList = $('#js-panelList');
const $btnViewMore = $('#js-btnViewMore');
const odr = $('#js-hdOdr').val();
const catId = $('#js-hdCatId').val();
// 列表商品总数
let listItemCount;
const sendParams = {
    catId,
    odr,
    page: 1,
};
const timer = new Timer();

const flashSale = {
    init() {
        // banner轮播
        this.bannerSwiper();

        // 设置筛选项高亮
        this.setFilterActive();

        // 分页数据
        this.initLoader();
        // 倒计时
        this.countdown();

        // 绑定事件
        this.bindEvent();
    },

    // 绑定事件
    bindEvent() {
        const self = this;

        // 筛选一级项点击
        $labelsFilter.on('tap', (e) => {
            const $this = $(e.currentTarget);
            const index = $this.index();

            $panelsFilter.removeClass('show');

            if ($this.hasClass('active')) {
                self.bodyUnlock();
                $this.removeClass('active');
            } else {
                self.bodyLock();
                $labelsFilter.removeClass('active');
                $this.addClass('active');
                $panelsFilter.eq(index).addClass('show');
            }
        });

        // 筛选面板区点击=>还原所有筛选下拉及关闭筛选面板
        $panelFilterWrap.on('click', () => {
            self.bodyUnlock();
            $labelsFilter.removeClass('active');
            $panelsFilter.removeClass('show');
        });

        // buy now(一键购)
        $(document).on('tap', '.js-buyNow', (e) => {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const sku = $this.attr('data-sku');
            const warehouse = $this.attr('data-warehouse');
            self.buyNow(sku, warehouse);
        });
    },

    // 锁定页面
    bodyLock() {
        $body.addClass('lock');
    },

    // 解锁页面
    bodyUnlock() {
        $body.removeClass('lock');
    },

    // banner轮播
    bannerSwiper() {
        if ($('.js-flashSwiper').find('.swiper-slide').length > 1) {
            new Swiper('.js-flashSwiper', {
                direction: 'horizontal',
                loop: true,
                autoplay: {
                    stopOnLastSlide: true,
                    delay: 1500,
                },
                pagination: {
                    el: '.swiper-pagination',
                },
                lazy: {
                    loadPrevNext: true
                }
            });
        }
    },

    // 设置筛选项高亮
    setFilterActive() {
        $panelFilterWrap.find(`[data-order="${odr || 'expiring'}"]`).addClass('active').attr('href', 'javascript:;');
        $panelFilterWrap.find(`[data-cate="${catId || '0'}"]`).addClass('active').attr('href', 'javascript:;');
    },

    // 加载loader
    initLoader() {
        const self = this;
        /**
         * 默认不请求第二页数据，当同步渲染的数据大于等于36条时，认为有第二条数据
         * 页面旧数据有可能会被缓存，从而导致无法异步加载新数据，需要手动刷新CDN
         */
        listItemCount = listItemCount || document.querySelectorAll('.flashSale_listItem');
        const dataEmptyText = $btnViewMore.attr('data-empty-text');
        if (listItemCount.length < 36) {
            $btnViewMore.text(dataEmptyText);
            return;
        }

        // 获取数据参数
        const params = sendParams;

        // 分页数据加载
        const loader = new Loader({
            viewMore: $btnViewMore,
            auto: true,
            data() {
                params.page += 1;

                // 请求其他分类数据
                return serviceFlashSalePage.http({
                    params,
                    loading: false,
                });
            },
            loadStart() {
                // 开始加载新数据
            },
            loadSuccess(res) {

                // 向当前分类容器追加数据
                const $newData = $(temp({
                    data: res.data.goods
                }));

                $panelList.append($newData);

                // 倒计时
                self.countdown($newData);

                // 更新货币
                PubSub.publish('sysUpdateCurrency', {
                    context: $panelList[0]
                });

                // 加载数据结束（完成|没有更多啦）
                if (res.data && !res.data.is_next) {
                    loader.end();
                    $btnViewMore.text(dataEmptyText);
                }

            }
        });
        // loader.load();
    },

    // 倒计时
    countdown($container) {
        const $target = $container ? $container.find('.js-cutDownTime') : $('.js-cutDownTime');

        // 活动已经开始商品的倒计时
        timer.add($target, {
            format(time) {
                return time < 24 * 60 * 60 ? '{hh}:{mm}:{ss}' : trans('goods.days_h_m_s', ['{d}', '{hh}', '{mm}', '{ss}']);
            },
            interval: 'end',
            onStart() {

            },
        });
    },

    // 一键购
    buyNow(sku, warehouse) {
        PubSub.publish('sysBuyNow', {
            goods: [{
                qty: 1,
                goodsSn: sku,
                warehouseCode: warehouse,
            }]
        });
    }
};
flashSale.init();
