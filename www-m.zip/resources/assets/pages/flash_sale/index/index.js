import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';

import PubSub from 'pubsub-js';
import Timer from 'component/timer/timer';
import { serviceFlashSaleScence } from 'js/service/promotion.js';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import Navigate from 'component/navigate/navigate.scroll';
import { dateFormat, throttle } from 'js/utils/index.js';
import asyncPrice from 'js/core/asyncPrice';
import Swiper from 'js/lib/swiper.js';
import flashSaleTrack from 'js/track/define/flash_sale.js';

import temp from '../artTpl/list.art';
import '../artTpl/list.css';
import './index.css';

runtime.trans = trans;


// 获取次日00:00:00 时间戳（单位: 秒）
function getTomorrowBegin() {
    // 当前时间戳 单位:s
    const now = new Date();
    now.setHours(0);
    now.setMinutes(0);
    now.setSeconds(0);
    now.setMilliseconds(0);
    now.setDate(now.getDate() + 1);
    return now.getTime();
}


// 顶部公共导航高度
const headerTop = $('.topHeader').height();
// 场次tab
const $tab = $('#js-tabScence');
// 商品面板
const $panelGoods = $('#js-panelGoodsList');
// 多语言配置
const TRANS_CONFIG = {
    // 场次状态名称
    'state-1': trans('goodslist.state_deal_end'), // -1：已结束
    state0: trans('goodslist.state_on_sale'), // 0：可抢购
    state00: trans('goodslist.state_selling'), // 00：当前抢购中
    state1: trans('goodslist.state_coming_soon'), // 1：当日即将到来场次
    state2: trans('goodslist.state_tomorrow'), // 2:明日及以后场次

    // 抢购口号
    'slogan-1': '',
    slogan0: trans('goodslist.on_sale_grab_it_now'),
    slogan00: trans('goodslist.on_sale_grab_it_now'),
    slogan1: '',
    slogan2: '',

    // 倒计时前缀
    'timer-1': '',
    timer0: trans('goodslist.timer_ends_in'),
    timer00: trans('goodslist.timer_ends_in'),
    timer1: trans('goodslist.timer_begins_in'),
    timer2: trans('goodslist.timer_begins_in'),
};


// 主功能
const flashSale = {
    init() {
        this.timer = new Timer();
        this.currentScenceInfo = {}; // 当前场次信息


        this.fillScenceInfo(); // 填充场次显示信息
        this.supplyTab(); // 场次tab补空(仅为了居中当前场次)
        this.tabAni(); // 场次tab动效

        this.timerShow(); // 当前场次倒计时
        this.scenceGoodsTimer(this.currentScenceInfo.index); // 当前场次商品倒计时

        this.bannerSwiper(); // 轮播图

        this.bindEvent(); // 事件绑定
    },

    bindEvent() {
        // 场次点击
        $tab.on('tap', '.js-tabScenceItem', async (e) => {
            const $this = $(e.currentTarget);
            const index = $this.index();
            const scenceId = $this.attr('data-scence-id');
            const $currentPanelGoods = $panelGoods.find('.js-panelListGroup').eq(index);
            const scenceState = $this.attr('data-scence-state');

            // 当前选中场次不可点
            if (!$this.hasClass('active')) {
                this.switchScence(index);
                this.timerShow();

                // 已有倒计时标识表明已渲染数据
                if (+$currentPanelGoods.data('timer-initialized') === 1) {
                    return;
                }

                const list = await this.getGoodsListAsync(scenceId);

                if (!list.length) {
                    $currentPanelGoods.addClass('showEmpty');
                    return;
                }

                // 移除空提示面板
                $currentPanelGoods.removeClass('showEmpty');

                // 渲染列表
                $currentPanelGoods.find('.js-panelItemList').html(temp({
                    data: list
                }));

                // 场次内商品倒计时
                this.scenceGoodsTimer(index);

                // 将来场次商品添加标识
                if (+scenceState > 0) {
                    $currentPanelGoods.find('.js-flashSaleGoodsItem').addClass('coming-soon');

                    PubSub.publish('sysUpdateCurrency', {
                        context: $currentPanelGoods[0],
                    });

                } else { // 非将来场次才要取实时价
                    asyncPrice({
                        context: $currentPanelGoods[0],
                        callback() {
                            PubSub.publish('sysUpdateCurrency', {
                                context: $currentPanelGoods[0],
                            });
                        }
                    });
                }

            }
        });

        // 页面滚动 场次tab吸顶
        window.addEventListener('scroll', throttle(() => {
            const scrollT = $(window).scrollTop();

            if ($tab.parent().offset().top - headerTop <= scrollT) {
                $tab.addClass('fixed');
                $tab.css({
                    top: headerTop
                });
            } else {
                $tab.removeClass('fixed');
                $tab.css({
                    top: 'initial'
                });
            }

        }, 80));
    },

    // 场次滚动效果
    tabAni() {
        if (!$tab.find('.js-tabScenceItem').length) {
            return;
        }

        this.tabScroll = new Navigate('.nflashSale_scene', {
            default: 0
        });

        // 滚动到当前tab
        this.tabScroll.goto(this.currentScenceInfo.index);
    },

    // 填充场次信息 1.开场时间  2.状态名称  3.状态标识
    fillScenceInfo() {
        $tab.find('.js-tabScenceItem').each((index, item) => {
            const $item = $(item);
            const { begin, end } = item.dataset;
            const scenceInfo = this.getScenceInfo(begin, end);

            // 时间
            $item.find('.nflashSale_sceneTime').text(scenceInfo.openTime);

            // 状态名称
            if ($item.hasClass('active')) {
                scenceInfo.status = '00';

                // 抛出当前场次信息
                this.currentScenceInfo = {
                    begin, // 开始时间戳
                    end, // 结束时间戳
                    index, // 当前dom所处位置
                    dom: $item, // 场次tab dom
                    status: scenceInfo.status, // 场次状态
                };
            }
            $item.find('.nflashSale_sceneLabel').text(TRANS_CONFIG[`state${scenceInfo.status}`]);

            // 状态标识
            $item.attr('data-scence-state', scenceInfo.status);
        });
    },

    // 末端补充空位
    supplyTab() {
        const $firstChild = $tab.find('.js-tabScenceItem').first();
        const $lastChild = $tab.find('.js-tabScenceItem').last();
        const emptyTab = '<div class="case"><div class="nflashSale_sceneItem"></div></div>';

        if ($firstChild.attr('data-scence-state') === '00') {
            $tab.prepend(emptyTab);
        }

        if ($lastChild.attr('data-scence-state') === '00') {
            $tab.append(emptyTab);
        }
    },

    // 获取场次信息(开始时间|状态)
    getScenceInfo(beginTime, endTime) {
        const res = {
            begin: beginTime,
            end: endTime,
            openTime: '', // 场次开始时间
            status: '' // 场次状态
        };
        // 当前时间戳 单位:s
        const NOW = Date.now() / 1000;

        if (!beginTime && !endTime) {
            return res;
        }

        // 开始时间
        if (beginTime) {
            res.openTime = dateFormat(beginTime, 'hh:ss');
        }

        // 当前状态
        if (NOW < beginTime) { // 未开始

            if (beginTime > getTomorrowBegin() / 1000) { // 明日或之后的时间
                res.status = 2;
            } else {
                res.status = 1;
            }

        } else if (NOW >= beginTime && NOW < endTime) { // 进行中
            res.status = 0;
        } else if (NOW >= endTime) { // 已结束
            res.status = -1;
        }

        return res;
    },

    // 切换到在场的倒计计
    timerShow() {
        if ('status' in this.currentScenceInfo) {
            const info = this.currentScenceInfo;

            // 倒计时左侧口号标语
            $('.js-timerLabel').text(TRANS_CONFIG[`slogan${info.status}`]);

            // 倒计时区
            const $timerPlace = $('.js-timerShow');
            const timerLabel = TRANS_CONFIG[`timer${info.status}`];

            $timerPlace.attr('data-begin', info.begin);
            $timerPlace.attr('data-end', info.end);

            if (this.scenceTimer) this.scenceTimer.destroy();
            this.scenceTimer = new Timer($timerPlace, {
                format: `${timerLabel} <b>{hh}</b>:<b>{mm}</b>:<b>{ss}</b>`,
                interval: +info.status > 0 ? 'begin' : 'end',
            });
        }
    },

    // 切换到指定的场次
    switchScence(index) {
        // 仅当前tab高亮
        const $tabs = $tab.find('.js-tabScenceItem');
        const $currentTab = $tabs.eq(index);
        $tabs.removeClass('active');
        $currentTab.addClass('active');

        // 仅当前场次商品显示
        const $groups = $panelGoods.find('.js-panelListGroup');
        const $currentGroup = $groups.eq(index);
        $groups.hide();
        $currentGroup.show();

        // 抛出当前场次信息
        this.currentScenceInfo = {
            begin: $currentTab.attr('data-begin'), // 开始时间戳
            end: $currentTab.attr('data-end'), // 结束时间戳
            index, // 当前dom所处位置
            dom: $currentTab, // 场次tab dom
            status: $currentTab.attr('data-scence-state'), // 场次状态
        };
    },

    // 指定场次内商品倒计时（只用作商品状态变更），不实际显示倒计时
    scenceGoodsTimer(index) {
        const self = this;
        const $currentGroups = $panelGoods.find('.js-panelListGroup').eq(index);
        const $goodsItems = $currentGroups.find('.js-flashSaleGoodsItem');
        const { status } = this.getScenceInfo($currentGroups.attr('data-begin'), $currentGroups.attr('data-end'));

        // 已倒计时则终止
        if (+$currentGroups.data('timer-initialized') === 1) {
            return;
        }

        // 标识本组已进入倒计时
        $currentGroups.data('timer-initialized', 1);

        // 本组商品倒计时
        this.timer.add($goodsItems, {
            interval: 'begin',
            onChange: $.noop,
            onStart(target) {
                const $target = $(target);
                if (+status < 1) {
                    $target.addClass('deal-end');
                }
            },
            onEnd(target) {
                self.timer.add(target, {
                    interval: 'end',
                    onChange: $.noop,
                    onStart(secondTarget) {
                        const $target = $(secondTarget);
                        if (+status < 1 && !$target.hasClass('js-goodsItemSoldOut')) {
                            $target.removeClass('deal-end');
                        }
                    },
                    onEnd(secondTarget) {
                        const $target = $(secondTarget);
                        if (+status < 1) {
                            $target.addClass('deal-end');
                        }
                    }
                });
            }
        });
    },

    // 获取商品列表-异步
    async getGoodsListAsync(scenceId) {
        const { status, data } = await serviceFlashSaleScence.http({
            params: {
                id: scenceId
            }
        });

        if (status === 0 && data.goodsList && data.goodsList.length) {
            return data.goodsList;
        }
        return [];
    },

    // banner轮播
    bannerSwiper() {
        if ($('.js-flashSwiper').find('.swiper-slide').length > 1) {
            new Swiper('.js-flashSwiper', {
                loop: true,
                autoplay: {
                    delay: 2000,
                }
            });
        }
    },
};

flashSale.init();

PubSub.subscribe('nativeReady', () => {
    flashSaleTrack();
});
