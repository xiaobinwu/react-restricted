/**
 * GESHOP专题
 * Created by Jiazhan Li on 2018/08/30.
 */
import 'js/bootstrap.js';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import PubSub from 'pubsub-js';
import { serviceCollectAdd, serviceDeleteCollection } from 'js/service/common';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import isLogin from 'js/core/user/isLogin';

// appsdk 支持
import appSdk from 'js/core/app.sdk.js';

import googleSubjectTrack from 'js/track/define/google_subject.js';
import landingTrack from 'js/track/define/landing_page.js';

const GESHOP = {};

/**
 * 添加购物车
 * @param reqData           // 后台接口请求参数，这是一个数组类型，允许批量添加购物车，单个对象配置信息如下：
 *     -- goodsSn           // string      Y   商品SKU
 *     -- qty               // string      Y   商品数量
 *     -- warehouseCode     // string      Y   仓库代码
 *     -- goodsType         // int         N   商品类型    0：正常  1：配件  2：赠品  3：加价购 4：买即赠赠品
 *     -- activityId        // int         N   活动Id，不传默认为0
 *     -- mainGoodsSn       // string      N   主商品SKU （配件商品传），默认为空
 *     -- ciphertext        // string      N   邮箱加密价，不传默认为空
 *     -- source            // int         N   加购商品来源  0-详情 1-列表
 *
 * @return void
 */
GESHOP.addToCart = ({
    reqData = [],
    callback = () => {},
} = {}) => {
    PubSub.publish('sysAddToCart', {
        goods: reqData,
        callback
    });
};


/**
 * 添加收藏
 * @param reqData       // 后台接口请求参数，这是一个数组类型，允许批量添加收藏，单个对象配置信息如下：
 *     -- sku           // string      Y   商品SKU
 *     -- wid           // string      Y   仓库代码
 *
 * @return Promise
 */
GESHOP.addCollection = (reqData = []) => {
    const goods = reqData.map(item => `${item.sku}_${item.wid}`);
    return serviceCollectAdd.http({
        data: { goods },
    });
};


/**
 * 取消收藏
 * @param reqData       // 后台接口请求参数，这是一个数组类型，允许批量添加收藏，单个对象配置信息如下：
 *     -- favid         // string      Y   商品收藏ID（一般来源于上一步《添加收藏》返回的值）
 *
 * @return Promise
 */
GESHOP.removeCollection = (reqData = []) => serviceDeleteCollection.http({
    data: { favId: reqData },
});


/**
 * 领取优惠券
 * @param couponCode        // string      Y   优惠券code
 * @param couponResource    // number      Y   优惠券渠道来源，默认：7
 * @param successTip        // boolean     N   是否启用默认成功提示，默认：true
 * @return Promise
 */
GESHOP.getCouponItem = getCouponItem;

// isLogin
GESHOP.isLogin = isLogin;

// appSdk
GESHOP.appSdk = appSdk;

// 全局暴露
window.GESHOP = GESHOP;

if (window.geShopType === 'ads') {
    landingTrack();
} else {
    googleSubjectTrack();
}
