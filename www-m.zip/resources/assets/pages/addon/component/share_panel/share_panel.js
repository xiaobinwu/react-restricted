import specAnimate from 'js/utils/specAnimate.js';
import './share_panel.css';

const sharePanel = {
    init() {
        console.log(333333333);
        this.$pop = $('#js-popShare');
        this.$popCont = this.$pop.find('.goodsPop_cont');
        this.dataReady = false;
        this.bindEvent();
        return this;
    },

    bindEvent() {
        const self = this;

        // 关闭弹窗
        this.$pop.find('.js-close').on('click', () => {
            self.hide();
        });

        // 点击遮罩层关闭弹窗
        this.$pop.on('click', (e) => {
            if ($(e.target).find('.goodsShare_cont').length > 0) {
                self.hide();
            }
        });
    },

    show() {
        const self = this;

        specAnimate.show({
            ele: self.$pop[0],
            fn() {
                self.$pop.addClass('show');
            }
        });

        if (!this.dataReady) {
            this.getAddThis();
        }
    },

    hide() {
        this.$pop.removeClass('show');
    },

    getAddThis() {
        try {
            const self = this;
            const script = document.createElement('script');
            script.src = 'https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5593999a63d4446e';
            script.onload = () => {
                self.dataReady = true;
                self.$pop.addClass('loaded');
            };
            document.body.appendChild(script);
        } catch (error) {
            throw new Error(error);
        }
    },
};

export default sharePanel;
