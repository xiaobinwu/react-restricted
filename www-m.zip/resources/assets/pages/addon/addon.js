import PubSub from 'pubsub-js';
import 'js/bootstrap';
import 'js/lib/zepto/fx.js';
import 'js/lib/zepto/fx_methodes.js';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import { updateCurrency } from 'js/core/currency';
import layer from 'layer';
import { serviceAddonJudge, serviceAddonCompose } from 'js/service/promotion';
// 多语言相关
import { trans } from 'js/core/translate.js';
// 大数据埋点
import addonTrack from 'js/track/define/addon.js';

import backPrevOrHome from 'js/core/backPrevOrHome';

/* 搜索分类排序 */
import appSide from '../category/component/appSide/appSide'; // check

import './addon.css';
import '../category/cate_list/cate_list.js';

import tempaddon from './addon.art';
import lsitPageRecom from '../newIndex/common/js/listPageRecom';

const $body = $('body');
const $dealsFilterList = $('.js-dealsFilterList a');
const $panelFilterWrap = $('.js-panelFilterWrap');
const $labelsFilter = $('.js-labellFilterBox').find('.js-labelFilter');
const $panelsFilter = $panelFilterWrap.find('.js-panelFilter');
const $opacityWrap = $('.js-opacityWrap');
const $hotSalelabelA = $('.js-filterLabelA');
const $hotSalelabelB = $('.js-filterLabelB');
const $lodingBounce = $('.js-lodingBounce');
const $innerItemBox = $('.js-innerItemBox a');
const $bottomNavInput = $('.js-priceInput');
const $recommendList = $('.addonContainer_content .addonContainer_goods');

addonTrack();

PubSub.subscribe('nativeReady', () => {
    appSide.init();
});

// 分页请求参数
const pagingParams = {
    curPage: 1, // 当前页码
    pageSize: 36, // 每页记录数
};

const screening = {
    totalPage: null, // 总页数
    addonBox: $('.js-addonItemBox'),
    init() {
        const type = 'addon';
        const activityId = this.getSearchObjControl();
        const renderResult = lsitPageRecom.pageShow(type, activityId);
        if (renderResult) {
            pagingParams.curPage = renderResult.page;
            if (renderResult.page >= renderResult.totalPage) {
                $('.viewMore').hide();
            }
        }

        this.bindEvent();
    },
    async getData() {
        const searchObj = this.getSearchObjControl();
        const params = {
            page: pagingParams.curPage,
            pageSize: pagingParams.pageSize,
            ...searchObj,
        };

        const res = await serviceAddonCompose.http({ params });
        this.totalPage = res.data.totalPage; // 总页数

        if (+pagingParams.page === 1) {
            lsitPageRecom.remove();
        }
        const listDate = res.data.goodsList;
        const totalPage = res.data.totalPage;

        lsitPageRecom.set({
            listDate,
            totalPage
        });

        if (pagingParams.curPage >= this.totalPage) {
            $('.viewMore').hide();
        }

        this.addonBox.append(tempaddon({
            goodsList: res.data.goodsList,
            activityId: searchObj.activityId,
        }));

        // 更新货币
        PubSub.publish('sysUpdateCurrency');
    },

    bindEvent() {
        const self = this;
        // 筛选一级项点击
        $labelsFilter.on('tap', (e) => {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const index = $this.index();

            $panelsFilter.removeClass('show');

            if ($this.hasClass('active')) {
                self.bodyUnlock();
                $this.removeClass('active');
            } else {
                self.bodyLock();
                $labelsFilter.removeClass('active');
                $this.addClass('active');
                $panelsFilter.eq(index).addClass('show');
            }
        });

        // 面板下拉筛选
        $dealsFilterList.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            const dataCode = thatSef.data('code');
            const dataType = thatSef.data('type');
            const dataCateId = thatSef.data('cate-id');

            if (dataType === 0) {
                $hotSalelabelA.text(dataCode);
                $('input[name=inputCateId]').val(dataCateId);
            } else if (dataType === 1) {
                $hotSalelabelB.text(dataCode);
                $('input[name=inputOrder]').val(dataCode);
            }

            if (!thatSef.hasClass('select')) {
                $lodingBounce.addClass('on');
                thatSef.addClass('select').siblings('a').removeClass('select');
            }
            self.lodingBounce(1500);
        });

        // 分类价格筛选
        $innerItemBox.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            const dataUrl = thatSef.data('url');
            const resultSpilt = dataUrl.match(/\?.*deals=([^&]*).*/);
            if (!thatSef.hasClass('on')) {
                $lodingBounce.addClass('on');
                $bottomNavInput.val(resultSpilt[1]);
                thatSef.addClass('on').siblings('a').removeClass('on');
            }
            setTimeout(() => {
                window.location.href = dataUrl;
                if ($lodingBounce.hasClass('on')) {
                    $lodingBounce.removeClass('on');
                }
            }, 1500);
        });

        // 面板遮罩层点击=>还原所有筛选下拉及关闭筛选面板
        $opacityWrap.on('tap', (e) => {
            self.bodyUnlock();
            $labelsFilter.removeClass('active');
            $panelsFilter.removeClass('show');
        });

        // 点击更多按钮，展示更多列表
        $('.js-showMore').on('click', () => {
            pagingParams.curPage += 1;
            this.getData();
        });

        // 点击推荐商品保存当前推荐商品到session
        $recommendList.on('click', '.addonContainer_item ', () => {
            lsitPageRecom.save();
            const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            lsitPageRecom.historyReplace(scrollTop);
        });
    },

    // 获取URL参数
    getSearchObjControl() {
        const qs = window.location.search.length > 0 ? window.location.search.substr(1) : '';
        const args = {};
        const items = qs.length > 0 ? qs.split('&') : [];
        let item = null;
        let name = null;
        let value = null;
        const len = items.length;
        for (let i = 0; i < len; i += 1) {
            item = items[i].split('=');
            name = decodeURIComponent(item[0]);
            value = decodeURIComponent(item[1]);

            if (name.length) {
                args[name] = value;
            }
        }
        return args;
    },
    // 锁定页面
    bodyLock() {
        $body.addClass('lock');
    },

    // 解锁页面
    bodyUnlock() {
        $body.removeClass('lock');
    },

    // loding
    lodingBounce(time) {
        setTimeout(() => {
            if ($lodingBounce.hasClass('on')) {
                $lodingBounce.removeClass('on');
            }
        }, time);
    },
};
screening.init();

// 添加到购物车
$(document).on('tap', '.js-addToCart', async (event) => {
    const $that = $(event.currentTarget);
    const goodSku = $that.attr('data-sku');
    const activityIdStr = $that.attr('data-activityId');
    const warehouseStr = $that.attr('data-warehousecode');
    const goodType = parseInt($that.attr('data-goodsType'), 10) || 0;
    const activityType = $that.attr('data-activitytype');

    // 换购、赠品加车前的校验
    if (activityType && (+activityType === 2 || +activityType === 4)) {
        /* 加车之前的判断 */
        const { status, data } = await serviceAddonJudge.http({
            params: {
                activityId: activityIdStr
            }
        });
        if (+status !== 0) { return; }
        const maxGiftCount = $that.closest('.addonContainer_content').attr('data-maxgiftcount');
        const meetAmount = $that.attr('data-meetamount');
        if (!(data.isJoined && (+maxGiftCount > data.actJoinedNumber) && !data.actJoinedSkuList.includes(goodSku) && (+data.actMergeAmount >= meetAmount))) { //eslint-disable-line
            layer.msg(trans('cart.addon_addcart_tip'));
            return;
        }
    }
    /* 添加到购物车 */
    PubSub.publish('sysAddToCart', {
        goods: {
            goodsSn: goodSku,
            warehouseCode: warehouseStr,
            qty: 1,
            activityId: activityIdStr,
            goodsType: goodType,
        },
    });
    // 加车成功订阅
    const sysAddToCartSuccess = PubSub.subscribe('sysAddToCartSuccess', async (res) => {
        if (!activityType) {
            if (serviceAddonJudge.cancel) {
                serviceAddonJudge.cancel();
            }
            const { status, data } = await serviceAddonJudge.http({
                params: {
                    activityId: activityIdStr
                }
            });
            if (+status !== 0) { return; }

            const $activityAmount = $('.js-activityAmount');
            $activityAmount.data('currency', data.actMergeAmount || 0);
            const $actMergeActualAmount = $('.js-actMergeActualAmount');
            $actMergeActualAmount.data('currency', data.actMergeActualAmount || 0);
            const $myDiscounted = $('.addonRuls_my_discounted');
            console.log(data.actMergeActualAmount);
            if (data.activityDeductAmount > 0) {
                $myDiscounted.removeClass('my-hide');
            }
            updateCurrency({
                elements: [$activityAmount[0], $actMergeActualAmount[0]]
            });
            PubSub.unsubscribe(sysAddToCartSuccess);
        }
    });
});

// 分享
const $btnShowShare = $('#js-btnShowShare');
// 分享面板
$btnShowShare.on('click', async (e) => {
    const { default: sharePanel } = await import('./component/share_panel/share_panel.js');
    const insSharePanel = sharePanel.init();
    insSharePanel.show();
});

// 返回上一级
$('.js-back').on('tap', () => {
    backPrevOrHome();
});
