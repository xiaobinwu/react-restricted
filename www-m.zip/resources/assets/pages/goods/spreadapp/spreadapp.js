import 'js/bootstrap';
import Cookies from 'js/utils/cookie';
import { getUrlQuery } from 'js/utils';
import './spreadapp.css';

class Spreadapp {
    static patternSascid = new RegExp('[\\?&\\#](lkid|utm_source|vip|sascid)=([^&]+)', 'g');
    constructor({ url = window.location.href, search = window.location.search } = {}) {
        this.ua = navigator.userAgent.toLowerCase();
        this.search = search;
        this.$btn = $('#js-spreadAppWrap_btn');
        this.$launchBtn = $('#js-launchAppWrap_btn');
        this.query = getUrlQuery(url);
        this.bindEvent();
    }
    bindEvent() {
        this.$btn.on('click', () => {
            if (this.ua.match(/(iPhone|iPod|iPad);?/i)) {
                window.location.href = 'https://itunes.apple.com/cn/app/gearbest-shopping/id1131090631?l=en&mt=8';
            } else if (this.ua.match(/(Android);?/i)) {
                // iframe唤起app，没有下载的话跳下载页
                const ifr = document.createElement('iframe');
                ifr.src = `gearbest://home/${this.search}`;
                ifr.style.display = 'none';
                document.body.appendChild(ifr);
                window.setTimeout(() => {
                    document.body.removeChild(ifr);
                    window.location.href =
                        'https://play.google.com/store/apps/details?id=com.globalegrow.app.gearbest&referrer=utm_source';
                }, 500);
            }
        });
        this.$launchBtn.on('click', () => {
            const {
                sascid,
                goods_web_sn: goodsWebSn,
                warehouse_code: warehouseCode,
                utm_source: utmSource,
                utm_medium: utmMedium,
                utm_campaign: utmCampaign,
                eo,
                pageType
            } = this.query;
            const curCookies = Cookies.get();
            const linkid = curCookies.lkid || '';
            let sascidApp = '';
            if (sascid || utmSource || utmMedium || utmCampaign || eo) {
                sascidApp = `&sascid=${sascid}&utm_source=${utmSource}&utm_medium=${utmMedium}&utm_campaign=${utmCampaign}&eo=${eo}`;
                if (pageType === 'index') {
                    sascidApp = `&sascid=${sascid}&utm_source=${utmSource}&utm_medium=${utmMedium}&utm_campaign=${utmCampaign}`;
                }

                if (utmSource && utmSource === 'admitad') {
                    const admitadUid = curCookies.admitad_uid || '';
                    const utmContent = curCookies.utm_content || '';
                    sascidApp = `&trace=third&admitad_uid=${admitadUid}&utm_source=${utmSource}&utm_content=${utmContent}`;
                }
                if (utmSource && utmSource === 'zanox') {
                    const zanpid = curCookies.zanpid || '';
                    const awc = curCookies.awc || '';
                    const awinPublisher = curCookies.awin_publisher || '';
                    sascidApp =
                    `&trace=third&zanpid=${zanpid}&awc=${awc}&awin_publisher=${awinPublisher}&utm_source=${utmSource}&utm_campaign=${utmCampaign}`;
                }
                if (utmSource && utmSource.indexOf('tt_') > -1) {
                    const utmContent = curCookies.utm_content || '';
                    const campaign = curCookies.campaign || '';
                    const data = curCookies.data || '';
                    sascidApp =
                    `&trace=third&utm_source=${utmSource}&utm_campaign=${utmCampaign}&utm_content=${utmContent}&campaign=${campaign}&data=${data}`;
                }
            }
            let schemeUrl = '';
            if (pageType === 'product') {
                schemeUrl = `gearbest://product?lkid=${linkid}&goods_web_sn=${goodsWebSn}&warehouse_code=${warehouseCode}&from=m${sascidApp}`;
            }
            if (pageType === 'index') {
                const linkidExp = curCookies.linkid_exp || '';
                schemeUrl = `gearbest://home/?lkid=${linkid}&expiresat=${linkidExp}&from=m${sascidApp}`;
            }
            window.location.href = schemeUrl;
            setTimeout(() => {
                window.history.back(-1);
            }, 3000);
        });
    }
}

new Spreadapp();
