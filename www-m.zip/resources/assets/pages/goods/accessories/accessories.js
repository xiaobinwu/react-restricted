/**
 * 配件页js
 */

import 'js/bootstrap';
import Cookies from 'js/utils/cookie';

import { serviceGoodsPrice } from 'js/service/goods';
import PubSub from 'pubsub-js';

import { calcRemToPx } from 'js/utils';
import { getCurrency, transform, addSymbol, add } from 'js/core/currency';


import Swiper from 'js/lib/swiper.js';

import 'modules/header/header.js';
import 'modules/footer/footer.js';

// 大数据埋点
import accessoriesTrack from 'js/track/define/accessories.js';

import './accessories.css';


new Swiper('#js-accessoriesSwiper', {
    slidesPerView: 'auto',
    spaceBetween: calcRemToPx(60),
    slidesOffsetBefore: calcRemToPx(20),
    slidesOffsetAfter: calcRemToPx(20)
});

class Accessories {

    static mainGoodsSn = '';
    static warehouseCode = '';

    constructor(options = {}) {
        const {
            mainGoodPriceDom,
            mktGoodPriceDom,
            accessoriesPanelDom,
            accessoriesCheckboxDom,
            totalSavePriceDom,
            totalFinalPriceDom,
            tabDom
        } = options;
        this.$mainGoodPrice = $(mainGoodPriceDom); // '主商品当前销售价DOM'
        this.$mktGoodPrice = $(mktGoodPriceDom); // '主商品门店销售价DOM'
        this.$accessoriesPanel = $(accessoriesPanelDom); // '配件板块DOM'
        this.$accessoriesCheckbox = this.$accessoriesPanel.find(accessoriesCheckboxDom); // '单个配件checkboxDOM'
        this.$totalSavePrice = $(totalSavePriceDom); // '节省money数DOM'
        this.$totalFinalPrice = $(totalFinalPriceDom); // 最终支付money数DOM
        this.$tabItem = $(tabDom);

        this.totalSavePrice = 0; // 节省的价格（不包含主物品，只包含配件）
        this.totalFinalPrice = 0; // 总价格（包含主物品和配件）
        this.totalMarketPrice = 0; // todo: 所有物品的市场总价格（包含主物品和配件，目前业务需求不要了）
        this.totalAccessoriesMarketPrice = 0; // 所有配件的市场总价格
        this.totalAccessoriesPrice = 0; // 所有配件的总价

        this.accessories = []; // 主商品和配件集合

        // 主商品sku、仓库代码、店铺code
        Accessories.mainGoodsSn = this.$mainGoodPrice.data('sku');
        Accessories.warehouseCode = this.$mainGoodPrice.data('warehouseCode');
        Accessories.shopCode = this.$mainGoodPrice.data('shopCode');
        Accessories.categoryId = this.$mainGoodPrice.data('categoryId');

        this.currentPrice = this.priceStockHandle();

    }

    // 获取商品实时当前价
    async priceStockHandle() {
        try {
            const resPrice = await serviceGoodsPrice.http({
                params: {
                    warehouse_code: Accessories.warehouseCode,
                    good_sn: Accessories.mainGoodsSn,
                    shop_code: Accessories.shopCode,
                }
            });
            return resPrice.data.price;
        } catch (err) {
            return {};
        }
    }

    async init() {
        await getCurrency(); // 确保 transform 和 addSymbol 拿得到当前币种信息

        const that = this;
        const checkedItems = [];
        const price = await this.currentPrice;
        this.$mainGoodPrice.data('currency', price);
        const currentPrice = transform({ price: price || 0 });
        this.$mainGoodPrice.html(addSymbol(currentPrice));
        this.accessories.push({
            goodsSn: Accessories.mainGoodsSn,
            qty: 1,
            warehouseCode: Accessories.warehouseCode,
            goodsType: 0,
            ciphertext: Cookies.get('eo') || '',
            currentPrice,
            marketPrice: transform({
                price: this.$mktGoodPrice.data('currency') || 0,
            }),
            categoryId: Accessories.categoryId,
        });
        this.$accessoriesCheckbox.each((index, item) => {
            if (item.checked) {
                checkedItems.push(that.getOptions($(item)));
            }
        });
        this.plusAccessorie(checkedItems);
        this.bindEvent();
    }

    getOptions($this) {
        return {
            goodsSn: $this.data('sku'),
            qty: 1,
            warehouseCode: $this.data('warehouseCode'),
            goodsType: 1,
            mainGoodsSn: Accessories.mainGoodsSn,
            currentPrice: transform({
                price: $this.data('currentPrice') || 0,
            }),
            marketPrice: transform({
                price: Math.max(+$this.data('marketPrice'), +$this.data('currentPrice')),
            }),
            categoryId: Accessories.categoryId,
        };
    }

    bindEvent() {
        const that = this;
        this.$accessoriesCheckbox.on('change', (e) => {
            const $this = $(e.currentTarget);
            const options = that.getOptions($this);
            if ($this.prop('checked')) {
                that.plusAccessorie(options);
            } else {
                that.reduceAccessorie(options);
            }
        });

        this.$tabItem.on('touchend', (e) => {
            const $this = $(e.currentTarget);
            const currentIndex = $this.index();
            that.$tabItem.removeClass('active');
            $this.addClass('active');
            that.$accessoriesPanel.removeClass('active');
            that.$accessoriesPanel.eq(currentIndex).addClass('active');
            PubSub.publish('sysUpdateLazyload');
            e.preventDefault();
        });
    }
    plusAccessorie(options) {
        if (Array.isArray(options)) {
            this.accessories = this.accessories.concat(options);
        } else {
            this.accessories.push(options);
        }
        this.calculateTotalPrice();
    }
    reduceAccessorie(options = {}) {
        const index = this.accessories.findIndex(item => item.goodsSn === options.goodsSn);
        this.accessories.splice(index, 1);
        this.calculateTotalPrice();
    }

    calculateTotalPrice() {
        this.totalFinalPrice = add(this.accessories.map(item => item.currentPrice)); // 总价格（包含主物品和配件）
        this.totalMarketPrice = add(this.accessories.map(item => item.marketPrice)); // todo: 所有物品的市场总价格（包含主物品和配件，目前业务需求不要了）
        const accessoriesMarketPriceArray = []; // 定义所有配件的市场价格数组
        this.accessories.forEach((item, index) => { // 所有配件的市场总价格
            if (index !== 0) { // 主商品为第0个
                accessoriesMarketPriceArray.push(item.marketPrice);
            }
        });
        const accessoriesPriceArray = []; // 定义所有配件的当前价格数组
        this.accessories.forEach((item, index) => { // 所有配件的总价
            if (index !== 0) { // 主商品为第0个
                accessoriesPriceArray.push(item.currentPrice);
            }
        });
        this.totalAccessoriesMarketPrice = add(accessoriesMarketPriceArray);
        this.totalAccessoriesPrice = add(accessoriesPriceArray);
        this.totalSavePrice = add(this.totalAccessoriesMarketPrice, -this.totalAccessoriesPrice); // 节省的价格（不包含主物品，只包含配件）
        this.$totalSavePrice.html(addSymbol(this.totalSavePrice));
        this.$totalFinalPrice.html(addSymbol(this.totalFinalPrice));
    }

    getSaveMoney() {
        return this.totalSavePrice;
    }
    getFinalMoney() {
        return this.totalFinalPrice;
    }

    getParams() {
        const accessories = JSON.parse(JSON.stringify(this.accessories));
        accessories.every((item) => {
            item.price = item.currentPrice;
            delete item.currentPrice;
            delete item.marketPrice;
            return true;
        });
        return accessories;
    }
}

const accessories = new Accessories({
    mainGoodPriceDom: '#js-bindBuyMainPrice', // '主商品当前销售价DOM'
    mktGoodPriceDom: '#js-bindBuyItemMktPrice', // '主商品门店销售价DOM'
    accessoriesPanelDom: '.js-goodsBindList', // '配件板块DOM'
    tabDom: '.js-tabBindBuy', // 'tab Item'
    accessoriesCheckboxDom: '.js-bindBuyItemCheck', // '单个配件checkboxDOM'
    totalSavePriceDom: '#js-bindBuyTotalSavePrice', // '节省money数DOM'
    totalFinalPriceDom: '#js-bindBuyTotalFinalPrice', // '最终支付money数DOM'
});

(async () => {
    await accessories.init();
    window.GOODS_TOGETHERDATA = accessories.getParams();
    accessoriesTrack();
    $(document).on('click', '#js-btnBindBuy', () => {
        PubSub.publish('sysAddToCart', { goods: accessories.getParams(), $eleCartNum: $('.siteHeader_cartNum') });
    });
})();
