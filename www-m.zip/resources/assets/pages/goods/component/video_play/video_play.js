import layer from 'layer';
import temp from './video_play.art';
import './video_play.css';

export class VideoPlay {
    constructor(videoCode, autoplay) {
        this.videoCode = videoCode;
        this.autoplay = autoplay;
    }

    // 全屏播放
    fullPlay() {
        if (!this.videoCode || !this.videoCode.length) {
            return;
        }
        if (typeof this.autoplay === 'undefined') {
            this.autoplay = 0;
        }
        try {
            const self = this;
            layer.open({
                type: 1,
                content: temp({
                    videoCode: self.videoCode,
                    autoplay: self.autoplay
                }),
                shade: 'background-color: rgba(0,0,0,1)',
                style: `
                    position: absolute;
                    top: 0;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    width: 100%;
                    height: 100%;
                `,
                success() {
                    const $ifr = $('#js-ifrVideoPlay');
                    $ifr.on('load', () => {
                        $('#js-panelVideoPlay').removeClass('box-loading');
                    });
                }
            });
        } catch (error) {
            throw new Error(error);
        }
    }
}
