import PubSub from 'pubsub-js';
import specAnimate from 'js/utils/specAnimate.js';
import temp from './promo_list.art';
import './promo_list.css';

export const promoList = {
    init() {
        this.$pop = $('#js-popPromo');
        this.$popCont = this.$pop.find('.goodsPop_cont');

        this.rendered = false;
        this.bindEventBefore();
    },

    bindEventBefore() {
        // 开启弹窗
        $('.js-btnShowPromo').on('click', () => {
            this.show();
        });
    },

    bindEventAfter() {
        const self = this;

        // 大于4个才显示切换按钮
        if (self.$promoGiftList.attr('data-len') > 4) {
            self.$btnToggleGift.addClass('show');
        }

        // 切换gift展示
        self.$btnToggleGift.on('click', () => {
            self.toggleGift();
        });

        // 关闭弹窗
        this.$pop.on('click', '.js-close', () => {
            self.hide();
        });

        // 点击遮罩层关闭弹窗
        this.$pop.on('click', (e) => {
            if ($(e.target).find('.goodsPromo_cont').length > 0) {
                self.hide();
            }
        });
    },

    show() {
        const self = this;

        if (!self.rendered) {
            this.render();
        }

        specAnimate.show({
            ele: self.$pop[0],
            beforeDisplay: 'block',
            fn() {
                self.$pop.addClass('show');
            }
        });
    },

    hide() {
        this.$pop.removeClass('show');
    },

    // 获取元素
    getEle() {
        this.$promoGiftList = $('#js-promoGiftList');
        this.$btnToggleGift = $('#js-btnTogglePromoGift');
    },

    // 显示promo弹窗
    render() {
        const self = this;

        self.$popCont.html(temp({
            list: self.activityList
        }));

        self.rendered = false;

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: self.$popCont[0]
        });

        self.getEle();
        self.bindEventAfter();
    },

    // 切换gift展示
    toggleGift() {
        this.$promoGiftList.toggleClass('show');
    },
};
