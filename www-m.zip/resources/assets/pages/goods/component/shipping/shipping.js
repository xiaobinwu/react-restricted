/* #shipping 运费弹窗# */
import InputNumber from 'component/input_number/input_number.js';
import PubSub from 'pubsub-js';
import { serviceGoodsShipping, serviceGoodsShippingCountry } from 'js/service/goods.js';
import { replaceUrlVal } from 'js/utils';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import { goodsCountryCode } from 'js/core/goods/goodsCountryCode.js';
import specAnimate from 'js/utils/specAnimate.js';
import { trans } from 'js/core/translate.js';
import 'component/combobox/combobox';
import borderStopScroll from 'component/borderStopScroll';
// import { COOKIE_CDN_COUNTRYCODE } from 'js/variables';
// import Cookies from 'js/utils/cookie';
import tempShipping from './shipping.art';
import tempShippingMethods from './shipping_methods.art';
import tempShippingWarehouse from './shipping_warehouse.art';
import tempTax from './shipping_tax.art';
import './shipping.css';

const GOODSINFO = GoodsInfo.get();
const baseInfo = GOODSINFO.baseGoodsInfo;
// 判断该商品是否是开平商品
const isPlatform = GOODSINFO.isPlatform || 0;
const $pop = $('#js-popShipping');
const $popCont = $pop.find('.goodsPop_cont');
// 获取当前sku仓库列表-来自页面
const getAllWareList = () => {
    const wareList = [];
    GOODSINFO.warehouseList.forEach((item) => {
        wareList.push(item.code);
    });
    return wareList;
};

export const shipping = {
    async init() {

        // 选中的仓库（默认选中第一个）
        this.selectedWarehouseInit = GOODSINFO.warehouseCode; // 仅用作关闭时作对比，不要进行变更
        this.selectedWarehouse = GOODSINFO.warehouseCode;

        // 国家码
        this.countryCode = await goodsCountryCode.get();
        // 初始化时判断是否是COD国家
        this.showCodCountryItem(this.countryCode);

        // 数量
        this.num = 1;

        this.getTemp();
        this.bindEvent();
    },

    bindEvent() {
        const self = this;

        // 切换仓库
        $('#js-panelShipWareList').on('click', '.js-warehouseItem', (e) => {
            const $this = $(e.currentTarget);
            const warehouse = $this.attr('data-code');

            // 记录当前选中仓
            self.selectedWarehouse = warehouse;

            // 当前仓高亮
            $this.addClass('active').siblings().removeClass('active');

            // 更新物流列表
            self.getShippingData(['shipping']);

            // 更新国家列表
            self.renderCountry();
        });

        // 切换到达国家
        $('#js-selShipToList').on('change', async (event) => {
            const country = $(event.currentTarget).val();
            self.countryCode = country;
            // 切换国家时判断是否是COD国家
            self.showCodCountryItem(country);
            // 设置商详专属国家码
            goodsCountryCode.set(country);

            // 更新物流列表
            self.getShippingData().then((res) => {
                // 发布国家变更
                PubSub.publish('goods.shippingToChange', res);
            });
        });

        // 数量控件
        const insShippingNumber = new InputNumber('js-goodsShippingQTY', {
            async onChange(value) {
                self.num = value;

                // 更新物流列表
                self.getShippingData(['shipping']);
            }
        });
        insShippingNumber.setMax(999);

        // 关闭弹窗
        $pop.find('.js-close').on('click', () => {
            self.hide();
        });

        // 点击遮罩层关闭弹窗
        $pop.on('click', (e) => {
            if ($(e.target).find('.goodsShipping_cont').length > 0) {
                self.hide();
            }
            return false;
        });
    },

    // 显示物流面板
    show() {

        // 先css动画再显示
        specAnimate.show({
            ele: $pop[0],
            fn() {
                $pop.addClass('show');
            }
        });

    },

    // 隐藏物流面板
    hide() {
        $pop.removeClass('show');
        this.shippingClose();
    },

    // 新增COD货到付款
    showCodCountryItem(country) {
        const $goodsShippingCod = $('.js-goodsSelCodPayItem');
        const isCod = $goodsShippingCod.data('iscod');
        const codCountry = $goodsShippingCod.data('codcountry');
        if (isCod && codCountry.indexOf(country) > -1) {
            $goodsShippingCod.removeClass('none');
        } else {
            $goodsShippingCod.addClass('none');
        }
    },

    // 筛选仓库列表
    filterWarehouseList() {
        // 仓库列表
        const warehouseList = window.warehouseList || [];
        this.warehouseList = [];
        warehouseList.forEach((item) => {
            if (+item.status === 1) {
                this.warehouseList.push(item);
            }
        });
    },

    // 显示弹窗
    getTemp() {
        const self = this;

        // 填充基础数据
        $popCont.html(tempShipping({
            goodsInfo: GOODSINFO,
            displayPrice: self.goodPrice,
        }));

        borderStopScroll({
            wrapEle: $pop[0]
        });

        this.getShippingData();
        this.renderCountry();


        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: $popCont.find('.goodsShipping_goodsInfo')[0]
        });
    },

    // 获取物流数据(仓库列表 + 物流方式)
    async getAjaxShipping(optParams = {}) {
        const self = this;
        const result = {
            shipList: [],
            warehouseList: [],
            taxData: []
        };
        try {
            const wareList = getAllWareList();
            const params = Object.assign({
                goodSn: GOODSINFO.goodsSn,
                countryCode: self.countryCode,
                realWhCodeList: wareList.join(','),
                realWhCode: self.selectedWarehouse,
                priceMd5: self.priceMd5,
                goodPrice: self.goodPrice,
                num: self.num,
                categoryId: GOODSINFO.categoryId,
                saleSizeLong: baseInfo.saleSizeLong,
                saleSizeWide: baseInfo.saleSizeWide,
                saleSizeHigh: baseInfo.saleSizeHigh,
                saleWeight: baseInfo.saleWeight,
                volumeWeight: baseInfo.columeWeight,
                properties: baseInfo.properties,
                shipTemplateId: GOODSINFO.shipTemplateId,
                isPlatform: GOODSINFO.isPlatform,
                virWhCode: GOODSINFO.warehouseCode,
                deliveryType: GOODSINFO.deliveryType,
                platformCategoryId: GOODSINFO.platformCategoryId,
                recommendedLevel: baseInfo.recommendedLevel,
            }, optParams);
            const res = await serviceGoodsShipping.http({
                errorPop: false,
                loading: false,
                params,
            });

            if (+res.status === 0 && res.data) {
                result.shipList = res.data.shippingMethodList;
                result.warehouseList = res.data.wareHoseList;
                result.taxData = res.data.taxData;
                result.isBfCounty = res.data.isBfCounty;
                result.freeShipping = res.data.freeShipping;
            }
        } catch (e) {
            console.log('ERROR:shipping=>getAjaxShipping', e);
        }

        return result;
    },

    // 获取配送国家列表
    async getAjaxCountry() {
        let result = [];
        const params = {
            warehouse_code: this.selectedWarehouse,
        };
        if (isPlatform) {
            Object.assign(params, {
                shipTemplateId: GOODSINFO.shipTemplateId,
                virWhCode: GOODSINFO.warehouseCode,
                isPlatform: GOODSINFO.isPlatform,
            });
        }
        try {
            const { status, data } = await serviceGoodsShippingCountry.http({
                errorPop: false,
                params,
            });
            if (+status === 0 && data && data.shippingCountry) {
                result = data.shippingCountry;
            }
        } catch (e) {
            console.log('ERROR:shipping=>getAjaxCountry', e);
        }
        return result;
    },

    // 获取
    async getShippingData(typeArr = ['warehouse', 'shipping', 'tax']) {
        const self = this;
        const res = await this.getAjaxShipping();
        const fn = {
            warehouse() {
                self.renderWarehouse(res.warehouseList);
            },
            shipping() {
                self.renderShipping(res.shipList);
            },
            tax() {
                self.renderTax(res.taxData);
            }
        };
        typeArr.forEach((item) => {
            if (fn[item] && typeof fn[item] === 'function') {
                fn[item]();
            }
        });

        // promotion coupon 异步载入
        (async function asyncPromotionCoupon() {
            const { default: promotionCoupon } = await import('../promotion_coupon/promotion_coupon.js');
            promotionCoupon.init(res.freeShipping);
        }());

        return res;
    },

    // 渲染仓库列表
    renderWarehouse(warehouseList) {
        if (warehouseList.length > 1) {
            $('#js-panelShipWareList').html(tempShippingWarehouse({
                warehouseList,
            })).show();
        } else {
            $('#js-panelShipWareList').hide();
        }
    },

    // 渲染国家列表
    async renderCountry() {
        const self = this;
        const countryList = await this.getAjaxCountry();
        const getFrequentCountry = countryList.filter(item => item.isFrequent === 1);
        $('#js-selShipToList').combobox({
            data: [getFrequentCountry, countryList],
            value: 'countryCode',
            text: 'countryName',
            default: self.countryCode,
            placeholder: trans('goods.choose_another_country'),
        });
    },

    // 渲染物流列表
    async renderShipping(shippingList) {
        $('#js-panelShipTypeList').html(tempShippingMethods({
            shippingList,
        })).show();

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: $('#js-panelShipTypeList')[0]
        });
    },

    // 获取税费信息
    async renderTax(taxData = {
        taxTitle: undefined,
        taxContent: undefined
    }) {
        if (typeof taxData.taxTitle !== 'undefined' && typeof taxData.taxContent !== 'undefined') {
            $('#js-panelShipTax').html(tempTax({
                taxData,
            }));
        } else {
            $('#js-panelShipTax').empty();
        }
    },

    // 选仓弹窗关闭时
    shippingClose() {
        const notChange = this.selectedWarehouseInit === this.selectedWarehouse;
        if (!notChange) {
            window.location.href = replaceUrlVal('wid', this.selectedWarehouse);
        }
    },
};
