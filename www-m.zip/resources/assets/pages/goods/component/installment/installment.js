import PubSub from 'pubsub-js';
import { add, divide, multiply } from 'js/core/currency';
import { trans } from 'js/core/translate.js';
import specAnimate from 'js/utils/specAnimate.js';
import layer from 'layer';
import temp from './installment.art';
import './installment.css';

const $panelGoodsProps = $('#js-goodsProps');
const $panelGoodsPropsCont = $panelGoodsProps.find('.goodsPop_cont');
const $panelGoodsPropsHeader = $panelGoodsProps.find('.goodsProps_goods');
const $entryInstallment = $('#js-entryInstallment');
const $panelSelectedShow = $('#js-panelInstallmentShow');

export class Installment {
    constructor() {
        this.$pop = $('#js-popInstallment');
        this.$popCont = this.$pop.find('.goodsPop_cont');

        // 选中期数
        this.selectedInstallment = null;
        this.bindEvent();
    }

    bindEvent() {
        const self = this;
        // 关闭弹窗
        this.$pop.on('click', '.js-close', (e) => {
            e.preventDefault();
            self.showSelected();
            self.hide();
        });

        // 选择某项分期
        this.$pop.on('click', '.js-itemInstallment', (e) => {
            const $this = $(e.currentTarget);

            // 变更选择的分期信息
            self.selectedInstallment = $this.attr('data-installments');

            // 变更无息标识状态
            self.changeFreeTag();
        });

        // 展开分期列表
        $entryInstallment.on('click', (e) => {
            // 免息提示弹窗
            // 当点击了提示按钮时(因zepto 阻止冒泡无法实现原因)
            if ($(e.target).hasClass('js-tagInterestFree')) {
                self.showFreeTip();
            } else {
                // 设置分期列表面板高度
                self.setPanelHeight();
                self.show();
            }
        });

        // 免息提示弹窗
        this.$pop.on('click', '.js-tagInterestFree', (e) => {
            self.showFreeTip();
            e.stopPropagation();
        });

        // 分期数据就绪
        PubSub.subscribe('goods.installmentDataReady', (msg, data) => {
            const { priceData, installmentData } = data;
            self.price = priceData.price;
            self.installmentData = installmentData;
            self.showEntry();
        });

        // 商品数量变更
        PubSub.subscribe('goods.numberChange', (msg, num) => {
            self.num = num;
            self.filterAllData();
            self.renderSel();
            self.showSelected();
        });
    }

    // 判断是否显示分期
    showEntry() {
        const list = this.filterAllData();
        if (list.length) {
            $entryInstallment.addClass('show');

        }
    }

    // 显示coupon弹窗
    show() {
        const self = this;

        specAnimate.show({
            ele: self.$pop[0],
            fn() {
                self.$pop.addClass('show');
            }
        });

        if (!this.renderSelFlag) {
            this.renderSel();
        }
    }

    hide() {
        this.$pop.removeClass('show');
    }

    // 设置分期列表面板高度
    setPanelHeight() {
        const height = $panelGoodsPropsCont.height() - $panelGoodsPropsHeader.height();
        this.$popCont.height(height);
    }

    // 筛选数据
    filterAllData() {
        if (this.installmentData) {
            const self = this;
            const data = self.installmentData || {};
            const { price } = self;
            const result = [];
            const num = self.num || 1;

            if (data.installments instanceof Array && data.installments.length) {
                data.installments.forEach((item) => {
                    const totalPrice = add(multiply(price, num), multiply(price, num, divide(item.rate, 100)));
                    const perPrice = divide(totalPrice, item.installments);

                    // 总金额限制    每期金额限制  分期数限制
                    if (
                        totalPrice >= data.min && totalPrice <= data.max &&
                        perPrice >= data.minAmount &&
                        item.installments > 1
                    ) {
                        result.push({
                            rate: item.rate,
                            installments: item.installments,
                            perPrice,
                            totalPrice,
                        });
                    }
                });
            }

            self.resultList = result.reverse();
            return self.resultList;
        }
        return [];
    }

    // 填充选项面板
    renderSel() {
        const self = this;

        const list = self.filterAllData();

        if (self.resultList instanceof Array) {

            self.$popCont.html(temp({
                ART_TYPE: 'list',
                selectedInstallment: self.selectedInstallment,
                list
            }));

            PubSub.publish('sysUpdateCurrency', {
                context: self.$popCont[0],
            });

            this.renderSelFlag = true;
        }
    }

    // 从分期列表中提取指定期数的数据(期数)
    filterSelectedData(installment) {
        const list = this.resultList;
        let result = {};
        list.forEach((item, index) => {
            if (+item.installments === +installment) {
                result = item;
            }
        });
        return result;
    }

    // 在select bar上显示选中的内容
    async showSelected() {
        const self = this;
        if (this.selectedInstallment > 0) {
            const selectedData = self.filterSelectedData(self.selectedInstallment);
            const tempConfig = Object.assign({
                ART_TYPE: 'selected',
            }, selectedData);

            $panelSelectedShow.html(temp(tempConfig));

            PubSub.publish('sysUpdateCurrency', {
                context: $panelSelectedShow[0],
            });
        }
    }

    // 变更无息标识状态
    changeFreeTag() {
        const selectedData = this.filterSelectedData(this.selectedInstallment);
        const { rate } = selectedData;
        if (+rate === 0) {
            this.$pop.addClass('interest_free');
        } else {
            this.$pop.removeClass('interest_free');
        }
        // $boxInstallment.parents('.goodsIntro_attrBox').attr('data-free', +rate === 0);
    }

    // 免息期数数量
    getFreeTimes() {
        const list = this.resultList;
        let count = 0;
        list.forEach((item, index) => {
            if (+item.rate === 0) {
                count += 1;
            }
        });
        return count;
    }

    showFreeTip() {
        const freeTimes = this.getFreeTimes();
        layer.open({
            title: [trans('goods.tips'), 'padding-top:.3rem; padding-bottom: .3rem;'],
            content: trans('goods.interest_information', [freeTimes]),
            style: 'max-width:73%',
            btn: trans('base.ok'),
        });
    }
}
