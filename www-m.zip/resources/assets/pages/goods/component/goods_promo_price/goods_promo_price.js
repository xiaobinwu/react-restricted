/** 商品促销（营销）价状态展示 */

import PubSub from 'pubsub-js';
import Timer from 'component/timer/timer';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import { add, divide } from 'js/core/currency';
import { trans } from 'js/core/translate.js';
import tempPromo from './goods_promo_price.art';
import './goods_promo_price.css';

const GOODSINFO = GoodsInfo.get();

/**
 * 指定商品状态才可显示营销价面板
 * 2    上架
 * 4    到货通知（只因设计问题）
 */
const SHOWPRICE_STATUS = [2, 4];

/**
 * 营销价格类型 (以下~开头表示有营销价格模板适配)
 * -2   ~前端定义：由商品状态（到货通知）聚合过来
 * -1   普通状态-本店售价
 * 1    ~邮件专享价
 * 2    ~预售价
 * 7    ~限时限量价
 * 8    ~普通促销
 */
const PRICE_TYPE = {
    '-2': {
        name: trans('goods.detail_arrival_notice'),
        showNormalPrice: true,
    },
    1: {
        name: trans('goods.detail_email_only'),
        showNormalPrice: false,
    },
    2: {
        name: trans('goods.detail_presale'),
        showNormalPrice: false,
    },
    7: {
        name: trans('goods.detail_flash_sale'),
        showNormalPrice: false,
    },
    11: {
        name: trans('base.super_deals'),
        showNormalPrice: false,
    },
};

const $panelPrice = $('#js-panelShopPrice');
const $shopPrice = $('#js-shopPrice');
const $panelDiscount = $('#js-panelDiscount');
const $flashSalesDesc = $('#js-flashSalesDesc');

class GoodsPromoPrice {
    constructor() {
        this.resPrice = {};
        this.isShowPrice = true;
    }
    priceLoadCall() {}
    init() {
        const self = this;
        self.isShowDep = 0;
        self.isShowNorPrice = 0;
        PubSub.subscribe('goods.priceReady', (msg, resPrice) => {
            self.resPrice = resPrice;

            // 调试模拟数据
            // self.goodsStatus = 2;
            // self.resPrice.labelId = 8;
            // self.resPrice.startTime = (+new Date(2018, 2, 28)) / 1000;
            // self.resPrice.endTime = (+new Date(2018, 3, 3)) / 1000;
            // window.arrvialNoticeMsg = `{"subscribeCount":"","arrivalTime":${(+new Date(2018, 3, 31)) / 1000},"msg":"11 Submit Notice"}`;

            // 因设计问题：到货通知是商品状态，但又将状态面板设计在营销价状态中
            // 如若当前商品状态为 到货通知 -> 那将到货通知聚合到营销价状态中
            if (self.goodsStatus === 4) {
                self.resPrice.labelId = -2;

                const arrivalMsg = window.arrvialNoticeMsg || {};
                // 实际内容是到货通知信息
                self.arrivalMsg = arrivalMsg.msg || '';
                // 是否顯示價格
                self.isShowPrice = arrivalMsg.isShowPrice === undefined ? 1 : arrivalMsg.isShowPrice;

                // 实际内容是到货通知结束时间
                self.resPrice.endTime = arrivalMsg.arrivalTime || (new Date().getTime() / 1000);

                // 未给出到货通知状态开始时间，让开始时间小于当前时间即可
                self.resPrice.startTime = ((new Date().getTime()) - 5000) / 1000 || '';
            }
            if (+self.resPrice.labelId === 28) {
                const nowTime = (new Date()).getTime() / 1000;
                const canBuyQty = self.resPrice.saleQty - self.resPrice.count;
                if (nowTime - self.resPrice.startTime > 0 && self.resPrice.endTime - nowTime > 0 && nowTime - self.resPrice.advanceStartTime > 0
                    && self.resPrice.advanceEndTime - nowTime > 0 && canBuyQty > 0) {
                    self.isShowDep = 1; // 可以预付定金时显示
                } else if (nowTime - self.resPrice.startTime > 0 && self.resPrice.endTime - nowTime > 0 &&
                    (nowTime - self.resPrice.advanceStartTime < 0 || self.resPrice.advanceEndTime - nowTime < 0 || canBuyQty <= 0)) {
                    self.isShowNorPrice = 1; // 是定金膨胀但不可以预付定金时
                }
            }
            // 当前商品状态要在上述定义的商品状态 并且 lableId在上述定义的价格类型才展示营销面板
            if ((SHOWPRICE_STATUS.includes(+self.goodsStatus) && self.resPrice.labelId in PRICE_TYPE) || self.isShowDep) {
                if (+self.resPrice.labelId === 11) {
                    const nowTime = (new Date()).getTime() / 1000;
                    if (nowTime - self.resPrice.startTime > 0 && self.resPrice.endTime - nowTime > 0) {
                        self.renderTemp();
                    }
                } else {
                    self.renderTemp();
                }
            }

            // 公共状态处理(折扣标+划线价)
            self.normalPrice();

            setTimeout(this.priceLoadCall, 300);
        });
    }

    // 模板渲染输出
    renderTemp() {
        try {
            const self = this;
            const rendData = self.packageData();
            const $panelPromoPrice = $('#js-goodsPromoPrice');

            // 将模板内容填充到容器中
            $panelPromoPrice.html(tempPromo(rendData)).addClass('show');

            // 倒计时
            self.countdownHandle();

            // 更新货币
            PubSub.publish('sysUpdateCurrency');
        } catch (error) {
            throw new Error(error);
        }
    }

    // 处理划线价
    shopPrice() {
        if (this.resPrice.price < GOODSINFO.shopPrice && !GOODSINFO.isPlatform) {
            $shopPrice.show();
        }
    }

    // 折扣标显隐
    discountHandle() {
        if (/^-2$/.test(this.resPrice.labelId)) { // 到货通知不显示折扣
            return;
        }
        const discount = this.discount();
        if (discount > 0 && !GOODSINFO.isPlatform) {
            $panelDiscount.html(trans('goods.detail_percent_off', [discount])).addClass('show');
        }
    }

    // 整点秒杀未开始提示语显隐
    falshSalesbeginsIn() {
        const self = this;
        const resPrice = self.resPrice;
        const nowTime = Math.floor((new Date()) / 1000);
        if (+resPrice.labelId === 11 && resPrice.startTime - nowTime > 0 && resPrice.flashSalePrice) {
            const startTime = resPrice.startTime;
            const endTime = resPrice.endTime;
            $flashSalesDesc.addClass('show')
                .html(`<i class="icon-clock"></i>
                        <span class="goodsIntro_flashSalesText">${trans('goods.super_deals_begins_in')} 
                            <span class="goodsPromoPrice_time" data-start="${startTime}" data-end="${endTime}">
                            </span>
                            <span class="falshSalesPrice js-currency" data-currency="${resPrice.flashSalePrice}"></span>
                        </span>`);
            const $flashSalesPrice = $flashSalesDesc.find('.falshSalesPrice');
            // 倒计时
            self.countdownHandle();
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $flashSalesPrice.parent()[0]
            });
        }
    }

    // 处理常规价格区
    normalPrice(rendData = {}) {
        const self = this;

        if (!self.isShowPrice) {
            $('#js-goodsWrap').addClass('hide-price');
        }

        // 定金膨胀可预订时显示页面价格
        if (self.isShowDep) {
            $panelPrice.attr('data-currency', self.resPrice.pricePage).show().removeClass('price-loading-goods');
        } else if (self.isShowNorPrice) {
            $panelPrice.attr('data-currency', self.resPrice.priceFact).show().removeClass('price-loading-goods');
        } else {
            // 实时价显示
            $panelPrice.attr('data-currency', self.resPrice.price).show().removeClass('price-loading-goods');
        }
        // 划线价
        self.shopPrice();

        // 折扣标显隐
        self.discountHandle();

        // 整点秒杀未开始(预售)提示语
        self.falshSalesbeginsIn();

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: $panelPrice.parent()[0]
        });
    }

    // 组装数据
    packageData() {
        const self = this;
        const price = self.resPrice || {};
        const pkData = {
            labelId: price.labelId,
            name: self.saleName(),
            price: price.price,
            startTime: self.resPrice.startTime,
            endTime: self.resPrice.endTime,
            surplus: self.surplus(),
            preSaleCount: self.preSaleCount(),
            arrivalMsg: self.arrivalMsg,
            isShowPrice: self.isShowPrice,
        };
        if (+price.labelId === 28) {
            Object.assign(pkData, {
                saleQty: price.saleQty,
                userBuyLimit: price.userBuyLimit,
                pricePage: price.pricePage,
                priceFact: price.priceFact,
                advanceAmount: price.advanceAmount,
                deductionAmount: price.deductionAmount,
                swellDiscontAmount: price.swellDiscontAmount,
                finalAmount: price.finalAmount,
                advanceStartTime: price.advanceStartTime,
                advanceEndTime: price.advanceEndTime,
                finalStartTime: self.specialDate(price.finalStartTime),
                finalEndTime: self.specialDate(price.finalEndTime),
                isCanShowDep: self.isCanShowDep,
            });
        }
        return pkData;
    }

    // 促销类型
    saleName() {
        try {
            return PRICE_TYPE[this.resPrice.labelId].name || '';
        } catch (error) {
            return '';
        }
    }

    // 折扣计算
    discount() {
        try {
            const originPrice = GOODSINFO.shopPrice;
            return Math.round(divide(add(originPrice, -this.resPrice.price), originPrice) * 100);
        } catch (error) {
            return 0;
        }
    }

    // 倒计时显示处理
    countdownHandle() {

        const self = this;
        const { labelId } = this.resPrice;
        const $panelPromoTime = $('.goodsPromoPrice_time');

        if (!$panelPromoTime.length) {
            return;
        }

        if (/^[178]$/.test(labelId)) {
            /**
             * 邮件专享:1   限时限量:7  普通促销:8
             * Ends In: 5 days 23:59:59
             */

            const timer = new Timer($panelPromoTime, {
                format(interval) {
                    return interval < 3600 * 24 ? '{hh}:{mm}:{ss}' : '{dd}:{hh}:{mm}:{ss}';
                },
                interval() {
                    const now = Math.floor((new Date()) / 1000);
                    const start = $panelPromoTime.data('start');
                    const end = $panelPromoTime.data('end');
                    if (end - start > 7 * 3600 * 24) {
                        return end - (7 * 3600 * 24) - now;
                    }
                    return start - now;
                },
                onStart() {
                    $panelPromoTime.hide();
                },
                onEnd() {
                    $panelPromoTime.show();
                    timer.add($panelPromoTime, {
                        format(interval) {
                            return interval < 3600 * 24 ? '{hh}:{mm}:{ss}' : `${trans('goods.days_h_m_s', ['{dd}', '{hh}', '{mm}', '{ss}'])}`;
                        },
                        interval: 'end',
                        onEnd() {
                            $panelPromoTime.hide();
                            self.reloadPage();
                        }
                    });
                }
            });

        } else if (/^-?2$/.test(labelId)) {
            /**
             * 到货通知:-2 预售:2
             * 1天以上：3 days left
             * 1天以内：Ends In: 23:59:59
             */

            new Timer($panelPromoTime, {
                format(interval) {
                    if (interval <= 60 * 60 * 24) {
                        return `${trans('goods.ends_in')}{hh}:{mm}:{ss}`;
                    }
                    return trans('goods.days_left', ['{dd}']);
                },
                interval: 'end',
                onEnd() {
                    // self.reloadPage();
                }
            });
        } else if (/28/.test(labelId)) {
            new Timer($panelPromoTime, {
                format(interval) {
                    return interval < 3600 * 24 ? '{hh}:{mm}:{ss}' : `${trans('goods.days_h_m_s', ['{dd}', '{hh}', '{mm}', '{ss}'])}`;
                },
                interval() {
                    const now = Math.floor((new Date()) / 1000);
                    const start = $panelPromoTime.data('start');
                    const end = $panelPromoTime.data('end');
                    let downTime = '';
                    if (end - now > 0 && now - start > 0) {
                        downTime = end - now;
                    }
                    return downTime;
                }
            });
        } else if (/11/.test(labelId)) {
            new Timer($panelPromoTime, {
                format(interval) {
                    return interval < 3600 * 24 ? '{hh}:{mm}:{ss}' : `${trans('goods.days_h_m_s', ['{dd}', '{hh}', '{mm}', '{ss}'])}`;
                },
                interval() {
                    const now = Math.floor((new Date()) / 1000);
                    const start = $panelPromoTime.data('start');
                    const end = $panelPromoTime.data('end');
                    let downTime = '';
                    if (end - now > 0 && now - start > 0) {
                        downTime = end - now;
                    } else if (end - now > 0 && start - now > 0) {
                        downTime = start - now;
                    }
                    return downTime;
                }
            });
        }
    }

    // 刷新页面
    reloadPage() {
        window.location.href = window.location.href;
    }

    // 剩余量计算
    surplus() {
        try {
            const price = this.resPrice || {};
            const result = {};

            // 可售出数量未设置，表示为不限出售数量，则隐藏剩余量进度条
            if (!String(price.saleQty).length) {
                result.count = -1;
                result.percent = -1;
            } else if (+this.stock <= 0) {
                result.count = 0;
                result.percent = 100;
            } else {
                // 总数量（可售数量+虚拟售出数量）
                const allCount = (+price.saleQty) + (+price.virtualSaleQty);

                // 共已售出量(虚拟售出 + 虚拟增量售出 + 用户已购买)
                let saledCount = (+price.count) + (+price.virtualSaleQty);

                // 防止计算溢出
                if (saledCount > allCount) {
                    saledCount = allCount;
                }

                // 限时限量剩余量(总数量-共已售出量)
                result.count = allCount - saledCount;

                // 防止计算出错
                if (allCount < 1) {
                    result.percent = 0;
                } else {
                    // 显示剩余量进度条 ((共已售出/共可售出) *100)
                    result.percent = (saledCount / allCount) * 100;
                }
            }

            return result;
        } catch (error) {
            return {
                count: -1,
                percent: -1,
            };
        }
    }

    /**
     * 预售数量
     */
    preSaleCount() {
        try {
            const price = this.resPrice || {};

            // 预售数量（虚拟售出+起批量）
            return (+price.count) + (+price.virtualSaleQty);
        } catch (error) {
            return 0;
        }
    }

    /**
     * 最后支付尾款时间显示
     */
    specialDate(time) {
        const date = new Date(time * 1000);
        const yy = date.getFullYear();
        const MM = date.getMonth() + 1;
        const dd = date.getDate();
        const hh = date.getHours() > 9 ? date.getHours() : `0${date.getHours()}`;
        const mm = date.getMinutes() > 9 ? date.getMinutes() : `0${date.getMinutes()}`;
        const spTime = `${yy}.${MM}.${dd} ${hh}:${mm}`;
        return spTime;
    }
}

export default GoodsPromoPrice;
