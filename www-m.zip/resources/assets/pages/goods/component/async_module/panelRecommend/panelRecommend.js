import { getGoodsRecommend } from 'js/service/other.js';
import PubSub from 'pubsub-js';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import tempRecom from './panelRecommend.art';
// import './skeletonRecommend.css';
import './panelRecommend.css';

const GOODSINFO = GoodsInfo.get();
/* eslint-disable */
class GoodsRecom {
    constructor(target) {
        this.type = target.dataset.type;
        this.trackClass = target.dataset.trackClass;
        this.$panelGoodsRecom = $(target).find('.js-panelGoodsRecom');
        this.dataList = [];
        // this.skeleton();
        this.getData();
    }

    skeleton() {
        const list = [];
        list.length = 6;
        this.$panelGoodsRecom.html(tempRecom({
            pageType: 'skeleton',
            list
        }));
    }

    // 获取数据
    async getData() {
        try {
            const res = await getGoodsRecommend({
                loading: false,
                errorPop: false,
                isCannel: false,
                params: {
                    goodSn: GOODSINFO.goodsSn,
                    shopCode: GOODSINFO.shopCode,
                    categoryid: GOODSINFO.categoryId,
                    type: this.type,
                }
            });
            if (+res.status === 0) {
                if (res.data && res.data.length) {
                    this.dataList = res.data;
                    this.renderRecom(res);
                }
            } else {
                throw new Error('get data fial !');
            }
        } catch (error) {
            this.$panelGoodsRecom.parent().hide();
        }
    }

    // 处理数据
    handleData() {
        const list = this.dataList;
        return list;
    }

    // 填充数据
    renderRecom(res) {
        const self = this;
        const list = self.handleData();

        this.$panelGoodsRecom.html(tempRecom({
            trackClass: this.trackClass,
            versionid: res.versionid,
            bucketid: res.bucketid,
            planid: res.planid,
            plancode: res.plancode,
            policy: res.policy,
            list,
        })).parent().show();

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: this.$panelGoodsRecom[0]
        });
    }
};

const goodsRecomIns = {
    init(target) {
        return new GoodsRecom(target);
    }
}

export default goodsRecomIns;
