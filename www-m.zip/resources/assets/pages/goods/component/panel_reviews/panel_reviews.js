// goods组件-评论
import Swiper from 'js/lib/swiper.js';
import Reviews from '../review/review.js';

// const $goodsReviewsPreview = $('.goodsReviews_preview');
const goodsReviews = {
    init() {
        // 评论
        this.insReviews = new Reviews();
        this.insReviews.init();
        // 评论图片swiper滚动
        new Swiper(document.getElementsByClassName('js-goodsReviewsImgs'), {
            slidesPerView: 'auto'
        });
        this.bindEvent();
    },
    bindEvent() {
        // if ($goodsReviewsPreview.length) {
        //     $goodsReviewsPreview.find('.goodsReviews_item').on('click', (e) => {
        //         const targetIsImgOrVideo = /(goodsReviews_img|goodsReviews_imgItem)/.test(e.target.classList.value);
        //         // detail板块评价，点击除（图片|视频）外均跳转到Reviews大区
        //         if (!targetIsImgOrVideo) {
        //             goodsNav.panelShow(2);
        //         }
        //     });
        // }
    }
};
goodsReviews.init();

export default goodsReviews;
