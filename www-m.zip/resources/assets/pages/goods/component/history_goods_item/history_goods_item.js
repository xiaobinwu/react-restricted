
import PubSub from 'pubsub-js';
import runtime from 'art-template/lib/runtime';
import GoodsViewHistory from 'js/core/goods/goodsViewHistory.js';
import { asyncPrice } from 'js/core/asyncPrice';
import temp from './history_goods_item.art';
import './history_goods_item.css';

runtime.GLOBAL = window.GLOBAL;
runtime.blank = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

const $btnEdit = $('#js-btnOpenEditing'); // 开启编辑按钮
const $panelHistoryWrap = $('#js-panelHistoryWrap'); // 历史记录页面区域
const $panelHistory = $('#js-panelHistory'); // 历史记录列表区域
const $ckboxSwitchAll = $('#js-ckboxSwitchAll'); // 全（不）选 checkbox
const $btnDeleteHistory = $('#js-btnDeleteHistory'); // 执行删除按钮

export const historyShow = {
    init() {
        this.arrSelectedIndex = [];
        this.render();
        this.bindEvent();
    },

    bindEvent() {
        const self = this;

        // 开启编辑状态
        $btnEdit.on('click', (e) => {
            e.preventDefault();
            $panelHistoryWrap.toggleClass('editing');
        });

        // 切换每条历史记录选项
        $panelHistoryWrap.on('click', '.js-ckboxHistoryItem', (e) => {
            const $this = $(e.currentTarget);
            const index = $this.val();
            const checked = $this.prop('checked');
            self.itemCheckedSwitch(index, checked);
        });

        // 局部滚动需要执行懒加载
        $panelHistory.on('scroll', () => {
            // 更新懒加载
            PubSub.publish('sysInitLazyload', {
                context: $panelHistoryWrap[0]
            });
        });

        // 批量切换选项
        $ckboxSwitchAll.on('click', (e) => {
            const checked = $(e.currentTarget).prop('checked');
            self.batchCheckedSwitch(checked);
        });

        // 删除所选项
        $btnDeleteHistory.on('click', () => {
            if (self.arrSelectedIndex.length > 0) {
                GoodsViewHistory.remove(self.arrSelectedIndex);
                self.arrSelectedIndex = [];
                self.render();
            }
        });
    },

    render() {
        const historyList = GoodsViewHistory.get();

        // 填充历史记录到页面
        $panelHistory.html(temp({
            list: historyList
        }));

        if (historyList.length) {
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $panelHistory[0]
            });

            // 实时价
            asyncPrice({
                callback(item, displayPrice) {
                    if ($(item).data('shop-price') <= displayPrice) {
                        $(item).next().hide();
                    }
                }
            });
        }

        // 可操作处理
        this.setHandle(historyList);
    },

    setHandle(historyList) {
        if (!historyList.length) {
            $panelHistoryWrap.removeClass('editing');
            $btnEdit.css('visibility', 'hidden');
        } else {
            $btnEdit.css('visibility', 'visible');
        }
    },

    // 批量切换选择
    batchCheckedSwitch(checked) {
        const self = this;
        const $items = $panelHistory.find('.js-ckboxHistoryItem');

        // 改变all选项状态
        $items.prop('checked', checked);

        if (checked) { // 全选
            $items.each((index, item) => {
                self.arrSelectedIndex.push(+index);
            });
        } else { // 全不选
            self.arrSelectedIndex = [];
        }
    },

    // 单项切换选择
    itemCheckedSwitch(index, checked) {
        const self = this;
        if (checked) {
            self.arrSelectedIndex.push(+index);
        } else {
            self.arrSelectedIndex.forEach((element, idx) => {
                if (+index === +element) {
                    self.arrSelectedIndex.splice(idx, 1);
                }
            });
        }

        self.allIsChecked();
    },

    allIsChecked() {
        const $items = $panelHistory.find('.js-ckboxHistoryItem');
        const arrAll = [];
        const arrNo = [];
        $items.each((index, item) => {
            if ($(item).prop('checked')) {
                arrAll.push(index);
            } else {
                arrNo.push(index);
            }
        });
        $ckboxSwitchAll.prop('checked', arrAll.length === 0);
        $ckboxSwitchAll.prop('checked', arrNo.length === 0);
    }
};
