/* #Arrival Notice 到货通知弹窗# */
import layer from 'layer';
import { serviceArrivalNotice } from 'js/service/goods.js';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import 'component/form/form.js';
import temp from './arrival_notice.art';
import './arrival_notice.css';

const GOODSINFO = GoodsInfo.get();

export const arrivalNotice = {
    bindEvent() {
        const self = this;
        const $form = $('#js-formArrivalNotice');
        this.$captch = $('.js-imgCaptch');

        // 提交表单
        $form.off('submit').on('submit', () => {
            self.subArrivalNotice($form.serialize());
        });

        // 刷新验证码
        this.$captch.off('click').on('click', () => {
            self.refreshCaptch();
        });
    },

    // 开启弹窗
    show() {
        const self = this;
        this.layero = layer.open({
            type: 5,
            className: 'goodsArrival',
            content: temp({
                goods: {
                    goodSn: GOODSINFO.goodsSn,
                    vhCode: GOODSINFO.warehouseCode,
                    pipelineCode: GOODSINFO.pipelineCode,
                    lang: window.GLOBAL.LANG,
                }
            }),
            success() {
                self.bindEvent();
                const h = $(window).height();
                $('body,html').css({
                    overflow: 'hidden',
                    height: `${h}px`
                });
            },
            end() {
                $('body,html').css({
                    overflow: 'visible',
                    height: 'auto'
                });
            }
        });
    },

    // 提交订阅信息
    async subArrivalNotice(sdata) {
        try {
            const self = this;
            const res = await serviceArrivalNotice.http({
                errorPop: false,
                loading: true,
                method: 'POST',
                data: sdata,
            });
            layer.msg(res.msg || '@warning:Server error');
            self.refreshCaptch();
            if (+res.status === 0) {
                layer.close(self.layero);
            }
        } catch (error) {
            throw new Error(error);
        }
    },

    // 刷新验证码
    refreshCaptch() {
        $('.js-iptCaptch').val('');
        this.$captch.attr('src', `${this.$captch.data('path')}?${Math.random()}`);
    }
};
