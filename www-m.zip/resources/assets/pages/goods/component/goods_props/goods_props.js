// 属性面板（属性切换|数量控件|分期付款|属性变更按钮状态）

import PubSub from 'pubsub-js';

// 数量控件
import InputNumber from 'component/input_number/input_number.js';

// 公用多规格属性
import GoodsAttr from 'component/goods_attr/goods_attr.js';
import specAnimate from 'js/utils/specAnimate.js';

import layer from 'layer';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import { multiply } from 'js/core/currency.js';
import { trans } from 'js/core/translate.js';

// 记录进入商详来源
import RecordToGoods from 'js/core/goods/recordToGoods.js';

import borderStopScroll from 'component/borderStopScroll';

// 大数据 切换属性，记录bts
import { goodsTrack } from 'common/js/track/define/goods';

import { STORAGE_SOURCE_ORIGIN } from 'common/js/variables';

import './goods_props.css';

const GOODSINFO = GoodsInfo.get();
const $panelGoodsProps = $('#js-goodsProps');
const $panelPropBtns = $('#js-panelGoodsPropBtns');
const $panelPropsImg = $('#js-panelPropsImg');
const $panelPropsTitle = $('#js-panelPropsTitle');
const $panelPropsPrice = $('#js-panelPropsPrice');
const goodsProps = {
    isInit: false,
    init() {
        if (this.isInit) return;
        this.isInit = true;
        // 数量控件 - 实例化
        this.insGoodsNumber = this.goodsNumber();

        // 因切换属性(this.goodsAttr中变更)时，产生新的SKU，对应不同的页面，需要跳转地址，在关闭属性弹层时使用
        this.needLocationHref = '';

        // 商品规格属性
        const goodsAttr = this.goodsAttr();

        // 初始化商品规格属性
        goodsAttr.init();

        // 事件
        this.bindEvent();

        this.updatePropPanel();

        borderStopScroll({
            wrapEle: $panelGoodsProps[0]
        });
        borderStopScroll({
            wrapEle: document.querySelector('#js-goodsPropsPanel')
        });
    },

    bindEvent() {
        const self = this;

        // 关闭属性面板
        $panelGoodsProps.on('click', '.js-btnHideAttrPanel', () => {
            self.hide();
            if (window.insInstallment) {
                window.insInstallment.hide();
            }
        });

        // 商品状态就绪 - 变更商品属性时（每次执行）
        PubSub.subscribe('goods.goodsStatusReady.every', () => {
            // 更新属性面板上商品信息
            self.updatePropPanel();
        });

        // 加车成功后关闭属性面板
        PubSub.subscribe('sysAddToCartSuccess', () => {
            goodsProps.hide();
        });

        // 点击遮罩层关闭弹窗
        $panelGoodsProps.on('click', (e) => {
            if ($(e.target).find('.goodsProps_panel').length > 0) {
                self.hide();
            }
        });
    },

    resetParams() {
        // 暂无需求
    },
    // 显示商品属性面板
    show(buyType, goodsData, reset) {
        if (reset) this.resetParams();

        // 合并参数
        Object.assign(this, goodsData);
        this.btnBuyType = buyType;

        // 尝试初始化 执行一次
        this.init();

        this.updateBtns();
        specAnimate.show({
            ele: $panelGoodsProps[0],
            fn() {
                $panelGoodsProps.addClass('show');
            }
        });
    },

    // 隐藏商品属性面板
    hide() {
        $panelGoodsProps.removeClass('show');
        // 假如选择了新的属性，关闭时需要跳转页面
        this.locationPageByGoods();
    },

    // 更新属性面板信息
    updatePropPanel() {
        const product = this.goodsGlobal.asyncProduct;

        // 基础信息（图片|标题|价格）
        this.updateGoods(product);
        // 面板属性切换数量重置为1
        this.insGoodsNumber.setMax(1);

        // 数量限制
        if (+product.labelId === 28 && +product.isShowDep) {
            this.insGoodsNumber.setMax(product.lessCanBuy);
            this.insGoodsNumber.setDisable(false);
        } else if (product.stockSum < 1) {
            this.insGoodsNumber.setMax(1);
            this.insGoodsNumber.setDisable(true);
        } else {
            this.insGoodsNumber.setMax(product.stockSum);
            this.insGoodsNumber.setDisable(false);
        }

        // 加车时传实时价
        this.SELECTEDGOODS.price = product.displayPrice;

        // 更新按钮状态
        this.updateBtns();
    },

    // 配置属性面板参数
    goodsAttr() {
        const self = this;
        const goodsLink = window.goodsLink || [];
        return new GoodsAttr({
            goodsList: goodsLink,

            jqWrap: $panelGoodsProps,
            rowCls: 'js-goodsPropsRow',

            activeCls: 'active',
            multiplyAttrName: 'prime',

            success(product) {
                const primeGoodsSn = product.goodSn;
                const primeVirWhCode = product.virCode;

                // 关闭属性面板时需要用的链接
                self.needLocationHref = product.url;

                // 变更将要加入购物车的商品对象信息
                self.SELECTEDGOODS.goodsSn = primeGoodsSn;
                self.SELECTEDGOODS.warehouseCode = primeVirWhCode;

                // 变更商品状态信息（异步获取）
                self.goodsGlobal.getGoodsStatus(primeGoodsSn, primeVirWhCode, 'every');
            },
            fail() {
                // 仅更新属性面板上按钮状态
                self.updateBtns({
                    goodsStatus: '-100'
                });
            }
        });
    },

    // 更新属性面板上商品信息
    updateGoods(product) {
        $panelPropsImg.attr('src', product.img);
        $panelPropsTitle.html(product.goodTitle);
        if (+product.labelId === 28 && +product.isShowDep) {
            $panelPropsPrice.attr('data-currency', product.pricePage).text(product.pricePage);
        } else {
            $panelPropsPrice.attr('data-currency', product.displayPrice).text(product.displayPrice);
        }
        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: $panelPropsPrice.parent()[0]
        });
    },

    // 数量控件
    goodsNumber() {
        const self = this;
        return new InputNumber('js-goodsPropsQTY', {
            // input值有变化时
            onChange(val) {
                self.SELECTEDGOODS.qty = val;
                self.switchPaypalBtn('numberChange');
                PubSub.publish('goods.numberChange', val);
            },
            onMax(val) {
                if (+self.goodsGlobal.asyncProduct.labelId === 28 && +self.goodsGlobal.asyncProduct.isShowDep) {
                    if ($('#js-goodsPropsPanel .canBuyTip').length) {
                        return;
                    }
                    $('.goodsProps_qty').after(`<p class="canBuyTip">
                    ${trans('goods.deposit_detail_canbuytip', [self.goodsGlobal.asyncProduct.lessCanBuy])}</p>`);
                    setTimeout(() => {
                        $('.canBuyTip').remove();
                    }, 3000);
                }
            }
        });
    },

    /**
     * 操作按钮状态
     *
     * 返回goodsStatus 对应值
     * 1    待发布
     * 2    上架
     * 3    下架(discontinued)
     * 4    到货通知(arrival notice)
     * 5    谍照
     */
    updateBtns() {
        let btns = [];
        const self = this;
        const product = this.goodsGlobal.asyncProduct;
        const status = product.goodsStatus;
        const stock = product.stockSum;
        const stateHandle = {
            // 未匹配到
            '-100': () => {
                btns = [{
                    cls: 'btn disabled',
                    txt: this.GOODSLANG.unmatched_goods,
                }];
            },
            // 待发布
            1: () => {
                btns = [{
                    cls: 'btn disabled',
                    txt: this.GOODSLANG.comming_soon,
                }];
            },
            // 正常
            2: () => {
                // 库存大于0才可购买
                if (stock > 0) {
                    if (/cart/.test(self.btnBuyType)) {
                        btns.push({
                            cls: 'btn goodsBtnCart js-addToCart',
                            txt: this.GOODSLANG.add_to_cart,
                        });
                    }

                    if (/buynow/.test(self.btnBuyType)) {
                        btns.push({
                            cls: 'btn goodsBtnPaypal js-buyNowWithPaypal',
                            txt: '',
                        });

                        btns.push({
                            cls: 'btn goodsBtnBuyNow js-buyNow',
                            txt: this.GOODSLANG.buy_now,
                        });
                    }
                } else {
                    btns.push({
                        cls: 'btn disabled',
                        txt: this.GOODSLANG.out_of_stock,
                    });
                }
            },
            // 下架
            3: () => {
                btns.push({
                    cls: 'btn disabled',
                    txt: this.GOODSLANG.discontinued,
                });
            },
            // 可订阅
            4: () => {
                btns.push({
                    cls: 'btn goodsBtnNotice js-arrivalNotice',
                    txt: this.GOODSLANG.arrival_notice,
                });
            },
        };
        if (stateHandle[status]) {
            stateHandle[status]();
            $panelPropBtns.empty();
            btns.forEach((item) => {
                const $btn = $('<a>').addClass(item.cls).text(item.txt);
                if (item.data) {
                    $btn.attr(`data-${item.data[0]}`, item.data[1]);
                }
                $panelPropBtns.append($btn);
            });
            self.switchPaypalBtn();
        }
        if (+product.labelId === 28 && +product.isShowDep) {
            const strBNow = `<span class="payDepositWrap">${trans('goods.deposit_detail_paydeposit')}</span>
            <span class="payDepositPrice js-currency js-btnPayDepositPrice" data-currency="${product.advanceAmount}"></span>`;
            $('.goodsBtnBuyNow').css('display', 'inline-block');
            $('.goodsBtnBuyNow').html(strBNow);
            $('.goodsBtnCart').css('display', 'none'); // 定金膨胀时隐藏加车按钮
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $('.goodsBtnBuyNow .js-btnShowAttrPanel').parent()[0]
            });
        }
    },

    // 如果变更了商品属性，关闭属性面板时要跳转页面
    locationPageByGoods() {
        const selectGoods = this.SELECTEDGOODS;
        const currentPageGoods = this.GoodsInfo.get();
        if (selectGoods.goodsSn !== currentPageGoods.goodsSn) {
            // 记录商详来源是来自属性切换
            RecordToGoods.set('isChangeAttr', true);

            const currentOrigin = goodsTrack.getRecordOrigin();
            if (Object.keys(currentOrigin).length) {
                window.sessionStorage.setItem(STORAGE_SOURCE_ORIGIN, JSON.stringify(currentOrigin));
            }
            goodsTrack.saveBTS(goodsTrack.getBTS());

            window.location.href = this.needLocationHref;
        }
    },

    // 切换paypal支付按钮显示
    switchPaypalBtn(type) {
        if (GOODSINFO.ppExpressInfo) {
            const $btnGoodsBuyNowPaypal = $('.js-buyNowWithPaypal');
            const { price, qty } = this.SELECTEDGOODS;
            const totalPrice = multiply(price, qty);
            // 除土耳其外其他都按新需求优化 http://jira.hqygou.com/browse/GB-20026
            const countryCode = window.GLOBAL.PIPELINE;
            let btnNeedHide = Boolean(GOODSINFO.ppExpressInfo.hide);
            const priceData = window.goodsPriceData || {};
            const product = this.goodsGlobal.asyncProduct;

            if (countryCode !== 'GBTR') {
                const payPalHtml = '<img src="https://uidesign.gbtcdn.com/GB/images/others/gb_pic/lightningM.png" class="lightningPayPalImg">';
                $btnGoodsBuyNowPaypal.html(payPalHtml);
            }

            // 商品单价大于paypal最大可支付价，则不可用paypay支付按钮
            if (price > GOODSINFO.ppExpressInfo.ppMax) {
                btnNeedHide = true;
            }

            // 无营销状态数据
            if (!priceData || typeof priceData.labelId === 'undefined') {
                btnNeedHide = true;
            }

            // 营销状态不可用情况 7:限时限量
            if (priceData && typeof priceData.labelId !== 'undefined' && /^[7]$/.test(priceData.labelId)) {
                btnNeedHide = true;
            }

            // 定金膨胀隐藏paypal按钮
            if (+product.labelId === 28 && +product.isShowDep) {
                btnNeedHide = true;
            }

            // 隐藏paypal按钮
            $btnGoodsBuyNowPaypal[btnNeedHide ? 'hide' : 'show']();

            if (totalPrice < GOODSINFO.ppExpressInfo.ppMin || totalPrice > GOODSINFO.ppExpressInfo.ppMax) {
                // 选择数量后结算总价小于最小支付价  或 大于最大支付价，置灰paypal支付按钮
                $btnGoodsBuyNowPaypal.addClass('disabled');

                // 数量变化且总结算金额大于最大可支付价
                if ($('#js-panelGoodsPropBtns').find('.js-buyNowWithPaypal').length) { // paypal支付面板中才提示
                    if (type === 'numberChange' && totalPrice > GOODSINFO.ppExpressInfo.ppMax && !product.isShowDep) {
                        layer.msg(trans('goods.cant_use_paypal_tip')); // product.isShowDep是定金膨胀时隐藏弹窗
                    }
                }
            } else { // 其他情况移除禁用
                $btnGoodsBuyNowPaypal.removeClass('disabled');
            }
        }
    },
};

export default goodsProps;
