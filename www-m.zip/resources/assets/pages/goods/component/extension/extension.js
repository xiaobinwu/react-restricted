import Cookies from 'js/utils/cookie';
import { getUrlQuery } from 'js/utils';
import isLogin from 'js/core/user/isLogin';
import { COOKIE_PIPELINE, STORAGE_SHOW_OPEN_APP_TIME } from 'js/variables';
import GoodsInfo from 'js/core/goods/goodsInfo';
import appStat from 'js/core/app.stat.js';
import { getEmailEo } from '../../common/getEmailEo.js';

// 大数据埋点
import appTrack from './extensionApp';
import './extension.css';

const GOODSINFO = GoodsInfo.get();
const curCookies = Cookies.get();
const UA = navigator.userAgent.toLowerCase();
const IS_IOS = UA.indexOf('os') > 0;
const IS_IOSSAFARI = /iP(ad|hone|od).+Version\/[\d\\.]+.*Safari/i.test(UA);
const IS_SAFARI = /Version\/[\d\\.]+.*Safari/i.test(UA);
const EO = getEmailEo(); // 商详邮件专享价加密串

// 关闭层记录 页面对应的存储key
const pageLocal = {
    product: 'closeTimeProd',
    index: 'closeTimeIndex'
};

/**
 * 创建查询串
 * @param {键值对} JSON keyValJson, 例如： {a: 1, b:2}
 * @param {前缀} String prefix, 例如 ? &
 * @return {用&拼接的uri查询串} String
 */
function createSearchs(keyValJson, prefix = '') {
    const searchs = [];
    for (const o in keyValJson) {
        searchs.push([o, keyValJson[o]].join('='));
    }
    return `${prefix}${searchs.join('&')}`;
}

// 关闭引流层本地存储逻辑
class LocalCloseTime {
    constructor() {
        this.timeObj = LocalCloseTime.get();
    }

    static get(pageKey) {
        let localCTime = null;

        try {
            const timeObj = JSON.parse(window.localStorage.getItem(STORAGE_SHOW_OPEN_APP_TIME));
            // 如果存在本地存储，取出对象
            if (timeObj) localCTime = timeObj;
        } catch (error) {
            // 无处理
        }

        // 提供单独取key
        if (pageKey && localCTime && localCTime[pageKey] !== 'undefined') {
            return localCTime[pageKey];
        }

        return localCTime;
    }

    static set(pageKey, timeVal) {
        const timeObj = this.get() || {};

        if (pageKey !== 'undefined') {
            timeObj[pageKey] = timeVal;
        }

        window.localStorage.setItem(STORAGE_SHOW_OPEN_APP_TIME, JSON.stringify(timeObj));
    }
}


class Extension {
    constructor({
        callback = $.noop,
        hideCallback = $.noop,
        pageType
    } = {}) {
        this.$box = $('.js-openAppBox'); // $DOM 引流层面板
        this.$openAppBtn = this.$box.find('.js-openAppBox-btn'); // $DOM 打开APP

        this.pageType = pageType; // 页面区分
        this.closeLocalKey = pageLocal[pageType]; // 引流层关闭记录：当前页面的存储key

        this.query = getUrlQuery(window.location.href); // 当前页面查询键值对

        this.thirdParty = ''; // 第三方参数串

        // 可以显示APP引流层
        if (this.canShowApp()) {
            this.showAppBannerHandle(); // 内部回调处理

            this.bindEvent(); // 引流层事件绑定

            appTrack(); // 引流层大数据埋点

            callback(this); // 外部因调处理

        } else {
            // 隐藏引流层
            this.$box.data('close', 1);

            // 购物车上方显示新注册奖励提示
            if (this.showRegTipStatement()) {
                $('#js-goodsCart').addClass('goodsCart-regTip');
            }

            hideCallback(this); // 隐藏时外部因调处理
        }
    }

    // 是否可显示引流条
    canShowApp() {
        const { channel } = this.query;
        let showApp = true;

        // 查询引流层关闭时间点
        const localCloseTime = LocalCloseTime.get(this.closeLocalKey) || 0;
        // 如果用户主动关闭引流层一天以内，继续隐藏层
        if (localCloseTime && ((+new Date() - localCloseTime) < 24 * 60 * 60 * 1000)) {
            showApp = false;
        }

        // 明确来自app标识 或 ios需要显示 或 android需要显示
        if (
            (channel && channel.toLowerCase() === 'app') ||
            (IS_IOS && this.$box.data('ios-show') === 1) ||
            (!IS_IOS && this.$box.data('android-show') === 1)
        ) {
            // showApp = true;
        } else {
            showApp = false;
        }

        // 商详页 来自广告推广过来的新用户
        if (this.showRegTipStatement()) {
            showApp = false;
        }

        return showApp;
    }

    // 商详页 来自广告推广过来的新用户
    showRegTipStatement() {
        let isNewInGoods = true;

        if (
            this.pageType !== 'product' ||
            !this.isAduser() ||
            isLogin() ||
            curCookies[COOKIE_PIPELINE] !== 'GB'
        ) {
            isNewInGoods = false;
        }

        return isNewInGoods;
    }

    // 确定显示引流层后处理
    showAppBannerHandle() {
        const sascid = this.getSascid();

        // 配置跳转链接和超时
        this.config = {
            timeout: IS_IOSSAFARI ? 2000 : 2000,
            jump: this.getJumpHref(sascid) // 跳转到推广APP页面的链接
        };

        // 第三方推广查询串
        this.thirdParty = this.getThirdSearchs(sascid);

        // 创建M版直接跳转APP的协议链接
        this.$openAppBtn.attr('href', this.getToAppLink());

        // 显示引流层
        this.$box.addClass('show');
        $('.topHeader').addClass('hasAppBanner');
    }

    getSascid() {
        let sascid = this.query.sascid || '';

        if (sascid) { // url有sascid有则存到cookie
            Cookies.set('sascid', sascid, { expires: 30 });
        } else if (curCookies.sascid) { // cookie中有sascid
            sascid = curCookies.sascid;
        }

        return sascid;
    }

    // 获取跳转到推广APP落地页链接+参数(sascid查询值)
    getJumpHref(sascid) {
        const spreadSearchObj = {};

        // 如果 有sascid
        if (sascid) {
            spreadSearchObj.sascid = sascid;
        }

        // 如果商详页 并且 享邮件专享价
        if (EO && this.pageType === 'product') {
            spreadSearchObj.eo = EO;
        }

        return `${GLOBAL.DOMAIN_MAIN}/spread-app.html${createSearchs(spreadSearchObj, '?')}`;
    }

    // 获取并组装推广参数查询串
    getThirdSearchs(sascid) {
        const {
            utm_source: utmSource = curCookies.utm_source || '',
            utm_medium: utmMedium = curCookies.utm_medium,
            utm_campaign: utmCampaign = curCookies.utm_campaign,
        } = this.query;

        // 如果是以下渠道 或者有 邮件专享价
        if (sascid || utmSource || utmMedium || utmCampaign || EO) {
            // 默认情况
            let urlObj = {
                sascid,
                utm_source: utmSource,
                utm_medium: utmMedium,
                utm_campaign: utmCampaign,
                eo: EO,
            };

            // 首页
            if (this.pageType === 'index') {
                urlObj = {
                    sascid,
                    utm_source: utmSource,
                    utm_medium: utmMedium,
                    utm_campaign: utmCampaign
                };
            }

            // utm_source admitad渠道
            if (utmSource === 'admitad') {
                const {
                    admitad_uid: admitadUid = curCookies.admitad_uid || '',
                    utm_content: utmContent = curCookies.utm_content || ''
                } = this.query;

                urlObj = {
                    trace: 'third',
                    admitad_uid: admitadUid,
                    utm_source: utmSource,
                    utm_content: utmContent
                };
            }

            // utm_source zanox渠道
            if (utmSource === 'zanox') {
                const {
                    zanpid = curCookies.zanpid || '',
                    awc = curCookies.awc || '',
                    awin_publisher: awinPublisher = curCookies.awin_publisher || ''
                } = this.query;

                urlObj = {
                    trace: 'third',
                    zanpid,
                    awc,
                    awin_publisher: awinPublisher,
                    utm_source: utmSource,
                    utm_campaign: utmCampaign
                };
            }

            // utm_source 以tt_开头 渠道
            if (utmSource.indexOf('tt_') > -1) {
                const {
                    utm_content: utmContent = curCookies.utm_content || '',
                    campaign = curCookies.campaign || '',
                    data = curCookies.data || ''
                } = this.query;

                urlObj = {
                    trace: 'third',
                    utm_source: utmSource,
                    utm_campaign: utmCampaign,
                    utm_content: utmContent,
                    campaign,
                    data,
                };
            }

            return createSearchs(urlObj, '&');
        }

        return '';
    }

    // 创建M版直接跳转APP的协议链接
    getToAppLink() {
        let schemeUrl = '';
        const { lkid: linkid = (curCookies.lkid || '') } = this.query;

        // 商详页
        if (this.pageType === 'product') {
            schemeUrl = createSearchs({
                lkid: linkid,
                goods_web_sn: GOODSINFO.webGoodsSn,
                warehouse_code: GOODSINFO.warehouseCode,
                from: 'm',
            }, 'gearbest://product?');
        }

        // 首页
        if (this.pageType === 'index') {
            schemeUrl = createSearchs({
                lkid: linkid,
                expiresat: curCookies.linkid_exp || '',
                from: 'm',
            }, 'gearbest://home/?');
        }

        return schemeUrl + this.thirdParty;
    }

    bindEvent() {
        // [打开APP] 按钮
        this.$openAppBtn.on('click', (e) => {
            this.appLinkToDetail();
        });

        // 点击[打开APP] 按钮，复制查询加密串
        appStat({
            query: this.query,
            target: this.$openAppBtn[0],
        });

        // 关闭引流层
        this.$box.find('.js-clearApp').on('click', (e) => {
            // 关闭引流面板记录至本地存储
            LocalCloseTime.set(this.closeLocalKey, +new Date());

            // 引流面板关闭状态
            this.$box.removeClass('show').data('close', '1');

            // 样式隐藏引流面板
            $('.show_openApp').removeClass('show_openApp');
            $('.topHeader').removeClass('hasAppBanner');
            $('.topHeader').css('height', $('.fixedHeader').height());
        });
    }

    appLinkToDetail() {
        const self = this;
        const startTime = new Date().getTime();
        let timerToApp = null;

        timerToApp = setTimeout(() => {
            const endTime = new Date().getTime();
            if (!startTime || endTime - startTime < self.config.timeout + 200) {
                const symbol = (self.config.jump.indexOf('?') > -1) ? '&' : '?';
                let hadApp = '';

                // 浏览器类型+页面来源
                hadApp = `${symbol}hadApp=${IS_SAFARI ? 1 : 0}&pageType=${self.pageType}`;

                // 商详页追加 sku 和 仓库码
                if (self.pageType === 'product') {
                    hadApp += `&goods_web_sn=${GOODSINFO.webGoodsSn}&warehouse_code=${GOODSINFO.warehouseCode}`;
                }

                window.location.href = self.config.jump + hadApp + self.thirdParty;
            }
        }, self.config.timeout);

        // 离开页面时中断倒计时(中止跳转)
        const hdPrefix = ['', 'webkit', 'moz', 'ms'].find(item => document[`${item}hidden`] !== 'undefined');
        const hdEvent = `${hdPrefix}visibilitychange`;
        const hdProperty = `${hdPrefix}hidden`;
        document.addEventListener(hdEvent, () => {
            if (document[hdProperty]) clearTimeout(timerToApp);
        }, false);

        // 当前页面窗口失去焦点时(中止跳转)
        window.onblur = () => {
            clearTimeout(timerToApp);
        };
    }

    /**
     * 是否广告用户
     * @param {*cookies} cookies集合
     * @param {*type} one || all 满足一个即可，还是满足所有
     */
    isAduser({
        // google facebook pinterest 广告用户
        cookies = ['_gcl_aw', 'utm_source:facebook', 'utm_source:pinterest'],
        type = 'one'
    } = {}) {
        // 只满足一个使用 some , 要满足所有使用every
        const filterType = type === 'one' ? 'some' : 'every';
        if (cookies.length) {
            return cookies[filterType]((item, index) => {
                let flag = 0;
                if (item.length) {
                    const arrSplit = item.split(':');
                    if (arrSplit[1]) {
                        if (Cookies.get(arrSplit[0]) === arrSplit[1]) {
                            flag = 1;
                        }
                    } else if (Cookies.get(item)) {
                        flag = 1;
                    }
                }
                return flag;
            });
        }
        return 0;
    }
}

export default Extension;
