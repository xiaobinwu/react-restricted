import Track from 'js/track/track';

const GOODS_CONFIG = {
    // M引流APP-openApp
    '.js-openAppBox-btn': {
        itemType: 'openApp',
        click: 'self',
        reportOrigin: 0,
        customData: {},
    },

    // M引流APP-closeApp
    '.js-clearApp': {
        itemType: 'closeApp',
        click: 'self',
        reportOrigin: 0,
        customData: {},
    },
};

class GoodsTrack extends Track {
    // 商详整页曝光
    explorePageData() {
    }

    // 点击处理（组装所需数据）
    customClickTrackCallback(config) {
        const { itemType } = config.configData || {};
        let data = {};
        const typeCfg = {

            // M引流APP-openApp
            openApp: () => {
                data = {
                    x: 'OPENAPP',
                };
            },

            // M引流APP-closeApp
            closeApp: () => {
                data = {
                    x: 'CLOSE',
                };
            },
        };
        if (typeof typeCfg[itemType] === 'function') {
            typeCfg[itemType]();
        }
        return { ...data };
    }
}

const goodsTrack = new GoodsTrack({ config: GOODS_CONFIG, context: 'body' });

export default () => {
    goodsTrack.run();
};
