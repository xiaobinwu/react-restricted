import PubSub from 'pubsub-js';
import { add, sub } from 'js/core/currency';

import { serviceGoodsParts } from 'js/service/goods.js';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import tempFitting from './panelFitting.art';

const GOODSINFO = GoodsInfo.get();

export default {
    async init(displayPrice) {
        // 主商品价格
        this.mainDisplayPrice = displayPrice || GOODSINFO.shopPrice;

        // 异步数据
        this.ajaxData = await this.ajaxGetFitting();

        // 页面显示数据
        this.showData = this.getFittingForPageShow();

        this.render();

    },

    // 异步获取配件信息
    async ajaxGetFitting() {
        let result = [];
        try {
            const { status, data } = await serviceGoodsParts.http({
                errorPop: false,
                loading: false,
                params: {
                    goodSn: GOODSINFO.goodsSn,
                    virCode: GOODSINFO.warehouseCode,
                    recommendLevel: GOODSINFO.recommendLevel,
                    categoryId: GOODSINFO.categoryId
                },
            });
            if (+status === 0) {
                result = data;
            }
        } catch (e) {
            console.log('ERROR:panelFitting=>ajaxGetFitting', e);
        }
        return result;
    },

    // 买配件节省金额
    getPriceWidthFitting() {
        let result = 0;
        const resData = this.ajaxData;

        if (resData && resData.length && resData[0].list) {
            resData[0].list.forEach((item) => {
                result = add(result, sub(item.shopPrice, item.displayPrice));
            });
        }

        console.log('result', result);

        return result;
    },

    // 获取页面需显示的配件（第一组前两项数据）
    getFittingForPageShow() {
        let result = [];
        const resData = this.ajaxData;

        if (resData && resData.length && resData[0].list) {
            result = resData[0].list.slice(0, 2);
        }

        return result;
    },

    render() {
        if (this.showData && this.showData.length) {

            const $panel = $('#js-panelGoodsFitting');
            const link = $panel.data('fitting-link');

            $('#js-panelGoodsFitting').html(tempFitting({
                link,
                savePrice: this.getPriceWidthFitting(),
                thumb: GOODSINFO.thumb,
                mainPrice: this.mainDisplayPrice,
                fitting: this.showData
            })).show();

            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $('#js-panelShipTypeList')[0]
            });
        }
    }
};
