import layer from 'layer';
import { getUrlQuery } from 'js/utils/index.js';
import { STORAGE_GOODS_REDIRECT_LINK } from 'common/js/variables';
import { trans } from 'js/core/translate.js';

import './linkRedirect.css';

class LinkRedirect {
    init(resData) {
        const { stock, goodsStatus } = resData;
        this.linkMap = {};
        const isRedirect = window.sessionStorage.getItem(STORAGE_GOODS_REDIRECT_LINK);
        if (isRedirect) {
            window.sessionStorage.removeItem(STORAGE_GOODS_REDIRECT_LINK);
        } else if (!(goodsStatus === 2 && stock > 0) && this.isPromote()) {
            this.filter();
        }
    }

    isPromote() {
        this.query = getUrlQuery(this.path);
        return this.query.vip || this.query.lkid;
    }

    filter() {
        const $attrLine = $('.js-goodsPropsRow');
        const len = $attrLine.length;
        let colorWrap = []; // nodeList
        let sizeWrap = []; // nodeList
        const oddColor = []; // 颜色所有奇数
        const oddSize = []; // 尺寸所有奇数
        const checkIndex = [0, 0]; // 选中的下标
        if (len > 0) colorWrap = [...$attrLine.eq(0).find('.goodsProps_item')];
        if (len > 1) sizeWrap = [...$attrLine.eq(1).find('.goodsProps_item')];
        colorWrap.forEach((value, index) => {
            oddColor.push(value.dataset.prime);
            if (value.className.indexOf('active') > 0) {
                checkIndex[0] = index;
            }
        });
        sizeWrap.forEach((value, index) => {
            oddSize.push(value.dataset.prime);
            if (value.className.indexOf('active') > 0) {
                checkIndex[1] = index;
            }
        });
        const urlResult = this.redirect(checkIndex, oddColor, oddSize);
        if (urlResult) this.layerHref(urlResult);
    }

    getPrimeLink() {
        window.goodsLink.forEach((value) => {
            this.linkMap[value.prime] = value;
        });
    }

    redirect(checkIndex, oddColor, oddSize) {
        if (oddColor.length > 1) {
            this.getPrimeLink();
            for (let m = checkIndex[1], n = 0, sizeLen = oddSize.length; (n < sizeLen || n === 0); n += 1) {
                let sizeIndex = 0;
                if (sizeLen) sizeIndex = (m + n) % sizeLen;

                for (let i = checkIndex[0], j = 1, colorLen = oddColor.length; j < colorLen; j += 1) {
                    const colorIndex = (i + j) % colorLen;
                    const url = this.getLink(oddColor[colorIndex], sizeLen ? oddSize[sizeIndex] : 1);
                    if (url) {
                        return url;
                    }
                }
            }
        }
        let link = '';
        try {
            const $crumbItem = $('.goodsCrumb_itemText');
            link = $crumbItem.length ? $crumbItem.eq($crumbItem.length - 1).find('a').attr('href') : '';
        } catch (e) {
            link = '';
        }
        return link;
    }

    getLink(colorNum, sizeNum) {
        const linkVal = this.linkMap[colorNum * sizeNum] || {};
        return linkVal.canBuy === 1 ? linkVal.url : '';
    }

    layerHref(urlResult) {
        window.sessionStorage.setItem(STORAGE_GOODS_REDIRECT_LINK, 1);
        const str = `<div class="redirectBox">
            <div class="redirectBox_title">${trans('goods.product_sold_out')}</div>
            <div class="redirectBox_content">${trans('goods.redirect_recommened', [3])}</div>
        </div>`;
        layer.open({
            content: str,
            closeBtn: 0,
            time: 3000,
            success() {
                let stNum = 3;
                function redirectST() {
                    setTimeout(() => {
                        stNum -= 1;
                        $('.redirectBox_content-time').html(stNum);
                        if (stNum !== 0) redirectST();
                    }, 1000);
                }
                redirectST();
            },
            end() {
                window.location.href = urlResult;
            }
        });
        setTimeout(() => {
            window.location.href = urlResult;
        }, 3000);
    }
}

export default new LinkRedirect();
