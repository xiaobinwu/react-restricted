import PubSub from 'pubsub-js';
import layer from 'layer';
import { trans } from 'js/core/translate.js';
import tempDepoist from './goods_depoist.art';
import './goods_depoist.css';

class goodsDepoist {
    init() {
        const $panelPriceWrap = $('#js-panelPriceWrap');
        const $goodsIntroPrice = $('.goodsIntro_price');
        PubSub.subscribe('goods.priceReady', (msg, resPrice) => {
            const price = resPrice;
            if (+price.labelId === 28) {
                const nowTime = (new Date()).getTime() / 1000;
                const canBuyQty = price.saleQty - price.count;
                if (nowTime - price.startTime > 0 && price.endTime - nowTime > 0 && nowTime - price.advanceStartTime > 0
                    && price.advanceEndTime - nowTime > 0 && canBuyQty > 0) {
                    $panelPriceWrap.html(tempDepoist(price));
                    $panelPriceWrap.addClass('isDeposit');
                } else {
                    $goodsIntroPrice.attr('data-currency', price.price).text(price.price);
                }
            }
        });

        // 查看规则
        $panelPriceWrap.on('tap', '.js-depRules', () => {
            const rulesTitle = `<span class="rulesTitleDep">${trans('goods.deposit_detail_rules')}</span><span class="js-closeBtn closeDepBtn">
            <i class="icon-closed"></i></span>`;
            const index = layer.open({
                className: 'depsoitRulesLayer',
                title: rulesTitle,
                type: 1,
                closeBtn: 1,
                area: ['auto', '6rem'],
                content: trans('goods.deposit_detail_ruledesc'),
            });
            // 关闭弹出层
            $('.js-closeBtn').on('tap', () => {
                layer.close(index);
            });
        });
    }
}

export default goodsDepoist;
