/**
 * 国家站翻译功能
 * 2019-03-28 10:27:38
 * luochongfei
 */
import { serviceGoodsSwitchLang } from 'js/service/goods.js';
import './switch_lang.css';

const $panelTitle = $('.js-panelIntroTitle');
const $panelDetail = $('.js-panelNormalGoodsDescription');
const $labelTransText = $('.js-labelTransText');

const switchLang = {
    init({ goodsSn }) {
        if (typeof goodsSn === 'undefined') return;
        // 商品sku
        this.goodsSn = goodsSn;

        // 数据存储
        this.storage = {
            mother: {},
            en: {},
        };

        // 是否已翻译
        this.isTransed = false;

        // 事件绑定
        this.bindEvent();
    },

    bindEvent() {
        const self = this;

        // 点击翻译按钮
        $(document).on('click', '.js-btnTransGoodsDetail', (e) => {
            self.translate();
        });
    },

    async translate() {
        // 先存储原数据
        this.storangeOldInfo();

        let resultData = {};

        if (!this.isTransed) { // 未翻译，调用英文翻译
            resultData = await this.getENInfo();
            this.isTransed = true;
            $labelTransText.text(window.switchTrans.see_original);
        } else { // 已翻译，调取母语
            resultData = this.storage.mother;
            this.isTransed = false;
            $labelTransText.text(window.switchTrans.see_translation);
        }

        // 标题切换
        $panelTitle.html(resultData.title);

        // 描述内容切换
        $panelDetail.html(resultData.detail);

    },

    // 存储原数据(母语)
    storangeOldInfo() {
        if (!this.storage.mother.status) {
            this.storage.mother = {
                status: 1,
                title: $panelTitle.html(),
                detail: $panelDetail.html()
            };
        }
    },

    // 获取英文翻译，从远程 或 变量存储
    async getENInfo() {
        if (this.storage.en.status) {
            return this.storage.en;
        }

        let attrValStr = '';
        const { goodTitle, webStyle, goodAttrRespList } = await this.getLangInfo({});

        // 组装标题后附带的规格属性
        if (goodAttrRespList && goodAttrRespList.length) {
            const attrVals = [];
            goodAttrRespList.forEach((item) => {
                attrVals.push(item.attrValue);
            });
            attrValStr = ` - ${attrVals.join(' ')}`;
        }

        this.storage.en = {
            status: 1,
            title: goodTitle + attrValStr,
            detail: webStyle
        };

        return this.storage.en;
    },

    // 异步获取翻译信息
    async getLangInfo() {
        let result = {};
        const { status, data } = await serviceGoodsSwitchLang.http({
            params: {
                goodSn: this.goodsSn,
            },
        });
        if (status === 0 && data) {
            result = data;
        }
        return result;
    },

};

export default switchLang;
