import Swiper from 'js/lib/swiper.js';
// import PubSub from 'pubsub-js';
import { serviceGoodsReviewsList } from 'js/service/goods.js';
import { dateFormat } from 'js/utils';
import runtime from 'art-template/lib/runtime';
import Loader from 'component/loader/loader';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import { trans } from 'js/core/translate.js';
import renderReviewsItem from './review.art';
import './review.css';

runtime.dateFormat = dateFormat;

const GOODSINFO = GoodsInfo.get();

// 获取数据参数
const query = [{
    goodsSn: GOODSINFO.goodsSn,
    page: 1,
    pageSize: 10,
    type: 0, // 全部all
}, {
    goodsSn: GOODSINFO.goodsSn,
    page: 0,
    pageSize: 10,
    type: 1, // 带图photos
}, {
    goodsSn: GOODSINFO.goodsSn,
    page: 0,
    pageSize: 10,
    type: 3, // 带视频
}];

const $tabWrapReviews = $('#js-tabReviews');
const $panelWrapReviews = $('#js-panelReview');

class Reviews {
    constructor() {
        this.currentIndex = 0;
        this.swiper = new Swiper('#js-goodsReviews_swiper', {
            autoHeight: true,
        });
        this.swiper.detachEvents();
        this.loaderCfg = [0, 0, 0];
        // this.swiperItem(document.getElementsByClassName('js-goodsReviewsImgs'));
        // PubSub.publish('sysUpdateLazyload');
    }
    init() {
        this.bindEvent();
        this.reset();
        this.emptyHandle();
    }

    emptyHandle() {
        const $emptyPanel = $panelWrapReviews.find('.js-reviewAllEmpty');
        if ($emptyPanel.length) {
            const emptyHeight = $(window).height() - $emptyPanel.offset().top;
            $panelWrapReviews.css('height', emptyHeight);
            $emptyPanel.addClass('empty_review').css('height', emptyHeight).text('');
        }
    }

    bindEvent() {
        const self = this;
        $tabWrapReviews.on('click', '[data-tab]', (event) => {
            const $this = $(event.currentTarget);
            const index = $this.index();
            $this.addClass('active').siblings().removeClass('active');
            // 切换面板
            self.swiper.slideTo(index);
            self.currentIndex = index;
            self.reset();
        });
    }

    // 重置
    reset() {
        this.getEle();
        this.initLoader();
    }

    // 获取对应元素
    getEle() {
        const $wrap = $panelWrapReviews.find('[data-panel]').eq(this.currentIndex);
        this.$panel = $wrap.find('.goodsreviews_panelList');
        this.$viewMore = $wrap.find('.goodsReviews_viewMore');
    }

    // 加载loader
    initLoader() {
        const self = this;
        if (!self.loaderCfg[self.currentIndex]) {
            const currentQuery = query[self.currentIndex];

            // view more处理
            const endHandle = (data) => {
                // 可分页总数
                const pageCount = Math.ceil(data.review_count / currentQuery.pageSize);

                if (currentQuery.page >= pageCount) { // 结束或为空时处理
                    loader.end();

                    if (pageCount === 0) { // 为空
                        const emptyHeight = $(window).height() - self.$viewMore.offset().top;
                        self.$viewMore.addClass('empty_review').css('height', emptyHeight).text('');
                    } else {
                        self.$viewMore.text(trans('goods.no_more_reviews'));
                    }

                } else {
                    self.$viewMore.text(trans('goods.view_more'));
                }
            };

            const loader = new Loader({
                viewMore: self.$viewMore,
                auto: true,
                bufferArea: 500,
                data() {
                    currentQuery.page += 1;
                    $('#js-panelReview').attr('data-trackpage', currentQuery.page);
                    return serviceGoodsReviewsList.http({
                        params: currentQuery,
                        loading: false,
                    });
                },
                loadStart() {
                    self.$viewMore.text(trans('goods.loading'));
                },
                loadSuccess(data) {
                    if (data && data.data.reviewList) {
                        data.data.reviewList[0].type = currentQuery.type;
                    }
                    // 组装数据
                    const $newList = $(renderReviewsItem({
                        list: data.data.reviewList
                    }));

                    // 渲染到页面
                    self.$panel.append($newList);

                    // 星星评分
                    $('.js-star').star();

                    // 末端或为空处理
                    endHandle(data.data);

                    // 刷新swiper
                    self.swiper.update();
                }
            });

            // 加载
            if (self.currentIndex > 0) {
                loader.load();
            }

            // 默认加载当前tab第1页数据
            self.loaderCfg[self.currentIndex] = 1;
        }
    }

    swiperItem(item) {
        new Swiper(item, {
            slidesPerView: 'auto',
        });
    }
}

export default Reviews;
