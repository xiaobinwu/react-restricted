import layer from 'layer';
import Swiper from 'js/lib/swiper.js';
import temp from './img_view.art';
import './img_view.css';

class ImgView {
    constructor(imgList) {
        this.imgList = imgList || [];
        this.initIndex = 0;
        this.layero = null;
    }

    // 显示预览弹窗
    show() {
        try {
            const self = this;
            const { imgList } = this;
            this.initIndex = imgList.initIndex;

            const popSuc = (layero) => {
                self.layero = layero;
                self.imgSwiper(imgList);
            };

            layer.open({
                type: 1,
                content: temp({
                    imgList,
                }),
                shade: 'background-color: rgba(0,0,0,1)',
                style: `
                    position: absolute;
                    top: 0;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    width: 100%;
                    height: 100%;
                `,
                success: popSuc
            });
        } catch (error) {
            throw new Error(error);
        }
    }

    // 图片滚动功能
    imgSwiper(imgList = []) {
        const { layero } = this;
        const initialSlide = this.initIndex;
        const oImgContainer = $(layero).find('.js-compImgView').get(0);

        if (oImgContainer instanceof HTMLElement) {
            return new Swiper(oImgContainer, {
                initialSlide,
                pagination: {
                    el: '.js-compImgViewPager',
                    type: 'fraction',
                },
                loop: imgList.length > 1
            });
        }
        return false;
    }
}

export default ImgView;
