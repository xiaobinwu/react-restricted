/**
 * Created by Liu.Jun on 2018/8/21.
 */
// 商祥页APP(SAS)推广

import { throttle } from 'js/utils';
import Extension from '../extension/extension';

export default {
    init() {
        this.extension();
    },

    // 引流广告切换显示 - 受内容区域滚动影响
    bannerHeaderSwitch(insExtension) {
        if (insExtension && insExtension.$box.length && !insExtension.$box.data('close')) {
            const clsFlag = $(window).scrollTop() === 0 ? 'addClass' : 'removeClass';
            insExtension.$box[clsFlag]('show');
        }
    },

    // sas推广
    extension() {
        new Extension({
            callback: (insExtension) => {
                // 刷新页面记忆scroll在页面中部时，主动先触发，防止顶部空缺
                this.bannerHeaderSwitch(insExtension);
                $('#js-goodsHeader').css('visibility', 'visible');

                const throttleIndexFn = throttle(() => {
                    this.bannerHeaderSwitch(insExtension);
                }, 60);

                $(window).on('scroll', throttleIndexFn);
            },
            hideCallback() {
                $('#js-goodsHeader').css('visibility', 'visible');
            },
            pageType: 'product'
        });
    }
};

