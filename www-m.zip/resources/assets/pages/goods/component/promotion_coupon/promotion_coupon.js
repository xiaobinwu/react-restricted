import PubSub from 'pubsub-js';
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import { serviceGoodsPromotion } from 'js/service/goods.js';
// 多语言相关
import { trans } from 'js/core/translate.js';

const GOODSINFO = GoodsInfo.get();
const $panelPromoEntry = $('.js-panelPromoEntryText');
const $panelCouponEntry = $('.js-panelCouponEntryList');

export default {
    // 确定是否
    init(freeData) {
        // 获取满额免邮数据(shipping.js)
        this.freeShippingData = freeData;
        this.pageEntrySwitch();
    },

    // 页面入口是否开启
    async pageEntrySwitch() {
        const res = await this.getPromoData();

        // promotion
        const $panelPromo = $('.js-btnShowPromo');
        if ((res.activity && res.activity.activityList && res.activity.activityList.length > 0) ||
        (this.freeShippingData && this.freeShippingData.logisticsName)) {
            const activityList = res.activity.activityList || [];
            const { promoList } = await import('../promo_list/promo_list.js');
            if (this.freeShippingData && this.freeShippingData.logisticsName) {
                activityList.push(this.freeShippingData);
            }
            this.showPromoLabel(activityList);
            $panelPromo.addClass('show');
            promoList.activityList = activityList;
            promoList.init();
        } else {
            $panelPromo.removeClass('show');
        }

        // coupon
        const $panelCoupon = $('.js-btnShowCoupon');
        if (res.coupon && res.coupon.length > 0) {
            const couponData = res.coupon;
            const { couponList } = await import('../coupon_list/coupon_list.js');

            this.showCouponLabel(couponData);
            $panelCoupon.addClass('show');
            couponList.couponList = couponData;
            couponList.init();
        } else {
            $panelCoupon.remove();
        }
    },

    // 获取活动及coupon数据
    getPromoData() {
        return new Promise(async (resolve, reject) => {
            try {
                const { status, data } = await serviceGoodsPromotion.http({
                    errorPop: false,
                    loading: false,
                    usePreResult: true,
                    params: {
                        shopCode: GOODSINFO.shopCode,
                        goodSn: GOODSINFO.goodsSn,
                        virCode: GOODSINFO.warehouseCode,
                        categoryId: GOODSINFO.categoryId,
                        brandCode: GOODSINFO.brandCode
                    },
                });
                if (+status === 0) {
                    resolve(data);
                }
            } catch (error) {
                reject(error);
            }
        });
    },

    // 页面上promotion活动显示
    showPromoLabel(data = [{
        activityString: ''
    }]) {
        let freeShippingText = '';
        if (data[0].logisticsName) {
            freeShippingText = trans('goods.free_shipping_text', [`<span class='logisticeName'>${data[0].logisticsName}</span>`,
                `<span class='freePrice js-currency' data-currency=${data[0].freePrice}></span>`]);
        }
        let activityString = data[0].activityString || freeShippingText || '';
        activityString = activityString.split('<br>')[0];
        $panelPromoEntry.html(activityString);

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: $panelPromoEntry[0],
        });
    },

    // 页面上coupon优惠券显示
    showCouponLabel(data) {
        let listHtml = '';
        if (data && data.length) {
            const newData = data.slice(0, 1);
            newData.forEach((item) => {
                listHtml += `
                    <div data-status="${item.receiveStatus}" data-id="${item.templateCode}" class="goodsCouponEntry_item">
                        ${item.saveStrategyDesc}
                    </div>`;
            });
        }

        $panelCouponEntry.html(listHtml);

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: $panelCouponEntry[0],
        });
    }
};
