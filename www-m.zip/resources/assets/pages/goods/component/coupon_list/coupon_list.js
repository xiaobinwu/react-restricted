import PubSub from 'pubsub-js';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import { serviceCouponReceivedStatus } from 'js/service/common.js';
import runtime from 'art-template/lib/runtime';
import { dateFormat } from 'js/utils';
import specAnimate from 'js/utils/specAnimate.js';
import borderStopScroll from 'component/borderStopScroll';
import temp from './coupon_list.art';
import './coupon_list.css';


// 商详页所有art模板注入语言转换方法
runtime.dateFormat = dateFormat;

export const couponList = {
    init() {
        this.$pop = $('#js-popCoupon');
        this.$popCont = this.$pop.find('.goodsPop_cont');

        this.rendered = false;
        this.bindEvent();
    },

    bindEvent() {

        const self = this;

        // 开启弹窗
        $('.js-btnShowCoupon').on('click', () => {
            self.show();
        });

        // 关闭弹窗
        this.$pop.on('click', '.js-close', () => {
            self.hide();
        });

        // 点击弹窗遮罩关闭弹窗
        this.$pop.on('click', (e) => {
            if ($(e.target).find('.goodsCoupon_cont').length > 0) {
                self.hide();
            }
        });

        // 触发领取优惠券
        this.$pop.on('click', '.js-btnGetCoupon', (e) => {
            const $this = $(e.currentTarget);
            self.getCoupon($this);
        });
    },

    // 显示coupon弹窗
    show() {
        const self = this;

        if (!self.rendered) {
            this.render();
            borderStopScroll({
                wrapEle: this.$pop[0]
            });
            borderStopScroll({
                wrapEle: document.querySelector('.goodsCoupon_popList')
            });
        }

        specAnimate.show({
            ele: self.$pop[0],
            beforeDisplay: 'block',
            fn() {
                self.$pop.addClass('show');
            }
        });
    },

    hide() {
        this.$pop.removeClass('show');
    },

    // 获取模板及绑定事件
    render() {
        const self = this;

        self.$popCont.html(temp({
            list: self.couponList
        }));

        self.rendered = true;

        self.couponReceivedStatus({
            $list: $('.goodsCoupon_popItem')
        });

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: self.$popCont[0],
        });
    },

    // 领取优惠券
    getCoupon($btn) {
        const self = this;
        const id = $btn.data('id');
        getCouponItem({
            templateCode: id,
            errorPop: false,
        }).then((status, msg, data) => {
            self.couponReceivedStatus({
                $list: $btn.parents('.goodsCoupon_popItem')
            });
        });
    },

    // 获取优惠券领取状态
    async couponReceivedStatus({ $list }) {
        const sendDataArr = [];

        $list.each((index, ele) => {
            const $this = $(ele);
            const code = $this.attr('data-code');
            sendDataArr.push(code);
        });

        const res = await serviceCouponReceivedStatus.http({
            errorPop: false,
            loading: false,
            params: {
                templateCode: sendDataArr.join(',')
            }
        });

        const resultData = res.data;
        $list.each((index, ele) => {
            const $this = $(ele);
            const code = $this.attr('data-code');

            if (resultData[code] && resultData[code].length > 0) {
                $this.addClass('is-used');
            } else {
                $this.removeClass('is-used');
            }
        });
    }
};
