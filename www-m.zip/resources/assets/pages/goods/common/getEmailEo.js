/**
 * 获取邮件专享价 eo 加密串
 * 无法使用 为 空时都 返回空，有则返回加密串
 * 2018-11-30 17:37:55
 */
import { STORAGE_SAVE_EO } from 'js/variables';
import { getUrlQuery } from 'js/utils';

// 本地存取eo
class LocalEo {
    static get() {
        return window.localStorage.getItem(STORAGE_SAVE_EO) || '';
    }

    static set(eo) {
        window.localStorage.setItem(STORAGE_SAVE_EO, eo || '');
    }
}

// 返回eo 加密串
function getEmailEo() {
    const {
        eo = LocalEo.get(),
        lkid,
        utm_source: utmSource
    } = getUrlQuery();

    let isSetEo = true;
    let resultEo = '';

    // 如果能取到eo加密串，还得再通过推广参数进行过滤
    if (eo) {
        // url参数中同时有lkid和eo 不享受邮件价
        if (lkid) {
            isSetEo = false;
        }

        // url参数中同时有utm_source和eo
        if (utmSource) {
            // 只有一个utm_source参数时
            const urlQuery = window.location.search.substr(1);
            if (urlQuery.indexOf('utm_source') === urlQuery.lastIndexOf('utm_source')) {
                // 除utm_source值为mail_api和email_sys之外，都不享受邮件价
                if (!(utmSource === 'mail_api' || utmSource === 'email_sys')) {
                    isSetEo = false;
                }
            } else { // 有多个utm_source参数，不享受邮件价
                isSetEo = false;
            }
        }

        // 可享受邮件价
        if (isSetEo) {
            LocalEo.set(eo);
            resultEo = eo;
        }
    }

    return resultEo;
}

export {
    LocalEo,
    getEmailEo
};
