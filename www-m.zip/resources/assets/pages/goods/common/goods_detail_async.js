// 顶部app下载栏
import goodsAppBanner from '../component/goods_app_banner/goods_app_banner.js';

export default () => {
    // 设置顶部banner
    goodsAppBanner.init();
};
