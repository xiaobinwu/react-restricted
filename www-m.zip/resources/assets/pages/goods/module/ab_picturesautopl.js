/**
 * AB test: 商详页是否自动轮播
 * A：保持原状  B：自动
 */
import Cookies from 'js-cookie';
import { serviceAbTest } from 'js/service/common.js';

const COOKIES = Cookies.get();

export const abPictureAutoPl = {

    init() {
        return new Promise(async (resolve, reject) => {
            const shunt = this.getShunt();
            let bucketPromise;
            if (!shunt) { // 吆喝
                bucketPromise = this.getBucketByYH;
            } else {
                bucketPromise = this.getBucketByBTS;
            }
            bucketPromise().then((resData) => {
                resolve(resData);
            });
        });
    },

    /**
     * 从AKAM_CLIENTID 随机分流
     * return 0~9 || 9:获取失败走BTS
     */
    getNumberClientId() {
        if (typeof COOKIES.AKAM_CLIENTID !== 'undefined') {
            return parseInt(parseInt(COOKIES.AKAM_CLIENTID, 16), 10);
        }
        return 9;
    },

    /**
     * 获取分流
     * return 0:吆喝 || 1:BTS
     */
    getShunt() {
        let result = 1;
        const numb = this.getNumberClientId();
        if (/^[0-4]$/.test(numb)) {
            result = 0;
        } else if (/^[5-9]$/.test(numb)) {
            result = 1;
        }
        console.log('分流结果是:', result === 1 ? 'BTS' : '吆喝科技');
        return result;
    },

    /**
     * 从BTS接口获取分桶数据
     * return {...} || {}
     */
    getBucketByBTS() {
        return new Promise(async (resolve) => {
            const res = {
                org: 'BTS',
                bucket: 'A',
                bucketData: {},
            };

            try {
                const { code, result } = await serviceAbTest.http({
                    data: JSON.stringify({
                        appkey: 'GB',
                        cookie: COOKIES.od || 'dsfdwfsfsfer343243',
                        plancode: 'picturesautopl',
                        params: {},
                    }),
                    headers: {
                        'Content-Type': 'application/json'
                    },
                });

                if (+code === 200 && result) {
                    res.bucket = result.policy || 'A';
                    res.bucketData = result || {};
                }

                resolve(res);

            } catch (e) {
                console.log('ERROR:abPictureAutoPl=>getSwitchByBts', e);
                resolve(res);
            }
        });
    },

    /**
     * 从吆喝科技获取分桶数据
     */
    getBucketByYH() {
        let resolveFlag = true;
        return new Promise(async (resolve) => {
            const res = {
                org: 'YH',
                bucket: 'A',
                bucketData: {},
            };

            try {
                // 加载吆喝科技sdk
                await import('js/lib/abtest/ab.plus.js');

                if (window.adhoc) {
                    // 禁用遮罩白屏
                    window.adhoc('setOverlay', false);

                    // 初始化
                    window.adhoc('init', {
                        appKey: 'ADHOC_555e2112-4789-47f3-8634-de81a32a774c', // 创建应用时获得的appkey
                        defaultFlags: { auto: 2 } // 仅用于编程模式：设置试验变量默认值（获取试验变量失败时使用）
                    });

                    /**
                     * 获取分流标识
                     * 0 : 原始版本
                     * 1 : 自动轮播版本
                     * 2 : 获取异常 按原始版本
                     */
                    window.adhoc('getFlags', (flags) => {
                        if (resolveFlag) {
                            resolveFlag = false;
                            console.log('吆喝科技获取标识成功：', flags.get('auto'));
                        }
                        res.bucket = +flags.get('auto') === 1 ? 'B' : 'A';
                        resolve(res);
                    });
                }

                setTimeout(() => {
                    if (resolveFlag) {
                        resolveFlag = false;
                        console.log('吆喝科技接口超时,执行默认配置', res);
                    }
                    resolve(res);
                }, 1000);

            } catch (error) {
                resolve(res);
            }
        });
    }
};
