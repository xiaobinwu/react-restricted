/**
 * 商详页js
 */
import 'js/bootstrap.js';
import layer from 'layer';

import Swiper from 'js/lib/swiper.js';

import PubSub from 'pubsub-js';
import lazyObserver from 'js/utils/lazyObserver';
import StateStore from 'js/core/goods/stateStore';

// 异步请求
import { serviceCollectAdd, serviceDeleteCollection, serviceCollectStatus } from 'js/service/common.js';
import { serviceGoodsInfo, serviceGoodsPriceStockInstallment, serviceGoodsAdvertising } from 'js/service/goods.js';
import { serviceCartSendQuickPay } from 'js/service/paycart.js';

// 获取国家简码
import { goodsCountryCode } from 'js/core/goods/goodsCountryCode.js';

// 跳转首页馆区
import indexHeaderInfo from 'js/core/index/headerInfo';

// 网采国家判断
import { isBfCountry } from 'js/core/bfCountry';

// 返回上级或首页操作
import backPrevOrHome from 'js/core/backPrevOrHome';
// 商品业务逻辑
import GoodsInfo from 'js/core/goods/goodsInfo.js';
import GoodsViewHistory from 'js/core/goods/goodsViewHistory.js';
import { buyNow } from 'js/core/goods/cart.js';

import { add, getCdnCountryCode } from 'js/core/currency.js';

// 大数据埋点
import goodsTrack from 'js/track/define/goods.js';

// 底部功能
import 'modules/footer/footer.js';
// 多语言相关
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';

// 星星评分
import 'component/star/star.js';

// 判断是否登陆
import isLogin from 'js/core/user/isLogin';

// goods组件-图片查看器
import ImgView from '../component/img_view/img_view.js';
// goods组件-商品促销（营销）价格状态
import GoodsPromoPrice from '../component/goods_promo_price/goods_promo_price.js';
// 定金膨胀
import GoodsDepoistPrice from '../component/goods_depoist/goods_depoist.js';
import { getEmailEo } from '../common/getEmailEo.js';
// 推广链接301跳转
import linkRedirect from '../component/linkRedirect/linkRedirect';

import './goods_detail.css';


runtime.trans = trans;

// 商品容器
const $goodsWrap = $('#js-goodsWrap');
// 当前商品信息
const GOODSINFO = GoodsInfo.get();
// 浏览器标识
const UA = navigator.userAgent.toLowerCase();
// 是否 IOS系统
const ISIOS = UA.indexOf('os') > 0;
// 是否 Safari浏览器
const ISSAFARI = /iP(ad|hone|od).+Version[\d\.]+.*Safari/i.test(UA); // eslint-disable-line
// Apple Store 应用市场
const URI_APPSTORE_IOS = 'https://itunes.apple.com/cn/app/gearbest-shopping/id1131090631?l=en&mt=8';
// Google Play 应用市场
const URI_APPSTORE_ANDROID = 'https://play.google.com/store/apps/details?id=com.globalegrow.app.gearbest';

const IS_LOGIN = isLogin();
const stateStore = new StateStore();

PubSub.subscribe('nativeReady', () => {
    const SELECTEDGOODS = {
        warehouseCode: GOODSINFO.warehouseCode,
        goodsSn: GOODSINFO.goodsSn,
        qty: 1,
    };
    const GOODSLANG = {
        comming_soon: trans('goods.comming_soon'),
        add_to_cart: trans('goods.add_to_cart'),
        buy_now: trans('goods.buy_now'),
        discontinued: trans('goods.detail_discontinued'),
        out_of_stock: trans('goods.detail_out_of_stock'),
        arrival_notice: trans('goods.detail_arrival_notice'),
        unmatched_goods: trans('goods.unmatched_goods'),
        detail_save: trans('goods.detail_save'),
    };
    // 切换到评论面板
    const switchToComment = async (flag = 'open') => {
        if (flag === 'open') {
            $goodsWrap.attr('data-page', 'comment');
            window.location.hash = 'comment';

            const $goodComment = $('.goodsComment');
            if (!$goodComment.hasClass('loaded')) {
                const { default: Reviews } = await import('../component/review/review');
                new Reviews().init();
                $goodComment.addClass('loaded');
            }
        } else {
            $goodsWrap.removeAttr('data-page', 'comment');
            goodsNav.setPanelPos();
            goodsNav.panelShow('js-goodsReviews');
        }
    };
    // 切换到尺码表
    const switchToSizeGuide = async (flag = 'open') => {
        if (flag === 'open') {
            $goodsWrap.attr('data-page', 'sizeGuide');
            window.location.hash = 'sizeGuide';
        } else {
            $goodsWrap.removeAttr('data-page', 'sizeGuide');
            goodsNav.setPanelPos();
            goodsNav.panelShow('js-goodsBasic');
        }
    };

    // 开平商城端商详描述Specification添加view more限高点击加载
    if (GOODSINFO.isPlatform) {
        const $sizeDescription = $('.js-sizeDescription');
        const $descViewMore = $('.js-descViewMore');
        const sizeDescriptionH = $sizeDescription.height();
        const maxHeight = document.documentElement.clientHeight || document.body.clientHeight;
        if (sizeDescriptionH > maxHeight) {
            $sizeDescription.addClass('hidePart');
            $descViewMore.show();
        }

        $descViewMore.on('click', () => {
            $sizeDescription.removeClass('hidePart');
            $descViewMore.hide();
        });
    }

    let GOODSPROPS = null;

    // 商详全局调用 - 前置
    const goodsGlobalBefore = {
        init() {
            // 首次载入或刷新时清空默认hash,防止停留在hash页面
            this.removeCommentHash();

            this.bindEvent();

            PubSub.subscribe('goods.priceReady', async (msg, priceData) => {
                // 大数据埋点
                window.goodsPriceData = priceData;

                // 因paypal支付要依赖营销状态，假设用户先触发打开buynow面板，就存在GOODSPROPS,需要执行paypay可用检测
                if (GOODSPROPS) {
                    GOODSPROPS.switchPaypalBtn();
                }

                // AB-test
                let pictureBucket = 'A';
                let trackBucket;

                // AB-test 仅葡萄牙站
                if (window.GLOBAL.PIPELINE === 'GBPT') {
                    const { abPictureAutoPl } = await import('../module/ab_picturesautopl.js');
                    abPictureAutoPl.init().then((bucketData) => {
                        console.log('bucketData', bucketData);
                        // 埋点曝光
                        if (bucketData.org === 'BTS') {
                            trackBucket = {
                                bts: bucketData.bucketData
                            };
                        }

                        // 吆喝科技点击上报
                        if (bucketData.org === 'YH') {
                            $(document).on('tap', '.js-buyNow,.js-addToCart', () => {
                                if (window.adhoc) {
                                    window.adhoc('track', 'add_cart_rate', 1);
                                }
                            });
                        }

                        pictureBucket = bucketData.bucket;

                        // 大图预览
                        goodsPreview.imgSlide({
                            autoplay: pictureBucket === 'B'
                        });

                        // 埋点实例化
                        goodsTrack(trackBucket);
                    });
                } else {
                    // 大图预览
                    goodsPreview.imgSlide();

                    // 埋点实例化
                    goodsTrack();

                }


                /**
                 * 因用户可能直接返回推荐位记忆位置，导致埋点先执行，造成埋点数据丢失 2018-10-22 16:53:10
                 * 推荐
                 */
                lazyObserver({
                    observeDom: document.querySelectorAll('.js-lazyModule'),
                    async callBack(target) {
                        try {
                            const { panel } = target.dataset;
                            if (panel) {
                                const { default: module } = await import(`../component/async_module/${panel}/${panel}.js`);

                                if (typeof module.init === 'function') {
                                    module.init(target);
                                }
                            }
                            $(target).removeClass('box-loading');
                        } catch (e) {
                            console.log('ERROR:goodsDetail=>goodsGlobal.lazyObserver', e);
                        }
                    },
                });
            });
        },

        bindEvent() {
            window.addEventListener('hashchange', (e) => {
                const { oldURL } = e;
                if (/#comment/.test(oldURL)) { // 从评论回退到主内容
                    switchToComment('close');
                }
                if (/#sizeGuide/.test(oldURL)) { // 从sizeguide回退到主内容
                    switchToSizeGuide('close');
                }
            });

            // 主面板评论区图片横向滚动懒加载图片
            $('.js-goodsReviewsImgs').on('scroll', (e) => {
                PubSub.publish('sysUpdateLazyload');
            });

        },

        // 清空页面级hash
        removeCommentHash() {
            if (/#(comment|sizeGuide)/.test(window.location.hash)) {
                window.location.href = window.location.href.split('#')[0];
            }
        },

        // 网采商品处理
        async bfProductHandle() {
            const clsFlag = (+await isBfCountry() && +GOODSINFO.recommendedLevel === 14) ? 'addClass' : 'removeClass';

            $('#js-goodsPreviewWrap')[clsFlag]('box-loading');
            $goodsWrap[clsFlag]('isBfProduct');
        }
    };
    goodsGlobalBefore.init();

    // 吸顶导航切换
    const $goodsHeader = $('#js-goodsHeader');
    const $goodsNav = $('#js-goodsNav');
    const $navBtnGoPrev = $('#js-navBtnGoPrev');
    const $goodsNavItem = $goodsNav.find('.goodsNav_item');
    const $goodsContentItem = $('#js-goodsContent').find('.goodsContent_item');
    const $btnGoTop = $('#js-btnGoTop');
    const $btnToggleMenu = $('#js-btnToggleMenu');
    const $goodsCodPayItem = $('.goodsSel_codPayItem');
    const goodsNav = {
        init() {
            this.$doc = $(document);
            this.$win = $(window);
            this.docHeight = this.$doc.height();
            // 要滚动对应版块的Y轴位置集合 例： {'goodsDesc': 2590}
            this.posConfig = {};

            // 当前显示的内容面板
            this.$currentPanel = $goodsContentItem.eq(0);

            this.bindEvent();
        },
        bindEvent() {
            const self = this;
            let docHeight;

            // 持续检查滚动状态及页面高度
            self.timer = setInterval(() => {
                docHeight = self.$doc.height();

                // 正在滚动
                if (self.scrolling) {
                    self.scrolling = false;
                    self.navFixed();
                    self.scrollChange();

                    // 滚动时隐藏汉堡菜单
                    $btnToggleMenu.removeClass('show');
                }

                // 页面高度变化
                if (docHeight !== self.docHeight) {
                    self.docHeight = docHeight;
                    self.setPanelPos();
                }
            }, 160);

            // 监测页面滚动
            window.addEventListener('scroll', () => {
                self.scrolling = true;
            });

            // 返回上一级或首页
            $navBtnGoPrev.on('click', (e) => {
                backPrevOrHome();
                return false;
            });

            // 导航面板切换
            $(document).on('click', '.js-anchorItem', (e) => {
                self.setPanelPos(); // 点击前重新位置信息
                const hash = self.getHash($(e.currentTarget));
                self.panelShow(hash);
                return false;
            });

            // 切换菜单显隐状态
            $btnToggleMenu.on('click', (e) => {
                e.stopPropagation();
                const $this = $(e.currentTarget);
                $this.toggleClass('show');
            });

            // 点击页面其他地方关闭菜单
            $(document).on('click', () => {
                $btnToggleMenu.removeClass('show');
            });

            // 点击返回顶部
            $btnGoTop.on('click', (e) => {
                self.goTop();
            });

            // 点击COD区域
            $goodsCodPayItem.on('tap', (e) => {
                const $this = $(e.target);
                if (!$this.hasClass('js-goodsSelCodPayFaq')) {
                    // 跳转到COD聚合页
                    window.location.href = `${window.GLOBAL.DOMAIN_MAIN}/cod.html`;
                } else {
                    // 弹出COD提示
                    e.stopPropagation();
                    const index = layer.open({
                        className: 'codPayFaqLayer',
                        type: 1,
                        btn: 'OK',
                        content: `${trans('goods.goods_cod_tips')}`,
                    });
                    // 关闭弹出层
                    $('.js-closeBtn').on('tap', () => {
                        layer.close(index);
                    });
                }
            });
        },

        // 导航吸顶
        navFixed() {
            const winScrT = this.$win.scrollTop();
            const clsFlag = (winScrT <= $goodsHeader.height()) ? 'removeClass' : 'addClass';
            $goodsHeader[clsFlag]('show');
            this.goTopHandle(clsFlag);
        },

        // 页面滚动变更导航高亮项
        scrollChange() {
            const scrollTop = this.$win.scrollTop();
            const section = this.getSection(scrollTop);
            let $navItem;

            // 匹配到版块
            if (section !== null) {
                $navItem = $goodsNav.find(`a[href="#${section}"]`);

                // 如果当前匹配到的panel未高亮
                if (!$navItem.hasClass('active')) {
                    // 当前导航项加高亮
                    this.currentNavActive($navItem);
                }
            }
        },

        // 通过滚动条位置确定对应版块
        getSection(scrollTop) {
            let returnValue = null;

            for (const section in this.posConfig) {
                if (this.posConfig[section] < scrollTop) {
                    returnValue = section;
                }
            }

            return returnValue;
        },

        // 获取需要滚动对应面板的位置（此处为top）
        setPanelPos() {
            const self = this;
            let linkHref;
            let $target;

            $goodsNavItem.each((index, ele) => {
                linkHref = self.getHash($(ele));
                $target = $(`#${linkHref}`);

                if ($target.length) {
                    const topPos = $target.offset().top;
                    self.posConfig[linkHref] = (Math.ceil(topPos) - $goodsHeader.height()) - 3;
                }
            });
        },

        // 获取href的hash
        getHash($link) {
            return $link.attr('href').split('#')[1];
        },

        // 当前导航项加高亮
        currentNavActive($current) {
            $goodsNav.get(0).scrollTo({
                left: $current.offset().left
            });

            $goodsNav.find('.active').removeClass('active');
            $current.addClass('active');
        },

        // 显示对应面板
        panelShow(hash) {
            // 切换到指定的面板
            window.scrollTo({
                top: this.posConfig[hash] + 3,
            });

            // 更新小导航当前项位置
            this.scrollChange();

            // 顶部小导航对应高亮
            $goodsNavItem.removeClass('active').filter(`[href='#${hash}']`).addClass('active');
        },

        // 返回顶部显隐处理
        goTopHandle(clsFlag) {
            $btnGoTop[clsFlag]('show');
        },

        // 返回顶部
        goTop() {
            window.scrollTo({
                top: 0
            });

            // 更新小导航当前项位置
            this.scrollChange();
        }
    };
    goodsNav.init();

    // 商品简览（大图预览|视频播放|分享）
    const $btnShowShare = $('#js-btnShowShare');
    const $itemImgSlide = $('#js-goodsPreview').find('.swiper-slide');
    const goodsPreview = {
        init() {

            this.bindEvent();
        },

        bindEvent() {
            const self = this;

            $('#js-goodsPreview').on('click', '.swiper-slide', (e) => {
                const $this = $(e.currentTarget);
                const realIndex = $this.data('swiper-slide-index') || 0;
                self.showImgView($itemImgSlide.eq(realIndex));
            });

            // 分享面板
            $btnShowShare.on('click', async (e) => {
                const { default: sharePanel } = await import('../component/share_panel/share_panel.js');
                const insSharePanel = sharePanel.init();
                insSharePanel.show();
            });
        },

        // 商品图片幻灯片
        imgSlide(options) {
            const imgLength = $itemImgSlide.length;
            const defaults = {
                watchOverflow: true,
                pagination: {
                    el: '.goodsPreview_page',
                    type: 'fraction',
                },
                lazy: {
                    elementClass: 'preview-lazy',
                },
                loop: imgLength > 1,
                on: {
                    slideChange(e, b) {
                        // 仅在第一张主图时展示视频
                        $('#js-btnMainVideo')[this.realIndex > 0 ? 'addClass' : 'removeClass']('hide');
                    },
                    resize() {
                        setTimeout(() => {
                            this.update();
                        }, 600);
                    }
                }
            };
            Object.assign(defaults, options);
            const previewSwiper = new Swiper('#js-goodsPreview', defaults);
            return previewSwiper;
        },

        // 获取预览图片组:预览图所有图片（$currentItem: 当前点选的图片）
        getImgList($currentItem) {
            if (typeof $currentItem === 'undefined' || $currentItem.length === 0) {
                return [];
            }

            const result = [];
            $itemImgSlide.each(function (index, ele) {// eslint-disable-line
                const $ele = $(ele);

                // 记录当前点击在当条评论图片中是第几张图片
                if ($currentItem[0] === $ele[0]) {
                    result.initIndex = index;
                }

                result.push({
                    thumb: $ele.attr('data-src'),
                    title: $ele.find('img').attr('alt') || $ele.find('img').attr('title'),
                    src: $ele.attr('data-original-src'),
                });
            });

            return result;
        },

        // 显示图片预览(需要当前图片对象)
        showImgView($ele) {
            const insImgView = new ImgView();
            insImgView.imgList = this.getImgList($ele);
            insImgView.show();
        },
    };
    goodsPreview.init();

    // 商品基础信息
    const $panelPrice = $('#js-panelShopPrice');
    const $entryToAttrPanel = $('#js-entryToAttrPanel');
    const applinkCls = 'js-applinkToDetail';
    const goodsBasic = {
        async init() {
            this.timerToApp = null;
            this.bindEvent();

            this.insSwitchLang();
        },

        bindEvent() {
            const self = this;

            // 跳转app商详|应用市场
            $(document).on('click', `.${applinkCls}`, (e) => {
                self.appLinkToDetail();
            });

            PubSub.subscribe('goods.goodsStatusReady.init', () => {
                PubSub.subscribe('goods.priceReady', (msg, resPrice) => {
                    // 邮件加密价
                    self.handleAppPrice(resPrice);

                    // 清仓标
                    let clearanceFlag = +GOODSINFO.saleMark;
                    // 营销价类型为10 或 '6396395377285853184' saleMark标识为清仓
                    if (+resPrice.labelId === 10 || String(resPrice.labelId) === '6396395377285853184') {
                        clearanceFlag = 3;
                    }
                    // 营销价类型不为127且 saleMark=3时
                    if (!/^[127]$/.test(resPrice.labelId) && clearanceFlag === 3) {
                        self.clearanceShow();
                    }
                });
                self.hidePanelByGoodsStatus();
            });

        },

        // 处理APP节省价
        handleAppPrice(resPrice) {
            const asyncDisplayPrice = goodsGlobal.asyncProduct.displayPrice;
            const { appPrice } = GOODSINFO;
            const appSavePrice = add(asyncDisplayPrice, -appPrice);
            const $panelAppPrice = $('#js-panelAppSavePrice');
            const $panelApp = $panelAppPrice.parents('.goodsIntro_app');

            if (+resPrice.labelId !== 1 && appSavePrice > 0) {
                $panelAppPrice.attr('data-currency', appSavePrice);
                $panelApp.addClass('show');

                // 更新货币
                PubSub.publish('sysUpdateCurrency', {
                    context: $panelApp[0]
                });
            } else {
                $panelApp.removeClass('show');
            }
        },

        // 根据商品状态隐藏某些元素
        hidePanelByGoodsStatus() {
            const status = goodsGlobal.asyncProduct.goodsStatus;
            const config = {
                // 待发布
                1: () => {
                    $panelPrice.hide(); // 商品价格
                    $btnShowShipping.hide(); // 物流入口
                    $entryToAttrPanel.hide(); // 多属性面板
                },
                // 谍照
                5: () => {
                    $panelPrice.hide(); // 商品价格
                    $btnShowShipping.hide(); // 物流入口
                    $entryToAttrPanel.hide(); // 多属性面板
                }
            };
            if (typeof config[status] === 'function') {
                config[status]();
            }
        },

        /**
         * M版跳转到GB-app商详
         * 如果未安装GB-app（通过短时间内是否离开页面焦点判断），则跳转到对应系统的应用市场
         */
        appLinkToDetail() {
            const self = this;
            const config = {
                url: ISIOS ? URI_APPSTORE_IOS : URI_APPSTORE_ANDROID,
                timeout: ISSAFARI ? 2000 : 500, // ? 我也不知道为啥，参考老GB规则(goods.js)
            };
            const startTime = new Date().getTime();

            clearTimeout(self.timerToApp);

            // 离开页面时中断倒计时(中止中转到应用市场)
            window.onblur = () => {
                clearTimeout(self.timerToApp);
            };

            // ? 我也不知道为啥，参考了老GB的规则
            if (ISIOS) {
                self.timerToApp = setTimeout(() => {
                    window.location.href = config.url;
                }, config.timeout);
                return;
            }

            self.timerToApp = setTimeout(() => {
                const endTime = new Date().getTime();
                if (!startTime || endTime - startTime < config.timeout + 200) {
                    window.location.href = config.url;
                }
            }, config.timeout);
        },

        /**
         * 显示清仓标
         */
        clearanceShow() {
            $('#js-goodsClearanceTag').append(`
                <span class="goodsIntro_serverTag-clean">
                    ${trans('goods.clearance')}
                </span>`);
        },

        // 翻译功能
        async insSwitchLang() {
            if ($('.js-btnTransGoodsDetail').length) {
                const { default: switchLang } = await import('../component/switch_lang/switch_lang.js');

                switchLang.init({
                    goodsSn: GOODSINFO.goodsSn,
                });
            }
        }
    };
    goodsBasic.init();

    // 选仓|运费方式
    const $btnShowShipping = $('.js-btnShowShipping');
    const goodsShipping = {
        init() {
            this.bindEvent();
        },

        data: {
            priceMd5: '',
            goodPrice: ''
        },

        async getShippingInstance() {
            if (this.insGoodsShipping === undefined) {
                const { shipping } = await import('../component/shipping/shipping.js');
                this.insGoodsShipping = shipping;
                Object.assign(this.insGoodsShipping, this.data);
            }

            return this.insGoodsShipping;
        },

        bindEvent() {
            // 商品价格状态就绪后取priceMd5
            PubSub.subscribe('goods.priceReady', (msg, resPrice) => {
                const price = resPrice;
                const product = goodsGlobal.asyncProduct;
                // 更新 shipping priceMd5
                this.data.priceMd5 = price.priceMd5;
                if (+price.labelId === 28 && +price.isShowDep) {
                    Object.assign(this.data, {
                        goodPrice: price.pricePage,
                        lessCanBuy: product.lessCanBuy,
                        isShowDep: 1,
                    });
                } else {
                    this.data.goodPrice = price.price;
                }

                // 初始化物流数据
                setTimeout(async () => {
                    const goodsShippingInit = await this.getShippingInstance();
                    goodsShippingInit.init();
                }, 1000);

                // 点击开启运费弹层
                $btnShowShipping.on('click', async () => {
                    const insGoodsShipping = await this.getShippingInstance();
                    insGoodsShipping.init();
                    insGoodsShipping.show();
                });
            });
        }
    };
    goodsShipping.init();

    const goodsSizeGuide = {
        init() {
            this.bindEvent();
        },

        bindEvent() {
            // 去到尺码表面板
            $('.js-entryGoodsSizeGuide').on('click', (e) => {
                switchToSizeGuide();
            });
        }
    };
    goodsSizeGuide.init();

    // 搭售（配件）购
    const $panelFittingSave = $('.js-panelFittingSave');
    const $panelFittingEntry = $('.js-panelFittingEntry');
    const goodsFitting = {
        init() {
            this.bindEvent();
        },
        bindEvent() {
            const self = this;

            // 商品状态就绪 - 仅初始化（单次）监听
            PubSub.subscribe('goods.goodsStatusReady.init', (msg, priceInfo) => {
                // 配件主件实时价放置
                $('.js-priceFitting').attr('data-currency', priceInfo.displayPrice);

                // 更新属性面板上按钮状态
                self.updateFittingSave();
            });
        },

        // 计算配件及主件节省金额
        updateFittingSave() {
            if ($panelFittingSave.length) {
                const fittingSave = $panelFittingSave.attr('data-currency');
                let totalSave = add(+fittingSave);
                if (totalSave < 0) {
                    totalSave = 0;
                }
                $panelFittingSave.attr('data-currency', totalSave);
                PubSub.publish('sysUpdateCurrency', {
                    context: $panelFittingEntry[0]
                });
            }
        }
    };
    if ($panelFittingEntry.length) {
        goodsFitting.init();
    }

    // 小购物车面板
    const $panelGoodsCart = $('#js-goodsCart');
    const $btnGoodsCart = $('#js-panelGoodsCartBtns');
    const goodsCart = {
        init() {
            this.bindEvent();
        },

        bindEvent() {
            const self = this;

            // 加购物车
            $(document).on('click', '.js-addToCart', () => {
                self.addCart();
            });

            // 一键购
            $(document).on('click', '.js-buyNow', () => {
                // 定金膨胀如果是可预订状态，传参数isDeposit给后台隐藏登录页面的访客购物入口,depData新增参数
                const product = goodsGlobal.asyncProduct;
                let depData = {};
                if (+product.labelId === 28 && product.isShowDep) {
                    depData = { isDeposit: 1 };
                }
                self.buyNow(depData);
            });

            // paypal购
            $(document).on('click', '.js-buyNowWithPaypal', (e) => {
                if (!$(e.currentTarget).hasClass('disabled')) {
                    self.buyWithPaypal();
                }
            });

            // 添加收藏
            $(document).on('click', '.js-addFav', (e) => {
                const $this = $(e.currentTarget);
                self.collect($this);
            });

            // 开启邮件订阅
            $(document).on('click', '.js-arrivalNotice', async () => {
                // goods组件-arrivalNotice
                const { arrivalNotice } = await import('../component/arrival_notice/arrival_notice.js');
                arrivalNotice.show();
            });

            // 异步价格获取成功
            PubSub.subscribe('goods.priceReady', (msg, resPrice) => {
                // 邮件加密价
                if (+resPrice.labelId === 1) {
                    SELECTEDGOODS.ciphertext = getEmailEo();
                }
            });

            // 商品状态就绪 - 仅初始化（单次）监听
            PubSub.subscribe('goods.goodsStatusReady.init', () => {
                self.updateBtns();
                self.show();
            });

            // 收藏接口
            stateStore.init({
                pool: ['priceData', 'instalmentInfo'],
                callback(map) {
                    self.installmentPay(map.get('priceData'), map.get('instalmentInfo'));
                }
            });
        },

        show() {
            $panelGoodsCart.addClass('show');
        },

        // 更新小购物车条上的按钮状态
        updateBtns() {
            let btns = [];
            const product = goodsGlobal.asyncProduct;
            const status = product.goodsStatus;
            const stock = product.stockSum;
            const stateHandle = {
                // 待上架（发布）
                1: () => {
                    btns = [{
                        cls: 'btn disabled',
                        txt: GOODSLANG.comming_soon,
                    }];
                },
                // 正常可加车
                2: () => {
                    // 库存大于0才可加购
                    if (stock > 0) {
                        btns = [{
                            cls: 'btn goodsBtnCart js-btnShowAttrPanel',
                            txt: GOODSLANG.add_to_cart,
                            data: ['buytype', 'cart'],
                        }, {
                            cls: 'btn goodsBtnBuyNow press js-btnShowAttrPanel',
                            txt: GOODSLANG.buy_now,
                            data: ['buytype', 'buynow'],
                        }];
                    } else {
                        btns = [{
                            cls: 'btn disabled',
                            txt: GOODSLANG.out_of_stock,
                        }];
                    }
                },
                // 下架
                3: () => {
                    btns = [{
                        cls: 'btn disabled',
                        txt: GOODSLANG.discontinued,
                    }];
                },
                // 可订阅
                4: () => {
                    btns = [{
                        cls: 'btn goodsBtnNotice js-arrivalNotice',
                        txt: GOODSLANG.arrival_notice,
                    }];
                },
                // 谍照
                5: () => {
                    btns = [{
                        cls: 'btn disabled',
                        txt: GOODSLANG.comming_soon,
                    }];
                },
            };
            if (stateHandle[status]) {
                stateHandle[status]();
                $btnGoodsCart.empty();
                btns.forEach((item) => {
                    const $btn = $('<a>').addClass(item.cls).text(item.txt);
                    if (item.data) {
                        $btn.attr(`data-${item.data[0]}`, item.data[1]);
                    }
                    $btnGoodsCart.append($btn);
                });
            }

            // 异步价格获取成功
            PubSub.subscribe('goods.priceReady', (msg, resPrice) => {
                // 定金膨胀
                const price = resPrice;
                if (+price.labelId === 28) {
                    const nowTime = (new Date()).getTime() / 1000;
                    const canBuyQty = price.saleQty - price.count;

                    if (nowTime - price.startTime > 0 && price.endTime - nowTime > 0 && nowTime - price.advanceStartTime > 0
                        && price.advanceEndTime - nowTime > 0 && canBuyQty > 0) {
                        const strBNow = `<span class="payDepositWrap">${trans('goods.deposit_detail_paydeposit')}</span>
                        <span class="payDepositPrice js-currency js-btnPayDepositPrice" data-currency="${price.advanceAmount}"></span>`;
                        $('.goodsBtnBuyNow').css('display', 'inline-block');
                        $('.goodsBtnBuyNow').html(strBNow);
                        // 更新货币
                        PubSub.publish('sysUpdateCurrency', {
                            context: $('.js-btnPayDepositPrice').parent()[0]
                        });
                    }
                }
            });
        },

        // 加入购物车
        addCart() {
            PubSub.publish('sysAddToCart', {
                goods: [SELECTEDGOODS],
            });
        },

        // 一键购
        buyNow(depData) {
            PubSub.publish('sysBuyNow', {
                goods: [SELECTEDGOODS],
                depData,
            });
        },

        // 使用paypal快捷支付
        buyWithPaypal() {
            if (GOODSINFO.ppExpressInfo && GOODSINFO.ppExpressInfo.channelCode) {
                buyNow({
                    goods: [SELECTEDGOODS],
                    callback: async (res) => {
                        try {
                            const quickPayData = await serviceCartSendQuickPay.http({
                                loading: true,
                                params: {
                                    channelCode: GOODSINFO.ppExpressInfo.channelCode
                                },
                            });

                            const { redirectUrl } = quickPayData.data;
                            if (redirectUrl) {
                                window.location.href = redirectUrl;
                            } else {
                                layer.msg(trans('user.data_error'));
                            }
                        } catch (e) {
                            console.log('ERROR:shopbtn_operate=>buyWithPaypal', e);
                        }
                    }
                });
            }
        },

        // 分期
        async installmentPay(priceData, instalmentInfo) {
            if (instalmentInfo && instalmentInfo.installments) {
                // 分期付款
                const { Installment } = await import('../component/installment/installment.js');
                window.insInstallment = new Installment();
                PubSub.publish('goods.installmentDataReady', {
                    installmentData: instalmentInfo,
                    priceData,
                });
            }
        },

        // 获取商品收藏状态
        async getCollectStatus({
            $btnCollect,
        }) {
            const sendDataArr = [];

            $btnCollect.each((index, ele) => {
                const $this = $(ele);
                const sku = $this.attr('data-sku');
                const warehouse = $this.attr('data-warehouse');
                sendDataArr.push([sku, warehouse].join('_'));
            });

            const params = {
                goodsSnlist: sendDataArr.join(',')
            };

            const res = await serviceCollectStatus.http({
                loading: false,
                params
            });
            const resData = res.data;

            // 验证是否一一对上
            if ($btnCollect.length === resData.favList.length) {
                const resultData = resData.favList;
                $btnCollect.each((index, ele) => {
                    const $this = $(ele);
                    if (resultData[index].fav) {
                        $this.addClass('isCollection').attr('data-id', resultData[index].id);
                    } else {
                        $this.removeClass('isCollection');
                    }
                });
            }

            stateStore.set('instalmentInfo', resData.instalmentInfo);
        },

        // 分发收藏=> 添加|取消
        collect($btnCollect) {
            if ($btnCollect.hasClass('isCollection')) {
                this.collectRemove($btnCollect);
            } else {
                this.collectAdd($btnCollect);
            }
        },

        // 商品 - 添加到收藏
        async collectAdd($btnCollect) {
            try {
                const sku = $btnCollect.attr('data-sku');
                const warehouse = $btnCollect.attr('data-warehouse');
                const res = await serviceCollectAdd.http({
                    method: 'POST',
                    loading: true,
                    errorPop: false,
                    data: {
                        goods: [[sku, warehouse].join('_')]
                    }
                });
                if (+res.status === 0) {
                    this.getCollectStatus({
                        $btnCollect
                    });
                } else if (res.data && res.data.redirectUrl) {
                    window.location.href = res.data.redirectUrl;
                } else {
                    layer.msg(res.msg);
                }
            } catch (error) {
                throw new Error(error);
            }
        },

        // 商品 - 取消收藏
        async collectRemove($btnCollect) {
            try {
                const collectId = $btnCollect.attr('data-id');
                const res = await serviceDeleteCollection.http({
                    loading: true,
                    errorPop: false,
                    method: 'POST',
                    data: {
                        favId: [collectId],
                    },
                });
                if (+res.status === 0) {
                    this.getCollectStatus({
                        $btnCollect
                    });
                } else if (res.data && res.data.redirectUrl) {
                    window.location.href = res.data.redirectUrl;
                } else {
                    layer.msg(res.msg);
                }
            } catch (error) {
                throw new Error(error);
            }
        },
    };
    goodsCart.init();

    /* 广告位 */
    const advertisingPosition = {
        init() {
            this.getData();
        },
        async getData() {
            const cdnCountry = await getCdnCountryCode();
            const { data, status } = await serviceGoodsAdvertising.http({
                params: {
                    countryCode: cdnCountry
                }
            });
            const $goodsAdvertisingBlock = $('.goodsAdvertising_block');
            if (status === 0 && data.banner_url) {
                const adver = `
                    <a href="${data.banner_link}" class="goodsAdvertising_link">
                        <img src="${data.banner_url}" alt="" class="goodsAdvertising_img">
                    </a>
                `;
                $goodsAdvertisingBlock.append(adver);
            } else {
                $goodsAdvertisingBlock.remove();
            }
        }
    };
    advertisingPosition.init();

    /* 推广链接301跳转 */
    function redirectPromote() {
        PubSub.subscribe('goods.goodsStatusReady.init', (msg, resData) => {
            const goodsStatus = resData.goodsStatus;
            const stock = resData.stockSum;
            linkRedirect.init({ goodsStatus, stock });
        });
    }
    redirectPromote();


    /* 评论区 */
    const $goodsReviewsPreview = $('.goodsReviews_preview');
    const goodsReviews = {
        init() {
            this.bindEvent();
        },
        bindEvent() {
            $goodsReviewsPreview.on('click', (e) => {
                // detail板块评价，点击除（图片|视频）外均跳转到Reviews大区
                if ($(e.target).parents('.js-goodsReviewsImgs').length < 1) {
                    switchToComment();
                }
            });
            $('.js-reviewAnchorItem').on('click', (e) => {
                e.preventDefault();
                switchToComment();
            });
        }
    };
    goodsReviews.init();

    /* 描述区 */
    const goodsDescription = {
        init() {
            this.bindEvent();
        },
        bindEvent() {
            $(document).on('click', '.js-tabSizeGuide li', (e) => {
                const $this = $(e.currentTarget);
                const $panel = $this.parent().next();
                const index = $this.index();
                $this.addClass('active').siblings().removeClass('active');
                $panel.children().eq(index).addClass('show').siblings()
                    .removeClass('show');
            });
        },
    };
    goodsDescription.init();

    // 商详全局调用
    const goodsGlobal = {
        init() {

            // 因用户可能直接返回推荐位记忆位置，导致埋点先执行，造成埋点数据丢失 2018-10-22 16:53:10
            // /**
            //  * 评论
            //  * 描述详情
            //  * 推荐
            //  */
            // lazyObserver({
            //     observeDom: document.querySelectorAll('.js-lazyModule'),
            //     async callBack(target) {
            //         try {
            //             const { panel } = target.dataset;
            //             if (panel) {
            //                 const { default: module } = await import(`../component/async_module/${panel}/${panel}.js`);

            //                 if (typeof module.init === 'function') {
            //                     module.init(target);
            //                 }
            //             }
            //             $(target).removeClass('lazyModule');
            //         } catch (e) {
            //             console.log('ERROR:goodsDetail=>goodsGlobal.lazyObserver', e);
            //         }
            //     },
            // });

            // 底部图标 iconfont 雪碧图
            // lazyObserver({
            //     async callBack() {
            //         // 底部图标进入视区加载
            //         import('common/css/footerFontIcon/iconfont.css');
            //     },
            //     observeDom: document.querySelector('.siteFooter')
            // });

            this.bindEvent();

            // 初始获取商品状态
            this.getGoodsStatus(GOODSINFO.goodsSn, GOODSINFO.warehouseCode, 'init');

            // 星星评分
            $('.js-star').star();
        },
        bindEvent() {
            const self = this;

            // 回到商详主界面（针对当前页面hash重定向去的面板）
            $('.js-navBtnGoMain').on('click', () => {
                window.history.go('-1');
            });

            // 触发评论图片
            $(document).on('click', '.js-btnViewImg', (e) => {
                self.showImgView($(e.currentTarget));
                return false;
            });

            // 触发视频播放
            $(document).on('click', '[data-video]', (e) => {
                self.showViewPlay($(e.currentTarget).attr('data-video'));
            });

            // 更新购物车
            PubSub.publish('sysUpdateUserStatus');

            // 更新货币
            PubSub.publish('sysUpdateCurrency');

            // 分期
            // channel: 'multi',
            PubSub.subscribe('goods.installment', (msg, { priceData, instalmentInfo }) => {
                if (IS_LOGIN) {
                    stateStore.set('priceData', priceData);
                } else {
                    goodsCart.installmentPay(priceData, instalmentInfo);
                }
            });

            // 加入购物车或者理解购买操作
            $(document).on('click', '.js-btnShowAttrPanel', async (e) => {
                const { default: goodsProps } = await import('../component/goods_props/goods_props.js');

                GOODSPROPS = goodsProps;

                // 初始化分期利率
                setTimeout(() => {
                    const $this = $(e.currentTarget);
                    const buyType = $this.attr('data-buytype');
                    GOODSPROPS.show(buyType, {
                        SELECTEDGOODS,
                        GOODSLANG,
                        goodsGlobal,
                        GoodsInfo
                    });
                }, 0);
            });

            // 商品状态就绪 - 仅初始化（单次）监听
            PubSub.subscribe('goods.goodsStatusReady.init', () => {
                // 更新属性面板上按钮状态
                const product = goodsGlobal.asyncProduct;

                // 商品营销价状态
                class CurGoodsPromoPrice extends GoodsPromoPrice {
                    priceLoadCall() {
                        // coupoon 优惠券 \ goods组件-优惠券 \ promotion 活动
                        lazyObserver({
                            rootMargin: `-${window.lib.flexible.rem2px(1.8)}px`,
                            async callBack() {
                                // goods组件-推荐位
                                const { default: promotionCoupon } = await import('../component/promotion_coupon/promotion_coupon.js');

                                // 到貨通知不顯示coupon
                                if (product.goodsStatus !== 4) {
                                    promotionCoupon.init();
                                } else {
                                    // 到货通知隐藏 coupon promotion
                                    $('.js-btnShowCoupon,.js-btnShowPromo').remove();
                                    // 到货通知隐藏 app专享价
                                    $('.js-applinkToDetail').remove();
                                }
                            },
                            observeDom: document.querySelector('.js-btnShowCoupon')
                        });
                    }
                }

                const insGoodsPromoPrice = new CurGoodsPromoPrice();
                // 将商品状态注入到营销价状态中
                insGoodsPromoPrice.goodsStatus = product.goodsStatus;
                // 将库存注入到营销价中
                insGoodsPromoPrice.stock = product.stockSum;
                // 营销价模块初始化
                insGoodsPromoPrice.init();

                // 变更商品价格状态
                self.getGoodsInfo();

                // 设置浏览历史记录
                self.setViewHistory(product.displayPrice);

                // 处理网采商品
                goodsGlobalBefore.bfProductHandle();

                // 配件入口
                self.goodsFittingEntry(product.displayPrice);
            });
        },

        // 商品点击率统计数据传送
        getGoodsClickUrl() {
            let url = $('#js-hdClickUrl').val();
            url = url.replace(/{{goodSn}}/, GOODSINFO.goodsSn);
            $(`<img src="${url}">`).css('display', 'none').appendTo('body');
        },

        // 获取评论图片组:一个评论内的所有图片（$currentItem: 当前点选的图片）
        getReviewsImgList($currentItem) {
            if (typeof $currentItem === 'undefined' || $currentItem.length === 0) {
                return [];
            }

            const $parent = $currentItem.parents('.goodsReviews_imgs');
            const $imgs = $parent.find('.js-btnViewImg');
            const result = [];
            $imgs.each(function (index, ele) {// eslint-disable-line
                const $ele = $(ele);

                // 记录当前点击在当条评论图片中是第几张图片
                if ($currentItem[0] === $ele[0]) {
                    result.initIndex = index;
                }

                result.push({
                    thumb: $ele.attr('data-src'),
                    title: $ele.attr('alt') || $ele.attr('title'),
                    src: $ele.attr('data-source-src'),
                });
            });

            return result;
        },

        // 显示图片预览(需要当前图片对象)
        showImgView($ele) {
            const insImgView = new ImgView();
            insImgView.imgList = this.getReviewsImgList($ele);
            insImgView.show();
        },

        // 显示视频弹窗(需要视频码)
        async showViewPlay(videoCode) {
            // goods组件-视频播放
            const { VideoPlay } = await import('../component/video_play/video_play.js');
            const insVideoPlay = new VideoPlay();
            insVideoPlay.videoCode = videoCode;
            insVideoPlay.fullPlay();
        },

        /**
         * 获取商品信息(含商品可购买状态)
         *
         * 返回goodsStatus 对应值
         * 1    待发布
         * 2    上架
         * 3    下架(discontinued)
         * 4    到货通知(arrival notice)
         * 5    谍照
         *
         * @param {*商品sku} goodsSn
         * @param {*商品仓库码} virWhCode
         */
        async getGoodsStatus(goodSn, virWhCode, flag = 'init') {
            try {
                const countryCode = await goodsCountryCode.get();
                const params = {
                    countryCode,
                    goodSn,
                    virWhCode,
                };

                if (getEmailEo()) {
                    params.eo = getEmailEo();
                }

                const res = await serviceGoodsInfo.http({
                    loading: false,
                    params
                });
                if (+res.status === 0) {
                    // 商品实时信息
                    const price = res.data;
                    if (+price.labelId === 28) {
                        // 当单价格可售数量(saleQty)及单用户可购数量(userBuyLimit)为空或者无返回字段时，本应为无穷大，现赋值为库存值+1
                        if (!price.saleQty) {
                            price.saleQty = +price.stockSum + 1;
                        }
                        if (!price.userBuyLimit) {
                            price.userBuyLimit = +price.stockSum + 1;
                        }
                        const nowTime = (new Date()).getTime() / 1000;
                        // 定义canBuyQty此产品剩余购买数
                        const canBuyQty = price.saleQty - price.count;
                        // 定义isShowDep可预订状态
                        const isShowDep = nowTime - price.startTime > 0 && price.endTime - nowTime > 0 && nowTime - price.advanceStartTime > 0
                        && price.advanceEndTime - nowTime > 0 && canBuyQty > 0;
                        // 定义isShowNorPrice可不预订状态，显示普通价格
                        const isShowNorPrice = nowTime - price.startTime > 0 && price.endTime - nowTime > 0 && (nowTime - price.advanceStartTime < 0
                            || price.advanceEndTime - nowTime < 0 || canBuyQty <= 0);
                        let depLessCount = price.saleQty - price.count;
                        depLessCount = depLessCount > 0 ? depLessCount : 0;
                        const arr = [depLessCount, price.userBuyLimit, price.stockSum];
                        const lessCanBuy = Math.min.apply(null, arr);
                        if (isShowDep) {
                            Object.assign(price, {
                                isShowDep,
                                lessCanBuy,
                            });
                            $('.goodsBtnCart').css('display', 'none'); // 定金膨胀时隐藏加车按钮
                        } else if (isShowNorPrice) {
                            Object.assign(price, {
                                isShowNorPrice,
                            });
                        }
                    }
                    this.asyncProduct = price;

                    // 商品实时信息获取成功
                    // goods.goodsStatusReady.init|goods.goodsStatusReady.every
                    PubSub.publish(`goods.goodsStatusReady.${flag}`, res.data);
                }
            } catch (error) {
                throw new Error(error);
            }
        },

        /**
         * 获取商品 营销价格+商品库存+分期信息
         * 入参：good_sn,warehouse_code,shop_code,is_virtual,categoryId
         */
        async getGoodsInfo() {
            try {
                const params = {
                    good_sn: GOODSINFO.goodsSn,
                    shop_code: GOODSINFO.shopCode,
                    warehouse_code: GOODSINFO.warehouseCode,
                    is_virtual: GOODSINFO.isVirtual,
                    categoryId: GOODSINFO.categoryId,
                };

                if (getEmailEo()) {
                    params.eo = getEmailEo();
                }

                const res = await serviceGoodsPriceStockInstallment.http({
                    params,
                    errorPop: false,
                    loading: false,
                });
                if (+res.status === 0 && res.data) {
                    const resData = res.data;

                    // 当单价格可售数量(saleQty)及单用户可购数量(userBuyLimit)为空或者无返回字段时，本应为无穷大，现赋值为库存值+1
                    if (+resData.price.labelId === 28 && !resData.price.saleQty) {
                        const product = goodsGlobal.asyncProduct;
                        resData.price.saleQty = +product.stockSum + 1;
                    }
                    if (+resData.price.labelId === 28 && !resData.price.userBuyLimit) {
                        const product = goodsGlobal.asyncProduct;
                        resData.price.userBuyLimit = +product.stockSum + 1;
                    }

                    // 营销价格
                    if (resData.price) {
                        const priceData = res.data.price;
                        // 无特殊价时，默认为本店正常售价
                        if (typeof priceData.labelId === 'undefined') {
                            priceData.labelId = -1;
                        }
                        // 定金膨胀
                        if (+priceData.labelId === 28) {
                            class DepoistPrice extends GoodsDepoistPrice {}
                            const insDepoistPrice = new DepoistPrice();
                            insDepoistPrice.init();
                        }
                        if (+resData.price.labelId === 28) {
                            const price = resData.price;
                            const nowTime = (new Date()).getTime() / 1000;
                            const canBuyQty = price.saleQty - price.count;
                            const isShowDep = nowTime - price.startTime > 0 && price.endTime - nowTime > 0 && nowTime - price.advanceStartTime > 0
                            && price.advanceEndTime - nowTime > 0 && canBuyQty > 0;
                            const isShowNorPrice = nowTime - price.startTime > 0 && price.endTime - nowTime > 0 &&
                            (nowTime - price.advanceStartTime < 0 || price.advanceEndTime - nowTime < 0 || canBuyQty <= 0);
                            if (isShowNorPrice) {
                                SELECTEDGOODS.advanceLabel = 2; // 定金膨胀加车为页面价
                                priceData.isShowNorPrice = 1;
                            }
                            if (isShowDep) {
                                SELECTEDGOODS.advanceLabel = 1; // 定金膨胀加车为预付价
                                priceData.isShowDep = 1;
                                $('.js-btnShowPromo').remove(); // 移除活动入口
                                $('.js-applinkToDetail').remove(); // 移除活动入口
                                $('.js-panelFittingEntry').remove(); // 移除搭配入口
                                $('.goodsBtnCart').css('display', 'none'); // 定金膨胀时隐藏加车按钮
                            }
                        }

                        PubSub.publish('goods.priceReady', priceData);
                        PubSub.publish('goods.installment', {
                            priceData,
                            instalmentInfo: res.data.instalmentInfo,
                        });
                    }
                }
            } catch (error) {
                throw new Error(error);
            }
        },

        // 设置历史记录
        setViewHistory(price = '') {
            GoodsViewHistory.set({
                url: window.location.href,
                img: GOODSINFO.thumb,
                title: GOODSINFO.title,
                sku: GOODSINFO.goodsSn,
                wid: GOODSINFO.warehouseCode,
                shopPrice: GOODSINFO.shopPrice,
                categoryId: GOODSINFO.categoryId,
                price,
            });
        },

        // 配件入口 按需载入
        goodsFittingEntry(displayPrice) {

            // 配件信息
            lazyObserver({
                observeDom: document.querySelector('#js-panelGoodsFitting'),
                async callBack() {
                    const { default: panelFitting } = await import('../component/panelFitting/panelFitting.js');
                    panelFitting.init(displayPrice);
                }
            });
        }
    };
    goodsGlobal.init();

    // 获取分类ID\用于跳转到首页
    indexHeaderInfo.setCateId(GOODSINFO.categoryId);
    indexHeaderInfo.toIndexLink();

    // 用户登陆状态
    const goodsUserLogin = {
        init() {
            this.bindEvent();
        },
        bindEvent() {
            if (IS_LOGIN) {
                goodsCart.getCollectStatus({
                    $btnCollect: $('.js-addFav')
                });
            }
        }
    };
    goodsUserLogin.init();

    PubSub.subscribe('nativeLoad', async () => {
        // 商品点击率统计数据传送(2019-3-13 10:08:00商详取消webclick--获取商品详情的数据统计)
        // goodsGlobal.getGoodsClickUrl();

        // 异步文件
        try {
            const { default: asyncFn } = await import('../common/goods_detail_async');
            asyncFn();
        } catch (e) {
            console.log('e', e);
        }
    });
});

// 手动 ready
// https://github.com/iliakan/javascript-tutorial-en/blob/master/2-ui/3-event-details/10-onload-ondomcontentloaded/article.md
if (document.readyState === 'complete' || document.readyState === 'interactive') {
    PubSub.publish('nativeReady');
}

// 手动 load
if (document.readyState === 'complete') {
    setTimeout(() => {
        PubSub.publish('nativeLoad');
    }, 200);
}
