import 'js/bootstrap.js';
import { historyShow } from '../component/history_goods_item/history_goods_item.js';
import './history.css';

historyShow.init();
