import PubSub from 'pubsub-js';
import layer from 'layer';
import Clipboard from 'clipboard';
import 'js/lib/zepto/fx.js';
import 'js/lib/zepto/fx_methodes.js';
import 'js/lib/zepto/zepto.scrollTop.js';
import 'js/bootstrap.js';
import { asyncPrice } from 'js/core/asyncPrice';
import Timer from 'component/timer/timer';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import staticAsset from 'js/core/staticAsset';
import Sticky from 'component/sticky/sticky.js';
import appSdk from 'js/core/app.sdk.js';
import isLogin from 'js/core/user/isLogin';
import { serviceCouponUpdateInfo } from 'js/service/coupon';
import { serviceCouponIsGot } from 'js/service/promotion';
import { throttle } from 'js/utils/index.js';
import pageExplore from 'js/track/define/pageExplore';

// 多语言相关
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';

import './new_hand.css';

pageExplore();

function importCommonJs() {
    Promise.all([import('modules/header/header.js'), import('modules/footer/footer.js')]);
}

if (!appSdk.IS_APP) {
    importCommonJs();
}

runtime.trans = trans;
runtime.staticAsset = staticAsset;

asyncPrice();

const {
    DOMAIN_LOGIN,
} = window.GLOBAL;

PubSub.subscribe('nativeReady', async () => {
    const userIsLogin = await isLogin(appSdk.IS_APP);
    let newCouponIds;
    if (userIsLogin) {
        serviceCouponIsGot.http({}).then(({ status, data }) => {
            if (status === 0) {
                if (data.isGot === 0) {
                    if (data.coupons && data.coupons.length) {
                        newCouponIds = data.coupons.join();
                        $('.js-gift-btn').css('display', 'inline-block');
                    } else {
                        $('.js-lazyload-two').removeClass('none');
                        $('.js-lazyload-one').addClass('none');
                        $('.js-allTaken').css('display', 'inline-block');
                    }
                } else {
                    $('.js-lazyload-two').removeClass('none');
                    $('.js-lazyload-one').addClass('none');
                    $('.js-gifted-btn').css('display', 'inline-block');
                }
            } else {
                $('.js-gift-btn').css('display', 'inline-block');
            }
        });
    } else {
        $('.js-gift-btn').css('display', 'inline-block');
    }
    // 导航栏吸附
    const sticky = new Sticky({
        nav: document.querySelector('.floorNav'),
        navItem: '.floorNav_item',
        navFixedClassName: 'floorFixed',
        section: '.js-achor'
    });
    sticky.init();

    // 查看更多
    $('.js-viewMore').on('click', (event) => {
        const $this = $(event.currentTarget);
        const $goodsIist = $this.parent('.viewMore').prev('.goods_list');
        const $gbGoodsMoreItem = $this.parent('.viewMore').prev('.goods_list').find('.gbGoodsMoreItem');
        if ($this.hasClass('isExpend')) {
            $gbGoodsMoreItem.fadeOut().css('display', 'none');
            $this.removeClass('isExpend').text(trans('goodslist.new_brand_view_all'));
        } else {
            if ($goodsIist.hasClass('deals')) {
                $gbGoodsMoreItem.fadeIn().css('display', 'block');
            } else {
                $gbGoodsMoreItem.fadeIn().css('display', 'inline-block');
            }
            $this.addClass('isExpend').text(trans('goodslist.view_less'));
        }
        // sticky.init();
    });


    // 领取店铺优惠券
    $('.js-gift-btn').on('click', (event) => {
        if (!userIsLogin) {
            if (!appSdk.IS_APP) {
                window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm?ref=${encodeURIComponent(window.location.href)}`;
            } else {
                window.location.href = 'gearbest://login?callback=userinfo()';
            }
            return;
        }
        const that = event.currentTarget;
        try {
            getCouponItem({
                templateCode: newCouponIds,
                erropPop: false,
                successTip: false
            }).then(({ status, msg, data }) => {
                if (status === 0) {
                    const index = layer.open({
                        type: 1,
                        area: ['auto', '700px'],
                        content: $('#js-success')[0].outerHTML,
                    });
                    // 关闭弹出层
                    $('.js-closeBtn').on('click', () => {
                        layer.close(index);
                    });
                    $(that).css('display', 'none');
                    $('.js-gifted-btn').css('display', 'inline-block');
                    $('.js-lazyload-one').addClass('none');
                    $('.js-lazyload-two').removeClass('none');
                } else {
                    const index = layer.open({
                        type: 1,
                        area: ['auto', '700px'],
                        content: $('#js-faild')[0].outerHTML
                    });
                    // 关闭弹出层
                    $('.js-closeBtn').on('click', () => {
                        layer.close(index);
                    });
                }
            });
        } catch(e) { // eslint-disable-line
        }
    });

    // 查看规则
    $('.js-rules').on('click', () => {
        const rulesTitle = $('.js-rules').text();
        const index = layer.open({
            title: rulesTitle,
            type: 1,
            area: ['auto', '700px'],
            content: $('#couponRules')[0].outerHTML,
        });
        // 关闭弹出层
        $('.js-closeBtn').on('tap', () => {
            layer.close(index);
        });
    });


    // 领取商品优惠券
    async function getGoodCoupon() {
        const $self = $(this);
        if ($self.parents('.hasGeted').length) {
            return false;
        }
        const couponId = $(this).attr('data-couponid');
        const resultTemp = await import('./artTpl/getCouponSuccess');
        const linkData = {};
        linkData.useLink = $self.attr('data-use-link');
        linkData.skuLink = $self.attr('data-app-sku');
        linkData.wcodeLink = $self.attr('data-app-wcode');
        linkData.productLink = $self.attr('product-link');
        getCouponItem({
            templateCode: couponId,
            successTip: false,
        }).then(({ status, msg, data }) => {
            if (status === 0) {
                $self.parents('.goods_item').addClass('hasGeted');
                $self.text(`${trans('goodslist.new_brand_coupon')}: ${data.couponCode}`);
                $self.attr('data-code', data.couponCode);
                const popHtml = resultTemp({ data, linkData });
                const index = layer.open({
                    type: 1,
                    area: ['auto', '700px'],
                    content: popHtml,
                });
                /* 复制coupon 码 */
                const clip = new Clipboard('.js-copyCoupon', {
                    text(trigger) {
                        return trigger.dataset.code;
                    },
                });
                clip.on('success', () => {
                    layer.open({
                        content: `${trans('goodslist.new_hand_copy_succeed')}`,
                        skin: 'msg',
                        time: 2
                    });
                });
                $('.hasGeted .js-getGoodCoupon').each((num, item) => {
                    clipHandle(item);
                });
                // 关闭弹出层
                $('.js-closeBtn').on('click', () => {
                    layer.close(index);
                });
            }
        });
        return true;
    }
    $('.js-getGoodCoupon').on('tap', getGoodCoupon);
    $('.hasGeted .js-getGoodCoupon').each((index, item) => {
        clipHandle(item);
    });
    const $toTopBtn = $('.js-bottomTopBtn');
    const $goodsFloorCon = $('.goodsFloorCon');
    const $window = $(window);
    PubSub.subscribe('nativeScroll', throttle(scrollShow, 300));
    function scrollShow() {
        const goodsFloorConTop = $goodsFloorCon.offset().top;
        if ($window.scrollTop() > goodsFloorConTop) {
            $toTopBtn.addClass('show');
        } else {
            $toTopBtn.removeClass('show');
        }
    }
    $toTopBtn.click(() => {
        $window.scrollTop(0);
    });
    // 促销码板块倒计时
    const timer = new Timer();
    timer.add('.js-codePromotionTime', {
        format: `${trans('promotion.begins_in')} {dd} | {hh} | {mm} | {ss}`,
        interval: 'begin',
        onStart(target) {
        },
        onEnd(target) {
            timer.add(target, {
                format: `${trans('promotion.ends_in')} {dd} | {hh} | {mm} | {ss}`,
                interval: 'end',
                onStart(targetOne) {
                },
                onEnd(targetOne) {
                    const $targetBuy = $(targetOne).siblings('.goods_otherInfo').find('.buyLink');
                    $targetBuy.text(trans('promotion.promotion_deal_ended'));
                    $targetBuy.css({
                        'background-color': '#ddd',
                        color: '#999'
                    });
                }
            });
        }
    });
    $('.js-promotionCodeCopy').each((index, item) => {
        clipHandle(item);
    });
});

// 剪切板
function clipHandle(item) {
    const clip = new Clipboard(item, {
        text(trigger) {
            return trigger.dataset.code;
        },
    });
    clip.on('success', () => {
        layer.open({
            content: `${trans('goodslist.new_hand_copy_succeed')}`,
            skin: 'msg',
            time: 2
        });
    });
}

// 刷新cdn缓存
(async () => {
    try {
        const { status, data } = await serviceCouponUpdateInfo.http({

            params: {
                templateCode: $('.couponContent').eq(0).data('templatecodes'),
            }
        });
        if (status === 0) {
            $('.js-getGoodCoupon').each((index, item) => {
                const $this = $(item);
                const templateid = $this.attr('data-couponid');
                if (data.hasOwnProperty(templateid)) { // eslint-disable-line
                    $this.attr('data-code', data[templateid]);
                    $this.parents('.goods_item').addClass('hasGeted').removeClass('expired').removeClass('noMore');
                    $this.text(`${trans('goodslist.new_brand_coupon')}: ${data[templateid]}`);
                }
            });
            $('.hasGeted .js-getGoodCoupon').each((index, item) => {
                clipHandle(item);
            });
        }
    } catch (e) { // eslint-disable-line
    }
})();
