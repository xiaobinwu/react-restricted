import 'js/bootstrap';
import PubSub from 'pubsub-js';
import 'modules/header/header.css';
import 'modules/footer/footer.js';
import indexHeaderInfo from 'js/core/index/headerInfo';
import './cate_nav.css';


indexHeaderInfo.toIndexLink();
PubSub.publish('sysUpdateUserStatus');


const cateNavApp = {
    recMenuBox: $('.cate_listBox'),
    recMenuItem: $('.js-cateToggle'),
    recMenuList: $('.cate_itemView'),
    init() {
        this.recToggleControl();
    },
    recToggleControl() {
        const taht = this;
        taht.recMenuList.each((index, val) => {
            const thatSef = $(val);
            if (thatSef.find('li').length > 0) {
                thatSef.closest('li.cate_li').removeClass('none');
            }
        });
        taht.recMenuBox.on('click', 'li.cate_li span', function navControl(e) {
            e.preventDefault();
            const thatSef = $(this);
            const thisParent = thatSef.closest('li');
            const subNav = thisParent.find('ul');
            const siblinsUl = thisParent.siblings().find('ul');

            siblinsUl.each((index, el) => {
                const $el = $(el);
                if ($el.css('display') !== 'none') {
                    $el.hide();
                    $(el).closest('li.cate_li').find('span.cate_icon i').removeClass('icon-minus')
                        .addClass('icon-plus')
                        .html('+');
                }
            });

            if (subNav.css('display') !== 'none') {
                subNav.hide();
                thisParent.find('span.cate_icon i').removeClass('icon-minus').addClass('icon-plus').html('+');
            } else {
                subNav.css({ opacity: 1, visibility: 'visible' }).show();
                thisParent.find('span.cate_icon i').removeClass('icon-plus').addClass('icon-minus').html('-');
            }
        });
    }
};

cateNavApp.init();
