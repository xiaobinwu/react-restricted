import PubSub from 'pubsub-js';
import Swiper from 'js/lib/swiper.js';
import layer from 'layer';
import Timer from 'component/timer/timer.js';
import Clipboard from 'clipboard';
import dealsTrack from 'js/track/define/dealses.js';
import 'js/bootstrap';
import 'js/lib/zepto/fx.js';
import 'js/lib/zepto/fx_methodes.js';
import 'modules/header/header.js';
import 'modules/footer/footer.js';

import { trans } from 'js/core/translate.js';
import { serviceDealsPage } from 'js/service/promotion';

import Loader from 'component/loader/loader';
import runtime from 'art-template/lib/runtime';

import temp from './template/list.art';
import './deals.css';

/* Deals频道大数据埋点 */
dealsTrack();

runtime.trans = trans;

const $body = $('body');
const $labelFilterWrap = $('#js-labellFilterWrap');
const $panelFilterWrap = $('#js-panelFilterWrap');
const $labelsFilter = $labelFilterWrap.find('.js-labelFilter');
const $panelsFilter = $panelFilterWrap.find('.js-panelFilter');
const $panelList = $('#js-panelList');
const $btnViewMore = $('#js-btnViewMore');
const sendParams = {
    page: 1,
};
const timer = new Timer();


const deals = {
    init() {
        // banner轮播
        this.bannerSwiper();

        // 移除当前高亮项的链接
        this.removeActiveHref();

        // 分页数据
        this.initLoader();

        // 对新dom绑定事件
        this.reBindEvent();

        // 事件
        this.bindEvent();
    },

    bindEvent() {
        const self = this;

        // 筛选一级项点击
        $labelsFilter.on('tap', (e) => {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const index = $this.index();

            $panelsFilter.removeClass('show');

            if ($this.hasClass('active')) {
                self.bodyUnlock();
                $this.removeClass('active');
            } else {
                self.bodyLock();
                $labelsFilter.removeClass('active');
                $this.addClass('active');
                $panelsFilter.eq(index).addClass('show');
            }
        });

        // 筛选面板区点击=>还原所有筛选下拉及关闭筛选面板
        $panelFilterWrap.on('click', (e) => {
            self.bodyUnlock();
            $labelsFilter.removeClass('active');
            $panelsFilter.removeClass('show');
        });

        // 加入购物车
        $(document).on('tap', '.js-addToCart', (e) => {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const sku = $this.attr('data-sku');
            const warehouse = $this.attr('data-warehouse');
            self.addToCart(sku, warehouse);
        });
    },

    // 对新dom绑定事件
    reBindEvent() {
        // 复制coupon码
        this.copyCoupon();

        // 倒计时
        this.countdown();
    },

    // 锁定页面
    bodyLock() {
        $body.addClass('lock');
    },

    // 解锁页面
    bodyUnlock() {
        $body.removeClass('lock');
    },

    // banner轮播
    bannerSwiper() {
        if ($('.js-dealsSwiper').find('.swiper-slide').length > 1) {
            new Swiper('.js-dealsSwiper', {
                direction: 'horizontal',
                loop: true,
                autoplay: {
                    stopOnLastSlide: true,
                    delay: 1500,
                },
                pagination: {
                    el: '.swiper-pagination',
                },
                lazy: {
                    loadPrevNext: true
                }
            });
        }
    },

    // 移除当前高亮项的链接
    removeActiveHref() {
        $panelFilterWrap.find('.deals_filterLink.active').attr('href', 'javascript:;');
    },

    // 加载loader
    initLoader() {
        const self = this;
        // 获取数据参数
        const params = sendParams;

        // 分页数据加载
        const loader = new Loader({
            viewMore: $btnViewMore,
            auto: true,
            data() {
                params.page += 1;

                // 请求其他分类数据
                return serviceDealsPage.http({
                    params,
                    loading: false,
                });
            },
            loadStart() {
                // 开始加载新数据
            },
            loadSuccess(res) {
                const data = res.data || {};
                const list = data.dealsGoodsInfo;

                // 大数据埋点 加载TrackData 数据
                if (list.length) {
                    list.forEach((item) => {
                        window.TrackData[`${item.goodsSn}_${item.wareCode}`] = {
                            k: item.wareCode,
                            pc: item.categoryId,
                            sku: item.goodsSn,
                            pam: 1
                        };
                    });
                }

                // 向当前分类容器追加数据
                $panelList.append(temp({
                    data: list,
                    orderByCode: data.orderByCode,
                    pageIndex: data.page,
                    pageSize: data.pageSize
                }));

                // 再绑定事件
                self.reBindEvent();

                // 更新货币
                PubSub.publish('sysUpdateCurrency', {
                    context: $panelList[0]
                });

                // 加载数据结束（完成|没有更多啦）
                if (!list.length) {
                    loader.end();
                    $btnViewMore.text($btnViewMore.attr('data-empty-text')).addClass('show');
                }
            }
        });
        loader.load();
    },

    // 复制coupon码
    copyCoupon() {
        const clip = new Clipboard('.js-copy', {
            text(trigger) {
                return trigger.dataset.code;
            }
        });
        clip.on('success', () => {
            layer.msg(trans('goodslist.copy_successed'));
        });
    },

    // 倒计时
    countdown() {
        timer.clean();
        // 活动已经开始商品的倒计时
        timer.add('.js-cutDownTime', {
            format(time) {
                return time < 24 * 60 * 60 ? '{hh}:{mm}:{ss}' : trans('goods.days_h_m_s', ['{d}', '{hh}', '{mm}', '{ss}']);
            },
            interval: 'end',
            onStart() {

            },
        });
    },

    // 加入购物车
    addToCart(sku, warehouse) {
        PubSub.publish('sysAddToCart', {
            goods: {
                goodsSn: sku,
                warehouseCode: warehouse,
                qty: 1,
            },
        });
    }
};
deals.init();
