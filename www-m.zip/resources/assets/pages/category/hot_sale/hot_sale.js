import PubSub from 'pubsub-js';
import Swiper from 'js/lib/swiper.js';
import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';

import { trans } from 'js/core/translate.js';
import { throttle } from 'js/utils';
import { serviceHotSaleList } from 'js/service/promotion';
import { STORAGE_GOODSLIST_NODE } from 'js/variables';
import runtime from 'art-template/lib/runtime';
import Loader from 'component/loader/loader';
import asyncPriceDiscount from 'js/core/goods/asyncPriceDiscount';
import pageExplore from 'js/track/define/pageExplore';
import GoodsItem from '../component/goods_item/goods_item.js';
import lsitPageRecom from '../../newIndex/common/js/listPageRecom';

import tempWord from './template/keyword_tpl.art';
import tempBanner from './template/banner_tpl.art';
import './hot_sale.css';


runtime.trans = trans;
pageExplore();

let loader = null;
const $body = $('body');
const $dealsFilterList = $('.js-dealsFilterList a');
const $panelFilterWrap = $('.js-panelFilterWrap');
const $labelsFilter = $('.js-labellFilterBox').find('.js-labelFilter');
const $panelsFilter = $panelFilterWrap.find('.js-panelFilter');
const $opacityWrap = $('.js-opacityWrap');
const $hotSalelabel = $('.js-hotSalelabel');
const $lodingBounce = $('.js-lodingBounce');
const $operaItemX = $('.js-operaSelect');
const $rateCounte = $('.js-star');
const $panelList = $('.js-panelList');
const $viewMoreBox = $('.js-viewMoreBox');
const $btnViewMore = $('.js-btnViewMore');
const $recommendList = $('.hotSale_listWrap .js-panelList');

const catId = $('input[name=inputCateId]').val();
const sendParams = {
    catId,
    page: 1,
};


const hotSaleApp = {
    init() {
        // Banner 轮播
        this.bannerSwiper();

        const type = 5;
        const renderResult = lsitPageRecom.pageShow(type);
        if (renderResult) {
            sendParams.page = renderResult.page;
            // 加载数据结束（完成|没有更多啦）
            if (renderResult.page >= renderResult.totalPage) {
                $btnViewMore.text(trans('goodslist.no_more_tips'));
                setTimeout(() => {
                    if ($viewMoreBox.hasClass('on')) {
                        $viewMoreBox.removeClass('on');
                    }
                }, 1500);
            }
        }

        // 分页数据
        this.initLoader();

        // 事件绑定
        this.bindEvent();

        // 返回顶部
        this.initScrollTopfunControl();

    },

    bindEvent() {
        const self = this;

        // 初始化橱窗
        GoodsItem.init({
            container: $panelList,
        });
        asyncPriceDiscount({
            elementLists: $('.js-panelList').find('.js-asyncPrice'),
            shopPriceClassName: '.gbGoodsItem_markPrice',
        });

        // 筛选一级项点击
        $labelsFilter.on('tap', (e) => {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const index = $this.index();

            $panelsFilter.removeClass('show');

            if ($this.hasClass('active')) {
                self.bodyUnlock();
                $this.removeClass('active');
            } else {
                self.bodyLock();
                $labelsFilter.removeClass('active');
                $this.addClass('active');
                $panelsFilter.eq(index).addClass('show');
            }
        });

        // 面板下拉筛选
        $dealsFilterList.on('tap', (e) => {
            e.preventDefault();
            const thatSef = $(e.currentTarget);
            const dataLink = thatSef.data('link');
            const dataCode = thatSef.data('code');
            $hotSalelabel.text(dataCode);
            if (!thatSef.hasClass('select')) {
                $lodingBounce.addClass('on');
                thatSef.addClass('select').siblings('a').removeClass('select');
            }
            setTimeout(() => {
                window.location.href = dataLink;
                if ($lodingBounce.hasClass('on')) {
                    $lodingBounce.removeClass('on');
                }
            }, 1000);
        });

        // 面板遮罩层点击=>还原所有筛选下拉及关闭筛选面板
        $opacityWrap.on('tap', (e) => {
            self.bodyUnlock();
            $labelsFilter.removeClass('active');
            $panelsFilter.removeClass('show');
        });

        // 切换列表
        $operaItemX.on('tap', (e) => {
            const thatSef = $(e.currentTarget);
            loader.update();
            self.bodyUnlock();
            $labelsFilter.removeClass('active');
            $panelsFilter.removeClass('show');
            if (!thatSef.hasClass('icon-grid_small')) {
                const obj = { page: 'hotSale', type: 'horizontal' };
                window.sessionStorage.setItem(STORAGE_GOODSLIST_NODE, JSON.stringify(obj));

                $panelList.removeClass('gbGoodsItem_list_column');
                thatSef.addClass('icon-grid_small').removeClass('icon-grid_list_small');
            } else {
                const obj = { page: 'hotSale', type: 'vertical' };
                window.sessionStorage.setItem(STORAGE_GOODSLIST_NODE, JSON.stringify(obj));

                $panelList.addClass('gbGoodsItem_list_column');
                thatSef.addClass('icon-grid_list_small').removeClass('icon-grid_small');
            }
        });

        // 点击推荐商品保存当前推荐商品到session
        $recommendList.on('click', '.js-gbGoodsItem', () => {
            lsitPageRecom.save();
            const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            lsitPageRecom.historyReplace(scrollTop);
        });
    },

    // 锁定页面
    bodyLock() {
        $body.addClass('lock');
    },

    // 解锁页面
    bodyUnlock() {
        $body.removeClass('lock');
    },

    // banner轮播
    bannerSwiper() {
        if ($('.js-hotSaleSwiper').find('.swiper-slide').length > 1) {
            new Swiper('.js-hotSaleSwiper', {
                loop: true,
                width: window.innerWidth,
                autoplay: {
                    delay: 1500,
                    disableOnInteraction: false,
                },
                pagination: {
                    el: '.swiper-pagination',
                },
                lazy: {
                    loadPrevNext: true
                },
                on: {
                    resize() {
                        this.params.width = window.innerWidth;
                        this.update();
                    },
                },
            });
        }
    },

    // 获取url参数转换为对象
    getQueryStringControl(nextPageNumber) {
        const theRequest = {};
        const url = window.location.search;
        if (url.indexOf('?') !== -1) {
            const str = url.substr(1);
            const strs = str.split('&');
            for (let i = 0; i < strs.length; i += 1) {
                theRequest[strs[i].split('=')[0]] = decodeURIComponent(strs[i].split('=')[1]);
            }
        }
        theRequest.page = nextPageNumber;
        return theRequest;
    },

    // loding
    lodingBounce(time) {
        setTimeout(() => {
            if ($lodingBounce.hasClass('on')) {
                $lodingBounce.removeClass('on');
            }
        }, time);
    },

    // 加载loader
    initLoader() {
        const $that = this;
        // 获取数据参数
        const params = sendParams;

        // 分页数据加载
        try {
            loader = new Loader({
                viewMore: $viewMoreBox,
                auto: true,
                data() {
                    params.page += 1;

                    // 请求其它分类数据
                    return serviceHotSaleList.http({
                        params,
                        loading: false,
                    });
                },
                loadStart() {
                    // 开始加载新数据
                    $viewMoreBox.addClass('on');
                },
                loadSuccess(res) {
                    const data = res.data || {};
                    const listDate = data.goodsList;
                    const totalPage = data.totalPage;

                    if (+params.page === 1) {
                        lsitPageRecom.remove();
                    }

                    lsitPageRecom.set({
                        listDate,
                        totalPage
                    });

                    // 向当前分类容器追加数据
                    GoodsItem.init({
                        container: $panelList,
                        type: 5,
                        list: listDate,
                        append: true,
                    });
                    asyncPriceDiscount({
                        elementLists: $('.js-panelList').find('.js-asyncPrice'),
                        shopPriceClassName: '.gbGoodsItem_markPrice',
                    });

                    const goodsItem = $panelList.find('.gbGoodsItem');

                    // 广告条Banner
                    if (res.data.advertisement && res.data.advertisement.length > 0) {
                        res.data.advertisement.forEach((item) => {
                            goodsItem.eq(item.order).after(tempBanner({
                                data: res.data.advertisement,
                                pageBannerIndex: item.order,
                                pageBannerUrl: item.image_url,
                                pageBannerLink: item.image_link
                            }));
                        });
                    }

                    // 热搜词
                    if (res.data.keyword && res.data.keyword.length > 0) {
                        res.data.keyword.forEach((item) => {
                            goodsItem.eq(item.order).after(tempWord({
                                data: item.keywordList,
                                pageIndex: item.order
                            }));
                        });
                    }

                    // 更新评分
                    $that.updateScore();

                    // 更新货币
                    $that.updateCurrency($panelList);

                    // 加载数据结束（完成|没有更多啦）
                    if (params.page >= res.data.totalPage) {
                        loader.end();
                        $btnViewMore.text(trans('goodslist.no_more_tips'));
                        setTimeout(() => {
                            if ($viewMoreBox.hasClass('on')) {
                                $viewMoreBox.removeClass('on');
                            }
                        }, 1500);
                    }
                }
            });
        } catch (error) {
            // error...
        }
        return true;
    },

    // 下拉加载
    upFresh() {
        const scrollShow = () => {
            const $window = $(window);
            const $document = $(document);
            if ($window.scrollTop() + $window.height() > $document.height() - 50) {
                this.initLoader();
            }
        };
        PubSub.subscribe('nativeScroll', throttle(scrollShow, 300, 300));
    },

    // 更新货币
    updateCurrency(containerClass) {
        PubSub.publish('sysUpdateCurrency', {
            context: containerClass[0]
        });
    },

    // 更新评分render
    updateScore() {
        if ($rateCounte && $rateCounte.length > 0) {
            $rateCounte.star();
        }
    },

    // top
    backToTop(time) {
        time = time || 300;
        let scrollTopTimer = null;
        const speed = Math.ceil(this.getPageScrollY() / (time / 10));
        clearInterval(scrollTopTimer);
        scrollTopTimer = setInterval(() => {
            const beforeTop = this.getPageScrollY();
            if (beforeTop > 0) {
                if (beforeTop <= speed) {
                    this.getPageScrollY(0);
                } else {
                    const resultTop = beforeTop - speed;
                    this.getPageScrollY(resultTop);
                }
            } else {
                clearInterval(scrollTopTimer);
            }
        }, 20);
    },

    getPageScrollY(top) {
        if (top || Number(top) === 0) { // 设置垂直滚动值
            if (window.pageYOffset) {
                window.pageYOffset = Number(top);
            }
            if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
                document.documentElement.scrollTop = Number(top);
            }
            if (document.body) { // all other Explorers
                document.body.scrollTop = Number(top);
            }
            return true;
        } else if (top || Number(top) !== 0) {
            let yScroll = null;
            if (window.pageYOffset) {
                yScroll = window.pageYOffset;
            } else if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
                yScroll = document.documentElement.scrollTop;
            } else if (document.body) { // all other Explorers
                yScroll = document.body.scrollTop;
            }
            return yScroll;
        }
        return true;
    },

    initScrollTopfunControl() {
        const topBtn = $('.js-bottomTopBtn');
        const clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
        const scrollSubscribe = () => {
            const osTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
            if (typeof osTop !== typeof undefined && osTop !== false) {
                if (osTop >= clientHeight) {
                    topBtn.addClass('show');
                } else {
                    topBtn.removeClass('show');
                }
            }
        };
        PubSub.subscribe('nativeScroll', throttle(scrollSubscribe, 300));
        topBtn.on('click', (e) => {
            e.preventDefault();
            // this.backToTop(300);
            $(window).scrollTop(0);
        });
    },

    // 返回顶部
    initScrollTopControl() {
        let timer = null;
        let isTop = true;
        const topBtn = $('.js-bottomTopBtn');
        const clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
        PubSub.subscribe('nativeScroll', () => {
            const osTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
            if (typeof osTop !== typeof undefined && osTop !== false) {
                if (osTop >= clientHeight) {
                    topBtn.addClass('show');
                } else {
                    topBtn.removeClass('show');
                }
                if (!isTop) {
                    clearInterval(timer);
                }
                isTop = false;
            }
        });
        topBtn.on('click', () => {
            timer = setInterval(() => {
                const osTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
                const isSpeed = Math.ceil(osTop / 10);
                window.scrollTo(0, osTop - isSpeed);
                isTop = true;
                if (osTop === 0) {
                    clearInterval(timer);
                }
            }, 30);
        });
    }
};

hotSaleApp.init();
