import 'js/bootstrap';
import layer from 'layer';
import PubSub from 'pubsub-js';
import asyncPriceDiscount from 'js/core/goods/asyncPriceDiscount';
import { trans } from 'js/core/translate.js';
import { throttle } from 'js/utils';
import { serviceSearchListData } from 'js/service/search_list.js';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import searchTrack from 'js/track/define/cate_list.js';
import indexHeaderInfo from 'js/core/index/headerInfo';
import StateBuffer from 'js/utils/StateBuffer';
import { getScrollTop, getSelector, getSelectorAll } from 'common/js/utils/similarjQ';
import borderStopScroll from 'component/borderStopScroll';
import { layerShow } from 'component/toggleLayer/toggleLayer';
import GoodsItem from '../component/goods_item/goods_item.js';
import goodsDepoist from '../component/goods_item/goods_deposit.js';
import { applyFilter } from './cateListCommon';
import lsitPageRecom from '../../newIndex/common/js/listPageRecom';

/* 搜索分类页 */
import './cate_list.css';

/* 组件—————— start */

/* 面包屑 */
import crumbItemApp from '../component/crumb/crumb'; // check

/* 搜索分类排序 */
import appOrder from '../component/appOrder/appOrder'; // check

/* 服装品类提示 */
import appApparel from '../component/apparel/appApparel'; // check

/* 电子烟品类提示 */
import cateNoticeController from '../component/notice/notice'; // check

/* 返回顶部  */
import backTop from '../component/backTop/backTop';

/* Ship to */
import appCountry from '../component/appCountry/appCountry';

/* 活动标签筛选 */
import appLabel from '../component/appLabel/appLabel';

/* 分类折叠筛选 */
import foldBlock from '../component/foldBlock/foldBlock';

/* 组件—————— end */


/* 聚合筛选侧滑面板 */
import appSide from '../component/appSide/appSide'; // check


/* 组件—————— end */

const $listMainBox = $('.cateMain_listWrap');

const cateListCase = {
    init() {
        this.bindEvent();
    },
    // 筛选框关闭所有子弹框
    operationPanelControl() {
        $('.js-appSortCountry, .js-countryItem, .js-arrowleft').removeClass('on');

        $('.js-listView').each((index, item) => {
            $(item).removeClass('on').css('display', 'none');
        });
    },
    bindEvent() {
        $('.js-arrowleft').on('click', () => {
            this.operationPanelControl();
        });
        $('.js-componentCountry').on('click', 'a', (e) => {
            e.stopPropagation();
            this.operationPanelControl();
        });
        // onSale 選中
        $('.saleCheckbox').click((e) => {
            applyFilter.set({
                onSale: 1
            });
        });
        // 搜索分类
        $('.side_categoryText').click((e) => {
            const $cate = $(e.currentTarget);
            applyFilter.set({
                catAttr: $cate.data('childId')
            });
        });
        // 分类 size和style属性
        $('.cate_childreItem').on('click', '.js-cateCheckbox', (e) => {
            const $this = $(e.currentTarget);
            applyFilter.set({
                attr: $this.data('order')
            });
        });

        // 筛选确认
        $('.js-applyBtn').click((e) => {
            applyFilter.get();
        });
        // 筛选取消
        $('.js-resetBtn').click(() => {
            applyFilter.get({ clear: true });
        });
        // 阻止侧边栏滚动
        borderStopScroll({
            wrapEle: getSelector('.side_listView')
        });
        borderStopScroll({
            wrapEle: getSelector('.js-countryItem')
        });
        getSelectorAll('.js-listView').forEach((ele) => {
            borderStopScroll({
                wrapEle: ele
            });
        });
    }
};

cateListCase.init();

const cateItemApp = {
    this: this,
    recShowMoreBtn: $('.js-showMoreBtn'),
    listMenuSelect: $('.js-listMenu'),
    iconArrowBack: $('.js-arrowleft'),
    labelCheckBoxBtn: $('.js-labelCheckbox'),
    sideCheckBoxBtn: $('.js-cateCheckbox'),
    searchInput: $('.js-searchInput'),
    searchBtn: $('.js-searchBtn'),
    searchKeyInput: $('.js-searchKeyInput'),
    seachFormBtn: $('.js-seachFormBtn'),
    cateListWrap: $('.js-catelistWrap'),
    cateShowMoreBtn: $('.js-cateShowMoreBtn'),
    relatedSearchBtn: $('.js-related-searches-dt'),
    recommendList: $('.cateMain_listWrap .js-catelistWrap'),
    init() {

        const castListType = $('input[name=track-infor]').data('track-type') || '';
        if (castListType) {
            const type = 2;
            const renderResult = lsitPageRecom.pageShow(type);
            if (renderResult) {
                this.cateShowMoreBtn.data('nextpage', +renderResult.page + 1);
                // 加载数据结束（完成|没有更多啦）
                if (renderResult.page >= renderResult.totalPage) {
                    this.cateShowMoreBtn.hide();
                }
            }

            // 点击推荐商品保存当前推荐商品到session
            this.recommendList.on('click', '.js-gbGoodsItem', () => {
                lsitPageRecom.save();
                const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
                lsitPageRecom.historyReplace(scrollTop);
            });
        }

        // 为第一页商品项记录页码
        this.recordPageForEachItem(1);

        this.cateRecomMoreControl();
        this.cateSelectControl();
        this.asideCheckBoxState();
        this.labelSelectControl();
        this.searchKeyWordControl();
        this.cateShowMoreControl();
        this.cateWidscrollControl();
        this.relatedSearchControl();
        this.searchFormKeyWordControl();
        // 获取分类ID，用于跳转到首页
        this.getCateId();
    },
    // 查看分类 (暂时隐藏)
    cateRecomMoreControl() {
        const that = this;
        that.recShowMoreBtn.on('click', function seeMore() {
            const thatSef = $(this);
            const listWrap = thatSef.closest('p').prev();
            listWrap.toggleClass('on');

            if (listWrap.hasClass('on')) {
                thatSef.addClass('on').data('node', 'show')
                    .html(`${trans('goodslist.search_see_less')} <i class="icon-arrow_down font-24"></i>`);
                PubSub.publish('sysUpdateLazyload'); // 让隐藏的图片加载出来
            } else {
                thatSef.removeClass('on').data('node', 'hide')
                    .html(`${trans('goodslist.search_see_more')} <i class="icon-arrow_down font-24"></i>`);
            }
        });
    },
    // 排序置顶
    cateWidscrollControl() {
        const $goodsBox = $('.js-goodsBox');
        if ($goodsBox.length) {
            const cateMainState = new StateBuffer('static');
            const goodsBoxHeight = $goodsBox.offset().top;
            const floorWrap = $('.cateMain_filter');
            const scrollNavShow = () => {
                if (getScrollTop() >= goodsBoxHeight) {
                    cateMainState.on('fixed', () => {
                        floorWrap.addClass('fixedX');
                        setTimeout(() => {
                            floorWrap.addClass('fixed');
                        }, 50);
                    });
                } else {
                    cateMainState.on('static', () => {
                        floorWrap.removeClass('fixedX fixed');
                    });
                }
            };
            PubSub.subscribe('nativeScroll', throttle(scrollNavShow, 100));
        }
    },
    // 筛选弹框二级显示隐藏
    cateSelectControl() {
        const that = this;
        that.listMenuSelect.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            $('.js-listView').removeClass('on').css('display', 'none');
            const thatChild = thatSef.find('.js-listView');
            if (thatChild.length > 0) {
                layerShow(thatChild, 'on');
                $('.js-arrowleft').addClass('on');
            }
        });
        $('.js-listView').click((e) => {
            e.stopPropagation();
        });
    },
    // 所有选项选中
    asideCheckBoxState() {
        const that = this;
        that.sideCheckBoxBtn.on('click', (e) => {
            $(e.currentTarget).toggleClass('on');
        });
    },
    // 推荐热搜词折叠
    relatedSearchControl() {
        const that = this;
        that.relatedSearchBtn.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            const thatParent = thatSef.closest('.related-searches');
            if (!thatParent.hasClass('down')) {
                thatParent.addClass('down').attr('data-rel', 1);
            } else {
                thatParent.removeClass('down').attr('data-rel', 0);
            }
        });
    },
    // 筛选弹框活动标签
    labelSelectControl() {
        const that = this;
        that.labelCheckBoxBtn.on('click', (e) => {
            e.preventDefault();
            const thatSef = $(e.currentTarget);
            thatSef.toggleClass('on');
            applyFilter.set({
                serverMarkValues: thatSef.data('key')
            });
        });
    },
    /* eslint-disable no-useless-escape */
    searchFilterControl(kwVal) {
        kwVal = kwVal.replace(/\*/g, '~~');
        kwVal = kwVal.replace(/\|/g, ']]');
        kwVal = kwVal.replace(/\=/g, '((');
        kwVal = kwVal.replace(/\"/g, ' ');
        kwVal = kwVal.replace(/\</g, '))');
        kwVal = kwVal.replace(/\>/g, ')))');
        kwVal = kwVal.replace(/\?/g, '!!!');
        kwVal = kwVal.replace(/\+/g, '__');
        kwVal = kwVal.replace(/\-/g, '^^');
        kwVal = kwVal.replace(/\//g, '..');
        kwVal = kwVal.replace(/\\/g, '...');
        kwVal = kwVal.replace(/\%/g, '!!');
        kwVal = kwVal.replace(/\#/g, '~~~');
        kwVal = kwVal.replace(/\>/g, '___');
        kwVal = kwVal.replace(/\</g, '^^^');
        kwVal = kwVal.replace(/\"/g, '[[');
        kwVal = kwVal.replace(/\$/g, '[[[');
        kwVal = kwVal.replace(/\@/g, ' ');
        kwVal = kwVal.replace(/\s+/g, '-');
        return encodeURIComponent(kwVal);
    },
    // 搜索纠错 页面有个输入框搜索
    searchKeyWordControl() {
        const that = this;
        that.searchBtn.on('click', () => {
            const searchInputVal = $.trim(that.searchInput.val());
            const searchKeyUrl = GLOBAL.DOMAIN_MAIN;
            if (searchInputVal === '' || searchInputVal === 'Search by Keyword, SKU # or Item #') {
                layer.msg(trans('goodslist.search_empty_tips'));
            } else {
                window.location.href = `${searchKeyUrl}/${that.searchFilterControl(searchInputVal)}-_gear/`;
            }
        });
    },
    // 获取URL参数，列表翻页参数
    getSearchObjControl(nextPageNumber) {
        const qs = window.location.search.length > 0 ? window.location.search.substr(1) : '';
        const args = {};
        const items = qs.length > 0 ? qs.split('&') : [];
        let item = null;
        let name = null;
        let value = null;
        const len = items.length;
        for (let i = 0; i < len; i += 1) {
            item = items[i].split('=');
            name = decodeURIComponent(item[0]);
            value = decodeURIComponent(item[1]);

            if (name.length) {
                args[name] = value;
            }
        }
        // args['{page}'] = nextPageNumber;
        args.page = nextPageNumber;
        return args;
    },
    // fix埋点
    getSearchPageTypeControl(type) {
        const itemColumn = $('.gbGoodsItem');
        const itemLikedX = $('.gbGoodsItem_like');
        if (itemColumn && itemColumn.length > 0) {
            itemColumn.each((index, item) => {
                const tahtSef = $(item);
                if (type === 'search') {
                    if (!tahtSef.hasClass('js-trackSearchGoodsItem') || !tahtSef.find(itemLikedX).hasClass('js-trackSearchCollect')) {
                        tahtSef.addClass('js-trackSearchGoodsItem').removeClass('js-trackGoodsItem');
                        tahtSef.find(itemLikedX).addClass('js-trackSearchCollect').removeClass('js-trackCollect');
                    }
                } else if (type === 'category') {
                    if (!tahtSef.hasClass('js-trackGoodsItem') || !tahtSef.find(itemLikedX).hasClass('js-trackGoodsItem')) {
                        tahtSef.addClass('js-trackGoodsItem');
                        tahtSef.find(itemLikedX).addClass('js-trackCollect');
                    }
                }
            });
        }
    },
    // 列表翻页查看更多
    cateShowMoreControl() {
        let nextPage = Number(this.cateShowMoreBtn.attr('data-nextpage'));
        const lastPage = Number(this.cateShowMoreBtn.attr('data-lastpage'));
        const cateCode = this.cateShowMoreBtn.attr('data-pagetype');
        asyncPriceDiscount({
            elementLists: this.cateListWrap.find('.js-asyncPrice'),
            shopPriceClassName: '.gbGoodsItem_markPrice'
        });
        this.cateShowMoreBtn.on('click', async (e) => {
            const tahtSef = $(e.currentTarget);
            const SearchObj = this.getSearchObjControl(nextPage);
            const res = await serviceSearchListData.http({
                errorPop: false,
                params: SearchObj
            });
            if (+res.status === 0) {
                nextPage += 1;
                if (nextPage >= lastPage) tahtSef.hide();
                if (res.data && res.data.length > 0) {

                    const listDate = res.data;
                    const totalPage = lastPage;

                    if (nextPage === 1) {
                        lsitPageRecom.remove();
                    }

                    lsitPageRecom.set({
                        listDate,
                        totalPage
                    });

                    GoodsItem.init({
                        container: this.cateListWrap,
                        type: 2,
                        list: res.data,
                        append: true,
                    });

                    // 为新增的项记录页面码
                    this.recordPageForEachItem(nextPage - 1);

                    asyncPriceDiscount({
                        elementLists: this.cateListWrap.find('.js-asyncPrice').slice(-res.data.length),
                        shopPriceClassName: '.gbGoodsItem_markPrice'
                    });
                    // 定金膨胀优化
                    goodsDepoist.init();
                    this.getSearchPageTypeControl(cateCode);
                    // 大数据埋点
                    res.data.forEach((item) => {
                        try {
                            window.TrackData[`${item.goodsSn}_${item.wareCode}`] = {
                                pam: 1,
                                pc: item.pc || '',
                                k: item.wareCode,
                            };
                        } catch (error) {
                            // throw new Error
                        }
                    });
                }
                tahtSef.data('nextpage', nextPage);
            } else {
                layer.msg(res.msg);
            }
        });
    },
    // 搜索纠错 页面有个输入框搜索
    searchFormKeyWordControl() {
        const that = this;
        that.seachFormBtn.on('click', () => {
            const searchKeyInputVal = $.trim(that.searchKeyInput.val());
            const searchKeyUrl = GLOBAL.DOMAIN_MAIN;
            if (searchKeyInputVal === '' || searchKeyInputVal === 'Search by Keyword, SKU # or Item #') {
                layer.msg(trans('goodslist.search_empty_tips'));
            } else {
                window.location.href = `${searchKeyUrl}/${that.searchFilterControl(searchKeyInputVal)}-_gear/`;
            }
        });
    },
    // 跳转首页判断馆区
    getCateId() {
        try {
            const catId = window.location.pathname.split('c_')[1].match(/\d+/)[0];
            indexHeaderInfo.setCateId(catId);
        } catch (e) {
            // no
        }
    },

    // 为每个商品项记录所在page
    recordPageForEachItem(page) {
        this.cateListWrap.find('.js-gbGoodsItem').each((index, item) => {
            if (typeof item.dataset.recodePage === 'undefined') {
                item.dataset.recodePage = page;
            }
        });
    }
};

cateItemApp.init();

PubSub.subscribe('nativeReady', () => {
    // 活动标筛选项
    appLabel.init();
    // 筛选排序
    appOrder.init();
    appSide.init();
    // 返回顶部
    backTop.init();
});

PubSub.subscribe('nativeLoad', () => {
    /* 搜索分类列表大数据埋点 */
    searchTrack();
    // 面包屑
    crumbItemApp.init();
    // 分类折叠筛选
    foldBlock.init();
    // 电子烟品类提示
    cateNoticeController.init();
    // 服装品类提示
    appApparel.init();
    // Ship to
    appCountry.init();
    // 初始化公共橱窗组件
    GoodsItem.init({
        container: $listMainBox,
    });

    goodsDepoist.init();
});

