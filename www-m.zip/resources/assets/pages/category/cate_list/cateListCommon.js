import { getUrlQuery } from 'js/utils';
import { toFixed } from 'js/core/currency';

class ApplyFilter {
    param = {
        serverMarkValues: new Set(),
        onSale: 0,
        country: 0,
        priceMin: 0,
        priceMax: 0,
        catAttr: new Set(),
        attr: new Map(),
    };
    init() {
        const currentUrl = window.location.href;
        const currentUrlQuery = getUrlQuery(currentUrl);
        if (currentUrlQuery.serverMarkValues) {
            this.param.serverMarkValues = new Set((currentUrlQuery.serverMarkValues).split(','));
        }
        this.param.onSale = currentUrlQuery.on_sale ? 1 : 0;
        this.param.country = currentUrlQuery.country ? currentUrlQuery.country : '';
        this.param.priceMin = currentUrlQuery.price_min ? currentUrlQuery.price_min : 0;
        this.param.priceMax = currentUrlQuery.price_max ? currentUrlQuery.price_max : 0;

        if (currentUrlQuery.cat_attr) {
            const catAttrStr = currentUrlQuery.cat_attr.split(',');
            this.param.catAttr = new Set(catAttrStr);
            catAttrStr.forEach((value) => {
                const $childCatAttr = $(`[data-child-id="${value}"]`);
                if ($childCatAttr.length) $childCatAttr.children('[type=checkbox]').attr('checked', 'checked');
            });
        }

        const attrStr = currentUrlQuery.attr;
        if (attrStr) {
            const attrList = attrStr.split('__');
            attrList.forEach((attrListItem) => {
                const family = attrListItem.split('-');
                family[1].split('_').forEach((child) => {
                    this.set({
                        attr: `${family[0]}-${child}`
                    });
                    const $checkedOrder = $(`[data-order="${family[0]}-${child}"]`);
                    if ($checkedOrder.length) $checkedOrder.children('[type=checkbox]').attr('checked', 'checked');
                });
            });
        }
    }
    get({ clear = false } = {}) {
        const {
            onSale,
            country,
            catAttr,
            attr,
        } = this.param;
        let {
            serverMarkValues,
            priceMin,
            priceMax,
        } = this.param;
        const resultJoin = [];
        serverMarkValues = [...serverMarkValues].join(',');
        const catAttrTemp = [...catAttr].join(',');
        const attrCombi = [...attr];
        let attrTemp = [];
        attrCombi.forEach((value) => {
            if (value[1].size) attrTemp.push(`${value[0]}-${[...value[1]].join('_')}`);
        });
        attrTemp = attrTemp.join('__');

        const { hostname, pathname, search } = window.location;
        const urlParam = this.deleteSearch(search);

        if (!clear) {
            if (serverMarkValues.length) resultJoin.push(`serverMarkValues=${serverMarkValues}`);
            if (onSale) resultJoin.push(`on_sale=${onSale}`);
            if (country) resultJoin.push(`country=${country}`);
            if (priceMin > priceMax) [priceMin, priceMax] = [priceMax, priceMin];
            if (priceMin) resultJoin.push(`price_min=${toFixed(priceMin, 4, 1)}`);
            if (priceMax) resultJoin.push(`price_max=${toFixed(priceMax, 4, 1)}`);
            if (catAttrTemp) resultJoin.push(`cat_attr=${catAttrTemp}`);
            if (attrTemp) resultJoin.push(`attr=${attrTemp}`);
        }
        window.location.href = `//${hostname}${pathname}${urlParam}${resultJoin.join('&')}`;
    }
    set({
        serverMarkValues = '',
        onSale = 0, // on_sale
        country = '',
        priceMin = '', // price_min
        priceMax = '', // price_max
        catAttr = 0, // cat_attr
        attr = '',
    } = {}) {
        if (serverMarkValues) {
            const strServerMarkValues = String(serverMarkValues);
            if (this.param.serverMarkValues.has(strServerMarkValues)) this.param.serverMarkValues.delete(strServerMarkValues);
            else this.param.serverMarkValues.add(strServerMarkValues);
        }
        if (onSale) {
            this.param.onSale = this.param.onSale ? 0 : 1;
        }

        if (country) {
            this.param.country = country;
        }

        if (priceMin !== '') {
            this.param.priceMin = priceMin;
        }

        if (priceMax !== '') {
            this.param.priceMax = priceMax;
        }

        if (catAttr) {
            const catAttrStr = String(catAttr);
            if (this.param.catAttr.has(catAttrStr)) this.param.catAttr.delete(catAttrStr);
            else this.param.catAttr.add(catAttrStr);
        }

        if (attr) {
            const attrArr = attr.split('-');
            const currentAttr = this.param.attr.get(attrArr[0]);
            if (currentAttr) {
                if (currentAttr.has(attrArr[1])) currentAttr.delete(attrArr[1]);
                else currentAttr.add(attrArr[1]);
            } else {
                this.param.attr.set(attrArr[0], new Set([attrArr[1]]));
            }
        }
    }
    deleteSearch(search) {
        const str = search.replace('?', '');
        let paramMap = [];
        if (str) {
            const searchArr = str.split('&');
            if (searchArr.length) {
                const searchObj = {};
                searchArr.forEach((value) => {
                    const unitParam = value.split('=');
                    searchObj[unitParam[0]] = unitParam[1];
                });
                const poolProp = ['serverMarkValues', 'on_sale', 'country', 'price_min', 'price_max', 'cat_attr', 'attr'];
                poolProp.forEach((value) => {
                    delete searchObj[value];
                });
                paramMap = Object.entries(searchObj).map(value => value.join('='));
            }
        }
        return paramMap.length ? `?${paramMap.join('&')}&` : '?';
    }
}
const applyFilter = new ApplyFilter();
applyFilter.init();

export { applyFilter };
