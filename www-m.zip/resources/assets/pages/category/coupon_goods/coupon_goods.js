import PubSub from 'pubsub-js';
import { getCurrency, toFixed, multiply, divide } from 'js/core/currency';
import { trans } from 'js/core/translate.js';
import { serviceCouponGoodsList } from 'js/service/search_list.js';
import layer from 'layer';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import 'js/bootstrap.js';
import './coupon_goods.css';

const couponPageApp = {
    $point: $('.js-point'),
    $body: $('body'),
    $filterContent: $('.js-filterContent'),
    $filterSelect: $('.js-filterSelect'),
    $filterPrice: $('.couponMain_filterPrice'),
    $refine: $('.js-refine'),
    $unit: $('.couponMain_unit'),
    $lowPrice: $('.js-lowPrice'),
    $highPrice: $('.js-highPrice'),
    $reset: $('.js-reset'),
    $apply: $('.js-apply'),
    $viewMore: $('.js-couponViewMore'),
    $goodsList: $('.js-goodsList'),
    $goBack: $('.js-goBack'),
    page: 1,
    init() {
        this.transformControl();
        this.selectFilter();
        this.selectFilterPrice();
        this.addCart();
        this.cateScrollTopControl();
        this.couponUnitPrice();
        this.priceCalculate();
        this.viewMore();
        this.goBack();
    },
    selectFilter() {
        this.$point.click((e) => {
            const $target = $(e.currentTarget);
            const index = $target.index();
            this.$filterSelect.eq(index).addClass('show').siblings('.js-filterSelect').removeClass('show');
            if ($target.hasClass('on')) {
                $target.removeClass('on');
                this.$body.removeClass('modalOpenX');
            } else {
                $target.addClass('on').siblings('.js-point').removeClass('on');
                this.$body.addClass('modalOpenX');
            }
        });
        this.$refine.click(() => {
            this.$filterPrice.addClass('active');
        });
    },
    selectFilterPrice() {
        $('.js-filterClose').click(() => {
            this.$filterPrice.removeClass('active');

        });
    },
    async couponUnitPrice() {
        const { currencySign, currencyRate } = await getCurrency();
        if (this.$unit.text() === '') {
            this.$unit.text(currencySign);
            if (this.$lowPrice.data('range')) {
                this.$lowPrice.val(toFixed(multiply(this.$lowPrice.data('range'), currencyRate), 2));
            }
            if (this.$highPrice.data('range')) {
                this.$highPrice.val(toFixed(multiply(this.$highPrice.data('range'), currencyRate), 2));
            }
        }
    },
    async transformControl() {
        const that = this;
        PubSub.subscribe('sysUpdateCurrency', async () => {
            const { currencySign, currencyRate } = await getCurrency();
            that.$unit.text(currencySign);
            if (this.$lowPrice.data('range')) {
                this.$lowPrice.val(toFixed(multiply(this.$lowPrice.data('range'), currencyRate), 2));
            }
            if (this.$highPrice.data('range')) {
                this.$highPrice.val(toFixed(multiply(this.$highPrice.data('range'), currencyRate), 2));
            }
        });
    },
    async viewMore() {
        if (!this.$viewMore.length) {
            return false;
        }
        this.maxPage = this.$viewMore.data('maxpage');
        this.$viewMore.click(async () => {
            const currentUrl = window.location.href;
            const reg = /page=\d+/;
            this.page += 1;
            let requestUrl;
            if (reg.test(currentUrl)) {
                requestUrl = currentUrl.replace(reg, $0 => `page=${this.page}`);
            } else {
                requestUrl = `${currentUrl}&page=${this.page}`;
            }
            await this.serviceCouponViewMore(requestUrl);
            if (this.page >= this.maxPage) {
                this.$viewMore.css('display', 'none');
            }
        });
        return true;
    },
    priceCalculate() {
        this.$apply.click(async () => {
            const { currencyRate } = await getCurrency();
            const minValNum = Number(this.$lowPrice.val());
            const maxValNum = Number(this.$highPrice.val());
            if (Number.isNaN(minValNum) || Number.isNaN(maxValNum)) {
                return layer.msg(trans('goodslist.coupon_valild_price_range'));
            }
            const minPriceVal = Number(toFixed(divide(minValNum, currencyRate), 2, 1));
            const maxPriceVal = Number(toFixed(divide(maxValNum, currencyRate), 2, 1));
            if (minPriceVal >= 0 && maxPriceVal >= 0 && minPriceVal <= maxPriceVal) {
                const reg = /(price-area=)(([0-9]+\.?[0-9]*)_([0-9]+\.?[0-9]*))?/;
                const currentUrl = window.location.href;
                if (reg.test(currentUrl)) {
                    let currentNewUrl;
                    if (!this.$lowPrice.val() && !this.$highPrice.val()) {
                        currentNewUrl = currentUrl.replace(reg, ($0, $1, $2) => 'price-area=');
                    } else {
                        currentNewUrl = currentUrl.replace(reg, ($0, $1, $2) => `price-area=${minPriceVal}_${maxPriceVal}`);
                    }
                    window.location.href = currentNewUrl;
                } else {
                    window.location.href = `${currentUrl}&price-area=${minPriceVal}_${maxPriceVal}`;
                }
            } else {
                layer.msg(trans('goodslist.coupon_valild_price_range'));
            }
            return true;
        });
        this.$reset.click(() => {
            this.$lowPrice.val('');
            this.$highPrice.val('');
        });
    },
    async serviceCouponViewMore(url) {
        const res = await serviceCouponGoodsList.http({
            url
        });
        if (+res.status === 0) {
            const temp = await import('./component/goods_item.art');
            const html = temp({
                list: res.data
            });
            this.$goodsList.append(html);
            PubSub.publish('sysUpdateCurrency', {
                context: this.$goodsList[0]
            });
            this.addCart();
        }
    },
    addCart() {
        $('.js-addToCart').click((e) => {
            const { goodsSn, warehouseCode, qty } = e.currentTarget.dataset;
            PubSub.publish('sysAddToCart', {
                goods: {
                    goodsSn,
                    warehouseCode,
                    qty,
                }
            });
        });
    },
    cateScrollTopControl() {
        const topBtn = $('.js-bottomTopBtn');
        const clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
        PubSub.subscribe('nativeScroll', () => {
            const osTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
            if (typeof osTop !== typeof undefined && osTop !== false) {
                if (osTop >= clientHeight) {
                    topBtn.addClass('show');
                } else {
                    topBtn.removeClass('show');
                }
            }
        });
        topBtn.on('click', () => {
            $(window).scrollTop(0);
        });
    },
    goBack() {
        this.$goBack.click(() => {
            window.history.back();
        });
    }
};

couponPageApp.init();
