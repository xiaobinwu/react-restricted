/**
 * 价格筛选
 */

import { getCurrency, divide, transform, toFixed } from 'js/core/currency.js';
import { applyFilter } from '../../../cate_list/cateListCommon';
import './definePrice.css';

class DefinePrice {
    $minInputCurrency = $('.js-minPrice');
    $maxInputCurrency = $('.js-maxPrice');
    $currencySign = $('.js-currencySign');
    // 监听输入框
    trigger() {
        this.$minInputCurrency.on('input', (e) => {
            this.setUSD('min', $(e.target));
        });
        this.$maxInputCurrency.on('input', (e) => {
            this.setUSD('max', $(e.target));
        });
    }
    // 初始化输入框
    async init(min = parseFloat(this.$minInputCurrency.data('currency')), max = parseFloat(this.$maxInputCurrency.data('currency'))) {
        const minPrice = min ? transform({ price: toFixed(min, 5), round: 1 }) : '';
        const maxPrice = max ? transform({ price: toFixed(max, 5), round: 1 }) : '';

        this.$minInputCurrency.val(minPrice);
        this.$maxInputCurrency.val(maxPrice);
        getCurrency().then((data) => {
            this.$currencySign.html(data.currencySign);
        });
    }

    // 获取输入框 美元
    async setUSD(item = 'min', $target) {
        const currentCurrency = await getCurrency();
        const inputVal = $target.val().trim();
        $target.val(inputVal.replace(/[^\d.]/g, '')); // 只输入数字
        if (item === 'min') {
            const min = divide(this.$minInputCurrency.val().trim(), currentCurrency.currencyRate);
            this.$minInputCurrency.data('currency', min);
            applyFilter.set({
                priceMin: min
            });
        } else {
            const max = divide(this.$maxInputCurrency.val().trim(), currentCurrency.currencyRate);
            this.$maxInputCurrency.data('currency', max);
            applyFilter.set({
                priceMax: max
            });
        }
    }

}

export default new DefinePrice();
