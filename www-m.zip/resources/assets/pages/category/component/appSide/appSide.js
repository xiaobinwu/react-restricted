/*
* 筛选框显示隐藏&&价格筛选功能
* */

import { layerShow, layerHide } from 'component/toggleLayer/toggleLayer';
import definePrice from './definePrice/definePrice';
import AppOrder from '../appOrder/appOrder';
import './appSide.css';


const appSide = {
    refineBoxSelect: $('.js-refine'),
    sideMakeBox: $('.js-sideMake, .js-closeBtn'),
    sideContainer: $('.js-sideContainer'),

    init() {
        this.bindEvent();
        definePrice.trigger();
    },

    bindEvent() {
        // 显示弹框
        this.refineBoxSelect.on('click', async (e) => {
            if (this.sideContainer.length) {
                definePrice.init();
                this.showSlideControl();
                AppOrder.close();
            }
        });

        // 隐藏弹框
        this.sideMakeBox.on('click', (e) => {
            this.hideSlideContainer();
        });

        // lable里面嵌套input，点击label会触发两次click。
        this.sideContainer.find('[type=checkbox]').click((e) => {
            e.stopPropagation();
        });
    },

    showSlideControl(self) {
        this.refineBoxSelect.addClass('on');
        layerShow(this.sideContainer, 'on');
    },

    hideSlideContainer() {
        this.refineBoxSelect.removeClass('on');
        $('.js-listView.on').removeClass('on');
        layerHide(this.sideContainer, 'on');
        this.hideControl();
    },

    hideControl() {
        const $iconBack = $('.js-arrowleft');
        const $countryItemWrap = $('.js-countryItem');
        const $appSortCountry = $('.js-appSortCountry');

        if ($countryItemWrap.hasClass('on')) {
            $iconBack.removeClass('on');
            $countryItemWrap.removeClass('on');
            $appSortCountry.removeClass('on');
        }
    },
};

export default appSide;
