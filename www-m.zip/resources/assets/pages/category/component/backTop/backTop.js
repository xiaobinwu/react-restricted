/*
* 返回顶部
* */
import PubSub from 'pubsub-js';
import { throttle } from 'js/utils';
import './backTop.css';

const backTop = {
    init() {
        this.initScrollTopControl();
    },

    getPageScrollY(top) {
        if (top || Number(top) === 0) { // 设置垂直滚动值
            if (window.pageYOffset) {
                window.pageYOffset = Number(top);
            }
            if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
                document.documentElement.scrollTop = Number(top);
            }
            if (document.body) { // all other Explorers
                document.body.scrollTop = Number(top);
            }
            return true;
        } else if (top || Number(top) !== 0) {
            let yScroll = null;
            if (window.pageYOffset) {
                yScroll = window.pageYOffset;
            } else if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
                yScroll = document.documentElement.scrollTop;
            } else if (document.body) { // all other Explorers
                yScroll = document.body.scrollTop;
            }
            return yScroll;
        }
        return true;
    },

    initScrollTopControl() {
        const topBtn = $('.js-bottomTopBtn');
        const clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
        const scrollSubscribe = () => {
            const osTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
            if (typeof osTop !== typeof undefined && osTop !== false) {
                if (osTop >= clientHeight) {
                    topBtn.addClass('show');
                } else {
                    topBtn.removeClass('show');
                }
            }
        };
        PubSub.subscribe('nativeScroll', throttle(scrollSubscribe, 300));
        topBtn.on('click', (e) => {
            e.preventDefault();
            $(window).scrollTop(0);
        });
    },
};

export default backTop;
