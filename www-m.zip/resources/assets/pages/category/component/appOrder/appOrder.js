/*
* 页面导航条排序
* */

import borderStopScroll from 'component/borderStopScroll';
import { getSelector } from 'js/utils/similarjQ';
import './appOrder.css';

class AppOrder {
    $treding = $('.js-treding');
    $tredingList = $('.js-tredingList');
    $opacityWrap = $('.js-opacityWrap');
    isShow = false;
    init() {

        this.$treding.on('tap', (e) => {
            e.preventDefault();
            if (!this.isShow) this.open();
            else this.close();
        });
        this.$opacityWrap.on('tap', (e) => {
            this.close();
        });

        borderStopScroll({
            wrapEle: getSelector('.js-screenlist')
        });
    }
    open() {
        this.isShow = true;
        this.$treding.addClass('on');
        this.$tredingList.addClass('on');
    }
    close() {
        this.isShow = false;
        this.$treding.removeClass('on');
        this.$tredingList.removeClass('on');
    }
}

export default new AppOrder();
