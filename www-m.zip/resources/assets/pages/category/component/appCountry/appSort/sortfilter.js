import './sortfilter.css';

const appSortController = {
    flexSort: $('.js-appSortCountry'),
    sideLetter: $('.js-sideLetter'),

    init(dataCountry) {
        this.sortDataControl(dataCountry);
        this.touchEventStart();
        this.touchEventEnd();
        this.touchEventMove();
    },

    sortDataControl(data) {
        // 右侧索引
        let str = '';
        data.forEach((value) => {
            str += `<a href="javascript:;" data-letter="${value.first}" class="font-24 side_anchor js-anchorJump">
                ${value.first} <i class="font-34 letter side_letter js-sideLetter"></i></a>`;
        });
        this.flexSort.html(str);
    },

    // 跳转锚点
    anchorJump(n) {
        try {
            const text = $(n).attr('data-letter');
            $(n).addClass('on').siblings('a').removeClass('on');
            if (text && text.length < 2) {
                $('.js-sideLetter').text(text);
                $('.js-sideLetter').css({
                    opacity: '1',
                    transform: 'scale(1)',
                    transition: 'transform .3s ease-in-out'
                });
                window.location.hash = `#${text}`;
            }
        } catch (error) {
            // error...
        }
    },

    // 触控点击
    touchEventStart() {
        $('.js-anchorJump').on('touchstart', (e) => {
            const target = $(e.currentTarget);
            // console.log(e);
            this.anchorJump(target);
        });
    },

    // 手指滑动
    touchEventMove() {
        // 获取开始点击的位置 每滑动一个a标签的高度切换一个锚点
        try {
            const elemFlexSort = document.querySelector('.js-appSortCountry');
            elemFlexSort.addEventListener('touchmove', (event) => {
                event.preventDefault();
                this.anchorJump(document.elementFromPoint(event.changedTouches[0].clientX, event.changedTouches[0].clientY));
            });
        } catch (error) {
            // error...
        }
    },

    // 滑动结束
    touchEventEnd() {
        const elem = document.querySelector('.js-appSortCountry');
        elem.addEventListener('touchend', () => {
            $('.side_anchor').removeClass('on');
        });
    },
};

export default appSortController;
