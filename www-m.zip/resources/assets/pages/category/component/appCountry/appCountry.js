/*
* ship to国家列表
* */
import layer from 'layer';
import { serviceGetCountryList } from 'js/service/search_list.js';
import appSort from './appSort/sortfilter.js';
import './appCountry.css';
import { applyFilter } from '../../cate_list/cateListCommon';

const $iconBack = $('.js-arrowleft');
const $appSortCountry = $('.js-appSortCountry');
const $countryItemWrap = $('.js-countryItem');
const $loadingCountry = $('.js-loadingOpacity');

const appCountry = {
    init() {
        this.selectCountryControl();
        this.selectCurrentCountry();
    },

    activeControl() {
        $iconBack.addClass('on');
        $appSortCountry.addClass('on');
        $countryItemWrap.addClass('on');
    },

    async getCountryControl() {
        const hotCountry = $('.js-hotCountry');
        const allCountry = $('.js-allCountry');
        $loadingCountry.addClass('on');
        const res = await serviceGetCountryList.http({
            errorPop: false
        });

        if (+res.status === 0) {
            $loadingCountry.removeClass('on');
            if (res.data.hotCountry && res.data.hotCountry.length) {
                const temp = await import('./template/hotCountry_tpl.art');
                hotCountry.html(temp({
                    data: res.data.hotCountry
                }));
            }
            if (res.data.allCountry && res.data.allCountry.length) {
                const temp = await import('./template/listCountry_tpl.art');
                allCountry.html(temp({
                    data: res.data.allCountry
                }));
                // 国家列表索引
                appSort.init(res.data.allCountry);
                $appSortCountry.addClass('on');
            }
        } else {
            layer.msg(res.msg);
            $loadingCountry.removeClass('on');
        }
    },

    selectCountryControl() {
        let isShow = false;
        $('.js-selectCountry').on('click', (e) => {
            if (!isShow) this.getCountryControl();
            isShow = true;
            this.activeControl();
        });
    },

    selectCurrentCountry() {
        const locationShipCountry = $('.js-locationShipCountry');
        $('.js-componentCountry').on('click', 'a', (e) => {
            e.stopPropagation();
            const thatSef = $(e.currentTarget);
            const dataCountryCode = thatSef.data('country-code');
            const dataCountry = thatSef.data('country');
            thatSef.addClass('on').siblings('a').removeClass('on');
            locationShipCountry.text(dataCountry);

            applyFilter.set({
                country: dataCountryCode
            });

        });
    },
};

export default appCountry;
