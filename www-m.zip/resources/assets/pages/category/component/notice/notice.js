/**
 * 电子烟品类提示
 */

import { STORAGE_IS_NOTICE } from 'js/variables';
import './notice.css';

const cateNoticeController = {
    $noticeCloseBtn: $('.js-noticeCloseBtn'),
    $noticeCateBox: $('.js-cateNoticeBox'),
    init() {
        this.bindEvent();
        this.setNoticeCookieHandle();
    },
    bindEvent() {
        this.$noticeCloseBtn.on('click', (e) => {
            this.$noticeCateBox.removeClass('on');
            localStorage.setItem(STORAGE_IS_NOTICE, +new Date());
        });
    },
    setNoticeCookieHandle() {
        if (this.$noticeCateBox.length) {
            const prevTime = localStorage.getItem(STORAGE_IS_NOTICE);
            const deffTime = +new Date() - prevTime;
            if (deffTime > 3 * 24 * 60 * 60 * 1000) this.$noticeCateBox.addClass('on');
        }
    },
};

export default cateNoticeController;
