import './appLabel.css';


/**
 * 列表页活动标签筛选项
 */

const appLabel = {
    init() {
        this.cateActiveTagControl();
    },

    recGetUrlParam(name) {
        const reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`);
        const str = window.location.search.substr(1).match(reg);
        if (str != null) return decodeURI(str[2]); return null;
    },

    cateActiveTagControl() {
        const $cateActiveBtn = $('.js-activeTagWrap');
        $cateActiveBtn.on('click', 'a', (e) => {
            const thatSef = $(e.currentTarget);
            const tagData = thatSef.data('node');
            const locationUrl = window.location.href;
            const indexOfString = locationUrl.indexOf('?') >= 0 ? '&' : '?';
            const isParamreplaceText = this.recGetUrlParam('tagValue');

            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
                const locationJump = locationUrl.indexOf('tagValue') >= 0 ? locationUrl
                    .replace(`tagValue=${isParamreplaceText}`, `tagValue=${tagData}`) : `${locationUrl}${indexOfString}tagValue=${tagData}`;
                window.location.href = locationJump;
            } else {
                thatSef.removeClass('on');
                const locationJumpx = locationUrl.indexOf('?tagValue=') >= 0 ? locationUrl
                    .replace(`?tagValue=${isParamreplaceText}`, '') : locationUrl.replace(`&tagValue=${isParamreplaceText}`, '');
                window.location.href = locationJumpx;
            }
        });
    },
};

export default appLabel;
