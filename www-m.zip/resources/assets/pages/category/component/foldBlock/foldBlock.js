/**
 * 搜索分类折叠选项
 */

import PubSub from 'pubsub-js';
import './foldBlock.css';

const foldBlock = {
    init() {
        this.foldBlockControl();
        this.documentClickControl();
        this.labelSelectChildControl();
    },

    foldBlockControl() {
        const $sideChildName = $('.js-sideChildName');
        $sideChildName.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            const thatParent = thatSef.parents('.js-searchList');

            if (thatParent.hasClass('on')) thatParent.removeClass('on');
            else thatParent.addClass('on');
            thatParent.siblings('.js-searchList').removeClass('on');
        });
    },

    labelSelectChildControl() {
        const $labelSelectBoxBtn = $('.js-saleCheckbox');
        $labelSelectBoxBtn.on('click', (e) => {
            e.stopPropagation();
            const extendAttr = [];
            const thatSef = $(e.currentTarget);
            thatSef.toggleClass('on');
            thatSef.closest('li.side_searchList').find('[data-child-id]').each((index, item) => {
                const thatVal = $(item);
                if (thatVal.hasClass('on')) {
                    extendAttr.unshift(thatVal.attr('data-child-name'));
                }
            });
            thatSef.parents('.side_searchList').find('em').text(extendAttr.join(','));
        });
    },

    documentClickControl() {
        PubSub.subscribe('nativeDocumentClick', (msg, e) => {
            const { target } = e;
            const $searchListOperat = $('.js-searchList');
            if ($searchListOperat.length > 0) {
                if (!$.contains($('.side_listItem')[0], target)) {
                    $searchListOperat.removeClass('on');
                }
            }
        });
    },
};

export default foldBlock;
