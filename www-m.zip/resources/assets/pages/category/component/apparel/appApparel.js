/*
* 服装品类提示
* */

import layer from 'layer';
import { STORAGE_APPAREL } from 'js/variables';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import './appApparel.css';

runtime.trans = trans;

const appApparel = {
    init() {
        this.renderlayerControl();
    },
    async layerControl() {
        const ageTemp = await import('./appApparel.art');
        layer.open({
            content: ageTemp(),
            area: '400px',
            btn: ['yes', 'no'],
            shadeClose: false,
            skin: 'apparelTemp_content',
            shade: 'background-color: rgba(0,0,0,.8)',
            yes: function layeYes(index) {
                layer.close(index);
                window.localStorage.setItem(STORAGE_APPAREL, 1);
            },
            no: function layeNo(index) {
                window.location.href = GLOBAL.DOMAIN_MAIN;
            }
        });
    },
    renderlayerControl() {
        const that = this;
        const apparelCode = window.localStorage.getItem(STORAGE_APPAREL);
        if (!apparelCode) {
            const linkAppareID = window.location.pathname.match(/c_([^/]*)/);
            const linkAppareArr = ['12181', '12182', '12183', '12184', '12185', '12186'];
            if (linkAppareID && linkAppareID[1]) {
                if (linkAppareArr.includes(linkAppareID[1])) that.layerControl();
            }
        }
    },
};

export default appApparel;
