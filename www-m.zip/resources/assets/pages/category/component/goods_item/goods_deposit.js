/**
 * 商品-是否预定时间范围不显示预定标
 */
const goodsDepoistControl = {
    init() {
        this.asyncGetdepoistControl();
    },
    asyncGetdepoistControl() {
        try {
            const nowTime = Math.floor((new Date()).getTime() / 1000);
            $('.js-depositExpired').each((index, item) => {
                const tahtSef = $(item);
                const startTime = tahtSef.data('start-time');
                const endTime = tahtSef.data('end-time');
                if (nowTime - startTime > 0 && endTime - nowTime > 0) {
                    tahtSef.addClass('on');
                }
            });
        } catch (error) {
            // error...
        }
    }
};

export default goodsDepoistControl;

