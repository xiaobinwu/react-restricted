/**
 * 面包屑
 */

import borderStopScroll from 'component/borderStopScroll';
import { getSelectorAll } from 'js/utils/similarjQ';
import AppOrder from '../appOrder/appOrder';
import './crumb.css';

const crumbItemApp = {
    init() {
        getSelectorAll('.cateMain_listBox').forEach((value) => {
            borderStopScroll({
                wrapEle: value
            });
        });
        this.cateItemControl();
    },
    cateItemControl() {
        const $breadBox = $('.js-catePopBox');
        const $breadItem = $('.cateMain_breadItem');
        const listBoxLen = $('.cateMain_listBox').length;
        const $breadWrap = $('.cateMain_allCatelist');
        const $breadArrow = $('.cateMain_breadItem-arrow');
        const itemLen = $breadItem.length;
        let itemArr = Array(itemLen).fill(0);
        let wheelBool = true;

        function closeOperator() {
            wheelBool = true;
            itemArr = Array(itemLen).fill(0);
            $breadBox.removeClass('on');
            AppOrder.close();
        }
        function openOperator($item, index) {
            wheelBool = false;
            $item.find('.cateMain_breadItem-arrow').addClass('on');
            $breadBox.addClass('on');
            AppOrder.close();
            itemArr = Array(itemLen).fill(0);
            itemArr[index] = 1;
            $breadWrap.css('transform', `translateX(-${(1 / itemLen) * index * 100}%)`);
        }
        $('.cateMain_breadItem').click((e) => {
            const $currentBreadItem = $(e.currentTarget);
            const index = $currentBreadItem.index();
            $breadArrow.removeClass('on');
            if (itemArr[index] === 1 || index >= listBoxLen) {
                closeOperator();
            } else {
                openOperator($currentBreadItem, index);
            }
        });

        $breadBox.click((e) => {
            const $target = $(e.currentTarget);
            if ($target.closest('.cateMain_allCatelist').length === 0) {
                $breadArrow.removeClass('on');
                closeOperator();
            }
        });

        if ($breadBox && $breadBox.length) {
            $breadBox[0].addEventListener('touchmove', (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        }

        // 禁止鼠标滚轮事件
        window.onmousewheel = scrollFunc;
        function scrollFunc() {
            return wheelBool;
        }
    },
};

export default crumbItemApp;

