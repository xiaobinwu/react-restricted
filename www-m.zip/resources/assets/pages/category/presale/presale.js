import PubSub from 'pubsub-js';
import 'js/bootstrap';
import { getUrlQuery } from 'js/utils';
import { servicePresalePage } from 'js/service/promotion';
import Timer from 'component/timer/timer.js';
// import 'js/lib/zepto/fx.js';
// import 'js/lib/zepto/fx_methodes.js';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
// 多语言相关
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';
import presaleTrack from 'js/track/define/presales.js';
import './presale.css';

/* 新品页数据曝光埋点 */
presaleTrack();

runtime.trans = trans;

const timer = new Timer();
PubSub.subscribe('nativeReady', () => {
    const cutTime = () => {
        timer.clean();
        // 活动已经开始商品的倒计时
        timer.add('.js-cutDown', {
            format(time) {
                return time < 24 * 60 * 60 ? '{hh}:{mm}:{ss}' : '{d} day(s) {hh}:{mm}:{ss}';
            },
            interval: 'end',
            onStart() {

            },
        });
    };
    cutTime();
    $('.dropList_btn').on('tap', (event) => {
        const $self = $(event.currentTarget);
        const $dropCon = $self.next('.dropListCon');
        $self.toggleClass('on');
        $dropCon.toggleClass('show');
    });
    let nextPage = 2;
    const queryParams = getUrlQuery();
    const $moreBtn = $('.js-viewMore');
    const pageTotal = +$moreBtn.attr('data-totalpage');
    const $targetRenderDom = $('.presaleContent_list');

    function checkMoreBtn() {
        if (nextPage > pageTotal) {
            $moreBtn.parent().hide();
        }
    }

    async function pageOver() {
        const resultTemp = await import('./artTpl/list.art');
        const { status, data } = await servicePresalePage.http({
            params: {
                cat_id: queryParams.cat_id || '',
                page: nextPage,
            },
        });

        if (status === 0) {
            $targetRenderDom.append(resultTemp({ data }));
            nextPage += 1;
            cutTime();
            checkMoreBtn();

            // 大数据埋点数据
            data.forEach((item) => {
                window.TrackData[`${item.goodsSn}_${item.wareCode}`] = {
                    k: item.wareCode,
                    pc: item.catId,
                    sku: item.goodsSn,
                    pam: 1
                };
            });
        }
    }

    $moreBtn.on('tap', () => {
        pageOver();
        if (nextPage <= pageTotal) {
            pageOver();
        }
    });

    checkMoreBtn();
});
