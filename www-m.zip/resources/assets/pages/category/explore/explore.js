import PubSub from 'pubsub-js';
import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';

import { trans } from 'js/core/translate.js';
import { throttle } from 'js/utils';
import { STORAGE_EXPLORE_NODE } from 'js/variables';
import { serviceExploreDealsList } from 'js/service/promotion';
import Loader from 'component/loader/loader';
import asyncPriceDiscount from 'js/core/goods/asyncPriceDiscount';
import runtime from 'art-template/lib/runtime';
import GoodsItem from '../component/goods_item/goods_item.js';
import lsitPageRecom from '../../newIndex/common/js/listPageRecom';

import './explore.css';

runtime.trans = trans;

let loader = null;
const $rateCounte = $('.js-star');
const $panelList = $('.js-panelList');
const $lodingBounce = $('.js-lodingBounce');
const $viewMoreBox = $('.js-viewMoreBox');
const $btnViewMore = $('.js-btnViewMore');
const $recommendList = $('.js-listWrap .js-panelList');

const tab = $('input[name=inputNode]').val();
const odr = $('input[name=inputOrder]').val();
const sendParams = {
    tab,
    odr,
    page: 1,
};


const exploreConfigApp = {
    docHeight: 0,
    listContBox: $('.js-listWrap'),
    listNavMenu: $('.js-exploreMenu'),
    listLoaderWrap: $('.explore_empty_tips'),

    init() {
        this.cateWidscrollControl();

        const type = 7;
        const renderResult = lsitPageRecom.pageShow(type);
        if (renderResult) {
            sendParams.page = renderResult.page;
            // 加载数据结束（完成|没有更多啦）
            if (renderResult.page >= renderResult.totalPage) {
                $btnViewMore.text(trans('goodslist.no_more_tips'));
                setTimeout(() => {
                    if ($viewMoreBox.hasClass('on')) {
                        $viewMoreBox.removeClass('on');
                    }
                }, 1500);
            }
        }

        // 分页数据
        this.initLoader();

        // 事件绑定
        this.bindEvent();

        this.cateNativeScroll();

        this.cateSelectOrderControl();

        // 返回顶部
        this.initScrollTopfunControl();
    },

    bindEvent() {

        // 初始化橱窗
        GoodsItem.init({
            container: $panelList,
        });
        asyncPriceDiscount({
            elementLists: $('.js-panelList').find('.js-asyncPrice'),
            shopPriceClassName: '.gbGoodsItem_markPrice',
        });

        // 点击推荐商品保存当前推荐商品到session
        $recommendList.on('click', '.js-gbGoodsItem', () => {
            lsitPageRecom.save();
            const scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            lsitPageRecom.historyReplace(scrollTop);
        });
    },

    cateWidscrollControl() {
        const scrollNavShow = () => {
            const WinDoc = $(window);
            const floorWrap = $('.js-cateBox');
            if (this.listContBox && this.listContBox.length > 0) {
                this.docHeight = this.listContBox.offset().top.toFixed(2);
                if (WinDoc.scrollTop() >= this.docHeight) {
                    floorWrap.addClass('fixedX');
                    setTimeout(() => {
                        floorWrap.addClass('fixed');
                        $('.explore_empity').addClass('on');
                    }, 50);
                } else {
                    floorWrap.removeClass('fixedX fixed');
                    $('.explore_empity').removeClass('on');
                }
            }
        };
        PubSub.subscribe('nativeScroll', throttle(scrollNavShow, 300));
    },

    cateNativeScroll() {
        const $cateActive = $('.explore_item.on');
        if ($cateActive.length === 0) return;

        const cateCenterOffsetX = $cateActive.offset().left + ($cateActive.width() / 2);
        const screenWidth = $('body').width();
        const scrollX = cateCenterOffsetX - (screenWidth / 2);
        const cateListsWidth = $('.exploreWrap_menuBox').width();
        const cateTopEle = document.querySelector('.js-exploreMenu');

        if (cateListsWidth - cateCenterOffsetX > (screenWidth / 2)) {
            cateTopEle.scrollLeft = scrollX;
        } else {
            cateTopEle.scrollLeft = cateListsWidth - screenWidth;
        }
    },

    cateSelectOrderControl() {
        this.listNavMenu.on('click', 'a', async (e) => {
            const thatSef = $(e.currentTarget);
            const dataNode = thatSef.data('node');
            if (!thatSef.hasClass('on')) {
                $btnViewMore.attr('data-nextpage', 2);
                $('input[name=inputNode]').val(dataNode);
                thatSef.addClass('on').siblings('a').removeClass('on');
                window.sessionStorage.setItem(STORAGE_EXPLORE_NODE, dataNode);
            }
        });
    },

    // loding
    lodingBounce(time) {
        setTimeout(() => {
            if ($lodingBounce.hasClass('on')) {
                $lodingBounce.removeClass('on');
            }
        }, time);
    },

    // 加载loader
    initLoader() {
        const $that = this;
        // 获取数据参数
        const params = sendParams;

        // 分页数据加载
        try {
            loader = new Loader({
                viewMore: $viewMoreBox,
                auto: true,
                data() {
                    params.page += 1;

                    // 请求其它分类数据
                    return serviceExploreDealsList.http({
                        params,
                        loading: false,
                    });
                },
                loadStart() {
                    // 开始加载新数据
                    $viewMoreBox.addClass('on');
                },
                loadSuccess(res) {
                    const data = res.data || {};
                    const listDate = data.goodsList;
                    const totalPage = data.totalPage;

                    if (+params.page === 1) {
                        lsitPageRecom.remove();
                    }

                    lsitPageRecom.set({
                        listDate,
                        totalPage
                    });

                    // 向当前分类容器追加数据
                    GoodsItem.init({
                        container: $panelList,
                        type: 7,
                        list: listDate,
                        append: true,
                    });
                    asyncPriceDiscount({
                        elementLists: $('.js-panelList').find('.js-asyncPrice'),
                        shopPriceClassName: '.gbGoodsItem_markPrice',
                    });

                    // let listNextPage = +$btnViewMore.attr('data-nextpage');
                    // $btnViewMore.attr('data-nextpage', listNextPage += 1);

                    // 更新评分
                    $that.updateScore();

                    // 更新货币
                    $that.updateCurrency($panelList);

                    // 加载数据结束（完成|没有更多啦）
                    if (params.page >= res.data.totalPage) {
                        loader.end();
                        $btnViewMore.text(trans('goodslist.no_more_tips'));
                        setTimeout(() => {
                            if ($viewMoreBox.hasClass('on')) {
                                $viewMoreBox.removeClass('on');
                            }
                        }, 1500);
                    }
                }
            });
        } catch (error) {
            // error...
        }
        return true;
    },

    // 更新货币
    updateCurrency(containerClass) {
        PubSub.publish('sysUpdateCurrency', {
            context: containerClass[0]
        });
    },

    // 更新评分render
    updateScore() {
        if ($rateCounte && $rateCounte.length > 0) {
            $rateCounte.star();
        }
    },

    // top
    backToTop(time) {
        time = time || 300;
        let scrollTopTimer = null;
        const speed = Math.ceil(this.getPageScrollY() / (time / 10));
        clearInterval(scrollTopTimer);
        scrollTopTimer = setInterval(() => {
            const beforeTop = this.getPageScrollY();
            if (beforeTop > 0) {
                if (beforeTop <= speed) {
                    this.getPageScrollY(0);
                } else {
                    const resultTop = beforeTop - speed;
                    this.getPageScrollY(resultTop);
                }
            } else {
                clearInterval(scrollTopTimer);
            }
        }, 20);
    },

    getPageScrollY(top) {
        if (top || Number(top) === 0) { // 设置垂直滚动值
            if (window.pageYOffset) {
                window.pageYOffset = Number(top);
            }
            if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
                document.documentElement.scrollTop = Number(top);
            }
            if (document.body) { // all other Explorers
                document.body.scrollTop = Number(top);
            }
            return true;
        } else if (top || Number(top) !== 0) {
            let yScroll = null;
            if (window.pageYOffset) {
                yScroll = window.pageYOffset;
            } else if (document.documentElement && document.documentElement.scrollTop) { // Explorer 6 Strict
                yScroll = document.documentElement.scrollTop;
            } else if (document.body) { // all other Explorers
                yScroll = document.body.scrollTop;
            }
            return yScroll;
        }
        return true;
    },

    initScrollTopfunControl() {
        const topBtn = $('.js-bottomTopBtn');
        const clientHeight = document.documentElement.clientHeight || document.body.clientHeight;
        const scrollSubscribe = () => {
            const osTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop;
            if (typeof osTop !== typeof undefined && osTop !== false) {
                if (osTop >= clientHeight) {
                    topBtn.addClass('show');
                } else {
                    topBtn.removeClass('show');
                }
            }
        };
        PubSub.subscribe('nativeScroll', throttle(scrollSubscribe, 300));
        topBtn.on('click', (e) => {
            e.preventDefault();
            // this.backToTop(300);
            $(window).scrollTop(0);
        });
    },
};

exploreConfigApp.init();
