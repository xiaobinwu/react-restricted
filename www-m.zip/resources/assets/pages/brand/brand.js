import 'js/bootstrap';
import 'modules/footer/footer.js';
import 'modules/header/header.js';
import { serviceBrandCate } from 'js/service/brand';
import Swiper from 'js/lib/swiper.js';
import Navigate from 'component/navigate/navigate.scroll';
import 'component/navigate/navigate.css';
import { BrandsTrack, RULES } from 'js/track/define/top_brands';
import asyncPriceDiscount from 'js/core/goods/asyncPriceDiscount';
import 'component/star/star.js';

import GoodsItem from '../category/component/goods_item/goods_item';
import './brand.css';

// 初始化埋点配置
new BrandsTrack({
    config: RULES,
    page: true,
}).run();

// 评分
$('.js-star').star();

new Swiper('.js-brandSwiper');
const BRAND_NAME = $('.brandName').val();
$('.brandHot_cateItem').eq(0).addClass('on');
$('.js-allCate .brandHot_cateAllItem').eq(0).addClass('brandHot_cateAllItem-active');
let cateId = 0;
let page = 1;
const nav = new Navigate('.js-cateScroll', {
    // default: 0,
    onChange(item) {
        const index = $(item).index();
        const id = $(item).attr('data-cate-id');
        const $items = $('.js-allCate .brandHot_cateAllItem');
        $items.removeClass('brandHot_cateAllItem-active').eq(index).addClass('brandHot_cateAllItem-active');
        $('.js-brandMore').show();
        renderList(id);
    },
});

async function renderList(cate, append = false) {
    cateId = cate;
    if (!append) {
        page = 0;
    }
    page += 1;
    const { data } = await serviceBrandCate.http({
        params: {
            brand: BRAND_NAME,
            cate_id: cate,
            page,
        }
    });

    if (!data.goodsList.length) {
        $('.js-brandMore').hide();
    } else {
        GoodsItem.init({
            container: $('.js-brandItemContain'),
            type: 2,
            list: data.goodsList,
            append,
        });
        asyncPriceDiscount({
            elementLists: $('.js-brandItemContain').find('.js-asyncPrice'),
            shopPriceClassName: '.gbGoodsItem_markPrice',
            callback({ $eleShopPrice }) {
                $eleShopPrice.removeClass('gbGoodsItem_hide');
            }
        });

        const $goodsItem = $('.gbGoodsItem');
        $goodsItem.each((index, elem) => {
            const info = elem.dataset.trackKey.split('_');
            const { catId } = elem.dataset;
            const key = `${info[0]}_${info[1]}`;

            try {
                window.TrackData[key] = {
                    k: info[1],
                    pc: catId,
                };
            } catch (e) {
                // 大数据没返回数据
            }
        });
    }
}
renderList(cateId, true); // 初始化渲染

// 加载下一页
$('.js-brandMore').on('tap', (e) => {
    // const $this = $(e.target);
    renderList(cateId, true);
});

// 品牌介绍查看更多
$('.js-infoTrigger').on('tap', (e) => {
    const $this = $(e.currentTarget);
    $this.toggleClass('brandHeader_infoTrigger-less');
    $('.brandHeader_info').toggleClass('brandHeader_info-less');
});

// 底部品牌展开按钮
$('.js-brandBriefMore').on('tap', (e) => {
    const $this = $(e.currentTarget);
    $this.toggleClass('brandBrief_more-less');
    $('.brandBrief_info').toggleClass('brandBrief_info-less');
});

// 品牌分类点击
$('.js-allCate').on('tap', '.brandHot_cateAllItem', (e) => {
    const index = $(e.target).index();
    nav.goto(index);
    $('.js-dropDown').addClass('up');
    $('.js-cateAll').removeClass('brandHot_cateAll-active');
    $('.js-cateDim').removeClass('brandHot_cateDim-active');
});

// 品牌分类点击下拉
$('.js-dropDown').on('tap', (e) => {
    const $this = $(e.currentTarget);
    const $cateDim = $('.js-cateDim');
    const { top } = $cateDim.get(0).getBoundingClientRect();
    const wHeight = $(window).height();
    $cateDim.height(wHeight - top);
    $this.toggleClass('up');
    $cateDim.toggleClass('brandHot_cateDim-active');
    $('.js-cateAll').toggleClass('brandHot_cateAll-active');
});
