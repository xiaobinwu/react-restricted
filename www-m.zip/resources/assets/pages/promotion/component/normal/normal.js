/**
 * Created by Jiazhan Li on 2018/08/02.
 */

import PubSub from 'pubsub-js';
import layer from 'layer';
import Timer from '../../../../component/timer/timer';
import appSdk from '../../../../common/js/core/app.sdk.js';
import copyHandle from '../../utils/copyHandle/copyHandle.js';
import { trans } from '../../../../common/js/core/translate.js';
import './normal.css';
import './new_normal.css';

function callback(module) {
    const $module = $(module);

    return new Promise(async (resolve) => {
        // 泳道商品样式
        const swiper = module.querySelector('.pmNormal_container.swiper-container');
        if (swiper) {
            const { default: Swiper } = await import('js/lib/swiper.js');
            new Swiper(swiper, {
                appPolyfill: {
                    use: true,
                    needNav: true
                },
                freeMode: true,
                slidesPerView: 2.433,
                spaceBetween: window.lib.flexible.rem2px(0.2666666),
                lazy: {
                    loadPrevNext: true,
                },
            });
        }

        resolve(); // 待轮播图插件初始化完毕再显示模块，避免出现闪动情况

        // 商品倒计时
        [...module.querySelectorAll('.js-timer')].forEach((timer) => {
            const $timer = $(timer);
            const $goodsItem = $timer.closest('.js-pmGoodsItem');
            const $unknownPrice = $goodsItem.find('.pmGoodsItem_curPrice-XXX');
            const $button = $goodsItem.find('.pmGoodsItem_btn');
            const $statusMask = $goodsItem.find('.js-pmGoodsItem_status span');
            const status = $goodsItem.data('status');

            Timer.add(timer, {
                format: `${trans('promotion.start_in')} {dd}: {hh}: {mm}: {ss}`,
                interval: 'begin',
                onStart() {
                    if (status !== 'comingSoon') {
                        $unknownPrice.removeClass('pmGoodsItem_curPrice-XXX');
                    }
                },
                onEnd(target) {
                    if (status === 'comingSoon') {
                        $unknownPrice.removeClass('pmGoodsItem_curPrice-XXX');
                        $goodsItem.removeClass('status-comingSoon').addClass('status-buyNow');
                        $button.text(trans('promotion.promotion_buy_now'));
                    }

                    Timer.add(target, {
                        format: `${trans('promotion.ends_in')} {dd}: {hh}: {mm}: {ss}`,
                        interval: 'end',
                        onEnd() {
                            $goodsItem.removeClass('status-buyNow').addClass('status-dealEnded');
                            $button.text(trans('promotion.promotion_deal_ended'));
                            $statusMask.text(trans('promotion.promotion_deal_ended'));
                        }
                    });
                }
            });
        });

        // 添加购物车
        $module.on('click', '.js-addCart', (e) => {
            console.log('add cart');
            const { goodsSn, warehouseCode, qty } = e.currentTarget.dataset;
            const $this = $(e.currentTarget);
            PubSub.publish('sysAddToCart', {
                goods: {
                    goodsSn,
                    warehouseCode,
                    qty,
                },
                callback() {
                    if ($this.closest('.status-comingSoon').length) {
                        layer.msg(trans('promotion.comming_soon_cart_tip'));
                    } else if ($this.closest('.status-dealEnded').length) {
                        layer.msg(trans('promotion.deals_end_cart_tip'));
                    }
                    appSdk.actCartChanged();
                },
            });
        });

        // 复制coupon码
        $module.find('.js-copy').each((i, elem) => {
            copyHandle(elem);
        });

        // 定金膨胀判断活动时间是否结束
        const nowTime = parseInt((+new Date()) / 1000, 10);
        $('.js-depositExpansion').each((index, value) => {
            const startTime = value.dataset.startTime;
            const endTime = value.dataset.endTime;
            if (
                (!startTime || !endTime || (nowTime > endTime || nowTime < startTime)) &&
                !$(value).closest('.js-pmGoodsItem').hasClass('status-soldOut')
            ) {
                $(value).closest('.js-pmGoodsItem').removeClass('status-buyNow').addClass('status-dealEnded');
                $(value).closest('.js-pmGoodsItem').find('.js-pmGoodsItem_status span').text(trans('promotion.promotion_deal_ended'));
                // $(value).find('.js-depositExpansion_board').addClass('hidden');
            }
        });
    });
}

export default {
    showAfterComplete: true,
    callback,
};
