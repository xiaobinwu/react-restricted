/**
 * Created by Jiazhan Li on 2018/08/02.
 */

import PubSub from 'pubsub-js';
import appSdk from '../../../../common/js/core/app.sdk.js';
import '../../../../component/star/star';
import './matchSell.css';

function callback(module) {
    const $module = $(module);

    // 添加购物车
    $module.on('click', '.js-addCart', (e) => {
        const params = [];
        const $this = $(e.currentTarget);
        const $wrap = $this.closest('.pmMatchSell_wrap');
        const $mainGoods = $wrap.find('.msGoodsItem-main');
        const $accessory = $wrap.find('.msGoodsItem-accessory');
        const { goodsSn: mainGoodsSn, warehouseCode: mainWarehouseCode, goodsType } = $mainGoods[0].dataset;

        params.push({
            goodsSn: mainGoodsSn,
            warehouseCode: mainWarehouseCode,
            qty: 1,
        });

        if (goodsType === '1') {
            $accessory.each((index, elem) => {
                const { goodsSn, warehouseCode } = elem.dataset;
                params.push({
                    goodsSn,
                    warehouseCode,
                    mainGoodsSn,
                    goodsType,
                    qty: 1,
                });
            });
        }

        PubSub.publish('sysAddToCart', {
            goods: params,
            callback() {
                appSdk.actCartChanged();
            },
        });
    });

    // 评星
    $module.find('.js-star').star();
}

export default {
    callback,
};
