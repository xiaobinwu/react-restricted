/**
 * Created by Jiazhan Li on 2018/08/02.
 */

import initCoupon from '../../utils/initCoupon/initCoupon.js';
import '../../../../component/navigate/navigate.css';
import './multiGoods.css';

function callback(module) {
    const $win = $(window);
    const $module = $(module);
    const $nav = $module.find('.navigate');
    const $content = $module.find('.pmMultiGoods_item');

    return new Promise(async (resolve) => {
        // 设置coupon橱窗高度
        const height = module.querySelector('.pmMultiGoods_item.on .js-pmGoodsItem').offsetHeight;
        [...module.querySelectorAll('.firstItem')].forEach((item) => {
            item.style.height = `${height}px`;
        });

        resolve();

        // 初始化导航组件
        const { default: Navigate } = await import('../../../../component/navigate/navigate.scroll.js');
        new Navigate($nav[0], {
            onChange($case) {
                $content.removeClass('on').eq($case.index()).addClass('on');
                $win.trigger('scroll');
            }
        });

        initCoupon(module);
    });
}

export default {
    showAfterComplete: true,
    callback,
};
