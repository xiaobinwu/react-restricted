/**
 * Created by Jiazhan Li on 2018/08/02.
 */

import appSdk from 'js/core/app.sdk.js';
import { trans } from 'js/core/translate.js';
import './banner.css';
import subscribe from '../../utils/subscribe';

const TYPE = {
    1: 'single', // 一行一个
    2: 'double', // 一行两个
    6: 'slide', // 轮播图
    7: 'lane', // 一行两个半（泳道）
};

function callback(module) {
    const { type: t } = module.dataset;
    const isUseSwiper = ['slide', 'lane'].indexOf(TYPE[t]) >= 0;

    // 针对轮播图和泳道样式，提前设置图片路径，不然高度计算会有问题
    if (isUseSwiper) {
        [...module.querySelectorAll('.pmBanner_img')].forEach((img) => {
            img.src = img.dataset.lazy;
        });
    }

    initSubscribe(module);

    return new Promise(async (resolve) => {
        if (isUseSwiper) {
            const { default: Swiper } = await import('js/lib/swiper.js');
            if (TYPE[t] === 'slide') {
                // 轮播图
                new Swiper(module.querySelector('.pmBanner_container'), {
                    appPolyfill: {
                        use: true
                    },
                    effect: 'coverflow',
                    loop: true,
                    slidesPerView: 3,
                    autoplay: {
                        delay: 3000,
                        disableOnInteraction: false,
                    },
                    lazy: {
                        loadPrevNext: true
                    },
                    pagination: {
                        el: module.querySelector('.pmBanner_pagination'),
                    },
                    coverflowEffect: {
                        rotate: 0,
                        stretch: 0,
                        depth: 600,
                        modifier: 1,
                        slideShadows: true,
                    },
                });
            } else if (TYPE[t] === 'lane') {
                // 一行两个半广告位（泳道）
                new Swiper(module.querySelector('.pmBanner_container'), {
                    freeMode: true,
                    slidesPerView: 2.323,
                    spaceBetween: window.lib.flexible.rem2px(0.1333333),
                });
            }
        }

        resolve(); // 待轮播图插件初始化完毕再显示模块，避免出现闪动情况
    });
}

// 预约提醒初始化
function initSubscribe(module) {
    /**
     * 预约截止时间前展示 'Remind Me' 按钮
     * 预约截至时间之后，活动开始之前展示 'Coming Soon' 按钮
     * 活动开始后不展示按钮
     */
    [...module.querySelectorAll('.js-subscribe')].forEach((bannerItem) => {
        const $bannerItem = $(bannerItem);
        const $bannerBtn = $bannerItem.find('.pmBanner_btn');
        const { deadline, start } = bannerItem.dataset;
        const nowTime = Math.floor((new Date()) / 1000);

        if (nowTime < deadline) {
            // 未到订阅截止时间时显示订阅按钮
            $bannerBtn.css('display', 'block').text(trans('promotion.remind_me'));
        } else if (nowTime < start) {
            // 当前时间处于订阅截止时间与活动开始时间之间时显示按钮，文案为 Coming Soon
            $bannerBtn.css('display', 'block').text(trans('promotion.promotion_coming_soon'));
        }
    });

    /**
     * 点击订阅按钮交互
     */
    $(module).on('click', '.js-subscribe', async (e) => {
        const $bannerItem = $(e.currentTarget);
        const $bannerBtn = $bannerItem.find('.pmBanner_btn');
        const nowTime = Math.floor((new Date()) / 1000);
        const floor = $bannerItem.closest('.js-lazyModule').index();
        const {
            reservation,
            deadline,
            start,
            weplink,
            applink,
        } = e.currentTarget.dataset;

        /**
         * 当前时间在订阅截止时间之前时：点击按钮发起订阅请求
         * 当前时间位于订阅截止时间和活动开始时间之间时：点击无反应
         * 当前时间在活动开始时间之后时：跳转到活动页面（区分WEP版和APP）
         */
        if (nowTime < deadline && !$bannerBtn.hasClass('reserved')) {
            subscribe({
                type: 'banner',
                data: { reservation, floor },
                onSuccess() {
                    $bannerBtn.addClass('reserved');
                    $bannerBtn.text(trans('promotion.reserved'));
                }
            });
        } else if (nowTime > start) {
            if (appSdk.IS_APP && applink) {
                window.location.href = applink;
            } else if (!appSdk.IS_APP && weplink) {
                window.location.href = weplink;
            }
        }
    });
}

export default {
    showAfterComplete: true,
    callback,
};
