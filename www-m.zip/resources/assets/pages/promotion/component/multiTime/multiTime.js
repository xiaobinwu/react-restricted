/**
 * Created by Jiazhan Li on 2018/08/02.
 */

import { throttle } from 'js/utils';
import Timer from '../../../../component/timer/timer';
import { trans } from '../../../../common/js/core/translate';
import '../../../../component/navigate/navigate.css';
import subscribe from '../../utils/subscribe';
import './multiTime.css';

function callback(module) {
    const $win = $(window);
    const $module = $(module);
    const $nav = $module.find('.navigate');
    const $navTimer = $nav.find('.nav_timer');
    const $content = $module.find('.pmMultiTime_item');
    const $timer = $module.find('.js-timer-nav');
    const nowTime = Math.floor(new Date() / 1000);
    const { dataset } = module;
    const hasFiveGroup = dataset.type === '10'; // 是否显示5组商品
    const groupLength = Number(dataset.group); // 多时段的类型 2，3，5

    let buyNowIndex = 0;

    const NAV = {
        array: [],

        init() {
            NAV.array = NAV.getArray();
            buyNowIndex = NAV.getActiveIndex(NAV.array);
            NAV.layout();
        },

        layout() {
            const { first, last } = NAV.getArrayRange({
                array: NAV.array,
                activeIndex: buyNowIndex,
                length: +groupLength,
                position: hasFiveGroup ? 2 : 0,
            });

            [...$navTimer].forEach((item, index) => {
                if (index >= first && index <= last) {
                    $(item).parent().removeClass('hide');
                } else {
                    $(item).parent().addClass('hide');
                }
            });
        },

        // 返回当前高亮的导航索引
        getActiveIndex(array) {
            let activeIndex = array.length - 1;
            array.some((item, index) => {
                if (nowTime < item) {
                    activeIndex = index;
                    return true;
                }
                return false;
            });
            return activeIndex;
        },

        // 一个包含每个时间段的截至时间的数组，用来做一些计算，防止频繁操作dom元素
        getArray() {
            return [...$navTimer].map(item => item.dataset.end);
        },

        getArrayRange({
            array = [], // 目标数组
            activeIndex = 0, // 返回相对于目标数组当前的索引
            length = 0, // 期望返回的数组长度
            position = 0, // 期望在返回的数组中高亮的位置
        } = {}) {
            let first = 0;
            let last = array.length - 1;

            activeIndex = +activeIndex;
            length = +length;
            position = +position;

            if (array[activeIndex] !== undefined) {
                first = Math.max(0, activeIndex - position);
                last = Math.min(array.length - 1, (first + length) - 1);
                first = Math.max(0, (last - length) + 1);
            }
            return { first, last };
        }
    };

    NAV.init();

    initSubscribe(module);

    return new Promise(async (resolve) => {
        let navigate = null;
        let { default: Navigate } = (await import('../../../../component/navigate/navigate.scroll.js'));

        if (!$nav.hasClass('navigate-scroll')) {
            Navigate = Navigate.SuperClass;
        }

        setTimeout(() => {
            navigate = new Navigate($nav[0], {
                default: buyNowIndex, // 默认跳转到 Buy Now
                onChange($case) {
                    $content.removeClass('on').eq($case.index()).addClass('on');
                    $win.trigger('scroll');
                }
            });
        }, 0);

        const refresh = throttle(() => {
            if (navigate && navigate.refresh) navigate.refresh();
        }, 500);

        resolve(); // 此时删除模块蒙层

        // 导航中的倒计时交互
        [...$timer].forEach((timer) => {
            Timer.add(timer, {
                format() {
                    if (hasFiveGroup) return '{dd}:{hh}:{mm}:{ss}';
                    return `${trans('promotion.start_in')}: {dd}:{hh}:{mm}:{ss}`;
                },
                interval: 'begin',
                onStart(target) {
                    const $case = $(target).parent();
                    const $title = $case.find('em');

                    if (hasFiveGroup) {
                        $title.text(`${trans('promotion.start_in')}:`);
                    }
                },
                onEnd(target) {
                    const $case = $(target).parent();
                    const $title = $case.find('em');
                    $title.text(trans('promotion.promotion_buy_now'));

                    if (hasFiveGroup) {
                        $case.addClass('status-buyNow');
                    }

                    Timer.add(target, {
                        format: `${trans('promotion.ends_in')} {dd}:{hh}:{mm}:{ss}`,
                        interval: 'end',
                        onEnd() {
                            const curIndex = $case.index();

                            if ($case.hasClass('on')) {
                                buyNowIndex += 1;
                                NAV.layout();
                                if ($timer.eq(curIndex + 1).length > 0 && navigate && navigate.goto) {
                                    navigate.goto(curIndex + 1);
                                }
                            }

                            if (hasFiveGroup) {
                                $case.removeClass('status-buyNow');
                                $case.addClass('status-onSale');
                                $title.text(trans('promotion.on_sale'));
                            } else {
                                $case.addClass('status-dealEnded');
                                $title.text(trans('promotion.promotion_deal_ended'));
                            }

                            refresh();
                        }
                    });
                }
            });
        });
    });
}

// 预约提醒初始化
function initSubscribe(module) {
    /**
     * 预约截止时间前展示 'Remind Me' 按钮
     * 预约截至时间之后，活动开始之前展示 'Coming Soon' 按钮
     * 活动开始后不展示按钮
     */
    [...module.querySelectorAll('.js-subscribe')].forEach((target) => {
        const $target = $(target);
        const nowTime = Math.floor((new Date()) / 1000);
        const { deadline, start } = target.dataset;

        if (nowTime < deadline) {
            // 未到订阅截止时间时显示 Remind Me
            $target.text(trans('promotion.remind_me'));
        } else if (nowTime < start) {
            // 当前时间处于订阅截止时间与活动开始时间之间时显示按钮，文案为 Coming Soon
            $target.text(trans('promotion.promotion_coming_soon'));
        } else {
            // 删除这个类名可以让该按钮点击不到
            $target.parent().removeClass('pmGoodsItem_control-top');
        }
    });

    /**
     * 点击订阅按钮交互
     */
    $(module).on('click', '.js-subscribe', async (e) => {
        const $target = $(e.currentTarget);
        const nowTime = Math.floor((new Date()) / 1000);
        const floor = $target.closest('.js-lazyModule').index();
        const {
            reservation,
            deadline,
        } = e.currentTarget.dataset;

        /**
         * 当前时间在订阅截止时间之前时：点击按钮发起订阅请求
         * 当前时间位于订阅截止时间和活动开始时间之间时：点击无反应
         * 当前时间在活动开始时间之后时：跳转到活动页面（区分WEP版和APP）
         */
        if (nowTime < deadline && !$target.hasClass('reserved')) {
            subscribe({
                type: 'goods',
                data: { reservation, floor },
                onSuccess() {
                    $target.addClass('reserved');
                    $target.text(trans('promotion.reserved'));
                }
            });
        }
    });
}

export default {
    showAfterComplete: true,
    callback,
};
