/**
 * Created by Jiazhan Li on 2018/08/02.
 */

import initCoupon from '../../utils/initCoupon/initCoupon.js';
import Timer from '../../../../component/timer/timer';
import { trans } from '../../../../common/js/core/translate.js';
import subscribe from '../../utils/subscribe';
import './coupon.css';

const TYPE = {
    1: 'A1', // A类：一行两个
    4: 'A2', // A类：一行两个半（泳道）
    5: 'B1', // B类：一行两个
    8: 'B2', // B类：一行两个半（泳道）
};

function callback(module) {
    const { type: t } = module.dataset;
    const isUseSwiper = ['A2', 'B2'].indexOf(TYPE[t]) >= 0;

    return new Promise(async (resolve) => {
        if (isUseSwiper) {
            const { default: Swiper } = await import('js/lib/swiper.js');

            new Swiper(module.querySelector('.pmCoupon_container'), {
                freeMode: true,
                slidesPerView: 2.323,
                slidesPreGroup: 1,
                appPolyfill: {
                    use: true,
                    needNav: true
                },
                spaceBetween: window.lib.flexible.rem2px(0.1333333)
            });

        }

        // 领券倒计时
        [...module.querySelectorAll('.js-timer-coupon')].forEach((timer) => {
            const $timer = $(timer);
            const $btn = $timer.closest('.pmCoupon_item').find('.pmCoupon_btn');

            Timer.add(timer, {
                format: `<span class="words">${trans('promotion.comes_in')}</span> <em>{dd}:{hh}:{mm}:{ss}</em>`,
                interval: 'begin',
                onStart() {
                    $btn.addClass('coupon-comingSoon');
                },
                onEnd() {
                    $btn.removeClass('coupon-comingSoon');
                    const { status } = timer.dataset;
                    if (status === 'coupon-normal') {
                        $timer.parent().html(`<i class="icon-coupon_underway"></i><em class="font-22">${trans('promotion.grab_coupon_now')}</em>`);
                    } else if (status === 'coupon-allTaken') {
                        $timer.parent().html(`<i class="icon-coupon_nothing"></i><em class="font-22">${trans('promotion.all_coupons_taken')}</em>`);
                    } else if (status === 'coupon-expired') {
                        $timer.parent().html(`<i class="icon-coupon_end"></i><em class="font-22">${trans('promotion.coupons_unavailable')}</em>`);
                    }
                }
            });
        });

        resolve(); // 待轮播图插件初始化完毕再显示模块，避免出现闪动情况
        initCoupon(module); // 获取coupon码
        initSubscribe(module);
    });
}

// 预约提醒初始化
function initSubscribe(module) {
    /**
     * 预约截止时间前展示 'Remind Me' 按钮
     * 预约截至时间之后，活动开始之前展示 'Coming Soon' 按钮
     * 活动开始后不展示按钮
     */
    [...module.querySelectorAll('.js-subscribe')].forEach((target) => {
        const $target = $(target);
        const $btnTextWrap = $target.find('.pmCoupon_btnText');
        const nowTime = Math.floor((new Date()) / 1000);
        const { deadline = 0, start } = target.dataset;

        if (nowTime < deadline) {
            // 未到订阅截止时间时显示 Remind Me
            $btnTextWrap.text(trans('promotion.remind_me'));
        } else if (nowTime < start) {
            // 当前时间处于订阅截止时间与活动开始时间之间时显示按钮，文案为 Coming Soon
            $btnTextWrap.text(trans('promotion.promotion_coming_soon'));

            // 活动开始后按钮文案还原
            setTimeout(() => {
                $btnTextWrap.text($btnTextWrap.data('text'));
            }, (start - nowTime) * 1000);
        }
    });

    /**
     * 点击订阅按钮交互
     */
    $(module).on('click', '.js-subscribe', async (e) => {
        const $target = $(e.currentTarget);
        const $btnTextWrap = $target.find('.pmCoupon_btnText');
        const nowTime = Math.floor((new Date()) / 1000);
        const floor = $target.closest('.js-lazyModule').index();
        const {
            reservation,
            deadline = 0,
        } = e.currentTarget.dataset;

        /**
         * 当前时间在订阅截止时间之前时：点击按钮发起订阅请求
         * 当前时间位于订阅截止时间和活动开始时间之间时：点击无反应
         * 当前时间在活动开始时间之后时：跳转到活动页面（区分WEP版和APP）
         */
        if (nowTime < deadline && !$target.hasClass('reserved')) {
            subscribe({
                type: 'coupon',
                data: { reservation, floor },
                onSuccess() {
                    $target.addClass('reserved');
                    $btnTextWrap.text(trans('promotion.reserved'));
                }
            });
        }
    });
}

export default {
    showAfterComplete: true,
    callback,
};
