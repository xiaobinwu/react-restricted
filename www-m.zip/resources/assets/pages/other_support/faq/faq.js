import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import 'common/icon/pageArticle/index.css'; // 品牌升级文章页字体图标

import backPrevOrHome from 'js/core/backPrevOrHome';

import './faq.css';

// 引入单独页面样式
async function linkAsync() {
    if ($('#about_us').length) {
        // about us (m + app)
        await import('./component/about_us/about_us.css');
    } else if ($('.points_nav').length) {
        // about_points (app + m)
        await import('./component/about_points/about_points.css');
    } else if ($('.shippingmethods_main').length) {
        // shipping methods (app)
        await import('./component/shipping_methods/shipping_methods.css');
    } else if ($('.os_cantactUs-m').length) {
        // contact us (app)
        await import('./component/contact_us/contact_us.css');
    } else {
        await import('./component/about_us/about_us.css');
        await import('./component/about_points/about_points.css');
        await import('./component/shipping_methods/shipping_methods.css');
        await import('./component/contact_us/contact_us.css');
    }
    $('.js-skeleton').html('').removeClass('skeleton');
}
linkAsync();

/*
*
*   js方法 my - point
*
*/
window.Get_Points_click = (element) => {
    const $elm = $(element);
    $elm.addClass('get_on ');
    $('.Use_Points').removeClass('get_on');

    $('.Get_Points_main').css({
        display: 'block'
    });
    $('.Use_Points_main').css({
        display: 'none'
    });
    // element.setAttribute('style', 'display: block;');
    // const usePoint = document.getElementsByClassName('Use_Points')[0];
    // usePoint.setAttribute('style', 'display: none;');
};
window.Use_Points_click = (element) => {
    const $elm = $(element);
    $elm.addClass('get_on ');
    $('.Get_Points').removeClass('get_on');

    $('.Use_Points_main').css({
        display: 'block'
    });
    $('.Get_Points_main').css({
        display: 'none'
    });
};

$('.js-back').click((e) => {
    backPrevOrHome();
});
