import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import Track from 'js/track/track';
import { getULike } from 'js/service/other';
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';
// import 'js/core/goods/collect.js';

// import layer from 'layer';
// import Timer from 'component/timer/timer.js';
import tempRecom from 'pages/goods/component/async_module/panelRecommend/panelRecommend.art';
import 'pages/goods/component/async_module/panelRecommend/skeletonRecommend.css';
import 'pages/goods/component/async_module/panelRecommend/panelRecommend.css';
import PubSub from 'pubsub-js';

import './error.css';

runtime.trans = trans;

const errorTrack = new Track({
    page: true
});

errorTrack.run();

// TR404页面优化暂时注释  http://jira.hqygou.com/browse/GB-19168 2018/10/23
// const pipelinecode = window.GLOBAL.PIPELINE;
const errorHandle = {
    init() {
        // TR404页面优化暂时注释  http://jira.hqygou.com/browse/GB-19168 2018/10/23
        /* this.locationHref = $('#js-jumpTimerWrap').data('jump-url');
        // 土耳其渠道跳转
        if (pipelinecode === 'GBTR' && this.locationHref) {
            this.showRedirectUrlDialog();
        } */

        this.recom();
    },

    // 显示弹窗
    // showRedirectUrlDialog() {
    //     const self = this;
    //     layer.open({
    //         fixed: true,
    //         area: '400px',
    //         closeBtn: 0,
    //         btn: false,
    //         move: false,
    //         shadeClose: false,
    //         shade: 0.3,
    //         content: 'Üzgünüz, incelemek istediğiniz ürün bulunamıyor sizi hemen anasayfaya yönlendiriyoruz.',
    //         success() {
    //             if (self.locationHref) {
    //                 self.timerToEnter();
    //             }
    //         }
    //     });
    // },
    //
    // // 倒计时并处理
    // timerToEnter() {
    //     const self = this;
    //     const timer = new Timer();
    //     timer.add('#js-jumpTimerWrap', {
    //         interval: 3,
    //         format: '',
    //         onEnd() {
    //             window.location.href = self.locationHref;
    //         },
    //     });
    // },

    async recom() {
        // 大数据推荐 slick init
        const { status, data } = await getULike({
            params: {
                goodsinfo: []
            },
            recommendType: '1030101'
        });

        if (status === 0) {
            const $recommendBox = $('.js_recommendBox');
            $recommendBox.html(tempRecom({
                list: data,
                btnType: 'cart'
            }));

            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $recommendBox[0]
            });

            // 添加购物车
            $recommendBox.on('click', '.js-addCart', (e) => {
                const { sku, warehouse } = e.currentTarget.dataset;
                PubSub.publish('sysAddToCart', {
                    goods: {
                        goodsSn: sku,
                        warehouseCode: warehouse,
                        qty: 1,
                    }
                });
            });
        }
    }
};
errorHandle.init();
