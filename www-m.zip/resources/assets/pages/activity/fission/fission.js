import 'js/bootstrap';
import 'js/lib/zepto/fx.js';
import 'js/lib/zepto/fx_methodes.js';
import { Base64 } from 'js-base64';
import Clipboard from 'clipboard';
import { getUrlQuery } from 'js/utils';
import Cookies from 'js/utils/cookie';
import Service from 'js/http/service';
import { trans } from 'js/core/translate.js';
import appSdk from 'js/core/app.sdk';
import {
    serviceFissionPacketInfo,
    serviceFissionPacketAssist,
    serviceFissionPacketWithdraw,
    serviceFissionPacketforwardInfo,
    serviceFissionMianBanner
} from 'js/service/promotion.js';
import { add, sub, divide, transformSymbol } from 'js/core/currency';
import isLogin from 'js/core/user/isLogin.js';
import PubSub from 'pubsub-js';
import layer from 'layer';
import Timer from 'component/timer/timer';
import runtime from 'art-template/lib/runtime';
import Swiper from 'js/lib/swiper.js';
import { toAppLink } from 'js/utils/appMethod.js';
import brushCheck from 'component/brushCheck/brushCheck.js';
import recommend from './recommend';
import fissionAlert from './alert';
import layerTemp from './packet_handle.art';
import './fission.css';

runtime.trans = trans;

// ----- 环境变量 -----
const COOKIE_HELPID = 'helpId';
const { DOMAIN_LOGIN, DOMAIN_MAIN } = window.GLOBAL;
const { IS_APP, APP_OS, APP_VER } = appSdk;
const imei = Cookies.get('imei');
const appParams = IS_APP ? `?type=app&platform=${APP_OS || ''}` : '';

// ----- 全局状态 -----
window.fisnSTORE = {
    leavepage: fissionAlert.leavepage, // APP 离开页面调用方法
    isLogin: isLogin(IS_APP),
    status: '',
    fbLoginBtn: false, // fb登陆按钮
    appVerSign: 0,
    appShareSign: 0,
    gRecaptchaResponse: '', // 谷歌接口防刷 token
    attachInfo: '', // 防刷设备信息
};

// ----- 页面状态设置 -----
if (!IS_APP) {
    import('modules/header/header.js');
    import('modules/footer/footer.js');
} else {
    window.fissionAlert = fissionAlert;

    if (APP_VER) {
        // 判断当前所处版本
        const appVERnum = parseInt(APP_VER.replace(/[ver.]/g, ''), 10);
        if (APP_OS === 'ios' && appVERnum >= (window.validate === '2' ? 331 : 301)) {
            window.fisnSTORE.appVerSign = window.validate === '2' ? 2 : 1;
        } else if (APP_OS !== 'ios' && appVERnum >= (window.validate === '2' ? 401 : 371)) {
            window.fisnSTORE.appVerSign = window.validate === '2' ? 2 : 1;
        } else {
            window.fisnSTORE.appVerSign = 0;
        }

        if (window.fisnSTORE.appVerSign > 0) { // 版本合法 判断是否启用fb登陆
            window.fisnSTORE.fbLoginBtn = !(window.validate === '2');
        } else { // 提示版本升级
            fissionAlert.toDowApp();
        }

        // 判断app版本是否支持原生分享
        if (APP_OS === 'ios' && appVERnum >= 370) {
            window.fisnSTORE.appShareSign = 1;
        } else if (APP_OS !== 'ios' && appVERnum >= 440) {
            window.fisnSTORE.appShareSign = 1;
        } else {
            window.fisnSTORE.appShareSign = 0;
        }
    }

    // 获取防刷数据
    if (window.local_obj && window.local_obj.attachInfo) {
        window.fisnSTORE.attachInfo = window.local_obj.attachInfo() || '';
    }
}

// ----- 页面逻辑处理 -----
const fissionConfigApp = {
    timeBtn: $('.js-fission-time'),
    openRulebtn: $('.js-fission-rule'),
    recomScroll: $('.js-fission-scroll'),
    fissionSpecial: $('.js-fissionWrap'),
    fissionPop: $('.js-fission-pop'),
    fissionMsg: $('.js-fission-message'),
    fissionPrice: $('.js-fission-paket'),
    fissionRecord: $('.js-fission-record'),
    fissionShareBtn: $('.js-shareBtn'),
    fissionInviteBtn: $('.js-layerInviteBtn'),
    fissionWithdraw: $('.js-fissionWithdraw'),
    fissionWithdBtn: $('.js-fissionWithdBtn'),
    fissionLayerWrap: $('.js-fissionLayerWrap'),
    fixPanelA: $('.js-fissionPanelA'),
    fixPanelB: $('.js-fissionPanelB'),
    fixOpenAmount: $('.js-opentAmount'),
    fixPackAmount: $('.js-packetAmount'),
    fixOpenTotal: $('.js-openTotal'),
    fixOpenTotalBar: $('.js-openTotalBar'),
    init() {
        this.bindEvent();
        this.appCurrencyTransform();
        this.renderCallbackHandleControl();
        recommend(IS_APP);
    },
    // 获取当前页面状态
    async getStatus() {
        const $this = this;
        // 获取用户当前状态
        if ((IS_APP && window.fisnSTORE.isLogin) || window.activityRecordId) {
            const res = await new Service().http({
                method: 'jsonp',
                cache: false,
                loading: false,
                errorPop: false,
                url: `${DOMAIN_MAIN}/activity/red-packet/get-page-status${appParams}`,
                params: {
                    imei,
                    activityRecordId: String(window.activityRecordId),
                }
            });

            if (+res.status === 0) {
                window.fisnSTORE.status = res.data.pageStatus;

                const pageIndex = res.data.pageStatus;
                const lodingOpacityBox = $('.js-opacityBox');
                lodingOpacityBox.addClass('remove');

                setTimeout(() => {
                    lodingOpacityBox.remove();
                }, 150);

                if (pageIndex.indexOf('B') >= 0) {
                    $this.updateImg($(`#page${pageIndex}`), res.data);
                }

                if (IS_APP) {
                    $('#notInApp').remove();
                    const page = $(`#page${pageIndex}`);
                    page.show();
                    if (res.data.activityRecordId) {
                        window.activityRecordId = res.data.activityRecordId;
                    }

                    if (pageIndex === 'A1') {
                        // A用户无红包
                        $this.getLog(page.find('.fission_forwardList'));
                        $this.toOpen(page.find('.fission_open'));
                        // 显示规则
                        $('.fission_rules').on('tap', () => {
                            fissionAlert.rules(IS_APP);
                        });

                    } else if (pageIndex === 'A2') {
                        // A用户有红包
                        $this.init();

                    } else if (pageIndex === 'B1') {
                        // A用户红包结束,B用户无红包
                        const money = trans('promotion.fission_send_cash');

                        page.find('.fission_A_helping').html(money);
                        PubSub.publish('sysUpdateCurrency', {
                            context: page[0]
                        });
                        $this.count(page);

                    } else if (pageIndex === 'B2' || pageIndex === 'B5') {
                        // B2 A用户红包结束,B用户有红包
                        // B5 A用户红包未结束, B用户已经帮拆,B用户有红包
                        const remain = add(res.data.redPacketAmount, -res.data.dismantledAmount);
                        const count = `<span class="js-currency" data-currency="${remain}">${transformSymbol({ price: remain })}</span>`;
                        const money = trans('promotion.fission_stillhas_money', [count]);

                        page.find('.fission_A_helping').html(money);
                        $this.count(page);

                    } else if (pageIndex === 'B3') {
                        // A用户红包未结束, B用户未帮拆
                        $this.getLog(page.find('.fission_forwardList'));
                        $this.helpOpen(page.find('.fission_open'), res);
                        $this.updateProcess(page, res.data);

                    } else if (pageIndex === 'B4') {
                        // A用户红包未结束, B用户已经帮拆,B用户无红包
                        $this.count(page);
                        const money = trans('promotion.fission_send_cash');

                        page.find('.fission_A_helping').html(money);
                    }
                    PubSub.publish('sysUpdateCurrency', {
                        context: page[0]
                    });

                } else {
                    // 显示规则
                    $('.fission_rules').on('tap', () => {
                        fissionAlert.rules(IS_APP);
                    });

                    const pageA = pageIndex.indexOf('A');
                    const notInApp = $('#notInApp');
                    const page = $(`#page${pageIndex}`);
                    notInApp.show();
                    if (pageA >= 0) {
                        $('#user_a').show();
                        $('#user_b').hide();
                    } else if (pageIndex === 'B1') {
                        page.show();
                        $this.count(page);
                    } else {
                        $('#user_a').hide();
                        $('#user_b').show();
                        $this.updateProcess($('#user_b'), res.data);
                        $this.updateImg($('#user_b'), res.data);
                    }
                    // 领取记录轮播
                    $this.getLog(notInApp.find('.fission_forwardList'));
                    // 点击打开APP
                    $this.openApp('.fission_open');
                    PubSub.publish('sysUpdateCurrency', {
                        context: page[0]
                    });
                }
            } else {
                layer.msg(res.msg, {
                    timer: 5000,
                    end() {
                        if (IS_APP) {
                            fissionAlert.leavepage();
                        }
                    }
                });
            }
        } else {
            const page = $('#pageA1');
            const notInApp = $('#notInApp');
            if (IS_APP) {
                notInApp.remove();
                page.show();
                // A用户无红包
                $this.getLog(page.find('.fission_forwardList'));
                $this.toOpen(page.find('.fission_open'));
            } else {
                notInApp.show();
                $('#user_a').show();
                $('#user_b').hide();
                // 领取记录轮播
                $this.getLog(notInApp.find('.fission_forwardList'));
                // 点击打开APP
                $this.openApp('.fission_open');
            }
            // 关闭loadding
            const lodingOpacityBox = $('.js-opacityBox');
            lodingOpacityBox.addClass('remove');
            setTimeout(() => {
                lodingOpacityBox.remove();
            }, 150);
            // 显示规则
            $('.fission_rules').on('tap', () => {
                fissionAlert.rules(IS_APP);
            });
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: page[0]
            });
        }
    },
    // 领取记录轮播
    getLog(selector) {
        try {
            new Swiper(selector, {
                autoplay: {
                    delay: 2000,
                    disableOnInteraction: false,
                },
                loopedSlides: 3,
                slidesPerView: 'auto',
                direction: 'vertical',
            });
        } catch (err) {
            // error
        }
    },
    async getToken() {
        const res = await new Service().http({
            method: 'POST',
            cache: false,
            url: `${DOMAIN_MAIN}/api/token`,
            data: {
                imei,
            }
        });
        return res;
    },
    async openPackage(actRecordId) { // 领取红包
        const $this = this;
        const tokenRes = await $this.getToken();
        const data = {
            activityId: String(window.activityId),
            imei,
            gRecaptchaResponse: window.fisnSTORE.gRecaptchaResponse || '',
            nohvz: window.fisnSTORE.attachInfo,
        };

        if (actRecordId) {
            data.activityRecordId = String(actRecordId);
        }

        if (tokenRes.status === 0) {
            data.accessToken = tokenRes.data.accessToken;
            const res = await new Service().http({
                method: 'POST',
                cache: false,
                errorPop: false,
                url: `${DOMAIN_MAIN}/activity/red-packet/open${appParams}`,
                data,
            });
            return res;
        }
        return tokenRes;
    },
    // 点击领取按钮
    toOpen(btn) {
        const $this = this;
        let lock = true;
        btn.on('tap', async () => {
            if (lock) {
                if (window.fisnSTORE.isLogin) {
                    lock = !lock;
                    const res = await $this.openPackage();

                    if (+res.status === 0) {
                        window.activityRecordId = res.data.activityRecordId;
                        $this.afterOpen($('#pageA2'), 'A2', res);
                    } else if (res.data.innerCode === 10055003) { // 账户未绑定手机号码
                        lock = !lock;
                        window.location.href = 'gearbest://bindPhone';
                    } else if (res.data.innerCode === 10055004) { // 谷歌放刷验证
                        lock = !lock;
                        const { gbcaptcha } = await brushCheck({
                            siteKey: window.gRecaptchaSiteKey,
                            recaptchaVersion: 'v2',
                        });
                        window.fisnSTORE.gRecaptchaResponse = gbcaptcha || '';
                    } else {
                        layer.msg(res.msg);
                        lock = !lock;
                    }
                } else {
                    let url = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
                    if (IS_APP) {
                        url = $this.appCallbackLogin();
                    }
                    fissionAlert.login(url);
                }
            }
        });
    },
    helpOpen(btn, statusRes) {
        const $this = this;
        let lock = true;
        btn.on('tap', async () => {
            if (window.fisnSTORE.isLogin) {
                if (lock) {
                    lock = !lock;
                    const res = await $this.openPackage(window.activityRecordId);

                    if (+res.status === 0) {
                        // 记录用户帮拆成功
                        Cookies.set(COOKIE_HELPID, window.activityRecordId);

                        // 判断用户是有正在进行红包接口
                        const response = await new Service().http({
                            method: 'POST',
                            loading: false,
                            cache: false,
                            url: `${DOMAIN_MAIN}/activity/red-packet/validate${appParams}`,
                            data: {
                                imei,
                                activityId: String(window.activityId),
                            }
                        });
                        if (+response.status === 0) {
                            $('#pageB3').hide();
                            const { dismantledAmount, currentRedPacketAmount, redPacketAmount } = res.data;
                            const count = `
                                <span class="js-currency" data-currency="${currentRedPacketAmount}">
                                    ${transformSymbol({ price: currentRedPacketAmount })}
                                </span>
                            `;
                            const money = trans('promotion.fission_helped_got', [count]);
                            if (response.data) {
                                // 有红包
                                const remain = add(redPacketAmount, -dismantledAmount);
                                const remains = `
                                    <span class="js-currency" data-currency="${remain}">${transformSymbol({ price: remain })}</span>
                                `;
                                $('#pageB7').find('.fission_helped_got').html(money);
                                $('#pageB7').find('.fission_A_helping').html(remains);
                                $('#pageB7').show();
                                $this.count($('#pageB7'));
                                $this.updateImg($('#pageB7'), statusRes.data);
                            } else {
                                // 没有红包
                                $('#pageB6').find('.fission_helped_got').html(money);
                                $('#pageB6').show();
                                $this.count($('#pageB6'));
                                $this.updateImg($('#pageB6'), statusRes.data);
                            }
                        } else {
                            layer.msg(response.msg);
                        }
                    } else if (res.data.innerCode === 10055003) { // 账户未绑定手机号码
                        lock = !lock;
                        window.location.href = 'gearbest://bindPhone';
                    } else if (res.data.innerCode === 10055004) { // 谷歌放刷验证
                        lock = !lock;
                        const { gbcaptcha } = await brushCheck({
                            siteKey: window.gRecaptchaSiteKey,
                            recaptchaVersion: 'v2',
                        });
                        window.fisnSTORE.gRecaptchaResponse = gbcaptcha || '';
                    } else {
                        layer.msg(res.msg);
                        lock = !lock;
                    }
                }
            } else {
                let url = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
                if (IS_APP) {
                    url = $this.appCallbackLogin();
                }
                fissionAlert.login(url);
            }
        });
    },
    count(page) {
        const $this = this;
        // 倒计时
        let count = 3;
        let timer = null;
        const fissionCount = page.find('.fission_B_count');
        timer = setInterval(async () => {
            count -= 1;
            fissionCount.html(count);
            if (count === 0) {
                clearInterval(timer);
                $this.action(page);
            }
        }, 1000);

        let lock = true;
        page.find('.fission_open').on('click', async () => {
            if (lock) {
                lock = !lock;
                clearInterval(timer);
                $this.action(page, lock);
            }
        });
    },
    async action(page, lock) {
        const $this = this;
        if (page.selector === '#pageB2' || page.selector === '#pageB4' || page.selector === '#pageB6') {
            // 到达A2
            if (page.selector === '#pageB2') {
                // pageB2 有红包
                page.hide();
                $this.init();
                $('#pageA2').show();
            } else {
                // B用户无红包
                const res = await $this.openPackage();
                window.activityRecordId = res.data.activityRecordId || '';
                if (res.status === 0) {
                    page.hide();
                    $('#pageA2').show();
                    $this.init();
                    $this.fissionPacketLayerHandle(res.data.redPacketAmount, res.data.currentRedPacketAmount);
                } else if (res.data.innerCode === 10055003) { // 账户未绑定手机号码
                    window.location.href = 'gearbest://bindPhone';
                } else if (res.data.innerCode === 10055004) { // 谷歌放刷验证
                    const { gbcaptcha } = await brushCheck({
                        siteKey: window.gRecaptchaSiteKey,
                        recaptchaVersion: 'v2',
                    });
                    window.fisnSTORE.gRecaptchaResponse = gbcaptcha || '';
                } else {
                    layer.msg(res.msg);
                    if (lock !== undefined) {
                        lock = !lock;
                    }
                }
            }

        } else if (page.selector === '#pageB1' || page.selector === '#pageB5' || page.selector === '#pageB7') {
            if (page.selector === '#pageB1' && !IS_APP) {
                $('#pageB1').hide();
                $('#user_a').show();
            } else {
                const { href, pathname } = window.location;
                const paramsList = [];
                const params = getUrlQuery(href);
                for (const key in params) {
                    if (key !== 'activityRecordId') {
                        paramsList.push(`${key}=${params[key]}`);
                    }
                }
                const urlParams = paramsList.join('&');
                window.location.href = urlParams.length > 0 ? `${DOMAIN_MAIN}${pathname}?${urlParams}` : `${DOMAIN_MAIN}${pathname}`;
            }
        }

    },
    // 点击open
    afterOpen(page, pageIndex, res) {
        const $this = this;
        const btn = page.find('.fission_open');
        if (pageIndex === 'A1') {
            $this.getLog(page.find('.fission_forwardList'));
            $this.toOpen(btn);

        } else if (pageIndex === 'A2') {
            $this.init();
            $('#pageA2').show();
            $this.fissionPacketLayerHandle(res.data.redPacketAmount, res.data.currentRedPacketAmount);
        }
    },
    // A已结束
    async mainEnd(page, pageIndex) {
        const $this = this;
        const res = await new Service().http({
            method: 'GET',
            loading: false,
            cache: false,
            url: `${DOMAIN_MAIN}/activity/red-packet/get-record-info`,
            params: {
                activityId: String(window.activityId),
                activityRecordId: String(window.activityRecordId),
            }
        });

        if (res.status === 0) {

            $this.updateProcess(page, res.data);
            $this.updateImg(page, res.data);
            if (pageIndex === 'B2') {
                // 倒计时
                $this.count(page);
            }
        }
    },
    // 打开 App
    openApp(triggerEle) {
        const { title } = document;
        const deeplink = `gearbest://webview?title=${
            encodeURIComponent(title)
        }&url=${
            encodeURIComponent(window.location.href)
        }&fissionId=${
            window.activityId
        }`;

        new Clipboard(triggerEle, {
            text() {
                setTimeout(() => {
                    window.location.href = deeplink;
                    toAppLink(() => {
                        window.location.href = `${GLOBAL.DOMAIN_MAIN}/spread-app.html`;
                    });
                });
                return Base64.encode(deeplink);
            },
        });
    },
    updateProcess(page, data) {
        const money = page.find('.fission_A_remains');
        const remain = add(data.redPacketAmount, -data.dismantledAmount);
        const count = `<span class="js-currency" data-currency="${remain}">${transformSymbol({ price: remain })}</span>`;
        const leftVal = Math.floor((data.dismantledAmount / data.redPacketAmount) * 100);
        money.html(`
            <span class="fission_A_remainsCon" style="left:${leftVal < 40 ? leftVal : 40}%">
                ${trans('promotion.fission_remains', [count])}
            </span>
        `);
        const $trail = page.find('.fission_A_trail');
        $trail.css({
            width: `${leftVal}%`,
        });
    },
    updateImg(page, data) {
        if (data.userImage) {
            page.find('.fission_user').find('img').attr('src', data.userImage);
        } else if (data.userEmail) {
            page.find('.fission_user').html(data.userEmail.substr(0, 1).toUpperCase());
        } else {
            page.find('.fission_user').html('G');
        }
    },
    bindEvent() {
        const that = this;
        const activityId = String(window.activityId);
        const activityRecordId = String(window.activityRecordId);

        that.openRulebtn.on('tap', () => {
            fissionAlert.rules(IS_APP);
        });

        // 帮拆红包记录
        that.fissionRecord.on('click', () => {
            const fissionOpenCode = that.fissionSpecial.data('open-amount');
            const fissionTotalCode = that.fissionSpecial.data('total-amount');
            const fissionAssistList = that.fissionSpecial.data('assist');
            if (!IS_APP) {
                if (window.fisnSTORE.isLogin) {
                    fissionAlert.detail(fissionOpenCode, fissionTotalCode, fissionAssistList);
                } else {
                    fissionAlert.login(`${DOMAIN_LOGIN}/m-users-a-sign.htm`);
                }
            } else if (IS_APP) {
                if (window.fisnSTORE.isLogin) {
                    fissionAlert.detail(fissionOpenCode, fissionTotalCode, fissionAssistList);
                } else {
                    fissionAlert.login(that.appCallbackLogin());
                }
            }
        });

        // 邀请好友分享
        that.fissionShareBtn.on('click', (e) => {
            fissionAlert.indexshare();
        });

        // 用户提现操作/未集满
        that.fissionWithdraw.on('click', (e) => {
            const dismantAmount = that.fissionSpecial.data('open-amount');
            const redPacketAmount = that.fissionSpecial.data('total-amount');
            if (!IS_APP) {
                if (window.fisnSTORE.isLogin) {
                    // 是否可以提现
                    if (dismantAmount === redPacketAmount) {
                        that.renderGrtUserWithdrawControl(activityId, activityRecordId);
                    } else {
                        fissionAlert.indexshare('nofull');
                    }
                } else {
                    fissionAlert.login(`${DOMAIN_LOGIN}/m-users-a-sign.htm`);
                }
            } else if (IS_APP) {
                if (window.fisnSTORE.isLogin) {
                    if (dismantAmount === redPacketAmount) {
                        that.renderGrtUserWithdrawControl(activityId, activityRecordId);
                    } else {
                        fissionAlert.indexshare('nofull');
                    }
                } else {
                    fissionAlert.login(that.appCallbackLogin());
                }
            }
        });

        // 用户提现操作
        that.fissionWithdBtn.on('click', (e) => {
            if (!IS_APP) {
                if (window.fisnSTORE.isLogin) {
                    that.renderGrtUserWithdrawControl(activityId, activityRecordId);
                } else {
                    fissionAlert.login(`${DOMAIN_LOGIN}/m-users-a-sign.htm`);
                }
            } else if (IS_APP) {
                if (window.fisnSTORE.isLogin) {
                    that.renderGrtUserWithdrawControl(activityId, activityRecordId);
                } else {
                    fissionAlert.login(that.appCallbackLogin());
                }
            }
        });
    },
    appCallbackLogin() {
        return window.validate === '2' ? 'gearbest://register?type=1' : 'gearbest://login';
    },
    packetSwiperScroll() {
        const that = this;
        const swiperWrapperList = $('.js-swiper-wrapper li');
        if (swiperWrapperList && swiperWrapperList.length > 2) {
            new Swiper(that.recomScroll, {
                autoplay: {
                    delay: 2000,
                    disableOnInteraction: false,
                },
                loop: true,
                direction: 'vertical',
            });
        }
    },
    fissionTimerHandle() {
        const $this = this;
        const timer = new Timer();
        if ($this.timeBtn.length) {
            timer.add($this.timeBtn, {
                format: `<b>{dd}</b><i>:</i>
                <b>{hh}</b><i>:</i>
                <b>{mm}</b><i>:</i>
                <b>{ss}</b>`,
                interval: 'end',
                onChange(target, output) {
                    target.html(output);
                },
            });
        }
    },
    fissionPacketLayerHandle(layerPrcie, packetPrcie) {
        layer.open({
            fixed: true,
            className: 'fission_packetBox',
            closeBtn: 0,
            btn: false,
            move: false,
            shadeClose: false,
            style: 'max-width: 10rem',
            shade: 'background-color: rgba(0,0,0,.8)',
            content: layerTemp({
                layerCurAmount: layerPrcie,
                layerPacketAmount: packetPrcie,
            }),
            success(elem) {
                const layerIndex = $(elem).attr('index');
                $('.js-layerInviteBtn').on('click', () => {
                    layer.close(layerIndex);
                    fissionAlert.indexshare();
                });
                PubSub.publish('sysUpdateCurrency', {
                    context: elem,
                });
            },
        });
    },
    showPacketEndDialog(dialogMsg, fissionPreice) {
        const that = this;
        if (that.fissionPop.length && that.fissionPop.css('display') !== 'block') {
            that.fissionPop.show();
            that.fissionMsg.html(dialogMsg);
            that.fissionPrice.attr('data-currency', fissionPreice).text(fissionPreice);
            setTimeout(() => {
                PubSub.publish('sysUpdateCurrency', {
                    context: that.fissionLayerWrap[0]
                });
            }, 200);
        }
    },
    async renderPacketForwardControl(activeId) {
        try {
            const swiperWrap = $('.js-swiper-wrapper');
            const res = await serviceFissionPacketforwardInfo.http({
                params: {
                    activityId: activeId,
                }
            });
            if (res.status === 0) {
                const temp = await import('./forward_info.art');
                temp.trans = trans;
                swiperWrap.html(temp(res));
                this.packetSwiperScroll();
                PubSub.publish('sysUpdateCurrency', {
                    context: swiperWrap[0]
                });
            } else {
                layer.msg(res.msg);
            }
        } catch (error) {
            // error;
        }
        return true;
    },
    async renderGetPacketInfoControl(recordShareId) {
        try {
            const recItemBox = $('.js-recItemBox');
            const fissionWrap = $('.js-fissionWrap');
            const res = await serviceFissionPacketAssist.http({
                params: {
                    activityRecordId: recordShareId
                }
            });
            if (res.status === 0) {
                const temp = await import('./render_info.art');
                recItemBox.html(temp(res));
                fissionWrap.attr('data-assist', JSON.stringify(res.data));
                PubSub.publish('sysUpdateCurrency', {
                    context: recItemBox[0]
                });
            } else {
                layer.msg(res.msg);
            }
        } catch (error) {
            // error
        }
    },
    async renderUpdateInforControl(activeId, recordShareId) {
        try {
            const that = this;
            const fissionWrap = $('.js-fissionWrap');
            const fissionPacket = $('.fission_packet-info');
            const fissionPanelX = $('.js-fissionPanelB');
            const { status, data } = await serviceFissionPacketInfo.http({
                params: {
                    activityId: activeId,
                    activityRecordId: recordShareId
                }
            });
            if (status === 0) {
                // 红包已拆满
                if (data.dismantledAmount === data.redPacketAmount) {
                    that.fixPanelA.hide();
                    that.fixPanelB.show();
                    that.fixOpenAmount.attr('data-currency', data.dismantledAmount);
                    that.fixPackAmount.attr('data-currency', data.redPacketAmount);
                    PubSub.publish('sysUpdateCurrency', {
                        context: fissionPanelX[0]
                    });
                } else {
                    that.fixPanelA.show();
                    that.fixPanelB.hide();
                    that.timeBtn.attr('data-end', data.validityTime);
                    that.fixOpenTotal.attr('data-currency', data.redPacketAmount);
                    const str = `
                        <p class="fission_packetBarTxt font-26">
                            ${trans('promotion.fission_text_collected', [data.dismantledAmount, sub(data.redPacketAmount, data.dismantledAmount)])}
                        </p>
                        <p class="fission_packetBarRate">
                            <span style="width: ${divide(data.dismantledAmount, data.redPacketAmount) * 100}%;"></span>
                        </p>
                    `;
                    that.fixOpenTotalBar.html(str);
                }
                that.fissionTimerHandle();
                fissionWrap.attr({
                    'data-open-amount': data.dismantledAmount,
                    'data-total-amount': data.redPacketAmount,
                });
                // 更新币种
                PubSub.publish('sysUpdateCurrency', {
                    context: fissionPacket[0]
                });
            } else {
                layer.msg(data.msg);
            }
        } catch (error) {
            // console.log(error);
        }
        return true;
    },
    async renderGrtUserWithdrawControl(activeId, recordShareId) {
        try {
            const res = await serviceFissionPacketWithdraw.http({
                data: {
                    activityId: activeId,
                    activityRecordId: recordShareId,
                    imei,
                    gRecaptchaResponse: window.fisnSTORE.gRecaptchaResponse || '',
                    nohvz: window.fisnSTORE.attachInfo,
                }
            });
            if (res.status === 0) {
                fissionAlert.setup();
            } else if (res.data.innerCode === 10055004) { // 谷歌放刷验证
                const { gbcaptcha } = await brushCheck({
                    siteKey: window.gRecaptchaSiteKey,
                    recaptchaVersion: 'v2',
                });
                window.fisnSTORE.gRecaptchaResponse = gbcaptcha || '';
            } else if (res.data.innerCode === 10055007) { // 未绑定邮箱
                fissionAlert.bindEmail(res.data.email);
            } else if (res.data.innerCode === 10055001) { // 账户未激活
                fissionAlert.activate(res.data.email);
            } else {
                layer.msg(res.msg);
            }
        } catch (error) {
            // error
        }
    },
    async renderMianBanner() {
        const { status, data } = await serviceFissionMianBanner.http();
        const banenrBox = $('.js-fission-recordBanner');
        if (status === 0 && data.banner) {
            const str = `
                <a href="${data.banner.banner_link}" class="fission_recordBannerLink" target="__blank">
                    <img src="${data.banner.banner_url}" alt="" class="fission_recordBannerImg">
                </a>
            `;
            banenrBox.html(str);
        } else if (status === 0) {
            banenrBox.hide();
        }
    },
    // 注：红包领取成功调用！！！
    renderCallbackHandleControl() {
        const that = this;
        const activityId = String(window.activityId);
        const activityRecordId = String(window.activityRecordId);
        that.renderPacketForwardControl(activityId);
        that.renderUpdateInforControl(activityId, activityRecordId);
        that.renderGetPacketInfoControl(activityRecordId);
        that.renderMianBanner();
    },
    appCurrencyTransform() {
        // APP客户端货币更新
        if (window.GLOBAL && window.GLOBAL.IS_APP) {
            window.appCurrency = (currencyCode) => {
                PubSub.publish('sysUpdateCurrency', {
                    currencyCode,
                });
            };
            window.location.href = 'GBWebAction://getAppCurrency';
        }
    },
};

fissionConfigApp.getStatus();
