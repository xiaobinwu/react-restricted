import layer from 'layer';
import PubSub from 'pubsub-js';
import Timer from 'component/timer/timer';
import { sub, divide } from 'js/core/currency';
import { trans } from 'js/core/translate.js';
import { toAppLink } from 'js/utils/appMethod.js';
import staticAsset from 'js/core/staticAsset';
import { getUrlQuery } from 'js/utils';
import Cookies from 'js/utils/cookie';
import Clipboard from 'clipboard';
import { sendActivationEmail } from 'js/service/auth';
import { servicePaymetResultsReplaceEmail } from 'js/service/paycart';
import './index.css';

const win = window;

const fissionAlert = {
    blacklist: () => {
        layer.msg(trans('promotion.fission_alert_blacklist'));
    },
    maxnum() {
        fissionAlert.initLayer('fissionAlert_maxnum', trans('promotion.fission_alert_maxnum'));
    },
    rules(IS_APP) {
        const href = `${win.GLOBAL.DOMAIN_MAIN}/promotion-Money-Bag-special-4982.html${IS_APP ? '?type=app' : ''}`;
        if (href) {
            window.location.href = href;
            return;
        }
        const ruleContent = $('#rule_content').html();
        const rulesStr = `
            <h6 class="font-36">${trans('promotion.fission_alert_rules_title')}</h6>
            <div class="content">${ruleContent}</div>
        `;
        fissionAlert.initLayer('fissionAlert_rules', rulesStr);
    },
    // 优化fecebook分享，避免同一页面有两次FB分享时只有一个分享有效
    eventClick(selector, url, onSuccess, layerIndex) {
        $(document).on('click', selector, async () => {
            if (layerIndex !== undefined) {
                layer.close(layerIndex);
            }
            FB.ui({ // eslint-disable-line
                method: 'share',
                href: url,
                display: 'popup',
                // mobile_iframe: true,
            }, (res) => {
                onSuccess(res);
            });
        });
    },
    facebook({
        selector,
        url,
        layerIndex,
        appId = 900125666754558, // 线上id  // 测试id 361131840691772
        version = 'v3.1',
        onSuccess = () => {},
    }) {
        const fjs = document.getElementsByTagName('script')[0];
        if (document.getElementById('facebook-jssdk')) {
            this.eventClick(selector, url, onSuccess, layerIndex);
            return;
        }
        const js = document.createElement('script');
        js.id = 'facebook-jssdk';
        js.src = 'https://connect.facebook.net/en_US/sdk.js';
        fjs.parentNode.insertBefore(js, fjs);
        window.fbAsyncInit = () => {
            FB.init({ appId, status: true, cookie: true, oauth: true, xfbml: true, version, }); // eslint-disable-line
            this.eventClick(selector, url, onSuccess, layerIndex);
        };
    },
    twitter({
        selector,
        url,
        desc = '',
        title = '',
        layerIndex,
        onClose = () => {},
    }) {
        const { url: gUrl, desc: gDesc, title: gTitle } = this.encode({ url, desc, title });
        $(document).on('click', selector, async () => {
            layer.close(layerIndex);
            window.open(
                `https://twitter.com/intent/tweet?text=${gTitle} ${gDesc}&url=${gUrl}`,
                '_blank',
                'location=yes,left=0,top=0,height=540,width=650,scrollbars=yes,status=yes',
            );
        });
    },
    mshare(full, closeAll) {
        const that = this;
        if (!$('.fissionShareBox').length) {
            const text = full === 'nofull' ? 'promotion.fission_alert_no_full' : 'promotion.fission_alert_index_share';
            const indexshareStr = `
                <div class="fiss_share">
                    <p class="font-30">${trans(text)}</p>

                    <div class="fiss_shareBox">
                        <div class="fiss_sharebtns">
                            <a class="shares-btn fiss_share-fb" href="javascript:;">
                                <i class="ic_share ic_fb"></i>Facebook
                            </a>
                            <a class="shares-btn fiss_share-whatsapp" href="${this.shareLink('whatsapp')}" type="whatsapp">
                                <i class="ic_share ic_wh" type="whatsapp"></i>WhatsApp
                            </a>
                            <a class="shares-btn fiss_share-tw" href="javascript:;">
                                <i class="ic_share ic_tw"></i>Twitter
                            </a>
                            <a class="shares-btn fiss_share-messenger" href="${this.shareLink('messenger')}" type="messenger">
                                <i class="ic_share ic_msg" type="messenger"></i>Messenger
                            </a>
                            ${Clipboard.isSupported() ? `
                            <a class="shares-btn fiss_share-copy" href="javascript:;">
                                <i class="ic_share ic_cl"></i>${trans('promotion.fission_copy_link_btn')}
                            </a>
                            ` : ''}
                        </div>
                    </div>
                </div>

                <a href="javascript:;" class="js-fission-closeBtn font-34">${trans('order.cancel')}</a>
            `;

            const layerIndex = this.initLayer('fissionAlert_indexShare', indexshareStr, null, 'fissionShareBox', true, 'pop', !closeAll);

            // 分享
            this.facebook({
                selector: '.fiss_share-fb',
                url: this.shareLink('fb'),
                layerIndex,
            });

            this.twitter({
                selector: '.fiss_share-tw',
                url: this.shareLink('tw'),
                layerIndex,
            });

            // 复制分享链接
            new Clipboard('.fiss_share-copy', {
                text() {
                    return that.shareLink();
                }
            }).on('success', () => {
                layer.msg(trans('promotion.fission_copy_success'));
                layer.close(layerIndex);
            });

            setTimeout(() => {
                $('.fiss_share-whatsapp, .fiss_share-messenger').on('click', (e) => {
                    layer.close(layerIndex);
                    let type = $(e.target).attr('type');
                    switch (type) {

                    case 'whatsapp':
                        type = 'WhatsApp';
                        break;
                    default:
                        type = 'Messenger';
                        break;
                    }

                    // 调用判断是否安装app功能
                    toAppLink(() => {
                        layer.msg(trans('promotion.fission_share_noapp', [type]), {
                            end() {
                                if (!closeAll) layer.closeAll();
                            }
                        });
                    });
                });
            }, 300);
        }
    },
    appshare() {
        window.location.href = `gbwebaction://share?share_title=${
            encodeURIComponent(window.shareInfo.title)
        }&share_doc=${
            encodeURIComponent(window.shareInfo.desc)
        }&share_image=${
            encodeURIComponent(window.shareInfo.image)
        }&share_type=${
            'Facebook,WhatsApp,Twitter,FacebookMessenger,VK,GooglePlus,Pinterest,Copy'
        }&share_url=${
            encodeURIComponent(this.shareLink())
        }&share_click=fissionAlert.appShareClick&share_finish=fissionAlert.appShareFinish&share_copyfirst=fissionAlert.appShareCopyFirst`;
    },
    indexshare(full, closeAll) {
        if (window.fisnSTORE.appShareSign) {
            this.appshare();
        } else {
            this.mshare(full, closeAll);
        }
    },
    setup() {
        const leavepageStr = `
            <p>${trans('promotion.fission_alert_setup')}</p>
            <span class="js-fission-setup">${trans('promotion.fission_alert_setup_btn')}</span>
        `;
        this.initLayer('fissionAlert_setup', leavepageStr, (index) => {
            const setupBtn = $('.js-fission-setup');
            const second = $('.js-fission-setup').find('em');
            let secondNum = 3;
            second.text(secondNum);

            setupBtn.on('click', () => {
                const { lang } = win.location.href;
                // 集满点击按钮
                win.location.href = `${win.GLOBAL.DOMAIN_MAIN}/money-bag.html?type=app${lang ? `&lang=${lang}` : ''}`;
                layer.close(index);
            });

            const timer = setInterval(() => {
                secondNum -= 1;
                second.text(secondNum);
                if (secondNum <= 0) {
                    // 集满倒计时
                    const { lang } = win.location.href;
                    win.location.href = `${win.GLOBAL.DOMAIN_MAIN}/money-bag.html?type=app${lang ? `&lang=${lang}` : ''}`;
                    clearInterval(timer);
                    layer.close(index);
                }
            }, 1000);
        });
    },
    leavepage() {
        const interval = $('.js-fission-time').data('end');
        if (interval) {
            const leavepageTip = interval ? `<p>
                ${trans('promotion.fission_alert_leavepage', [`<b id="leavepageMsg" data-end="${interval}"></b>`])}
            </p>` : '';
            let timer = null;
            const leavepageStr = `
                ${leavepageTip}
                <span class="line js-fission-leave">${trans('promotion.fission_alert_leavepage_btnline')}</span>
                <span class="js-fission-continue">${trans('promotion.fission_alert_leavepage_btnstron')}</span>
            `;
            this.initLayer('fissionAlert_leavepage', leavepageStr, (index) => {
                if (interval) {
                    timer = new Timer();
                    timer.add($('#leavepageMsg'), { interval: 'end' });
                }
                $('.js-fission-leave').on('click', () => {
                    // 离开页面
                    if (interval) {
                        timer.destroy();
                    }
                    win.location.href = 'gearbest://webFinish';
                    layer.close(index);
                });

                $('.js-fission-continue').on('click', () => {
                    // 继续操作 留在当前页面
                    if (interval) {
                        timer.destroy();
                    }
                    layer.closeAll();
                });
            });
        } else {
            win.location.href = 'gearbest://webFinish';
        }
    },
    login(url) {
        let extraBtnStr = '';
        if (win.fisnSTORE.fbLoginBtn) {
            extraBtnStr = '<a href="javascript:;" class="logbtn fb js-fission-login-fb">Facebook</a>';
        } else {
            extraBtnStr = `<a href="javascript:;" class="logbtn js-fission-login">${trans('promotion.fission_alert_login_btn')}</a>`;
        }
        const loginStr = `
            <p>${trans(`promotion.${win.fisnSTORE.status.indexOf('B') > 0 ? 'fission_alert_login_help' : 'fission_alert_login'}`)}</p>
            ${extraBtnStr}
        `;

        this.initLayer('fissionAlert_login', loginStr, (index) => {
            $('.js-fission-login').on('click', () => {
                // 登陆逻辑
                win.location.href = url;
                layer.close(index);
            });

            $('.js-fission-login-fb').on('click', () => {
                // 登陆逻辑
                win.location.href = window.fisnSTORE.appVerSign === 2 ? 'gearbest://login?type=2' : 'gearbest://login?type=facebook';
                layer.close(index);
            });
        });
    },
    detail(dismantledAmount = 0, redPacketAmount = 0, assistList = []) {
        const rate = divide(dismantledAmount, redPacketAmount) * 100;

        const detailStr = `
            <h6>
                <span class="js-currency" data-currency="${dismantledAmount}"></span>
                <strong class="font-30">${trans('promotion.fission_alert_detail_title')}</strong>
            </h6>
            <div class="content">
                <div class="progressBar">
                    <p class="progressTip font-30" style="left: ${rate < 45 ? rate : 45}%;">
                        <span class="js-currency" data-currency="${sub(redPacketAmount, dismantledAmount)}"></span>
                        ${trans('promotion.fission_alert_detail_still')}
                    </p>
                    <p class="progressBar_rate">
                        <span style="width: ${rate}%;"></span>
                    </p>
                </div>
                <ul class="detailList">${assistList.map(item => `
                    <li class="detailList_item">
                        <span class="detailList_itemImg font-40">
                            ${item.userImage ? `
                                <img class="js-lazyload"
                                src="${staticAsset('/img/activity/fission/default_avatar.png')}" data-lazy="${item.userImage}">
                            ` : (item.userEmail ? item.userEmail.substr(0, 1).toUpperCase() : 'G')}
                        </span>
                        <div class="detailList_itemCon">
                            <p class="email font-30">${item.userEmail}</p>
                            <p class="help font-30">
                                ${trans('promotion.fission_alert_detail_help')}
                                <span class="js-currency" data-currency="${item.helpAmount}"></span>
                            </p>
                        </div>
                    </li>
                `).join('')}</ul>
            </div>
            <p class="detaileBtnBox">
                <a href="javascript:;" class="fission_inviteBtn js-fission-detaileBtn">
                <i class="icon-share"></i> <span class="font-30">${trans('promotion.fission_invite_text')}</span>
                </a>
            </p>
        `;

        this.initLayer('fissionAlert_detail', detailStr, () => {
            $('.js-fission-detaileBtn').on('click', () => {
                this.indexshare('', 'notall');
            });

            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $('.fissionAlert_detail')[0]
            });
        });
    },
    initLayer(conClass, content, fn, popClass = 'fission_alertBox', shadeClose = false, anim = 'scale', closeAll = true) {
        let layerIndex = 0;
        layer.open({
            type: 1,
            className: popClass,
            shadeClose,
            anim,
            content: `
                <span class="close_btn js-fission-closeBtn"><i class="icon-closed"></i></span>
                <div class="${conClass}">${content}</div>
            `,
            success(elem) {
                layerIndex = $(elem).attr('index');
                // 关闭当前弹窗
                $('.js-fission-closeBtn').on('click', () => {
                    if (closeAll) {
                        layer.closeAll();
                    } else {
                        layer.close(layerIndex);
                    }
                });

                if (fn) fn(layerIndex);
            }
        });
        return layerIndex;
    },
    toDowApp() {
        const todowStr = `
            <p>${trans('promotion.fission_alert_to_dow_txt')}</p>
            <a href="javascript:;" class="logbtn js-fission-todowapp">${trans('promotion.fission_alert_to_dow')}</a>
        `;
        this.initLayer('fissionAlert_login', todowStr, (index) => {
            $('.js-fission-todowapp').on('click', () => {
                // 登陆逻辑
                win.location.href = `${win.GLOBAL.DOMAIN_MAIN}/spread-app.html`;
                layer.close(index);
            });
        });
    },
    bindEmail(email) { // 绑定邮箱
        layer.open({
            type: 1,
            className: 'fissionAlert_bindEmail',
            anim: 'scale',
            content: `
                <p class="title">${trans('promotion.fission_alert_bind_email_title')}</p>
                <div class="content">
                    <div class="item">
                        <p class="itemTitle">${trans('promotion.fission_alert_bind_email_pwd')}:</p>
                        <input type="password" class="inputItem js-pwdInp" />
                        <p class="itemTip js-pwdTip"></p>
                    </div>
                    <div class="item">
                        <p class="itemTitle">${trans('promotion.fission_alert_bind_email_newemail')}:</p>
                        <input type="text" class="inputItem js-emailInp" />
                        <p class="itemTip js-emailTip"></p>
                    </div>
                    <a href="javascript:;" class="btn">${trans('promotion.fission_alert_bind_email_save')}</a>
                </div>
            `,
            success(elem) {
                const layerIndex = $(elem).attr('index');
                const $box = $(elem);
                const pwdInp = $box.find('.js-pwdInp');
                const emailInp = $box.find('.js-emailInp');
                const pwdTip = $box.find('.js-pwdTip');
                const emaildTip = $box.find('.js-emailTip');
                $box.on('click', '.btn', async () => {
                    if (!pwdInp.val().trim()) {
                        pwdInp.addClass('err');
                        pwdTip.text(trans('promotion.fission_alert_bind_email_tip_pwd'));
                    } else if (!emailInp.val().trim()) {
                        emailInp.addClass('err');
                        emaildTip.text(trans('promotion.fission_alert_bind_email_tip_email'));
                    } else {
                        const { status, data, msg } = await servicePaymetResultsReplaceEmail.http({
                            errorPop: false,
                            data: {
                                oldEmail: email,
                                oldPassword: pwdInp.val(),
                                newEmail: emailInp.val()
                            }
                        });
                        if (status === 0) {
                            fissionAlert.activate(emailInp.val());
                            layer.close(layerIndex);
                        } else if (data.innerCode === 70009) { // 密码错误
                            pwdInp.addClass('err');
                            pwdTip.text(trans('promotion.fission_alert_bind_email_tip_pwderr'));
                        } else if (data.innerCode === 70016) { // 邮箱不存在
                            emailInp.addClass('err');
                            emaildTip.text(trans('promotion.fission_alert_bind_email_tip_emailerr'));
                        } else {
                            layer.msg(msg);
                        }
                    }
                });
                pwdInp.on('focus', () => {
                    pwdInp.removeClass('err');
                    pwdTip.text('');
                    emailInp.removeClass('err');
                    emaildTip.text('');
                });
                emailInp.on('focus', () => {
                    emailInp.removeClass('err');
                    emaildTip.text('');
                    pwdInp.removeClass('err');
                    pwdTip.text('');
                });
            }
        });
    },
    activate(email) { // 发送激活邮件
        layer.open({
            type: 1,
            shadeClose: false,
            className: 'fissionAlert_activate',
            anim: 'scale',
            content: `
                <div class="content">
                    <p class="title">${trans('promotion.fission_alert_activate_title')}</p>
                    <div class="text">
                        ${trans('promotion.fission_alert_activate_note', [email])}
                    </div>
                </div>
                <p class="btnBox">
                    <a href="javascript:;" class="alertBtn js-alertBtn1">${trans('promotion.fission_alert_activate_ok')}</a>
                    <a href="javascript:;" class="alertBtn js-alertBtn2">${trans('promotion.fission_alert_activate_resend')}</a>    
                </p>
            `,
            success(elem) {
                const layerIndex = $(elem).attr('index');
                const $box = $(elem);
                const btn1 = $box.find('.js-alertBtn1');
                const btn2 = $box.find('.js-alertBtn2');
                btn1.on('click', () => {
                    layer.close(layerIndex);
                });
                btn2.on('click', async () => {
                    const { msg } = await sendActivationEmail.http({
                        data: {
                            email
                        }
                    });
                    layer.close(layerIndex);
                    layer.msg(msg);
                });
            }
        });
    },
    // ----- 静态处理方法 -----
    shareLink(type) {
        const shareId = win.activityRecordId;
        const thisLang = getUrlQuery(win.location.href).languages || Cookies.get('gb_lang') || '';
        const origUrl = `${win.GLOBAL.DOMAIN_MAIN}/money-bag/${shareId}/${thisLang}`;
        const encodeLink = encodeURIComponent(origUrl);

        switch (type) {
        case 'whatsapp':
            return `whatsapp://send?text=${trans('promotion.fission_whatsapp_text')} ${encodeLink}`;
        case 'messenger':
            return `fb-messenger://share/?link=${encodeLink}&app_id=624353394279966`;
        default:
            return origUrl;
        }
    },
    encode({ ...rest }) {
        const result = {};
        Object.entries(rest).forEach(([key, val]) => {
            result[key] = encodeURIComponent(val);
        });
        return result;
    },
    // ----- 挂载到 window 上的 app 回调 -----
    appShareClick(shareType) { // 点app分享原生触发
        window.dataLayer.push({ event: `triggerAppShareClick_${shareType}` });
    },
    appShareFinish(shareType, status) { // 分享成功回调
        // console.log(shareType, status);
    },
    appShareCopyFirst(appId, appName) { // copy 后第一次打开的app
        win.appShareCopyFirstVal = `${appName}_${appId}`;
        window.dataLayer.push({ event: 'triggerAppShareCopyFirst' });
    }
};

export default fissionAlert;
