import PubSub from 'pubsub-js';
import { fissionRecommend } from 'js/service/promotion';
import { trans } from 'js/core/translate.js';
import BackTop from 'modules/back_top/back_top.js';
import itemArt from './index.art';
import './index.css';

export default (isApp) => {
    const recommendObj = {
        recommendBox: $('.js-fission-recommendBox'), // 推荐位顶层盒子
        goodsList: null,
        loadingDom: null,
        isfirst: true,
        isLoading: false,
        pageNum: 1,
        init() {
            this.getData();
            // 页面置顶
            new BackTop();
        },
        initTemplate(itemData) {
            const tempStr = `
                <h6 class="fission_recommendTitle font-50">${trans('promotion.fission_recommend_title')}</h6>
                <ul class="fission_recommendList js-fission-recommendList"></ul>
                <p class="fission_recommendLoading js-fission-recommendLoading">
                    <i></i><i></i><i></i>
                </p>
            `;
            this.recommendBox.html(tempStr);
            this.goodsList = $('.js-fission-recommendList');
            this.loadingDom = $('.js-fission-recommendLoading');
            this.isfirst = false;
            this.appendItem(itemData);
            this.continueLoad();
        },
        continueLoad() {
            $(window).scroll(() => {
                const wScrollY = window.scrollY; // 当前滚动条位置
                const wInnerH = window.innerHeight; // 设备窗口的高度（不会变）
                const bScrollH = document.body.scrollHeight; // 滚动条总高度
                if (wScrollY + wInnerH + 5 >= bScrollH) {
                    if (!this.isLoading) {
                        this.isLoading = true;
                        this.loadingDom.show();
                        this.getData();
                    }
                }
            });
        },
        async getData() {
            const that = this;
            const resData = await fissionRecommend.http({
                params: {
                    page: that.pageNum,
                }
            });
            if (resData.status === 0 && resData.data.length > 0) { // 数据请求成功 并且有数据
                if (this.isfirst) {
                    // 更改推荐位展示状态
                    this.initTemplate(resData.data);
                } else {
                    this.appendItem(resData.data);
                }
            } else {
                this.loadingDom.hide();
            }
        },
        appendItem(itemData) {
            this.goodsList.append(itemArt({ itemData, isApp }));
            this.pageNum += 1;
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: this.goodsList[0]
            });
            this.loadingDom.hide();
            this.isLoading = false;
        }
    };

    recommendObj.init();
};
