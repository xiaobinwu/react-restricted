/**
 * 新增第三方登录中间跳转页， 用来获取第三方code
 *
 */

import Cookies from 'js/utils/cookie';

$(document).ready(() => {
    const loginCode = $('#js-accept-code').val();
    const loginToken = $('#js-accept-token').val();
    if (loginCode) {
        Cookies.set('sing_code', loginCode);
    } else if (loginToken) {
        Cookies.set('sing_token', loginToken);
    } else {
        const urlHashList = window.location.hash.slice(1).split('&');
        urlHashList.forEach(($value) => {
            const [rulKey, rulValue] = $value.split('=');
            if (['token', 'access_token'].indexOf(rulKey) >= 0) {
                Cookies.set('sing_token', rulValue);
            }
        });
    }
    window.close();
});
