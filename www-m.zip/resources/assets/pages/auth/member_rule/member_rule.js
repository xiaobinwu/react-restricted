/**
 * 会员中心FAQ
 * @author  huangxiaoguo (huangxiaoguo@globalegrow.com)
 * @date    2018/08/21
 */

import 'js/bootstrap';
import PubSub from 'pubsub-js';
import { trans } from 'js/core/translate.js';
import UserTrack from 'js/track/define/user';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import './member_rule.css';

let userTrack = null;
// 添加埋点
userTrack = new UserTrack({
    type: 'rule',
    page: true,
    extendData: { b: 'e', s: 'e20' }
});
userTrack.run();

PubSub.subscribe('nativeReady', () => {

    const infoList = $('.js-memberRuleInfoHide');
    // console.log(infoList);
    const moreHtml = `<p class="memberRuleInfo_more font-28">
        <span class = "js-memberRuleInfoMore" > 
        <b>${trans('user.member_rule_more')}</b>
        <i class = "icon-arrow_down font-28 js-ruleInfoMoreIcon" ></i> 
        </span></p>`;
    infoList.each((index, item) => {
        if ($(item).height() > $(item).next().height()) {
            $(item).closest('.memberRuleInfo').append(moreHtml);
        }
    });

    $('.js-memberRuleInfoMore').on('click', (e) => {
        const $target = $(e.currentTarget);
        const $ruleMoreIcon = $target.find('.js-ruleInfoMoreIcon');
        const $ruleInfoShow = $target.closest('.memberRuleInfo_more').prev();
        const infoShowH = $ruleInfoShow.prev().height();
        if ($ruleMoreIcon.hasClass('iconArrow_up')) {
            $ruleMoreIcon.removeClass('iconArrow_up');
            $target.find('b').text(`${trans('user.member_rule_more')}`);
            $ruleInfoShow.css({
                'max-height': '1.52rem',
                '-webkit-line-clamp': '3',
            });
        } else {
            $ruleMoreIcon.addClass('iconArrow_up');
            $target.find('b').text(`${trans('user.member_rule_collapse')}`);
            $ruleInfoShow.css({
                'max-height': infoShowH,
                '-webkit-line-clamp': 'inherit',
            });
        }

    });
});
