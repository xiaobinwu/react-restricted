/**
 * 会员中心首页
 * @author  huangxiaoguo (huangxiaoguo@globalegrow.com)
 * @date    2018/08/15
 */

// import { servicememeberCenter } from 'js/service/user';
// import { getULike } from 'js/service/other';
// import { trans } from 'js/core/translate.js';
import 'js/bootstrap';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import PubSub from 'pubsub-js';
import Rotate from 'component/rotate';
import layer from 'layer';
import isLogin from 'js/core/user/isLogin';
import appSdk from 'js/core/app.sdk';
import { getUrlQuery } from 'js/utils';
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';
import { serviceGetSpins } from 'js/service/user';
import getRaffle from 'js/core/user/userRaffle.js';

import lotteryDialog from './lotteryDialog.art';
import dialogGiftBg from './img/dialog-gift-bg.png';

import './lottery.css';

const { IS_APP } = appSdk;

// 判断用户是否登陆（Promise对象）
const userIsLogin = isLogin();
const query = getUrlQuery(window.location.href);

runtime.trans = trans;

// 进入页面
PubSub.subscribe('nativeReady', () => {
    $('.turntable').each((index, item) => {
        new Turntable(item);
    });
});


class Turntable {
    constructor(parent = null) {
        this.priceIndex = {}; // 奖品索引
        this.isArrowLottery = true; // 是否允许再次抽奖
        this.isLottery = false; // 是否抽过奖（兼容APP）；
        this.upgradeGiftUrl = $('.js-upgradeGiftUrl').val();
        this.$parent = $(parent);
        this.$winnerList = this.$parent.next();
        this.activityId = query.lotteryId || '';
        this.init();
        this.bindEvent();
    }

    /**
     * 返回支持的css属性名，用于js操作样式
     */
    static getSupportStyle() {
        const bodyStyle = document.body.style;
        const TRANSFORM = ['transform', 'webkitTransform', 'MozTransform', 'msTransform', 'OTransform'];
        const transform = TRANSFORM.find(item => bodyStyle[item] !== undefined);
        return { transform };
    }

    /**
     * 弹出框
     */
    static dialog(config) {
        config = Object.assign({
            content: '',
            type: '',
            share: false,
            skin: 'turntable',
            shade: 'background-color: rgba(0,0,0,.7)',
            btn: false,
        }, config);

        config.content =
            `<div class="contentWrap contentWrap-${config.type}" data-type="${config.type}">
                <div class="content">${config.content}</div>
            </div>
            <div class="close js-close  giftDialog_close" ><i class="icon-closed font-36"></i></div > `;

        layer.open(config);
    }

    /**
     * 初始化
     */
    async init() {
        // 兼容性测试
        const { transform } = Turntable.getSupportStyle();
        const $prizeList = this.$parent.find('.turntable_prizeList');
        const $prizeItem = $prizeList.find('.turntable_prizeItem');
        const $prizeImg = $prizeList.find('.turntable_prizeImg');
        const $prizeTitle = $prizeList.find('.turntable_prizeTitle');

        const prizeCount = $prizeItem.length;
        const unitAngle = 360 / prizeCount;
        const unitSkew = 90 - unitAngle;
        const firstAngle = (unitAngle / 2) + 89.99; // 这里的89.99原先为90，但是会在app内嵌页面出现兼容问题（当奖项为3个的时候）

        this.prizeCount = prizeCount;

        // 分区样式
        $prizeItem.each((index, elem) => {
            elem.style[transform] = `rotate(${(unitAngle * index) - firstAngle}deg) skew(${unitSkew}deg)`;
            this.priceIndex[elem.dataset.order] = index;
        });

        // 分区内图片样式
        $prizeImg.each((index, elem) => {
            elem.style[transform] = `skew(${-unitSkew}deg, 0) rotate(${firstAngle}deg) translate(-50%, -267%)`;
        });

        // 分区内文本样式
        $prizeTitle.each((index, elem) => {
            elem.style[transform] = `skew(${-unitSkew}deg, 0) rotate(${firstAngle}deg) translate(-50%, -350%)`;
        });

        // 一切属性设置好后才显示转盘
        this.$parent.css('opacity', 1);

        // 新建旋转实例
        this.rotate = new Rotate({
            element: this.$parent.find('.turntable_prizeList')[0],
            duration: 3000,
        });

        // 确保用户登陆后才请求积分和抽奖信息
        if (IS_APP || await userIsLogin) {
            this.updateSpins();
        }
    }

    /**
     * 更新剩余抽奖次数
     * @return {Promise<void>}
     */
    async updateSpins() {
        const { status, data } = await serviceGetSpins.http({ params: { activityId: this.activityId } });
        const $turntableAxle = $('.js-turntableAxle');
        if (status === 0) {
            $('.js-rutntableTip').html(data.count > 0 ?
                trans('user.turntable_yes_tip') :
                trans('user.turntable_no_tip'));
            $('.js-rutntableTitle').html(data.count > 0 ?
                `<span>${trans('user.turntable_go_try')}</span>` :
                `<a href="${this.upgradeGiftUrl}">${trans('user.turntable_go_upgrade')}</a>`);
            if (data.count > 0) {
                $turntableAxle.removeClass('turntable_axle-disable');
            } else {
                $turntableAxle.addClass('turntable_axle-disable');
                if (IS_APP && this.isLottery) {
                    window.location.href = 'gearbest://refreshVipCenter';
                }
            }
        }
    }


    /**
     * 事件定义
     */
    bindEvent() {
        const self = this;
        /**
         * 点击抽奖
         */
        this.$parent.find('.turntable_axle').on('tap', () => {
            if (!self.isArrowLottery) return;
            self.isArrowLottery = false;
            this.lottery();
        });

        // 关闭弹窗
        $(document).on('click', '.layui-m-layer-turntable .js-close', (e) => {
            e.preventDefault();
            layer.closeAll();
        });
    }

    /**
     * 抽奖
     */
    async lottery() {
        const self = this;
        self.isArrowLottery = false;

        const reqData = { activityId: self.activityId };
        if (IS_APP) reqData.type = 'app';

        const { status, msg, data } = await getRaffle({
            data: reqData
        });

        if (status === 0) {
            this.isLottery = true;
            const prizeIndex = this.priceIndex[data.order];
            this.rotate.run({
                animateTo: ((360 / this.prizeCount) * (this.prizeCount - prizeIndex)) + (360 * 5),
                onEnd() {
                    Turntable.dialog({
                        content: lotteryDialog({ dialogGiftBg, ...data }),
                        share: true,
                    });
                    self.isArrowLottery = true;
                }
            });

            this.updateSpins();
        } else if (data.redirectUrl) {
            window.location.href = data.redirectUrl;
        } else {
            Turntable.dialog({ content: msg });
            self.isArrowLottery = true;
        }
    }
}
