<template>
    <div class="snsLoginComp">
        <div class="snsLoginTip">
            <span class="snsLoginTip_text font-24">
                {{$trans('login.or_connect_via')}}
            </span>
        </div>
        <div class="snsLoginList">
            <a v-for="item in socialTypeList" :key="item.type" href="javascript:;" data-gapiattached="true" class="snsLoginItem js-thirdLoginBtn"
            v-bind:class="{ 'snsLoginItem-google': item.type===2,
                'snsLoginItem-facebook': item.type===1,
                'snsLoginItem-vkontakte': item.type===5 }"
            v-bind:data-type="item.type">
                <i class="font-60"
                v-bind:class="{ 'icon-google': item.type===2,
                    'icon-fb': item.type===1,
                    'icon-vk': item.type===5 }" ></i>
            </a>
            <!-- <a href="javascript:;" data-gapiattached="true" class="snsLoginItem snsLoginItem-google js-thirdLoginBtn"  data-type="2">
                <i class="icon-google font-60"></i>
            </a>
            <a href="javascript:;" class="snsLoginItem snsLoginItem-facebook js-thirdLoginBtn" data-type="1">
                <i class="icon-fb font-60"></i>
            </a> -->
        </div>
        <bind-email v-model="bindComData.showBindEmail" :bindData="bindComData.bindData"></bind-email>
        <div class="gb-hide js-prejudging">
            <form class="form prejudgingForm" action="" id="js-prejudgingForm">
                <span class="close-prejudging js-close-preBtn">
                    <i class="icon-closed"></i>
                </span>
                <div class="form_group form_itemAgree">
                    <div class="form_data form_data-prefix">
                        <div class="formAgree_text form_text font-24"
                            v-html="$trans('login.registration_terms_eu', ['/about/terms-and-conditions', '/about/privacy-policy'])">
                        </div>
                        <span class="form_prefix js-checkAgree" data-state="false" @click="checkAgree = !checkAgree">
                            <i v-if="checkAgree" class="icon-check formAgree_checked"></i>
                            <i v-else class="icon-check"></i>
                        </span>
                    </div>
                </div>
                <div class="form_group form_itemAgree">
                    <div class="form_data form_data-prefix">
                        <div class="formAgree_text form_text font-24"
                            v-html="$trans('login.registration_terms_confirm_eu', ['/about/privacy-policy'])">
                        </div>
                        <span class="form_prefix js-checkConfirm" data-state="false" @click="checkConfirm = !checkConfirm">
                            <i v-if="checkConfirm" class="icon-check formAgree_checked"></i>
                            <i v-else class="icon-check"></i>
                        </span>
                    </div>
                </div>

                <div class="form_button">
                    <button type="button"
                            class="btn btnLight js-checkFormBtn disabled"
                            :disabled="!checkFormBtn"
                            href="javascript:;">
                        {{ submitBtn }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
    import { serviceSocialTypeList } from 'js/service/auth.js';
    import SocialLogin from '../SocialLogin';
    import bindEmail from './bindEmail.vue';

    export default {
        components: {
            bindEmail
        },
        data() {
            const { $trans } = this;
            return {
                bindComData: {
                    bindData: {},
                    showBindEmail: false,
                },
                checkAgree: false,
                checkConfirm: false,
                disabled: false,
                checkFormBtn: false,
                submitBtn: $trans('user.wallet_send'),
                socialTypeList: [],
            };
        },
        watch: {
            checkAgree() {
                if (this.checkAgree === true && this.checkConfirm === true) {
                    this.checkFormBtn = true;
                } else {
                    this.checkFormBtn = false;
                }
            },
            checkConfirm() {
                if (this.checkAgree === true && this.checkConfirm === true) {
                    this.checkFormBtn = true;
                } else {
                    this.checkFormBtn = false;
                }
            }
        },
        async mounted() {
            const res = await serviceSocialTypeList.http();
            this.socialTypeList = res.data;
            this.$nextTick(() => {
                this.socialLogin = new SocialLogin({
                    bindEmail: (postData) => {
                        this.bindComData.bindData = postData;
                        this.bindComData.showBindEmail = true;
                    }
                });
            });
        }
    };
</script>

<style>
    @import 'common/css/variable.css';
    .snsLoginTip{
        position: relative;
        text-align: center;
/*        &:before{
            content: ' ';
            width: 100%;
            height: rem(2);
            position: absolute;
            top: 50%;
            left: 0;
            margin-top: rem(-2);
            background-color: var(--splitC);
        }*/
        .snsLoginTip_text{
            position: relative;
            color: var(--color-text-primary);
            line-height: rem(80);
            background-color: var(--color-main-bg);
            padding: 0 rem(20);
        }
    }
    .snsLoginItem{
        display: inline-block;
        border-radius: 50%;
        width: rem(96);
        height: rem(96);
        line-height: rem(96);
        margin: 0 rem(40);
        color: var(--color-float-btn);
    }
    .snsLoginItem-facebook{
        background-color: var(--color-facebook);
    }
    .snsLoginItem-google{
        background-color: var(--color-google);
    }
    .snsLoginItem-vkontakte{
        background-color: var(--color-vk);
    }

    .formAgree_checked{
        color: var(--color-warning);
    }
    .formAgree_text {
        border: none;
        padding-bottom: rem(10);
        padding-top: rem(10);
        height: auto;
        margin-bottom: rem(20);
    }
    .form_itemAgree{
        height: auto;
        margin-bottom: 0;
    }
    .form_prefix{
        height: auto;
    }
    .prejudgingForm{
        padding-top: rem(70);
        position: relative;
        .close-prejudging{
            position: absolute;
            right: rem(20);
            top: rem(10);
        }
    }
    .snsLoginList{
        text-align: center;
    }
</style>
