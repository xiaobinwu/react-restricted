<template>
    <div class="emailSuffix" v-show="56 && suffixArr.length > 0">
        <ul class="emailSuffixBox">
            <li class="emailSuffixItem font-28" v-for="(suffixItem, suffixIndex) in suffixArr" :key="suffixIndex" @click="selectItem(suffixItem)">{{ suffixItem }}</li>
        </ul>
    </div>
</template>

<script>
import { getCountryCode } from 'js/core/currency.js';

export default {
    props: ['inputData'],
    data() {
        return {
            globalEmailSuffix: [
                '@gmail.com',
                '@yahoo.com',
                '@hotmail.com',
                '@outlook.com'
            ],
            localEmail: {
                US: '@aol.com',
                RU: [
                    '@yandex.com',
                    '@inbox.ru',
                    '@mail.ru'
                ],
                IT: '@libero.it',
                BR: '@sinos.net',
                DE: '@gmx.de',
                FR: '@orange.fr'
            },
            localIp: 'US',
            suffixArr: []
        };
    },
    watch: {
        inputData(value) {
            this.checkValue(value);
        }
    },
    methods: {
        checkValue(enterData) {
            if (enterData && enterData.substr(enterData.length - 1, 1) === '@') {
                this.suffixtion(enterData.substr(0, enterData.length - 1));
            } else {
                this.suffixtion();
            }
        },
        suffixtion(frontData) { // 组建列表数据
            const vm = this;
            vm.suffixArr = [];
            if (frontData) {
                vm.globalEmailSuffix.forEach((item) => {
                    vm.suffixArr.push(frontData + item);
                });
                if (Array.isArray(vm.localEmail[vm.localIp])) {
                    vm.localEmail[vm.localIp].forEach((localItem) => {
                        vm.suffixArr.push(frontData + localItem);
                    });
                } else if (vm.localEmail[vm.localIp]) {
                    vm.suffixArr.push(frontData + vm.localEmail[vm.localIp]);
                }
            }
        },
        selectItem(value) {
            this.$parent.formData.email.value = value;
        }
    },
    async created() {
        this.localIp = await getCountryCode();
        this.checkValue(this.inputData);
    }
};
</script>

<style>
    @import 'common/css/variable.css';
    .emailSuffix {
        position: relative;
        height: 0;
    }
    .emailSuffixBox {
        position: absolute;
        top: rem(-2);
        left: 0;
        z-index: 1;
        width: 100%;
        background: var(--color-main-bg);
        border: rem(2) solid var(--color-border);
    }
    .emailSuffixItem {
        border-top: rem(2) solid var(--color-border);
        padding: rem(20);
        line-height: rem(40);
        color: var(--color-text-primary);
        &:first-child{
            border-top: none;
        }
    }
</style>
