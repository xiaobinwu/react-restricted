<template>
    <ul class="signInTab horizontal-view content-around">
        <li class="signIn_item">
            <router-link class="signIn_link"
                         :to="{name: 'authSignIn', query: { fb_token: fbToken }}"
                         :class="{'signIn_link-active': 'authSignIn' === routerName}"
                         tag="a"> {{$trans('login.sign_in_tab')}}
            </router-link>
        </li>
        <li class="signIn_item">
            <router-link class="signIn_link"
                         :to="{name: 'authRegister', query: { fb_token: fbToken }}"
                         :class="{'signIn_link-active': 'authRegister' === routerName}"
                         tag="a"> {{$trans('login.register_tab')}}
            </router-link>
        </li>
    </ul>
</template>

<script>
    export default {
        computed: {
            fbToken() {
                return this.$route.query.fb_token;
            },
            routerName() {
                return this.$route.name;
            }
        },
    };
</script>

<style>
    @import 'common/css/variable.css';
    .signInTab{
        .signIn_link{
            display: block;
            padding: rem(20) 0;
            color: var(--color-text-placeholder);
            white-space: nowrap;
            text-align: center;
            box-sizing: border-box;
            font-weight: bold;
            @mixin font 36;
        }
        .signIn_link-active{
            color: var(--color-text-primary);
            border-bottom: rem(8) solid var(--color-primary);
        }
    }
</style>
