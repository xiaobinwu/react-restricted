<template>
    <transition name="fade">
        <div class="bindEmailBox" v-if="value">
            <i class="icon-closed bindEmail_close" @click="backLogin"></i>
            <div class="bindEmailBox_content">
                <h2 class="bindEmail_title tc font-48">
                    {{$trans('login.link_email')}}
                </h2>
                <p class="bindEmail_tip font-24 tc">{{$trans('login.link_login_tip')}}</p>
                <form class="form bindForm">
                    <div class="form_group required" :class="{error: formData.email.hasError}">
                        <div class="form_data form_data-prefix">
                            <input v-model="formData.email.value"
                                   type="email"
                                   class="form_text"
                                   :disabled="!checkEmailInput"
                                   :readonly="status === 3"
                                   :placeholder="$trans('login.type_email_address')">
                                <span class="form_prefix">
                                <i class="icon-mail"></i>
                            </span>
                            <span v-if="checkEmailInput">
                                <span v-if="formData.email.value" @click="formData.email.value = ''" class="form_suffix">
                                    <i class="icon-closed"></i>
                                </span>
                            </span>

                        </div>
                        <p class="form_msg" v-if="formData.email.hasError">{{formData.email.msg}}</p>
                    </div>

                    <div v-if="formData.passWord.show" class="form_group required" :class="{error: formData.passWord.hasError}">
                        <div class="form_data form_data-prefix form_data-suffix">
                            <input v-model="formData.passWord.value" :type="showPass ? 'text' : 'password'" class="form_text" :placeholder="$trans('login.type_password')">
                            <span class="form_prefix">
                                <i class="icon-password"></i>
                            </span>
                            <span class="form_suffix" @click="showPass = !showPass">
                                <i v-if="!showPass" class="icon-hide_password"></i>
                                <i v-else class="icon-show_password"></i>
                            </span>
                        </div>
                        <p class="form_msg" v-if="formData.passWord.hasError">{{formData.passWord.msg}}</p>
                    </div>

                    <div v-if="status > 0 && formTip"
                         v-html="formTip"
                         class="form_tip font-24"
                         :class="formTipErr ? 'error' : ''">
                    </div>

                    <div class="form_button">
                        <button type="submit"
                                @click.prevent="onSubmit"
                                class="btn btnLight"
                                href="javascript:;">
                            {{ submitBtn }}
                        </button>
                    </div>

                    <div v-if="status === 3" class="form_button">
                        <button type="button"
                                @click.prevent="status = 0"
                                class="btn btnChange"
                                href="javascript:;">
                            {{ $trans('login.change_email') }}
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </transition>
</template>

<script>
    import layer from 'layer';
    import { timer } from 'js/utils';
    import { serviceSocialBind } from 'js/service/auth';
    import { getFormData, validateFormData } from '../commonData';

    // const NO_EMAIL = 70051;     // 新邮箱地址
    const EMAIL_BIND = 70119; // 已绑定过 提示错误
    const EMAIL_REGISTERED = 70008; // 已注册 提示输入密码绑定

    export default {
        props: {
            value: {
                type: [Boolean],
                default: false,
            },
            bindData: {
                type: [Object],
                default: {},
            },
        },
        data() {
            const { $trans } = this;
            return {
                // 0 默认
                // 1 新邮箱第一次登陆
                // 2 新邮箱第2次登陆 倒计时灰色按钮
                // 3 邮箱可用 提示输入密码
                // 4 邮箱绑定过不可用 提示错误
                status: 0,
                isEU: window.gData.isEU,
                submitBtn: $trans('login.link_email'),
                disabled: false,
                formTip: '',
                checkEmailInput: true,
                showPass: false,
                formData: {
                    email: {
                        hasError: false,
                        value: '',
                        msg: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.sign_email_error'),
                            }, {
                                type: 'email',
                                msg: $trans('login.sign_email_error'),
                            }
                        ]
                    },
                    passWord: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: false,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.sign_password_error'),
                            }, {
                                type: 'passwordLength',
                                msg: $trans('login.sign_password_error'),
                            }
                        ]
                    }
                }
            };
        },
        watch: {
            value(show) {
                if (show) {
                    this.col = document.documentElement.style.overflow;
                    document.documentElement.style.overflow = 'hidden';
                } else {
                    document.documentElement.style.overflow = this.col || '';
                }
            },
            status(newVal) {
                const { $trans } = this;
                this.disabled = false;
                this.formTipErr = false;
                this.formData.passWord.show = false;

                this.clearTiemr();

                if (newVal === 1 || newVal === 2) {
                    this.submitBtn = $trans('login.resend_activation_email');
                    if (newVal === 1) {
                        this.formTip = $trans('login.link_email_tips_unregistered');
                    } else {
                        // 倒计时
                    }
                } else if (newVal === 3) {
                    this.submitBtn = $trans('login.button_sign_in');
                    this.formTip = $trans('login.link_email_tips_registered');
                    this.formData.passWord.show = true;
                } else if (newVal === 4) {
                    this.submitBtn = $trans('login.link_email');
                    // this.disabled = true;
                    this.formTip = $trans('login.link_email_defeated');
                    this.formTipErr = true;
                } else {
                    this.submitBtn = $trans('login.link_email');
                    this.formTip = '';
                }
            },
            bindData() {
                if (this.bindData.email) {
                    this.formData.email.value = this.bindData.email;
                    this.checkEmailInput = false;
                }
            }
        },
        beforeDestroy() {
            this.clearTiemr();
        },
        methods: {
            countdown(ttl) {
                const { $trans } = this;
                this.disabled = true;

                const endTimer = timer((time) => {
                    this.disabled = true;
                    this.formTip = $trans('login.link_email_resend', [time]);
                }, () => {
                    this.formTip = $trans('login.link_email_tips_unregistered');
                    this.disabled = false;
                }, ttl);

                if (!Array.isArray(this.timerList)) {
                    this.timerList = [];
                }
                this.timerList.push(endTimer);
            },
            clearTiemr() {
                if (Array.isArray(this.timerList)) {
                    this.timerList.forEach((curTimer) => {
                        try {
                            curTimer();
                        } catch (e) {
                            // nothing
                        }
                    });
                    this.timerList = [];
                }
            },
            backLogin() {
                this.clearTiemr();
                setTimeout(() => {
                    this.status = 0;
                });
                this.$emit('input', false);
            },
            noMail({ ttl }) {
                if (this.status === 0) {
                    this.status = 1;
                } else {
                    this.status = 2;
                    setTimeout(() => {
                        this.countdown(ttl);
                    });
                }
            },
            async onSubmit() {
                if (validateFormData(this.formData)) {
                    const prams = getFormData(this.formData);

                    const { status, data, msg } = await serviceSocialBind.http({
                        data: {
                            ...this.bindData,
                            ...prams,
                        }
                    });

                    if (status === 0) {
                        if (this.formData.passWord.show) {
                            // 登陆成功
                            const { redirectUrl } = data;
                            if (redirectUrl) {
                                window.location.href = redirectUrl;
                            }
                        } else {
                            // 新邮箱 返回倒计时
                            this.noMail(data);
                        }
                    } else {
                        const { innerCode } = data;
                        if (innerCode === EMAIL_BIND) {
                            // 已绑定过 提示错误
                            this.status = 4;
                        } else if (innerCode === EMAIL_REGISTERED) {
                            this.status = 3;
                        } else {
                            // 直接提示错误
                            layer.msg(msg);
                        }
                    }
                }
            }
        }
    };
</script>

<style scoped>
    @import 'common/css/variable.css';

    .fade-enter-active, .fade-leave-active {
        transition: opacity .2s;
    }
    .fade-enter, .fade-leave-active {
        opacity: 0;
    }
    .btnChange{
        background-color: var(--color-text-primary);
    }
    .form_tip{
        margin: rem(30) 0;
        color: var(--color-text-secondary);
        line-height: 1.4;
        &.error{
            color: var(--warningC);
        }
    }

    .bindEmailBox{
        position: fixed;
        z-index: 10;
        left: 0;
        top: 0;
        width: 100vw;
        height: 100vh;
        background: var(--color-main-bg);
        .tc{
            text-align: center;
        }
        .bindEmail_title{

        }
        .bindEmail_tip{
            padding: rem(20) rem(40);
            color: var(--color-text-secondary);
        }
    }

    .bindEmailBox_content{
        position: relative;
        overflow: auto;
        height: 100%;
        width: 100%;
        padding: rem(100) rem(50) 0;
        -webkit-overflow-scrolling: touch;
    }
    .bindEmail_close{
        position: absolute;
        top: rem(30);
        right: rem(30);
        cursor: pointer;
        z-index: 1;
    }

</style>

