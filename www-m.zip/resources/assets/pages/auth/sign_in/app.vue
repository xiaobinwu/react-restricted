<template>
    <div class="signInContainer">
        <div v-if="envTip" class="envTip">预发布</div>
        <div class="signIn-router">
            <div v-if="isShowSkeleton" class="skeletonPage skeleton">
                <div class="skeletonPage_menu">
                    <div class="skeletonPage_menu-item skeletonBackground block"></div>
                    <div class="skeletonPage_menu-item skeletonBackground block"></div>
                </div>
                <div class="skeletonPage_account skeletonBackground block"></div>
                <div class="skeletonPage_password skeletonBackground block"></div>
                <div class="skeletonPage_checkbox skeletonBackground block"></div>
                <div class="skeletonPage_button skeletonBackground block"></div>
            </div>
            <transition name="router-fade" mode="out-in">
                <router-view></router-view>
            </transition>
        </div>
    </div>
</template>

<script>
    import Cookies from 'js/utils/cookie';
    // import Router from 'vue-router';

    export default {
        data() {
            return {
                envTip: Cookies.get('staging') === 'true',
                isShowSkeleton: false
            };
        },
        methods: {
            afterSkeleton() {
                this.isShowSkeleton = false;
            }
        },
        created() {
            if (this.$route.meta.isShowSkeleton) {
                this.isShowSkeleton = this.$route.meta.isShowSkeleton;
            }
        }
    };
</script>

<style>
    @import 'common/css/variable.css';

    /*.router-fade-enter-active, .router-fade-leave-active {*/
        /*transition: opacity .2s;*/
    /*}*/
    /*.router-fade-enter, .router-fade-leave-active {*/
        /*opacity: 0;*/
    /*}*/

    .envTip{
        position: fixed;
        top: rem(200);
        left: rem(30);
        color: var(--color-main-bg);
        @mixin font 24;
        background: var(--color-danger);
        padding: rem(10);
        z-index: 10086;
        pointer-events: none;
    }
    .signInContainer{
        padding: rem(50);
        .form{
            padding: 0;
        }
        .skeletonPage{
            padding: 0;
        }
    }

</style>
