// import { serviceUserSocial } from 'js/service/auth';
import { serviceSocialLogin, serviceSocialLoginUrl, serviceSocialCheck, servicePassportInit } from 'js/service/auth.js';
// import { trans } from 'js/core/translate.js';
import layer from 'layer';
import { getTimezone } from 'js/utils';
import Cookies from 'js/utils/cookie';

// 避免js 反复加载
const scriptList = [];
export function loadScript(url) {
    return new Promise((resolve) => {
        if (scriptList.indexOf(url) > -1) {
            resolve();
        } else {
            const script = document.createElement('script');
            script.type = 'text/javascript';
            if (script.readyState) {
                script.onreadystatechange = () => {
                    if (script.readyState === 'loaded' || script.readyState === 'complete') {
                        script.onreadystatechange = null;
                        scriptList.push(url);
                        resolve();
                    }
                };
            } else {
                script.onload = () => {
                    scriptList.push(url);
                    resolve();
                };
            }
            script.src = url;
            document.getElementsByTagName('head')[0].appendChild(script);
        }
    });
}


// ******************************** 第三方(社会化)登录 ********************************
export default class SocialLogin {

    constructor(options) {
        this.setting = Object.assign({
            bindEmail: () => {},
            btnGoogleId: 'jsGoogleLogin',
            initSocialList: ['google'] // 需要先初始化
        }, options);
        this.msgAuthFail = 'Auth fail!';

        this.thirdLoginBtn = $('.js-thirdLoginBtn');
        this.$prejudgingForm = $('#js-prejudgingForm');
        this.checkAgree = false;
        this.checkConfirm = false;
        this.checkFormBtn = false;
        this.init();
    }

    init() {
        this.ThirdEvent();
    }

    // 第三方登录请求（修定）
    async ajaxCode() {
        const self = this;

        // 记录时区
        self.ajaxData.timeZone = getTimezone();

        const res = await serviceSocialLogin.http({
            data: Object.assign(self.ajaxData, {
                userCenterSuffix: window.location.hash,
            }),
        });
        if (+res.status === 0) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                window.location.href = window.GLOBAL.DOMAIN_MAIN || '/';
            }
        } else if (Number(res.data.innerCode) === 70051) {
            // 取绑定邮箱地址
            if (res.data.email) {
                self.ajaxData.email = res.data.email;
            }
            self.setting.bindEmail(self.ajaxData);
        } else {
            layer.msg(res.msg);
        }
    }

    // 第三方 event
    ThirdEvent() {
        this.thirdLoginBtn.on('click', (e) => {
            e.preventDefault();
            const thirdType = $(e.currentTarget).data('type');
            const features = this.windowConfig(700, 500);
            const myWindow = window.open('', 'newwindowsss', features);
            this.ThirdLogin(myWindow, thirdType);
        });
    }

    // 第三方登录
    async ThirdLogin(myWindow, typeVal) {
        const $this = this;
        const csrfName = '_token';
        const ajdata = { type: typeVal };
        const res = await serviceSocialLoginUrl.http({
            data: ajdata,
        });
        myWindow.location.href = res.data.loginUrl;
        const loop = setInterval(async () => {
            if (myWindow.closed) {
                clearInterval(loop);
                if (Cookies.get('sing_code')) {
                    $this.ajaxData = {
                        type: typeVal,
                        code: Cookies.get('sing_code')
                    };
                    Cookies.set('sing_code', null, { expires: 0 });
                } else if (Cookies.get('sing_token')) {
                    $this.ajaxData = {
                        type: typeVal,
                        token: Cookies.get('sing_token')
                    };
                    Cookies.set('sing_token', null, { expires: 0 });
                } else {
                    return false;
                }
                // CSRF攻击防御token
                $this.ajaxData[csrfName] = $('meta[name=csrf-token]').attr('content');

                // 获取是否欧盟
                const passportInit = await servicePassportInit.http();
                if (passportInit.status !== 0) {
                    layer.msg(passportInit.msg);
                    return false;
                }
                if (Number(passportInit.data.isEU) === 1) {
                    const check = await serviceSocialCheck.http({
                        data: $this.ajaxData
                    });
                    if (check.status === 0) {
                        $this.ajaxCode();
                    } else if (check.data.innerCode === 70017) {

                        const preLayer = layer.open({
                            content: $('.js-prejudging').html(),
                            type: 1,
                            btn: 0,
                            shadeClose: 0,
                            closeBtn: 1
                        });

                        const jsCheckAgree = $('.js-checkAgree');
                        const jsCheckConfirm = $('.js-checkConfirm');
                        const jsCheckFormBtn = $('.js-checkFormBtn');
                        const closePreBtn = $('.js-close-preBtn');
                        jsCheckFormBtn.prop('disabled', true);
                        jsCheckFormBtn.addClass('disabled');
                        $this.checkAgree = false;
                        $this.checkConfirm = false;

                        jsCheckAgree.on('click', (event) => {
                            event.preventDefault();
                            const eTarger = $(event.target);
                            $this.checkAgree = !$this.checkAgree;
                            $this.thirdClause($this.checkAgree, eTarger, jsCheckFormBtn);
                        });
                        jsCheckConfirm.on('click', (event) => {
                            event.preventDefault();
                            const eTarger = $(event.target);
                            $this.checkConfirm = !$this.checkConfirm;
                            $this.thirdClause($this.checkConfirm, eTarger, jsCheckFormBtn);
                        });
                        jsCheckFormBtn.on('click', (event) => {
                            event.preventDefault();
                            $this.ajaxCode();
                            layer.close(preLayer);
                        });
                        closePreBtn.on('click', (event) => {
                            event.preventDefault();
                            layer.close(preLayer);
                        });
                    } else {
                        layer.msg(check.msg);
                    }
                } else {
                    $this.ajaxCode();
                }
            }
            return true;
        }, 200);
    }

    // 前置条件事件
    thirdClause($check, $eTarger, jsCheckFormBtn) {
        const $this = this;
        if ($this.checkAgree && $this.checkConfirm) {
            $this.checkFormBtn = true;
        } else {
            $this.checkFormBtn = false;
        }
        if ($check) {
            $eTarger.addClass('formAgree_checked');
        } else {
            $eTarger.removeClass('formAgree_checked');
        }
        if ($this.checkFormBtn) {
            jsCheckFormBtn.prop('disabled', false);
            jsCheckFormBtn.removeClass('disabled');
        } else {
            jsCheckFormBtn.prop('disabled', true);
            jsCheckFormBtn.addClass('disabled');
        }
    }

    // window open 基本配置
    windowConfig(wid, hei) {
        const features = `
            toolbar = no, 
            menubar = no, 
            scrollbars = no, 
            resizable = no, 
            location = no, 
            status = no, 
            titlebar = yes, 
            alwaysRaised = yes, `;
        return features;
    }
}
