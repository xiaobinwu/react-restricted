/**
 * Created by Liu.Jun on 2018/1/30.
 */

import layer from 'layer';

export default function (router) {
    router.beforeEach((to, from, next) => {
        // loading..
        // 强制刷新 php blade 数据要刷新啊
        // layer.loading();
        if (from.name && to.name !== from.name && to.meta.needReload) {
            window.location.href = to.fullPath;
            layer.closeAll();
        } else {
            if (to.meta.isShowSkeleton) {
                from.meta.isShowSkeleton = to.meta.isShowSkeleton;
            }
            next();
            // document.title = to.meta.title;
        }
    });

    router.afterEach(() => {
        layer.closeAll();
        // end loading
    });
}
