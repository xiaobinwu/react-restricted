/**
 * Created by Liu.Jun on 2018/1/30.
 */

import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

export const constantRouterMap = [
    // 登陆
    {
        path: '/m-users-a-sign.htm',
        name: 'authSignIn',
        component: () => import('../view/sign_in.vue'),
        meta: {
            title: 'Sign In',
            needReload: true, // php模板数据不能动态刷新问题
            isShowSkeleton: true,
        },
    },

    // 注册
    {
        path: '/m-users-a-join.html',
        name: 'authRegister',
        component: () => import('../view/register.vue'),
        meta: {
            title: 'Register',
            needReload: true, // php模板数据不能动态刷新问题
            isShowSkeleton: true,
        },
    },

    // 注册成功提示发送邮件
    {
        path: '/register/registerOver/:email',
        name: 'registerOver',
        component: () => import('../view/register_over.vue'),
        meta: {
            title: 'Activate your account'
        },
    },
    // 注册成功 激活新用户
    {
        path: '/register/success/:email',
        name: 'registerSuccess',
        component: () => import('../view/register_success.vue'),
        meta: {
            title: 'Register success'
        },
    },

    // 忘记密码
    {
        path: '/reset-password.html',
        name: 'authResetPassword',
        component: () => import('../view/forget_password.vue'),
        meta: {
            title: 'Reset Password',
            needReload: true, // php模板数据不能动态刷新问题
        },
    },

    // 重置密码
    {
        path: '/new-password/:confirmCode',
        name: 'authNewPassword',
        component: () => import('../view/new_password.vue'),
        meta: {
            title: 'Reset password'
        },
    },

    // 登出
    {
        path: '/m-users-a-logout.htm',
        name: 'logout',
        component: () => import('../view/logout.vue'),
        meta: {
            title: 'Reset password'
        },
    },

    // messenger特殊登录结果页
    {
        path: '/linking-result/:status',
        name: 'linkingResult',
        component: () => import('../view/linking_result.vue'),
        meta: {
            title: ''
        },
    },

    {
        path: '*',
        redirect: {
            name: 'authSignIn'
        }
    }
];

export default new Router({
    mode: process.env.NODE_ENV === 'dev' ? 'hash' : 'history',
    base: process.env.NODE_ENV === 'dev' ? '/dev/auth/sign_in.html' : '',
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition;
        }

        if (from.meta.keepAlive) {
            Object.defineProperty(from.meta, 'savedPosition', document.body.scrollTop);
        }
        return {
            x: 0,
            y: to.meta.savedPosition || 0,
        };
    },
    routes: constantRouterMap
});
