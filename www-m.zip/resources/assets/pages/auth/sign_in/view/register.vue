<template>
    <div class="register_wrap hbv">
        <login-heard></login-heard>
        <div class="new-members-wrap">
            <p v-if="pipeline == 'GB'" class="new-members-bonus">{{this.$trans('login.new_members_bonus_register', [couponNum])}}</p>
        </div>
        <form class="form registerForm">
            <div class="form_group required" :class="{error: formData.email.hasError}">
                <div class="form_data">
                    <input v-model="formData.email.value" type="email" class="form_text"  :placeholder="$trans('login.type_email_address')">
                    <span v-if="formData.email.value" @click="formData.email.value = ''" class="form_suffix">
                        <i class="icon-closed"></i>
                    </span>

                    <email-suffix :inputData="formData.email.value"></email-suffix>
                </div>
                <p class="form_msg" v-if="formData.email.hasError">{{formData.email.msg}}</p>
            </div>

            <div class="form_group required" :class="{error: formData.passWord.hasError}">
                <div class="form_data form_data-suffix">
                    <input maxlength="30" v-model="formData.passWord.value" :type="showPass ? 'text' : 'password'" class="form_text" :placeholder="$trans('login.create_pass')">
                    <span class="form_suffix" @click="showPass = !showPass">
                        <i v-if="!showPass" class="icon-hide_password"></i>
                        <i v-else class="icon-show_password"></i>
                    </span>
                </div>
                <p class="form_msg" v-if="formData.passWord.hasError">{{formData.passWord.msg}}</p>
            </div>

            <div v-if="formData.captcha.show" class="form_group horizontal-view content-between required form_group-captcha" :class="{error: formData.captcha.hasError}">
                <div class="form_dataBox">
                    <div class="form_data">
                        <input v-model="formData.captcha.value" type="text" maxlength="4" class="form_text" :placeholder="$trans('login.enter_the_code')">
                    </div>
                    <p class="form_msg" v-if="formData.captcha.hasError">{{formData.captcha.msg}}</p>
                </div>
                <div class="form_captcha" @click="captcha = getCaptcha()">
                    <img class="form_captchaImg" :src="captcha" alt="captcha">
                </div>
            </div>

            <div class="form_group required" :class="{error: formData.agree.hasError}">
                <div class="form_data form_dataAgree">
                    <label class="check_item">
                        <input type="checkbox" name="agree" class="cAuthCheck_input" v-model="formData.agree.value">
                        <i class="check_shape"></i>
                    </label>

                    <div v-if="isEU == 1" class="formAgree_text form_text font-24"
                         v-html="$trans('login.registration_terms_eu', ['/about/terms-and-conditions', '/about/privacy-policy'])">
                    </div>
                    <div v-else class="formAgree_text form_text font-24"
                         v-html="$trans('login.registration_terms', ['/about/terms-and-conditions', '/about/privacy-policy'])">
                    </div>
                </div>
                <p class="form_msg" v-if="formData.agree.hasError">{{formData.agree.msg}}</p>
            </div>
            <div v-if="isEU == 1" class="form_group required" :class="{error: formData.agreeEu.hasError}">
                <div class="form_data form_dataAgree">
                    <label class="check_item">
                        <input type="checkbox" name="agreeEu" class="cAuthCheck_input" v-model="formData.agreeEu.value">
                        <i class="check_shape"></i>
                    </label>

                    <div class="formAgree_text form_text font-24"
                         v-html="$trans('login.registration_terms_confirm_eu', ['/about/privacy-policy'])">
                    </div>
                </div>
                <p class="form_msg" v-if="formData.agreeEu.hasError">{{formData.agreeEu.msg}}</p>
            </div>
            <div class="form_button">
                <button type="submit"
                        @click.prevent="onSubmit"
                        class="btn btnLight"
                        href="javascript:;"
                >{{this.$trans('login.register')}}</button>
            </div>
        </form>
        <sns-login class="snsLoginBox" v-if="!fbToken"></sns-login>
    </div>
</template>

<script>
    import { serviceRegister, serviceCheckEmailExist, servicePassportInit } from 'js/service/auth';
    import { getTimezone } from 'js/utils';
    import layer from 'layer';

    import LoginHeard from '../component/loginHeard.vue';
    import SnsLogin from '../component/snsLogin.vue';
    import EmailSuffix from '../component/emailSuffix.vue';
    import { getFormData, validateFormData, getCaptcha } from '../commonData';

    export default {
        components: {
            LoginHeard,
            SnsLogin,
            EmailSuffix
        },
        watch: {
            'formData.passWord.value': function changeValue(value) {
                this.formData.passWord.value = String(value).replace(/\s/g, '');
            },
        },
        data() {
            const { $trans } = this;

            return {
                showPass: false,
                captcha: this.getCaptcha(),
                formData: {
                    email: {
                        hasError: false,
                        value: '',
                        msg: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.register_email_error'),
                            }, {
                                type: 'email',
                                msg: $trans('login.register_email_error'),
                            }
                        ]
                    },
                    passWord: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.register_password_tip'),
                            }, {
                                type: 'password',
                                msg: $trans('login.register_password_tip'),
                            }
                        ]
                    },
                    captcha: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: Boolean(window.gData.showCaptcha || 0),
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.valid_correct'),
                            }
                        ]
                    },
                    agree: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.register_agree_tip'),
                            }
                        ]
                    },
                    agreeEu: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.register_agreeeu_tip'),
                            }
                        ]
                    },
                    regType: {
                        value: 1
                    },
                    isEmailSub: {
                        value: 1
                    },

                },
                isEU: null,
                couponNum: 10,
                pipeline: window.GLOBAL.PIPELINE,
            };
        },
        computed: {
            fbToken() {
                return this.$route.query.fb_token;
            }
        },
        mounted() {
            this.$nextTick(async () => {
                this.$parent.afterSkeleton();
                const { data, status } = await servicePassportInit.http();
                if (status === 0) {
                    this.isEU = data.isEU;
                    this.formData.agreeEu.show = data.isEU === 1;
                }
            });
        },
        methods: {
            getCaptcha() {
                return getCaptcha();
            },
            refreshCaptcha() {
                this.captcha = this.getCaptcha();
            },
            _validateForm() {
                return true;
            },
            async checkEmail(email) {
                const {
                    status, data: { internalMessage }
                } = await serviceCheckEmailExist.http({
                    params: {
                        email
                    }
                });
                return {
                    hasError: status !== 0,
                    msg: internalMessage,
                };
            },
            async onSubmit() {
                // 重置提示语
                this.formData.email.msg = '';
                this.formData.email.hasError = false;
                this.formData.passWord.msg = '';
                this.formData.passWord.hasError = false;
                this.formData.captcha.msg = '';
                this.formData.captcha.hasError = false;
                this.formData.agree.msg = '';
                this.formData.agree.hasError = false;
                this.formData.agreeEu.msg = '';
                this.formData.agreeEu.hasError = false;

                // 表单验证并提交
                if (validateFormData(this.formData)) {
                    const validEmail = await this.checkEmail(this.formData.email.value);
                    if (validEmail.hasError) {
                        this.formData.email.hasError = true;
                        this.formData.email.msg = validEmail.msg;

                        // 邮箱地址存在
                        // this.refreshCaptcha();
                    } else {
                        const prams = getFormData(this.formData);

                        // 记录时区
                        prams.timeZone = getTimezone();

                        // messenger 特殊登录标记
                        if (this.fbToken) {
                            prams.fb_token = this.fbToken;
                        }

                        const { status, data, msg } = await serviceRegister.http({
                            data: prams,
                            errorPop: false
                        });

                        if (status === 0) {
                            window.location.href = data.redirectUrl;
                            /* this.$router.push({
                                name: 'registerOver',
                                params: {
                                    email: data.redirectUrl.split('/').pop()
                                }
                            }) */
                        } else if (Number(status) === 423) {
                            this.formData.captcha.show = true;
                        } else {
                            layer.msg(msg);
                        }
                    }
                    if (this.formData.captcha.show) {
                        this.refreshCaptcha();
                    }
                }
            }
        }
    };
</script>

<style>
    @import 'common/css/variable.css';

    .registerForm{
        margin-top: rem(40);
    }
    .formAgree_text{
        border: none;
        line-height: 1.4;
        margin: 0;
    }
    .new-members-wrap{
        font-size: 0;
        text-align: center;
        margin-top: rem(40);
    }
    .new-members-bonus{
        @mixin font 28;
        display: inline-block;
        padding: rem(4) rem(4);
        border-radius: rem(4);
        color: var(--color-warning);
        border: 1px dashed var(--color-warning);
        text-align: center;
    }
    .form_dataAgree{
        display: flex;
        flex-direction: row;
        .formAgree_text{
            padding-top: 0;
            margin-left: rem(10);
        }
    }
    /*.cAuthCheck_inputWrap{
        width: rem(50);
        .cAuthCheck_input {
            display: block;
            position: absolute;
            z-index: 1;
            left: 0;
            right: 0;
            width: rem(30);
            height: rem(30);
            opacity: 0;
            cursor: pointer;
            margin: auto;
        }
        .cAuthCheck_inner {
            display: block;
            vertical-align: middle;
            width: rem(30);
            height: rem(30);
            border: 1px solid var(--color-border);
            line-height: rem(30);
            @mixin font 28;
            font-weight: 700;
            color: var(--color-float-btn);
            -webkit-border-radius: 3px;
            border-radius: 3px;
            margin: auto;
        }
        .cAuthCheck_input:checked+.cAuthCheck_inner {
            background-color: var(--color-warning);
            border-color: var(--color-warning);
            text-align: center;
        }
    }*/


    .formAgree_textLink {
        text-decoration: underline;
    }

</style>
