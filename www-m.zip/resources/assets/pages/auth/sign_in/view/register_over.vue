<template>
    <div class="activationPassword_wrap">
        <form class="form">
            <div class="actPasswordHead">
                <h1 class="actPasswordHead_title">{{$trans('login.over_to_activation')}}</h1>
                <div class="actPasswordHead_tip font-24">
                    <p class="actPasswordHead_tip-text">{{$trans('login.over_activation')}}</p>
                    <p class="actPasswordHead_tip-email">{{$trans('login.email_address')}}: <span class="email_text">{{email}}</span></p>
                </div>
            </div>
            <div class="form_button">
                <button @click.prevent="onResend"
                   class="btn btnLight"
                   href="javascript:;"
                   :disabled="ttl > 0"
                >{{$trans('login.over_resend')}} {{ttl > 0 ? ttl : ''}}</button>
            </div>
        </form>
    </div>
</template>

<script>
    import { sendActivationEmail } from 'js/service/auth';

    export default {
        computed: {
            email() {
                return window.gData.newPassData.email;
            }
        },
        data() {
            return {
                ttl: 0
            };
        },
        beforeDestroy() {
            clearTimeout(this.ttlTimer);
        },
        methods: {
            countdown(ttl) {
                if (ttl >= 0) {
                    this.ttl = ttl;
                    this.ttlTimer = setTimeout(() => {
                        this.countdown(this.ttl - 1);
                    }, 1000);
                }
            },
            async onResend() {
                const { email } = this;
                const { status, data } = await sendActivationEmail.http({
                    data: {
                        email
                    }
                });
                if (status === 0) {
                    this.countdown(data.ttl);
                }
            }
        },
    };
</script>

<style>
    @import 'common/css/variable.css';

    .actPasswordHead{
        text-align: left;
        line-height: 1.4;
        .actPasswordHead_title{
            color: var(--color-text-primary);
            font-weight: bold;
            @mixin font 36;
        }
        .actPasswordHead_tip{
            padding: rem(20) 0;
            color: var(--color-text-primary);
        }
        .actPasswordHead_tip-email{
            margin-top: rem(40);
            font-weight: bold;
        }
    }

</style>
