<template>
    <div class="linking-wrap">
        <div v-if="status == 'register-success'" class="linking-registerSucces">
            <i class="icon-check linking-iconMain"></i>
            <h2 class="linking-title">{{$trans('login.account_linking_is_successful')}}</h2>
            <p class="linking-desc">{{$trans('login.please_check_your_activation_email')}}</p>
            <div class="linking-email" v-if="email">{{$trans('login.email_address_is', [email])}}</div>
        </div>
        <div v-else-if="status == 'login-success'" class="linking-loginSucces">
            <i class="icon-check linking-iconMain"></i>
            <h2 class="linking-title">{{$trans('login.account_linking_is_successful')}}</h2>
        </div>
        <div v-else-if="status == 'fail'" class="linking-fail">
            <i class="icon-info linking-iconMain"></i>
            <div v-if="code == 1006">
                <h2 class="linking-title">{{$trans('login.account_linking_already')}}</h2>
            </div>
            <div v-else>
                <h2 class="linking-title">{{$trans('login.account_linking_failed')}}<br>{{$trans('login.please_try_later')}}</h2>
                <a :href="`/user/bind-messenger?fb_token=${fb_token}`" class="linking-trybtn">{{$trans('login.try_btn')}}</a>
            </div>

        </div>
    </div>
</template>

<script>
    export default {
        computed: {
            status() {
                return this.$route.params.status;
            },
            email() {
                return this.$route.query.email || '';
            },
            code() {
                return this.$route.query.code || 0;
            },
            fb_token() {
                return this.$route.query.fb_token || '';
            },
        },
    };
</script>

<style>
    @import 'common/css/variable.css';

    .linking-wrap{
        margin: rem(150) auto rem(150);
        text-align:center;
    }
    .linking-iconMain{
        @mixin font 130;
        margin: 0 auto;
        width: rem(130);
        height: rem(130);
        color: green;
        @nest .linking-fail & {
            color: var(--color-warning);
        }
    }
    .linking-title{
        margin-top: rem(30);
        line-height: 1.5;
        @mixin font 40;
        color: var(--color-text-primary);
    }
    .linking-desc{
        margin-top: rem(20);
        line-height: 1.5;
        @mixin font 28;
        color: var(--color-text-secondary);
    }
    .linking-email{
        margin-top: rem(40);
        line-height: 1.5;
        @mixin font 28;
        color: var(--color-text-primary);
    }
    .linking-trybtn {
        display: inline-block;
        color: var(--color-warning);
        border: 1px solid var(--color-warning);
        border-radius: rem(4);
        padding: 0 rem(30);
        line-height: rem(60);
        margin-top: rem(30);
        @mixin font 26;
    }
</style>
