<template>
    <div class="activation_wrap">
        <form class="form">
            <h1 class="activation_title">{{$trans('login.reg_success_title')}}</h1>
            <div class="activation_tip font-24">
                <p class="activation_tip-account">{{$trans('login.reg_success_account_is')}} : {{email}}</p>
                <!-- <p class="activation_tip-point">{{$trans('login.reg_success_gb_points')}}</p> -->
            </div>
            <div class="activationActs">
                <div v-if="`${GLOBAL.PIPELINE}` == 'GB'" class="form_button">
                    <a :href="`${GLOBAL.DOMAIN_USER}/activity/new-shopping-guide/`" class="btn">{{$trans('login.new_members_bonus_start')}}</a>
                </div>
            </div>
            <div class="activation_tip font-24">
                <p class="activation_tip-return" ref="registerCutDown" v-html="$trans('login.reg_success_account_return', [retueTime])"></p>
            </div>
        </form>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                retueTime: 5,
                email: window.gData.registerSuccess.email,
                rollbackUrl: window.gData.registerSuccess.rollbackUrl,
                GLOBAL

            };
        },
        mounted() {
            const vm = this;
            this.$nextTick(() => {
                const t = setInterval(() => {
                    vm.retueTime -= 1;
                    if (vm.retueTime === 0) {
                        clearInterval(t);
                        window.location.href = vm.rollbackUrl;
                    }
                }, 1000);
            });
        },
    };
</script>

<style>
    @import 'common/css/variable.css';
    .btn-user{
        background-color: var(--color-other-33);
        &:active {
            background-color: var(--color-text-primary);
        }
    }
    .activation_wrap{
        line-height: 1.4;
    }
    .activation_title{
        @mixin font 48;
    }
    .activation_tip{
        margin-top: rem(60);
        @mixin font 32;
        .activation_tip-account{
        }
        .activation_tip-point{
            font-weight: bold;
        }
    }
    .activationActs{
        margin-top: rem(60);
    }
    .new-members-bonus-btn{
        background: none;
        border: 1px solid var(--color-other-33);
        color: var(--color-text-primary);
    }
    .activation_tip-return{
        text-align: center;
        .red{
            color: var(--color-danger);
        }
    }

</style>
