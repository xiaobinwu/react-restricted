<template>
    <div class="resetPass_wrap">
        <div class="resetPass_step">
            <div class="resetPassHead">
                <h1 class="resetPass_title">{{$trans('login.new_pass_title')}}</h1>
                <div class="resetPassHead_tip font-28">
                    {{$trans('login.find_password_tips')}}
                </div>
            </div>
            <form class="form signInForm">
                <div class="form_group" :class="{error: formData.email.hasError}">
                    <div class="form_data">
                        <input readonly v-model="formData.email.value" type="email" class="form_text" :placeholder="$trans('login.type_email_address')">
                    </div>
                </div>
                <div class="form_group required" :class="{error: formData.passWord.hasError}">
                    <div class="form_data form_data-suffix">
                        <input maxlength="30" v-model="formData.passWord.value" :type="showPass ? 'text' : 'password'" class="form_text" :placeholder="$trans('login.new_pass_new_pass')">
                        <span class="form_suffix" @click="showPass = !showPass">
                            <i v-if="!showPass" class="icon-hide_password"></i>
                            <i v-else class="icon-show_password"></i>
                        </span>
                    </div>
                    <p class="form_msg" v-if="formData.passWord.hasError">{{formData.passWord.msg}}</p>
                </div>

                <div class="form_group required" :class="{error: formData.passWord2.hasError}">
                    <div class="form_data form_data-suffix">
                        <input maxlength="30" v-model="formData.passWord2.value" :type="showPass ? 'text' : 'password'" class="form_text" :placeholder="$trans('login.new_pass_re_enter')">
                        <span class="form_suffix" @click="showPass = !showPass">
                        <i v-if="!showPass" class="icon-hide_password"></i>
                        <i v-else class="icon-show_password"></i>
                    </span>
                    </div>
                    <p class="form_msg" v-if="formData.passWord2.hasError">{{formData.passWord2.msg}}</p>
                </div>

                <div class="form_button">
                    <button @click.prevent="onSubmit" class="btn btnLight" href="javascript:;">{{$trans('login.new_pass_confirm')}}</button>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
    import { serviceResetPassword } from 'js/service/auth';
    import { getFormData, validateFormData, getCaptcha } from '../commonData';


    export default {
        watch: {
            'formData.passWord.value': function changePass(value) {
                this.formData.passWord.value = String(value).replace(/\s/g, '');
            },
        },
        data() {
            const { $trans } = this;
            return {
                showPass: false,
                formData: {
                    email: {
                        value: window.gData.newPassData.email
                    },
                    passWord: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.register_password_tip'),
                            }, {
                                type: 'password',
                                msg: $trans('login.register_password_tip'),
                            }
                        ]
                    },
                    passWord2: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.register_password_tip'),
                            }, {
                                type: 'password',
                                msg: $trans('login.register_password_tip'),
                            }, {
                                type: 'equal',
                                equal: 'passWord',
                                msg: $trans('login.valid_same_pass'),
                            }
                        ]
                    },
                }
            };
        },
        methods: {
            getCaptcha() {
                return getCaptcha();

            },
            _validateForm() {
                return true;
            },
            async onSubmit() {
                if (validateFormData(this.formData)) {
                    const prams = getFormData(this.formData);
                    const { status } = await serviceResetPassword.http({
                        data: {
                            accessToken: window.gData.newPassData.accessToken,
                            passWord: prams.passWord
                        }
                    });
                    if (status === 0) {
                        const { DOMAIN_USER } = GLOBAL;
                        window.location.href = `${DOMAIN_USER}/index`;
                    }
                }
            }
        }
    };
</script>

<style>
    @import 'common/css/variable.css';

    .resetPass_step{
        line-height: 1.4;
        .resetPass_title{
            font-weight: bold;
            @mixin font 36;
        }
    }
    .resetPassHead{
        color: var(--color-text-primary);
        .resetPassHead_tip{
            padding: rem(20) 0;
        }
    }
    .resetPass_done{
        .resetPass_title, .resetPass_step-link{
            color: var(--color-warning);
        }
        .resetPass_tip{
            margin-top: rem(70);
        }
    }
    .resetPass_email{
        font-weight: bold;
    }
</style>
