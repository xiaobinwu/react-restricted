<template>
    <div class="signIn_wrap">
        <login-heard></login-heard>
        <form class="form signInForm">
            <div class="form_group required" :class="{error: formData.email.hasError}">
                <div class="form_data">
                    <input v-model="formData.email.value" ref="emailInput" type="email" class="form_text"
                           :placeholder="$trans('login.type_email_address')">
                    <span v-if="formData.email.value" @click="formData.email.value = ''" class="form_suffix">
                        <i class="icon-closed"></i>
                    </span>

                    <email-suffix :inputData="formData.email.value"></email-suffix>
                </div>
                <p class="form_msg" v-if="formData.email.hasError">{{formData.email.msg}}</p>
            </div>

            <div class="form_group required" :class="{error: formData.passWord.hasError}">
                <div class="form_data form_data-suffix">
                    <input v-model="formData.passWord.value" ref="passwWordInput" :type="showPass ? 'text' : 'password'"
                           class="form_text" :placeholder="$trans('login.type_password')">
                    <span class="form_suffix" @click="showPass = !showPass">
                            <i v-if="!showPass" class="icon-hide_password"></i>
                            <i v-else class="icon-show_password"></i>
                        </span>
                </div>
                <p class="form_msg" v-if="formData.passWord.hasError">{{formData.passWord.msg}}</p>
            </div>

            <div v-if="formData.captcha.show"
                 class="form_group horizontal-view content-between required form_group-captcha"
                 :class="{error: formData.captcha.hasError}">
                <div class="form_dataBox">
                    <div class="form_data">
                        <input v-model="formData.captcha.value" type="text" maxlength="4" class="form_text"
                               :placeholder="$trans('login.enter_the_code')">
                    </div>
                    <p class="form_msg" v-if="formData.captcha.hasError">{{formData.captcha.msg}}</p>
                </div>
                <div class="form_captcha press-light" @click="captcha = getCaptcha()">
                    <img class="form_captchaImg" :src="captcha" alt="captcha">
                </div>
            </div>
            <div class="form_group signGetPass horizontal-view content-between alignItem-center">
                    <span class="horizontal-view" v-if="!fbToken">
                        <label class="signKeepMe horizontal-view content-between alignItem-center">
                            <span class="signKeepMe_inner check_item">
                                <input type="checkbox" v-model="hasChecked">
                                <i class="check_shape"></i>
                            </span>
                            <span class="signKeepMe_text">
                                {{ $trans('login.keep_me') }}
                            </span>
                        </label>
                        <span class="cformKeepMeTip">
                            <i class="icon-question" @click="KeepMeTip = !KeepMeTip"></i>
                            <span v-if="KeepMeTip" class="formKeepMeTip_content">
                                <i class="icon-closed" @click="KeepMeTip = !KeepMeTip"></i>
                                {{ $trans('login.login_keep_tip_new1') }}<br/>
                                {{ $trans('login.login_keep_tip_new2') }}
                            </span>
                        </span>
                    </span>
                <span class="horizontal-view" v-else></span>


                <router-link class="signGetPass_link font-24" :to="{name: 'authResetPassword'}">
                    {{$trans('login.sign_forgot_your_password')}}
                </router-link>
            </div>
            <div class="form_button">
                <button type="submit" @click.prevent="onSubmit" class="btn btnLight" href="javascript:;">
                    {{$trans('login.sign_in')}}
                </button>
            </div>
        </form>
        <sns-login class="snsLoginBox" v-if="!fbToken"></sns-login>

        <div v-if="visitor === 1" class="visitorBox">
            <a :href="visitorUrl" class="btn visitorBtn">
                {{$trans('login.visitor_purchase_btn')}}
            </a>
            <a href="javascript:;" class="visitorFaqBtn" @click="openVisitorFaq()">
                <span class="font-26">{{$trans('login.visitor_faq_btn')}}</span>
                <i class="icon-question font-40"></i>
            </a>
        </div>
    </div>
</template>

<script>
    import { serviceLogin } from 'js/service/auth';
    import { getTimezone } from 'js/utils';
    import layer from 'layer';
    import brushCheck from 'component/brushCheck/brushCheck.js';
    import { initFirebase } from 'js/core/firebase/main.js';

    import LoginHeard from '../component/loginHeard.vue';
    import SnsLogin from '../component/snsLogin.vue';
    import EmailSuffix from '../component/emailSuffix.vue';
    import { getFormData, validateFormData, getCaptcha, getCsrfToken } from '../commonData';

    export default {
        components: {
            LoginHeard,
            SnsLogin,
            EmailSuffix
        },
        data() {
            const { $trans } = this;
            return {
                showPass: false,
                captcha: '',
                hasChecked: false,
                visitor: window.visitor,
                visitorUrl: window.visitorUrl,
                KeepMeTip: false,
                formData: {
                    email: {
                        hasError: false,
                        value: '',
                        msg: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.sign_email_error'),
                            }, {
                                type: 'email',
                                msg: $trans('login.sign_email_error'),
                            }
                        ]
                    },
                    passWord: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: true,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.sign_password_error'),
                            }, {
                                type: 'passwordLength',
                                msg: $trans('login.sign_password_error'),
                            }
                        ]
                    },
                    captcha: {
                        hasError: false,
                        msg: '',
                        value: '',
                        show: false,
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.valid_correct'),
                            }
                        ]
                    },
                }
            };
        },
        computed: {
            fbToken() {
                return this.$route.query.fb_token;
            }
        },
        methods: {
            getCaptcha() {
                return getCaptcha();
            },
            refreshCaptcha() {
                this.captcha = this.getCaptcha();
            },
            async onSubmit() {
                if (validateFormData(this.formData)) {
                    const prams = getFormData(this.formData);
                    prams.keepMe = +this.hasChecked;

                    // CSRF攻击防御token
                    const csrfName = '_token';
                    prams[csrfName] = getCsrfToken();

                    // 记录时区
                    prams.timeZone = getTimezone();

                    // messenger 特殊登录标记
                    if (this.fbToken) {
                        prams.fb_token = this.fbToken;
                    }

                    let res = await serviceLogin.http({
                        data: Object.assign(prams, {
                            userCenterSuffix: window.location.hash,
                        }),
                        errorPop: false
                    });
                    // 防刷校验40373285,然后第二次调用登陆接口
                    if (res.status === 40373285) {
                        const checkContent = await brushCheck({
                            action: res.data.action,
                            siteKey: res.data.siteKey,
                            recaptchaVersion: res.data.recaptchaVersion
                        });
                        res = await serviceLogin.http({
                            data: Object.assign(prams, {
                                userCenterSuffix: window.location.hash,
                                gbcaptcha: checkContent.gbcaptcha,
                                captchaType: checkContent.captchaType,
                                recaptchaVersion: checkContent.recaptchaVersion
                            }),
                            errorPop: false
                        });
                    }
                    if (res.status === 0) {
                        try {
                            await initFirebase(true);
                        } catch (e) {
                            // nothing
                        }
                        window.location.href = res.data.redirectUrl;
                    } else if (res.status === 10070002) {
                        this.formData.captcha.show = true;
                        layer.msg(res.msg);
                    } else if (res.status === 10070003) {
                        window.location.href = res.data.redirectUrl;
                    } else if (res.data && res.data.redirectUrl) {
                        window.location.href = res.data.redirectUrl;
                    } else {
                        layer.msg(res.msg);
                    }
                    if (this.formData.captcha.show) {
                        this.refreshCaptcha();
                    }
                }
            },
            openVisitorFaq() {
                layer.open({
                    className: 'visitorFaqAlert',
                    content: `
                        <i class="visitorFaqAlertClose icon-closed js-visitorFaqAlertClose font-32"></i>
                        <div class="visitorFaqAlertCon">
                            <h5 class="font-28">${this.$trans('login.visitor_faq_btn')}</h5>
                            <p class="font-28">${this.$trans('login.visitor_faq_rules')}</p>
                        </div>
                    `,
                    success() {
                        $(document)
                            .on('click', '.visitorFaqAlert .js-visitorFaqAlertClose', () => {
                                layer.closeAll();
                            });
                    }
                });
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.$parent.afterSkeleton();
                setTimeout(() => {
                    if (this.$refs.emailInput.value) {
                        this.formData.email.value = this.$refs.emailInput.value;
                        this.formData.passWord.value = this.$refs.passwWordInput.value;
                    }
                }, 200);
            });
        },
    };
</script>

<style>
    @import 'common/css/variable.css';

    .signInForm {
        margin-top: rem(40);
    }

    .signKeepMe_text {
        margin-left: rem(10);
        white-space: nowrap;
    }

    .signGetPass {
        text-align: right;

        .signGetPass_link {
            color: var(--color-text-secondary);
            text-decoration: underline;
            white-space: nowrap;
        }
    }

    .cformKeepMeTip {
        margin-left: rem(12);
        cursor: pointer;
        position: relative;

        .icon-question {
            color: var(--color-text-secondary);
            @mixin font 48;
        }

        .icon-closed {
            position: absolute;
            @mixin font 30;
            right: rem(10);
            top: rem(10);
        }

        .formKeepMeTip_content {
            position: absolute;
            width: rem(560);
            top: rem(52);
            left: rem(-250);
            border: 1px solid var(--color-other-lable);
            box-shadow: 0 2px 12px 0 var(--color-border);
            background: var(--color-main-bg);
            padding: rem(30) rem(40);
            border-radius: 4px;
            line-height: 1.4;
            color: var(--color-text-primary);
            @mixin font 28;
            z-index: 2;
            text-align: left;

            &:after, &:before {
                content: "";
                width: 0;
                height: 0;
                border-style: solid;
                position: absolute;
                border-width: 6px;
            }

            &:before {
                border-color: transparent transparent var(--color-border) transparent;
                left: rem(258);
                top: rem(-24);
            }

            &:after {
                border-color: transparent transparent var(--color-main-bg) transparent;
                left: rem(258);
                top: rem(-24);
            }
        }

    }

    .visitorBox {
        margin-top: rem(50);
        text-align: center;
    }

    .visitorBtn {
        background-color: var(--color-main-bg);
        border: 1px solid var(--color-text-primary);
    }

    .visitorFaqBtn {
        margin-top: rem(24);
        display: inline-block;
        font-size: 0;
    }

    .visitorFaqBtn span {
        display: inline-block;
        vertical-align: top;
        line-height: rem(32);
    }

    .visitorFaqBtn .icon-question {
        display: inline-block;
        vertical-align: top;
        line-height: rem(32);
        margin-left: rem(16);
    }

    /* 弹窗样式 */
    .visitorFaqAlert.layui-m-layerchild {
        position: relative;
        max-width: rem(580);
    }

    .visitorFaqAlert .layui-m-layercont {
        padding: rem(60) rem(32) rem(50);
    }

    .visitorFaqAlertCon {
        max-height: rem(818);
        text-align: left;
        overflow-y: scroll;
    }

    .visitorFaqAlertCon h5 {
        line-height: rem(56);
        font-weight: bold;
    }

    .visitorFaqAlertCon p {
        line-height: rem(40);
    }

    .visitorFaqAlertClose {
        position: absolute;
        top: rem(20);
        right: rem(40);
    }
</style>
