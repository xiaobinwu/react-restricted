<template>
    <div class="logout">
        <div class="logout_confirm"> <i class="icon-confirm"></i></div>
        <p class="logout_head font-30" >{{$trans('login.logout_quitl')}}</p>
        <a :href="reff" class="logout_info font-24">{{$trans('login.logout_previous')}}</a>
        <a :href="logoutUrl" class="logout_info font-24">{{$trans('login.logout_home')}}</a>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                reff: document.referrer,
                logoutUrl: window.GLOBAL.DOMAIN_MAIN,
            };
        }
    };
</script>

<style>
    @import 'common/css/variable.css';
    .logout {
        padding: rem(100) rem(80);
        text-align: center;
    }
    .logout_confirm {
        i {
            @mixin font 240;
            color: var(--color-other-40);
        }
    }
    .logout_head {
        font-weight: bold;
        margin-bottom: rem(20);
    }
    .logout_info {
        margin-bottom: rem(20);
        display: block;
    }

</style>
