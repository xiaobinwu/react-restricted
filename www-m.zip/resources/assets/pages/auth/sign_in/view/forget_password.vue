<template>
    <div class="resetPassword_wrap">
        <div v-if="!isSuccess" class="resetPassword_step">
            <div class="resetPassHead">
                <h1 class="resetPassword_title">{{$trans('login.forgot_your_password')}}</h1>
                <div class="resetPassHead_tip font-28">
                    {{ resetPassTip }}
                    <!--{{$trans(isUnusual ? 'login.detected_unusual_m' : 'login.find_password_tips')}}-->
                </div>
            </div>
            <form class="form signInForm">
                <div class="form_group required" :class="{error: formData.email.hasError}">
                    <div class="form_data">
                        <input v-model="formData.email.value" type="email" class="form_text" :placeholder="$trans('login.type_email_address')">
                        <span v-if="formData.email.value" @click="formData.email.value = ''" class="form_suffix">
                            <i class="icon-closed"></i>
                        </span>
                    </div>
                    <p class="form_msg" v-if="formData.email.hasError">{{formData.email.msg}}</p>
                </div>

                <div class="form_group horizontal-view content-between required form_group-captcha" :class="{error: formData.captcha.hasError}">
                    <div class="form_dataBox">
                        <div class="form_data">
                            <input v-model="formData.captcha.value" type="text" maxlength="4" class="form_text" :placeholder="$trans('login.find_password_code')">
                        </div>
                        <p class="form_msg" v-if="formData.captcha.hasError">{{formData.captcha.msg}}</p>
                    </div>
                    <div class="form_captcha" @click="captcha = getCaptcha()">
                        <img class="form_captchaImg" :src="captcha" alt="captcha">
                    </div>
                </div>

                <div class="form_button">
                    <button @click.prevent="onSubmit" class="btn btnLight" href="javascript:;">{{$trans('login.find_password_continue')}}</button>
                </div>
            </form>
        </div>

        <div v-else class="resetPassword_step resetPassword_done">
            <h1 class="resetPassword_title">{{$trans('login.reset_pass_title')}}</h1>
            <div class="resetPassword_tip font-28">
                <p v-html="$trans('login.reset_pass_to_email', [formData.email.value])"></p>
                <p>{{$trans('login.reset_pass_to_email_tip')}}</p>
            </div>
            <div class="resetPassword_tip font-28 resetPassword_tip-2">
                <p>{{$trans('login.reset_pass_to_email_junk')}}</p>
                <p v-html="$trans('login.reset_pass_to_email_contact', ['/about/about-us'])"></p>
            </div>
        </div>
    </div>
</template>

<script>
    import { serviceConfirmIdentity } from 'js/service/auth';
    import { getFormData, validateFormData, getCaptcha } from '../commonData';

    export default {
        data() {
            const { $trans } = this;
            return {
                captcha: this.getCaptcha(),
                isSuccess: false,
                resetPassTip: window.gData.resetPassTip,
                // isUnusual: window.gData.isUnusual || false,    // 是否是异常账号强制重置
                formData: {
                    email: {
                        show: true,
                        hasError: false,
                        value: '',
                        msg: '',
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.find_password_email_error'),
                            }, {
                                type: 'email',
                                msg: $trans('login.find_password_email_error'),
                            }
                        ]
                    },
                    captcha: {
                        show: true,
                        hasError: false,
                        msg: '',
                        value: '',
                        rules: [
                            {
                                require: true,
                                msg: $trans('login.valid_correct'),
                            }
                        ]
                    },
                }
            };
        },
        methods: {
            getCaptcha() {
                return getCaptcha();
            },
            refreshCaptcha() {
                this.captcha = this.getCaptcha();
            },
            _validateForm() {
                return true;
            },
            async onSubmit() {
                if (validateFormData(this.formData)) {
                    const prams = getFormData(this.formData);
                    setTimeout(() => {
                        this.refreshCaptcha();
                    });
                    const { status } = await serviceConfirmIdentity.http({
                        data: prams
                    });
                    if (status === 0) {
                        this.isSuccess = true;
                    }
                } else {
                    this.refreshCaptcha();
                }
            }
        }
    };
</script>

<style>
    @import 'common/css/variable.css';

    .resetPassword_step{
        line-height: 1.4;
        .resetPassword_title{
            font-weight: bold;
            @mixin font 36;
        }
    }
    .resetPassHead{
        color: var(--color-text-primary);
        .resetPassHead_tip{
            padding: rem(20) 0;
        }
    }
    .resetPassword_done{
        .resetPassword_step-link{
            text-decoration: underline;
        }
        .resetPassword_tip{
            margin-top: rem(70);
        }
    }
    .resetPassword_email{
        font-weight: bold;
    }
</style>
