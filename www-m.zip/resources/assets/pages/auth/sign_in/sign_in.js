import 'js/bootstrap';
import { trans } from 'js/core/translate.js';
import Vue from 'vue';
import Track from 'js/track/track';

import 'modules/header/header.js';
import 'modules/footer/footer.js';

import './sign_in.css';

import router from './router';
import routerBefore from './router/routerBefore';

import App from './app.vue';

routerBefore(router);

Vue.prototype.$trans = trans;

new Vue({
    router,
    render: h => h(App),
}).$mount('#app');

new Track({
    page: true,
}).run();
