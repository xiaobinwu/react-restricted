/**
 * Created by Liu.Jun on 2018/2/1.
 */

import { regEmail, regUrl, testPassword } from 'js/utils/regExp';

const hasOwn = Object.prototype.hasOwnProperty;

export function getFormData(formData) {
    const prams = {};
    for (const key in formData) {
        if (hasOwn.call(formData, key) && formData[key].show) {
            prams[key] = formData[key].value;
        }
    }
    return prams;
}

function validateRequire(value) {
    return !(String(value).trim() === '' || value === false);
}

function validateEmail(value) {
    return regEmail.test(String(value));
}

function validateUrl(value) {
    return regUrl.test(String(value));
}

function validatePassword(value) {
    return testPassword(String(value));
}

function validatePasswordLength(value) {
    return String(value).length >= 6;
}

/**
 * @param 验证的值
 * @param 规则
 * @reutrn 返回一个数组的错误信息
 */
export function validator(value, rules, formData) {
    const ErrMsg = [];

    if (rules) {
        rules.forEach((rule) => {
            // 非空
            const isRequire = validateRequire(value);
            if (rule.require && !isRequire) {
                ErrMsg.push(rule.msg);
            }
            // 非空 检查 type
            if (isRequire) {
                // email
                if (rule.type === 'email') {
                    if (!validateEmail(value)) {
                        ErrMsg.push(rule.msg);
                    }
                }

                // url
                if (rule.type === 'url') {
                    if (!validateUrl(value)) {
                        ErrMsg.push(rule.msg);
                    }
                }

                // password
                if (rule.type === 'password') {
                    if (!validatePassword(value)) {
                        ErrMsg.push(rule.msg);
                    }
                }

                // password length
                if (rule.type === 'passwordLength') {
                    if (!validatePasswordLength(value)) {
                        ErrMsg.push(rule.msg);
                    }
                }

                // equal
                if (rule.type === 'equal') {
                    if (formData[rule.equal].value !== value) {
                        ErrMsg.push(rule.msg);
                    }
                }
            }
        });
    }

    return ErrMsg;
}

export function validateFormData(formData, key) {
    let valid = true;
    if (key) {
        // 验证单个字段
    } else {
        for (const item in formData) {
            if (hasOwn.call(formData, item)) {
                const formItem = formData[item];
                if (formItem.show) {
                    const ErrMsg = validator(formItem.value, formItem.rules, formData);
                    if (!ErrMsg.length > 0) {
                        formItem.hasError = false;
                    } else {
                        // 取第一条错误
                        [formItem.msg] = ErrMsg;
                        formItem.hasError = true;
                        valid = false;
                        return valid;
                    }
                }
            }
        }
    }
    return valid;
}

export function getCaptcha() {
    return `/captcha/default?${+new Date()}`;
}

// CSRF攻击防御token
export function getCsrfToken() {
    return $('meta[name=csrf-token]').attr('content');
}
