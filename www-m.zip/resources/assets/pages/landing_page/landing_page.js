import 'js/bootstrap';
import 'js/lib/zepto/fx.js';
import 'js/lib/zepto/fx_methodes.js';
import PubSub from 'pubsub-js';
import appSdk from 'js/core/app.sdk';
import landingTrack from 'js/track/define/landing_page.js';
import { throttle } from 'js/utils';
import { serviceLandingPage } from 'js/service/promotion';
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';

import 'modules/header/header.js';
import 'modules/footer/footer.js';

import './landing_page.css';

const landingPage = {
    page: 1,
    $setViewMore: $('.js-setViewMore'),
    init() {
        // 绑定事件
        this.bindEvent();
        runtime.trans = trans;
        landingTrack(); // 大数据埋点
    },
    bindEvent() {
        const self = this;
        const $viewMore = $('.js-viewMore');
        const $viewMorePage = $('.js-viewMorePage');
        const $btnGoTop = $('#js-btnGoTop');
        // 推荐商品区点击加载更多
        $viewMore.on('tap', (e) => {
            const $this = $(e.currentTarget);
            const $gbGoodsMoreItem = $this.parent('.view_more').prev('.subjectGoodList').find('.gbGoodsMoreItem');
            if ($this.hasClass('on')) {
                const distance = $this.parent('.view_more').offset().top - $(window).scrollTop();
                $gbGoodsMoreItem.fadeOut().css('display', 'none');
                $(window).scrollTop($this.parent('.view_more').offset().top - distance);
                $this.removeClass('on').find('.text').text(trans('promotion.view_more'));
            } else {
                $gbGoodsMoreItem.fadeIn().css('display', 'inline-block');
                $this.addClass('on').find('.text').text(trans('promotion.view_less'));
            }
            e.preventDefault();
        });
        // 精选商品区点击加载更多
        $viewMorePage.on('tap', (e) => {
            self.getMorePage();
            e.preventDefault();
        });
        // 点击加车
        $('#landingPage').on('tap', '.js-addToCart', (e) => {
            const $this = $(e.currentTarget);
            PubSub.publish('sysAddToCart', {
                goods: {
                    goodsSn: $this.attr('data-goodssn'),
                    warehouseCode: $this.attr('data-warehousecode'),
                    qty: 1,
                },
                callback() {
                    appSdk.actCartChanged();
                },
            });
            e.preventDefault();
        });
        // 点击返回顶部
        $btnGoTop.on('tap', (e) => {
            const $win = $(window);
            $win.scrollTop(0);
            e.preventDefault();
        });

        // 滚动显示置顶按钮
        const scrollShow = () => {
            const $win = $(window);
            const $scrollTop = $win.scrollTop();
            const $winHeight = $win.height();
            if ($scrollTop >= $winHeight) {
                $btnGoTop.addClass('show');
            } else {
                $btnGoTop.removeClass('show');
            }
        };

        PubSub.subscribe('nativeScroll', throttle(scrollShow, 300));
    },
    // 请求加载更多数据
    async getMorePage() {
        const self = this;
        const $viewMore = $('.view_morePage');
        self.page += 1;
        try {
            const { data, status } = await serviceLandingPage.http({
                params: {
                    page: self.page
                }
            });
            if (+status === 0) {
                if (data.goods_list && data.goods_list.length > 0) {
                    if (data.total_pages === self.page) {
                        $viewMore.addClass('dsn');
                    }
                    const temp = await import('./landingPage_item.art');
                    self.$setViewMore.append(temp(data));
                    PubSub.publish('sysUpdateCurrency', {
                        context: self.$setViewMore[0],
                    });
                }
            }
        } catch (e) {
            console.log(e);
        }
    },
};
landingPage.init();
