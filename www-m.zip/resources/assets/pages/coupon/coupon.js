import Clipboard from 'clipboard';
import 'js/bootstrap';
import layer from 'layer';
import { serviceCouponUpdateInfo } from 'js/service/coupon';
import 'modules/header/header.js';
import 'modules/footer/footer.js';
import Swiper from 'js/lib/swiper.js';
import { calcRemToPx } from 'js/utils';
import CategoryTrack from 'js/track/define/category.js';
import getCouponItem from 'js/core/goods/getCouponItem.js';
// 多语言相关
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import './coupon.css';

runtime.trans = trans;

let categoryTrack = null;
// 添加埋点
categoryTrack = new CategoryTrack({
    page: true,
});
categoryTrack.run();

// swiper切换
const couponSwiper = new Swiper('#js-couponSwiper', {
    slidesPerView: 'auto',
    watchSlidesProgress: true,
    watchSlidesVisibility: true,
    spaceBetween: calcRemToPx(60),
    slidesOffsetBefore: calcRemToPx(30),
    slidesOffsetAfter: calcRemToPx(30),
    on: {
        tap() {
            couponContentSwiper.slideTo(couponSwiper.clickedIndex);
        }
    }
});

const couponContentSwiper = new Swiper('#js-couponContentSwiper', {
    autoHeight: true,
    touchMoveStopPropagation: true,
    on: {
        slideChangeTransitionStart() {
            updateNavPosition();
        }
    }
});

function updateNavPosition() {
    $('#js-couponSwiper .active').removeClass('active');
    const activeNav = $('#js-couponSwiper .swiper-slide').eq(couponContentSwiper.activeIndex).addClass('active');
    if (!activeNav.hasClass('swiper-slide-visible')) {
        // if (activeNav.index() > couponSwiper.activeIndex) {
        //     const thumbsPerNav = Math.floor(couponSwiper.width / activeNav.width()) - 1;
        //     couponSwiper.slideTo(activeNav.index() - thumbsPerNav);
        // } else {
        //     couponSwiper.slideTo(activeNav.index());
        // }
        couponSwiper.slideTo(activeNav.index());
    }
}


// 展开收缩
$('.couponContent_panelItemArea').each((index, item) => {
    const $this = $(item);
    if ($this[0].scrollHeight > $this[0].clientHeight) {
        $this.css({ overflow: 'hidden', whiteSpace: 'nowrap' });
    } else {
        $this.next('.icon-arrow_down').css('display', 'none');
    }
});

$('.couponContent_expend .icon-arrow_down').on('touchend', (e) => {
    const $this = $(e.currentTarget);
    const $panelItemArea = $this.prev('.couponContent_panelItemArea');
    if ($this.hasClass('active')) {
        $panelItemArea.css({ whiteSpace: 'nowrap', overflow: 'hidden' }).height(calcRemToPx(25));
        $this.removeClass('active');
    } else {
        $panelItemArea.css({ whiteSpace: 'normal', overflow: 'visible' }).height($panelItemArea[0].scrollHeight);
        $this.addClass('active');
    }
    e.preventDefault();
});

// 进度条初始化
$('.couponContent_panelOperateBar').each((index, item) => {
    const $this = $(item);
    const $fillBar = $this.find('.couponContent_panelOperateBarFill');
    const percentage = $fillBar.data('value');
    $fillBar.css({ width: `${percentage}%`, transitionDelay: `${index * 0.2}s` });
});

// 剪切板
function clipHandle(item) {
    const clip = new Clipboard(item, {
        text(trigger) {
            return trigger.dataset.code;
        },
    });
    clip.on('success', () => {
        layer.open({
            content: `${trans('promotion.copy_succeed')}!`,
            skin: 'msg',
            time: 2
        });
    });
}

$('.js-copy').each((index, item) => {
    clipHandle(item);
});

$(document).on('tap', '.couponPop > .icon-closed', (e) => {
    layer.closeAll();
});

// 获取有效小时数
function getHours(time) {
    const currentDate = new Date();
    const hours = (time - ((currentDate / 1000).toFixed(0))) / 3600;
    return hours.toFixed(0);
}

// 领取
$('.js-grab').on('touchend', async (event) => {
    const $this = $(event.currentTarget);
    const templateId = $this.data('templatecode');
    $this.css('pointerEvents', 'none');
    try {
        getCouponItem({ templateCode: templateId, couponResource: 5 }).then(async (res) => {
            await resHandle(res, $this);
        });
    } catch (e) {
        // nothing
    } finally {
        $this.css('pointerEvents', 'auto');
    }
    event.preventDefault();
});
async function resHandle(res, $this) {
    if (res.status === 0) {
        const copySuccessTemp = await import('./component/copy_success/copy_success.art');
        layer.open({
            content: copySuccessTemp({ validityHours: getHours(res.data.endTime), code: res.data.couponCode }),
            className: 'goodsCoupon',
            btn: false,
            closeBtn: 0,
            shadeClose: false,
        });
        const $panelOperateContainer = $this.closest('.couponContent_panelOperateContainer');
        const $panelReceivedContainer = $panelOperateContainer.next('.couponContent_panelReceivedContainer');
        $panelOperateContainer.css('display', 'none');
        const $panelReceivedOperate = $panelReceivedContainer.css('display', 'flex').find('.couponContent_panelReceivedstatus')
            .text(res.data.couponCode).next('.couponContent_panelReceivedOperate')
            .attr('data-code', res.data.couponCode);
        const $lastPanelReceivedOperate = $panelReceivedOperate.next('.couponContent_panelReceivedOperate');
        const useLink = $this.data('link');
        if (useLink) {
            $lastPanelReceivedOperate.attr('href', useLink);
        } else {
            $lastPanelReceivedOperate.css('display', 'none');
        }
        clipHandle('.js-popCopy');
    } else if (res.data && res.data.redirectUrl) {
        window.location.href = res.data.redirectUrl;
    } else {
        layer.msg(res.msg);
    }
}

// 刷新cdn缓存
(async () => {
    try {
        const { status, data } = await serviceCouponUpdateInfo.http({
            params: {
                templateCode: $('.couponContent').data('templatecodes'),
            }
        });
        if (status === 0) {
            $('.couponContent_panelReceivedContainer').each((index, item) => {
                const $this = $(item);
                const templateid = $this.data('templatecode');
                if (data.hasOwnProperty(templateid)) { // eslint-disable-line
                    const $panelOperateContainer = $this.prev('.couponContent_panelOperateContainer');
                    $panelOperateContainer.css('display', 'none');
                    $this.css('display', 'flex').find('.couponContent_panelReceivedstatus')
                        .text(data[templateid])
                        .next('.couponContent_panelReceivedOperate')
                        .attr('data-code', data[templateid]);
                }
            });
        }
    } catch (e) { // eslint-disable-line
    }
})();
