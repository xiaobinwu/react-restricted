/**
 * Created by Liu.Jun on 2018/2/27.
 */

export default {
    detail_warehouse: 'warehouse',
    detail_warehouse_options: 'Warehouse Options',
    ships_between: 'Ships between :#$1#',
    detail_selected: 'selected',
    detail_color: 'Color',
    detail_quantity: 'Quantity',
    detail_size: 'Size',
    detail_recommended_products: 'RECOMMENDED PRODUCTS',
    click_to_description: 'Click to description',
    detail_description: 'Description',
    detail_reviews: 'Reviews',
    detail_detail: 'Detail',
    detail_customer_reviews: 'Customer Reviews',
    detail_buy_together_save: 'Buy Together & Save',
    detail_flash_sale: 'Flash sale',
    detail_off: ':#$1# OFF',
    ends_in_days: 'Ends in :#$1# days 00:00:00',
    detail_pcs_left: ':#$1# pcs left',
    detail_app_save: 'Save an extra :#$1# for using the app',
    detail_email_only: 'Email only',
    detail_presale: 'presale',
    pre_orders: ':#$1# Pre - orders',
    days_left_: ':#$1# days :#$1#:#$1#：:#$1#:#$1#：:#$1#:#$1#',
    detail_arrival_notice: 'arrival notice',
    detail_days_left_: ':#$1#:#$1# days left',
    detail_notices_submitted: ':#$1# Notices submitted',
    detail_notices_more: ':#$1# Notices more',
    detail_code_is_incorrect: 'The code is incorrect！',
    e_mail_be_invalid: 'This E-mail appears to be invalid.',
    detail_submitted_ok: 'OK',
    detail_stock_arrives: 'Once New Stock Arrives, We\'ll Email you immediately!',
    detail_e_mail_address: 'E-mail address',
    detail_validation_code: 'validation code',
    detail_submit: 'submit',
    detail_out_of_stock: 'OUT OF STOCK',
    detail_discontinued: 'discontinued',
    detail_qty: 'QTY',
    ships_cost_to: 'ships cost to',
    available_shiping_methods: 'available shiping methods',
    detail_cancel: 'cancel',
    detail_please_note: `please note:the standard and e:#$1#pedited shipping costs are only estimates;
    the actual shiping price ill be shown on the order page.`,
    accessories_discount: 'discount :#$1#',
    accessories_buy_together_save: 'Buy Together & Save',
    accessories_final_price: 'final Price',
    accessories_you__save: 'You Save',
    review_all: 'All',
    review_photos: 'Photos',
    review_videos: 'Videos',
    goods_star: 'Star',
    review_price: 'Price',
    review_ease_of_use: 'Ease of Use',
    review_build_quality: 'Build Quality',
    review_usefulness: 'Usefulness',
    review_overall_rating: 'Overall Rating',
    view_more: 'view more',
    detail_cart: 'cart',
    detail_save: 'save',
    number_of_reviews: ':#$1# reviews',
    buy_now: 'buy now',
    add_to_cart: 'add to cart',
    detail_promotion: 'promotion',
    detail_gifts_rules: 'Limited Quantity: Buy this product to receive FREE Gift Product(s). View Gifts>>',
    detail_gifts: 'Gifts',
    detail_additional_purchase_rules: `If Cart Subtotal exceeds $100.00, you can buy 1 Special Add-On for $5.00; 
    spend over 200.00 to buy 1 Add-On for $2.00. Discounts are automatically applied to shopping cart before checkout. View Promo>>`,
    detail_additional_purchase_deal: 'Additional Purchase Deal',
    detail_price_break_offer: 'Price Break Offer',
    detail_price_break_offer_rules: `Spend over $100 on the featured products, get $5 OFF. Spend over $200, 
    get $15 OFF. Discounts utomatically applied to shopping cart before checkout. View Promo>>`,
    detail_combo_deal_price: 'Combo Deal Price',
    detail_combo_deal_price_rules: `Choose any 5-unit combo from Featured Products, pay just $100. 
    Choose any 10-unit combo, pay ust $150. View Promo>>`,
    accessories_selected: 'Accessories selected: 10',
    max_per_order: 'Max per order',
    no_gift_stock_available: 'No Gift Stock Available',
    store_collected: 'Collected',
    installment: 'installments',
    please_choose: 'choose',
    get_discount: 'Spend:#$1#，Get:#$1# discount.',
    redeem_items: ':#$1# more and you are able to redeem items',
    get_add_on: 'Spend :#$1#，Get :#$1# Add-On',
    combo_deal_price: ':#$1# item(s)  more and you are able to get a Combo Deal Price ',
    spend_get_pieces: 'Spend :#$1#， Get :#$1# pieces',
    redemption_conditions_met: 'Redemption conditions met, please go to your shopping cart to redeem goods',
    for_a_discount: 'You have qualified for a discount on additional cart items',


    // 营销价格区
    begins_in: 'Begins In:',
    ends_in: 'Ends In:',
    days_h_m_s: '<b>:#$1#</b> days <b>:#$3#::#$2#::#$4#</b>',

    // promotion面板内
    sold_out: 'Sold out',
    one_pc: '1PC',
    more_pcs: ':#$1#PCS',
    see_more: 'See more',

    // 优惠券面板内
    coupon: 'Coupon',
    get_it_now: 'Get It Now',
    detail_percent_off: ':#$1#% OFF',
    use_link: 'Use Link',

    // shipping面板
    apply: 'APPLY',

    // 评论区
    pros: 'Pros',
    cons: 'Cons',
    loading: 'loading...',

    // 购买相关
    comming_soon: 'Comming Soon',
    unmatched_goods: 'Unmatched Goods',

    // 2018-03-02 15:37:48
    interest_free: 'interest-free',
    done: 'Done',
    tips: 'Tips',
    interest_information: `Orders placed with only interest-free products can enjoy :#$1# times interest-free
     privilege,otherwise , the privilage will not be enabled`,
    choose_another_country: 'Choose another country',
    cant_use_paypal_tip: 'Sorry, the item amount has exceeded the limit and cannot be paid using Paypal',
    no_more_reviews: 'No more comments!',
    super_deals_begins_in: 'Super Deals begins in'
};
