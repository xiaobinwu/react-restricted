/**
 * 搜索分类多语言配置文件
 */

export default {
    search_see_more: 'See More',
    search_see_less: 'See less',
    search_view_more: 'View more',
    search_pop_tips: 'Sorry, search keywords cannot be empty!',
    search_empty_tips: 'Sorry, search keywords cannot be empty!',
    search_cate_option: 'Sorry, there is no classification option!',
    // Flash Sale
    flash_sale_buy_now: 'Buy Now',
    flash_sale_left: 'left',
    view_more: 'View More',
    view_less: 'View Less',
    off_text: 'OFF',
    gadget_deals_after_coupon: 'after coupon',
    gadget_deals_copy: 'copy',
    copy_successed: 'Coupon successfully copied!',
    presale_buy_now: 'Buy Now',
    presale_pre_orders: 'Pre-orders',
    store_success_saved: 'success saved',
    store_canceled_save: 'canceled save',
    new_brand_coupon: 'COUPON',
    coupon_received_tip: 'Coupon Received!',
    user_links: 'User Links',
    on_sale_grab_it_now: 'On sale, Grab it now!',
    state_coming_soon: 'Coming Soon',
    btn_coming_soon: 'Coming soon',
    state_on_sale: 'On Sale',
    state_selling: 'Selling',
    state_deal_end: 'Deal End',
    timer_ends_in: 'Ends in',
    timer_begins_in: 'Begins in',
    btn_grab_it: 'Grab it',
    btn_deal_end: 'Deal end',
    deal_ended: 'Deal Ended',
    state_tomorrow: 'Tomorrow',
    only_limit: 'Only :#$1#'
};
