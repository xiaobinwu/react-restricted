/* eslint-disable */

export default {
    /* 以下内容引用于结算流程 --- 订单确认页 */
    // 页面标题
    shipping_information: 'Shipping Information',
    // 顶部地址
    name: 'Name',
    address_line_one: 'Address Line 1',
    address: 'Address',
    zip_postal_code: 'ZIP / Postal Code',
    phone_number: 'Phone Number',
    mail_address: 'E-mail Address',
    edit_shipping_address: 'Edit Shipping Address',
    edit: 'Edit',
    // 订单列表
    split_order_notice: 'Note：We have split the order for you because of different warehouse',
    table_price: 'Selected Items',
    table_num: 'Unit Price',
    table_total: 'Quantity',
    table_oper: 'Subtotal',
    goods_color: 'color',
    goods_size: 'size',
    goods_flash_sale: 'flash sale',
    goods_email_only: 'email only',
    goods_presale: 'presale',
    goods_arrival_notice: 'arrival notice',
    goods_redeem: 'redeem',
    goods_accessory: 'accessory',
    goods_gift: 'Gift',
    changes_in_stock: 'Changes in stock',
    price_disclaimer: 'Price Disclaimer',
    price_tip: 'Prices may fluctuate due to page caches, updates or sales ending; the most up-to-date price takes priority.',
    second_address_tip: 'Please include your Passport information for your selected Shipping Method (to facilitata clearance of goods)',
    place_middle_name: 'Consignee Middle Name',
    place_passport_serial: 'Consignee Passport Serial',
    place_passport_number: 'Consignee passport Number',
    place_passport_issue_date: 'Passport Issue date',
    place_issued_by: 'Issued by',
    place_tax_id: 'Tax ID',
    middle_name: 'Middle Name',
    passport_serial: 'Passport Serial',
    passport_number: 'Passport Number',
    passport_issue_date: 'Passport issue date',
    passport_issue_tip: 'Your date is incorrect.',
    issued_by: 'Issued by',
    tax_id: 'Tax Number',
    save: 'Save',
    total: 'Total',
    goods_weight: 'Weight',
    shipping_options: 'Shipping Options',
    insurance: 'Insurance',
    notice_shipping_title: 'What\'s The Total Delivery Time?',
    notice_shipping_content: `
        Total Delivery Time = Processing Time + Packing Time + Shiping Time. </br>
        Note: To get a safe delivery,we recommend to buy insurance to guarantees your shipment.
        INthe event of verified shipping damage/loss, Gearbest will resend an identical parcel free of charge.
    `,
    remote_fee: 'Already included in the remote fee',
    business_days: 'business days',
    no_tracking_number: 'No tracking number',
    shipping_method: 'Shipping Method',
    total_ost: 'Total Cost',
    place_your_order: 'Place Your Order',
    place_order: 'Place Order',
    have_discount: 'Have discount',
    dropping: 'Dropshipping',
    item_sub_total: 'Item Sub-total',
    gb_points_disscount: 'GB Points Disscount',
    coupon: 'Coupon',
    shipping_cost: 'Shipping Cost',
    promotion: 'Promotion',
    payment_discount: 'Payment discount',
    cod_cost: 'cod Cost',
    cod_discount: 'cod Discount',
    cod_shipping_limit_tip: 'Sorry, you already have 2 unfinished COD order. Please place the order after the package is received and paid',
    tax_price: 'GST',
    grand_total: 'Grand Total',
    guide_insurance: 'Note: For safer delivery, please buy the tracking & insurance fee. In cases of verified shipping loss/damage GB will resend for free.',
    total_giveintegral: 'Earn <em>:#$1#</em> GB points',
    // 优惠方式
    choose_points: 'GB Points',
    use_points: 'Use GB Points',
    want_to_use: 'I want to use',
    use_points_discount: 'Save More: You can use up to :#$1# GB Points( Worth :#$2# ) from your account for a further discount.',
    discount_tip: 'Every order you palce with us is completely safe and secure!',
    apply: 'Apply',
    use_coupon: 'Use Coupon',
    type_coupon_code: 'Type coupon code',
    for_select_items_only: 'For Select Items Only',
    expried: 'Expried',
    input_code_to_use_it: 'Input code to use it',
    available_oupon: 'Available Coupon',
    no_available_coupons: 'No Available Coupons',
    no_use_coupon: 'Don’t want to use coupon',
    coupon_invalid: 'Voucher null and void',
    subtotal_over: 'Subtotal over',
    only_on_unit: 'ONLY for 1st Unit',
    fixed_price: 'Fixed price',
    subototal_over: 'Subototal over',
    coupon_off_over: 'off over',
    coupon_unit_s: 'unit(s)',
    coupon_off: 'off',
    coupon_after: 'after coupon',
    goods_clearance: 'Clearance',

    // 弹窗按钮
    to_pay_page: 'To Pay Page ',
    submit: 'Submit',
    cancel: 'cancel',
    to_edit_address: 'To Edit Address',
    success: 'Success',
    error: 'Error',
    choice_paymode: 'Choice of payment method',
    back_shoping_cart: 'Back Shoping Cart',
    back_to_cart: 'Back to cart',
    pleace_include: '请填写以下内容',
    // 结算页地址校验弹窗提示
    check_edit_address: 'Edit Address',
    check_edit_tips: 'Your shipping address does not meet the shipping company\'s requirements',
    check_edit_btn: 'Edit the address',
    check_edit_to_address: 'The address details are incorrect. Please update the information. ',
    // 物流关税提示
    logistics_tariff_tip: 'The price offered by DHL does not include customs duties. Please cooperate with the customs if so requested. Thanks',
    // 满额免邮提示
    logistics_freeship: 'Get More <em>:#$1#</em> To Enjoy <em>FREE SHIPPING</em> <span>(Notice: ONLY For Apparel Bags & Shoes Watches & Jewelry Items)</span>',
    logistics_freeship_tip: 'Free postal activities do not include remote fees and duties',
    // 前置支付方式
    pay_channels_title: 'Payment Method(s)',
    pay_channels_tip: 'No payment method is available due to legal restrictions, regulations and channels.',
    // 针对巴西特殊收费提示
    special_fee_brazil: `
        Notice: Dear Customer, we inform you that since August 28 of this year,
        the Correios do Brasil has been charging a fee of 15 reais on all international orders.
    `,
    // 定金膨胀
    depoist_goods_choose: 'to save',
    depoist_goods: 'Deposit',
    depoist_no_discount: 'Note: Points and Coupons  cannot be applied to deposit-to-presale items;<br/> Final Payment includes shipping costs, insurance and taxes.',
    depoist_clause_tip: 'You cannot purchase until you agree and acknowledge that your desposit is non-refundable.',
    depoist_clause_text: 'I agree and acknowledge that my desposit is non-refundable.',
    depoist_rules: `
        <h6>Rules</h6>
        <ul>
            <li>Payments will be split into two: initial deposit and final payment.</li>
            <li>
                For even bigger savings, GearBest applies a “deposit expansion”;
                this is a FREE bonus that increases your deposit. The exact amount
                of this increase depends on the specific product.
            </li>
            <li>The remaining balance must be paid within the specified deadline. </li>
            <li>
                Failure to pay the balance before the deadline will see the original
                deposit retained and the order cancelled.
            </li>
            <li>
                For the final payment of the balance, points and coupons cannot
                be used. However, different payment methods can be used and/or
                offline payment are welcome.
            </li>
            <li>
                GearBest reserves the right to amend the guidelines for this
                payment scheme. If you have any questions, please contact our
                Support Staff. (https://support.gearbest.com/)
            </li>
            <li>
                Final Price is the actual amount paid for the item, which equals
                deposit and final payment.
            </li>
            <li>
                (Worked example). Price: $100 ($5 deposit saves $10). The final
                payment: $85=100-10-5. So the final Price: $90=85+5 (Note: this
                applies to item cost only and excludes any tax fee, shopping fee
                and insurance fee.)
            </li>
        </ul>
    `,
    // 定金膨胀明细面板
    depoist_stage: 'Stage',
    depoist_title: 'Deposit',
    depoist_final_payment: 'Final Payment',
    depoist_count_down: 'The booking ends in :#$1# days :#$2#',
    depoist_balance_due: 'Balance Due',
    depoist_discount: 'Discount',
    depoist_actual_payment: 'Actual payment',
    // 结拦截生单弹窗
    depoist_created_alert_tip: 'Please register first before purchasing products that enjoy "deposit expansion".',
    depoist_created_alert_to_register: 'Register now',
    depoist_created_alert_later: 'Later',
    // cod 货到付款
    cod_online_payment_title: 'Online Payment',
    cod_online_payment_note: 'Wire Transfer, Gredit or debit card, paytm, Google Pay, Credit or debit Card.',
    cod_cash_on_delivery: 'Cash on Delivery',
    cod_cash_on_delivery_note: 'There is an additional fee (US$10.00) for this service.',
    cod_cash_on_delivery_tip: 'Payment upon Receipt is a payment method offer for our  customers in UAE, Saudi Arabia. To be eligible for Payment upon Receipt, the Total Price payable (price after discounts) must be between 50 and 400 USD.',
    // 短信验证弹窗
    cod_sms_alert_title: 'Determine',
    cod_sms_alert_top: 'Upon receiving the package,  please pay :#$1# in Cash. Payment must be made in full with cash. We will send an SMS containing the code, please check your phone.',
    cod_sms_alert_send_btn: 'Send SMS',
    cod_sms_alert_note: 'If you do not receive an SMS message, please contact our Customer Serveive Staff.',
    cod_sms_alert_check_btn: 'Check Out',
    cod_sms_alert_bottom: 'In the event of receipt failure, please check the address details and mobile  numberyou entered.',
    cod_sms_alert_err_empty: '验证码不可以为空',
    cod_sms_alert_input_place: 'Validation Code',
    // 支付方式前置
    wallet_pay_discount: 'Wallet',
    payment_pre_bottom_tip: 'Every order you place with us is completely safe and secure.',
    payment_pre_online_nothing: ' No payment method available,please contact our <a href=":#$1#">customer service</a> for assistance.',
    payment_pre_online_retract: 'Retract',
    payment_pre_online_more: 'More',
    payment_pre_wallet_send_email: 'Forget Password ? >>',
    payment_pre_wallet_send_set_email: 'Set up transaction password >>',
    payment_pre_wallet_placetxt: 'Enter The Transaction Password',
    payment_pre_wallet_title: 'GB Wallet',
    payment_pre_wallet_pay: 'Pay',
    payment_pre_wallet_alert_reset: `
        How to Set/Reset Your Wallet Password:
        Click Set your Wallet password/Forget Wallet password->Check your Verification Email-> Set Wallet Password->Succeed</br></br>
        Kindly note: If you can’t find the verification email,
        you can also check your junk mail or contact Customer Service  for help.
    `,
    payment_pre_wallet_alert_note: 'Wallet is a safe and secure payment method which you can use the Wallet balance to pay for new orders or withdraw at any time.',
    payment_pre_wallet_error_setpwd: 'Please set up your Wallet password firstly.',
    payment_pre_wallet_pwd_check_tip: 'Please enter your transaction password',
    payment_pre_no_paychannel: 'No payment method available，please contact our customer service for assistance;',
    payment_pre_no_select_channel: 'Please select a payment method.',
    payment_pre_check_currency_top: ':#$1# is not accepted by :#$2#, please select another currency.',
    payment_pre_set_tip: 'Email sent. Please check your email address:":#$1#" to change your password.',
    payment_pre_reset_tip: 'Email sent. Please check your email address:":#$1#" to change your password.',
    payment_pre_filter_onlaine: 'The selected payment method is not allowed to pay with Wallet together ,please select another payment method',

    /* 以下内容引用于结算流程 --- 支付结果页 */
    // --- 支付状态标题
    payment_successful: 'Payment Successful!',
    payment_pending: '正在支付',
    payment_failed: 'Payment Failed!',
    payment_refund: '退款',
    payment_submit: 'Submit Successful',

    // --- 订单信息
    payment_paid: 'Paid',
    payment_need_to_pay: 'Need to Pay',
    payment_order_no: 'Order No',
    payment_failed_tip: 'System is busy, please try again later.',
    payment_successful_title: 'We Appreciate Your Shopping! Your order has been paid successfully.',
    payment_successful_info1: 'Please remember your order number',
    payment_successful_info2: 'The payment amount is',
    payment_successful_tip: `
        For your safety, we contact you to confirm your order details. If you do, please reply us as soon as possible for a faster shipment. Thanks!
    `,

    // --- 按钮
    payment_check_my_order: 'Check my Order',
    payment_contact_us: 'Contact Us',
    payment_check_bank: 'Check bank details',
    payment_bank_btn: 'Check :#$1# details',
    payment_print: 'Print',
    payment_info: 'Info',
    payment_try_again: 'Try Again',
    payment_message_us: 'Message Us',
    payment_continue_to_payment: 'Continue to payment',

    // --- 线下支付提示语
    payment_line_tip_title: 'Order will be expired within',
    payment_line_tip_text: 'days.Please pay as soon as possible.',
    payment_line_tip_content: `
        Normally payment takes 3-4 days to confirm, please be patient.Any problems regarding your payment, you are welcome to contact us directly
    `,
    payment_line_bankinfo_title: 'Shroff Account number',
    payment_offline_agt_tip: 'Please print your Voucher and pay it at corresponding store within 3 days. Any problems regarding your payment, you are welcom to contact us directly.',
    payment_offline_zl_tip: 'Please print your Voucher and pay it at Servipag store within 3 days. Any problems regarding your payment, you are welcom to contact us directly.',
    payment_offline_in_tip: 'Please kindly check your payment code in your email sending by Payment company and follow the instruction to pay your order.',

    // --- 公共提示文案
    payment_to_messenger: 'Go to messenger',
    payment_click_to_mes: 'Click to track shipping at anytime.',
    payment_click_to_mes_tip: 'Tips: Click Messenger, Get a chance to WIN a phone, and track shipping at anytime.',
    payment_cancelled_tip: 'Sorry, your order was canceled when payment was made. If payment is successful, our Customer Support Team will process your refund using the same payment method.',
    payment_company_days: 'days',
    payment_coupon_tip: 'Order payment successful, a special offer will be given after you confirm order receipt.',

    // 后置礼包
    payment_special_notes: 'Special Notes',
    payment_enter: 'Enter',
    payment_my_coupon: 'My coupon',
    payment_to_view: 'page to view your coupon',

    /* 以下内容引用于快捷购物流程 --- 新支付结果页 */
    // 支付信息
    quickbuy_payinfo_title: 'We Appreciate Your Shopping! Your order has been paid successfully.',
    quickbuy_payinfo_content: 'Please remember your order number: <b>:#$1#.</b> The payment amount is: <b class="org">:#$2#</b>',
    quickbuy_payinfo_copy: 'Copy',
    quickbuy_payinfo_copy_tip: 'Click to save the order number, this is required when contacting our customer support.',
    quickbuy_payinfo_copy_success: 'copy success',
    // 设置账户
    quickbuy_config_title: 'Confirm registration information',
    quickbuy_config_err_tip: 'Kindly know that this email has been registered, please try another new email address.',
    quickbuy_config_email: 'Email',
    quickbuy_config_change: 'change',
    quickbuy_config_tips: 'Tips',
    quickbuy_config_tip_txt: 'To better understand your order details and improve your shopping experience, please improve your personal information',
    quickbuy_config_save: 'Save',
    quickbuy_config_clause: 'I agree to Gearbest <a href=":#$1#/about/terms-and-conditions.html" target="_blank">Terms and Conditions</a> and <a href=":#$2#/about/privacy-policy.html" target="_blank">Privacy Policies</a>',
    quickbuy_config_clause_eu: 'I confirm all information provided is my own; I understand and agree it will be used as per the GearBest <a href=":#$1#/about/privacy-policy.html" target="_blank">Privacy Policy</a>; I can withdraw my prior consent at any time',
    // 校验提示语
    quickbuy_config_clause_error: "To complete the registration, you must agree to gearbest's website Terms and Conditions.",
    quickbuy_config_clause_eu_error: 'To complete registration, you must provide your consent to the above.',
    quickbuy_config_email_reg: 'The email must be a valid email address.',
    quickbuy_config_email_require: 'Please enter a valid email address',
    quickbuy_config_psd_reg: 'Must be at least 8 characters; please use at least 2 types (letters, numbers, or special characters)',
    quickbuy_config_psd_require: 'Please enter password',
    quickbuy_config_psd2_reg: 'Please enter the same value again.',
    quickbuy_config_psd2_require: 'Repeat your password',
    quickbuy_config_email_title: 'E-mail address',
    quickbuy_config_psd_title: 'Enter a password',
    quickbuy_config_psd2_title: 'Comfirm password',
    // 账户设置成功
    quickbuy_finish_title: 'Please activate your account!',
    quickbuy_finish_section: 'our account is awaiting activation. We wiil resend the activation email to help you complete your registration.',
    quickbuy_finish_email_address: 'Email address',
    quickbuy_finish_btn_resend: 'Resend Verification Email',
    quickbuy_finish_btn_change: 'Change Email Address',
    quickbuy_finish_count_down: '剩余倒计时： :#$1#',
    // 弹窗内容
    quickbuy_alert_title: 'Please verify with your original registered password',
    quickbuy_alert_oldpwd_title: 'password',
    quickbuy_alert_oldpwd_require: 'Please enter password',
    quickbuy_alert_oldpwd_err: 'Please input the correct password.',
    quickbuy_alert_newemail_title: 'New Email',
    quickbuy_alert_newemail_require: 'Please enter a valid email address',
    quickbuy_alert_newemail_reg: 'The email must be a valid email address.',
    quickbuy_alert_newemail_err: 'This email address has already been registered.',
    // 支付进入弹窗提示
    quickbuy_alert_enter_title: 'Help us to help you',
    quickbuy_alert_enter_conten: `
        Please be sure to provide accurate registration information.
        This helps us to deal quickly and efficiently with order changes,
        returns, lost packages, and other unexpected events.
        This also allows you to contact our helpful customer service team with your order information.
    `,


    // 个人中心订单列表、订单详情
    nav_my_orders: 'My Orders',
    order_all: 'All',
    order_unpaid: 'Unpaid',
    order_notshipped: 'Not shipped',
    order_partly_shipped: 'Partly shipped',
    order_shipped_out: 'Shipped out',
    order_delivered: 'Delivered',
    order_refunded: 'Refunded',
    union_order: 'Union Order',
    spit_order_tips: 'We hava spit the order for you because of different warehouse',
    order: 'Order',
    pieces_of_goods: ':#$1# pieces',
    order_total: 'Total:',
    union_order_total: 'Total:',
    nav_order_information: 'Order information',
    please_pay_within: 'Please pay within',
    product_list: 'Product list',
    order_detail_subtotal: 'Subtotal:',
    shipping_time: 'Shipping Time',
    shipping_insurance: 'Shipping Insurance',
    order_amount_deatils: 'Order Amount Details',
    product_amount: 'Product Amount',
    shipping_fee: 'Shipping Fee',
    wallet_cost: 'GB Wallet',
    coupon_cost: 'Coupon',
    points_cost: 'Points',
    order_detail_total: 'Total:',
    payment_method: 'Payment method',
    check_my_ticket: 'Check my ticket',
    submit_a_ticket: 'Submit a ticket',
    nav_order_tracking: 'Order tracking',
    package: 'Package',
    tracking_logistics: 'Logistics:',
    tracking_no: 'Tracking No:',
    transfer_no: 'Transfer No:',
    order_tracking: 'Order Tracking',
    tracking_view_more: 'View more',
    tracking_product_list: 'Product list',
    reconfirm_cancel: 'Order will be cancelled, Please reconfirm.',
    payment_reference: 'Payment Reference',
    swiftcode: 'SWIFTCODE',
    iban: 'IBAN',
    country: 'Country',
    city: 'City',
    bank_name: 'Bank Name',
    bank_account: 'Bank Account',
    account_holder: 'Account Holder',
    blz: 'BLZ',
    special_id: 'Special ID',
    // eslint-disable-next-line
    bank_transfer_desc: `Please don't forget to submit the correct <em>payment reference</em> which you can see in this page to your bank when doing money transfer,because it's very important for us to do payment confirmation in due time!`,
    order_waitting_for_payment: 'waitting for payment',
    order_pending: 'Pending',
    order_paid: 'Paid',
    order_submitted: 'Order Submitted',
    order_packed: 'Packed',
    order_apply_for_refund: 'Apply for refund',
    order_partial_pay: 'Partial pay',
    order_refunding: 'Refunding',
    order_cancelled: 'Cancelled',
    order_reviewed: 'Reviewed',
    order_deleted: 'Deleted',
    days: 'days',
    continue_to_pay: 'Continue to pay',
    contact_us: 'Contact Us',
    dispatch_faster: 'Dispatch Faster',
    dispatch_faster_success: 'Success！ We will process your order as soon as possible.',
    tracking: 'Tracking',
    receipt: 'Receipt',
    review: 'Review',
    go_shopping: 'Go shopping',
    boleto_bancario: 'Check boleto voucher',
    oxxo: 'Check OXXO voucher',
    pago_efectivo: 'Check Pago Efectivo voucher',
    bank_transfer: 'Bank Transfer',
    please_chose_reson: 'Please Chose Reason',
    please_chose_reason: 'Please Chose Reason',
    reconfirm_refund: 'Are you sure to cancel your order?',
    reconfirm_receipt: 'Do you confirm receipt?',
    bank_account_information: 'Bank account information',
    order_canceled: 'Order canceled',
    payment_timeout: 'Payment timeout',
    manually_cancel: 'Manually cancel',
    estimated_shipping_time: 'Estimated Shipping Time',
    estimated_shipping_time_value: 'Approximately :#$1#-:#$2# business days',
    no: 'No',
    a_reference: 'A reference',
    an_entity: 'An entity number',
    payable_amount_val: 'Payable amount value',
    expiry_date: 'Due date/Expiry date',
    multibanco_tips: 'Please pay your order within :#$1# days.',
    multibanco: 'Multibanco',
    multibanco_dialog_title: 'Your MultiBanco Payment details',
    order_detail_return_coupon: 'Order is successful, you have a new coupon, will be automatically presented after the order is signed.',
    payment_local_btn: 'Check :#$1# Voucher',
    pending_tip: 'There is a little delay for payment status confirmation, please come back to check your order status a few minutes later.',
    country_specific_bank_key: 'Country specific bank key(s)',

    // 定金膨胀相关文案
    deposit: 'Deposit',
    final_payment: 'Final Payment',
    the_period_for_final_payment: 'The period for final payment: :#$1#',
    button_pay_deposit: 'Pay a deposit',
    button_pay_final_payment: 'Pay final payment',
    not_allow_to_pay_final_payment: 'Sorry, the final payment is not ready yet.',
    stage: 'Stage :#$1#',
    not_yet_paid: 'Not yet paid',
    completed: 'Completed',
    goods_final_amount: 'Balance Due',
    totalswell_discount: 'Discount',
    download_invoice: 'Download Invoice',
    issue_invoice: 'Issue an invoice',
    tips_expired_invoice: `Cuz it's over 30 valid days to issue invoice,please contact customer service to apply.`,
    tips_error_invoice: `Billing failed, please try again.`,
    button_issue: 'Issue',
    invoice_title: 'Invoice title',
    generating: 'Generating',
    tips_generating: 'Invoice generation is expected to be generated within 2 hours. Please download later.',
    personal: 'Personal',
    company: 'Company',
    billing_adress: 'Billing adress',
    use_shipping_address: 'Use shipping address',
    use_another: 'Use another',
    receiveName_required_msg: 'Please insert invoice title',
    city_required_msg: 'Please enter city',
    address1_required_msg: 'Please enter address',

    // Wire Transfer支付方式
    wire_transfer_btn: 'Wire Transfer',
    wire_transfer_bankinfo_title: 'Wire transfer account',
    wire_transfer_acc_name: 'Account name',
    wire_transfer_acc_nameval: 'YOUSONGTONG E-COMMERCE (HONGKONG) LIMITED',
    wire_transfer_acc_number: 'Account number',
    wire_transfer_acc_numberval: 'OSA90000323435100',
    wire_transfer_bank_name: 'Bank name',
    wire_transfer_bank_nameval: 'BANK OF COMMUNICATIONS CO.,LTD OFFSHORE BANKING UNIT',
    wire_transfer_acc_add: 'Account address',
    wire_transfer_acc_addval: 'NO 188,YINCHENG ZHONG ROAD,SHANGHAI,CHINA',
    wire_transfer_swift_code: 'SWIFT Code',
    wire_transfer_swift_codeval: 'COMMCN3XOBU',
    wire_transfer_conten_m_tip: `NOTICE: Once paid, please contact our <a href=":#$1#">Support Center</a> with the order number,
                            the bank receipt and amount you sent.`,

    // cod 支付方式
    cod_discount: 'cod discount is',


    seller_refund: 'Request a Refund',
    contact_seller: 'Contact Seller',
    contact_the_seller: 'Contact the seller',
    order_ended: 'ended'
};
