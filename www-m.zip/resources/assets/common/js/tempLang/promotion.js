/**
 * Created by WuShaoBin on 2018/2/28.
 */

export default {
    copy_succeed: 'Copy Succeed',
    promo_start_in: 'Promo Start In:',
    start_in: 'Start In:',
    ends_in: 'Ends In:',
    begins_in: 'begins In:',
    view_less: 'View Less',
    view_more: 'View More',
    coupon_received: 'Coupon received! Your coupon code is:',
    copy_to_use: 'COPY TO USE',
    all_taken: 'all taken',
    coming_soon: 'COMING SOON',
    promotion_received: 'Received',
    comes_in: 'Comes in',

    // 针对红包裂变活动提多语言
    // --- 弹窗部分 ---
    fission_alert_blacklist: 'lllegal request, please participate in other activities on GearBest.',
    fission_alert_maxnum: 'You have reached the maximum number of Red Packet actions today. Please come back tomorrow.',
    fission_alert_rules_title: 'Activity Rules',
    fission_alert_index_share: 'Invite friends to get more cash.',
    fission_alert_no_full: 'Withdrawal target has not been reached',
    fission_alert_share_help: 'Invite frierds to help',
    fission_alert_setup: 'Money successfully withdrawn! Please check your GB Wallet.',
    fission_alert_setup_btn: 'Open next red packet (<em></em>S)',
    fission_alert_leavepage: 'Your red packet has not been opened! Expires in 24:00.',
    fission_alert_leavepage_btnline: 'Leave',
    fission_alert_leavepage_btnstron: 'Continue',
    fission_alert_login: 'Please Login in first',
    fission_alert_login_btn: 'Login In',
    fission_alert_detail_title: 'Has been collected',
    fission_alert_detail_still: 'still remains!',
    fission_alert_detail_help: 'help',
    fission_alert_detail_sharebtn: 'Send to',

    // 领取红包成功模块
    fission_rules: 'rules',
    fission_withdraw: 'withdraw',
    fission_record_text: 'Record',
    fission_money_bag: 'Money Bag',
    fission_top_first_title: 'want daily cash?',
    fission_top_second_title: 'collect coins!',
    fission_collected_text: 'coins collected',
    fission_packet_text: 'Red packet will wexpire',
    fission_invite_text: 'invite your friend to help',
    fission_text_get: 'Got',
    fission_text_collected: `
        <em class="js-currency" data-currency=":#$1#"></em> collected <em class="js-currency" data-currency=":#$2#"></em> remaining
    `,

    // 红包领取成功弹框
    fission_layer_title: 'Congratulations!',
    fission_layer_packet: 'You got',
    fission_layer_packet_tip: 'from the Money Bag!',
    fission_layer_packet_coin: 'coins collected',
    fission_layer_packet_invite: 'invite friends to help',

    // --- 分享功能提示语
    fission_share_noapp: '请去下载app',
    fission_copy_link_btn: 'Copy Link',
    fission_copy_success: 'Copy Success',

    // --- 推荐位 ---
    fission_recommend_title: 'Recommend Products',
    // 裂变活动
    fission_released: 'released',
    fission_a1_rules_btn: 'RULES',
    fission_notapp_title: 'COLLECT A RED PACKET<br>EVERY DAY GET CASH',
    fission_uptp_money: 'Up to <span class="js-currency" data-currency="10"></span><br>Money Bag',
    fission_openinapp: 'OPEN IN APP',
    fission_helpinapp: 'HELP IN APP',
    fission_remains: ':#$1# still remains!',
    fission_haveapacket: 'You also have a Red<br>Packet after helping',
    fission_reword: 'reword',
    fission_dailycash: 'WANT DAILY CASH?<br>COLLECT COINS!',
    fission_open: 'OPEN',
    fission_collectpacket: 'Collect a red packet every day<br>get cash the easy way',
    fission_endover: 'Your friend\'s activity is over,<br>thanks for the help.',
    fission_send_cash: 'Send you a cash red packet<br>Up to :#$1# Red Packet',
    fission_open_it: 'OPEN IT NOW',
    fission_stillhas_money: 'Your money bag<br>still has :#$1#<br>available to withdraw',
    fission_invite_help: 'INVITE FRIENDS TO HELP',
    fission_help_open: 'HELP OPEN',
    fission_u_helped: 'Thanks! You have helped!',
    fission_helped_got: 'Has helped your friend got :#$1#',
    fission_remains_foru: ':#$1# still remains for your red packet!',

    // 预约提醒
    reserved: 'Reserved',
    reserved_successfully2: `Reserved successfully. We will notify you before the promotion starts. 
    Also you can check all your reservation details at <a class="link" href=":#$1#" data-app="reservations">'My Reservation'</a>`,
    reserved_latest_version: 'Successfully reserved, update to the latest version for reservation record',
    reserved_failed: 'Attempt failed, try again later.',
    my_reservation: 'My reservation',
    confirm_cancel_subscribe: 'Are you sure you wish to cancel?',
    valid: 'Valid',
    remind_me: 'Remind Me',
    on_sale: 'ON SALE',
    grab_coupon_now: 'Grab coupon now',
    coupons_unavailable: 'Coupons unavailable',
    all_coupons_taken: 'All coupons taken',
};
