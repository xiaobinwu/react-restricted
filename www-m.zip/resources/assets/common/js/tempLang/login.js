export default {
    login: 'Login',
    register: 'Register',
    type_email_address: 'E-mail address',
    type_password: 'Password',
    sign_forgot_your_password: 'Forgot your password?',
    sign_email_error: 'Please enter a valid email address',
    sign_password_empty: 'Provide a password',
    sign_password_error: 'Enter at least 6 characters',
    sign_in: 'Sign In',
    or_connect_via: 'Or connect via',
    facebook: 'Facebook',
    google: 'Google',
    vkontakte: 'Vkontakte',
    forgot_your_password: 'Forgot Your Password?',
    find_password_tips: 'Enter your email address below and Click the Continue button',
    email_address: 'E-mail address',
    find_password_code: 'Access code',
    find_password_email_error: 'Please enter a valid email address',
    find_password_code_error: 'Please enter a valid verification code',
    find_password_continue: 'Continue',
    register_email_address: 'E-mail address',
    set_password: 'Create a Password',
    enter_the_code: 'Enter the code',
    register_email_error: 'Please enter a valid email address',
    register_email_repeated: ':#$1# is already in use',
    register_password_empty: 'Provide a password',
    register_password_error: 'Enter at least 8 characters',
    register_code_error: 'Please enter the correct code.',
    registration_terms: 'I agree to GearBest<a target="_special" href=":#$1#" ' +
                        'class="formAgree_textLink">Terms and Conditions</a> and ' +
                        '<a target="_special" href=":#$2#" class="formAgree_textLink">Privacy Policies</a>.',
    register_password_tip: 'Must be at least 8 characters; please use at least 2 types (letters, numbers, or special characters)',
    valid_correct: 'Please enter the correct code',
    reset_pass_title: 'Reset Your Password Safely',
    reset_pass_to_email: 'We\'ve sent an email to: <strong class="resetPassword_email">:#$1#</strong>.',
    reset_pass_to_email_tip: 'Please follow the steps to reset your password.',
    reset_pass_to_email_junk: 'Don\'t forget to check your junk  email folder.',
    reset_pass_to_email_contact: 'If you require assistance,contact our <a class="resetPassword_step-link" href=":#$1#">contact us</a>',
    new_pass_title: 'Reset Your Password',
    new_pass_confirm: 'Confirm',
    new_pass_re_enter: 'Re-enter password',
    new_pass_new_pass: 'New password',
    reg_success_account_is: 'Your account is',
    reg_success_shop_now: 'Shop Now',
    reg_success_my_account: 'Check my account',
    reg_success_gb_points: '500 GB points have been sent to your account .',
    reg_success_title: 'Your account activated successfully !',
    over_activation: 'Your account is awaiting activation. We will resend the activation email to help you complete your registration',
    over_to_activation: 'Please activate your account !',
    over_resend: 'RESEND VERIFICATION EMAIL',
    create_pass: 'Create a password',
    valid_same_pass: 'Please enter the same value again.',
    keep_me: 'Keep me signed in',
    login_keep_tip_new1: 'Choosing "Keep me signed in" reduces the number of times you\'re asked to sign in on this device.',
    login_keep_tip_new2: 'To keep your account secure, use this option only on your personal devices.',
    // detected_unusual_m: 'An unusual activity was detected on your account, please change your current password or keep on using it.',
    logout_quitl: 'You have successfully quitl',
    logout_previous: 'Return to the previous page',
    logout_home: 'Return to Home',

    // new
    link_login_tip: 'Please enter the email address account',
    link_email: 'Link to email account now',
    link_email_tips_unregistered: 'An activation email has been sent to you. Please follow the prompts to activate your customer account.',
    link_email_tips_registered: 'The email address has been registered, please log in',
    link_email_defeated: 'The email address has is already in use; please use another.',
    link_email_resend: 'Resent successfully. Please check your email box to activate your account. After ' +
                        ':#$1# seconds,<br> you can resend it again.',
    link_email_succeed: 'Successfully linked',
    resend_activation_email: 'Resend Activation Email',
    button_sign_in: 'Sign In',
    change_email: 'Change E-mail',

    account_linking_is_successful: 'Account linking is suceessful!',
    please_check_your_activation_email: 'Please check your activation email to complete your registration.',
    email_address_is: 'E-mail address : :#$1#',
    account_linking_failed: 'Account linking failed!',
    please_try_later: 'Please try later',
    try_btn: 'Try Again',
    account_linking_already: 'This messenger account is already linked, please change your account.',
    registration_terms_confirm_eu: 'I confirm all information provided is my own; I understand and agree it will be used as per the GearBest ' +
                                    '<a target="_special" href=":#$1#" class="formAgree_textLink formAgree_textLink_eu">Privacy Policy</a> ; ' +
                                    'I can withdraw my prior consent at any time',
    registration_terms_eu: 'I agree to GearBest <a target="_special" href=":#$2#" class="formAgree_textLink">Privacy Policy</a> and ' +
    '<a target="_special" href=":#$1#" class="formAgree_textLink">Terms and Conditions</a>.',
    new_members_bonus: '*New Member\'s Bonus, $:#$1# OF COUPONS FREE!',
    new_members_bonus_register: '*New Member\'s Bonus, $:#$1# OF COUPONS FREE!',
    register_agree_tip: 'To complete the registration, you must agree to gearbest\'s website Terms and Conditions.',
    register_agreeeu_tip: 'To complete registration, you must provide your consent to the above.',
    reg_success_account_return: 'After <span class="red">:#$1#s</span> will return to the previous page.',

    // 访客模式 相关
    visitor_purchase_btn: 'Continue to Purchase',
    visitor_faq_btn: 'Fast Shopping FAQ',
    visitor_faq_rules: `
        1. If you shop as a guest, you can skip the normal login process and start purchasing goods immediately.<br/>
        2. For the best possible shopping experience and to ensure your order is processed correctly, 
        please add your registration details following a successful purchase. 
        This gives you free access to our class-leading after-sales support and many additional benefits.<br/>
        3. Please add your order information to the new account after registering on the order completion page, 
        or via the link included in the order confirmation email.<br/>
        4. Once you complete your purchase, please keep your order information in a safe place to track the order progress/status.<br/>
        5. We will keep a record for up to three days for you; if more than three days have elapsed, 
        you will need to re-enter the address details.<br/>
        6. Please note: when you exit guest mode, you may lose your shopping cart record!<br/>
        7. Whenever you make a purchase, we will send the order information to your inbox. 
        You can contact Customer Support with your order information for an order status update.
    `,
    visitor_customer_service: 'Customer Service',
};
