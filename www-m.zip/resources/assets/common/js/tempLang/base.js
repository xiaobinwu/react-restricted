export default {
    ok: 'OK',
    // eslint-disable-next-line
    empty_msg: `Oops! It's empty now......`,
    satisfaction_survey: 'Satisfaction survey',
    error_equal: '输入不一致',
    error_password: '密码格式错误',
    error_regex: '正则表达式匹配错误',
    error_required: '必填项',
    super_deals: 'Super Deals'
};
