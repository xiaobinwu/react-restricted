/**
 * 个人中心多语言配置文件
 * Created by Liu.Jun on 2018/2/26.
 */
/* eslint-disable */

export default {
    ok: 'Ok',

    // 个人中心首页
    account_pointsdata: 'My Points: :#$1# Points = <span class="js-currency" data-currency=":#$2#"></span>',
    account_my_order: 'My Order',
    account_order_all: 'All',
    account_order_unpaid: 'Unpaid',
    account_order_noshipped: 'Not shipped',
    account_order_shipped_out: 'Shipped Out',
    account_order_reviews: 'Reviews',
    account_favorites: 'My Favorites',
    account_wallet: 'GB Wallet',
    account_points: 'My Points',
    account_coupons: 'My Coupons',
    account_contact_us: 'Contact Us',
    get_point_info: 'Get 50 Points',
    enter_e_mail_tips_title_eu: 'Want to Earn 50 Points? Subscribe to GearBest!',

    // 编辑个人信息
    nav_personal_information: 'Personal Information',
    personal_information: 'Personal:#$1#Information',
    change_password: 'Change:#$1#Password',
    address_book: 'Address:#$1#Book',
    nickname: 'Name:',
    gender: 'Gender:',
    private: 'Private',
    male: 'M',
    female: 'F',
    personal_mobilephone: 'Mobile Phone:',
    personal_confirm: 'Confirm',
    personal_nickname_error: 'Please enter your name',
    personal_mobilephone_error: 'Please only use: numbers, +, -, or ()',
    modify_successfully: 'Modify successfully！',
    personal_confirm_error: 'System is busy, please try again later.',
    personal_birthday: 'Birthday',

    // 修改密码
    original_password: 'The Original Password:',
    new_password: 'New Password:',
    confirm_password: 'Confirm Password:',

    // 地址列表
    email: 'Email',
    add_a_new_address: 'Add a New Address',
    default_address: 'Default',
    delete_address_popout: 'Are you sure to delete the address?',
    cancel: 'Cancel',
    max_of_address: 'You can save 5 addresses',
    shipping_address: 'Shipping Address',

    // 地址编辑
    address_first_name: 'First name:',
    address_last_name: 'Last name:',
    address_email_address: 'E-mail address:',
    address_phone_number: 'Phone Number:',
    address_country: 'Country / Region:',
    address_zip_code: 'ZIP/Postal Code',
    address_state: 'State/County',
    address_city: 'City',
    street_address1: 'Street Address line 1:',
    street_address2: 'Street Address line 2:',
    street_address3: 'Street Address line 3:',
    street_address4: 'Street Address line 4:',
    // eslint-disable-next-line
    street_address_tips: 'Note: Please provide a full, detailed shipping address in English: Room Number, Floor, House Number and Street Name. Thank you.',
    street_lang_address1: 'Street Address line 1（:#$1#）:',
    street_lang_address2: 'Street Address line 2（:#$1#）:',
    tax_id: 'Tax id:',
    date_of_birth: 'Date Of Birth',
    citizen_code_name: 'Not A Citizen Of The Russian Federation',
    consignee_passport_serial: 'Consignee Passport Serial:',
    consignee_middle_name: 'Consignee Middle Name:',
    consignee_passport_number: 'Consignee Passport Number:',
    passport_issue_date: 'Passport Issue date:',
    set_default_address: 'Set to the default address',
    issued_by: 'Issued by',
    empty_msg_of_country: 'Please select country of the recipient',
    // eslint-disable-next-line
    empty_msg_of_province: `Please enter consignee's State`,

    // 我的收藏
    nav_my_favorites: 'My Favorites',
    nav_goods: 'Goods',
    nav_store: 'Store',
    goods_collection_count: 'You have <em id="totalCount">:#$1#</em> items in your collection',
    store_collection_count: 'You have <em id="totalCount">:#$1#</em> stores',
    unsubscribe: 'Unsubscribe',
    expired: 'Expired',

    // 我的积分
    nav_my_points: 'My Points',
    points_amount: 'You have <em>:#$1# points</em> which equal :#$2# Credits.',
    points_tips: '<a href=":#$1#">Check out</a> how to use them and get more points.',
    points_expiry_date: 'Points expiry date: :#$1#',

    // 我的coupon
    nav_unused: 'Unused',
    nav_used: 'Used',
    nav_expired: 'Expired',
    coupon_use_link: 'Use Link',
    more: 'More',
    fixed_price: 'Fixed price',

    // 访客模式相关
    visitor_email_note: `
        Note: We will send order information email to your email address;
        please ensure it is correct to receive important order information and allow you to track your order.
    `,

    // 电子钱包
    wallet_my_wallet: 'My Wallet',
    wallet_click_here: 'Click here',
    wallet_to_pwd: 'to change your Transaction Password',
    wallet_no_record: 'No record',
    wallet_view_more: 'View More',
    wallet_income: 'Income',
    wallet_disbursement: 'Disbursement',
    wallet_frozen: 'Frozen',
    wallet_unfrozen: 'Unfrozen',
    wallet_other: 'Other',

    wallet_send_email: 'Send mail',
    wallet_send_tip: 'To ensure wallet safety, please set/reset a secure trasaction password by email.',
    wallet_email: 'E-mail address',
    wallet_send: 'Send',
    wallet_app_email_verfication: 'Application Email Verification',
    wallet_rest_transaction_password: 'Reset Transaction Password',

    wallet_result_success: 'Sent Successfully',
    wallet_result_tip1: 'We\'ve sent a message to the email address ',
    wallet_result_tip2: 'you have on file with us.Please follow the instructions provided in the message to reset your password.',
    wallet_result_txt: `
        Didn't receive the mail from us?<br>
        Check your bulk or junk email folder<br>
        If you still can't find it, click
        <a href="http://support.gearbest.com/">support center</a> for help
    `,

    wallet_change_title: 'Set up Transaction Password',
    wallet_change_txt: 'Your password must contain 6-10 characters and include either 2 of the following: letters, numbers,'
    + ' and special characters (e.g. >, @).',
    wallet_change_oldpassword: 'The original Password',
    wallet_change_password: 'Password',
    wallet_change_cpassword: 'Confirm Password',
    wallet_change_confirm: 'Confirm',
    wallet_change_error1: 'Passwords do not match', // 两次输入不一致
    wallet_change_error2: 'Invalid password; Your password must contain 6-10 characters and include either 2 of the following: letters, numbers, and special characters (e.g. >, @).', // 密码不符合规则
    wallet_change_error0: 'Please enter old password .', // 旧密码字段必填
    wallet_change_success: 'Successful',
    wallet_changebtn_txt: 'Reset Transaction Password',
    wallet_resetlink_txt: 'Forgot Wallet Password?',

    wallet_my_gb_wallet: 'My GB Wallet',
    wallet_transaction_record: 'Transaction Record',
    wallet_account_management: 'Account Management',
    wallet_tips: 'GB Wallet is a fast and secure payment tool,'
    + ' making it easy to stay up-to-date with all your account transactions. <a href=":#$1#" target=":#$2#">Check out</a> how to use your wallet.',

    wallet_account_name: 'Account Name',
    wallet_email_address: 'Email Address',
    wallet_available_balance: 'Available Balance',
    wallet_balance_reserved: 'Balance Reserved',
    wallet_note: 'Notes',
    wallet_notetxt: '1.To ensure wallet safety, please set up a secure transaction before first use.'
    + ' <a href=":#$1#" target=":#$2#">Set up transaction password</a></br>'
    + '2.Refunds issued for orders will be added to your GB Wallet Account Balance.</br>'
    + '3.Balance Reserved refers to funds currently in use and pending clearance; it is not accessible unless the order is canceled.',

    wallet_transaction_status: 'Transaction Status',
    wallet_all: 'all',
    wallet_refund: 'Refund',
    wallet_expense: 'Expense',
    wallet_table_date: 'Date',
    wallet_table_tn: 'Transaction Number',
    wallet_table_status: 'Status',
    wallet_table_defray: 'Disbursement',
    wallet_table_income: 'incoming',
    wallet_table_detail: 'Detail',
    wallet_table_withdrawal: 'Withdrawal',
    wallet_table_case: 'Case',
    wallet_table_deduction: 'Deduction',
    wallet_table_reward: 'Reward',
    wallet_table_expired: 'Expired',

    wallet_transaction_password: 'Transaction Password',
    wallet_htftc: 'How to find out your Transaction Code?',
    wallet_tptip: 'Transaction password is the entity that establishes the authenticity of the user.'
    + ' It is a high-security lock for your GB Wallet, which reduces the risk from an unauthorized intruder.',
    wallet_send_notetipe: 'Please keep secret and remember your transaction password',
    wallet_send_stip: 'Please continue click to the application button if your didn\'t obtain Email verification in 1 Minutes.</br>'
    + 'Didn\'t receive the mail from us?</br>Check your bulk or junk email folder.</br>'
    + 'If you still can\'t find it, click <a href=":#$1#" target=":#$2#">support center</a> for help</br>',
    wallet_total: 'Total',
    wallet_put_forward_tip: 'GB Wallet is applicable for GearBest purchases. Available Balance can be withdrawn.',

    // 个人中心 我的评论
    user_review: 'My Review',
    user_review_tip: 'Want an EXTRA<span>160 points (worth $3.20)</span>? Review your items!',
    user_test_var: '恭喜你获得:#$1#元:#$2#',
    user_review_write: 'Write Review',
    user_review_awrite: 'Write a Review',
    user_review_commented: 'To be commented',
    user_review_previous: 'My Previous Reviews',
    user_review_from: 'From: ',
    user_review_pros: 'Pros: ',
    user_review_cons: 'Cons: ',
    user_review_ratprice: 'Price Rating:',
    user_review_ratease: 'Ease-of-use Rating:',
    user_review_ratbuild: 'Build Quality Rating:',
    user_review_ratuse: 'Usefulness Rating:',
    user_review_ratoverall: 'Overall Rating:',
    user_review_points: '10 Points for verified Text Reviews',
    user_review_uploadimgpoints: 'Upload Images:Get 20 GB Points',
    user_review_uploadvideopoints: 'Upload Video:Get 50 GB Points',
    user_review_name: 'Name:',
    user_review_title: 'Title:',
    user_review_placeholder: 'Please don\'t exceed 3,000 characters.',
    user_review_prompt: 'Please provide JPEG, GIF, or PNG. Width at least 500px and Height must ove 600px.'
    + 'All the photo size should not exceed 2 MB.',
    user_review_videotitle: 'Video Title:',
    user_review_videourl: 'Video URL:',
    user_review_textone: 'Please note the video:',
    user_review_texttwo: 'Should state you bought the product from us.',
    user_review_textthr: 'YouTube text shows the product page URL.',
    user_review_textfou: 'e.g.:https://www.youtube.com/watch?v=n3v4kTqF_w8',
    user_review_submit: 'Submit Reviews',
    coupon_received_success: 'Coupon received!',
    coupon_valid_date: 'Valid for :#$1# Hour(s) after receiving.',
    coupon_your_code: 'Your coupon code is:',
    coupon_copy_to_use: 'Copy to Use',
    continue_to_pay_hint: 'Payment overdue, the order will be canceled soon.',
    national_id_number: 'National ID number',

    // 站内信
    message_my_message: 'My Messages',
    message: 'message',
    message_order_m: 'Order & Shipping Info',
    message_promotion_m: 'Promo Notices',
    message_system_notice_m: 'System Messages',
    message_view_m: 'View details',
    message_operation_m: 'Operation',
    message_empty_m: 'You have no news',
    message_balance: 'Balance',
    message_coupon: 'Coupon',
    message_notice: 'Notice',

    // 会员体系
    member_entrance: 'VIP Center',
    member_rule: 'Rule',
    member_card_aristocrats: 'Aristocrats',
    member_card_croissance: 'Ma valeur de croissance:',
    member_slack_describe: 'Congratulations on upgrading and getting a gift package.Try your luck now!',
    member_test_luck: 'Test your luck',
    member_but_another: 'Buy Another One',
    member_happy_birthday: 'Happy Birthday!',
    member_receive_gift: 'Receive Gifts',
    member_recomendations_good: 'Recomendations For You',
    member_current_need_growth: 'Need :#$1# Growth Value',
    member_current_my_benefits: 'My Benefits',

    member_address_growthnote: 'Complete the information to receive :#$1# Growth Value',
    member_growth_value: ':#$1# Growth Value',
    member_rules: 'Rules',
    member_rule_more: 'More',
    member_rule_collapse: 'Collapse',
    member_rule_learn_more: 'Learn More',
    member_rule_bigtitle_growthvalue: 'How to quickly obtain growth value?',
    member_rule_bigtitle_growthbenefits: 'Membership Benefits',
    member_rule_bigtitle_growthreduced: 'Will my growth value be reduced?',

    member_incomplete: 'Incompleted',
    member_completed: 'Completed',
    member_shopping: 'Shopping',
    member_shopping_tips: 'Order payment ($) will be converted at an exchange rate of $1 for 10 growth value.',
    member_order_quantity: 'Order Quantity',
    member_oq_tips: 'When you shop for the first time and make a second purchase, you will receive extra growth value bonuses.',
    member_complete_profile: 'Complete Profile',
    member_cp_tips: `GearBest will provide a birthday gift package based on your personal information.
        Complete your profile to earn 2-30 growth value.`,
    member_advanced_treasure: 'Advanced Treasure Box',
    member_atb_tips: `When your title is upgraded, you will earn an "Advanced Treasure Chest" with a massive $188 site-wide coupon! For example,
        being promoted from "Registered Member" to "Bronze Member".Limit: You can only receive one "Advanced Treasure Box" per corresponding
        level once every year.`,
    member_upgrade_package: 'Upgrade Package',
    member_up_tips: `When your level is upgraded, you will get an "Upgrade Package" containing an $88 site-wide coupon!
        Example: When you upgrade from lv.1 to lv.2, you will get one "Upgrade Package".Limit: You can only receive one "Upgrade Package"
        per corresponding level once every year.`,
    member_exclusive_pageage: 'VIP Exclusive Package',
    member_vep_tips: `Every time you shop (excluding returns/refunds) and place 3 orders, you will receive a VIP Exclusive Package.
        Enjoy complementary coupons or GB Points for huge savings. Limit: Up to 2 VIP Packages per calendar month.`,
    member_product_return: '30 Day Product Return',
    member_pr_tips: 'Any product purchased at GearBest can be returned for any reason within 30 days (provided it does not affect product re-sale).',
    member_free_shipping: 'FREE Return Shipping',
    member_fs_tips: `Any GearBest goods purchased and returned unconditionally within 30 days can enjoy "free return shipping"
        privileges; GearBest will bear up to $10 of the costs.`,
    member_gb_credits: 'GB Credits',
    member_gbc_tips: `Compared to normal Registered Members, VIP members can use their GB Points to offset a higher percentage of
        the order amount (normally 30%) and also earn more points.`,
    member_priority_service: '24/7 Priority Service',
    member_ps_tips: `To better serve the needs of our VIP members, GearBest customer service will provide priority status
        to resolve queries and issues.`,
    member_birthday_gift_pack: 'Birthday Gift Package',
    member_bgp_tips: 'GearBest will present you with a coupon on your birthday. This will help you save even more during your shopping.',
    member_reduce_growth_tips1: `From the date you become a VIP member, a small portion of your growth will be deducted every 90 days.
        If the remaining growth value after deduction is lower than the maximum growth value required by the grade, your grade will be
        reduced to the corresponding grade range. The specific deduction rules are as follows:`,

    member_month_january: 'January',
    member_month_february: 'February',
    member_month_march: 'March',
    member_month_april: 'April',
    member_month_may: 'May',
    member_month_june: 'June',
    member_month_july: 'July',
    member_month_august: 'August',
    member_month_september: 'September',
    member_month_october: 'October',
    member_month_november: 'November',
    member_month_december: 'December',
    member_date_canel: 'Cancel',
    member_date_set: 'Set',

    turntable_yes_tip: 'Congratulations on upgrading and getting a gift package.',
    turntable_no_tip: 'You can only participate when upgrading or advancing!',
    turntable_go_upgrade: 'I want to upgrade',
    turntable_go_try: 'Try your luck now!',
    lottery_dialog_title: 'Congrats! You Received',
    lottery_dialog_coupon: 'COUPON:',
    lottery_dialog_points: 'Points',
    lottery_dialog_growth: 'Growth Value',
    lottery_dialog_userlink: 'My Coupon',
    lottery_dialog_checkpoints: 'Check Points',
    member_lottery_level_tip: 'Get :#$1# more growth value, to upgrade with a Lucky Draw chance.',
    member_special_get_tip: 'Get a FREE Gift Pack for every :#$1# Paid Orders.',
    member_special_finished_tip: 'You have already received two gift packages this month!',
    member_open_package: 'Open Package',

    member_layer_vip_title: 'Congratulations! You are now a <br/><strong class="layerTitle_strong font-36">:#$1# VIP Member</strong>',
    member_layer_vip_info: ':#$1# VIP Treasure Gift',
    member_layer_level_title: 'Congrats on your promotion to <br/><strong class="layerTitle_strong font-36">Lv.:#$1#!</strong>',
    member_layer_level_info: 'Lv.:#$1# Upgrade Package',

    lottery_dialog_birthday_info: 'Please accept our gift!',
    lottery_dialog_special_title: 'Completed :#$1# Orders',
    lottery_dialog_special_info: 'Enjoy your Gift Pack!',
    member_lottery_note: 'Note: The Game and prizes have no official affiliation with Apple or Google.',
    member_lottery_title: 'Advanced Treasure Box',

    review_comment_placeholder: 'Please write in English, this helps customers from different countries to understand your opinion.:#$1#'
    + 'Consider::#$2#'
    + 'Why did you choose this rating ?:#$3#'
    + 'What did you like or dislike about the item ?:#$4#'
    + 'What’ s the advantage / disadvantage over other similar products ?:#$5#'
    + 'Will you recommend it to your friends ?',

    my_reservations: 'My Reservations',
    effective: 'Effective',
    activity: 'Activity',
    not_ready_yet: 'Not ready yet, Try again later.',
    phone_validate_text: 'The phone number you entered is incorrect. To ensure your package delivery, please enter a valid number accordingly.',
    yes: 'YES',
    no: 'NO',

    my_message_batch_read: 'Mark all messages as read.',
    my_message_unread_no: 'There are no messages to clear.'
};
