/**
 * 采用事件发布机制，此文件是一些dom 原生事件的封装
 */

/* eslint-disable func-names,prefer-arrow-callback */

import PubSub from 'pubsub-js';

window.addEventListener('DOMContentLoaded', (e) => {
    PubSub.publish('nativeReady', e);
});

window.addEventListener('load', (e) => {
    PubSub.publish('nativeLoad', e);
});

window.addEventListener('scroll', (e) => {
    PubSub.publish('nativeScroll', e);
});

document.addEventListener('click', (e) => {
    PubSub.publish('nativeDocumentClick', e);
});

window.addEventListener('resize', (e) => {
    PubSub.publish('nativeResize', e);
});

window.addEventListener('touchmove', (e) => {
    PubSub.publish('nativeTouchmove', e);
});
