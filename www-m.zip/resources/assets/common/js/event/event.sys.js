import PubSub from 'pubsub-js';

import { updateCurrency } from 'js/core/currency';
import { initLazyload, updateLazyload } from 'js/utils/lazyload';
import { addToCart, buyNow } from 'js/core/goods/cart.js';
import updateUserStatus from 'js/core/user/updateUserStatus';

/**
 * 系统订阅的事件
 */
PubSub.subscribe('sysUpdateCurrency', (msg, data) => {
    updateCurrency(data);
});

PubSub.subscribe('sysUpdateUserStatus', (msg, $eleCartNum) => {
    updateUserStatus($eleCartNum);
});

PubSub.subscribe('sysAddToCart', (msg, data) => {
    addToCart(data);
});

// 订阅一键购(buy now)
PubSub.subscribe('sysBuyNow', (msg, data) => {
    buyNow(data);
});

PubSub.subscribe('sysInitLazyload', (msg, data) => {
    initLazyload(data);
});

PubSub.subscribe('sysUpdateLazyload', (msg, data) => {
    updateLazyload(data);
});
