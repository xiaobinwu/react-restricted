/**
 * Created by Liu.Jun on 2018/4/5.
 */

import axios from 'axios';
import Cookies from '../utils/cookie';
import { push as loadingPush, pop as loadingPop, errPop, redirectUrl } from './ajaxLoaing';

const gAxios = axios.create({
    timeout: 20 * 1000,
    headers: {
    }
});

// 简单请求
// gAxios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8'

// 全局设置
gAxios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

// 检验token
const token = document.head.querySelector('meta[name="csrf-token"]');

// 添加请求拦截器
gAxios.interceptors.request.use((config) => {
    const cookie = Cookies.get();
    if (!cookie[config.xsrfCookieName]) {
        if (token) {
            config.headers.common['X-CSRF-TOKEN'] = token.content;
        } else {
            console.error('CSRF token not found: https://laravel.com/docs/csrf#csrf-x-csrf-token');
        }
    }
    loadingPush(config);
    return config;
}, error => Promise.reject(error));

// 添加响应拦截器
gAxios.interceptors.response.use((res) => {
    redirectUrl(res); // 这行代码需要放在最前面
    loadingPop(res.config);
    errPop(res);
    return res.data;
}, (err) => {
    // 请求报错，服务器500，取消上一个请求等都会跑到这里来
    loadingPop(err.config);
    return Promise.reject(err);
});

export default gAxios;
