/**
 * Created by Liu.Jun on 2018/4/5.
 */

// import jsonp from 'jsonp';

// import $ from 'jquery';
import { push as loadingPush, pop as loadingPop, errPop, redirectUrl } from './ajaxLoaing';

const xhrData = {};
let tokenStart = 1;

function getPathName(url) {
    const a = document.createElement('a');
    a.setAttribute('href', url);
    return a.pathname.replace(/[^a-z]/g, '_');
}

const defaultOptions = {
    timeout: 10 * 1000,
    dataType: 'jsonp',
};

// $( document ).ajaxComplete(function() {
//     debugger;
// });

function gJonp(config) {
    config.type = config.method;
    delete config.method;
    loadingPush(config);

    // callback 形式才可以return 一个可abort的请求
    return new Promise((resolve, reject) => {
        xhrData[config.cancelToken] = $.ajax({
            ...defaultOptions,
            url: config.url,
            data: config.params,
            // jsonpCallback: config.jsonpCallback,
            jsonpCallback: config.cache ? (config.jsonpCallback || getPathName(config.url)) : '',
            cache: config.cache || false,
            success(data) {
                redirectUrl({ data, config }); // 这行代码需要放在最前面
                loadingPop(config);
                errPop({ data, config });
                resolve(data);
            },
            error(XMLHttpRequest, textStatus, errorThrown) {
                loadingPop(config);
                reject(errorThrown);
            },
            complete() {
                // 释放请求结果
                delete xhrData[config.cancelToken];
            }
        });
    });
}

// 兼容 axios 取消 api
class CancelTokenSource {
    constructor() {
        this.token = tokenStart;
        tokenStart += 1;
    }
    cancel() {
        const calledFn = xhrData[this.token];
        if (calledFn) {
            return calledFn.abort();
        }
        // 请求已经结束或者不存在
        return 0;
    }
}

gJonp.CancelToken = {
    source() {
        return new CancelTokenSource();
    }
};

export default gJonp;
