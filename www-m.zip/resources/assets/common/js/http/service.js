import http from './index';

/**
 * 请求公共类
 */
export default class Service {
    constructor(params) {
        this.params = Object.assign({
            method: 'jsonp',
            loading: true,
            isCancel: true,
            errorPop: true,
            usePreResult: false, // 多次执行  http 方法直接返回上一次的promise 对象，不会判断参数变更，谨慎使用
            isLogin: false, // 设置为true时，接口只能在用户登录后才能登录，否则自动调到登录页面
        }, params);
    }

    http(params) {
        const curParams = Object.assign({}, this.params, params);

        if (curParams.usePreResult && this.$preResult) return this.$preResult;

        if (curParams.isCancel) {
            this.cancel();
        }
        this.cancelToken = http.CancelToken.source(curParams.method);

        this.$preResult = http(({
            cancelToken: this.cancelToken.token,
            ...curParams,
        }));

        return this.$preResult;
    }
    cancel() {
        if (this.cancelToken) {
            this.cancelToken.cancel();
        }
    }
}
