import Thirdparty from 'js/core/thirdparty.js'; // 第三方统计数据
import asyncScript from 'js/utils/asyncScript.js';
import preload from 'js/core/preload/preload.js'; // 页面预加载
import updateMessageCount from 'js/core/user/updateMessageCount.js'; // 获取站内信数量
import guideEDM from 'js/core/guideEDM.js';
import { initFirebase } from 'js/core/firebase/main.js'; // firebase fcm

export default () => {
    // AFF 系统的推广链接的cookie记录
    new Thirdparty();

    // EDM 引流到 app
    guideEDM();

    // 站内信总数
    updateMessageCount(document.querySelectorAll('.js-msgCount'));
    initFirebase();
    // 三方 异步script
    ['//js.affasi.com/affasi_web.min.js', window.GLOBAL.LOGSSS_URL].map(item => asyncScript({
        url: item
    }));

    // load 后 1s 预加载
    setTimeout(() => {
        preload(window.nextCommon);
    }, 1000);
};
