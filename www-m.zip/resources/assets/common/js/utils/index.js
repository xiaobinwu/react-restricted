/**
 * 全局工具函数
 */


/**
 * 节流阀函数（当多次执行待封装的函数时，为了节约性能，函数将在一次间隔时间内最多执行一次）
 * @param  [Function] func 待封装的函数
 * @param  [Number] wait 间隔时间
 * @param  [Boolean] immediate 如果为 true，函数会在一开始执行一次
 * @return [Function] 返回封装后的函数
 * @author lijiazhan
 */
function debounce(func, wait, immediate) {
    let timeout;
    let args;
    let context;
    let timestamp;
    let result;

    function later() {
        const last = new Date() - timestamp;

        if (last < wait && last >= 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            if (!immediate) {
                result = func.apply(context, args);
                args = null;
                context = args;
            }
        }
    }

    return (...params) => {
        context = this;
        args = params;
        timestamp = new Date();
        const callNow = immediate && !timeout;
        if (!timeout) timeout = setTimeout(later, wait);
        if (callNow) {
            result = func.apply(context, args);
            args = null;
            context = args;
        }
        return result;
    };
}


/**
 * 时间戳格式化
 * @param  [Date|Number] date 要格式化的日期对象或者时间戳（注意：时间戳单位为秒）
 * @param  [String] format 进行格式化的模式字符串，默认为：'yyyy-MM-dd hh:mm:ss'
 * @return [String]
 * @author lijiazhan
 * @demo
 *     dateFormat(new Date()); // ==> 2006-01-02 08:09:04
 *     dateFormat(1234567891); // ==> 2006-01-02 08:09:04
 *     dateFormat(1234567891, 'yyyy-MM-dd hh:mm:ss');       // ==> 2006-01-02 08:09:04
 *     dateFormat(new Date(), 'yyyy-M-d h:m:s');            // ==> 2006-1-2 8:9:4
 *     dateFormat(new Date(), 'MMM dd, yyyy hh:mm:ss');     // ==> Jan 02, 2006 08:09:04
 *     dateFormat(new Date(), 'MMMM d, yyyy');              // ==> January 2, 2006
 *     dateFormat(new Date(), 'MMM dd, yyyy hh:mm:ss TT');  // ==> Mar 15, 2018 18:15:58 AM
 *
 * 你还可以提前设置一些默认值，比如：dateFormat.format 和 dateFormat.months
 */
function dateFormat(date, format) {
    const $date = date instanceof Date ? date : new Date(date * 1000);

    if (!dateFormat.format) {
        dateFormat.format = 'yyyy-MM-dd hh:mm:ss';
    }

    let $format = typeof format === 'string' ? format : dateFormat.format;

    if (!dateFormat.months) {
        dateFormat.months = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December',
        ];
    }

    const map = {
        y: $date.getFullYear(),
        M: $date.getMonth() + 1,
        d: $date.getDate(),
        h: $date.getHours(),
        m: $date.getMinutes(),
        s: $date.getSeconds(),
        T: $date.getHours() < 13 ? 'AM' : 'PM'
    };

    $format = $format.replace(/(([yMdhmsT])(\2)*)/g, (all, t1, t2) => {
        const v = map[t2];

        if (t2 === 'y') {
            return `${v}`.substr(4 - t1.length);
        } else if (t2 === 'M' && t1.length > 2) {
            if (t1.length === 3) {
                return dateFormat.months[v - 1].substr(0, 3);
            }
            return dateFormat.months[v - 1];
        }
        return t1.length > 1 ? `0${v}`.substr(-2) : v;
    });

    return $format;
}

/**
 * JS模拟表单POST跳转
 * @param {*要跳转的链接} uri
 * @param {*参数键值对} data
 */
function postLocation(uri, data) {
    const formEl = document.createElement('form');
    formEl.method = 'post';
    formEl.action = uri;

    if (typeof data !== 'undefined') {
        Object.entries(data).forEach((item) => {
            const ele = document.createElement('input');
            ele.setAttribute('type', 'hidden');
            ele.setAttribute('name', item[0]);
            ele.setAttribute('value', item[1]);
            formEl.appendChild(ele);
        });
    }

    document.querySelector('body').appendChild(formEl);
    formEl.submit();
}

/**
 * 当前uri参数值替换或添加,支持多个重复的参数
 * @param {*参数名} nam
 * @param {*参数值} value
 */
function replaceUrlVal(name, value) {
    const winlocation = window.location;

    if (typeof name === 'undefined' || typeof value === 'undefined') {
        return winlocation.href;
    }

    // 不允许传含 ? &的字符
    if (/[?&=]/.test(`${name}${value}`)) {
        return winlocation.href;
    }

    let query = winlocation.search;
    const regMatch = new RegExp(`[\\?&]${name}=[^&]*`, 'gi');
    const matchList = query.match(regMatch);

    // 存在或存在多个匹配
    if (matchList && matchList.length) {
        matchList.forEach((item) => {
            query = query.replace(item.replace(/[?&]/, ''), `${name}=${value}`);
        });
    } else {
        const prefix = /\?/.test(query) ? '&' : '?';
        query += `${prefix}${name}=${value}`;
    }

    return `${winlocation.origin}${winlocation.pathname}${query}${winlocation.hash}`;
}

function calcRemToPx(px) {
    const baseFont = Number.parseFloat(document.querySelector('html').style.fontSize);
    return (px / 75) * baseFont;
}


// https://github.com/jashkenas/underscore/blob/master/underscore.js
function throttle(func, wait, ops) {
    let context;
    let args;
    let result;
    let timeout = null;
    let previous = 0;
    const options = Object.assign({}, ops);

    const later = () => {
        previous = options.leading === false ? 0 : Date.now();
        timeout = null;
        result = func.apply(context, args);
        if (!timeout) {
            context = null;
            args = null;
        }
    };

    return (...reArgs) => {
        const now = Date.now();
        if (!previous && options.leading === false) previous = now;
        const remaining = wait - (now - previous);
        context = this;
        args = reArgs;
        if (remaining <= 0 || remaining > wait) {
            if (timeout) {
                clearTimeout(timeout);
                timeout = null;
            }
            previous = now;
            result = func.apply(context, args);
            if (!timeout) {
                context = null;
                args = null;
            }
        } else if (!timeout) {
            timeout = setTimeout(later, remaining);
        }
        return result;
    };
}

// 解析当前url的serach
function getUrlQuery(href) {
    const url = String(href === undefined ? window.location.href : href).replace(/#.*$/, '');
    const search = url.substring(url.lastIndexOf('?') + 1);
    const obj = {};
    const reg = /([^?&=]+)=([^?&=]*)/g;
    search.replace(reg, (rs, $1, $2) => {
        const name = decodeURIComponent($1);
        const query = String(decodeURIComponent($2));
        obj[name] = query;
        return rs;
    });
    return obj;
}

/**
 * @param callBack 间隔回调
 * @param endCall  结束调用
 * @param maxTime
 * @param duration
 * @returns {end} [function] 停止方法
 */
function timer(callBack, endCall, maxTime = 60, duration = 1000) {
    let times = maxTime;
    let countdownTimer = null;
    let callFn = null;

    const end = () => {
        clearTimeout(countdownTimer);
        callFn = null;
        endCall();
    };
    callFn = () => {
        if (times > 0) {
            callBack(times);
            times -= 1;
            countdownTimer = setTimeout(() => {
                callFn();
            }, duration);
        } else {
            end();
        }
    };

    callFn();
    return end;
}

// 针对需要连续调用的promise ，只会触发一次请求，改变所有 promise 的状态
/**
 * @param getData Promise
 * @returns {function(): Promise<any>}
 */

function queuePromise(getData, {
    useCache = true,
} = {}) {
    let callFnQueue = [];
    let time = 0;
    let promiseStatus = 'pending';
    let returnData;
    return (params) => {
        time += 1;
        return new Promise(async (resolve, reject) => {
            if (time === 1 || !useCache) {
                try {
                    returnData = await getData(params);
                    // 保证顺序
                    setTimeout(() => {
                        callFnQueue.forEach(item => item(0, returnData));
                        // 清空列队
                        callFnQueue = [];
                    });
                    // resolve
                    promiseStatus = 'fulfilled';
                    resolve(returnData);
                } catch (e) {
                    setTimeout(() => {
                        callFnQueue.forEach(item => item(1));
                        // 清空列队
                        callFnQueue = [];
                    });
                    // reject
                    promiseStatus = 'rejected';
                    reject();
                }
            } else {
                if (promiseStatus !== 'pending') {
                    if (promiseStatus === 'fulfilled') {
                        resolve(returnData);
                    } else {
                        reject();
                    }
                    return;
                }

                callFnQueue.push((status, data) => {
                    if (status === 0) {
                        resolve(data);
                    } else {
                        reject();
                    }
                });
            }
        });
    };
}

// 获取时区
function getTimezone() {
    const timezone = new Date().toString().split('GMT')[1].substr(0, 3);
    return String(timezone);
}

// polyfill passive
function applyPassive() {
    let passiveIfSupported = false;
    const options = Object.defineProperty({}, 'passive', {
        get() {
            passiveIfSupported = { passive: true };
            return passiveIfSupported;
        }
    });
    try {
        window.addEventListener('testPassive', null, options);
    } catch (err) {
        //
    }
    return passiveIfSupported;
}

/**
 * 判断类型
 * @param data
 * @returns {string}
 * @demo
 * getType({a:1})
 * 返回：'Object'
 */
function getType(data) {
    return Object.prototype.toString.call(data, null).slice(8, -1);
}


export {
    debounce,
    dateFormat,
    postLocation,
    replaceUrlVal,
    calcRemToPx,
    throttle,
    getUrlQuery,
    timer,
    queuePromise,
    getTimezone,
    applyPassive,
    getType,
};
