/**
 * 动画执行器-display和动画执行处理
 * luochongfei
 * 2018-08-01 11:35:01
 * 解释：
 *      因浏览器会合并同一执行过程中对同一元素设置样式
 *      所以对一个隐藏的元素，先display:block 再运行一段动画，那动画无法正常执行
 * 下方代码原理：
 *      将元素显隐操作与动画通过定时器异步错开
 */

export default {
    show({
        ele = '',
        beforeDisplay = 'block',
        fn = null
    } = {}) {
        if (ele instanceof HTMLElement) {
            ele.style.display = beforeDisplay;
            setTimeout(() => {
                if (fn) fn();
            });
        }
    },

    // hide({
    //     ele = '',
    //     fn = null,
    //     afterDisplay = '',
    // }) {
    //     if (ele instanceof HTMLElement) {
    //         const fn2 = (e) => {
    //             if (e.target === e.currentTarget) {
    //                 ele.style.display = afterDisplay;
    //                 ele.removeEventListener('transitionend', fn2);
    //             }
    //         };
    //         ele.addEventListener('transitionend', fn2, false);
    //         if (fn) {
    //             fn();
    //         }
    //     }
    // }
};
