export function toAppLink(fn, timerSecound = 2000) {
    const startTime = new Date().getTime();
    const timerToApp = setTimeout(() => {
        const endTime = new Date().getTime();
        if (!startTime || endTime - startTime < timerSecound + 200) {
            try {
                fn();
            } catch (e) {
                console.log(e);
            }
        }
    }, timerSecound);

    // 离开页面时中断倒计时(中止中转到应用市场)
    try {
        let hidden;
        let visibilityChange;
        if (typeof document.hidden !== 'undefined') {
            hidden = 'hidden';
            visibilityChange = 'visibilitychange';
        } else if (typeof document.msHidden !== 'undefined') {
            hidden = 'msHidden';
            visibilityChange = 'msvisibilitychange';
        } else if (typeof document.webkitHidden !== 'undefined') {
            hidden = 'webkitHidden';
            visibilityChange = 'webkitvisibilitychange';
        }
        document.addEventListener(visibilityChange, () => {
            if (document[hidden]) {
                clearTimeout(timerToApp);
            }
        }, false);

    } catch (e) {
        console.log(e);
    }
    window.onblur = () => {
        clearTimeout(timerToApp);
    };
}

/** app 版本对比
 * @param currentVersion 当前版本
 * @param miniVersion 最小版本
 * @returns {boolean} true -> 大于等于 ,false -> 版本不够
 */
export function versionCompar(currentVersion, miniVersion) {
    if (currentVersion) currentVersion = currentVersion.replace(/(ver)|(\.)/g, '');
    if (miniVersion) miniVersion = miniVersion.replace(/\./g, '');
    return +currentVersion >= +miniVersion;
}

// APP跳转判断版本号
export function updateVersionTips({
    currentVersion = '',
    miniVersion = '',
    beforeVersion = () => {},
    afterVersion = () => {},
} = {}) {
    if (versionCompar(currentVersion, miniVersion)) {
        afterVersion();
    } else {
        // 版本不够
        beforeVersion();
    }
}
