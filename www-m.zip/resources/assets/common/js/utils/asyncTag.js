/**
 * Created by Liu.Jun on 2018/8/6.
 */

export default function (tagName = 'link', attr = {
    as: 'font',
    // crossorigin: 'anonymous',
    type: 'font/woff2'
}) {
    const docMeta = document.getElementsByTagName('meta')[0];
    const addLink = document.createElement(tagName);
    Object.entries(attr).forEach(([key, value]) => {
        addLink[key] = value;
    });
    docMeta.parentNode.insertBefore(addLink, docMeta);
}
