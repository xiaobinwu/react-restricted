/**
 * Created by Liu.Jun on 2018/7/23.
 */

export default function ({
    url = '',
    async = true
} = {}) {
    const docScript = document.getElementsByTagName('script')[0];
    const newJs = document.createElement('script');
    newJs.src = url;
    newJs.async = !!async;
    docScript.parentNode.insertBefore(newJs, docScript);
}
