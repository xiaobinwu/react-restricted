/**
 * 选择单个
 * @param select [String] css选择器
 * @param root [HTMLELement] 父级元素
 * @returns {Element | null} 返回选择的节点
 */
export function getSelector(select = '', root = document) {
    return root.querySelector(select);
}

/**
 * 选择多个
 * @param select [String] css选择器
 * @param root [HTMLELement] 父级元素
 * @returns [Array]<HTMLELement> 返回所有选择节点
 */
export function getSelectorAll(selects = '', root = document) {
    return [...root.querySelectorAll(selects)];
}

/**
 * 选择单个元素，如果成功则执行回调
 * @param select
 * @param callback(err, res)
 */
export function selectTodo(select = '', callback) {
    const element = getSelector(select);
    callback(element === undefined, element);
}

/**
 * 选择多个元素，如果成功则执行回调
 * @param selects
 * @param callback(err, res)
 */
export function selectsTodo(selects = '', callback) {
    const elements = getSelectorAll(selects);
    callback(elements.length === 0, elements);
}

/**
 * 获取元素scrollTop
 * @param select
 * @returns {number}
 */
export function getScrollTop(select = '') {
    let scrollTop = 0;
    if (select) {
        selectTodo(select, (err, element) => {
            if (!err) scrollTop = element.scrollTop;
        });
    } else {
        scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    }
    return scrollTop;
}
