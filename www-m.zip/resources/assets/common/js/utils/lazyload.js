/**
 ***************** 图片懒加载模块 ********************
 * 一、非幻灯片内图片标签写法：
 * <img class="js-lazyload" src="默认图" data-lazy="目标图" data-spare="备用图">
 *
 * 二、幻灯片内图片标签写法（其实就是少个类名）：
 * <img src="默认图" data-lazy="目标图" data-spare="备用图">
 */

import 'mutationobserver-shim';
import Lazyload from 'vanilla-lazyload/dist/lazyload.min.js';
import staticAsset from 'js/core/staticAsset';
import { throttle } from 'js/utils';
import PubSub from 'pubsub-js';

// 图片容器加载中的标识
const lazyClass = ['icon-loading', 'box-loading'];

// Lazyload对象
let lazyload = null;

/**
 * 初始化图片懒加载
 */
function initLazyload(config = {}) {
    window.lazyLoadOptions = Object.assign({
        elements_selector: '.js-lazyload',
        data_src: 'lazy',
        class_loading: 'lazy-loading',
        class_loaded: 'lazy-loaded',
        class_error: 'lazy-error',
        callback_load: lazySuccess,
        callback_error: lazyError,
        container: window,
        threshold: window.lib.flexible.rem2px(4), // 750px 宽度默认300px，也就是4rem
    }, config);

    lazyload = new Lazyload(window.lazyLoadOptions);

    const mutationThrottle = throttle(() => {
        PubSub.publish('sysUpdateLazyload');
    }, 300);

    new MutationObserver((mutations) => {
        mutations.forEach((event) => {
            const targetChild = event.target.innerHTML;
            if (targetChild.indexOf('js-lazyload') !== -1) {
                mutationThrottle();
            }
        });
    }).observe(document.body, {
        childList: true,
        subtree: true
    });
}

/**
 * 图片加载成功
 */
function lazySuccess(image) {
    const { parentNode } = image;
    if (parentNode) {
        parentNode.classList.remove(...lazyClass);
    }
}

/**
 * 图片加载失败
 */
function lazyError(image) {
    const { parentNode, dataset, classList } = image;
    const spare = (dataset && dataset.spare) || null;

    if (parentNode) {
        parentNode.classList.remove(...lazyClass);
    }

    if (spare && !classList.contains('spared')) {
        image.src = spare;
        classList.add('spared');
    } else {
        const placement = `<figure class="tearImage"><img src="${staticAsset('/img/site/error_img@.png')}"></img></figure>`;
        $(image).after(placement);
        $(image).remove();
    }
}

/**
 * 更新图片懒加载
 */
function updateLazyload() {
    if (lazyload) {
        lazyload.update();
    }
}

export {
    lazySuccess,
    lazyError,
    initLazyload,
    updateLazyload
};
