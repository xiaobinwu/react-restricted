/**
 * Created by Liu.Jun on 2018/8/12.
 */
function px2rem(px) {
    return window.lib.flexible.px2rem(px);
}

function rem2px(rem) {
    return window.lib.flexible.rem2px(rem);
}
export {
    px2rem,
    rem2px
};
