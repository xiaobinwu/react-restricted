/**
 * 状态缓存器，多用在窗口滚动的时候过滤同一状态下的行为
 * Created by Jiazhan Li on 2018/08/02.
 */

// 状态缓存器
export default class StateBuffer {
    state;
    on(st, func) {
        if (this.state !== st) {
            this.state = st;
            func();
        }
    }
    init() {
        this.state = undefined;
    }
}
