/**
 * Created by GUOXIU on 2018/3/31.
 */

// 针对密码 RSA 加密
import { encryptedString, setMaxDigits, RSAKeyPair } from 'js/lib/rsa.js';

function rsaEncrypted(value) {
    setMaxDigits(130);
    // eslint-disable-next-line
    const key = new RSAKeyPair("10001","","bf58d0ac01d2e4ad38a1d681b3ea11a008caaea935a57e35a9027a8c89d2367032815aab3cf7b927f59d5ec89551e63dd5090c4aea030d8b7edbb36588872b6f30e64d93077bc7bb64d376e85f9977bd7d951227533851a2f0a5eba3ff342a7d4cadc213ac50cdb81025d0ed4282151acdf9e6e708e8a18b9b3b0322bf1d8ecd"); 
    return encryptedString(key, encodeURIComponent(value));
}

export default rsaEncrypted;
