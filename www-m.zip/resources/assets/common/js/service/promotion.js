/** 公共ajax请求 */
import appSdk from 'js/core/app.sdk.js';
import Service from '../http/service';

const {
    DOMAIN_MAIN,
    DOMAIN_USER,
} = window.GLOBAL;


/**
 * deals
 */
export const serviceDealsPage = new Service({
    url: `${DOMAIN_MAIN}/activity/deals/ajax-deals-lists`,
});

/**
 * flash_sale
 */
export const serviceFlashSalePage = new Service({
    url: `${DOMAIN_MAIN}/flash-sale/category.html`,
});

// 整点秒杀场次数据
export const serviceFlashSaleScence = new Service({
    url: `${DOMAIN_MAIN}/get-scene-goods`,
    loading: true,
    cache: true
});

/*
* Presale
*/
export const servicePresalePage = new Service({
    url: `${DOMAIN_MAIN}/presale.html`,
});

// 凑单购物车加车判断
export const serviceAddonJudge = new Service({
    url: `${DOMAIN_MAIN}/activity/compose-good/cart-activity-info`,
});

// 凑单页数据
export const serviceAddonCompose = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/compose-good/load-page`,
    cache: true,
});

/*
*  messenger
* */

// 转盘抽奖
export const serviceMessengerChance = new Service({
    url: `${DOMAIN_MAIN}/activity/messenger/raffle`,
});

// 分享获取抽奖机会
export const serviceMessengerShare = new Service({
    url: `${DOMAIN_MAIN}/activity/messenger/share-count`
});

// 分享送积分
export const serviceShareGetScore = new Service({
    method: 'POST',
    url: '/activity/special/share-point',
});

// 针对红包裂变活动接口
export const serviceFissionPacketforwardInfo = new Service({
    method: 'GET',
    url: `${DOMAIN_MAIN}/activity/red-packet/forward`,
    errorPop: false,
    loading: false,
});

// 用户已拆金额和红包生效时间戳
export const serviceFissionPacketInfo = new Service({
    method: 'GET',
    url: `${DOMAIN_MAIN}/activity/red-packet/get-record-info?t=${+new Date()}`,
    errorPop: false,
    loading: false,
});

// 裂变红包-助力名单列表
export const serviceFissionPacketAssist = new Service({
    method: 'GET',
    url: `${DOMAIN_MAIN}/activity/red-packet/get-assist?t=${+new Date()}`,
    errorPop: false,
    loading: false,
});

// 裂变红包-用户提现
export const serviceFissionPacketWithdraw = new Service({
    method: 'POST',
    url: `${DOMAIN_MAIN}/activity/red-packet/withdraw?t=${+new Date()}`,
    errorPop: false,
    loading: false,
});

// 裂变红包-中间位banner
export const serviceFissionMianBanner = new Service({
    method: 'GET',
    url: '/activity/red-packet/main-info',
    loading: false,
});

// 推荐位数据接口
export const fissionRecommend = new Service({
    method: 'GET',
    url: '/activity/red-packet/recommended-goods',
    loading: false,
    errorPop: false,
});

// 广告落地页请求更多数据
export const serviceLandingPage = new Service({
    url: `${DOMAIN_MAIN}/ads-landing-page/picked-goods`,
});

// Zone Deals 0.99-频道数据接口
export const serviceZoneDealsList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/zone-deals-list`,
    errorPop: false,
    loading: true,
    cache: true,
});

// Clearance 清仓数据接口
export const serviceClearanceList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/clearance-list`,
    cache: true,
    errorPop: false,
    loading: true,
});

// 新品页数据接口
export const serviceNewProductsList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/new-products-list/`,
    errorPop: false,
    loading: true,
});

// Hot sale 热卖页数据接口
export const serviceHotSaleList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/hot-sale-list/`,
    errorPop: false,
    loading: true,
    cache: true,
});

// Explore 页数据接口
export const serviceExploreDealsList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/explore-list`,
    errorPop: false,
    loading: true,
    cache: true,
});

/**
 * 专题活动接口
 */
class MyService extends Service {
    constructor(params) {
        super(Object.assign({
            method: 'jsonp',
            loading: false,
            errorPop: false,
            cache: false,
        }, params));
    }
}

const appParam = appSdk.IS_APP ? `?type=app&platform=${appSdk.APP_OS === 'ios' ? 'ios' : 'andriod'}` : '';

// 请求剩余积分
export const serviceGetPoints = new MyService({
    url: `${DOMAIN_USER}/query-user-points-info${appParam}`,
});

// 分享完成后赠送抽奖次数
export const serviceShareCallback = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/share${appParam}`,
    method: 'POST',
});

// 检查是否可以抽奖
export const serviceCheckLottery = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/check${appParam}`,
    method: 'post',
});

// 抽奖接口
export const serviceRunLottery = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/raffle${appParam}`,
    method: 'post'
});

// 请求剩余抽奖次数
export const serviceGetSpins = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/get-counter-remain${appParam}`,
});

// 请求中奖列表
export const serviceGetWinner = new MyService({
    url: `${DOMAIN_MAIN}/activity/get-lottery-prize-list`,
    cache: true,
});

// 预约提醒接口
export const serviceReservation = new Service({
    method: 'POST',
    url: '/activity/special/reservation',
    errorPop: false,
});

export const serviceRedRainRaffle = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/red-rain-raffle`,
    method: 'post'
});

export const serviceRedRainHasPlay = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/red-rain-check`,
    method: 'post'
});

// 5周年店庆（获取当前用户（未领取）奖品列表）
export const serviceUserNoGetPrizeList = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/get-user-prize`,
    method: 'jsonp'
});

// 5周年店庆 (根据活动id和prizeRank获取)
export const serviceGetPrize = new MyService({
    url: `${DOMAIN_MAIN}/activity/lottery/receive-prize`,
    method: 'post'
});

// 新手导购头部领取新手券  是否获取过
export const serviceCouponIsGot = new MyService({
    url: `${DOMAIN_MAIN}/activity/new-shopping-guide/is-got-coupon`,
    method: 'jsonp'
});

