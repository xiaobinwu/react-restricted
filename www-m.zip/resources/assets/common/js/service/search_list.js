/* 搜索|分类列表页数据请求接口 */

import Service from '../http/service';

const { DOMAIN_MAIN } = GLOBAL;
const locationPathname = window.location.pathname;

// 搜索分类页
export const serviceSearchListData = new Service({
    cache: true,
    url: `${DOMAIN_MAIN}${locationPathname}`,
});

// 凑单页商品列表
export const serviceCouponGoodsList = new Service({
    cache: true,
    url: `${DOMAIN_MAIN}/search-coupon`,
});

// 获取国家列表
export const serviceGetCountryList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/get-country-list`,
    loading: false,
});
