import Service from '../http/service';

const {
    DOMAIN_MAIN,
    DOMAIN_ORDER,
    DOMAIN_USER,
} = GLOBAL;

// 获取用户基本信息
export const serviceUserInfo = new Service({
    url: `${DOMAIN_USER}/info`,
    loading: false,
});

// 编辑用户基本信息
export const serviceEditUserInfo = new Service({
    method: 'post',
    url: '/user/edit-profile',
});

// 修改用户密码
export const serviceChangePwd = new Service({
    method: 'post',
    url: '/user/change-password',
});

// 获取地址本列表
export const serviceGetAddressList = new Service({
    url: `${DOMAIN_USER}/address-book`,
});

// 设置默认地址
export const serviceSetDefaultAddress = new Service({
    method: 'post',
    url: '/user/set-default-addr',
});

// 删除地址
export const serviceDeleteAddress = new Service({
    method: 'post',
    url: '/user/delete-address',
});

// 编辑商品评论
export const serviceWriteReview = new Service({
    method: 'post',
    url: '/user/goods/write-review',
});

// 商品评论列表
export class ServiceReviewList extends Service {
    constructor() {
        super({
            url: `${DOMAIN_MAIN}/user/goods/review/list`,
        });
    }
}

// 上传评论图片
export const serviceReviewUpload = new Service({
    url: `${window.GLOBAL.DOMAIN_UPLOAD}/review/upload`,
    method: 'post',
    errorPop: false,
    headers: {
        'Content-type': 'application/x-www-form-urlencoded'
    },
});

// 我的积分
export const serviceUserPoint = new Service({
    url: `${DOMAIN_USER}/query-points-detail`,
});

// 我的coupon
export const serviceCouponList = new Service({
    url: `${DOMAIN_USER}/coupon/index`,
});

// 我的收藏（商品）
export const serviceCollection = new Service({
    url: `${DOMAIN_USER}/collection`,
});

// 批量删除收藏商品
export const serviceDeleteCollection = new Service({
    method: 'post',
    url: '/user/collection/delete',
});

// 我的收藏（店铺）
export const serviceStoreList = new Service({
    url: `${DOMAIN_USER}/store`,
});

// 批量收藏/取消店铺
export const serviceStoreCollect = new Service({
    method: 'post',
    url: '/user/store-collect',
});

// 添加地址
export const serviceAddAddress = new Service({
    method: 'post',
    url: '/user/add-address',
});

// 修改地址
export const serviceEditAddress = new Service({
    method: 'post',
    url: '/user/edit-address',
});

// 0-----------------------
// 获取国家列表
export const serviceGetCountry = new Service({
    url: `${DOMAIN_MAIN}/user/get-country`,
    loading: false,
    cache: true,
});

// 获取省列表
export const serviceGetProvince = new Service({
    url: `${DOMAIN_MAIN}/user/get-province`,
    loading: false
});

// 获取城市列表
export const serviceGetCity = new Service({
    url: `${DOMAIN_MAIN}/user/get-city`,
    loading: false,
    cache: true,
});

// 获取用户paypal地址信息
export const serviceGetPaypalInfo = new Service({
    url: `${DOMAIN_ORDER}/payment/user-paypal-info`,
});

// 获取 "contact us" 跳转链接
export const serviceGotoContactUs = new Service({
    url: '/user/get-messenger-link'
});

// 订单--列表
export const serviceOrderList = new Service({
    url: `${DOMAIN_ORDER}/order/list`,
});

// 订单--取消原因列表
export const serviceOrderReason = new Service({
    url: `${DOMAIN_ORDER}/order/reason`,
});

// 订单--取消/退款
export const serviceOrderCancel = new Service({
    method: 'post',
    url: '/order/cancel',
});

// 订单--催单
export const serviceOrderExpedite = new Service({
    method: 'post',
    url: '/order/expedite',
});

// 订单--确认收货
export const serviceOrderConfirm = new Service({
    method: 'post',
    url: '/order/confirm',
});

// 订单--详情
export const serviceOrderDetail = new Service({
    url: `${DOMAIN_ORDER}/order/detail`,
});

// 订单--发票状态
export const serviceOrderInvoice = new Service({
    isCancel: false,
    url: `${DOMAIN_ORDER}/order/invoice-status`,
});

// 订单--包裹物流
export const serviceOrderPackage = new Service({
    url: `${DOMAIN_ORDER}/order/package`,
});

// 订单--获取RMA信息
export const serviceToRma = new Service({
    method: 'post',
    url: '/order/rma'
});

// 自定义地址校验接口
export const serviceGetAddressRule = new Service({
    url: `${DOMAIN_USER}/get-address-rule`,
});

// 通过zipcode 获取巴西国家洲等信息
export const serviceGetBrazilCode = new Service({
    url: `${DOMAIN_USER}/get-brazil-code`,
});

// GC银行--收款账号信息（BankTransfer）
export const serviceGetBankTransferInfo = new Service({
    url: `${DOMAIN_ORDER}/payment/bank-transfer-account`,
});


/* 电子钱包相关接口 */
// 余额
export const serviceWalletBalance = new Service({
    url: `${DOMAIN_USER}/payment/wallet/balance`,
    loading: true,
});

// 流水明细 -- loding按需取用
export const serviceWalletList = new Service({
    url: `${DOMAIN_USER}/payment/wallet/list`,
});

// 发送重置邮件
export const serviceWalletSendEmail = new Service({
    method: 'POST',
    url: '/payment/wallet/send-email',
    loading: true,
});

// 重置密码
export const serviceWalletPasswordSave = new Service({
    method: 'POST',
    url: '/payment/wallet/password-save',
    errorPop: false,
    loading: true,
});

// 验证token
export const serviceWalletVerificationToken = new Service({
    url: `${DOMAIN_USER}/payment/wallet/reset-password`,
    errorPop: false,
    loading: true,
});

// 更改密码
export const serviceWalletChangePassword = new Service({
    method: 'POST',
    url: '/payment/wallet/change-password',
    errorPop: false,
    loading: true,
});

// multibanco支付第三方付款凭证信息
export const serviceGetMultibanco = new Service({
    url: `${DOMAIN_ORDER}/payment/multibanco-info`,
});

/* 站内信相关接口 */
// 获取消息列表
export const serviceMessageList = new Service({
    url: '/user/message/list',
});

// 获取用户未读消息总数
export const serviceMessageCount = new Service({
    url: '/user/message/unread-count',
    errorPop: false,
    loading: false,
});

// 获取各个消息源的未读消息总数
export const serviceMessageSourceCount = new Service({
    url: '/user/message/source-unread-count',
});

// 批量设置已读
export const serviceMessageBatchRead = new Service({
    method: 'POST',
    url: '/user/message/batch-mark-read',
});

// 消息详情页面
export const serviceMessageInfo = new Service({
    url: '/user/message/info',
});

// 删除消息
export const serviceMessageDelete = new Service({
    method: 'POST',
    url: 'user/message/delete-message',
});

// 留言列表
export const serviceMessageLeaveList = new Service({
    url: 'user/messages',
});

// 留言详情
export const serviceMessageLeaveDetail = new Service({
    url: 'user/messages/detail',
});

// 留言删除
export const serviceMessageLeaveDelete = new Service({
    method: 'POST',
    url: 'user/messages/delete',
});

// 回复留言
export const serviceReplyMessageLeave = new Service({
    method: 'POST',
    url: 'user/messages/reply',
});

// 留言
export const serviceMessageLeave = new Service({
    method: 'POST',
    url: 'user/messages/add',
});

// 仲裁留言列表
export const serviceArbitrationList = new Service({
    url: 'user/arbitration/messages',
});

// 仲裁留言详情
export const serviceArbitrationDetail = new Service({
    url: 'user/arbitration/messages/detail',
});

// 仲裁留言删除
export const serviceArbitrationDelete = new Service({
    method: 'POST',
    url: 'user/arbitration/messages/delete',
});

// 仲裁留言回复
export const serviceArbitrationReply = new Service({
    method: 'POST',
    url: 'user/arbitration/messages/reply',
});

// 生成发票
export const serviceCreateInvoice = new Service({
    method: 'POST',
    url: '/order/create-invoice',
});
// 会员中心
export const servicememeberCenter = new Service({
    url: '/member-center',
});

// 会员中心规则
export const servicememeberRule = new Service({
    url: '/member-rule',
});

// 会员中心成长值
export const serviceMemeberGrowupScene = new Service({
    url: '/member-growup-scene',
});

// 抽奖接口
export const serviceRunLottery = new Service({
    url: `${DOMAIN_USER}/activity/lottery/raffle`,
    method: 'post'
});

// 请求剩余抽奖次数
export const serviceGetSpins = new Service({
    url: `${DOMAIN_USER}/activity/lottery/get-counter-remain`,
});

// 领取礼包
export const serviceGetGiftPackage = new Service({
    url: '/member-receive-gift',
});

// 领取礼包
export const serviceUpdateGiftPackage = new Service({
    url: '/member-gift',
});

// 获取预约总数
export const serviceGetReservationTotal = new Service({
    url: `${DOMAIN_USER}/user/reservation/total`,
});

// 获取预约列表
export const serviceGetReservationList = new Service({
    url: `${DOMAIN_USER}/user/reservation/list`,
});

// 预约列表删除数据
export const serviceRemoveReservation = new Service({
    method: 'POST',
    url: `${DOMAIN_USER}/user/reservation/delete`,
});

// 判断地址手机号码的有效性
export const serviceIsAvailablePhone = new Service({
    url: `${DOMAIN_USER}/user/address/is-available-phone`,
});
