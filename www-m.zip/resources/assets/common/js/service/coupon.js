/** 领券中心 ajax请求 */
import Service from '../http/service';

const { DOMAIN_USER } = GLOBAL;

/*
 * 领券接口
 */
export const serviceCouponReceive = new Service({
    method: 'post',
    url: '/user/coupon/receive',
});

/*
 * 更新领券已领取列表
 */
export const serviceCouponUpdateInfo = new Service({
    url: `${DOMAIN_USER}/coupon/info`,
});
