/**
 * Created by Liu.Jun on 2018/2/8.
 */

import Service from '../http/service';

const { DOMAIN_MAIN } = GLOBAL;

// 搜索推荐
export const serviceGetKeyword = new Service({
    loading: false,
    cache: true,
    url: `${DOMAIN_MAIN}/get-keyword/`,
});
