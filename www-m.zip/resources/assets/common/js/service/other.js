/**
 * Created by Liu.Jun on 2018/4/24.
 */

// 对外系统的 ，比如大数据
import Cookies from 'js/utils/cookie';
import { getCdnCountryCode } from 'js/core/currency.js';
import Service from '../http/service';

/**
 * 大数据推荐位相关
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=35196617
 */
const FUN = 'gb-recommend-service';
const pipelinecode = window.GLOBAL.PIPELINE;
const lang = window.GLOBAL.LANG;
const defaultSku = '99999999999';
const cookies = Cookies.get();
const sid = cookies.bgsid ? cookies.bgsid : cookies.AKAM_CLIENTID;

function getGoodsUrl(url) {
    const { DOMAIN_GOODS_IMAGE } = window.GLOBAL;
    if (url.indexOf('http') === 0) {
        return url;
    }
    return `${DOMAIN_GOODS_IMAGE}/${url}`;
}

function transformData(res) {
    const { DOMAIN_MAIN, DOMAIN_USER } = window.GLOBAL;
    if (res instanceof Array) {
        res.forEach((item) => {
            item.avgRate = item.avgrate;
            item.catId = item.catid;
            item.displayPrice = item.displayprice;
            item.favoriteCount = item.favoritecount;
            item.goodsImage = getGoodsUrl(item.imgurl);
            item.goodImg = item.goodsImage;
            item.goodsNum = item.goodsnum;
            item.goodSn = item.good_sn;
            item.goodsSn = item.good_sn;
            item.goodsTitle = item.goodstitle;
            item.goodTitle = item.goodstitle;
            item.goodsUrl = `${DOMAIN_MAIN}${item.url_title}?wid=${item.warecode}`;
            item.linkUrl = item.goodsUrl;
            item.gridUrl = getGoodsUrl(item.gridurl);
            item.reviewCount = item.reviewcount;
            item.reviewLink = `${DOMAIN_USER}/index#/review/list`;
            item.shopPrice = item.shopprice;
            item.thumbExtendUrl = getGoodsUrl(item.thumbextendurl);
            item.thumbUrl = getGoodsUrl(item.thumburl);
            item.warehouseCode = item.warecode;
            item.wareCode = item.warecode;
            item.webGoodSn = item.webgoodsn;
        });
    }
    return res;
}

function qs(obj) {
    const reData = JSON.parse(JSON.stringify(obj));
    if (reData.params) {
        reData.params = JSON.stringify(reData.params);
    }
    return Object.entries(reData).map(([key, value]) => `${key}=${value}`).join('&');
}

async function mergeData(data) {
    const cdnCountry = await getCdnCountryCode();
    const options = {
        params: {
            lang,
            platform: 'M',
            cookie: sid,
            pipelinecode,
            regioncode: cdnCountry
        },
        recommendType: '1010101',
        fun: FUN,
    };
    if (data && data.params) {
        data.params = Object.assign(options.params, data.params);
    }

    return Object.assign(options, data);
}

function reDataFn(data) {
    return recommendHttp.http({
        data: qs(data),
    }).then((res) => {
        if (res.status === 1) {
            res.status = 0;
            res.data = transformData(res.result);
            delete res.result;
        } else {
            res.status = -1;
        }
        return res;
    });
}

export const recommendHttp = new Service({
    method: 'POST',
    errorPop: false,
    isCancel: false,
    loading: false,
    Headers: {
        'Content-type': 'application/x-www-form-urlencoded'
    },
    url: window.GLOBAL.BIGDATA_URL,
    // url: 'http://34.231.141.219/',
    transformRequest(bodyData, headers) {
        // https://github.com/axios/axios/issues/382
        const tempHeaders = headers;
        delete tempHeaders.common['X-CSRF-TOKEN'];
        delete tempHeaders.common['X-Requested-With'];
        return bodyData;
    }
});

// 商品页推荐位
export async function getGoodsRecommend(args) {
    const data = await mergeData({
        params: {
            sku: args && args.params ? args.params.goodSn : defaultSku,
            categoryid: args && args.params && args.params.categoryid
        }
    });

    const type = args && args.params ? +args.params.type : 1;
    const typeCfg = {
        1: 1020101,
        2: 1020201,
        3: 1020301,
        4: 1020102,
    };
    data.recommendType = typeCfg[type];

    return reDataFn(data);
}

// you also like 推荐位 cart
export async function getULike(args) {
    const data = await mergeData({
        params: {
            ...args.params
        },
        recommendType: args.recommendType
    });
    return reDataFn(data);
}

// 首页获取推荐商品
export async function getIndexRecommend(config) {
    const curDefaultParams = {
        pageindex: 0,
        pagesize: 30,
        ortherparams: {}
    };

    const options = await mergeData({
        params: {
            ...curDefaultParams,
            ...config
        },
        recommendType: 1010102
    });

    return reDataFn(options);
}
