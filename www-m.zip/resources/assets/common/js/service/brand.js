
import Service from '../http/service';

const { DOMAIN_MAIN } = GLOBAL;

// 认证 - 登录
export const serviceBrandCate = new Service({
    url: `${DOMAIN_MAIN}/top-brands/brand/ajax-hot-sale`,
});
