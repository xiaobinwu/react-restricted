/** 公共ajax请求 */
import Service from '../http/service';

const { DOMAIN_MAIN } = window.GLOBAL;


/**
 * 获取所有商品列表
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=35195794
 */
export const serviceStoreCateGoods = new Service({
    url: `${DOMAIN_MAIN}/store/list`,
    cache: true,
});

/**
 * 获取其他分类商品
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=35195794
 */
export const serviceStoreWindowGoods = new Service({
    url: `${DOMAIN_MAIN}/store/windows-goods`,
    cache: true,
});

/**
 * 批量收藏/取消店铺操作
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=34701436
 */
export const serviceStoreCollect = new Service({
    method: 'post',
    url: '/user/store-collect',
});

/**
 * 查询是否收藏该店铺
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=37719442
 */
export const serviceStoreCollectStatus = new Service({
    url: `${DOMAIN_MAIN}/store/has-collect`,
});
