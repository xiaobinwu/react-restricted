/**
 * Created by Liu.Jun on 2018/2/11.
 */

import Service from '../http/service';

const {
    DOMAIN_LOGIN,
} = GLOBAL;

// 认证 - 登录
export const serviceLogin = new Service({
    method: 'post',
    url: '/user/login',
});

// 认证 - 注册
export const serviceRegister = new Service({
    method: 'post',
    url: '/user/register',
});

// 认证 - 注册时检查邮箱是否已存在
export const serviceCheckEmailExist = new Service({
    url: `${DOMAIN_LOGIN}/check-email-exist`,
});

// 认证 - 发送邮箱激活邮件
export const sendActivationEmail = new Service({
    method: 'post',
    url: '/user/register/send-activation-email',
});

// 认证 - 发送忘记密码邮件
export const serviceConfirmIdentity = new Service({
    method: 'post',
    url: '/user/confirm-identity',
});

// 重置密码
export const serviceResetPassword = new Service({
    method: 'post',
    url: '/user/reset-password',
});

// 认证 - 第三方登录
export const serviceUserSocial = new Service({
    method: 'POST',
    errorPop: false,
    url: '/user/social',
});

// 第三账号手动绑定
export const servicebindSocial = new Service({
    method: 'post',
    url: '/user/bind-social',
    errorPop: false,
    loading: true,
});

/**
 * 第三方登录， 获取联登地址(修改)
 *
 */
export const serviceSocialLoginUrl = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/login-url',
});

/**
 * 执行第三方登录(修改)
 *
 */
export const serviceSocialLogin = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/login',
});

/**
 * 绑定第三方(修改)
 *
 */
export const serviceSocialBind = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/bind',
});

/**
 * 检查第三方是否已经绑定(修改)
 *
 */
export const serviceSocialCheck = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/check',
});


/**
 * 检查第三方是否已经绑定(修改)
 *
 */
export const serviceSocialTypeList = new Service({
    method: 'get',
    loading: false,
    errorPop: false,
    url: '/social/type-list',
});

/**
 * 获取是否欧盟
 *
 */
export const servicePassportInit = new Service({
    method: 'get',
    loading: false,
    errorPop: false,
    url: '/user/passport/init',
});

/**
 * 设置 fcm token
 */
export const serviceSetToken = new Service({
    method: 'POST',
    loading: false,
    errorPop: false,
    url: '/user/push-fcm',
});
