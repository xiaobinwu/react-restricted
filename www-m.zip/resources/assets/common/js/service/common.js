/** 公共ajax请求 */
import Service from '../http/service';

const { DOMAIN_MAIN, DOMAIN_USER } = GLOBAL;

const { ASYNC_PRICE } = GLOBAL;
const curCDN = '//cur.gearbest.com';

// 收藏商品
export const serviceCollectAdd = new Service({
    method: 'post',
    url: '/user/collection/add',
    errorPop: false,
});

// 批量删除收藏商品
export const serviceDeleteCollection = new Service({
    method: 'post',
    url: '/user/collection/delete',
    errorPop: false,
});

export const serviceGetCouponItem = new Service({
    method: 'POST',
    url: '/user/coupon/receive',
    errorPop: false,
});

// 领取优惠券
export const serviceCouponReceive = new Service({
    method: 'post',
    url: '/user/coupon/receive',
});

// 尾部的邮件订阅
export const serviceSubscribe = new Service({
    method: 'post',
    url: '/subscribe',
});

// 用户信息获取
export const serviceUserStatus = new Service({
    url: `${DOMAIN_MAIN}/check/info`,
    errorPop: false,
    loading: false,
});

/**
 * 商品-异步获取收藏数，是否收藏
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=38503331
 */
export const serviceCollectStatus = new Service({
    url: `${DOMAIN_MAIN}/goods/user-fav`,
    errorPop: false,
    isCancel: false,
    loading: false,
});

/**
 * 全站商品列表-删除收藏
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=36344773
 */
export const serviceGoodlistCollectRemove = new Service({
    method: 'post',
    url: '/user/collection/delete-fav-goods',
    errorPop: false,
});

//  购物车数量(简)
export const serviceCartNum = new Service({
    url: '/cart/num',
});

//  加入购物车
export const serviceAddToCart = new Service({
    method: 'POST',
    url: '/cart/add',
});

//  一键购(buy now)
export const serviceCartEasyBuy = new Service({
    method: 'POST',
    url: '/cart/buy',
});

export const serviceAsyncPrice = new Service({
    method: 'POST',
    url: ASYNC_PRICE,
    errorPop: false,
    loading: false,
    withCredentials: false,
    headers: {},
    isCancel: false, // 独立页面调用与公用同时调用会中断其中一方，导航callback无法执行
});

//  优惠券领取状态
export const serviceCouponReceivedStatus = new Service({
    url: `${DOMAIN_USER}/coupon/info`,
});

// 错误上报
export const serviceReportError = new Service({
    method: 'POST',
    url: '/error/report',
    loading: false,
    errorPop: false,
});

// 获取默认国家和币种
export const serviceCurrencyInfo = new Service({
    method: 'jsonp',
    loading: false,
    cache: true,
    url: `${DOMAIN_MAIN}/currency/info`,
});

// 获取当前cdn国家代码
export const serviceCurrentCountry = new Service({
    method: 'jsonp',
    loading: false,
    cache: true,
    errorPop: false,
    url: `${curCDN}/current_country`,
});

// 获取国家列表
export const serviceGetCountry = new Service({
    url: `${DOMAIN_MAIN}/user/get-country`,
    loading: false,
    cache: true,
});

// 获取省列表
export const serviceGetProvince = new Service({
    url: `${DOMAIN_MAIN}/user/get-province`,
    loading: false,
    cache: true,
});

// 根据IP请求广告位
export const serviceIPBanner = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    cache: true,
    url: `${DOMAIN_MAIN}/async/region/banner`,
});

// 获取PW配置信息
export const serviceGetPwaInfo = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    cache: true,
    url: `${DOMAIN_MAIN}/pw`,
});

/**
 * BTS 分桶实验
 */
export const serviceAbTest = new Service({
    method: 'post',
    loading: false,
    errorPop: false,
    url: 'https://api-bts.logsss.com/gateway/shunt',
});

// 首页定金膨胀弹框
export const serviceDepositRemind = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    url: `${DOMAIN_MAIN}/get-deposit-remind`,
});

// 意见反馈
export const serviceFeedBack = new Service({
    method: 'post',
    url: '/feedback',
});

// bts abTest 分流
export const reviewBtsABtest = new Service({
    method: 'post',
    loading: false,
    errorPop: false,
    // url: 'http://35.175.15.99:9086/gateway/shunt', // 测试环境
    url: 'https://api-bts.logsss.com/gateway/shunt', // 正式环境
});
