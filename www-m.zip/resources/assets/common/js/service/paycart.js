import Service from '../http/service';

const {
    DOMAIN_MAIN,
    DOMAIN_CART,
    DOMAIN_ORDER,
} = GLOBAL;

/* 购物车相关页面接口 */
// 变更商品选中状态
export const serviceCartSelect = new Service({
    method: 'post',
    url: '/cart/select',
    errorPop: false,
    loading: false,
});
// 变更商品参与活动
export const serviceCartChange = new Service({
    method: 'post',
    url: '/cart/change',
    errorPop: false,
    loading: false,
});
// 删除商品
export const serviceCartDelete = new Service({
    method: 'post',
    url: '/cart/delete',
});
// 更改商品数量
export const serviceCartUpdate = new Service({
    method: 'post',
    url: '/cart/update',
    errorPop: false,
    loading: false,
});

// 获取活动赠品/加价购商品
export const serviceCartGift = new Service({
    method: 'jsonp',
    url: '/cart/gift',
    errorPop: false,
});
// 添加商品
export const serviceCartAdd = new Service({
    method: 'post',
    url: '/cart/add',
});
// 获取同款商品属性
export const serviceCartSameGoods = new Service({
    method: 'jsonp',
    url: '/cart/same',
    errorPop: false,
});
// 替换商品属性
export const serviceCartReplace = new Service({
    method: 'post',
    url: '/cart/replace',
    errorPop: false,
});
// 保存商品活动信息
export const serviceCartSaveActs = new Service({
    method: 'post',
    url: '/cart/save',
    errorPop: false,
});

// 地址便捷页请求快捷支付地址信息
export const serviceGetQuickPayAddress = new Service({
    method: 'post',
    url: '/payment/user-paypal-info',
});

// 查询分类名称路径
export const serviceGetCategoryInfo = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/category`,
    errorPop: false,
    loading: false,
});

// 不通邮检测
export const serviceShipCheck = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/ship-check`,
    errorPop: false,
    loading: false,
});

// 加载店铺优惠券
export const serviceCartCoupon = new Service({
    method: 'POST',
    url: `${DOMAIN_CART}/cart/coupon`,
    errorPop: false,
    loading: false,
});

/* 支付結果頁相关接口 */
// 后置礼包兑换抽奖次数
export const servicePaymetResultsGiftNum = new Service({
    method: 'POST',
    url: '/activity/gift/exchange-num',
    errorPop: false,
    loading: false,
});

// 后置礼包兑换抽奖
export const servicePaymetResultsGift = new Service({
    method: 'POST',
    url: '/activity/gift/raffle',
    loading: false,
});

// 订单确认页创建订单
export const serviceCheckoutCreateOrder = new Service({
    method: 'post',
    url: '/order/create',
    errorPop: false,
});

// 选择物流方式查询税费
export const serviceCheckoutQueryTax = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/tax`,
    loading: true,
});

// 快捷支付确认支付
export const serviceCheckoutQuickPayCreate = new Service({
    method: 'post',
    url: '/payment/express-pay',
    loading: false,
});

// 保存税号护照号地址信息接口
export const serviceCheckoutAddressSave = new Service({
    method: 'post',
    url: '/checkout/address/save',
});

// --------------------------- jsonp ----------
// 请求快捷支付
export const serviceCartSendQuickPay = new Service({
    url: `${DOMAIN_ORDER}/payment/express-checkout`,
    loading: false,
});

// 快捷支付获取支付方式
export const serviceCartGetQuickPayMode = new Service({
    url: `${DOMAIN_ORDER}/payment/express-channel`,
    errorPop: false,
    loading: false,
});

// 购物车列表推荐商品
export const serviceCartRecommend = new Service({
    url: `${DOMAIN_CART}/cart/recommend`,
    errorPop: false,
    loading: false,
});

/* 订单确认页相关接口 */
// 订单确认页页面数据
export const serviceCheckoutPageData = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/list`,
    errorPop: false,
});

// 订单确认页用户可用优惠券列表
export const serviceCheckoutGetCounponList = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/coupon`,
});

// 订单确认页普通支付请求跳转支付平台连接
export const serviceCheckoutGoToPay = new Service({
    url: `${DOMAIN_ORDER}/payment/go-pay`,
});

// 更具物流方式请求是否需要填写税号或护照号 （已弃用）
export const serviceCheckoutGetIsShowTaxPassport = new Service({
    url: '/order/validate-tax-passport',
});

// 快捷支付 获取支付折扣
export const serviceGetPayRelate = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/pay-relate`,
});

// 订单确认页获取默认保费默认方式
export const serviceInsuranceType = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/insurance-type `,
});

// 订单确认页店铺信息
export const serviceGetShopList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/store/shop-list`,
});

// 购物车列表
export const serviceCartList = new Service({
    url: `${DOMAIN_CART}/cart/list`,
    errorPop: false,
    isCancel: false,
    loading: false,
});

// GC银行--收款账号信息
export const serviceGetGCbankInfo = new Service({
    url: `${DOMAIN_ORDER}/payment/bank-transfer-account`,
    loading: true,
    errorPop: true,
});

// cod 发送短信验证码
export const serviceSendCodSMS = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/send-cod-sms`,
});

// cod 验证短信验证码
export const serviceCheckCodSMS = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/check-cod-sms`,
});

/**
 * 支付方式前置相关接口 --- 支付方式列表
 */
export const servicePaymentPreChannels = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/payment/pre-channels`,
});

// 支付方式前置相关接口 --- 电子钱包密码校验
export const serviceCheckWalletPassword = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/payment/check-wallet-password`,
});

// 支付方式前置相关接口 --- 币种校验
export const serviceCheckCurrency = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/payment/check-currency`,
});

// 支付方式前置相关接口 --- 发送埋点数据
export const servicePaymentPreSendTrack = new Service({
    method: 'POST',
    url: 'https://pay-dev.api.hqygou.com/dev82/v1/web/info',
});

/**
 * 支付流程相关页面 --- 快捷购物版支付结果页
 * 替换游客邮箱
 *
 */
export const servicePaymetResultsVisitorReplace = new Service({
    method: 'POST',
    url: '/replace-visitor-email',
    loading: true,
    errorPop: false,
});

/**
 * 换未激活用户邮箱
 */
export const servicePaymetResultsReplaceEmail = new Service({
    method: 'POST',
    url: '/replace-user-email',
    loading: true,
    errorPop: false,
});

// 支付折扣
export const serviceCartPayrelate = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/pay-relate`,
    errorPop: false,
    loading: false,
});
