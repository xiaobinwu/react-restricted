/** 商详页ajax请求 */
import Service from '../http/service';

const { DOMAIN_MAIN } = GLOBAL;

// 邮件订阅
export const serviceArrivalNotice = new Service({
    url: `${DOMAIN_MAIN}/goods/add-user-subscribe`,
});

// 实时价格及其他信息
export const serviceGoodsPrice = new Service({
    loading: false,
    url: `${DOMAIN_MAIN}/goods/get-price`,
});

//  商品库存
export const serviceGoodsStock = new Service({
    url: `${DOMAIN_MAIN}/goods/get-stock`,
});

/**
 * 物流配送信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31786536
 */
export const serviceGoodsShipping = new Service({
    cache: true,
    url: `${DOMAIN_MAIN}/goods/goods-shipping`,
});

/**
 * 物流可配送国家列表
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=55280002
 */
export const serviceGoodsShippingCountry = new Service({
    method: 'jsonp',
    loading: false,
    cache: true,
    url: `${DOMAIN_MAIN}/goods/shipping-country`,
});


//  异步获取商品信息
export const serviceGoodsInfo = new Service({
    cache: true,
    loading: false,
    url: `${DOMAIN_MAIN}/goods/asny-good-info`,
});

//  异步获取商品信息
export const serviceGoodsRecomList = new Service({
    url: `${DOMAIN_MAIN}/goods/recommend`,
});

//  异步获取商品评论
export const serviceGoodsReviewsList = new Service({
    cache: true,
    url: `${DOMAIN_MAIN}/goods/review/list`,
});

//  商品点击率url获取
export const serviceGoodsClickUrl = new Service({
    url: `${DOMAIN_MAIN}/goods/get-click-url`,
});

//  商品分期付款列表信息
export const serviceGoodsInstallmentInfo = new Service({
    method: 'jsonp',
    url: '/goods/instalment-info',
});

/**
 * 商详合并接口： [get-price, get-stock, installment_info]
 * 2018-04-26 16:44:41
 * @param good_sn,warehouse_code,shop_code,is_virtual,categoryId
 */
export const serviceGoodsPriceStockInstallment = new Service({
    method: 'jsonp',
    loading: false,
    url: `${DOMAIN_MAIN}/goods/goods-multi`,
    cache: true,
});

/**
 * coupon和promotion信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=56525457
 * 2018-07-30 15:45:46 新增
 */
export const serviceGoodsPromotion = new Service({
    cache: true,
    url: '/goods/promotion',
});

/**
 * 配件信息
 * 2018-10-24 15:10:47 新增
 */
export const serviceGoodsParts = new Service({
    cache: true,
    url: '/goods/goods-parts',
});

/**
 * 商详获取广告位
 */
export const serviceGoodsAdvertising = new Service({
    url: `${DOMAIN_MAIN}/goods/banner`,
    errorPop: false,
    loading: false,
    cache: true,
});

/**
 * 异步获取精选商品
 */
export const serviceGetConcentrateGoods = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/new-arrival/concentrate-goods`,
    errorPop: true,
    cache: false,
    loading: true,
});

export const serviceGetCodGoods = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/cod-list`,
    cache: true,
    errorPop: false,
    loading: true,
});


export const serviceGetSeoNewSales = new Service({
    method: 'jsonp',
    errorPop: true,
    cache: false,
    loading: true
});

// 国家站翻译功能
export const serviceGoodsSwitchLang = new Service({
    url: `${DOMAIN_MAIN}/goods/goods-switch-info`,
    cache: true,
    loading: true,
});
