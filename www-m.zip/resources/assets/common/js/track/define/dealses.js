import Track from 'js/track/track';

const { orderByCode, pageSize } = window.userTrackData;

const DEALS_CONFIG = {
    // 广告位点击
    '.deals_bannerLink': {
        click: 'self',
        pageModule: 'md',
        itemType: 'bannerItem',
        customData: {
            x: 'B_1',
        },
    },

    // 商品位曝光
    '.deals_listItem': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root',
    },

    // 商品位 异步数据曝光
    '.deals_listItem_async': {
        explore: 'self',
        pageModule: 'mp',
        async: true,
        observer: '.deals_list',
    },

    // 点击商品标题 + 图片
    '.deals_listTitle': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        recordOrigin: 1,
        customData: {
            x: 'sku',
        },
    },
    '.deals_listImgWrap': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        recordOrigin: 1,
        customData: {
            x: 'sku',
        },
    },


    // // 加入购物车
    // '.gbGoodsItem_cart': {
    //     click: 'self',
    //     itemType: 'addToCart',
    //     pageModule: 'mp',
    //     customData: {
    //         x: 'ADT',
    //     },
    // },
};

class DealsTrack extends Track {
    // 页面曝光
    explorePageData() {
        return {
            filter: {
                view: pageSize,
                sort: orderByCode,
                page: 1,
            }
        };
    }

    // 同步/异步 商品位曝光
    customExploreTrackCallback({ target }) {
        const curDataset = target.dataset;
        const [view, sort, page] = (curDataset.filtertrack || '').split('_');

        return {
            filter: {
                view, sort, page
            }
        };
    }

    // 点击事件
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        const data = {};
        if (itemType === 'goodslink') { // 点击商品图片或者标题
            const curGoodsItemDataset = dom.closest('.deals_listItem').dataset;
            const domDataset = curGoodsItemDataset.customtrack.split('_');
            const filterData = curGoodsItemDataset.filtertrack.split('_');

            data.skuinfo = [{
                sku: domDataset[0],
                pc: domDataset[1],
                k: domDataset[2],
                pam: domDataset[3],
            }];
            data.filter = {
                view: filterData[0],
                sort: filterData[1],
                page: filterData[2],
            };
        } else if (itemType === 'bannerItem') { // 广告位曝光
            const domDataset = dom.dataset.bannerid.split('_');
            data.ubcta = {
                mdlc: 'B_1',
                mdID: domDataset[0],
            };
        }
        // 加入购物车
        // if (itemType === 'addToCart') {
        //     const trackI = dom.dataset.index;
        //     const trackP = dom.dataset.trackcode.split('_');
        //     const trackC = $('input[name=track-infor]').data('track-inofo').split('_');
        //     data = {
        //         skuinfo: {
        //             sku: trackP[0],
        //             pam: 1,
        //             pc: trackP[1],
        //             k: trackP[2],
        //         },
        //         ubcta: {
        //             rank: trackI,
        //         },
        //         filter: {
        //             view: trackC[0],
        //             sort: trackC[1],
        //             page: trackC[2],
        //         },
        //     };
        // }

        return { ...data, ...configData.customData };
    }
}

const dealsTrack = new DealsTrack({
    config: DEALS_CONFIG,
    page: true,
});

export default () => {
    dealsTrack.run();
};
