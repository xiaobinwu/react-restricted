import Track from 'js/track/track';

const CATEGORY = {

};

export default class CategoryTrack extends Track {
    constructor({
        type = '', // 子页面名称
        page = false, // 是否曝光页面
        extendData = {} // 公共数据
    }) {
        super({
            config: CATEGORY[type],
            page,
            extendData
        });
    }
}
