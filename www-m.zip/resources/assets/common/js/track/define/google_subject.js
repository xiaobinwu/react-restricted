import Track from 'js/track/track';

const Googlesubject = {
    '.js-pmGoodsItem': {
        explore: 'self',
        click: ['.pmGoodsItem_link', '.js-addCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.js-addCart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT'
        },
    },
    '.track-goodsItem': {
        explore: 'self',
        click: ['.track-goodsLink'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
};

class GoogleSubjectTrack extends Track {
    customClickTrackCallback({ dom, configData }) {
        return { ...configData.customData };
    }
}

const googleSubjectTrack = new GoogleSubjectTrack({
    config: Googlesubject,
    page: true,
});

export default () => {
    googleSubjectTrack.run();
};
