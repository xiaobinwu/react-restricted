import Track from 'js/track/track';
import { getUrlQuery } from 'js/utils'; // 商品业务逻辑
import { STORAGE_BTS_BUYTOGETHER, STORAGE_COMBINATION_ORIGIN, STORAGE_BTS_SEARCHBUYTOGETHER } from 'js/variables';

// 商详组合购买加车时添加评论bts
const trackBts = [];
let trackReviewsBts;
let trackSearchBts;
try {
    // 获取商详评论BTS
    trackReviewsBts = JSON.parse(window.sessionStorage.getItem(STORAGE_BTS_BUYTOGETHER)) || {};
    // 获取搜索结果页BTS
    trackSearchBts = JSON.parse(window.sessionStorage.getItem(STORAGE_BTS_SEARCHBUYTOGETHER)) || {};
} catch (error) {
    trackReviewsBts = {};
    trackSearchBts = {};
}

if (trackReviewsBts && !$.isEmptyObject(trackReviewsBts)) {
    trackBts.push(trackReviewsBts);
}

if (trackSearchBts && !$.isEmptyObject(trackSearchBts)) {
    trackBts.push(trackSearchBts);
}

const ACCESSORIES_CONFIG = {
    // 组合买(配件)
    '.js-trackBtnBindBuy': {
        itemType: 'buyTogether',
        click: 'self',
        reportOrigin: 1,
    },
};

class AccessoriesTrack extends Track {

    // 点击处理（组装所需数据）
    customClickTrackCallback(config) {
        const { itemType } = config.configData || {};
        let data = {};
        const typeCfg = {

            // 组合买(配件)
            buyTogether: () => {
                // 商详页勾选的配件（含主件）
                const selectedGoods = window.GOODS_TOGETHERDATA || [];
                const result = [];
                const combinationSource = JSON.parse(window.sessionStorage.getItem(STORAGE_COMBINATION_ORIGIN)) || {};
                if (selectedGoods.length) {
                    selectedGoods.forEach((item) => {
                        result.push({
                            sku: item.goodsSn,
                            pam: 1,
                            pc: item.categoryId,
                            k: item.warehouseCode,
                            zt: 0,
                        });
                    });
                }
                data = {
                    skuinfo: result,
                    pm: 'mbt',
                    x: 'BTS',
                    ubcta: Object.assign(combinationSource, { k: getUrlQuery().virWhCode })
                };
                if (trackBts.length) {
                    if (trackBts.length === 1) {
                        data.bts = trackBts[0];
                    } else {
                        data.bts = trackBts;
                    }
                }
            },
        };
        if (typeof typeCfg[itemType] === 'function') {
            typeCfg[itemType]();
        }
        return { ...data };
    }
}

const accessoriesTrack = new AccessoriesTrack({ config: ACCESSORIES_CONFIG });

export default () => {
    accessoriesTrack.run();
};
