import Track from 'js/track/track';

const CLEARANCE_CONFIG = {

    // 商品位曝光与点击曝光
    '.js-gbGoodsItem': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root',
        itemType: 'goodsList',
        click: ['.gbGoodsItem_thumb', '.gbGoodsItem_title']
    },

    // 加入购物车
    '.js-trackAddCart': {
        click: 'self',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        }
    },
    '.js-trackCoupon': {
        click: 'self',
        itemType: 'coupon',
        customData: {
            x: 'COUPON_SELECT',
        }
    }
};

class ClearanceTrack extends Track {
    explorePageData() {
        return ClearanceTrack.btsData();
    }
    customExploreTrackCallback({ target }) {
        return ClearanceTrack.btsData();
    }
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};
        if (itemType === 'coupon') {
            // 筛选coupon下的sku商品的点击曝光
            const activeDom = $('.js-cleranceCoupon.active');
            const name = encodeURIComponent(activeDom.data('name'));
            const modelnum = activeDom.data('code');
            data = {
                ubcta: {
                    name,
                    modelnum
                }
            };
        } else if (itemType === 'goodsList') {
            data = ClearanceTrack.btsData();
        }
        return { ...data, ...configData.customData };
    }
    static btsData() {
        const trackS = $('input[name=track-bts-infor]').data('track-bts');
        return {
            bts: {
                versionid: 0,
                bucketid: '',
                planid: '',
                plancode: 'clearanceabtest',
                policy: trackS
            }
        };
    }
}

const clearanceTrack = new ClearanceTrack({
    config: CLEARANCE_CONFIG,
    page: true,
});

export default () => {
    clearanceTrack.run();
};
