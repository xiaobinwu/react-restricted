/**
 * Created by Liu.Jun on 2018/5/25.
 */

import Track from 'js/track/track';

const SEARCH = {
    '.popularItem_name': {
        // 热门推荐
        itemType: 'hotSearch',
        click: 'self',
        crossPage: 'search',
        recordOrigin: 2,
        customData: {
            sk: 'T',
            x: 'search',
        },
    },
    '.historyItem_link': {
        // 历史记录
        itemType: 'historySearch',
        click: 'self',
        crossPage: 'search',
        recordOrigin: 2,
        customData: {
            sk: 'H',
            x: 'search',
        }
    },
    '.searchTips_item': {
        // 联想词
        itemType: 'suggestSearch',
        click: 'self',
        crossPage: 'search',
        recordOrigin: 2,
        customData: {
            sk: 'L',
            x: 'search',
        },
    },
    '.searchBtn': {
        // 搜索按钮
        itemType: 'submitSearch',
        click: 'self',
        crossPage: 'search',
        recordOrigin: 2,
        customData: {
            x: 'search',
        },
    }
};

class HeaderTrack extends Track {
    customClickTrackCallback({
        dom,
        classKey,
        configData,
        module,
        targetData
    }) {
        const { itemType } = configData;
        const data = {};
        if (itemType === 'hotSearch') {
            data.sckw = dom.textContent;
            data.sl = $(classKey).index(dom) + 1;
        }
        if (itemType === 'historySearch') {
            data.sckw = dom.querySelector('.js-searchItemName').textContent;
            data.sl = $(classKey).index(dom) + 1;
        }
        if (itemType === 'suggestSearch') {
            data.sckw = dom.textContent;
            data.siws = $('#js-searchInput').val();
            data.sl = $(classKey).index(dom) + 1;
        }
        if (itemType === 'submitSearch') {
            data.siws = $('#js-searchInput').val();
            data.sckw = data.siws; // 直接搜索需要搜索纠正去修复
        }
        return data;
    }
}

const headerTrack = new HeaderTrack({ config: SEARCH });

export default () => {
    headerTrack.run();
};
