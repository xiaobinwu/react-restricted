import Track from 'js/track/track';
import { getUrlQuery } from 'js/utils';
import RecordToGoods from 'js/core/goods/recordToGoods.js'; // 记录进入商详来源
import appSdk from 'js/core/app.sdk';
import { STORAGE_BTS_REVIEWSENTRY, STORAGE_BTS_BUYTOGETHER, STORAGE_COMBINATION_ORIGIN } from 'js/variables';
import GoodsInfo from 'js/core/goods/goodsInfo.js'; // 商品业务逻辑
import { getType } from 'common/js/utils/index';

const linkParameters = getUrlQuery();
const appParam = appSdk.IS_APP ? `${appSdk.APP_OS === 'ios' ? 'ios' : 'android'}` : 'm';

// 商详来源记录,仅当属性切换时，是记录上一级来源，不记录同商品不同属性之间的来源
const { referrer, isChangeAttr } = RecordToGoods.get();
const preLink = (isChangeAttr === true) ? referrer : document.referrer;

RecordToGoods.set('isChangeAttr', false);
RecordToGoods.set('referrer', preLink);

// 如果有实际来源，则让所有曝光和点击记录原始来源
if (preLink) {
    window.TrackData.common.pl = preLink;
}

// 商详评论BTS分流结果
const btsTrackBtsPolicy = $('#js-hdTrackBtsPolicy').val() || '';
const storageKey = STORAGE_BTS_REVIEWSENTRY;

// 默认bts数据
let btsDefault = {};
let storageBts;

try {
    storageBts = JSON.parse(window.sessionStorage.getItem(storageKey)) || {}; // 这是接口返回的bts信息
} catch (error) {
    storageBts = {};
}
// 防止本地bts落空了
btsDefault = Object.assign(btsDefault, storageBts);
// 以副本上的policy为准
btsDefault.policy = btsTrackBtsPolicy;

if (btsDefault.versionid && btsDefault.policy && window.GLOBAL.PIPELINE === 'GB') {
    // 商详组合购买加车时添加评论bts
    window.sessionStorage.setItem(STORAGE_BTS_BUYTOGETHER, JSON.stringify(btsDefault));
} else {
    window.sessionStorage.removeItem(STORAGE_BTS_BUYTOGETHER);
}

const GOODSINFO = GoodsInfo.get();
// 埋点商品状态 0:正常  1:清仓    2:呆滞    3:滞销
const zt = 0;
const num = $('#js-goodsIntroQTY').find('[name=qty]').val();
const GOODS_CONFIG = {
    // 加车
    '.js-addToCart': {
        itemType: 'addToCart',
        click: 'self',
        reportOrigin: 1,
        reportBTS: 1,
        customData: {
            skuinfo: {
                sku: GOODSINFO.goodsSn,
                pam: num,
                pc: GOODSINFO.categoryId,
                k: GOODSINFO.warehouseCode,
                zt,
            },
            pm: 'mb',
            x: 'ADT',
            ksku: GOODSINFO.goodsSn,
            ubcta: {
                k: GOODSINFO.warehouseCode,
            },
        },
    },

    // 加收藏
    '.js-trackBtnGoodsCollect': {
        itemType: 'addToCollect',
        click: 'self',
        reportOrigin: 1, // 上报来源
        reportBTS: 1, // 上报bts
        customData: {
            pm: 'mb',
            skuinfo: {
                sku: GOODSINFO.goodsSn,
                pam: 1,
                pc: GOODSINFO.categoryId,
                k: GOODSINFO.warehouseCode,
                zt,
            },
            ubcta: {
                k: GOODSINFO.warehouseCode,
            },
            x: 'ADF',
        },
    },

    // 组合买(配件)
    '.js-panelFittingEntry': {
        itemType: 'combinationBuy',
        click: 'self',
    },

    // 直接购买
    '.js-buyNow': {
        itemType: 'buyNow',
        click: 'self',
        reportOrigin: 1,
        reportBTS: 1,
        customData: {
            skuinfo: {
                sku: GOODSINFO.goodsSn,
                pam: 1,
                pc: GOODSINFO.categoryId,
                k: GOODSINFO.warehouseCode,
                zt,
            },
            pm: 'mb',
            x: 'BDR',
            ubcta: {
                k: GOODSINFO.warehouseCode,
            },
            ksku: GOODSINFO.goodsSn,
        },
    },

    // 推荐位1
    '.js-trackGoodsRecom_item': {
        module: 'T_1',
        itemType: 'goods',
        click: ['.goodsRecom_itemImg', '.goodsRecom_itemTitle'],
        explore: 'self',
        pageModule: 'mr',
        async: true, // 异步加载的数据的设置
        observer: '.goodsRecom_panel1',
        exploreFirstShow: 100,
        recordOrigin: 1,
        recordBTS: 1,
        reportBTS: 1,
    },

    // 推荐位-spon
    '.js-trackGoodsRecomSpon_item': {
        module: 'T_2',
        itemType: 'goods',
        click: ['.goodsRecom_itemImg', '.goodsRecom_itemTitle'],
        explore: 'self',
        pageModule: 'mr',
        async: true, // 异步加载的数据的设置
        observer: '.goodsRecom_panel2',
        exploreFirstShow: 100,
        recordOrigin: 1,
        recordBTS: 1,
        reportBTS: 1,
    },

    // 分享-facebook
    '.at-svc-facebook': {
        itemType: 'share',
        shareType: 'fb',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 分享-twitter
    '.at-svc-twitter': {
        itemType: 'share',
        shareType: 'twitter',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 分享-google plus
    '.at-svc-google_plusone_share': {
        itemType: 'share',
        shareType: 'google plus',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 分享-pinterest
    '.at-svc-pinterest_share': {
        itemType: 'share',
        shareType: 'pinterest',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 评论-top
    '.js-trackReviewTop': {
        itemType: 'reviewTop',
        click: 'self',
        customData: {
            x: 'Reviews_top_click',
        },
        recordOrigin: 1,
    },

    // 评论-suspension
    '.js-trackReviewSuspension': {
        itemType: 'reviewSuspension',
        click: 'self',
        customData: {
            x: 'Reviews_suspension_click',
        },
        recordOrigin: 1,
    },

    // 评论内容曝光
    '.js-trackGoodsReviews': {
        itemType: 'goodsReviews',
        explore: 'self',
        exploreRoot: 'root',
    },

    // 评论页面曝光
    '.js-trackGoodsReviewsItem': {
        explore: 'self',
        itemType: 'goodsReviews',
        exploreRoot: 'root',
        async: true,
        observer: '.js-trackReviewsPanelList',
    },

    // 评论页面曝光
    '.js-trackGoodsReviewsPhotosItem': {
        explore: 'self',
        itemType: 'goodsReviews',
        exploreRoot: 'root',
        async: true,
        observer: '.js-trackReviewsPanelPhotosList',
    },

    // 评论页面曝光
    '.js-trackGoodsReviewsVideoItem': {
        explore: 'self',
        itemType: 'goodsReviews',
        exploreRoot: 'root',
        async: true,
        observer: '.js-trackReviewsPanelVideoList',
    },

    // 翻译点击上报
    '.js-btnTransGoodsDetail': {
        click: 'self',
        customData: {
            x: 'Languagechange',
        }
    }
};

class GoodsTrack extends Track {
    concatBTS(data, bts) {
        const typeBts = getType(bts);
        const typeDataBts = getType(data.bts);
        if (typeDataBts === 'Undefined') {
            data.bts = [];
        } else if (typeDataBts === 'Object') {
            data.bts = [data.bts];
        } else if (typeDataBts !== 'Array') {
            return false;
        }

        if (typeBts === 'Array') {
            data.bts.concat(bts);
        } else if (typeBts === 'Object' && Object.keys(bts).length) {
            data.bts.push(bts);
        }
        if (data.bts.length === 0) delete data.bts;
        return data;
    }
    // 商详整页曝光
    explorePageData() {
        const priceData = window.goodsPriceData || {};
        const priceIE = priceData.price || '';
        const skuInfo = {
            sku: GOODSINFO.goodsSn,
            pam: 1,
            pc: GOODSINFO.categoryId,
            k: GOODSINFO.warehouseCode,
            price: priceIE,
        };
        const sdata = {
            ksku: GOODSINFO.goodsSn,
            skuInfo,
            p: `p${GOODSINFO.webGoodsSn}`,
        };
        if (linkParameters.url_source) {
            sdata.ubcta = sdata.ubcta || {};
            sdata.ubcta[appParam] = linkParameters.url_source;
        }
        this.concatBTS(sdata, this.sendData);
        return sdata;
    }
    customExploreTrackCallback(target) {
        const { itemType } = target.configData || {};
        let data = {};
        if (itemType === 'goodsReviews') {
            const trackPage = $('#js-panelReview').data('trackpage').toString();
            data = {
                filter: {
                    page: trackPage,
                },
                ubcta: {
                    type: 'review',
                },
            };
            // policy不为空且只在全球站上报BTS
            if (btsDefault.policy && window.GLOBAL.PIPELINE === 'GB') {
                data.bts = btsDefault;
            }
        }

        return data;
    }

    // 点击处理（组装所需数据）
    customClickTrackCallback(config) {
        const self = this;
        const { itemType, shareType } = config.configData || {};
        let data = {};
        const typeCfg = {
            // 加车
            addToCart: () => {
                // 加车添加评论BTS
                if (btsDefault.plancode && btsDefault.policy && window.GLOBAL.PIPELINE === 'GB') {
                    this.concatBTS(data, btsDefault);
                }
                if (linkParameters.url_source) {
                    data.ubcta = data.ubcta || {};
                    data.ubcta[appParam] = linkParameters.url_source;
                }
                if (self.sendData) {
                    this.concatBTS(data, self.sendData);
                }
            },

            // 直接购买
            buyNow: () => {
                // 直接购买添加评论BTS
                if (btsDefault.plancode && btsDefault.policy && window.GLOBAL.PIPELINE === 'GB') {
                    this.concatBTS(data, btsDefault);
                }
                if (linkParameters.url_source) {
                    data.ubcta = data.ubcta || {};
                    data.ubcta[appParam] = linkParameters.url_source;
                }
                this.concatBTS(data, self.sendData);
            },

            // 分享
            share: () => {
                data = {
                    skuinfo: {
                        sku: GOODSINFO.goodsSn,
                        pc: GOODSINFO.categoryId,
                        k: GOODSINFO.warehouseCode,
                    },
                    pm: 'mb',
                    x: 'share',
                    ubcta: {
                        channel: '', // 分享类型
                        p: '' // 来自活动页面，要记录活动ID
                    },
                    ksku: GOODSINFO.goodsSn,
                };
                if (typeof shareType !== 'undefined') {
                    data.ubcta.channel = shareType;
                }
            },

            // 组合买
            combinationBuy: () => {
                const combinationSource = super.getRecordOrigin();
                if (Object.keys(combinationSource).length) {
                    window.sessionStorage.setItem(STORAGE_COMBINATION_ORIGIN, JSON.stringify(combinationSource));
                }
            }
        };
        if (typeof typeCfg[itemType] === 'function') {
            typeCfg[itemType]();
        }
        return { ...data };
    }
}

const goodsTrack = new GoodsTrack({
    config: GOODS_CONFIG,
    page: 'goods',
    noReleaseConnection: true,
    dataTrueIndex: 'data-recom-index'
});

export default (sendData = {}) => {
    goodsTrack.sendData = sendData; // 接收来自调用处传送的数据
    goodsTrack.run();
};

export { goodsTrack };
