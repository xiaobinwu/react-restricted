import Track from 'js/track/track';

const Addon = {
    '.gbGoodsItem_gift': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.gbGoodsItem_goodlist': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.gbGoodsGift_thumb_link': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    },
    '.gbGoodsGift_title_link': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    },
    '.gbGoodsList_thumb_link': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    },
    '.gbGoodsList_title_link': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    }
};

class AddonTrack extends Track {
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        const data = {};
        if (itemType === 'goodslink') { // 点击商品图片或者标题
            const domDataset = dom.closest('.gbGoodsItem_linkParent').dataset.customtrack.split('_');
            data.skuinfo = [{
                sku: domDataset[0],
                pc: domDataset[1],
                k: domDataset[2],
                pam: domDataset[3],
            }];
        }
        return { ...data, ...configData.customData };
    }
}

const addonTrack = new AddonTrack({
    config: Addon,
    page: true
});
export default () => {
    addonTrack.run();
};
