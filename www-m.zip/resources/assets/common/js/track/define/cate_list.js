import Track from 'js/track/track';
import { STORAGE_BTS_SEARCHENTRY, STORAGE_BTS_SEARCHBUYTOGETHER } from 'js/variables';


// 商详评论BTS分流结果
const btsTrackBtsPolicy = $('#js-hdTrackBtsPolicy').val() || '';
const storageKey = STORAGE_BTS_SEARCHENTRY;
// 默认bts数据
let btsDefault = {};
let storageBts;

try {
    storageBts = JSON.parse(window.sessionStorage.getItem(storageKey)) || {}; // 这是接口返回的bts信息
} catch (error) {
    storageBts = {};
}

// 防止本地bts落空了
btsDefault = Object.assign(btsDefault, storageBts);

// 判断 btsDefault 是否为空，有值则以副本上的policy为准,为空则不上报
if (!$.isEmptyObject(btsDefault)) {
    btsDefault.policy = btsTrackBtsPolicy;
} else {
    btsDefault = false;
}

// 当副本上的policy 和 本地存储中bts不等时
// 为防止后台统计数据干扰，剔除 除plancode和policy以外的值
if (btsDefault.policy !== storageBts.policy) {
    delete btsDefault.versionid;
    delete btsDefault.bucketid;
    delete btsDefault.planid;
}
// 获取当前页面的URL
const href = window.location.href;
// const trackOrder = $('input[name=track-infor]').data('track-order');
const isSearchPage = !(/c_\d{5,6}/.test(href)) && (/_gear/.test(href));
// 只有在搜索结果页才上报BTS
if (!isSearchPage) {
    btsDefault = false;
}
// 获取当前页的排序方式，只有在搜索结果页且trackOrder='Best Match'时才上报BTS
if (isSearchPage && $('.js-screenlist a.select').index() !== 0) {
    btsDefault = false;
}
// 判断是否是搜索结果页,只有搜索结果页只在全球站上报BTS
if (isSearchPage && window.GLOBAL.PIPELINE !== 'GB') {
    btsDefault = false;
}
// policy不为空才上报BTS
if (btsDefault.policy === '') {
    btsDefault = false;
}

// 存储BTS，在商详组合购买页面获取
if (btsDefault) {
    window.sessionStorage.setItem(STORAGE_BTS_SEARCHBUYTOGETHER, JSON.stringify(btsDefault));
} else {
    window.sessionStorage.removeItem(STORAGE_BTS_SEARCHBUYTOGETHER);
}

const SEARCHLIST_CONFIG = {
    // 搜索列表|分类列表商品位曝光
    '.js-gbGoodsItem': {
        explore: 'self',
        pageModule: 'mp',
        itemType: 'trackSearch',
        crossPage: 'search',
    },

    // 搜索列表|分类列表商品位 异步数据曝光
    '.js-gbGoodsItem-async': {
        explore: 'self',
        pageModule: 'mp',
        itemType: 'trackSearch',
        async: true,
        observer: '.js-catelistWrap',
    },

    // 搜索页点击商品位曝光
    '.js-trackSearchGoodsItem': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'trackSearch',
        recordOrigin: 1,
        mergeOrigin: 1,
        customData: {
            x: 'sku',
        },
        recordBTS: btsDefault,
        reportBTS: 1,
    },

    // 分类|普通列表页点击商品位曝光
    '.js-trackGoodsItem': {
        click: 'self',
        pageModule: 'mp',
        recordOrigin: 1,
        mergeOrigin: 1,
        itemType: 'trackPlain',
        customData: {
            x: 'sku',
        },
    },

    // 加入收藏
    '.js-trackCollect': {
        click: 'self',
        pageModule: 'mp',
        reportOrigin: 1,
        itemType: 'addToCollect',
        customData: {
            x: 'ADF',
        },
    },

    // 搜索结果页加入收藏(PS：仅限搜索结果页：sckw)
    '.js-trackSearchCollect': {
        click: 'self',
        pageModule: 'mp',
        reportOrigin: 1,
        itemType: 'addSearchToCollect',
        customData: {
            x: 'ADF',
        },
    },

    // 搜索列表关联词
    '.js-trackRelated': {
        itemType: 'relatedSearch',
        click: 'self',
        crossPage: 'search',
        recordOrigin: 2,
        customData: {
            sk: 'R',
            x: 'search',
        },
    },

    // 搜索纠错词
    '.js-trackSearchCorrect': {
        click: 'self',
        recordOrigin: 2,
        crossPage: 'search',
        itemType: 'searchCorrect',
        customData: {
            sk: 'J',
            x: 'search',
        },
    },
};

const ubctaSearch = {};
// 针对于搜索纠错页
const domErrorWord = document.querySelector('.searchKeyword_tips');
const trackKeyWord = $('input[name=track-word]').data('key-word');
if (trackKeyWord) {
    const correctSckw = trackKeyWord.split('_');
    ubctaSearch.sc = 'All Categories';
    ubctaSearch.siws = correctSckw[0];
    ubctaSearch.sckw = correctSckw[1];
    if (domErrorWord) {
        ubctaSearch.sk = 'J';
    }
}

// 针对于删词匹配页
const domItemX = document.querySelector('.cateMain_firstKeyWord');
if (domItemX) {
    const domArrX = [];
    const domFirsX = $('.cateMain_firstKeyWord');
    const domItemK = domFirsX.find('strike');
    const domAllKeyWord = domFirsX.text().replace(/['']/g, '').split(' ');
    domItemK.each((index, item) => {
        const tahtSef = $(item);
        domArrX.push(tahtSef.text());
    });
    const leftData = domAllKeyWord;
    const targetKeys = domArrX;
    const leg = leftData.length;
    for (let i = leg - 1; i >= 0; i -= 1) {
        for (let j = 0; j < targetKeys.length; j += 1) {
            if (leftData[i]) {
                if (leftData[i] === targetKeys[j]) {
                    leftData.splice(i, 1);
                    break;
                }
            }
        }
    }
    ubctaSearch.sk = 'S';
    ubctaSearch.sckw = leftData.join(' ') || '';
    ubctaSearch.siws = domFirsX.text().replace(/['']/g, '').split(' ').join(' ');
}

class SearchTrack extends Track {
    // 分类列表|搜索列表页整页曝光
    explorePageData() {
        const trackW = $('input[name=track-infor]').data('track-order');
        const filter = {
            view: 36,
            sort: trackW || '',
            page: 1,
        };
        const data = { filter, ...ubctaSearch };

        if (btsDefault) {
            super.saveBTS(btsDefault);
            super.mergeBTS();
        }

        return data;
    }

    customExploreTrackCallback(target) {
        const { itemType } = target.configData || {};
        const data = {};
        const trackC = $('input[name=track-infor]').data('track-order');
        const currentPage = $(target.target).attr('data-recode-page') || 1;
        if (itemType === 'trackSearch') {
            if (btsDefault) {
                data.bts = btsDefault;
            }
            data.filter = {
                view: 36,
                sort: trackC,
                page: currentPage,
            };
        }
        Object.assign(data, ubctaSearch);

        return data;
    }

    // 分类列表|搜索列表返回商品数量统计
    customCrossPageData(data) {
        // const trackA = $('input[name=track-infor]').data('total-num');
        const searchAt = (window.TrackData && window.TrackData.search && window.TrackData.search.at) || 0;
        let ubcta = {
            ubcta: {
                at: searchAt || 0,
            }
        };
        ubcta = { ...ubcta, ...ubctaSearch };
        return ubcta;
    }
    // 跨页面数据搜索纠错词数据
    getFixOriginData() {
        const trackR = $('.js-track-correct');
        const trackX = $('input[name=track-infor]').data('track-type');
        if (trackX === 'search') {
            if (trackR && trackR.length > 0) {
                const correctWordX = $('input[name=correct-word]').data('track-correct');
                return {
                    sckw: correctWordX || '',
                };
            }
        }
        return null;
    }

    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        const currentPage = $(dom).attr('data-recode-page') || 1;
        let data = {};
        // 普通分类列表页加入收藏
        if (itemType === 'addToCollect') {
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackC = $('input[name=track-infor]').data('track-order');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    fmd: 'mp',
                    rank: trackI,
                },
                filter: {
                    view: 36,
                    sort: trackC,
                    page: currentPage,
                },
            };
        } else if (itemType === 'addSearchToCollect') {
            // 搜索列表页加入收藏
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackC = $('input[name=track-infor]').data('track-order');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                    sckw: trackKeyWord,
                },
                filter: {
                    view: 36,
                    sort: trackC,
                    page: currentPage,
                },
            };
        } else if (itemType === 'trackPlain') {
            // 普通分类列表页商品位包含图片或标题点击曝光
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackC = $('input[name=track-infor]').data('track-order');

            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter: {
                    view: 36,
                    sort: trackC,
                    page: currentPage,
                },
            };
        } else if (itemType === 'trackSearch') {
            // 搜索列表商品位包含图片或标题点击曝光
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackC = $('input[name=track-infor]').data('track-order');
            const trackSK = super.getRecordOrigin().sk || '';

            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    sk: trackSK,
                    rank: trackI,
                    sckw: trackKeyWord || window.userTrackData.sckw,
                },
                filter: {
                    view: 36,
                    sort: trackC,
                    page: currentPage,
                },
            };
        } else if (itemType === 'relatedSearch') {
            // 搜索列表关联词点击曝光
            const trackW = dom.dataset.relatedcode.split('_');
            const trackA = $('input[name=track-infor]').data('total-num');
            data = {
                sl: trackW[0],
                sckw: trackW[1],
                ubcta: {
                    at: trackA || '',
                },
            };
        } else if (itemType === 'searchCorrect') {
            // 搜索纠错词
            const trackI = dom.dataset.index;
            const trackW = dom.dataset.correctKey;
            const trackX = $('input[name=correctKey]').data('key');
            data = {
                sl: trackI,
                sckw: trackW,
                siws: trackX,
                sc: 'All Categories',
            };
        }

        return { ...data, ...configData.customData };
    }
}

const searchTrack = new SearchTrack({
    config: SEARCHLIST_CONFIG,
    page: true,
    noReleaseConnection: true,
});

export default () => {
    searchTrack.run();
};
