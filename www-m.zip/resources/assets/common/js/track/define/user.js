import Track from 'js/track/track';

const USER = {
    // 会员中心入口
    index: {
        '.js-centerEntrance': {
            click: 'self',
            async: true,
            recordOrigin: 1,
            customData: {
                x: 'VIPCENTER_CLICK',
            },
        },
    },
    // 商品收藏页
    goodsFavor: {
        '.favor_item': {
            explore: 'self',
            pageModule: 'mp',
            exploreRoot: 'root',
            async: true,
            observer: '.favor_list'
        },

        '.link': {
            click: 'self',
            pageModule: 'mp',
            async: true,
            recordOrigin: 1,
            observer: '.favor_list'
        },

        '.js-addToCart': {
            click: 'self',
            pageModule: 'mb',
            async: true,
            reportOrigin: 1,
            observer: '.favor_list',
        },
    },

    // 我的订单
    order: {
        '.js-continueToPay': {
            click: 'self',
            async: true,
            observer: '.orderList',
        },
        '.childOrder_goodsItem': {
            click: ['.link'],
            itemType: 'orderLink'
        }
    },

    // 会员中心
    center: {
        '.js-memberBanner': {
            module: 'A_@',
            start: 1,
            click: 'self',
            explore: 'self',
            pageModule: 'md',
            async: true,
            recordOrigin: 1,
            exploreRoot: 'root',
        },
    },

    rule: {
        '.js-growthValueBtn': {
            click: 'self',
            recordOrigin: 1,
        }
    }
};

export default class UserTrack extends Track {
    constructor({
        type = 'goodsFavor', // 子页面名称
        page = false, // 是否曝光页面
        extendData = {} // 公共数据
    }) {
        super({
            config: USER[type],
            page,
            extendData
        });
    }
    customClickTrackCallback(data) {
        const {
            dom,
            classKey,
            configData,
            // module,
            targetData
        } = data;
        const { itemType } = configData;
        if (classKey === '.js-centerEntrance') {
            return {
                ubcta: { name: 'vipcenter enter' }
            };
        } else if (classKey === '.js-addToCart') {
            // 加入购物车
            return {
                x: 'ADT',
                ksku: targetData.sku,
                ubcta: { fmd: 'mp' }
            };
        } else if (classKey === '.js-continueToPay') {
            return {
                x: 'CTP',
                skuinfo: (window.trackDataForOrder || {})[dom.dataset.track],
            };
        } else if (classKey === '.js-memberBanner') {
            const key = dom.dataset.index;
            return {
                x: `B_${key}`,
                ubcta: {
                    mdlc: `B_${key}`,
                    mdID: dom.dataset.trackKey,
                },
            };
        } else if (classKey === '.js-growthValueBtn') {
            return {
                x: 'RULE_CLICK',
                ubcta: { name: 'shopping' }
            };
        } else if (itemType === 'orderLink') {
            return {
                ubcta: {
                    type: 'mp',
                    sku: dom.dataset.goodssn,
                    tab: $('.navigate').find('.case.on').html()
                }
            };
        }
        return {};
    }
}
