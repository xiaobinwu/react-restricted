import Track from 'js/track/track';

const {
    storeId, pageNo, orderByCode, pageSize
} = window.userTrackData;

const storeConfig = {
    '.js-gbGoodsItem': {
        click: ['.gbGoodsItem_text', '.gbGoodsItem_thumb'],
        explore: 'self',
        exploreRoot: 'root',
        pageModule: 'mp',
        itemType: 'goodsItem',
        recordOrigin: 1
    },
    '.js-gbGoodsItem-async': {
        click: ['.gbGoodsItem_text', '.gbGoodsItem_thumb'],
        explore: 'self',
        exploreRoot: 'root',
        pageModule: 'mp',
        itemType: 'goodsItem',
        async: true, // 异步加载的数据的设置
        observer: '.storeGoods_panelList',
        recordOrigin: 1
    },
};

class StoreTrack extends Track {
    // 店铺整页曝光
    explorePageData() {
        const data = {
            si: storeId,
            filter: {
                view: pageSize,
                sort: orderByCode,
                page: pageNo
            }
        };
        return data;
    }
    customExploreTrackCallback({
        target,
        configData
    }) {
        const { itemType } = configData;
        const {
            trackKey
        } = target.dataset;
        let obj = {};
        if (itemType === 'goodsItem') {
            const index = $(target).index();
            const pageIndex = parseInt(index / pageSize, 10) + 1;
            obj = {
                ubcta: {
                    sku: trackKey.split('_')[0],
                    rank: index + 1
                },
                filter: {
                    view: pageSize,
                    sort: window.userTrackData.orderByCode, // 这个变量会变化
                    page: pageIndex
                }
            };
        }
        return obj;
    }

    customUserOriginData({ data, tmpSearchOriginData, keyTarget }) {
        const { rank, store } = data.ubcta;
        return {
            rank,
            store
        };
    }
    customClickTrackCallback({ dom, configData, module }) {
        const { itemType } = configData;
        if (itemType === 'goodsItem') {
            let pageIndex = 1;
            const $dom = $(dom);
            const index = $dom.closest('.gbGoodsItem').index();
            pageIndex = parseInt(index / pageSize, 10) + 1;
            return {
                ubcta: {
                    store: storeId,
                    rank: index + 1
                },
                filter: {
                    view: pageSize,
                    sort: window.userTrackData.orderByCode, // 这个变量会变化
                    page: pageIndex
                }
            };
        }
        return {};
    }
}

const storeTrack = new StoreTrack({
    config: storeConfig,
    page: true,
});
export default () => {
    storeTrack.run();
};
