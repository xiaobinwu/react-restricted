/**
 * Created by Liu.Jun on 2018/5/16.
 */
import Track from 'js/track/track';

const indexConfig = {
    '.indexBan_slickItem': {
        module: 'A_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        recordOrigin: 1,
        exploreRoot: '.indexSwiper',
        exploreFirstShow: 1,
    },
    '.indexAd_item': {
        module: 'B_@',
        start: 2,
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'indexAd',
        recordOrigin: 1,
        exploreRoot: 'root',
    },
    '.js_flashSaleItem': {
        module: 'R_1',
        click: 'self',
        explore: 'self',
        pageModule: 'mr',
        itemType: 'flashSaleItem',
        recordOrigin: 1,
        exploreRoot: 'root',
    },
    '.js_dailyDealsItem': {
        module: 'R_2',
        click: 'self',
        explore: 'self',
        pageModule: 'mr',
        itemType: 'dailyDealsItem',
        recordOrigin: 1,
        exploreRoot: '.indexSale_contain',
    },
    '.indexCate_item': {
        module: '@_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'indexCateItem',
        recordOrigin: 1,
        parent: {
            query: '.indexCate',
            start: 'C',
        },
        exploreRoot: 'root',
    },

};

const headerTrack = new Track({
    config: indexConfig,
    page: 'index'
});

export default () => {
    headerTrack.run();
};
