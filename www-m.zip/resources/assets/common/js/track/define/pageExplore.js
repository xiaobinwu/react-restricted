import Track from 'js/track/track';

const track = new Track({
    page: true,
});

export default () => {
    track.run();
};
