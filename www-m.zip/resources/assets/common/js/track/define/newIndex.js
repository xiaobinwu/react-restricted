/**
 * Created by Liu.Jun on 2018/5/16.
 */
import Track from 'js/track/track';

const indexConfig = {
    '.indexBan_slickItem': {
        module: '@_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        recordOrigin: 1,
        exploreRoot: '.js-trackExplore',
        parent: {
            query: '.js-trackExplore',
            start: 'A',
        },
        exploreFirstShow: 1,
        customUbcta({ target }) {
            const swiperIndex = $(target).attr('data-banner-index');
            return {
                rank: +swiperIndex + 1,
            };
        }
    },
    '.indexBanner_link': {
        module: '@_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        recordOrigin: 1,
        exploreRoot: 'root',
        parent: {
            query: '.js-trackExplore',
            start: 'A',
        },
    },
    '.indexCatetory_item': {
        module: '@_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        recordOrigin: 1,
        exploreRoot: 'root',
        parent: {
            query: '.js-trackExplore',
            start: 'A',
        },
        customUbcta({ target }) {
            const swiperIndex = $(target).attr('data-cate-index');
            return {
                rank: +swiperIndex + 1,
            };
        }
    },
    '.indexAd_item': {
        module: '@_@',
        start: 1,
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        recordOrigin: 1,
        exploreRoot: 'root',
        parent: {
            query: '.js-trackExplore',
            start: 'A',
        },
    },
    '.indexSaleItem_img': {
        module: '@_1',
        explore: 'self',
        click: 'self',
        pageModule: 'mr',
        itemType: 'indexSale',
        recordOrigin: 1,
        exploreRoot: 'root',
        parent: {
            query: '.js-trackExplore',
            start: 'A',
        },
    },
    '.js-gbGoodsItem': {
        module: '@_1',
        explore: 'self',
        click: ['.gbGoodsItem_thumb', '.gbGoodsItem_title'],
        pageModule: 'mr',
        itemType: 'indexRecommend',
        recordOrigin: 1,
        exploreRoot: 'root',
        parent: {
            query: '.js-trackExplore',
            start: 'A',
        },
        async: true,
        observer: '.indexRecommend_list',
    },
};

const headerTrack = new Track({
    config: indexConfig,
    page: 'index',
    noReleaseConnection: true
});

export default () => {
    headerTrack.run();
};
