import Track from 'js/track/track';

const RULES = {
    common: {
        '.gbGoodsItem': {
            explore: 'self',
            pageModule: 'mp',
            exploreRoot: 'root',
            click: 'self',
            itemType: 'goodslink',
            customData: {
                x: 'sku',
            },
        },

        '.goodsItem_thumb': {
            click: 'self',
            pageModule: 'mp',
        },

        '.goodsItem_title': {
            click: 'self',
            pageModule: 'mp',
        },

        '.gbGoodsItem_like': {
            click: 'self',
            pageModule: 'mb',
        },

        '.gbGoodsItem_cart': {
            click: 'self',
            pageModule: 'mb',
        },
    },
};

class BrandsTrack extends Track {
    constructor({
        type = 'common', // 子页面名称
        page = false, // 是否曝光页面
        extendData = {} // 公共数据
    }) {
        super({
            config: RULES[type],
            page,
            extendData
        });
    }

    customClickTrackCallback({
        dom, classKey, configData, targetData
    }) {
        let data = {};
        if (classKey === '.gbGoodsItem_cart') {
            // 加入购物车
            data = {
                x: 'ADT',
                ksku: targetData.sku,
                ubcta: { fmd: 'mp' }
            };
        } else if (classKey === '.gbGoodsItem_like') {
            // 加入收藏夹
            data = {
                x: 'ADF',
                ubcta: { fmd: 'mp' }
            };
        } else if (configData.itemType === 'goodslink') {
            // 点击商品图片或者标题
            const { dataset } = dom.closest('.js-gbGoodsItem');
            const trackKeys = dataset.trackKey.split('_');
            const { catId } = dataset;
            data.skuinfo = [{
                sku: trackKeys[0],
                pc: catId,
                k: trackKeys[1],
                pam: 36,
            }];
        }
        return { ...data, ...configData.customData };
    }
}

export {
    BrandsTrack,
    RULES
};
