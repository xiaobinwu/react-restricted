/**
 * Created by Jiazhan Li on 2018/11/23.
 */

import Track from 'js/track/track';

window.addEventListener('beforeinstallprompt', (event) => {
    if (event.userChoice) {
        event.userChoice.then((result) => {
            if (result.outcome === 'dismissed') {
                // 用户点了取消
                Track.sendData({ data: { x: 'CLOSE_HOMESCREEN' } });
            } else {
                Track.sendData({ data: { x: 'ADD_HOMESCREEN' } });
            }
        });
    }
});
