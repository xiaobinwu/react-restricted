import Track from 'js/track/track';

const RULES = {
    // 单个收藏
    '.icon-favorItem': {
        click: 'self',
        pageModule: 'mb',
        itemType: 'favor',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },
    // 批量收藏
    '.icon-allFavor': {
        click: 'self',
        pageModule: 'mb',
        itemType: 'batchFavor',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },
    // 点击商品图片
    '.cart_img': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    },
    // 点击商品标题
    '.cart_link': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    },
    // 快捷支付
    '.quickPay': {
        click: 'self',
        pageModule: 'mr',
        itemType: 'checkout',
        customData: {
            x: 'CWP',
        },
    },
    // 点击下单
    '.checkout': {
        click: 'self',
        pageModule: 'mr',
        itemType: 'checkout',
        customData: {
            x: 'checkout',
        },
    },
    // 底部推荐位 曝光 + 点击
    '.gbGoodsItem': {
        module: 'T_2',
        click: 'self',
        explore: 'self',
        recordOrigin: 1,
        itemType: 'goodsRecom',
        pageModule: 'mr',
        async: true,
        observer: '.recommend_goods',
    },
    '.cart_itemlist': {
        click: ['.cart_img', '.cart_link'],
        itemType: 'cartItem',
    }
};

class Paycart extends Track {
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        const data = {};
        if (itemType === 'batchFavor' || itemType === 'checkout') { // 批量收藏
            const skuinfo = [];
            const trackData = window.TrackData.TrackDataList;
            for (const datakey in trackData) {
                const item = trackData[datakey];
                if (item.isSelected) {
                    const skudata = {
                        sku: item.sku,
                        pc: item.pc,
                        k: item.k,
                    };
                    // 点击 生成订单按钮
                    if (itemType === 'checkout') {
                        skudata.pam = item.pam;
                    }
                    skuinfo.push(skudata);
                }
            }

            data.skuinfo = skuinfo;
        } else if (itemType === 'favor') { // 单个收藏
            const dataset = dom.dataset.customtrack.split('_');
            data.skuinfo = [{
                sku: dataset[0],
                pc: dataset[1],
                k: dataset[2],
            }];
        } else if (itemType === 'goodslink') { // 点击商品图片或者标题
            const domDataset = dom.closest('.cart_itemlist').dataset.customtrack.split('_');
            data.skuinfo = [{
                sku: domDataset[0],
                pc: domDataset[1],
                k: domDataset[2],
                pam: domDataset[3],
            }];
        } else if (itemType === 'goodsRecom') { // 点击推荐位商品
            const { dataset } = dom;
            const itemSku = dataset.trackKey.split('_')[0];
            data.ubcta = [];
            data.ubcta.push({
                mrlc: RULES['.gbGoodsItem'].module,
                sku: itemSku,
                rank: dataset.index,
            });
            data.ksku = itemSku;
        } else if (itemType === 'cartItem') {
            data.x = $(dom).closest('.cart_itemlist').data('customtrack').split('_')[0];
        }

        return { ...data, ...configData.customData };
    }
    // 页面曝光数据：
    explorePageData() {
        const trackData = window.TrackData.TrackDataList;
        const data = {};
        data.skuinfo = [];
        for (const item in trackData) {
            const itemData = trackData[item];
            data.skuinfo.push({
                sku: itemData.sku,
                pam: itemData.pam,
                pc: itemData.pc,
                k: itemData.k,
            });
        }
        return data;
    }
}

class CheckoutTrack extends Track {
    // 页面曝光数据：
    explorePageData() {
        const data = {};
        return data;
    }
}

export {
    Paycart,
    RULES,
    CheckoutTrack
};
