import Track from 'js/track/track';

const PRESALE_CONFIG = {
    // // 预售页列表点击商品位曝光
    // '.js-trackGoodsItem': {
    //     click: 'self',
    //     pageModule: 'mp',
    //     itemType: 'trackPlain',
    //     customData: {
    //         x: 'sku',
    //     },
    // },

    // 预售页列表商品位曝光
    '.presaleContent_item': {
        explore: 'sefl',
        pageModule: 'mp',
        exploreRoot: 'root',
    },

    // 预售页列表商品位 异步数据曝光
    '.presaleContent_item_async': {
        explore: 'self',
        pageModule: 'mp',
        async: true,
        observer: '.presaleContent_list',
    },

};

class PresaleTrack extends Track {
    // customClickTrackCallback({ dom, configData }) {
    //     const { itemType } = configData;
    //     let data = {};
    //     if (itemType === 'trackPlain') {
    //         // 预售页列表商品位图片或标题点击曝光
    //         const trackI = dom.dataset.index;
    //         const trackP = dom.dataset.trackcode.split('_');
    //         const trackC = $('input[name=track-infor]').data('track-inofo').split('_');
    //         data = {
    //             skuinfo: {
    //                 sku: trackP[0],
    //                 pam: 0,
    //                 pc: trackP[1],
    //                 k: trackP[2],
    //             },
    //             ubcta: {
    //                 rank: trackI,
    //             },
    //             filter: {
    //                 view: trackC[0],
    //                 page: trackC[1] ? trackC[1] : 1,
    //             },
    //         };
    //     }

    //     return { ...data, ...configData.customData };
    // }
}

const presaleTrack = new PresaleTrack({
    config: PRESALE_CONFIG,
    page: true,
});

export default () => {
    presaleTrack.run();
};
