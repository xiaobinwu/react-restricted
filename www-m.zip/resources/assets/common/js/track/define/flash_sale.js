import Track from 'js/track/track';

const FLASHSALE_CONFIG = {
    '.js-goodsItemAsync': {
        explore: 'self',
        click: ['.js-trackBtnImg', '.js-trackBtnTitle', '.js-trackBtnBuy'],
        exploreRoot: 'root',
        pageModule: 'mp',
        itemType: 'goods',
        async: true, // 异步加载的数据的设置
        observer: '.js-panelItemList',
        customUbcta({ sku, target }) {
            const $itemParent = $(target).parents('.js-panelListGroup');
            const index = $itemParent.find(target).index();
            return {
                sku,
                fsid: $itemParent.attr('data-scence-id'),
                time: $itemParent.attr('data-begin'),
                rank: +index + 1,
            };
        }
    },
    '.js-trackFlashGoodsItem': {
        explore: 'self',
        click: ['.js-trackBtnImg', '.js-trackBtnTitle', '.js-trackBtnBuy'],
        exploreRoot: 'root',
        pageModule: 'mp',
        itemType: 'goods',
        customUbcta({ sku, target }) {
            const $itemParent = $(target).parents('.js-panelListGroup');
            const index = $itemParent.find(target).index();
            return {
                sku,
                fsid: $itemParent.attr('data-scence-id'),
                time: $itemParent.attr('data-begin'),
                rank: +index + 1,
            };
        }
    },
};
class FlashSaleTrack extends Track {
    // 商详整页曝光
    explorePageData() {
        const $sellingScence = $('#js-tabScence').find('.js-trackDefaultScence');
        const data = {
            ubcta: {
                fsid: $sellingScence.attr('data-scence-id'),
                time: $sellingScence.attr('data-begin')
            }
        };

        return data;
    }

    // 自定义
    customClickTrackCallback(config) {
        const { keyTarget } = config;
        const { itemType } = config.configData || {};
        if (itemType === 'goods') {
            const $itemParent = $(keyTarget).parents('.js-panelListGroup');
            const index = $itemParent.find(keyTarget).index();
            const sku = $(keyTarget).attr('data-track-key').split('_')[0];

            super.setOriginStorage({
                sku,
                fsid: $itemParent.attr('data-scence-id'),
                time: $itemParent.attr('data-begin'),
                rank: +index + 1,
            });
        }
    }
}

const flashSaleTrack = new FlashSaleTrack({
    page: true,
    config: FLASHSALE_CONFIG,
});

export default () => {
    flashSaleTrack.run();
};
