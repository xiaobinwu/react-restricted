/**
 * Created by Liu.Jun on 2018/8/30.
 */
import appSdk from 'js/core/app.sdk.js';
import { serviceGetPwaInfo } from 'js/service/common.js';

const version = 'gb0.1.1';
const stargeKey = 'sw_version';

async function runServerWork() {
    if (appSdk.IS_APP) {
        return;
    }

    if (0 && 'serviceWorker' in navigator && 'fetch' in window) {
        const { status, data } = await serviceGetPwaInfo.http();
        // unregister
        if (status === 0 && data === 0) {
            navigator.serviceWorker.getRegistrations().then((registrations) => {
                for (const registration of registrations) {
                    registration.unregister().then(() => {
                        console.log('SW unregister');
                    });
                }
            });
        } else {
            navigator.serviceWorker.register(`/sw.js?v=${version}`).then((registration) => {
                if (version !== localStorage.getItem(stargeKey)) {
                    registration.update().then(() => {
                        localStorage.setItem(stargeKey, version);
                        console.log('SW_version update');
                    });
                }
                console.log('SW registered: ↓', registration);
            }).catch((registrationError) => {
                // console.log('SW registration failed: ', registrationError)
            });
        }
    }
}

export { runServerWork };
