import 'gbpolyfill';
import 'js/event/event.dom';
import 'js/event/event.sys';
import 'intersection-observer';
import 'mutationobserver-shim';

// 全站基础css
import 'common/icon/syncGlobal/index.css'; // 全站同步字体图标

import 'css/bootstrap.css';

// layer css 独立出来通过vendor提取
import 'js/lib/layer/mobile/need/layer.css';
import 'js/lib/layer/mobile/layer.custom.css';


// 兼容双十一首页嵌套的一些异常
import 'js/core/app_polyfill/style.css';

import PubSub from 'pubsub-js';
import Cookies from 'js/utils/cookie';
import asyncPrice from 'js/core/asyncPrice';
import { getUrlQuery } from 'js/utils/index.js';
import 'js/lib/alloyfinger/zepto.event.extend';
import 'js/track/define/beforeinstallprompt.js';

import { COOKIE_LANG, COOKIE_PIPELINE } from 'js/variables';

// 获取默认和设置默认的语言和国家渠道
Cookies.set(COOKIE_LANG, GLOBAL.LANG);
Cookies.set(COOKIE_PIPELINE, GLOBAL.PIPELINE);

// 为防止丢失linkid，提前写cookie
setTimeout(() => {
    const { lkid, vip } = getUrlQuery();
    const linkid = vip || lkid;
    if (linkid) {
        Cookies.set('linkid', linkid, {
            domain: window.GLOBAL.DOMAIN_COOKIE,
            expires: 30
        });
    }
}, 0);

PubSub.publish('sysInitLazyload');
asyncPrice();

// PubSub.subscribe('nativeReady', async () => {
//
// });


PubSub.subscribe('nativeLoad', async () => {
    const { default: asyncBootstrap } = await import('./asyncBootstrap.js');
    asyncBootstrap();
});

// 有用的 不能删除 !!!!
document.body.addEventListener('touchstart', () => {});

