/**
 * 全局公共JS变量
 */

const EMPTY_IMG = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

const COOKIE_MUID = 'muid';
const COOKIE_LANG = 'gb_lang';
// const COOKIE_LOGIN = 'gbm_isLogin';
const COOKIE_PIPELINE = 'gbm_pipeline';
const COOKIE_CURRENCY_CODE = 'gbm_currencyCode';
const COOKIE_COUNTRY_CODE = 'gbm_countryCode';
// const COOKIE_FIRST_VIEW = 'gbm_firstView';
const COOKIE_CDN_COUNTRYCODE = 'cdn_countryCode';
const COOKIE_USERINFO = 'gbm_userinfo';
const COOKIE_FULL_SITE = 'fullsite';
const COOKIE_CATEID = 'gbm_cateId';
const COOKIE_IS_VIEW = 'gbm_isView';
const COOKIE_GOODS_REVIEW_AB = 'gbm_goodsReviewAB'; // 前端使用，商详评论abtest副本标识
const COOKIE_TEST_COOKIE_ID = 'gbm_testCookieId'; // 前端使用，测试环境没有AKMANID，前端自己生成使用，仅测试环境
const COOKIE_UID = 'guid';
const COOKIE_SEARCH_AB = 'gbm_searchAB'; // 前端使用，搜索结果页abtest副本标识
const COOKIE_FCM = 'gb_fcm'; // 前端使用，fcm request状态 (core/firebse/main.js)
const COOKIE_FCM_TOKEN = 'gb_fcmtoken'; // 前端使用，当前fcm token
const COOKIE_FCM_PIPELINE = 'gb_fcmPipeLine'; // 前端使用，判断国家站是否有push过token

const STORAGE_APPAREL = 'gbm_apparel';
const STORAGE_GOODS_VIEW_HISTORY = 'gbm_goodsViewHistory';
const STORAGE_DEALS_NODE_ITEM = 'gbm_dealsNodeItem';
const STORAGE_EXPLORE_NODE_DATA_ID = 'gbm_exploreNodeDataId';
const STORAGE_EXPLORE_NODE = 'gbm_exploreNode';
const STORAGE_ZONE_CATE_NAV = 'gbm_zoneCateNav';
const STORAGE_ZONE_DEALS_NODE = 'gbm_zoneDealsNode';
const STORAGE_GOODSLIST_NODE = 'gbm_goodsListNode';
const STORAGE_SHARE_STATUS = 'shareStatus';
const STORAGE_SAVE_EO = 'gbm_saveEo';
const STORAGE_CATEID = 'gbm_cateId';
const STORAGE_IS_NOTICE = 'gbm_isNotice';
const STORAGE_REVIEW_NICK_NAME = 'gbm_reviewNickName';
const STORAGE_GOODS_COUNTRYCODE = 'gbm_goodsCountryCode'; // 为不影响整站国家码，商详页物流面板记录单独的国家码
const STORAGE_COOKIE_POLICY = 'gbm_cookiePolicy';
const STORAGE_RECORD_TO_GOODS = 'gbm_recordToGoods'; // 记录进入商详标识(referrer,isChangeAttr)
const STORAGE_SHOW_OPEN_APP_TIME = 'gbm_showOpenAppTime'; // 记录顶部引流条关闭时间节点
const STORAGE_MESSAGE_INFO = 'messageInfo'; // 站内信信息
const STORAGE_INDEX_RECOM = 'gbm_indexRecom'; // 首页AI推荐数据
const STORAGE_GOODS_REDIRECT_LINK = 'gbm_goodsRedirectLink';
const STORAGE_BTS_REVIEWSENTRY = 'gbm_btsReviewsEntry'; // 商详评论入口abtest bts
const STORAGE_BTS_BUYTOGETHER = 'gbm_btsBuyTogether'; // 商详组合购买加车时添加评论bts
const STORAGE_SOURCE_BTS = 'gbm_sourceBTS';
const STORAGE_SOURCE_ORIGIN = 'gbm_sourceOrigin';
const STORAGE_COMBINATION_ORIGIN = 'gbm_combinationOrigin'; // 组合购买的记录页面来源
const STORAGE_BTS_SEARCHENTRY = 'gbm_btsSearchEntry'; // 搜索结果页入口abtest bts
const STORAGE_BTS_SEARCHBUYTOGETHER = 'gbm_btsSearchBuyTogehter'; // 搜索结果页进入商详再进入组合购买页面时获取


export {
    EMPTY_IMG,

    COOKIE_MUID,
    COOKIE_LANG,
    // COOKIE_LOGIN,
    COOKIE_PIPELINE,
    COOKIE_CURRENCY_CODE,
    // COOKIE_FIRST_VIEW,
    COOKIE_COUNTRY_CODE,
    COOKIE_CDN_COUNTRYCODE,
    COOKIE_USERINFO,
    COOKIE_FULL_SITE,
    COOKIE_CATEID,
    COOKIE_IS_VIEW,
    COOKIE_GOODS_REVIEW_AB,
    COOKIE_TEST_COOKIE_ID,
    COOKIE_UID,
    COOKIE_SEARCH_AB,
    COOKIE_FCM,
    COOKIE_FCM_TOKEN,
    COOKIE_FCM_PIPELINE,

    STORAGE_APPAREL,
    STORAGE_GOODS_VIEW_HISTORY,
    STORAGE_DEALS_NODE_ITEM,
    STORAGE_EXPLORE_NODE_DATA_ID,
    STORAGE_EXPLORE_NODE,
    STORAGE_ZONE_CATE_NAV,
    STORAGE_ZONE_DEALS_NODE,
    STORAGE_GOODSLIST_NODE,
    STORAGE_SHARE_STATUS,
    STORAGE_SAVE_EO,
    STORAGE_CATEID,
    STORAGE_IS_NOTICE,
    STORAGE_REVIEW_NICK_NAME,
    STORAGE_GOODS_COUNTRYCODE,
    STORAGE_COOKIE_POLICY,
    STORAGE_RECORD_TO_GOODS,
    STORAGE_SHOW_OPEN_APP_TIME,
    STORAGE_MESSAGE_INFO,
    STORAGE_INDEX_RECOM,
    STORAGE_GOODS_REDIRECT_LINK,
    STORAGE_BTS_REVIEWSENTRY,
    STORAGE_BTS_BUYTOGETHER,
    STORAGE_SOURCE_BTS,
    STORAGE_SOURCE_ORIGIN,
    STORAGE_COMBINATION_ORIGIN,
    STORAGE_BTS_SEARCHENTRY,
    STORAGE_BTS_SEARCHBUYTOGETHER,
};
