/**
 * 禁用BF(网采)商品国家
 * 2018-10-09 21:20:49
 * luochongfei
 */

import { getCdnCountryCode } from 'js/core/currency';

// 禁用BF商品国家列表
const BFCOUNTRY = ['US', 'GB', 'FR', 'DE', 'CA', 'AU', 'HK', 'CN'];

// 是否禁用BF商品国家(传国家码可判断指定国家, 不传则判断IP国家)
const isBfCountry = async (countryCode = null) => {
    const country = countryCode || await getCdnCountryCode();
    return BFCOUNTRY.includes(country);
};

export {
    BFCOUNTRY,
    isBfCountry
};
