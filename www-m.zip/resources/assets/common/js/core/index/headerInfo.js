import { STORAGE_CATEID, COOKIE_CATEID } from 'js/variables';
import Cookies from 'js/utils/cookie';

const headerInfo = {
    prevHref: window.GLOBAL.DOMAIN_MAIN || '/',
    setCateId(categoryId) {
        Cookies.set(COOKIE_CATEID, categoryId); // 种cookkie，解决跨域
        window.sessionStorage.setItem(STORAGE_CATEID, categoryId);
    },
    getCateIdHref() {
        const cateId = Cookies.get(COOKIE_CATEID);
        let indexHref = this.prevHref;
        if (cateId) {
            indexHref += `/index/region?catId=${cateId}`;
        }
        window.location.href = indexHref;
    },
    toIndexLink() {
        /* 根据分类ID跳不同首頁馆区 */
        $('.js-indexCate_link').click((e) => {
            const catIdsUrls = JSON.parse(window.sessionStorage.getItem('catIdsUrls'));
            const catId = window.sessionStorage.getItem(STORAGE_CATEID);
            const hitIndex = [];
            if (catIdsUrls) {
                if (catId) {
                    e.preventDefault();
                    catIdsUrls.catIds.forEach((value, index) => {
                        if (index !== 0) {
                            if (value.indexOf(catId) !== -1) {
                                hitIndex.push(index);
                            }
                        }
                    });
                    let toIndexHref = '';
                    if (hitIndex.length >= 2) {
                        toIndexHref = catIdsUrls.urls[0];
                    } else if (hitIndex.length === 1) {
                        toIndexHref = catIdsUrls.urls[hitIndex[0]];
                    } else {
                        toIndexHref = this.prevHref;
                    }
                    window.location.href = toIndexHref;
                }
            } else {
                e.preventDefault();
                this.getCateIdHref();
            }
        });

    }
};

export default headerInfo;
