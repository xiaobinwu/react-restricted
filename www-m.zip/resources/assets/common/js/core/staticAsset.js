/**
 * Created by Liu.Jun on 2018/7/26.
 */

function staticAsset(url) {
    const domainStatic = window.GLOBAL && window.GLOBAL.DOMAIN_STATIC ? window.GLOBAL.DOMAIN_STATIC : '';
    return `${domainStatic}${url}`;
}

export default staticAsset;
