
import Base64 from 'base-64';
import Cookies from 'js/utils/cookie';
import { COOKIE_USERINFO } from 'js/variables';


let userInfo;
const { DOMAIN_LOGIN } = GLOBAL;

/* 获取用户登录状态/自动处理跳转到登录页（状态会被缓存）
 * @param update   强制重新请求(默认关闭)
 * @param toLogin  是否自动登录(默认开启)
*/

function getUserStatus({ update = 0, toLogin = 1 } = {}) {
    if (undefined === userInfo || update) {
        const userInfoCookie = Cookies.get(COOKIE_USERINFO);
        let errorFlag;
        if (userInfoCookie) {
            try {
                const data = JSON.parse(Base64.decode(decodeURIComponent(userInfoCookie)));
                if (data) {
                    userInfo = data;
                } else {
                    errorFlag = 1;
                }
            } catch (error) {
                errorFlag = 1;
            }
        } else {
            errorFlag = 1;
        }
        if (errorFlag) {
            return {};
        }
    }
    if (toLogin && !userInfo.isLogin) {
        window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
        return false;
    }
    return userInfo;
}


export default getUserStatus;
