/**
 * 获取用户的唯一标识ID，保证不重样
 * 2018-11-28 10:34:36
 */

import Cookies from 'js/utils/cookie';
import { COOKIE_TEST_COOKIE_ID } from 'js/variables';

const cookies = Cookies.get();

/**
 * 生成唯一ID，来自https://analytics.logsss.com/logsss22.min.js
 */
function createUniqueId() {
    const array = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
    let ubcd = '';
    const timestamp = String(Date.now());
    for (let i = 0; i < 12; i += 1) {
        const index = Math.floor(Math.random() * array.length);
        ubcd += array[index];
    }
    const cookieid = ubcd + timestamp;
    return cookieid;
}

/**
 * 获取用户唯一ID
 * 因测试环境没有 AKAM_CLIENTID，退而求其次，用自己生成的ID
 */
function getUserId() {
    // php唯一标识
    if (cookies.bgsid) {
        return cookies.bgsid;
    }

    // 线上和预发布 CDN: AKAM_CLIENTID
    if (cookies.AKAM_CLIENTID) {
        return cookies.AKAM_CLIENTID;
    }

    // 测试环境
    if (cookies[COOKIE_TEST_COOKIE_ID]) {
        return cookies[COOKIE_TEST_COOKIE_ID];
    }

    const uid = createUniqueId();
    Cookies.set(COOKIE_TEST_COOKIE_ID, uid);
    return uid;
}

export {
    createUniqueId,
    getUserId
};

