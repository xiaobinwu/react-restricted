/**
 * Created by Liu.Jun on 2018/7/27.
 */
import Cookies from 'js/utils/cookie';
import getUserStatus from './getUserStatus.js';

/**
 * 判断是否登录
 * return true || false
 */
function isLogin(IS_APP = false) {
    if (IS_APP) {
        const curIsLogin = Cookies.get('authorization');
        return curIsLogin && curIsLogin.length > 20;
    }

    const userData = getUserStatus({
        toLogin: 0
    });
    return userData.isLogin || false;
}

export default isLogin;
