/**
 * 站内信总数
 */
import { getTimezone } from 'js/utils';
import { serviceMessageCount } from 'js/service/user';
import Cookies from 'js/utils/cookie';
import { COOKIE_USERINFO } from 'js/variables';
import Base64 from 'base-64';
import RecordMessageInfo from 'js/core/user/RecordMessageInfo.js'; // 记录站内信总数
import getUserStatus from './getUserStatus.js';

let promise = null;

export default async (elements) => {
    const userStatus = await getUserStatus({ update: 1, toLogin: 0 });

    if (userStatus.isLogin) {
        const userInfoCookie = Cookies.get(COOKIE_USERINFO);
        const userInfoData = JSON.parse(Base64.decode(decodeURIComponent(userInfoCookie)));
        const expireTime = userInfoData.siteMessageTimeInterval > 0 ? userInfoData.siteMessageTimeInterval : 60;
        if (!promise) {
            promise = new Promise(async (resolve) => {
                try {
                    const nowTime = Number(new Date());
                    const { messageQty, messageTime } = RecordMessageInfo.get();
                    if (messageTime && nowTime - messageTime < 1000 * expireTime) {
                        resolve(messageQty || 0);
                    } else {
                        const { status, data } = await serviceMessageCount.http({ params: { time_zone_id: getTimezone() } });
                        if (status === 0) {
                            resolve(data.num || 0);
                            RecordMessageInfo.set(data.num);
                        }
                    }
                } catch (err) {
                    resolve(0);
                }
            });
        }

        const count = await promise;
        [...elements].forEach((item) => {
            item.innerHTML = count > 99 ? '99+' : count;
            item.style.visibility = count > 0 ? 'visible' : 'hidden';
        });
    }
};
