/* yanrenqian 抽奖接口防刷封装 */
import { serviceRunLottery } from 'js/service/user.js';
import brushCheck from 'component/brushCheck/brushCheck.js';

const getRaffle = data => serviceRunLottery.http(data)
    .then(async (resOne) => {
        if (resOne.status === 40373285) {
            const checkContent = await brushCheck({
                action: resOne.data.action,
                siteKey: resOne.data.siteKey,
                recaptchaVersion: resOne.data.recaptchaVersion
            });
            data.data.gbcaptcha = checkContent.gbcaptcha; // 防刷类型
            data.data.captchaType = checkContent.captchaType; // 防刷验证码
            data.data.recaptchaVersion = checkContent.recaptchaVersion; // 谷歌防刷版本
            const res = await serviceRunLottery.http(data);
            return res;
        }
        return resOne;
    });
export default getRaffle;
