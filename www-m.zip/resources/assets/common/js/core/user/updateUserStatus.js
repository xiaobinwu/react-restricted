import getUserStatus from './getUserStatus.js';

/**
 * Created by Liu.Jun on 2018/7/27.
 */

async function updateUserStatus($eleCartNum) {
    const data = await getUserStatus({ update: 1, toLogin: 0 });
    if (!data.user) {
        return;
    }
    const $ele = $eleCartNum || $('.js-cartNum');
    const count = data.cartCount;
    if (count >= 0) {
        $ele.css('visibility', count < 1 ? 'hidden' : 'visible').text(count);
        window.USERINFO = {
            email: data.user.email || ''
        };
    }

    const { DOMAIN_LOGIN } = GLOBAL;
    if (!data.isLogin) {
        $('.js-siteHeaderUserBtn').attr('href', `${DOMAIN_LOGIN}/m-users-a-sign.htm`);
    }

}

export default updateUserStatus;
