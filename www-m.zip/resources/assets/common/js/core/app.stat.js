/**
 * Created by Liu.Jun on 2018/4/6.
 */

import Clipboard from 'clipboard';

export default function ({
    query = {},
    target = null
} = {}) {
    const {
        sascid,
        lkid,
        utm_source: utmSource,
        utm_medium: utmMedium,
        utm_campaign: utmCampaign,
    } = query;

    // app sascid
    let copyData;
    let isObj = true; // isObj为true,copyData为对象，否则为数组
    if (sascid) {
        copyData = { sascid };
    } else if (lkid) {
        copyData = { lkid };
    } else if (utmSource) {
        if (utmSource === 'admitad' || utmSource === 'zanox' || utmSource.indexOf('tt_') > -1) {
            copyData = window.location.search.substr(1);
            isObj = false;
        } else {
            copyData = {};
            copyData.utm_source = utmSource;
            copyData.utm_medium = utmMedium === undefined ? '' : utmMedium;
            copyData.utm_campaign = utmCampaign === undefined ? '' : utmCampaign;
        }
    }

    if (copyData) {
        let paramsList;
        if (copyData && isObj) {
            paramsList = Object.entries(copyData).map(([key, value]) => `${key}=${value}`);
            copyData = window.btoa(unescape(encodeURIComponent(paramsList.join('&'))));
        } else {
            if (copyData.indexOf('trace=third') > -1) {
                paramsList = copyData;
            } else {
                paramsList = `${copyData}&trace=third`;
            }
            copyData = window.btoa(unescape(encodeURIComponent(paramsList)));
        }

        // const triggerEle = document.documentElement;
        new Clipboard(target, {
            text() {
                return copyData;
            },
        });
    }
}
