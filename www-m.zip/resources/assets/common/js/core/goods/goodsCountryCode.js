/**
 * 获取|设置 商详页国家码
 * luochongfei
 * 2018-08-24 10:26:37
 * 历史缘由：因M整站站无公用的ship to选项，为了商详在变更物流到达国家时不影响整站国家码，帮单独存储
 */

import { STORAGE_GOODS_COUNTRYCODE } from 'js/variables';
import { getCountryCode } from 'js/core/currency';

export const goodsCountryCode = {
    async get() {
        let code = window.sessionStorage.getItem(STORAGE_GOODS_COUNTRYCODE);
        if (!code) {
            code = await getCountryCode();
        }
        return code;
    },

    set(countryCode = '') {
        if (countryCode !== '') {
            window.sessionStorage.setItem(STORAGE_GOODS_COUNTRYCODE, countryCode);
        }
    }
};
