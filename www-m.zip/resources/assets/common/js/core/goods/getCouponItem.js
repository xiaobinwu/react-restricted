/**
 * Created by Liu.Jun on 2018/7/27.
 */

import { serviceGetCouponItem } from 'js/service/common.js';
import layer from 'layer';
import { trans } from 'js/core/translate.js';
import brushCheck from 'component/brushCheck/brushCheck.js';
import appSdk from 'js/core/app.sdk.js';

const getCouponItem = ({
    templateCode, // 优惠券code
    couponResource = 7, // 优惠券渠道
    successTip = true, // 成功提示语
    erropPop = true, // 失败提示语
    tologin = true, // 是否需要登录
    loading = false, // 是否显示loading
    isCancel = false, // 是否需要取消上次的请求
}) => serviceGetCouponItem.http({
    data: {
        templateCode,
        couponResource,
    },
    loading,
    isCancel,
    erropPop,
}).then(async ({ status, msg, data }) => {
    if (status === 40373285) {
        const checkContent = await brushCheck({
            action: data.action,
            siteKey: data.siteKey,
            recaptchaVersion: data.recaptchaVersion
        });
        const res = await serviceGetCouponItem.http({
            data: {
                templateCode,
                couponResource,
                gbcaptcha: checkContent.gbcaptcha, // 防刷类型
                captchaType: checkContent.captchaType, // 防刷验证码
                recaptchaVersion: checkContent.recaptchaVersion // 谷歌防刷版本
            },
            loading,
            isCancel,
            erropPop,
        });
        if (res.status === 0) {
            if (successTip) {
                layer.msg(trans('cart.got_your_coupon'));
            }
        } else if (tologin && res.data.redirectUrl) {
            return appSdk.actLogin(res.data.redirectUrl);
        } else if (erropPop) {
            layer.msg(res.msg);
        }
        return res;
    }
    if (status === 0) {
        if (successTip) {
            layer.msg(trans('cart.got_your_coupon'));
        }
    } else if (tologin && data.redirectUrl) {
        return appSdk.actLogin(data.redirectUrl);
    } else if (erropPop) {
        layer.msg(msg);
    }
    return { status, msg, data };
});

export default getCouponItem;
