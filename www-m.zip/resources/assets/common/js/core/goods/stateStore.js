/**
 * StateStore 用于管理数据集合。主要用于当pool的所有参数都设置了值后，触发callback回调
 */
class StateStore {
    map = new Map();
    once = true;
    instance = null;
    init({
        pool = [],
        callback = null,
        once = true,
    } = {}) {
        pool.forEach((value) => {
            this.map.set(value, null);
        });
        this.once = once;
        this.callback = callback;
    }
    set(key, value) {
        if (this.map.has(key)) {
            this.map.set(key, value ? key : value);
            this.judge();
        }
    }
    get(key) {
        return this.map.get(key);
    }
    judge() {
        let isFull = true;
        for (const value of this.map.values()) {
            if (value === null) isFull = false;
        }
        if (isFull) this.triggle();
    }
    triggle() {
        if (this.once && !this.instance) {
            this.instance = this.callback;
            this.callback(this.map);
        } else {
            this.callback(this.map);
        }
    }
}

export default StateStore;
