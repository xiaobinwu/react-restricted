import { STORAGE_GOODS_VIEW_HISTORY } from 'js/variables';

/**
 * 用户浏览商品历史记录
 */
class GoodsViewHistory {
    // 获取历史记录 Array
    static get() {
        return JSON.parse(window.localStorage.getItem(STORAGE_GOODS_VIEW_HISTORY) || '[]');
    }
    /**
     * 设置单条历史记录
     * @param {*商品信息键值对} val@JSON
     */
    static set(val) {
        let isInIndex = 0;
        const data = GoodsViewHistory.get();

        // 判断是否浏览过
        const isIn = data.some((item, index) => {
            isInIndex = index;
            return val.sku === item.sku;
        });

        // 浏览过要清除，下一步将作为新值插入到起始
        if (isIn) {
            data.splice(isInIndex, 1);
        }

        // 在起始插入新值
        data.unshift(val);

        // 仅显示最近20条
        if (data.length > 20) {
            data.length = 20;
        }

        window.localStorage.setItem(STORAGE_GOODS_VIEW_HISTORY, JSON.stringify(data));
    }
    /**
     * 移除历史记录
     * @param {*指定移除下标数组，不指定则移除所有} removeIndex@Array
     */
    static remove(removeIndex = []) {
        if (!(removeIndex instanceof Array) || !removeIndex.length) {
            window.localStorage.removeItem(STORAGE_GOODS_VIEW_HISTORY);
        } else {
            const arrHistory = GoodsViewHistory.get();
            removeIndex.sort((a, b) => b - a);
            removeIndex.forEach((item) => {
                arrHistory.splice(item, 1);
            });
            window.localStorage.setItem(STORAGE_GOODS_VIEW_HISTORY, JSON.stringify(arrHistory));
        }
    }
}

export default GoodsViewHistory;
