/**
 * 商详评论入口ABtest
 */

import PubSub from 'pubsub-js';
import Cookies from 'js/utils/cookie';
import { reviewBtsABtest } from 'js/service/common.js';
import { getUserId } from 'js/core/user/getUserId.js';
import {
    COOKIE_GOODS_REVIEW_AB,
    STORAGE_BTS_REVIEWSENTRY,
    COOKIE_SEARCH_AB,
    STORAGE_BTS_SEARCHENTRY,
} from 'js/variables';

// 配置项
const CONFIG = {
    // AB分流超时时间（单位:毫秒）
    abShuntTimeout: 1500,

    // AB分流数据本地存在时间（单位：秒）
    abShuntLocalTime: 60 * 60,

    // AB分流cookie过期时间（单位：天）
    cookieExpires: 1 / 24,

    // 商详评论测试开关
    reviewsAbTestSwitch: +$('#js-hdReviewsAbTestSwitch').val() || 0,

    // 商详评论实验码
    plancodeForReview: 'review',

    // 搜索结果页测试开关
    searchAbTestSwitch: +$('#js-hdSearchAbTestSwitch').val() || 0,

    // 搜索结果页实验码
    plancodeForSearch: 'mkeyword',
};

const reviewsABTest = {
    init() {
        this.bindEvent();
    },

    bindEvent() {
        // // 捕获全站的a链接
        // $(document).on('click', 'a', (e) => {
        //     const href = $(e.currentTarget).attr('href');
        //     this.shuntHandle(href, e);
        // });


        // 主动先缓存数据
        PubSub.subscribe('nativeLoad', () => {
            reviewsABTest.shuntHandle('review');
            reviewsABTest.shuntHandle('search');
        });
    },

    /**
     * 分流处理
     * @param {链接} href
     * @param {触发事件对象} e
     */
    shuntHandle(pageType) {
        const self = this;
        // 初始化实验开关, 实验码, 存储KEY, COOKIE-KEY
        let switchTag;
        let plancode;
        let storageKey;
        let cookieKey;

        // 商详评论页
        if (pageType === 'review') {
            switchTag = CONFIG.reviewsAbTestSwitch;
            plancode = CONFIG.plancodeForReview;
            storageKey = STORAGE_BTS_REVIEWSENTRY;
            cookieKey = COOKIE_GOODS_REVIEW_AB;
        }

        // 搜索结果页
        if (pageType === 'search') {
            switchTag = CONFIG.searchAbTestSwitch;
            plancode = CONFIG.plancodeForSearch;
            storageKey = STORAGE_BTS_SEARCHENTRY;
            cookieKey = COOKIE_SEARCH_AB;
        }

        // 开启状态
        if (switchTag) {
            if (!Cookies.get(cookieKey)) { // cookie不存在
                recordData().catch((e) => {
                    console.log(e);
                });
            }
        } else { // 关闭状态

            // 清除本地存储bts数据
            window.sessionStorage.removeItem(storageKey);
            // 清除AB cookie
            Cookies.remove(cookieKey);
        }

        // 记录传递数据
        async function recordData() {
            // 等待AB分流数据
            const res = await self.getABData(plancode);

            if (res && res.policy) {
                // 分流结果存储，以备在分类及搜索页埋点上报使用
                window.sessionStorage.setItem(
                    storageKey,
                    JSON.stringify(res)
                );

                // 设置cookie，给分类及搜索页作cdn副本标识
                Cookies.set(cookieKey, res.policy, { expires: CONFIG.cookieExpires });
            }
        }
    },

    /**
     * ab分流
     * @param {试验码} plancode
     */
    async getABData(plancode) {
        const res = await reviewBtsABtest.http({
            data: JSON.stringify({
                appkey: 'GB',
                cookie: getUserId(),
                plancode,
                params: {},
            }),
            isCancel: false,
            timeout: CONFIG.abShuntTimeout,
            useLocalCache: CONFIG.abShuntLocalTime,
            headers: {
                'Content-Type': 'application/json'
            },
        });

        if (res && res.result) {
            return res.result;
        }

        throw new Error('bts data error !!');
    }
};


export { reviewsABTest };
