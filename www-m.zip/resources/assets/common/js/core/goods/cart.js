/**
 * Created by Liu.Jun on 2018/7/27.
 */

import layer from 'layer';
import PubSub from 'pubsub-js';

import { serviceCartNum, serviceAddToCart, serviceCartEasyBuy } from 'js/service/common.js';
import { trans } from 'js/core/translate.js';
import { postLocation } from 'js/utils';

const URI_CHECKOUT = `${GLOBAL.DOMAIN_ORDER}/checkout/index`; // 订单页面链接

/**
 * 添加到购物车
 * @param data(支持传一个data对象，表示只添加一个商品) [{
 *  goodsSn         string      Y   商品SKU
 *  qty             string      Y   商品数量
 *  warehouseCode   string      Y   仓库代码
 *  ===========================================
 *  goodsType       int         N   商品类型    0：正常  1：配件  2：赠品  3：加价购 4：买即赠赠品
 *  activityId      int         N   活动Id 不传默认为0
 *  mainGoodsSn     string      N   主商品SKU （配件商品传） 默认 空
 *  ciphertext      string      N   邮箱加密价 默认空
 *  source          int         N   来源  0-详情 1-列表
 *  }]
 *  }
 */
async function addToCart({
    goods,
    $eleCartNum = $('.js-cartNum'),
    callback,
} = {}) {
    // 购物车请求
    const res = await serviceAddToCart.http({
        loading: true,
        data: {
            goods: JSON.stringify(goods),
        },
    });
    if (res.status === 0) {
        PubSub.publish('sysUpdateUserStatus');
        PubSub.publish('sysAddToCartSuccess', res);
        // LCF-LANG
        layer.msg(`${trans('cart.add_to_cart_success')}!`);
        if (callback) {
            callback();
        }
    } else {
        PubSub.publish('sysAddToCartFail', res);
    }
    PubSub.publish('sysAddToCartAlways', res);
}


/**
 * 一键购 (buy now)
 * @param 参数同 addToCart 加入购物车
 */
async function buyNow({
    goods = [],
    callback = null,
    depData = {}
}) {
    try {
        // 购物车请求
        const res = await serviceCartEasyBuy.http({
            loading: true,
            data: {
                goods: JSON.stringify(goods),
            },
        });
        if (res.status === 0) {
            // depData商详页点击buyNow传参过来
            const depParam = { isQuickBuy: 1 };
            if (depData.isDeposit) {
                Object.assign(depParam, depData);
            }
            if (typeof callback === 'function') { // 商详paypal支付，是先调用buynow逻辑，无须直接跳结算页
                callback(res);
            } else {
                postLocation(URI_CHECKOUT, depParam);
            }
        } else {
            // LCF-LANG
            layer.msg(res.msg);
            PubSub.publish('sysBuyNowFail', res);
        }
        PubSub.publish('sysBuyNowAlways', res);
    } catch (error) {
        // error;
    }
}

async function updateSampleCart($eleCartNum) {
    try {
        const $ele = $eleCartNum || $('.js-cartNum');
        const res = await serviceCartNum.http({
            loading: false,
            errorPop: false,
        });
        const count = res.data.num;
        if ($ele.length) {
            $ele.css('visibility', count < 1 ? 'hidden' : 'visible').text(count);
        }
    } catch (error) {
        throw new Error(error);
    }
}

export default addToCart;

export {
    updateSampleCart,
    addToCart,
    buyNow
};
