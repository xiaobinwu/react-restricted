/**
 * Created by Liu.Jun on 2018/10/29.
 */

// 商详页收藏和取消逻辑

import layer from 'layer';
import { serviceCollectAdd, serviceGoodlistCollectRemove } from 'js/service/common.js';


const collectFlag = 'isCollection';
// 分发收藏=> 添加|取消
const collect = {
    collect($btnCollect) {
        if ($btnCollect.hasClass(collectFlag)) {
            this.collectRemove($btnCollect);
        } else {
            this.collectAdd($btnCollect);
        }
    },

    // 商品 - 取消收藏
    async collectRemove($btnCollect) {
        const { sku, warehouse } = $btnCollect[0].dataset;
        const res = await serviceGoodlistCollectRemove.http({
            data: {
                goodSn: sku,
                virCode: warehouse,
            },
        });
        if (+res.status === 0) {
            $btnCollect.removeClass(collectFlag);
        } else if (res.data && res.data.redirectUrl) {
            window.location.href = res.data.redirectUrl;
        } else {
            layer.msg(res.msg);
        }
    },

    // 商品 - 添加到收藏
    async collectAdd($btnCollect) {
        const { sku, warehouse } = $btnCollect[0].dataset;
        const res = await serviceCollectAdd.http({
            method: 'POST',
            loading: true,
            errorPop: false,
            data: {
                goods: [[sku, warehouse].join('_')]
            }
        });
        if (+res.status === 0) {
            $btnCollect.addClass(collectFlag);
        } else if (res.data && res.data.redirectUrl) {
            window.location.href = res.data.redirectUrl;
        } else {
            layer.msg(res.msg);
        }
    }
};

$(document).on('click', '.js-addFav', (e) => {
    const $this = $(e.currentTarget);
    collect.collect($this);
});

export default collect;

