import { sub, divide, multiply, updateCurrency } from 'js/core/currency';
import asyncPrice from 'js/core/asyncPrice';

function generateDiscount(eleGoodsPrice, asyncPriceNum, shopPriceClassName, callback) {
    const $eleGoodsPrice = $(eleGoodsPrice);
    const $eleShopPrice = $eleGoodsPrice.parent().find(shopPriceClassName);
    const isdiscount = $eleGoodsPrice.attr('data-isdiscount');
    if (isdiscount) return;
    $eleGoodsPrice.attr('data-isdiscount', 1);
    if ($eleShopPrice.length > 0) {
        const shopPrice = $eleShopPrice.data('currency');
        if (asyncPriceNum < shopPrice) {
            const discount = Math.round(multiply(divide(sub(shopPrice, asyncPriceNum), shopPrice), 100));
            if (discount > 0) {
                const descountStr = window.GLOBAL.LANG === 'tr' ?
                    `%<strong class="gbGoodsItem_per">${discount}</strong>` :
                    `<strong class="gbGoodsItem_per">${discount}</strong>%`;
                const str = `<span class="gbGoodsItem_discount">
                            <span class="gbGoodsItem_discountBox">
                                ${descountStr}
                                <i class="gbGoodsItem_off">OFF</i>
                            </span>
                        </span>`;
                $eleGoodsPrice.closest('.js-gbGoodsItem')[0].insertAdjacentHTML('afterbegin', str);
                callback({ $eleGoodsPrice, $eleShopPrice, discount });
            }
        }
    }
}

/** asyncPriceDiscount 获取设置异步价格，并且生成折扣标
 * @param elementLists 需要更新异步价格的数组或类数组元素
 * @param shopPriceClassName 店铺价格类名   售卖价格和店铺价格必须是同级
 * @param notAsyncPrice 是否是异步价格， 如果已经是实时价格，则不需要发请求
 * @param callback 生成折扣后的回调
 */
export default function asyncPriceDiscount({
    elementLists = [],
    shopPriceClassName = '',
    notAsyncPrice = false,
    callback = () => {},
} = {}) {
    if (!notAsyncPrice) {
        asyncPrice({
            elements: elementLists,
            callback(eleGoodsPrice, asyncPriceNum) {
                generateDiscount(eleGoodsPrice, asyncPriceNum, shopPriceClassName, callback);
            }
        });
    } else {
        // 不要传入一个 zepto 对象
        if ($.zepto.isZ(elementLists)) {
            console.warn('elementLists 不要传入一个zepto对象');
            elementLists = Array.prototype.slice.call(elementLists, 0);
        }

        updateCurrency();
        elementLists.forEach((eleGoodsPrice) => {
            const asyncPriceNum = eleGoodsPrice.dataset.asyncPrice;
            generateDiscount(eleGoodsPrice, asyncPriceNum, shopPriceClassName, callback);
        });
    }

}
