/**
 * 异步价格
 * Created by li Jiazhan on 2018/5/9
 */

import { serviceAsyncPrice } from 'js/service/common';
import { updateCurrency } from 'js/core/currency';

/**
 * 执行入口
 * @param context       容器（DomElement）
 * @param selector      选择器
 * @param elements      DOM元素列表（NoteList）
 * @param callback      回调函数，参数为 1、target(列表项) 2、price(实际价格)
 * @returns {Promise<*>}
 */
async function asyncPrice({
    context = document,
    selector = '.js-asyncPrice',
    elements = [],
    callback = () => {},
} = {}) {
    const availableElem = []; // 有效元素
    const queryData = []; // 请求参数集合
    // 以传入的元素列表优先级最高
    if (elements && elements.nodeType === 1) {
        elements = [elements];
    } else if (!elements || !elements.length || elements[0].nodeType !== 1) {
        elements = context.querySelectorAll(selector);
    }

    // 过滤无效元素
    [...elements].forEach((item) => {
        const param = item.dataset.asyncPrice;
        if (/\d+#\w+/.test(param)) {
            availableElem.push(item);
            queryData.push(param);
        }
    });

    if (availableElem.length > 0) {
        try {
            const res = await serviceAsyncPrice.http({
                errorPop: false,
                headers: {
                    'Content-Type': 'application/json'
                },
                transformRequest(bodyData, headers) {
                    // https://github.com/axios/axios/issues/382
                    const tempHeaders = headers;
                    delete tempHeaders.common['X-CSRF-TOKEN'];
                    delete tempHeaders.common['X-Requested-With'];
                    return bodyData;
                },
                data: JSON.stringify({
                    domain: GLOBAL.PIPELINE,
                    accessToken: GLOBAL.ACCESS_TOKEN,
                    version: GLOBAL.ESVERSION,
                    language: GLOBAL.LANG,
                    filters: [{
                        field: 'skuId',
                        values: queryData,
                    }],
                }),
            });

            availableElem.forEach((item, index) => {
                const { displayPrice } = res.data[index];
                if (displayPrice) {
                    item.dataset.currency = displayPrice;
                    callback(item, displayPrice);
                }
            });
        } catch (e) {
            console.error('asyncPrice get fail!');
        }
    }
    updateCurrency();

    // 清除价格加载样式
    [...context.querySelectorAll('.price-loading')].forEach((item) => {
        item.classList.remove('price-loading');
    });
}


export { asyncPrice };

export default asyncPrice;
