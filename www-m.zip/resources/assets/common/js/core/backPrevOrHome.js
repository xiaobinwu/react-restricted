import headerInfo from 'js/core/index/headerInfo.js';

/**
 * 返回上一级，如果上一级不是GB相关站点，则返回GB首页
 */
function backPrevOrHome() {
    const referrer = document.referrer || '';
    const referrerIsGearbest = /gearbest/.test(referrer);
    if (referrer && referrerIsGearbest) {
        window.history.back();
    } else {
        headerInfo.getCateIdHref();
    }
}

export default backPrevOrHome;
