import Cookies from 'js/utils/cookie';
import { getUrlQuery } from 'js/utils';

class AFF {
    static ACTION = 'getlkid';
    static SITE = 'gearbest';
    constructor(path = window.location.href) {
        this.path = path;
        this.getLkid();
    }
    getLkid() {
        this.query = getUrlQuery(this.path);
        let { vip: lkid } = this.query;
        const { cid, refid,  utm_source: utmSource , utm_campaign: utmCampaign, utm_medium: utmMedium } = this.query; //eslint-disable-line
        lkid = lkid || this.query.lkid;
        AFF.setCookie('reffer_channel', document.reffer);
        AFF.setCookie('landingUrl', window.location.href);

        const postbackid = cid || refid;

        if (lkid) {
            Cookies.remove('utm_source');
            Cookies.remove('utm_campaign');
            Cookies.remove('utm_medium');
            AFF.setCookie('postbackid', postbackid);

            AFF.setCookie('linkid', lkid);
            AFF.send({
                url: encodeURIComponent(window.location.href),
                webName: AFF.SITE,
                timestamp: (new Date()).getTime(),
                reffer: encodeURIComponent(document.referrer),
                lkid,
            });
        } else if (utmSource || utmCampaign || utmMedium) {
            Cookies.remove('linkid');
            AFF.setCookie('utm_source', utmSource);
            AFF.setCookie('utm_source', utmCampaign);
            AFF.setCookie('utm_source', utmMedium);
            AFF.setCookie('postbackid', postbackid);
        }
    }
    static setCookie(key, value) {
        if (value) {
            Cookies.set(key, value, { domain: window.GLOBAL.DOMAIN_COOKIE, expires: 30 });
        } else {
            Cookies.remove(key);
        }
    }
    static send(data) {
        const searchArray = [];
        Object.entries(data).forEach(([key, value]) => {
            searchArray.push(`${key}=${value}`);
        });
        const img = new Image(1, 1);
        img.src = `${GLOBAL.AFF_URL}/logsss/1.gif?${searchArray.join('&')}`;
    }
}

export default AFF;
