// fcm 配置
export const configDev = {
    config: {
        apiKey: 'AIzaSyBU5pwN_rcjJOFvoOF2A100Or2QRBMD1Q0',
        authDomain: 'gearbest-wap-test.firebaseapp.com',
        databaseURL: 'https://gearbest-wap-test.firebaseio.com',
        projectId: 'gearbest-wap-test',
        storageBucket: 'gearbest-wap-test.appspot.com',
        messagingSenderId: '180731699460'
    },
    key: 'BBjMgFtlENyqySPohxr3UqSAV2C0nvz6zI2rlTIOEmAbf2I4tvRK5OD6k1vwvJq0rqQiBc2rOvy1RMZEtBmIQDA',

};

export const configProd = {
    config: {
        apiKey: 'AIzaSyBOJDC4BfeaLtPCq9Unzqqvu-Ze1GZVMrA',
        authDomain: 'gearbest-wap-prod.firebaseapp.com',
        databaseURL: 'https://gearbest-wap-prod.firebaseio.com',
        projectId: 'gearbest-wap-prod',
        storageBucket: 'gearbest-wap-prod.appspot.com',
        messagingSenderId: '715087982294'
    },
    key: 'BLA0s5-WAQwmVSAye7598cbLkaHbBdNyCKyfPUvt6NiO5Dijm4bcVT7osOAG9F1xpIJptxxpMPcpKJwBLZSIKAo',
};
