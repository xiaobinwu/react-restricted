/**
 *  GUOXIU 2018-11-05 EDM 邮件推广引流 APP
 *
 */
import { getUrlQuery } from 'js/utils';

export default function () {
    const path = window.location.href;
    const pathname = window.location.pathname;
    const query = getUrlQuery(path);
    const { eo, utm_source: utmSource, utm_campaign: utmCampaign, utm_medium: utmMedium } = query; //eslint-disable-line
    const { sku } = query; //eslint-disable-line

    // 判断通过 EDM 进入的链接
    if (utmSource && utmSource === 'email_sys') {
        // 根据当前所处页面组装对应的参数
        const pageSign = window.dataLayer[0].PAGE;
        const linkParams = `utm_source=${utmSource || ''}&utm_campaign=${utmCampaign || ''}&utm_medium=${utmMedium || ''}&eo=${eo || ''}`;
        const appObj = {};

        switch (pageSign) {
        case 'index':
            appObj.page = 'home';
            appObj.link = `gearbest://home?${linkParams}`;
            break;
        case 'goods':
            appObj.page = 'product';
            if (window.gbmGoodsInfo && window.gbmGoodsInfo.webGoodsSn && window.gbmGoodsInfo.warehouseCode) {
                appObj.link = `gearbest://product?goods_web_sn=${
                    window.gbmGoodsInfo.webGoodsSn
                }&warehouse_code=${
                    window.gbmGoodsInfo.warehouseCode
                }&${linkParams}`;
            }
            break;
        case 'category':
            appObj.page = 'category';
            appObj.link = `gearbest://category?category_id=${
                pathname.match(/c_(\d*)/) ? pathname.match(/c_(\d*)/)[1] : ''
            }&category_name=${''}&${linkParams}`;
            break;
        case 'search':
            appObj.page = 'search';
            appObj.link = `gearbest://search?keyword=${
                pathname.match(/([\w-]*)-_gear/) ? pathname.match(/([\w-]*)-_gear/)[1] : ''
            }&${linkParams}`;
            break;
        default:
            appObj.page = '';
            appObj.link = '';
        }

        // 尝试打开app对应页面
        if (appObj.link) window.location.href = appObj.link;
    }
}
