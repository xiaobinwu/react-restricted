/**
 * Created by Liu.Jun on 2018/11/10.
 */

import appSdk from 'js/core/app.sdk.js';
import { versionCompar } from 'js/utils/appMethod.js';

const isAppHome = window.location.href.indexOf('env=appHome') > -1;
const isAndroid = String(appSdk.APP_OS).toLocaleLowerCase() === 'android';

// 顶部显示
if (isAppHome) {
    const promoAside = document.querySelector('.promoAside');
    if (promoAside && promoAside.style) promoAside.style.cssText = ';display:none;';
}

// 安卓webview 滚动兼容
function androidScroll(val) {
    window.local_obj.scrollable(val);
}

// 轮播位强制修复
export function appNavigation(swiperDom, needNav = false) {
    // 插入dom 节点
    if (isAppHome && isAndroid) {
        if (!versionCompar(appSdk.APP_VER, '4.1.0')) {
            // 低版本 兼容
            if (needNav) {
                $(swiperDom).append('<span class="app-swiper-button app-swiper-button-prev"><i class="icon-back_to_top"></i></span>' +
                    '<span class="app-swiper-button app-swiper-button-next"><i class="icon-back_to_top"></i></span>');
                return {
                    slidesPreGroup: 1,
                    navigation: {
                        nextEl: '.app-swiper-button-next',
                        prevEl: '.app-swiper-button-prev',
                    }
                };
            }
        }

        // 高版本兼容
        swiperDom.addEventListener('touchstart', () => {
            androidScroll(false);
        });
        swiperDom.addEventListener('touchend', () => {
            androidScroll(true);
        });
    }

    return {};
}
