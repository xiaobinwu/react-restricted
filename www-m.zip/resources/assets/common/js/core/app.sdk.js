/**
 * Created by Liu.Jun on 2018/3/10.
 */

/** APP内嵌浏览器右上角展示购物车和分享按钮
 <head>
 <meta name="share_title" content="分享的标题" />
 <meta name="share_desc" content="分享的描述" />
 <meta name="share_logo" content="分享的小图标图片地址URL" />
 <meta name="share_url" content="分享的链接URL" />
 <meta name="attach_cart" content="true" /> <!--表示是否展示APP右上角购物车按钮-->
 <meta name="attach_share" content="true" /> <!--表示是否展示APP右上角分享按钮-->
 </head>
 */

/**
 * actLogin         => 调用APP登录功能，未登录将前往APP登录页面
 * actPointChanged  => 通知APP刷新用户中心积分，amount是积分值
 * actCartChanged   => H5添加购物车后，通知APP刷新浏览器右上角购物车图标右上角角标数字
 * category         => 分类页
 * product          => 商品详情页
 * webview          => 直接打开页面
 * link             => 跳转链接
 * login            => 登陆页
 * register         => 注册页
 * account          => 个人中心页
 * home             => 首页
 * search           => 搜索页
 * brandWallDetail  => 品牌页
 * brandSales       => 品牌闪购页
 * coupon           => 个人中心coupon页
 * point            => 个人中心point页
 * livePerson       => livePerson客服
 * appClass         => 固定类
 * brandList        => 品牌列表页
 * store            => 店铺主页
 * buyTogether      => 凑单页
 * deals            => Gadget deals页面
 */

import cookie from 'js/utils/cookie';
import layer from 'layer';
import { trans } from 'js/core/translate';
import { toAppLink, updateVersionTips } from 'js/utils/appMethod.js';

const {
    DOMAIN_MAIN,
    DOMAIN_LOGIN,
    DOMAIN_USER,
    IS_APP,
} = window.GLOBAL;

let APP_VER = '';
let APP_OS = '';

if (IS_APP) {
    const cookies = cookie.get();
    APP_VER = cookies['app-version'];
    APP_OS = cookies['app-type'];
}

const route = {
    app: {
        actLogin() {
            to(APP_OS === 'ios' ? 'gearbest://login?callback=userinfo()' : 'GBWebAction://login?callback=userinfo()');
        },
        actPointChanged(amount) {
            to(`GBWebAction://pointChanged?amount=${amount}`);
        },
        actCartChanged() {
            to(APP_OS === 'ios' ? 'gearbest://cartChanged' : 'GBWebAction://cartChanged');
        },
        actUpdate() {
            to(APP_OS === 'ios' ?
                'gearbest://link?url=https://itunes.apple.com/cn/app/gearbest-shopping/id1131090631?l=en&mt=8' :
                'gearbest://link?url=https://play.google.com/store/apps/details?id=com.globalegrow.app.gearbest&referrer=utm_source');
        },
        category({ appId, appName }) { // id => 分类ID | name => 分类名称
            to(`gearbest://category?category_id=${appId}&category_name=${appName}`);
        },
        product({ appSku, appWcode }) { // sku => 商品sku | wcode => 仓库编码
            to(`gearbest://product?goods_web_sn=${appSku}&warehouse_code=${appWcode}`);
        },
        webview({ appTitle, appUrl }) { // title => 页面标题 | url => 页面链接
            to(`gearbest://webview?title=${appTitle}&url=${encodeURIComponent(appUrl)}`);
        },
        link({ appUrl }) { // url => 页面链接
            to(`gearbest://link?url=${appUrl}`);
        },
        login() {
            to('gearbest://login');
        },
        register() {
            to('gearbest://register');
        },
        bindphone() {
            to('gearbest://bindphone');
        },
        account() {
            to('gearbest://account');
        },
        home() {
            to('gearbest://home');
        },
        search({ appKey }) { // key => 搜索键值
            to(`gearbest://search?keyword=${appKey}`);
        },
        brandWallDetail({ appCode, appName }) { // code => 品牌编码 | name => 品牌名称
            to(`gearbest://brandWallDetail/?brandCode=${appCode}&brandName=${appName}`);
        },
        brandSales({ appTab = 0 } = {}) { // (tab = 0) => flash sale | (tab = 1) => brand sales
            to(`gearbest://brandSales/?tab=${appTab}`);
        },
        coupon() {
            to('gearbest://coupon/');
        },
        livePerson() {
            to('gearbest://livePerson/');
        },
        appClass({ appType }) { // (type = 1) => GADGET DEALS | (type = 2) => PRESALE | (type = 3) => NEWGADGETS
            to(`gearbest://class?type=${appType}`);
        },
        brandList() {
            to('gearbest://brandList');
        },
        store({ appId }) { // id => 店铺ID
            to(`gearbest://store?store_id=${appId}`);
        },
        buyTogether({ appId, appCode }) { // id => 活动ID | code => 仓库编码
            to(`gearbest://buyTogether?activityId=${appId}&warehouseCode=${appCode}`);
        },
        deals() {
            to('gearbest://home/?activity=GadgetDealsActivity');
        },
        custom({ appUrl }) { // url => 自定义页面链接
            to(appUrl);
        },
        point() {
            to('gearbest://point/');
        },
        reservations() {
            to('gearbest://myreservations');
        },
    },
    wap: {
        actLogin(url) {
            to(url || `${DOMAIN_LOGIN}/user/login`);
        },
        actPointChanged() {},
        actCartChanged() {},
        category({ appId, appName }) { // id => 分类ID | name => 分类名称
            to(`${DOMAIN_MAIN}/${appName.split(' ').join('-')}-c_${appId}/`);
        },
        product({ appSku, appWcode }) { // sku => 商品sku | wcode => 仓库编码
            to(`${DOMAIN_MAIN}/goods/pp_${appSku}.html?wid=${appWcode}`);
        },
        webview({ appTitle, appUrl }) { // title => 页面标题 | url => 页面链接
            to(appUrl);
        },
        link({ appUrl }) { // url => 页面链接
            to(appUrl);
        },
        login() {
            to(`${DOMAIN_LOGIN}/user/login`);
        },
        register() {
            to(`${DOMAIN_LOGIN}/user/register`);
        },
        bindphone() {
            // to(`${DOMAIN_LOGIN}/user/bindphone`);
        },
        account() {
            to(`${DOMAIN_USER}/user/index`);
        },
        home() {
            to(`${DOMAIN_MAIN}`);
        },
        search({ appKey }) { // key => 搜索键值
            to(`${DOMAIN_MAIN}/${encodeURIComponent(appKey)}-_gear`);
        },
        brandWallDetail({ appCode, appName }) {}, // code => 品牌编码 | name => 品牌名称
        brandSales({ appTab = 0 } = {}) {}, // (tab = 0) => flash sale | (tab = 1) => brand sales
        coupon() {},
        livePerson() {},
        appClass({ appType }) {}, // (type = 1) => GADGET DEALS | (type = 2) => PRESALE | (type = 3) => NEWGADGETS
        brandList() {},
        store({ appId }) {}, // id => 店铺ID
        buyTogether({ appId, appCode }) {}, // id => 活动ID | code => 仓库编码
        deals() {},
        custom() {},
        reservations() {},
    },
};

const appSdk = Object.assign({
    IS_APP,
    APP_VER,
    APP_OS,
}, route[IS_APP ? 'app' : 'wap']);

if (!window.hasDefineSdkEvent) {
    window.hasDefineSdkEvent = true;
    $(document).on('click', '[data-app]', (event) => {
        const { dataset, href, className } = event.currentTarget;
        const { iosVersion, androidVersion, app: linkName } = dataset;
        const toAppPage = () => {
            if (appSdk[linkName]) appSdk[linkName](dataset);
        };

        if (IS_APP) {
            event.preventDefault();
            if (iosVersion || androidVersion) {
                // APP判断版本号决定是否要提示升级
                updateVersionTips({
                    currentVersion: APP_VER, // 当前版本号
                    miniVersion: APP_OS === 'ios' ? iosVersion : androidVersion,
                    beforeVersion() {
                        layer.open({
                            title: trans('base.base_notice'),
                            content: trans('promotion.deposit_update_tips'),
                            btn: [trans('base.update'), trans('promotion.skip_anyway')],
                            yes() {
                                appSdk.actUpdate();
                            },
                            end() {
                                toAppPage();
                            }
                        });
                    },
                    afterVersion() {
                        toAppPage();
                    },
                });
            } else {
                toAppPage();
            }
        } else if (className.indexOf('js-toApp') && href) {
            // M版未安装app跳转
            toAppPage();
            toAppLink(() => {
                to(href);
            });
        }
    });
}

function to(url) {
    if (url) window.location.href = url;
}

export function setVersionTips({
    iosVersion = '', androidVersion = '', beforeVersion = () => {}, afterVersion = () => {}
}) {
    let isApp = false;
    if (IS_APP) {
        isApp = true;
        updateVersionTips({
            currentVersion: APP_VER, // 当前版本号
            miniVersion: APP_OS === 'ios' ? iosVersion : androidVersion,
            beforeVersion,
            afterVersion,
        });
    }
    return isApp;
}


export default appSdk;
