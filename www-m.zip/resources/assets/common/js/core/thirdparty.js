/**
 *  第三方推广链接访问统计
 *
 */
import Cookies from 'js/utils/cookie';
import { getUrlQuery } from 'js/utils';

const maxLength = 50;

class Thirdparty {
    static ACTION = 'setThirdpartyCookie';
    static SITE = 'gearbest';
    constructor(path = window.location.href) {
        this.path = path;
        this.getParams();
    }
    getParams() {
        this.query = getUrlQuery(this.path);
        // 判断参数中是否含有vip字段 赋值给lkid
        let { vip: lkid } = this.query;
        const { cid, refid,  utm_source: utmSource , utm_campaign: utmCampaign, utm_medium: utmMedium } = this.query; //eslint-disable-line
        const { utm_term, actionpay, sascid, admitad_uid, zanpid, awc, tduid: ftduid, click_id, offer_type, pl_type, af_id, pl_id, lmdsid, cjevent } = this.query; //eslint-disable-line
        lkid = lkid || this.query.lkid;
        let postbackid = cid ? { cid } : (refid ? { refid } : ''); // cid > refid

        // 遗留数据
        Thirdparty.setCookie('reffer_channel', document.reffer);
        Thirdparty.setCookie('landingUrl', window.location.href);

        // 第三方推广 cookie 排查业务逻辑
        if (lkid && window.top === window.self) { // 有lkid时 判断是否含有 utm_source || utm_campaign || utm_medium ,存在则值变为xxxxxx
            Thirdparty.setCookie('linkid', lkid);
            if (postbackid) {
                postbackid = JSON.stringify(postbackid);
            }

            Thirdparty.setCookie('postbackid', postbackid);

            if (Cookies.get('utm_source')) Thirdparty.setCookie('utm_source', 'xxxxxx');
            if (Cookies.get('utm_campaign')) Thirdparty.setCookie('utm_campaign', 'xxxxxx');
            if (Cookies.get('utm_medium')) Thirdparty.setCookie('utm_medium', 'xxxxxx');

            // 当url中有lkid时发送aff统计日志
            // Thirdparty.send({
            //     url: encodeURIComponent(window.location.href),
            //     web_id: Thirdparty.SITE,
            //     // timestamp: Math.round((new Date()).getTime() / 1000),
            //     timestamp: (new Date()).getTime() / 1000,
            //     reffer: encodeURIComponent(document.referrer.replace(/\?*$/, '')),
            //     lkid,
            //     od: Cookies.get('od')
            // });

            // 清除无效cookie
            const cookieObj = { utm_term, actionpay, sascid, admitad_uid, zanpid, awc, ftduid, click_id, offer_type, pl_type, af_id, pl_id, cjevent }; //eslint-disable-line
            for (const cookieItem in cookieObj) {
                if (Cookies.get(cookieItem)) {
                    Thirdparty.setCookie(cookieItem);
                }
            }
        } else if (utmSource || utmCampaign || utmMedium) { // 含有utm 之一 且没有lkid时清除 lkid
            Thirdparty.setCookie('linkid');
            Thirdparty.setCookie('postbackid');

            if (utmSource) {
                if (utmSource === 'admitad') { // Admitad 平台特殊处理
                    Thirdparty.setCookie('utm_source', 'admitad_uid');
                } else {
                    Thirdparty.setCookie('utm_source', utmSource);
                }
            } else {
                Thirdparty.setCookie('utm_source');
            }
            if (utmCampaign) {
                Thirdparty.setCookie('utm_campaign', utmCampaign);
            } else {
                Thirdparty.setCookie('utm_campaign');
            }
            if (utmMedium) {
                Thirdparty.setCookie('utm_medium', utmMedium);
            } else {
                Thirdparty.setCookie('utm_medium');
            }

            if (utmSource === 'lomadee') { // lomadee 平台特殊处理
                Thirdparty.setCookie('utm_campaign', lmdsid);
            }

            const cookieObj = { utm_term, actionpay, sascid, admitad_uid, zanpid, awc, ftduid, click_id, offer_type, pl_type, af_id, pl_id, cjevent }; //eslint-disable-line
            for (const cookieItem in cookieObj) {
                if (cookieObj[cookieItem]) {
                    if (cookieItem === 'cjevent') { // 针对 cjevent 特殊处理
                        if (utmSource === 'cj') {
                            Thirdparty.setCookie(cookieItem, cookieObj[cookieItem]);
                        } else if (Cookies.get('cjevent')) {
                            Thirdparty.setCookie(cookieItem);
                        }
                    } else {
                        Thirdparty.setCookie(cookieItem, cookieObj[cookieItem]);
                    }
                }
            }
        }
    }
    static setCookie(key, value) {
        if (value) {
            const newVal = String(value).length > maxLength ? String(value).substr(0, maxLength) : String(value);
            Cookies.set(key, newVal, { domain: window.GLOBAL.DOMAIN_COOKIE, expires: 30 });
        } else {
            Cookies.remove(key, { domain: window.GLOBAL.DOMAIN_COOKIE });
        }
    }
    // static send(data) {
    //     const searchArray = [];
    //     Object.entries(data).forEach(([key, value]) => {
    //         searchArray.push(`${key}=${value}`);
    //     });
    //     const img = new Image(1, 1);
    //     img.src = `${GLOBAL.AFF_URL}/logsss/1.gif?${searchArray.join('&')}`;
    // }
}

export default Thirdparty;
