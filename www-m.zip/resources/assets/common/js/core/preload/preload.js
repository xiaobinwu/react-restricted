/**
 * Created by Liu.Jun on 2018/11/12.
 */

import asyncTag from 'js/utils/asyncTag';

export default function (list) {
    if (list && Array.isArray(list)) {
        list.forEach((item) => {
            if (item.indexOf('.js') > -1) {
                // js
                asyncTag('link', {
                    rel: 'preload',
                    as: 'script',
                    href: item,
                });
            } else if (item.indexOf('.css') > -1) {
                asyncTag('link', {
                    rel: 'preload',
                    as: 'style',
                    href: item,
                });
            }
        });
    }
}
