import $ from 'zepto-webpack';
import 'js/lib/alloyfinger/zepto.event.extend';
import './test.css';
import '../star.js';

$('.js-star').star();
