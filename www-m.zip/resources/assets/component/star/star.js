/*
 * name: star（星星组件）
 * author: zaki
 * date: 2018/02/23
 */

import './star.css';

$.fn.star = function(fn) { // eslint-disable-line
    if (this.length === 0) return this;

    // 支持批量操作
    if (this.length > 1) {
        this.each(function() { // eslint-disable-line
            $(this).star();
        });
        return this;
    }

    const self = this;
    const isInput = self.is('input'); // 是否编辑控件

    // 确保grade的值有效
    let grade = isInput ? Number(self.val()) : Number(self.data('value')); // 评分
    grade = grade >= 0 && grade <= 5 ? grade : 0;

    // 初始化控件
    if (!self.hasClass('compStar-actived')) {
        self.addClass('compStar-actived');

        if (isInput) {

            self.css('display', 'none');
            self.shape = $(getHtmlCode(isInput, grade));
            self.after(self.shape);

            // 定义点击事件
            let activeStar = self.shape.find('.on-full'); // 上一个高亮的星星
            self.shape.on('tap', '.item', (e) => {
                const $this = $(e.currentTarget);
                activeStar.removeClass('on-full');
                activeStar = $this.addClass('on-full');
                self.val($this.data('index'));
                if (fn) fn();
            });
        } else {
            self.addClass('compStar');
            self.html(getHtmlCode(isInput, grade));
        }
    }

    return this;
};

function getHtmlCode(isInput, grade) {
    const int = Math.floor(grade);
    const decimal = grade % 1;

    let skin = 'on-full';
    let index = 0;

    if (isInput) {
        index = int;
    } else {
        index = int;
        if (decimal >= 0.25) index = int + 1;
        if (decimal >= 0.25 && decimal < 0.75) skin = 'on-half';
    }

    let starHtml = '';

    if (index === 0) starHtml += '<i class="on-full"></i>';
    for (let i = 1; i <= 5; i += 1) {
        starHtml += `<i class="item ${index === i ? skin : ''}" data-index="${i}"></i>`;
    }

    if (isInput) {
        return `<span class="compStar compStar-input">${starHtml}</span>`;
    }

    return `${starHtml}<em>${grade}</em>`;
}
