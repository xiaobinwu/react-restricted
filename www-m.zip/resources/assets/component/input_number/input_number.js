/*
 * name: input_number
 * author: luochongfei
 * date: 2017-12-06
 *
 ******************************** 《简介》 ********************************

    1. 组件无依赖（自身样式除外）
    2. IE8+
    3. 在html属性设置属性
    4. 在对象实例设置回调

 ******************************** 《html》 ********************************
    <!-- exp1 -->
    <span class="compInputNumber" id="js-yourElementId">
        <span class="compInputNumber_reduce">-</span>
        <span class="compInputNumber_inputWrap">
            <input type="text" value="1" step="1" min="1" max="50" class="compInputNumber_input">
        </span>
        <span class="compInputNumber_plus">+</span>
    </span>

    <!-- exp2 可对input设置禁用-->
    <span class="compInputNumber" id="js-yourElementId">
        <span class="compInputNumber_reduce">-</span>
        <span class="compInputNumber_inputWrap">
            <input type="text" value="1" step="1" min="1" max="50" class="compInputNumber_input" disabled>
        </span>
        <span class="compInputNumber_plus">+</span>
    </span>

 ******************************** 《调用方式》 ********************************

    demo1: new InputNumber('js-productCount');  // 普通初始化 (参数取行内属性或默认)
    demo2:
        new InputNumber('js-productCount', {
            // input值有变化时
            onChange(val) {
                console.log('有变化：', val);
            },
            // input值到最大时
            onMax(val) {
                console.log('最大了：', val);
            },
            // input值到最小时
            onMin(val) {
                console.log('最小了：', val);
            },
        });

 ******************************** 《input可配置属性》 ********************************
    data-min:           最小值
    data-max:           最大值
    data-step:          加减量
    data-hold-down:     是否开启长按（当要监听事件时不建议开启此项）
    disabled:           存在则禁用整个控件，反之启用整个控件

 ******************************** 《对象实例回调事件》 ********************************
    onChange(value):        input值有变化时
    onMax(value):           input值到最大时
    onMin(value):           input值到最小时

 ******************************** 《对象实例设定事件》 ********************************
    setDisable(Boolean):     设置是否禁用控件
    setMax(value):           设置最大值
    setMin(value):           设置最小值
 */

import './input_number.css';

class InputNumber {
    constructor(id, options) {
        if (typeof id === 'undefined') {
            return;
        }
        this.oParent = document.getElementById(id);
        if (!this.oParent) {
            return;
        }
        this.opt = options || {};
        this.dom();
        this.eleConfig();
        this.bindEvent();
    }
    dom() {
        this.oBtnPlus = this.oParent.querySelector('.compInputNumber_plus');
        this.oBtnReduce = this.oParent.querySelector('.compInputNumber_reduce');
        this.oInput = this.oParent.querySelector('.compInputNumber_input');
    }
    eleConfig() {
        function replaceNum(val, newVal) {
            return (!val || Number.isNaN(val)) ? newVal : val;
        }
        this.min = replaceNum(parseInt(this.oInput.getAttribute('min'), 10), 1);
        this.max = replaceNum(parseInt(this.oInput.getAttribute('max'), 10), 100);
        this.step = replaceNum(parseInt(this.oInput.getAttribute('step'), 10), 1);
        this.holdDown = this.oInput.getAttribute('hold-down') || false;
        this.disabled = this.oInput.disabled;
        this.setDisable(this.disabled);
    }
    bindEvent() {
        this.oBtnPlus.addEventListener('mousedown', () => {
            if (this.disabled) {
                return;
            }
            this.plus();
            this.onChange();
            this.hold(this.plus);
        }, false);
        this.oBtnPlus.addEventListener('mouseup', () => {
            this.clearTimer();
        });
        this.oBtnReduce.addEventListener('mousedown', () => {
            if (this.disabled) {
                return;
            }
            this.reduce();
            this.onChange();
            this.hold(this.reduce);
        }, false);
        this.oBtnReduce.addEventListener('mouseup', () => {
            this.clearTimer();
        });
        this.oInput.addEventListener('input', () => {
            this.input();
            this.onChange();
        }, false);
        // 兼容ie9
        this.oInput.addEventListener('propertychange', () => {
            this.input();
            this.onChange();
        }, false);
    }
    // 加
    plus() {
        let inputVal = parseInt(this.oInput.value, 10);
        inputVal += this.step;
        if (inputVal >= this.max) {
            this.oInput.value = this.max;
            this.onMax();
            return null;
        }
        this.oInput.value = inputVal;
        return null;
    }
    // 减
    reduce() {
        let inputVal = parseInt(this.oInput.value, 10);
        inputVal -= this.step;
        if (inputVal <= this.min) {
            this.oInput.value = this.min;
            this.onMin();
            return false;
        }
        this.oInput.value = inputVal;
        return null;
    }
    // 输入框输入时
    input() {
        const inputVal = parseInt(this.oInput.value, 10);
        if (Number.isNaN(inputVal)) {
            this.oInput.value = this.min;
        }

        if (inputVal >= this.max) {
            this.onMax();
            this.oInput.value = this.max;
        }

        if (inputVal <= this.min) {
            this.onMin();
            this.oInput.value = this.min;
        }
    }
    // 值变化时
    onChange() {
        if (this.opt.onChange) {
            this.opt.onChange.call(null, this.oInput.value);
        }
    }
    // 最小时
    onMin() {
        if (this.opt.onMin) {
            this.opt.onMin.call(null, this.oInput.value);
        }
    }
    // 最大时
    onMax() {
        if (this.opt.onMax) {
            this.opt.onMax.call(null, this.oInput.value);
        }
    }
    // 设置是否禁用
    setDisable(isDisable) {
        const dis = isDisable;
        this.oInput.disabled = dis;
        this.disabled = dis;
        if (dis) {
            this.oBtnPlus.setAttribute('disabled', '');
            this.oBtnReduce.setAttribute('disabled', '');
        } else {
            this.oBtnPlus.removeAttribute('disabled');
            this.oBtnReduce.removeAttribute('disabled');
        }
    }
    // 设置最小值
    setMin(value) {
        let val = value;
        if (!val || Number.isNaN(val)) {
            val = 1;
        }
        this.min = val;
        this.oInput.setAttribute('data-min', val);
        // 如若当前值小于最小值，让其等于要设置的最小值
        if (this.oInput.value < val) {
            this.oInput.value = val;
        }
    }
    // 设置最大值
    setMax(value) {
        let val = value;
        if (!val || Number.isNaN(val)) {
            val = 100;
        }
        this.max = val;
        this.oInput.setAttribute('data-max', val);
        // 如若当前值大于最大值，让其等于要设置的最大值
        if (this.oInput.value > val) {
            this.oInput.value = val;
        }
    }
    // 按住
    hold(fn) {
        if (!this.holdDown) {
            return;
        }
        this.plusTimer1 = setTimeout(() => {
            this.plusTimer2 = setInterval(() => {
                fn.call(this);
            }, 70);
        }, 600);
    }
    // 清除按住定时器
    clearTimer() {
        clearInterval(this.plusTimer1);
        clearInterval(this.plusTimer2);
    }
}
export default InputNumber;
