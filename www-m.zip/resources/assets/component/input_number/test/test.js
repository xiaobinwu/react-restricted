import '../input_number.css';
import InputNumber from '../input_number.js';

window.inputNumber1 = new InputNumber('js-inputNumber1');  // eslint-disable-line

window.inputNumber2 = new InputNumber('js-inputNumber2', {  // eslint-disable-line
    onChange(val) {
        console.log('有变化：', val);
    },
    onMax(val) {
        console.log('最大了：', val);
    },
    onMin(val) {
        console.log('最小了：', val);
    },
});
