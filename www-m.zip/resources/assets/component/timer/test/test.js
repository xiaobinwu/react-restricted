import $ from 'zepto-webpack';
import Timer from '../timer.js';

// 也可以直接这么写
const timer = new Timer('.js-timer1', {
    format: '{dd}:{hh}:{mm}:{ss}',
    interval: 'time',
});

// 如有后续任务，直接用 timer.add 方法添加任务，如
timer.add('.js-timer2', {
    format(gap) {
        return gap < 24 * 60 * 60 ? '{hh}:{mm}:{ss}' : '{d}D {h}H';
    },
    interval: (24 * 60 * 60) + 5,
});
