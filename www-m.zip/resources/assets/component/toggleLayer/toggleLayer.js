import $ from 'zepto-webpack';

function layerShow(element, selectClass) {
    const $ele = $(element);
    $ele.css('display', 'block');
    setTimeout(() => {
        $ele.addClass(selectClass);
    });
}

function layerHide(element, selectClass) {
    const $ele = $(element);
    $ele.css('display', 'none').removeClass(selectClass);
}

export {
    layerShow,
    layerHide
};
