/*
 * name: loader（列表加载器）
 * author: zaki
 * date: 2018/02/09
 */

import { debounce } from 'js/utils/index.js';

export default class Loader {
    constructor(params) {
        this.config = Object.assign({
            viewMore: null,
            auto: false,
            pullToRefresh: false,
            bufferArea: 500,
            data: $.noop,
            loadStart: $.noop,
            loadSuccess: $.noop
        }, params);

        this.loadStatus = 'ready';
        this.data = null;
        this.$viewMore = $(this.config.viewMore);
        this.update();

        if (this.$viewMore.length > 0) {
            this.$viewMore = this.$viewMore.eq(0);

            const $win = $(window);
            const screenHeight = $win.height();
            if (this.config.auto) {

                $win.on('scroll', () => {
                    const scrollTop = $win.scrollTop();
                    if (this.vmTop - scrollTop - screenHeight < this.config.bufferArea) {
                        this.load();
                    }

                });
            } else {
                this.$viewMore.on('tap', () => {
                    this.load();
                });
            }

            if (this.config.pullToRefresh) {

                const lazyUpdate = debounce(() => {
                    this.load();
                }, 500, true);

                $('.js-detailScroll').on('scroll', () => {
                    const scrollTop = $('.js-detailScroll').scrollTop();
                    if (scrollTop < 10) {
                        lazyUpdate();
                    }
                });
            }
        }
    }

    async load() {
        if (this.loadStatus === 'ready') {
            this.loadStatus = 'loading';
            this.config.loadStart();

            if (this.$viewMore.length > 0) {
                this.$viewMore.addClass('loading');
            }

            // 华丽的分割线--------------------
            this.data = await this.config.data();
            this.loadStatus = 'ready';
            this.config.loadSuccess(this.data);
            this.update();

            if (this.$viewMore.length > 0) {
                this.$viewMore.removeClass('loading');
            }
        }
    }

    update() {
        if (this.$viewMore.length > 0) {
            this.vmTop = this.$viewMore.offset().top;
        }
    }

    reset() {
        this.loadStatus = 'ready';
    }

    end() {
        this.loadStatus = 'end';
    }
}
