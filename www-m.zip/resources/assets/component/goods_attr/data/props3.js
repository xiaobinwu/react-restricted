/* eslint-disable */
export default {
    "attr_list": [
        {
            "name": "Color",
            "attr_id": "8",
            "list": [
                {
                    "prime": 2,
                    "attr_value": "WHITE",
                    "is_check": ""
                }
            ],
            "idx": 0
        }
    ],
        "goods_list": [
            {
                "product_number": 2,
                "goods_id": "571876",
                "goods_title": "Robotic Vacuum Cleaner Filter for Xiaomi",
                "goods_img": "https://gloimg.gbtcdn.com/gb/pdm-product-pic/Electronic/2016/11/10/goods-img/1500947952718157482.jpg",
                "stock": 1,
                "price": "12.21"
            }
        ],
            "prime_list": {
        "8": {
            "WHITE": 2
        }
    }
}