/**
 * 商品多规格属性切换 - jquery
 * luochongfei
 * 2018-01-24 15:20:29
 */
class GoodsAttr {
    constructor(options) {
        this.settings = {
            // 商品列表
            goodsList: [],
            // 商品列表每项中的乘积属性名称
            multiplyAttrName: '',

            // 此功能作用区块范围 - jquery对象
            jqWrap: $('#wrap'),
            // 高亮（选中）className
            activeCls: 'active',
            // 禁用className
            disabledCls: 'disabled',
            // 每个质数项的属性名
            primeAttr: 'data-prime',
            // 每个属性行的 className
            rowCls: 'attr-row',

            // 成功匹配到商品
            success(product) {
                console.info(product);
            },
            // 未匹配到商品
            fail() {
                console.warn('Unmatched goods');
            },

            // 禁用默认定义的事件
            disableDefaultEvent: false,

            // 接管事件
            defineEvent: null,
        };

        const settings = Object.assign(this.settings, options || {});

        // 乘积初始值
        this.multiplyResult = 1;

        // 所有属性行的集合
        this.jqRows = settings.jqWrap.find(`.${settings.rowCls}`);
        // 所有选项集合
        this.jqItems = settings.jqWrap.find(`[${settings.primeAttr}]`);

        this.run = true;

        // 未找到行或项
        if (this.jqRows.length === 0 || this.jqItems.length === 0) {
            // throw new Error('No line|items found');
            this.run = false;
        }

        // 未设置商品列表每项中的乘积属性名称
        if (settings.multiplyAttrName.length === 0) {
            // throw new Error('No data product property name set');
            this.run = false;
        }

        if (this.run) {
            // 绑定事件
            this.bindEvent();
        }
    }

    // 初始化
    init() {
        // 1.禁用所有非选中项
        this.disableAll();
        // 2.计算乘积
        this.multiplys();
        // 3.每行处理
        this.rowHandle();
    }

    // 绑定事件
    bindEvent() {
        const self = this;
        const { settings } = this;

        // 使用默认定义的事件
        if (!settings.disableDefaultEvent) {
            settings.jqWrap.on('click', `[${settings.primeAttr}]`, (e) => {
                const $this = $(e.currentTarget);
                if ($this.hasClass(settings.activeCls)) {
                    return false;
                }
                if ($this.hasClass(settings.disabledCls)) {
                    self.jqItems.removeClass(settings.activeCls);
                }
                self.jqItems.removeClass('cant-buy');
                $this.addClass(settings.activeCls).siblings().removeClass(settings.activeCls);
                // 状态初始化
                self.init();
                // 触发结果处理
                self.resultHandle();
                return false;
            });
        }

        // 接管事件
        if (typeof settings.defineEvent === 'function') {
            settings.defineEvent(self, settings);
        }
    }

    // 置灰所有未选中项
    disableAll() {
        const self = this;
        this.jqItems.each((index, item) => {
            if (!$(item).hasClass(self.activeCls)) {
                $(item).addClass(self.disabledCls);
            }
        });
    }

    // 选中项乘积
    multiplys() {
        this.multiplyResult = 1;

        const self = this;
        const { settings } = this;
        const $actives = settings.jqWrap.find(`.${settings.activeCls}`);

        $actives.each((index, item) => {
            self.multiplyResult *= $(item).attr(settings.primeAttr);
        });
    }

    // 每行属性处理
    rowHandle() {
        const self = this;
        const { settings } = this;

        // 遍历每一行
        self.jqRows.each((index, item) => {
            // 当前行所有项
            const $items = $(item).find(`[${settings.primeAttr}]`);
            // 当前行的质数
            const currentRowPrime = $(item).find(`.${settings.activeCls}`).attr(settings.primeAttr) || 1;
            // 其他所有行选中项的乘积
            const otherRowPrimeMultiply = self.multiplyResult / currentRowPrime;

            // 给当前行可用项去除禁用
            self.removeDisable($items, otherRowPrimeMultiply);

            // 给当前行不可购买项加标识
            self.setCantBuy($items, otherRowPrimeMultiply);
        });
    }

    // 设置不可购买样式
    setCantBuy($items, otherRowPrimeMultiply) {
        const { settings } = this;
        $items.each((index, item) => {
            const prime = $(item).attr(settings.primeAttr);
            const ji = prime * otherRowPrimeMultiply;
            const idx = this.multiplyIndex(ji);
            if (settings.goodsList[idx]) {
                if ('canBuy' in settings.goodsList[idx] && +settings.goodsList[idx].canBuy === 2) {
                    if (!$(item).hasClass('line1')) {
                        $(item).addClass('cant-buy');
                    }
                }
            }
        });
    }

    // 给一行可用项去除禁用
    removeDisable($items, otherRowPrimeMultiply) {
        const { settings } = this;
        $items.each((index, item) => {
            const prime = $(item).attr(settings.primeAttr);
            const can = settings.goodsList.some(element => element[settings.multiplyAttrName] % (prime * otherRowPrimeMultiply) === 0);

            if (can) {
                $(item).removeClass(settings.disabledCls);
            } else {
                $(item).addClass(settings.disabledCls);
            }
        });
    }

    // 选中项乘积对应商品列表中的索引 不存在返回-1
    multiplyIndex(prime) {
        const { settings } = this;
        // 计算乘积对应的key
        let idx = -1;
        const hasProduct = settings.goodsList.some((item, index) => {
            idx = index;
            return item[settings.multiplyAttrName] === prime;
        });
        return hasProduct ? idx : -1;
    }

    // 结果处理
    resultHandle() {
        const index = this.multiplyIndex(this.multiplyResult);
        const { settings } = this;

        if (index > -1) {
            const product = settings.goodsList[index];
            if (typeof settings.success === 'function') {
                settings.success(product);
            }
        } else if (typeof settings.fail === 'function') {
            settings.fail();
        }
    }
}

export default GoodsAttr;
