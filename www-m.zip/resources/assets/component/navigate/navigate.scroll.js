/**
 * 导航组件（滚动版）
 * @author  lijiazhan (lijiazhan@globalegrow.com)
 * @date    2018/01/19
 */

import IScroll from 'iscroll/iscroll-lite';
import { appNavigation } from 'js/core/app_polyfill/index.js';

import SuperClass from './navigate';

export default class Navigate extends SuperClass {
    constructor(selector, params) {
        // 修改传递到父类的default参数，防止在调用父类构造函数的时候先执行默认跳转
        const config = Object.assign({}, params);
        config.default = null;
        super(selector, config);

        this.screenWidth = $(window).width(); // 屏幕宽度
        this.innerWidth = this.nav.find('.inner').width(); // 导航内容宽度

        // 兼容 app
        appNavigation($(selector)[0]);

        // 初始化iscroll插件，这个插件有个 click: true 的配置项，这是个垃圾，千万不要用！
        this.iscroll = new IScroll(selector, {
            useTransform: true,
            useTransition: true,
            HWCompositing: true,
            disableMouse: true,
            disablePointer: false,
            disableTouch: false,
            scrollX: true,
            scrollY: false,
        });

        // 执行默认跳转
        if (typeof params.default === 'number') {
            this.goto(params.default);
        }
    }

    // 扩展父类的locate方法
    locate(index) {
        super.locate(index);
        let pos = ((this.screenWidth / 2) - (this.caseWidth / 2)) - this.caseLeft;
        if (pos > 0) pos = 0;
        else if (pos < this.screenWidth - this.innerWidth) pos = this.screenWidth - this.innerWidth;
        this.iscroll.scrollTo(pos, 0, 300);
    }

    // 刷新iscroll插件
    refresh() {
        if (this.iscroll) this.iscroll.refresh();
    }

    static SuperClass = SuperClass;
}
