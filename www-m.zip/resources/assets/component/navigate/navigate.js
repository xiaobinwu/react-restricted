/**
 * 导航组件
 * @author  lijiazhan (lijiazhan@globalegrow.com)
 * @date    2018/01/19
 */

export default class Navigate {
    constructor(selector, params) {
        this.nav = $(selector); // 容器
        this.cursor = this.nav.find('.cursor'); // 光标
        this.items = this.nav.find('.case'); // 子项
        this.activeCase = this.items.filter('.on'); // 上一次聚焦的子项

        // 配置
        this.config = Object.assign({
            default: null, // 默认选中的位置
            repeat: false, // 点击聚焦选项仍会触发事件
            onChange: $.noop, // 选中元素后的回调
            onClick: $.noop, // 点击选中的回调
        }, params);

        // 定义选中事件
        this.nav.on('tap', '.case', (e) => {
            this.clickBy(e.currentTarget);
            this.config.onClick(e.currentTarget);
        });

        // 默认跳转
        if (typeof this.config.default === 'number') {
            this.goto(this.config.default);
        }
    }

    clickBy(navItem) {
        const $target = $(navItem);
        if (this.config.repeat || !$target.hasClass('on')) {
            this.locate($target.index());
            this.config.onChange($target);
        }
    }

    locate(index) {
        if (this.index !== index) {
            this.index = index;

            const $case = this.items.eq(index);
            this.caseLeft = $case.position().left;
            this.caseWidth = $case.width();

            if (this.activeCase.length) this.activeCase.removeClass('on');
            this.activeCase = $case.addClass('on');

            this.cursor.css({
                left: this.caseLeft,
                width: this.caseWidth
            });
        }
    }

    // 主动触发跳转到指定位置
    goto(index) {
        this.clickBy(this.items.eq(index));
    }
}
