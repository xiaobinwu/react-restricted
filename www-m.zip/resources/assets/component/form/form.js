import './form.css';

/**
 * 输入框获得焦点时显示眼睛按钮
 * 输入框获得焦点且有文字时显示删除文字按钮
 * 输入框失去焦点时隐藏上述按钮
 */
$(document).on('focus', '.form_text', (e) => {
    const $this = $(e.currentTarget);
    const $suffix = $this.siblings('.form_suffix').eq(0);

    if ($suffix.hasClass('form_clear')) {
        if ($this.val() === '') $suffix.hide();
        else $suffix.show();

    } else if ($suffix.hasClass('form_eye')) {
        $suffix.show();
    }

}).on('blur', '.form_text', (e) => {
    const $this = $(e.currentTarget);
    $this.siblings('.form_clear, .form_eye').hide();

}).on('input', '.form_text', (e) => {
    const $this = $(e.currentTarget);
    const $suffix = $this.siblings('.form_suffix').eq(0);

    if ($suffix.hasClass('form_clear')) {
        if ($this.val() === '') $suffix.hide();
        else $suffix.show();
    }
});

/**
 * 删除输入框内的文字
 */
$(document).on('touchstart', '.form_clear', (e) => {
    const $input = $(e.currentTarget).siblings('.form_text');
    $input.val('').trigger('input');
    $input.focus();
    e.preventDefault();
}).on('touchend', '.form_clear', (e) => {
    e.preventDefault();
});

/**
 * 切换密码框可视状态
 */
$(document).on('touchstart', '.form_eye', (e) => {
    const $this = $(e.currentTarget);
    const $icon = $this.children().eq(0);
    const $input = $this.siblings('.form_text');

    if ($icon.hasClass('icon-hide_password')) {
        $icon.removeClass('icon-hide_password').addClass('icon-show_password');
        $input.attr('type', 'text');
    } else if ($icon.hasClass('icon-show_password')) {
        $icon.removeClass('icon-show_password').addClass('icon-hide_password');
        $input.attr('type', 'password');
    }

    $input.focus();
    e.preventDefault();
}).on('touchend', '.form_eye', (e) => {
    e.preventDefault();
});
