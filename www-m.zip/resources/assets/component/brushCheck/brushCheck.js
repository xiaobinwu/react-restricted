/**
 * 本组件是一个防刷调用组件，有两种防刷机制，主要采用recapchaV3，另一种是recapchaV2
 * 业务模块调用这个组件，promise会返回对象{ captchaType: '', // 防刷方式（captcha， recaptcha）
                                             gbcaptcha: '' // 返回的验证码
                                             recaptchaVersion: ''  // 谷歌验证的版本号
                                          }
 */
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';
import './brushCheck.css';
import brushRecaptchaV2 from './component/brush_reCaptchaV2'; // 谷歌  reCaptcha V2版本验证
import brushRecaptchaV3 from './component/brush_reCaptchaV3'; // 谷歌  reCaptcha V3版本验证

runtime.trans = trans;

export default ({ action, siteKey, recaptchaVersion = 'v3' }) => new Promise((resolve, reject) => {
    if (recaptchaVersion === 'v2') {
        brushRecaptchaV2({ resolve, reject, siteKey });
    } else {
        if (!siteKey) {
            reject(new Error('no google sitekey'));
            return;
        }
        brushRecaptchaV3({
            resolve, reject, siteKey, action
        });
    }
}).catch((error) => {
    console.log(error);
});
