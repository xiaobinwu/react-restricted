/**
 * 谷歌  reCaptcha V2版本验证
 */
import layer from 'layer';

export default ({ resolve, reject, siteKey }) => {
    const queryScriptV2 = document.getElementById('scriptReCaptchaV2');
    const { dpr = 1 } = document.querySelector('html').dataset;
    // 不需要重复加载recaptcha.js,添加<script>
    if (queryScriptV2) {
        const reCaptchaV2Layer = layer.open({
            type: 1,
            content: `<div id="recaptchaV2" class="scale${dpr}"></div>`,
            shadeClose: false, // 开启遮罩关闭
            area: ['364px', '138px'],
            className: 'layer_recaptchaV2'
        });
        const reCaptchaV2VerifyCallback = function reCaptchaV2VerifyCallback(token) {
            resolve({
                gbcaptcha: token,
                captchaType: 'recaptcha',
                recaptchaVersion: 'v2'
            });
            layer.close(reCaptchaV2Layer);
        };
        window.grecaptcha.render('recaptchaV2', {
            sitekey: siteKey,
            callback: reCaptchaV2VerifyCallback,
        });
    } else {
        const src = 'https://www.google.com/recaptcha/api.js?render=explicit&onload=onloadRecaptchaV2Callback';
        const script = document.createElement('script');
        script.src = src;
        script.type = 'text/javascript';
        script.setAttribute('id', 'scriptReCaptchaV2');
        script.onload = () => {
            const reCaptchaV2Layer = layer.open({
                type: 1,
                area: ['364px', '138px'],
                content: `<div id="recaptchaV2" class="scale${dpr}"></div>`,
                shadeClose: false, // 开启遮罩关闭
                className: 'layer_recaptchaV2'
            });
            const reCaptchaV2VerifyCallback = function reCaptchaV2VerifyCallback(token) {
                resolve({
                    gbcaptcha: token,
                    captchaType: 'recaptcha',
                    recaptchaVersion: 'v2'
                });
                layer.close(reCaptchaV2Layer);
            };
            window.onloadRecaptchaV2Callback = function onloadRecaptchaV2Callback() {
                window.grecaptcha.render('recaptchaV2', {
                    sitekey: siteKey,
                    callback: reCaptchaV2VerifyCallback,
                });
            };
        };
        script.onerror = () => {
            reject('key Error，download failed');
        };
        document.getElementsByTagName('head')[0].appendChild(script);
    }
};

