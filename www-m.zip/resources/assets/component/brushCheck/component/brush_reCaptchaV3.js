/**
 * 谷歌  reCaptcha V3版本验证
 */
export default ({ resolve, siteKey, action }) => {
    const queryScript = document.getElementById('scriptReCaptchaV3');
    if (queryScript) {
        window.grecaptcha.execute(siteKey, { action })
            .then((token) => {
                resolve({
                    captchaType: 'recaptcha',
                    gbcaptcha: token,
                    recaptchaVersion: 'v3'
                });
            });
    } else {
        const src = `https://www.google.com/recaptcha/api.js?render=${siteKey}`;
        const script = document.createElement('script');
        script.src = src;
        script.type = 'text/javascript';
        script.setAttribute('id', 'scriptReCaptchaV3');
        script.onload = () => {
            window.grecaptcha.ready(() => {
                window.grecaptcha.execute(siteKey, { action })
                    .then((token) => {
                        resolve({
                            captchaType: 'recaptcha',
                            gbcaptcha: token,
                            recaptchaVersion: 'v3'
                        });
                    });
            });
        };
        document.getElementsByTagName('head')[0].appendChild(script);
    }
};
