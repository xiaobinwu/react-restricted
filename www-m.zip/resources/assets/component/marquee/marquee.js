/*
 * name: marquee（跑马灯组件）
 * author: Jiazhan Li
 * date: 2018/05/28
 */

import './marquee.css';

const ANIMATION = ['animation', 'webkitAnimation', 'MozAnimation', 'msAnimation', 'OAnimation'];
const bodyStyle = document.body.style;
const animation = ANIMATION.find(item => bodyStyle[item] !== undefined);

/**
 * 单个跑马灯
 * @param {Element}  element     元素
 * @param {Number}   speed       移动一个像素的毫秒值（默认16）
 * @param {String}   direction   轮播方向（默认向上）：up, left
 */
class SingleMarquee {
    constructor({
        element = null,
        speed = 16,
        direction = 'up',
    } = {}) {
        this.element = element;
        this.speed = speed;
        this.child = element.children[0];
        this.isOverflow = false; // 内容是否溢出容器
        this.direction = direction;

        if (!this.child) return;

        if (this.direction === 'up') {
            this.parentSize = this.element.clientHeight;
            this.childSize = this.child.offsetHeight;
            this.animationName = 'marqueeV';
        } else if (this.direction === 'left') {
            this.parentSize = this.element.clientWidth;
            this.childSize = this.child.offsetWidth;
            this.animationName = 'marqueeH';
        }

        if (this.parentSize < this.childSize) {
            this.isOverflow = true;
            this.child.innerHTML = this.child.innerHTML.repeat(2);
            this.duration = (this.childSize * this.speed) / 1000;
            this.child.style[animation] = `${this.animationName} ${this.duration}s linear infinite`;
        }
    }

    /**
     * 开始动画
     */
    start() {
        if (this.isOverflow) {
            this.child.style[`${animation}PlayState`] = 'running';
        }
        return this;
    }

    /**
     * 停止动画
     */
    stop() {
        if (this.isOverflow) {
            this.child.style[`${animation}PlayState`] = 'paused';
        }
        return this;
    }
}

/**
 * Marquee类
 * @param {String}  selector    元素选择器
 * @param {Number}  speed       移动一个像素的毫秒值（默认16）
 * @param {String}  direction   轮播方向（默认向上）：up, left
 */
class Marquee {
    constructor({
        selector = 'js-marquee',
        speed = 16,
        direction = 'up',
    } = {}) {
        try {
            if (selector.nodeType === 1) this.elements = [selector];
            else if (typeof selector === 'string') this.elements = document.querySelectorAll(selector);
            else if (selector.length > 0) this.elements = selector;
            else this.elements = [];
        } catch (e) {
            console.error('Marquee选择器错误');
            this.elements = [];
        }

        this.list = [];

        [...this.elements].forEach((element) => {
            this.list.push(new SingleMarquee({
                element,
                speed,
                direction,
            }));
        });
    }

    start() {
        return this.list.map(item => item.start());
    }

    stop() {
        return this.list.map(item => item.stop());
    }
}

export default Marquee;
