import './test.css';
import Marquee from '../marquee.js';

new Marquee({
    selector: '.js-marquee',
});
