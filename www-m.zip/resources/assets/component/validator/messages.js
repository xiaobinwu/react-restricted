import { trans } from 'js/core/translate.js';

export default {
    ERROR_EQUAL: trans('base.error_equal'), // 输入不一致
    ERROR_PASSWORD: trans('base.error_password'), // 密码格式错误
    ERROR_REGEX: trans('base.error_regex'), // 正则表达式匹配失败
    ERROR_REQUIRED: trans('base.error_required'), // 请输入字段
};
