// 格式化输出
export function getErrorMsg(ruleName, done, message) {
    if (!done()) {
        const errorMsg = {};
        errorMsg[ruleName] = message;
        return errorMsg;
    }
    return false;
}

// 验证值是否为空
export function isEmpty(value) {
    const emptyValue = '';
    return value.length === 0 || value.every(item => item === emptyValue);
}
