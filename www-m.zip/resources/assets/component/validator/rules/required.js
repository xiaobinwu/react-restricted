/**
 * 验证必填项
 */
import { getErrorMsg, isEmpty } from '../util';
import MSG from '../messages.js';

export default function required(value, param) {
    return getErrorMsg(
        'required',
        () => !param || !isEmpty(value),
        MSG.ERROR_REQUIRED
    );
}
