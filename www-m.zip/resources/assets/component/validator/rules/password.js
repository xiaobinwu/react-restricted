/**
 * 正则表达式匹配校验
 */
import { getErrorMsg, isEmpty } from '../util';
import MSG from '../messages.js';

const regPasswordArr = [
    /(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}/,
    /(?=.*[0-9])(?=.*[~`@#$%^&*\-_=+|\\?/()<>[\]{}",.;'!]).{8,30}/,
    /(?=.*[a-zA-Z])(?=.*[~`@#$%^&*\-_=+|\\?/()<>[\]{}",.;'!]).{8,30}/,
];

export default function password(value, param) {
    return getErrorMsg('password', () => {
        if (isEmpty(value) || !param) return true; // 仅对非空字段有效
        return regPasswordArr.some(item => item.test(value));
    }, MSG.ERROR_PASSWORD);
}
