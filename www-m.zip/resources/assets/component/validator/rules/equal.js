/**
 * 比较两个输入框的值是否相等（一般用在检测密码输入是否一致）
 */
import { getErrorMsg } from '../util';
import MSG from '../messages.js';

export default function equal(value, param) {
    return getErrorMsg('equal', () => {
        const compareWith = document.getElementById(param);
        const compareValue = compareWith && compareWith.value;
        return compareValue === value[0];
    }, MSG.ERROR_EQUAL);
}
