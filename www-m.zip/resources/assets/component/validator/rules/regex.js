/**
 * 正则表达式匹配校验
 */
import { getErrorMsg, isEmpty } from '../util';
import MSG from '../messages.js';

export default function (value, param) {
    return getErrorMsg('regex', () => {
        if (isEmpty(value)) return true; // 仅对非空字段有效
        const reg = param instanceof RegExp ? param : new RegExp(String(param));
        return value.every(item => reg.test(item));
    }, MSG.ERROR_REGEX);
}
