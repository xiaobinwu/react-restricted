import required from './required';
import regex from './regex';
import password from './password';
import equal from './equal';

export default {
    required,
    regex,
    password,
    equal,
};
