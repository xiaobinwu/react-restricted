/*
 * name: validator（表单验证组件，暂时依赖zepto、jquery）
 * author: zaki
 * date: 2018/03/21
 */

import validators from './rules/';

export default class Validator {
    constructor({
        container = document, // 容器
        autoValid = true, // 是否自动触发验证（全局）
        position = false, // 是否自动定位
        rules = {}, // 验证规则
        messages = {}, // 验证提示
        errorPlacement = null // 表单交互
    }) {
        this.container = $(container);
        this.rules = rules;
        this.messages = messages;
        this.elements = this.getElements();
        this.autoValid = autoValid;
        this.position = position;
        this.errorPlacement = errorPlacement || Validator.errorPlacement;

        if (autoValid) {
            this.bindEvent();
        }
    }

    // 需要验证的表单元素
    getElements(keys) {
        const elems = {};

        keys = keys || Object.keys(this.rules);
        keys.forEach((key) => {
            const target = this.getElementByName(key);
            if (target.length > 0) {
                elems[key] = target;
            }
        });
        return elems;
    }

    // 返回单个DOM元素
    getElementByName(name) {
        let target = this.container.find(`[name="${name}"]`);
        if (target.length === 0) {
            target = this.container.find(`#${name}`);
        }
        return target;
    }

    // 序列化表单参数
    serialize(include) {
        const result = {};
        for (const key in this.elements) {
            result[key] = Validator.getFieldValue(this.elements[key]);
        }
        if (include && include.length) {
            include.forEach((item) => {
                if (!(item in this.elements)) {
                    result[item] = Validator.getFieldValue(this.getElementByName(item));
                }
            });
        }
        return result;
    }

    // 事件绑定
    bindEvent() {
        for (const key in this.elements) {
            const $elem = this.elements[key];
            const nodeName = $elem[0].nodeName.toLocaleLowerCase();
            const fieldType = $elem[0].type;
            const handle = () => {
                if (this.autoValid) {
                    const source = {};
                    source[key] = Validator.getFieldValue($elem);
                    this.validate(source);
                }
            };

            let triggerEvent = 'blur'; // 触发验证的事件

            if (nodeName === 'select' || fieldType === 'radio' || fieldType === 'checkbox') {
                triggerEvent = 'change';
            }

            $elem.on(triggerEvent, handle);
        }
    }

    // 全局验证
    valid() {
        return this.validate(this.serialize());
    }

    // 验证器
    validate(source) {
        let isPassValid = true; // 是否通过验证
        const errorTargets = []; // 存放错误元素

        Object.keys(source).forEach((fieldName) => {
            const errors = [];
            const value = source[fieldName];
            const rule = this.rules[fieldName];

            if (typeof rule === 'object') {
                Object.keys(rule).forEach((ruleName) => {
                    const err = validators[ruleName](value, rule[ruleName]);
                    if (err) {
                        let message = err[ruleName];
                        if (this.messages[fieldName] && this.messages[fieldName][ruleName]) {
                            message = this.messages[fieldName][ruleName];
                        }
                        if (ruleName === 'required') {
                            errors.unshift(message); // 必填项错误置顶
                        } else {
                            errors.push(message);
                        }
                        isPassValid = false;
                    }
                });
            }

            // 需开启自动定位功能
            if (this.position && errors.length > 0) {
                errorTargets.push(this.elements[fieldName]);
            }

            setTimeout(() => {
                this.errorPlacement(errors, this.elements[fieldName]);
            }, 0);
        });

        // 需开启自动定位功能
        if (this.position && errorTargets.length > 0) {
            const offsetTops = errorTargets.map(item => $(item).eq(0).offset().top).sort((a, b) => a - b);
            $(window).scrollTop(offsetTops[0] - window.lib.flexible.rem2px(2.5));
        }

        return isPassValid;
    }

    // 获取表单元素值
    static getFieldValue(target) {
        const result = [];
        target.each((i, elem) => {
            if (['radio', 'checkbox'].indexOf(elem.type) < 0 ||
                elem.checked) {
                result.push(elem.value);
            }
        });
        return result;
    }

    static errorPlacement(errors, elem) {
        const $formGroup = $(elem).eq(0).closest('.form_group');
        let $msg = $formGroup.find('.form_msg');

        if (errors.length > 0) {
            // 错误
            $formGroup.addClass('error');

            if ($msg.length === 0) {
                $msg = $('<p class="form_msg form_msg-error"></p>');
                $formGroup.append($msg);
            }

            if ($msg.hasClass('form_msg-error')) {
                $msg.show();
            } else if (!$msg.data('original')) {
                $msg.data('original', $msg.html()); // 储存原文本信息
            }

            $msg.html(errors[0]);
        } else {
            // 正确
            $formGroup.removeClass('error');

            if ($msg.length > 0) {
                if ($msg.hasClass('form_msg-error')) {
                    $msg.html('').hide();
                } else if ($msg.data('original')) {
                    $msg.html($msg.data('original')); // 还原文本信息
                }
            }
        }
    }
}
