### borderStopScroll 简介
*GB缺少一个阻止背景滚动的方法，具体细节是当弹框的滚动到达顶点、底部或者没有滚动的时候，继续沿着某一状态滚动将不再触发滚动。
代码精简易读。borderStopScroll思想是：当到达临界点比如底部的时候，再往上滑动，这时应该阻止用户的滚动，达到阻止页面背景滚动的效果

### Useage
borderStopScroll({
	wrapEle: document.querySelector('.layBox')
});
