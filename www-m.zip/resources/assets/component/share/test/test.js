import '../share.css';
import Share from '../share.js';

Share.facebook({
    appId: 900125666754558,
    selector: '.js-fb',
    url: 'http://www.w3cschool.com',
});
Share.twitter({
    desc: 'test',
    url: 'http://www.baidu.com',
    selector: '.js-tw',
});
Share.vk({
    selector: '.js-vk',
});

Share.google({
    selector: '.js-google',
    url: 'http://www.baidu.com',
    title: 'test',
});

Share.reddit({
    selector: '.js-reddit',
    url: 'http://www.baidu.com',
    title: 'test',
});

Share.pinterest({
    selector: '.js-pinterest',
    url: 'http://www.baidu.com',
    title: 'test',
});
