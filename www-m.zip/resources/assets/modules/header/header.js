import PubSub from 'pubsub-js';
import indexHeaderInfo from 'js/core/index/headerInfo';
import headerCateNav from 'modules/header/header_cate_nav';
import { reviewsABTest } from 'js/core/goods/reviewsABtest.js';

import './header.css';

PubSub.publish('sysUpdateUserStatus');

// 跳转首页馆区
indexHeaderInfo.toIndexLink();

reviewsABTest.init();

// 下一个事件队列执行
setTimeout(() => {
    headerCateNav.init();
}, 0);
