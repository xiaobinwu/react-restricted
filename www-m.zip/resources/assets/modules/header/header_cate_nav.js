import { layerShow, layerHide } from 'component/toggleLayer/toggleLayer';
import 'modules/footer/footer.js';
import borderStopScroll from 'component/borderStopScroll';

import './header_cate_nav.css';

const headerCateNav = {
    loadCateLazyImg: () => {
        const $lazyLoad = $('.js-cateBlock').find('.js-lazyload');
        $lazyLoad.each((index, value) => {
            const $value = $(value);
            $value.attr('src', $value.data('lazy')).removeClass('js-lazyload');
        });
    },
    hideCate: () => {
        layerHide('.js-cate_NavBox', 'moveCateTrans');
    },
    init() {
        this.bindEvent();
    },
    bindEvent() {
        // 分类栏
        let firstTimeCate = 0;
        const cateBlockEle = document.querySelector('.js-cateBlock');
        if (!cateBlockEle) return;
        // 滚动
        borderStopScroll({
            wrapEle: cateBlockEle,
            live: true
        });

        // SEO首页侧边栏隐藏一级文案和跳转链接
        const seoCateItem = [...document.querySelectorAll('.js-seoCateItem')];
        if (seoCateItem.length) {
            seoCateItem.forEach((element) => {
                const dataset = element.dataset;
                element.setAttribute('href', dataset.seoHref);
                element.innerHTML = dataset.seoName;
            });
        }

        $('.js-cateBtn').click((e) => {
            layerShow('.js-cate_NavBox', 'moveCateTrans');
            if (!firstTimeCate) {
                firstTimeCate = 1;
                this.loadCateLazyImg();
            }
            e.preventDefault();
        });
        $('.js-cateClose').click(() => {
            this.hideCate();
        });
        $('.cateAside').click((e) => {
            e.stopPropagation();
        });
        $('.js-cate_NavBox').click(() => {
            this.hideCate();
        });
        // 分类列表展开
        $('.js-cateItem').click((e) => {
            const $this = $(e.currentTarget);
            if ($this.hasClass('icon-fold')) {
                $this.removeClass('icon-fold').addClass('icon-unfold')
                    .closest('.cateItem').removeClass('active');
            } else {
                $('.js-cateItem.icon-fold').removeClass('icon-fold').addClass('icon-unfold');
                $this.removeClass('icon-unfold').addClass('icon-fold')
                    .closest('.cateItem').addClass('active')
                    .siblings()
                    .removeClass('active');
            }
        });

    }
};

export default headerCateNav;
