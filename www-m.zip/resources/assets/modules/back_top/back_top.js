/**
 * Created by Jiazhan Li on 2018/10/24.
 */

import StateBuffer from 'js/utils/StateBuffer.js';

class BackTop {
    static html = `<div class="floatButton">
                        <div class="floatButton-inner">
                            <a href="javascript:;" class="floatButton-item js-gotoTop"><i class="icon-back_to_top"></i></a>
                        </div>
                    </div>`

    static actived = false;

    constructor({
        selector = '.js-gotoTop',
        onShow = null,
        onHide = null,
    } = {}) {
        const $win = $(window);
        const $selector = $(selector);
        const stateCache = new StateBuffer();

        if (!BackTop.actived && $selector.length) {
            BackTop.actived = true; // 防止二次定义事件

            // 点击置顶
            $(document).on('click', selector, () => {
                $win.scrollTop(0);
            });

            // 窗口滚动触发显示隐藏
            $win.on('scroll', () => {
                const scrTop = $win.scrollTop();

                if (scrTop >= $win.height()) {
                    stateCache.on('show', () => {
                        if (typeof onShow === 'function') {
                            onShow($selector);
                        } else {
                            $selector.addClass('show');
                        }
                    });
                } else {
                    stateCache.on('hide', () => {
                        if (typeof onHide === 'function') {
                            onHide($selector);
                        } else {
                            $selector.removeClass('show');
                        }
                    });
                }
            });
        }
    }
}

export default BackTop;
