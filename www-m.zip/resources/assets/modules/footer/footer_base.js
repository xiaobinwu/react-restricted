import Cookies from 'js/utils/cookie';
import PubSub from 'pubsub-js';
import layer from 'layer';
import { serviceSubscribe } from 'js/service/common';
import { COOKIE_LANG, COOKIE_FULL_SITE } from 'js/variables';
import { getUrlQuery } from 'js/utils';
import { trans } from 'js/core/translate.js';
import { getCurrency } from 'js/core/currency';
import { regEmail } from 'js/utils/regExp';


async function renderExchangeRate() {
    const select = document.querySelectorAll('.js-formExchange');
    const DEFAULT_CURRENCY = (await getCurrency()).currencyCode;
    if (window.EXCHANGERATE) {
        if (select.length) {
            [...select].forEach((value) => {
                const frameElement = document.createDocumentFragment();
                window.EXCHANGERATE.forEach((item) => {
                    const option = new Option(
                        item.currencySign + item.currencyCode,
                        item.currencyCode, item.currencyCode,
                        DEFAULT_CURRENCY === item.currencyCode
                    );
                    option.dataset.sign = item.currencySign;
                    option.dataset.name = item.currencyName;
                    frameElement.appendChild(option);
                });
                value.appendChild(frameElement);
            });
        }
    }
}

function eventExchangeRate() {
    $('.js-formExchange').on('change', (e) => {
        const select = e.target;
        PubSub.publish('sysUpdateCurrency', {
            currencyCode: select.value,
        });
    });
}

function eventLanguage() {
    $('.js-formLanguage').on('change', (e) => {
        const select = e.target;
        const selectedOption = select.options[select.selectedIndex];
        const currentUrl = window.location.href;
        const currentUrlQuery = getUrlQuery(currentUrl);

        if (currentUrl.indexOf('/checkout/index') > -1) {
            Cookies.set(COOKIE_LANG, selectedOption.value);
            window.location.reload();
        } else {
            currentUrlQuery.lang = selectedOption.value;
            const toUrl = `${window.location.origin}${window.location.pathname}?${
                Object.entries(currentUrlQuery).map(([key, value]) => `${key}=${value}`).join('&')
            }`;
            window.location.href = toUrl;

            // Cookies.set(COOKIE_LANG, selectedOption.dataset.link);
            // window.location.reload(true);
            // window.location.href = selectedOption.dataset.link;
        }
    });
}

async function submitFun(e) {
    const $input = $(e.currentTarget).closest('.js-subscribe').find('input');
    e.preventDefault();
    if ($input.val()) {
        if (!regEmail.test($input.val().trim())) { // 邮箱正则验证
            return layer.msg(trans('login.sign_email_error'));
        }
        const res = await serviceSubscribe.http({
            data: {
                email: $input.val(),
                subscribedSource: 2,
            },
        });
        if (res && res.msg) {
            layer.msg(res.msg);
        }
    }
    return undefined;
}

function eventSubscribe() {
    $('.js-subscribe').on('submit', (e) => {
        submitFun(e);
    }).on('click', 'button, .siteFooter_subBtn', (e) => {
        e.preventDefault();
        submitFun(e);
    });
}
renderExchangeRate();
eventExchangeRate();
eventLanguage();
eventSubscribe();

const $formGroupInputEu = $('.js-formGroup-input-eu');
$formGroupInputEu.on('focus', (e) => {
    $('.js-gbform_input_tipsBox').show();
});
$formGroupInputEu.on('blur', (e) => {
    setTimeout(() => {
        $('.js-gbform_input_tipsBox').hide();
    }, 200);
});

// 跳转pc站
$('.js-fullSite').click(() => {
    Cookies.set(COOKIE_FULL_SITE, true, { expires: 1 });
    const url = window.location.href;
    const pathName = window.location.pathname + window.location.search + window.location.hash;
    const reg = /:\/\/(m(-?))/g;
    if (!reg.test(url)) {
        return false;
    }
    const newUrl = url.replace(reg, ($0, $1, $2) => {
        if ($2) {
            return $0.replace('m-', '');
        }
        return $0.replace('m', 'www');
    });
    // 产品给出的pc端不存在的路径
    const noExistArr = ['/messenger-lucky-draw.html', '/m-accessories-id-170238102.html?virWhCode=1433363&categoryId=12315', '/money-bag.html'];
    const index = noExistArr.findIndex(value => value === pathName);
    if (index >= 0) {
        const host = newUrl.replace(noExistArr[index], '');
        window.location.href = host;
        return false;
    }
    window.location.href = newUrl;
    return true;
});
