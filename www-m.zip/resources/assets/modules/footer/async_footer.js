// 解决css同时被同步、异步 webpack 单一module 被css提取后导致丢失或者不能正常提取问题

import './footer_base.js';
import './async_footer.css';
