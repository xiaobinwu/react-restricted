// https://eslint.org/docs/user-guide/configuring

module.exports = {
    root: true,
    parserOptions: {
        parser: 'babel-eslint'
    },
    env: {
        browser: true
    },
    extends: [
        // https://github.com/vuejs/eslint-plugin-vue#priority-a-essential-error-prevention
        // consider switching to `plugin:vue/strongly-recommended` or `plugin:vue/recommended` for stricter rules.
        'plugin:vue/recommended',
        // http://fenpm.hqygou.com/#/detail/@gb/eslint-config-gb,
        '@gb/eslint-config-gb'
    ],
    // required to lint *.vue files
    plugins: ['vue'],
    // add your custom rules here
    rules: {
        'prettier/prettier': 'off',
        // allow async-await
        'generator-star-spacing': 'off',
        // allow debugger during development
        'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'off',
        // 设置 vue 文件中 script 代码顶级缩进 1 倍 indent
        'vue/script-indent': [
            "error",
            4,
            {
                'baseIndent': 1
            }
        ],
        // 修改vue/html中缩进
        'vue/html-indent': [
            'error',
            4
        ],
        // 关闭属性换行
        'vue/max-attributes-per-line': 'off',
        // 关闭HTML标签自闭合
        'vue/html-self-closing': 'off'
    },
    overrides: [
        {
            // 关闭 eslint 对 vue 文件的缩进检查
            files: ['*.vue'],
            rules: {
                indent: 'off'
            }
        }
    ]
};
