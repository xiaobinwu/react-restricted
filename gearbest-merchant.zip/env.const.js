/**
 * 环境常量配置文件 - 提供给 /config/env.const.js 使用
 */
module.exports = {
    // 开发环境
    dev: {
        CDN_IMG: '/',
        UPLOAD_LOGO: 'http://pdm.hqygou.com',
        UPLOAD_REVIEW_IMG: 'http://uploads.review.com.a.php5.egomsl.com/review/upload',
        GEARBEST_URL: 'https://www.gearbest.net',
    },

    // 测试环境
    test: {
        CDN_IMG: '/',
        UPLOAD_LOGO: 'http://pdm.hqygou.com',
        UPLOAD_REVIEW_IMG: 'http://uploads.review.com.a.php5.egomsl.com/review/upload',
        GEARBEST_URL: 'https://www.gearbest.net',
    },

    // 生产环境
    prod: {
        CDN_IMG: 'https://i.gbsimg.com/',
        UPLOAD_LOGO: 'http://pdm.gw-ec.com',
        UPLOAD_REVIEW_IMG: 'https://uploads.reuew.com/review/upload',
        GEARBEST_URL: 'https://www.gearbest.com',
    },

    // 预发布环境
    stag: {
        CDN_IMG: 'https://i.gbsimg.com/',
        UPLOAD_LOGO: 'http://pdm.gw-ec.com',
        UPLOAD_REVIEW_IMG: 'https://uploads.reuew.com/review/upload',
        GEARBEST_URL: 'https://www.gearbest.com',
    }
};
