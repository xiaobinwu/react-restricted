import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    {
        path: '/order/lists',
        name: 'OrderLists',
        meta: {
            title: 'base.order.list'
        },
        component: () => asyncComponent(import('@order/views/OrderLists.vue'))
    },
    {
        path: '/order/details/:orderSn',
        name: 'OrderDetails',
        meta: {
            title: 'base.order.details',
            focusMenu: '/order/lists'
        },
        component: () => asyncComponent(import('@order/views/OrderDetails.vue'))
    },
    {
        path: '/order/deliveryregistered/:orderSn',
        name: 'OrderDeliveryregistered',
        meta: {
            title: 'base.order.deliveryRegistered',
            focusMenu: '/order/lists'
        },
        component: () => asyncComponent(import('@order/views/OrderDeliveryregistered.vue'))
    },
    {
        path: '/order/aftersale',
        name: 'OrderAftersale',
        meta: {
            title: 'base.order.aftersale'
        },
        component: () => asyncComponent(import('@order/views/OrderAftersale.vue'))
    },
    {
        path: '/order/aftersaledetail/:id',
        name: 'OrderAftersaledetail',
        meta: {
            title: 'base.order.aftersaledetail',
            focusMenu: '/order/aftersale'
        },
        component: () => asyncComponent(import('@order/views/OrderAftersaledetail.vue'))
    },
    {
        path: '/order/accountability',
        name: 'OrderAccountability',
        meta: {
            title: '判责列表'
        },
        component: () => asyncComponent(import('@order/views/OrderAccountability.vue'))
    },
    {
        path: '/order/accountability/:serviceNo',
        name: 'OrderAccountabilityDetail',
        meta: {
            title: '判责详情',
            focusMenu: '/order/accountability'
        },
        component: () => asyncComponent(import('@order/views/OrderAccountabilityDetail.vue'))
    }
];
