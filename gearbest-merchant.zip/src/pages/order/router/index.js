import router from '@/assets/js/router';
import Layout from '@/components/Layout';
import children from './routes';

// Layout 为布局组件
// 所有的视图挂在它下面
const routes = [
    {
        path: '/',
        component: Layout,
        redirect: '/order/lists',
        meta: {
            requireAuth: true
        },
        children
    }
];

export default router({ routes });
