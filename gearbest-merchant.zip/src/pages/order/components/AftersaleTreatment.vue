<template>
    <div>
        <!-- 售后操作 -->
        <div :class="$style.content">
            <div :class="$style.item">
                <span :class="[$style.lable, $style.bi]">{{ $t('order.aftersale.module.makeAchoice') }}:</span>
                <div :class="$style.itemConent">
                    <el-radio-group v-model="isAccept" @change="reason = ''">
                        <el-radio label="1">{{ $t('order.aftersale.module.accept') }}</el-radio>
                        <el-radio label="2">{{ $t('order.aftersale.module.refuse') }}</el-radio>
                    </el-radio-group>
                </div>
            </div>
            <div
                v-if="isAccept == 1"
                :class="$style.item">
                <span :class="[$style.lable, $style.bi]">{{ $t('order.aftersale.module.solution') }}:</span>
                <div :class="$style.itemConent">
                    <el-radio-group v-model="isFullAmount">
                        <el-radio
                            v-show="refundVisible.all"
                            label="1">
                            {{ $t('order.aftersale.module.fullRefund') }}
                        </el-radio>
                        <el-radio
                            v-show="refundVisible.part"
                            :disabled="types == 1"
                            label="2">
                            {{ $t('order.aftersale.module.partialRefund') }}
                        </el-radio>
                    </el-radio-group>
                </div>
            </div>
            <div
                v-if="isAccept == 1"
                :class="$style.item">
                <span :class="[$style.lable, $style.bi, $style.line40]">{{ $t('order.aftersale.module.refundAmount') }}:</span>
                <div :class="$style.itemConent">
                    <el-input
                        v-model.trim="refund"
                        :disabled="isFullAmount == 1"
                        :placeholder="`$${maxAmount || 0}`"
                        type="number"
                        @blur="checkAmount"></el-input>
                </div>
            </div>
            <div :class="$style.item">
                <span :class="[$style.lable, $style.bi, $style.line40]">{{ $t('order.aftersale.module.causeExplanation') }}:</span>
                <div :class="$style.itemConent">
                    <el-select v-model="reason" :placeholder="$t('order.aftersale.module.pleaseChoose')">
                        <el-option v-for="(value, key) in reasonOptions" :key="key" :label="value" :value="key" />
                    </el-select>
                </div>
            </div>
        </div>
        <!-- 退货地址 -->
        <h3 v-if="types == 1 && isAccept == 1" :class="$style.title">{{ $t('order.aftersale.module.addressTitle') }}</h3>
        <div v-if="types == 1 && isAccept == 1" :class="$style.content">
            <div :class="$style.item">
                <span :class="[$style.lable, $style.line40]">{{ $t('order.aftersale.module.returnAddress') }}:</span>
                <div :class="$style.itemConent">
                    <el-select
                        v-model="returnAddress.value"
                        :placeholder="$t('order.aftersale.module.pleaseChoose')"
                        @change="addressChange()">
                        <el-option
                            v-for="item in returnAddress.option"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                        </el-option>
                    </el-select>
                </div>
                <div :class="$style.itemExtra">
                    <el-button type="text" @click="toEditAddress">{{ $t('order.aftersale.module.editAddress') }}</el-button>
                </div>
            </div>
            <div
                v-for="(item, key) in returnAddress.info"
                v-show="key == 'name' || key == 'telephone' || key == 'address1' || key == 'postcode'"
                :class="$style.item"
                :key="key">
                <span :class="[$style.lable, $style.gray]">
                    {{ key == 'name' ? `${$t('order.aftersale.module.addressName')}:` : '' }}
                    {{ key == 'telephone' ? `${$t('order.aftersale.module.addressPhone')}:` : '' }}
                    {{ key == 'address1' ? `${$t('order.aftersale.module.address1')}:` : '' }}
                    {{ key == 'postcode' ? `${$t('order.aftersale.module.addressPostcode')}:` : '' }}
                </span>
                <div :class="$style.itemConent">{{ item }}</div>
            </div>
        </div>
        <!-- 按钮 -->
        <div align="center">
            <el-button @click="$emit('cancleEvent')">{{ $t('order.aftersale.module.cancle') }}</el-button>
            <el-button type="primary" @click="confrim()">{{ $t('order.aftersale.module.confirm') }}</el-button>
        </div>
    </div>
</template>

<script>
    import {
        getLogisticsList,
        getSmsStatus
    } from '../services/aftersale.js';

    export default {
        name: 'AftersaleTreatment',
        props: {
            types: {
                type: [Number, String],
                default: 1 // 10:退款 20:退货退款
            },
            isShip: {
                type: String,
                default: '' // 1. 未发货 2. 已发货
            },
            maxAmount: {
                type: [Number, String],
                default: 0, // 最大退款金额
            }
        },
        data() {
            return {
                isAccept: '1',
                isFullAmount: '1',
                refund: '',
                reason: '',
                // 退货地址
                returnAddress: {
                    value: '',
                    option: [],
                    info: {},
                    dataList: [],
                },
                // 状态数据映射
                smsState: {
                    salesRejectReason: {}, // 拒绝原因
                    middleSalesReason: {}, // 接受原因 - 退款
                    afterSalesReason: {}, // 接受原因 - 退货退款
                },
            };
        },
        computed: {
            reasonOptions() {
                const {
                    salesRejectReason,
                    middleSalesReason,
                    afterSalesReason
                } = this.smsState;

                if (
                    this.types === '2'
                    && this.isShip === '2'
                    && this.isAccept === '1'
                ) {
                    return afterSalesReason;
                }
                if (
                    this.types === '2'
                    && this.isShip === '2'
                    && this.isAccept === '2'
                ) {
                    return salesRejectReason;
                }
                if (
                    this.types === '2'
                    && this.isShip === '1'
                    && this.isAccept === '1'
                ) {
                    return middleSalesReason;
                }
                if (
                    this.types === '1'
                    && this.isShip === '2'
                    && this.isAccept === '2'
                ) {
                    return salesRejectReason;
                }
                if (
                    this.types === '1'
                    && this.isShip === '2'
                    && this.isAccept === '1'
                ) {
                    return afterSalesReason;
                }

                return null;
            },
            refundVisible() {
                // 已发货 && 退款
                if (this.isShip === '2' && this.types === '2') {
                    return {
                        all: true,
                        part: true
                    };
                }
                // 未发货 && 退款
                if (this.isShip === '1' && this.types === '2') {
                    return {
                        all: true,
                        part: false
                    };
                }
                // 已发货 && 退货退款
                if (this.isShip === '2' && this.types === '1') {
                    return {
                        all: true,
                        part: false
                    };
                }

                return {
                    all: false,
                    part: false
                };
            }
        },
        watch: {
            isFullAmount(val) {
                if (val === '1') {
                    this.refund = this.maxAmount;
                }
            }
        },
        created() {
            const vm = this;
            // 请求 SMS 状态映射表
            getSmsStatus.http().then((smsData) => {
                const { status, data } = smsData;
                if (status === 0) {
                    vm.smsState.salesRejectReason = data.SalesRejectReason;
                    vm.smsState.middleSalesReason = data.MiddleSalesReason;
                    vm.smsState.afterSalesReason = data.AfterSalesReason;
                }
            });
            if (+vm.types === 1) { // 退货退款
                vm.getAddressList();
            }
        },
        methods: {
            createdAddressObj(data) {
                return {
                    name: data.contacts, // 地址姓名
                    telephone: data.telephone, // 电话
                    address1: data.address_detail, // 详细地址
                    postcode: data.postcode, // 邮编
                    country: data.country, // 国家
                    province: data.province, // 省份
                    city: data.city, // 城市
                };
            },
            checkAmount() {
                if (Number.parseFloat(this.refund) > this.maxAmount) {
                    this.refund = +this.maxAmount;
                }
            },
            addressChange() {
                const vm = this;
                let info = {};
                vm.returnAddress.dataList.forEach((item) => {
                    if (item.id === vm.returnAddress.value) info = vm.createdAddressObj(item);
                });
                Object.assign(vm.returnAddress.info, info);
            },
            confrim() {
                const vm = this;
                let msg = '';
                if (!vm.reason) msg = vm.$t('order.aftersale.module.chooseReason');
                if (+vm.isFullAmount === 2 && !vm.refund) msg = vm.$t('order.aftersale.module.enterRefund');
                if (msg) {
                    vm.$message({
                        type: 'error',
                        message: msg
                    });
                    return;
                }
                let sendData = {
                    action: +vm.isAccept === 1 ? 'receive' : 'reject',
                    reason_id: vm.reason,
                    reason: vm.reasonOptions[vm.reason],
                    service_type: vm.types,
                    receive_type: vm.isFullAmount,
                    receive_amount: (+vm.isFullAmount === 1 ? vm.maxAmount : vm.refund) || 0
                };
                if (+vm.types === 1) {
                    sendData = Object.assign(sendData, {
                        contact_user_name: vm.returnAddress.info.name || '',
                        phone: vm.returnAddress.info.telephone || '',
                        country: vm.returnAddress.info.country || '',
                        province: vm.returnAddress.info.province || '',
                        city: vm.returnAddress.info.city || '',
                        post_code: vm.returnAddress.info.postcode || '',
                        address1: vm.returnAddress.info.address1 || '',
                    });
                }
                vm.$emit('confrimEvent', sendData);
            },
            // ----- 请求数据 -----
            async getAddressList() {
                const vm = this;
                const { status, data } = await getLogisticsList.http();
                const optArr = [];
                let info = {};
                if (status === 0) {
                    vm.returnAddress.dataList = data;
                    vm.returnAddress.dataList.forEach((item) => {
                        optArr.push({
                            label: item.name,
                            value: item.id
                        });
                        if (item.is_default) {
                            vm.returnAddress.value = item.id;
                            info = vm.createdAddressObj(item);
                        }
                    });
                    if (!vm.returnAddress.value) {
                        vm.returnAddress.value = vm.returnAddress.dataList[0].id;
                        info = vm.createdAddressObj(vm.returnAddress.dataList[0]);
                    }
                }
                Object.assign(vm.returnAddress.option, optArr);
                Object.assign(vm.returnAddress.info, info);
            },

            toEditAddress() {
                this.$router.gbPush('/logistics/returnAddressList');
            }
        }
    };
</script>

<style module>
    .title {
        padding-left: 30px;
        line-height: 40px;
        font-size: 16px;
    }

    .content {
        margin-bottom: 25px;
    }

    .item {
        line-height: 26px;
        margin-bottom: 10px;
        color: #000;
    }

    .lable {
        display: inline-block;
        vertical-align: top;
        text-align: right;
        margin-right: 15px;
        width: 130px;
    }

    .bi::before {
        content: '*';
        color: #FF0000;
        margin-right: 5px;
    }

    .line40 {
        line-height: 40px;
    }

    .gray {
        color: #999999;
    }

    .itemConent {
        display: inline-block;
        vertical-align: top;
    }

    .itemExtra {
        display: inline-block;
        vertical-align: top;
        line-height: 40px;
        margin-left: 15px;
    }
</style>
