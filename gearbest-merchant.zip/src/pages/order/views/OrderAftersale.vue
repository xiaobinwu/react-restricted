<template>
    <div :class="$style.container">
        <div :class="$style.topTip">
            <i :class="['el-icon-warning', $style.tipIcon]"></i>
            <span>{{ $t('order.aftersale.topTip', [5]) }}</span>
        </div>
        <!-- 顶部筛选 -->
        <el-form ref="elForm" :model="formOption" inline label-suffix="：">
            <el-form-item :label="`${$t('order.aftersale.serviceNumber')}`" prop="serviceNo">
                <el-input
                    v-model="formOption.serviceNo"
                    placeholder="">
                </el-input>
            </el-form-item>
            <el-form-item :label="`${$t('order.aftersale.orderNumber')}`" prop="orderNo">
                <el-input
                    v-model="formOption.orderNo"
                    placeholder="">
                </el-input>
            </el-form-item>
            <el-form-item :label="`${$t('order.aftersale.initiationTime')}`" prop="screenTime">
                <el-date-picker
                    v-model="formOption.screenTime"
                    :start-placeholder="$t('order.aftersale.selectDate')"
                    :end-placeholder="$t('order.aftersale.selectDate')"
                    :range-separator="$t('order.aftersale.to')"
                    value-format="timestamp"
                    type="datetimerange"
                    align="center">
                </el-date-picker>
            </el-form-item>
            <el-form-item :label="`${$t('order.aftersale.serviceType')}`" prop="serviceType">
                <el-select
                    v-model="formOption.serviceType"
                    placeholder="">
                    <el-option :label="$t('order.aftersale.all')" value="" />
                    <el-option v-for="(value, key) in serviceTypeOption" :key="key" :label="value" :value="key" />
                </el-select>
            </el-form-item>
            <el-form-item :label="`${$t('order.aftersale.processingState')}`" prop="serviceStatus">
                <el-select
                    v-model="formOption.serviceStatus"
                    placeholder="">
                    <el-option :label="$t('order.aftersale.all')" value="" />
                    <el-option v-for="(value, key) in serviceStatusOption" :key="key" :label="value" :value="key" />
                </el-select>
            </el-form-item>
            <el-form-item :label="`${$t('order.aftersale.goodsNumber')}`" prop="sku">
                <el-input
                    v-model="formOption.sku"
                    placeholder="">
                </el-input>
            </el-form-item>
            <el-form-item label="">
                <el-button @click="cleanInput('elForm')">{{ $t('order.aftersale.reset') }}</el-button>
                <el-button type="primary" @click="setRoute()">{{ $t('order.aftersale.search') }}</el-button>
            </el-form-item>
        </el-form>
        <!-- 列表 -->
        <el-table
            :class="$style.listBox"
            :data="listData"
            stripe>
            <el-table-column
                :label="$t('order.aftersale.serviceOrderInformation')"
                prop="service_no"
                width="130"
                align="center">
                <template slot-scope="scope">
                    <div :class="$style.serviceNo">
                        <div :class="$style.serviceNoItem">
                            <p :class="$style.serviceNoItemTitle">{{ $t('order.aftersale.serviceNumber') }}:</p>
                            <router-link :to="{ name: 'OrderAftersaledetail', params: { id: scope.row.service_no } }">
                                {{ scope.row.service_no }}
                            </router-link>
                        </div>
                        <div :class="$style.serviceNoItem">
                            <p :class="$style.serviceNoItemTitle">{{ $t('order.aftersale.initiationTime') }}:</p>
                            <p>{{ $dateFormat(scope.row.adddate) }}</p>
                        </div>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.goodsInfo')"
                prop="sku"
                width="220"
                align="center">
                <template slot-scope="scope">
                    <div :class="$style.goodsMsg">
                        <img :src="scope.row.goods_image" :class="$style.goodsMsgImg" />
                        <div :class="$style.goodsMsgWrap">
                            <a :href="scope.row.goods_url" :class="$style.goodsMsgTitle" :title="scope.row.goods_title">
                                {{ scope.row.goods_title }}
                            </a>
                            <p>{{ `${$t('order.aftersale.number')}: ${scope.row.sku}` }}</p>
                        </div>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.orderNumber')"
                prop="order_no"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.buyer')"
                prop="buyer_user_name"
                align="center">
                <template slot-scope="scope">
                    <router-link :to="{ name: 'OrderAftersaledetail', params: { id: scope.row.service_no, anchor: true, jump: 1 } }">
                        {{ scope.row.buyer_user_name }}
                    </router-link>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.refundAmount')"
                prop="refund_amount"
                align="center">
                <template slot-scope="scope">
                    {{ `$${scope.row.refund_amount || '0.00'}` }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.actualRefundAmount')"
                prop="real_refund_amount"
                align="center">
                <template slot-scope="scope">
                    {{ `$${scope.row.real_refund_amount || '0.00'}` }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.processingState')"
                prop="service_status"
                align="center">
                <template slot-scope="scope">
                    {{ smsState.serviceStatus[scope.row.service_status] || scope.row.service_status }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.serviceType')"
                prop="service_type"
                align="center">
                <template slot-scope="scope">
                    {{ smsState.serviceType[scope.row.service_type] || scope.row.service_type }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('order.aftersale.option')"
                align="center">
                <template slot-scope="scope">
                    <!-- 待处理时展示 -->
                    <a
                        v-if="scope.row.service_status == 30"
                        href="javascript:;"
                        @click="aftersaleAlert(scope.row)">
                        {{ $t('order.aftersale.treatment') }}
                    </a>
                    <!-- 退货退款 且 待退货 -->
                    <a
                        v-if="scope.row.service_type == 1 && scope.row.service_status == 45"
                        href="javascript:;"
                        @click="confirmReceipt(scope.row)">
                        {{ $t('order.aftersale.confirmRseceipt') }}
                    </a>
                    <router-link
                        :to="{
                            name: 'OrderAftersaledetail',
                            params: { id: scope.row.service_no, anchor: true }}">
                        {{ $t('order.aftersale.viewDetails') }}
                    </router-link>
                </template>
            </el-table-column>
        </el-table>
        <!-- 翻页 -->
        <el-row>
            <el-col :span="6">
                <div :class="$style.listOrderAmount">
                    {{ `${$t('order.aftersale.currentOrderAmount')}: $${listOrderTotalAmount}` }}
                </div>
            </el-col>
            <el-col :span="18">
                <el-pagination
                    :current-page="currentPage"
                    :total="total"
                    :page-sizes="pageSizes"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    align="right"
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange">
                </el-pagination>
            </el-col>
        </el-row>
        <!-- 弹窗 -->
        <el-dialog
            :visible.sync="isAftersaleAlert"
            :title="$t('order.aftersale.treatment')"
            width="540px">
            <aftersale-treatment
                v-if="isAftersaleAlert"
                :types="afterSaleTreatment.type"
                :is-ship="afterSaleTreatment.isShip"
                :max-amount="afterSaleTreatment.maxAmount"
                @cancleEvent="isAftersaleAlert = false"
                @confrimEvent="treatmentFn">
            </aftersale-treatment>
        </el-dialog>
    </div>
</template>

<script>
    import {
        getAfterSales,
        changeAftersalesStatus,
        getSmsStatus
    } from '../services/aftersale.js';

    export default {
        name: 'OrderAftersale',
        data() {
            return {
                shopCode: this.$store.state.user.userInfo.defaultShop.shopCode || '',
                // shopCode: 554654522,
                // 状态数据映射
                smsState: {
                    serviceType: {},
                    serviceStatus: {},
                },
                // 筛选数据
                formOption: {
                    serviceNo: '',
                    orderNo: '',
                    sku: '',
                    screenTime: null,
                    serviceType: '',
                    serviceStatus: '',
                },
                serviceTypeOption: {},
                serviceStatusOption: {},
                // 表格数据
                listData: [],
                listOrderTotalAmount: 0,
                // 翻页
                total: 1,
                currentPage: 1,
                pageSize: 20,
                pageSizes: [10, 20, 30],
                isAftersaleAlert: false,
                afterSaleTreatment: {
                    type: 0,
                    isShip: 0,
                    maxAmount: 0,
                    submitInfo: null,
                }
            };
        },
        watch: {
            $route(to, from) {
                this.mergeParam();
            }
        },
        created() {
            const vm = this;
            // 请求 SMS 状态映射表
            getSmsStatus.http().then((smsData) => {
                const { status, data } = smsData;
                if (status === 0) {
                    vm.smsState.serviceType = data.ServiceType;
                    vm.smsState.serviceStatus = data.ServiceStatus;
                    vm.serviceTypeOption = vm.smsState.serviceType;
                    vm.serviceStatusOption = vm.smsState.serviceStatus;
                }
            });
            vm.mergeParam();
        },
        methods: {
            cleanInput(ref) {
                this.$refs[ref].resetFields();
            },
            aftersaleAlert(itemInfo) {
                this.isAftersaleAlert = true;
                this.afterSaleTreatment.type = itemInfo.service_type;
                this.afterSaleTreatment.isShip = itemInfo.is_ship;
                this.afterSaleTreatment.maxAmount = itemInfo.refund_amount;
                this.afterSaleTreatment.submitInfo = {
                    merchant_no: itemInfo.sku,
                    service_no: itemInfo.service_no
                };
            },
            confirmReceipt(itemInfo) {
                const vm = this;
                vm.$alert(vm.$t('order.aftersale.confirmRseceiptTip'), vm.$t('order.aftersale.confirmRseceipt'), {
                    confirmButtonText: vm.$t('order.aftersale.confirm'),
                }).then(() => {
                    vm.changeStatus({
                        action: 'confirm',
                        merchant_no: itemInfo.sku,
                        service_no: itemInfo.service_no,
                        service_type: itemInfo.service_type
                    });
                }).catch(() => {
                    // console.log('已取消')
                });
            },
            treatmentFn(data) {
                const vm = this;
                const reqDat = Object.assign(vm.afterSaleTreatment.submitInfo, data);
                vm.changeStatus(reqDat);
            },
            handleSizeChange(val) {
                const vm = this;
                vm.pageSize = val;
                vm.setRoute();
            },
            handleCurrentChange(val) {
                const vm = this;
                vm.currentPage = val;
                vm.setRoute();
            },
            // ----- 页面逻辑 -----
            setRoute() { // 将参数写入路由
                const vm = this;
                const queryData = {};
                if (vm.currentPage && vm.currentPage !== 1) queryData.currentPage = vm.currentPage;
                if (vm.pageSize && vm.pageSize !== 10) queryData.pageSize = vm.pageSize;
                if (vm.formOption.serviceNo) queryData.serviceNo = vm.formOption.serviceNo;
                if (vm.formOption.orderNo) queryData.orderNo = vm.formOption.orderNo;
                if (vm.formOption.screenTime) {
                    queryData.startTime = vm.formOption.screenTime[0];
                    queryData.endTime = vm.formOption.screenTime[1];
                }
                if (vm.formOption.serviceType) queryData.serviceType = vm.formOption.serviceType;
                if (vm.formOption.serviceStatus) queryData.serviceStatus = vm.formOption.serviceStatus;
                if (vm.formOption.sku) queryData.sku = vm.formOption.sku;
                vm.$router.push({
                    name: 'OrderAftersale',
                    query: queryData
                });
            },
            mergeParam() { // 从路由读取参数
                const vm = this;
                const urlQuery = vm.$route.query || {};
                // 根据链接参数初始化默认值
                const reqData = {
                    merchant_no: vm.shopCode,
                    page: +urlQuery.currentPage || 1,
                    pageSize: +urlQuery.pageSize || 10,
                };
                if (urlQuery.serviceNo) reqData.service_no = urlQuery.serviceNo;
                if (urlQuery.orderNo) reqData.order_no = urlQuery.orderNo;
                if (urlQuery.startTime && urlQuery.endTime) {
                    reqData.start_time = urlQuery.startTime / 1000;
                    reqData.end_time = urlQuery.endTime / 1000;
                }
                if (urlQuery.serviceType) reqData.service_type = urlQuery.serviceType;
                if (urlQuery.serviceStatus) reqData.service_status = urlQuery.serviceStatus;
                if (urlQuery.sku) reqData.sku = urlQuery.sku;
                vm.getList(reqData);
            },
            // ----- 请求数据 -----
            async getList(params) { // 请求列表数据
                const vm = this;
                const { status, data } = await getAfterSales.http({
                    loading: true,
                    params
                });
                if (status === 0) {
                    if (params.start_time && params.end_time) vm.formOption.screenTime = [params.start_time * 1000, params.end_time * 1000];
                    vm.formOption.serviceNo = params.service_no || '';
                    vm.formOption.orderNo = params.order_no || '';
                    vm.formOption.serviceType = params.service_type || '';
                    vm.formOption.serviceStatus = params.service_status || '';
                    vm.formOption.sku = params.sku || '';
                    vm.currentPage = params.page;
                    vm.pageSize = params.pageSize;
                    vm.total = +data.total;
                    vm.listData = data.data;
                    vm.listOrderTotalAmount = data.order_total_amount;
                }
            },
            async changeStatus(params) {
                const vm = this;
                const { status } = await changeAftersalesStatus.http({
                    loading: true,
                    data: params
                });
                if (status === 0) {
                    vm.isAftersaleAlert = false;
                    vm.mergeParam();
                }
            }
        }
    };
</script>

<style module>
    .container {
        background: #fff;
        padding: 30px 20px;
        min-height: 740px;
    }

    .topTip {
        line-height: 32px;
        padding: 0 10px;
        border: 1px solid #FFEBCC;
        border-radius: 4px;
        background: #FFF5E6;
        color: #666666;
        margin-bottom: 20px;
    }

    .tipIcon {
        color: #FFB403;
    }

    .listBox {
        margin-bottom: 10px;
    }

    .listOrderAmount {
        line-height: 32px;
    }

    /* 表格内容 */
    .serviceNo {
        text-align: left;
    }

    .serviceNoItem {
        margin-bottom: 5px;
        line-height: 20px;
    }

    .serviceNoItem:nth-child(2) {
        margin-bottom: 0;
    }

    .serviceNoItemTitle {
        color: #666;
    }

    .goodsMsg {
        font-size: 0;
    }

    .goodsMsgImg {
        display: inline-block;
        vertical-align: middle;
        width: 40px;
        height: 40px;
    }

    .goodsMsgWrap {
        display: inline-block;
        vertical-align: middle;
        font-size: 14px;
        margin-left: 20px;
        width: 140px;
        text-align: left;
    }

    .goodsMsgTitle {
        width: 100%;
        line-height: 20px;
        margin-bottom: 5px;
    }
</style>
