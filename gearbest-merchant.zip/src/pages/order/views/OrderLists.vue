<!-- 全部 -->
<template>
    <div :class="$style.container">
        <!-- tabs box -->
        <el-tabs
            v-model="tapsCurrent"
            type="border-card"
            @tab-click="tabsChange">
            <el-tab-pane
                v-for="(value, key) in stateStore.orderListTab"
                :key="key"
                :name="key">
                <span slot="label">
                    {{ value }} <em :class="$style.tipsNum"></em>
                </span>

                <!-- 筛选区 -->
                <el-form
                    ref="elForm"
                    :model="filterOrder"
                    :class="$style.filterFrom"
                    label-suffix="："
                    inline>

                    <el-form-item :label="`${ $t('order.filter.goodsName') }`" prop="goodsTitle">
                        <el-input
                            v-model="filterOrder.goodsTitle"></el-input>
                    </el-form-item>

                    <el-form-item :label="`${ $t('order.filter.orderNumber') }`" prop="orderSns">
                        <el-input
                            v-model="filterOrder.orderSns"></el-input>
                    </el-form-item>

                    <!-- 下单时间 -->
                    <el-form-item
                        v-if="[0, 1, 2, 3, 4].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.orderTime') }`"
                        prop="createTimeInterval">
                        <el-date-picker
                            :clearable="false"
                            :start-placeholder="$t('order.filter.startTime')"
                            :range-separator="$t('order.filter.toTime')"
                            :end-placeholder="$t('order.filter.endTime')"
                            v-model="filterOrder.createTimeInterval"
                            type="datetimerange"
                            value-format="timestamp"
                            align="center">
                        </el-date-picker>
                    </el-form-item>

                    <!--  完成时间 -->
                    <el-form-item
                        v-if="[5].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.timeCompletion') }`"
                        prop="timeCompletionInterval">
                        <el-date-picker
                            :clearable="false"
                            :start-placeholder="$t('order.filter.startTime')"
                            :range-separator="$t('order.filter.toTime')"
                            :end-placeholder="$t('order.filter.endTime')"
                            v-model="filterOrder.timeCompletionInterval"
                            type="datetimerange"
                            value-format="timestamp">
                        </el-date-picker>
                    </el-form-item>

                    <!--  退款时间 -->
                    <el-form-item
                        v-if="[6].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.timeRefund') }`"
                        prop="timeCancelInterval">
                        <el-date-picker
                            :clearable="false"
                            :start-placeholder="$t('order.filter.startTime')"
                            :range-separator="$t('order.filter.toTime')"
                            :end-placeholder="$t('order.filter.endTime')"
                            v-model="filterOrder.timeCancelInterval"
                            type="datetimerange"
                            value-format="timestamp">
                        </el-date-picker>
                    </el-form-item>

                    <!--  取消时间 -->
                    <el-form-item
                        v-if="[7].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.timeCancel') }`"
                        prop="timeCancelInterval">
                        <el-date-picker
                            :start-placeholder="$t('order.filter.startTime')"
                            :range-separator="$t('order.filter.toTime')"
                            :end-placeholder="$t('order.filter.endTime')"
                            v-model="filterOrder.timeCancelInterval"
                            type="datetimerange"
                            value-format="timestamp">
                        </el-date-picker>
                    </el-form-item>

                    <!-- 运单编号 -->
                    <el-form-item
                        v-if="[0, 2, 3, 4].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.logisticsSn') }`"
                        prop="logisticsSn">
                        <el-input
                            v-model="filterOrder.logisticsSn"></el-input>
                    </el-form-item>

                    <el-form-item :label="`${ $t('order.filter.productId') }`" prop="goodsSn">
                        <el-input
                            v-model="filterOrder.goodsSn"></el-input>
                    </el-form-item>

                    <!--  付款时间 -->
                    <el-form-item
                        v-if="[2].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.timePayment') }`"
                        prop="timePaymentInterval">
                        <el-date-picker
                            :clearable="false"
                            :start-placeholder="$t('order.filter.startTime')"
                            :range-separator="$t('order.filter.toTime')"
                            :end-placeholder="$t('order.filter.endTime')"
                            v-model="filterOrder.timePaymentInterval"
                            type="datetimerange"
                            value-format="timestamp">
                        </el-date-picker>
                    </el-form-item>

                    <!--  发货时间 -->
                    <el-form-item
                        v-if="[3].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.timeDelivery') }`"
                        prop="timeDeliveryInterval">
                        <el-date-picker
                            :clearable="false"
                            :start-placeholder="$t('order.filter.startTime')"
                            :range-separator="$t('order.filter.toTime')"
                            :end-placeholder="$t('order.filter.endTime')"
                            v-model="filterOrder.timeDeliveryInterval"
                            type="datetimerange"
                            value-format="timestamp">
                        </el-date-picker>
                    </el-form-item>

                    <!--  退款申请时间 -->
                    <el-form-item
                        v-if="[4].includes(Number(tapsCurrent))"
                        :label="`${ $t('order.filter.timeRefundApplication') }`"
                        prop="timeRefundApplication">
                        <el-date-picker
                            :clearable="false"
                            :start-placeholder="$t('order.filter.startTime')"
                            :range-separator="$t('order.filter.toTime')"
                            :end-placeholder="$t('order.filter.endTime')"
                            v-model="filterOrder.timeRefundApplication"
                            type="datetimerange"
                            value-format="timestamp">
                        </el-date-picker>
                    </el-form-item>

                    <el-form-item :label="`${ $t('order.filter.deliveryMode') }`" prop="deliveryType">
                        <el-select v-model="filterOrder.deliveryType">
                            <el-option :label=" $t('order.filter.all')" value=""></el-option>
                            <el-option
                                v-for="(value, key) in stateStore.deliveryType"
                                :key="key" :label="value" :value="key"></el-option>
                        </el-select>
                    </el-form-item>

                    <el-button @click="cleanInput('elForm', key)">{{ $t('order.filter.reset') }}</el-button>
                    <el-button type="primary" @click="changeList()">{{ $t('order.filter.search') }}</el-button>
                </el-form>

                <!-- 数据列表 -->
                <el-table
                    :data="orderData">
                    <el-table-column
                        :label="$t('order.list.orderInformation')"
                        width="130"
                        align="center">
                        <template slot-scope="scope">
                            <div :class="$style.orderMsg">
                                <p :class="$style.orderMsgTitle">{{ $t('order.list.orderNumber') }}:</p>
                                <p :class="$style.orderNum">
                                    <router-link
                                        :to="{ name: 'OrderDetails', params: { orderSn: scope.row.orderSn } }">
                                        {{ scope.row.orderSn }}
                                    </router-link>
                                </p>
                                <p :class="$style.orderMsgTitle">{{ $t('order.filter.orderTime') }}:</p>
                                <p>{{ $dateFormat(scope.row.createdTime) }}</p>
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column
                        :label="$t('order.list.goodsMsg')"
                        width="200"
                        align="center">
                        <template slot-scope="scope">
                            <div :class="$style.goodsMsg">
                                <img :src="scope.row.orderGoodsResp[0].imgUrl" :class="$style.goodsMsgImg" />
                                <div :class="$style.goodsMsgWrap">
                                    <p :class="$style.goodsMsgTitle">
                                        <a :href="scope.row.orderGoodsResp[0].goodsUrl">
                                            {{ scope.row.orderGoodsResp[0].goodsTitle }}
                                        </a>
                                    </p>
                                    <p>{{ $t('order.list.number') }}：{{ scope.row.orderGoodsResp[0].goodsSn }}</p>
                                    <p>{{ $t('order.list.attribute') }}：{{ scope.row.orderGoodsResp[0].goodsAttrResp.color }} </p>
                                    <p>{{ $t('order.list.size') }}：{{ scope.row.orderGoodsResp[0].goodsAttrResp.size }}</p>
                                    <p>{{ $t('order.list.price') }}：${{ scope.row.orderGoodsResp[0].price }}</p>
                                    <p>{{ $t('order.list.amount') }}：{{ scope.row.orderGoodsResp[0].qty }}</p>
                                </div>
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column
                        :label="$t('order.list.orderAmount')"
                        align="center"
                        prop="orderAmount">
                        <template slot-scope="scope">
                            ${{ scope.row.orderAmount }}
                        </template>
                    </el-table-column>

                    <el-table-column
                        :label="$t('order.list.buyers')"
                        align="center">
                        <template slot-scope="scope">
                            <router-link :to="{ name: 'OrderDetails', params: { orderSn: scope.row.orderSn, jump: 1 } }">
                                {{ scope.row.firstName }} {{ scope.row.laseName }}
                            </router-link>
                        </template>
                    </el-table-column>

                    <el-table-column
                        :label="$t('order.list.orderStatus')"
                        align="center">
                        <template slot-scope="scope">
                            {{ stateStore.orderStatusSequ[scope.row.orderStatusSequ] || scope.row.orderStatusSequ }}
                        </template>
                    </el-table-column>

                    <el-table-column
                        :label="$t('order.list.logisticsGroup')"
                        align="center"
                        prop="logisticsLevel">
                        <template slot-scope="scope">
                            {{ stateStore.logisticsLevel[scope.row.logisticsLevel] || scope.row.logisticsLevel }}
                        </template>
                    </el-table-column>

                    <el-table-column
                        :label="$t('order.filter.deliveryMode')"
                        align="center">
                        <template slot-scope="scope">
                            {{ stateStore.deliveryType[scope.row.deliveryType] }}
                        </template>
                    </el-table-column>

                    <el-table-column
                        :label="$t('order.list.operation')"
                        align="center">
                        <template slot-scope="scope">
                            <!-- 退款处理 判断条件：完全支付payStatus=3 取消申请中orderStatus=5 未审核过 checkStatus=0 -->
                            <div v-if="scope.row.payStatus == 3 && scope.row.checkStatus == 0 && scope.row.orderStatus == 5">
                                <a
                                    href="javascript:;"
                                    @click="refundMoney(scope.row.orderSn)">
                                    {{ $t('order.list.refundProcess') }}
                                </a>
                            </div>
                            <!-- 发货登记：(待配货、部分配货、待发货、部分发货) 且 不为FBG(入仓) -->
                            <div v-if="[2, 13, 3, 14].includes(scope.row.orderStatusSequ) && scope.row.deliveryType != 2">
                                <router-link :to="{ name: 'OrderDeliveryregistered', params: { orderSn: scope.row.orderSn } }">
                                    {{ $t('order.list.registration') }}
                                </router-link>
                            </div>
                            <div>
                                <router-link :to="{ name: 'OrderDetails', params: { orderSn: scope.row.orderSn } }">
                                    {{ $t('order.list.orderDetails') }}
                                </router-link>
                            </div>
                        </template>
                    </el-table-column>
                </el-table>
            </el-tab-pane>
        </el-tabs>

        <!-- 底部分页 -->
        <el-row :class="$style.orderListsFooter">
            <el-col :span="6">
                <div :class="$style.orderMoneySum">
                    {{ $t('order.list.totalOrderAmount') }}：${{ pageTotalAmount }}
                </div>
            </el-col>
            <el-col :span="18">
                <el-pagination
                    :current-page="currentPage"
                    :total="totalCount"
                    :page-size="pageSize"
                    :page-sizes="pageSizeArr"
                    layout="total, sizes, prev, pager, next, jumper"
                    align="right"
                    @size-change="pageSizeSelect"
                    @current-change="currentChangeSize">
                </el-pagination>
            </el-col>
        </el-row>

        <!-- 弹出层内容 -->
        <el-dialog
            :visible.sync="dialogTableVisible"
            :title="$t('order.list.refundProcess')"
            width="450px">
            <div :class="$style.refundItem">
                <span :class="$style.refundItemLabel">{{ $t('order.list.refundReason') }}：</span>
                <div :class="$style.refundItemValue">
                    {{ $t('order.list.notNeed') }}
                </div>
            </div>
            <div :class="$style.refundItem">
                <span :class="[$style.refundItemLabel, $style.refundItemLabelRequier]">{{ $t('order.list.select') }}：</span>
                <div :class="$style.refundItemValue">
                    <el-radio v-model="refundSelect" :label="1">{{ $t('order.list.accept') }}</el-radio>
                    <el-radio v-model="refundSelect" :label="2">{{ $t('order.list.refused') }}</el-radio>
                </div>
            </div>
            <div v-if="refundSelect === 2" :class="$style.refundItem">
                <span :class="[$style.refundItemLabel, $style.refundItemLabelRequier]">{{ $t('order.list.reasonThat') }}：</span>
                <div :class="$style.refundItemValue">
                    <el-select v-model="refuseReason">
                        <el-option
                            v-for="(value, key) in stateStore.returnReason"
                            :label="value"
                            :value="key"
                            :key="key">
                        </el-option>
                    </el-select>
                </div>
            </div>
            <div slot="footer" align="center">
                <el-button @click="dialogTableVisible = false">{{ $t('order.list.cancel') }}</el-button>
                <el-button type="primary" @click="sureRefund">
                    {{ refundSelect === 2 ? $t('order.list.sureDelivery') : $t('order.list.sure') }}
                </el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import { getOrderList, auditCancelOrder } from '../services';
    import { getOrderStatus } from '../utils/statusStore.js';
    import getHasValueObj, { typeIsTrue, checkEqualObject } from '../utils/getHasValueObj.js';

    const timeInterval = [(+new Date() - 1000 * 60 * 60 * 24 * 30), (+new Date())]; // 默认前30天
    export default {
        data() {
            return {
                // 状态映射数据
                stateStore: {
                    orderListTab: {},
                    orderStatusSequ: {},
                    deliveryType: {},
                    returnReason: {},
                    logisticsLevel: {},
                },
                // tab 筛选数据
                tapsCurrent: '0',
                filterOrder: {
                    goodsTitle: '', // 商品名称
                    orderSns: '', // 订单编号
                    createTimeInterval: timeInterval, // 下单时间
                    timePaymentInterval: [], // 付款时间
                    timeDeliveryInterval: [], // 发货时间
                    timeCompletionInterval: timeInterval, // 完成时间
                    timeRefundApplication: [], // 退款申请时间
                    timeCancelInterval: timeInterval, // 退款、取消时间
                    logisticsSn: '', // 运单编号
                    goodsSn: '', // 商品编号
                    deliveryType: '', // 发货模式
                },
                // 订单数据
                orderData: [],
                // 分页器
                currentPage: 1,
                totalCount: 0,
                pageSize: 10,
                pageSizeArr: [10, 20, 30, 40, 50],
                pageTotalAmount: 0,
                // 保存prev 请求参数
                prevQuery: {},
                // 弹窗数据 - 退款申请
                dialogTableVisible: false,
                refundOrderSn: '',
                refundSelect: 1,
                refuseReason: '',
            };
        },
        watch: {
            $route(to, from) {
                const vm = this;
                if (Object.keys(to.query).length) {
                    vm.initChangeUrl(to.query);
                } else {
                    vm.changeList({
                        init: true
                    });
                }
            }
        },
        created() {
            const vm = this;
            // 获取状态映射数据
            getOrderStatus(['orderListTab', 'orderStatusSequ', 'deliveryType', 'returnReason', 'logisticsLevel']).then((resolved) => {
                vm.stateStore.orderListTab = resolved.orderListTab;
                vm.stateStore.orderStatusSequ = resolved.orderStatusSequ;
                vm.stateStore.deliveryType = resolved.deliveryType;
                vm.stateStore.returnReason = resolved.returnReason;
                vm.stateStore.logisticsLevel = resolved.logisticsLevel;
            });
            if (Object.keys(this.$route.query).length) {
                vm.initChangeUrl(this.$route.query);
            } else {
                vm.changeList({
                    init: true
                });
            }
        },
        methods: {
            cleanInput(ref, index) {
                try {
                    this.$refs[ref][index].resetFields();
                } catch (e) {
                    //
                }
            },
            getSeconds(milliSecond) {
                return milliSecond ? parseInt(milliSecond / 1000, 10) : undefined;
            },
            getMilliSecond(seccond) {
                return seccond ? parseInt(seccond * 1000, 10) : undefined;
            },
            // ----- 根据tab 初始化组装时间 ----
            tabsChange({ index = 0 }) {
                const vm = this;
                vm.currentPage = 1;
                vm.pageSize = 10;
                vm.tapsCurrent = String(index);
                vm.cleanInput('elForm', index);
                vm.changeList();
            },
            // filterOrderClear() {}
            refundMoney(orderSn) {
                this.dialogTableVisible = true;
                this.refundOrderSn = orderSn;
            },
            pageSizeSelect(size) { // 选择分页数量
                this.pageSize = size;
                this.changeList();
            },
            currentChangeSize(currentPage) {
                this.currentPage = currentPage;
                this.changeList();
            },
            initFilterData() {
                const vm = this;
                vm.tapsCurrent = '0';
                vm.totalCount = 0;
                vm.pageSize = 10;
                vm.filterOrder = {
                    goodsTitle: '', // 商品名称
                    orderSns: '', // 订单编号
                    createTimeInterval: timeInterval, // 下单时间
                    timePaymentInterval: [], // 付款时间
                    timeDeliveryInterval: [], // 发货时间
                    timeCompletionInterval: timeInterval, // 完成时间
                    timeRefundApplication: [], // 退款申请时间
                    timeCancelInterval: timeInterval, // 退款、取消时间
                    logisticsSn: '', // 运单编号
                    goodsSn: '', // 商品编号
                    deliveryType: '', // 发货模式
                };
            },
            changeList({
                init = false
            } = {}) {
                const vm = this;
                if (init) vm.initFilterData();
                const time = {};
                const tabsIndex = Number(vm.tapsCurrent);
                if ([0, 1, 2, 3, 4].includes(tabsIndex) && vm.filterOrder.createTimeInterval) {
                    time.createStartTime = vm.getSeconds(vm.filterOrder.createTimeInterval[0]);
                    time.createEndtime = vm.getSeconds(vm.filterOrder.createTimeInterval[1]);
                }
                if (tabsIndex === 2 && vm.filterOrder.timePaymentInterval) {
                    time.completedStartTime = vm.getSeconds(vm.filterOrder.timePaymentInterval[0]);
                    time.completedEndTime = vm.getSeconds(vm.filterOrder.timePaymentInterval[1]);
                }
                if (tabsIndex === 3 && vm.filterOrder.timeDeliveryInterval) {
                    time.wholeDeliveryStartTime = vm.getSeconds(vm.filterOrder.timeDeliveryInterval[0]);
                    time.wholeDeliveryEndTime = vm.getSeconds(vm.filterOrder.timeDeliveryInterval[1]);
                }
                if (tabsIndex === 4 && vm.filterOrder.timeRefundApplication) {
                    time.cancelingStartTime = vm.getSeconds(vm.filterOrder.timeRefundApplication[0]);
                    time.cancelingEndTime = vm.getSeconds(vm.filterOrder.timeRefundApplication[1]);
                }
                if (tabsIndex === 5 && vm.filterOrder.timeCompletionInterval) {
                    time.logisticsConfirmStartTime = vm.getSeconds(vm.filterOrder.timeCompletionInterval[0]);
                    time.logisticsConfirmEndTime = vm.getSeconds(vm.filterOrder.timeCompletionInterval[1]);
                }
                if ([6, 7].includes(tabsIndex) && vm.filterOrder.timeCancelInterval) {
                    time.canceledStartTime = vm.getSeconds(vm.filterOrder.timeCancelInterval[0]);
                    time.canceledEndTime = vm.getSeconds(vm.filterOrder.timeCancelInterval[1]);
                }

                const query = Object.assign({
                    orderCombinedStatus: tabsIndex,
                    pageSize: vm.pageSize,
                    pageNo: vm.currentPage
                }, {
                    goodsTitle: vm.filterOrder.goodsTitle || undefined,
                    orderSns: vm.filterOrder.orderSns || undefined,
                    logisticsSn: vm.filterOrder.logisticsSn || undefined,
                    goodsSn: vm.filterOrder.goodsSn || undefined,
                    deliveryType: vm.filterOrder.deliveryType || undefined,
                }, time);

                if (init) {
                    vm.getOrderList(query);
                } else if (!checkEqualObject(vm.prevQuery, query)) {
                    vm.cleanInput('elForm', tabsIndex);
                    vm.changeUrlUpdate(query);
                }
            },
            // ----- 请求数据 -----
            async getOrderList(query) {
                const vm = this;
                const { status, data } = await getOrderList.http({
                    loading: true,
                    params: query
                });
                if (status === 0) {
                    vm.currentPage = +data.pageNo;
                    vm.totalCount = data.totalCount;
                    vm.pageTotalAmount = data.pageTotalAmount;
                    vm.orderData = data.list;
                }
            },
            changeUrlUpdate(query) { // 添加导航历史记录
                const routeTo = {
                    name: 'OrderLists',
                    query: getHasValueObj(query)
                };
                this.$router.push(routeTo);
            },
            initChangeUrl(query) {
                const vm = this;
                const {
                    createStartTime,
                    createEndtime,
                    completedStartTime,
                    completedEndTime,
                    wholeDeliveryStartTime,
                    wholeDeliveryEndTime,
                    cancelingStartTime,
                    cancelingEndTime,
                    logisticsConfirmStartTime,
                    logisticsConfirmEndTime,
                    canceledStartTime,
                    canceledEndTime,
                    orderCombinedStatus,
                    pageSize,
                    pageNo,
                    goodsTitle,
                    orderSns,
                    logisticsSn,
                    goodsSn,
                    deliveryType,
                } = query;
                vm.prevQuery = query;
                vm.cleanInput('elForm', orderCombinedStatus);
                if (typeIsTrue(createStartTime)) vm.filterOrder.createTimeInterval.splice(0, 1, vm.getMilliSecond(createStartTime));
                if (typeIsTrue(createEndtime)) vm.filterOrder.createTimeInterval.splice(1, 1, vm.getMilliSecond(createEndtime));
                if (typeIsTrue(completedStartTime)) vm.filterOrder.timePaymentInterval.splice(0, 1, vm.getMilliSecond(completedStartTime));
                if (typeIsTrue(completedEndTime)) vm.filterOrder.timePaymentInterval.splice(1, 1, vm.getMilliSecond(completedEndTime));
                if (typeIsTrue(wholeDeliveryStartTime)) vm.filterOrder.timeDeliveryInterval.splice(0, 1, vm.getMilliSecond(wholeDeliveryStartTime));
                if (typeIsTrue(wholeDeliveryEndTime)) vm.filterOrder.timeDeliveryInterval.splice(1, 1, vm.getMilliSecond(wholeDeliveryEndTime));
                if (typeIsTrue(cancelingStartTime)) vm.filterOrder.timeRefundApplication.splice(0, 1, vm.getMilliSecond(cancelingStartTime));
                if (typeIsTrue(cancelingEndTime)) vm.filterOrder.timeRefundApplication.splice(1, 1, vm.getMilliSecond(cancelingEndTime));
                if (typeIsTrue(logisticsConfirmStartTime)) {
                    vm.filterOrder.timeCompletionInterval.splice(0, 1, vm.getMilliSecond(logisticsConfirmStartTime));
                }
                if (typeIsTrue(logisticsConfirmEndTime)) {
                    vm.filterOrder.timeCompletionInterval.splice(1, 1, vm.getMilliSecond(logisticsConfirmEndTime));
                }
                if (typeIsTrue(canceledStartTime)) vm.filterOrder.timeCancelInterval.splice(0, 1, vm.getMilliSecond(canceledStartTime));
                if (typeIsTrue(canceledEndTime)) vm.filterOrder.timeCancelInterval.splice(1, 1, vm.getMilliSecond(canceledEndTime));

                if (typeIsTrue(orderCombinedStatus)) vm.tapsCurrent = String(orderCombinedStatus);
                if (typeIsTrue(pageSize)) vm.pageSize = Number(pageSize);
                if (typeIsTrue(pageNo)) vm.currentPage = Number(pageNo);
                if (typeIsTrue(goodsTitle)) vm.filterOrder.goodsTitle = goodsTitle;
                if (typeIsTrue(orderSns)) vm.filterOrder.orderSns = orderSns;
                if (typeIsTrue(logisticsSn)) vm.filterOrder.logisticsSn = logisticsSn;
                if (typeIsTrue(goodsSn)) vm.filterOrder.goodsSn = goodsSn;
                if (typeIsTrue(deliveryType)) vm.filterOrder.deliveryType = deliveryType;
                this.getOrderList(query);
            },
            async sureRefund() { // 确定退款
                const vm = this;
                if (vm.refundSelect === 2 && vm.refuseReason !== 0 && !vm.refuseReason) { // 拒绝原因必填
                    vm.$message({
                        type: 'error',
                        message: '请选择原因说明'
                    });
                    return;
                }
                vm.dialogTableVisible = false;
                const { status, msg } = await auditCancelOrder.http({
                    params: {
                        orderSn: vm.refundOrderSn,
                        status: vm.refundSelect,
                        msg: vm.refuseReason
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                if (status === 0) {
                    if (vm.refundSelect === 2) {
                        vm.$router.push({
                            name: 'OrderDeliveryregistered',
                            params: {
                                orderSn: vm.refundOrderSn
                            }
                        });
                    } else {
                        vm.changeList();
                    }
                }
            },
        },
    };
</script>

<style module>
    .container {
        background-color: #fff;
        padding: 30px 20px;
        min-height: 740px;
    }

    /* tab box */
    .tipsNum {
        color: #2774FF;
        font-style: normal;
    }

    .filterFrom {
        margin-bottom: 20px;
    }

    /* 分页器 */
    .orderListsFooter {
        margin-top: 20px;
    }

    .orderMoneySum {
        height: 32px;
        line-height: 32px;
    }

    /* 数据表格 */
    .orderMsg {
        text-align: left;
    }

    .orderMsgTitle {
        color: #999;
    }

    .orderNum {
        margin-bottom: 10px;
    }

    .goodsMsg {
        font-size: 0;
    }

    .goodsMsgImg {
        display: inline-block;
        vertical-align: middle;
        width: 60px;
        height: 60px;
        margin-right: 10px;
    }

    .goodsMsgWrap {
        display: inline-block;
        vertical-align: middle;
        text-align: left;
        width: 110px;
        font-size: 14px;
    }

    .goodsMsgTitle {
        margin-bottom: 5px;
    }

    /* 弹窗 */
    .refundItem {
        color: #000;
        font-size: 0;
        margin-bottom: 10px;
    }

    .refundItemLabel {
        display: inline-block;
        vertical-align: top;
        text-align: right;
        width: 140px;
        margin-right: 10px;
        line-height: 40px;
        font-size: 14px;
    }

    .refundItemLabelRequier:before {
        content: '*';
        color: #c00;
    }

    .refundItemValue {
        display: inline-block;
        vertical-align: top;
        text-align: left;
        width: 260px;
        line-height: 40px;
        font-size: 14px;
    }
</style>
