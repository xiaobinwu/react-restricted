<template>
    <div :class="$style.container">
        <div :class="$style.tips">
            <el-alert
                v-if="notProofed"
                :closable="false"
                title="请在72小时内进行举证，若超时未进行举证，则默认按照原判责结果执行。"
                type="warning"
                show-icon>
            </el-alert>
        </div>
        <section :class="$style.detail">
            <p :class="$style.title">判责详情</p>
            <div :class="$style.detailContent">
                <dl>
                    <dt>判责明细</dt>
                    <dd>
                        判责单号：<span>{{ data.service_no }}</span>
                    </dd>
                    <dd>
                        判责金额：<span :class="$style.danger">{{ priceFormat(data.sku_refund_total_price) }}</span>
                    </dd>
                    <dd>
                        处理状态：<span :class="$style.warning">{{ serviceStatusFormat(data.service_status) }}</span>
                    </dd>
                    <dd>
                        判责原因：<span>{{ data.reason }}</span>
                    </dd>
                    <dd v-show="!!data.result">
                        判责结果：<span>{{ data.result }}</span>
                    </dd>
                    <dd>
                        是否终审：<span>{{ finishedTypeFormat(data.finished_type) }}</span>
                    </dd>
                </dl>
                <dl>
                    <dt>时间记录</dt>
                    <dd>
                        发起时间：<span>{{ dateFormat(data.create_time) }}</span>
                    </dd>
                    <dd v-if="data.is_proof_time_out === 0 && data.is_proofed === 1">
                        举证时间：<span>{{ dateFormat(data.proof_time) }}</span>
                    </dd>
                    <dd v-if="data.is_proof_time_out === 1">
                        举证时间：<span>{{ dateFormat(data.create_time + (60 * 60 * 72)) }}（超时未举证）</span>
                    </dd>
                    <dd v-if="data.finished_time > 0">
                        完成时间：<span>{{ dateFormat(data.finished_time) }}</span>
                    </dd>
                </dl>
            </div>

        </section>
        <section :class="$style.goods">
            <p :class="$style.title">商品信息</p>
            <div class="content">
                <el-table :data="table" border>
                    <el-table-column label="商品信息" width="300px">
                        <template slot-scope="scope">
                            <div :class="$style.goodsCard">
                                <div :class="$style.goodsImage">
                                    <img :src="scope.row.goods_image">
                                </div>
                                <div :class="$style.goodsInfo">
                                    <p><a :href="scope.row.goods_url" target="_blank">{{ scope.row.goods_title }}</a></p>
                                    <p>数量：{{ scope.row.sku_refund_amount }}</p>
                                    <p>单价：{{ priceFormat(scope.row.sku_refund_unit_price) }}</p>
                                </div>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column label="订单编号" width="200px">
                        <router-link slot-scope="scope" :to="{ name: 'OrderDetails', params: { orderSn: scope.row.order_no }}">
                            {{ scope.row.order_no }}
                        </router-link>
                    </el-table-column>
                    <el-table-column label="售后服务单号" prop="service_ticket_no">
                        <router-link slot-scope="scope" :to="{ name: 'OrderAftersaledetail', params: { id: scope.row.service_ticket_no }}">
                            {{ scope.row.service_ticket_no }}
                        </router-link>
                    </el-table-column>
                    <el-table-column label="服务类型" >
                        <template slot-scope="scope">
                            {{ serviceTypeFormat(scope.row.service_type) }}
                        </template>
                    </el-table-column>
                    <el-table-column label="发货模式">
                        <template slot-scope="scope">
                            {{ deliveryMode(scope.row.sku_delivery_mode) }}
                        </template>
                    </el-table-column>
                    <el-table-column label="商品总额">
                        <template slot-scope="scope">
                            {{ priceFormat(scope.row.sku_refund_total_price) }}
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </section>
        <section v-if="notProofed || isProofed" :class="$style.proof">
            <p :class="$style.title">举证信息</p>
            <div v-if="notProofed" :class="$style.proofContent">
                <el-form ref="form" :model="form" :rules="rules" label-width="100px" label-suffix="：">
                    <el-form-item label="判责结果">
                        {{ data.result }}
                    </el-form-item>
                    <el-form-item label="做出选择" prop="proof_type">
                        <el-radio v-model="form.proof_type" :label="1">接受</el-radio>
                        <el-radio v-model="form.proof_type" :label="2">进行举证</el-radio>
                    </el-form-item>
                    <el-form-item v-show="form.proof_type === 2" label="举证描述" prop="proof_des">
                        <el-input v-model="form.proof_des" type="textarea" placeholder="限10个字符以上，500字符以内"></el-input>
                    </el-form-item>
                    <el-form-item v-show="form.proof_type === 2" label="附件上传" prop="attachment_files">
                        <p>可上传图片或文件（格式为jpg、png、doc、docx、pdf,大小在5m以内,数量限6个以内）</p>
                        <div :class="$style.uploadFile" >
                            <div v-for="(file, index) in form.attachment_files" :class="$style.fileItem" :key="index" >
                                <template v-if="['jpeg','png','jpg'].includes(getFileExt(file))">
                                    <img :src="file">
                                </template>
                                <template v-if="['doc','docx'].includes(getFileExt(file))">
                                    <img src="@goods/assets/img/doc.png">
                                </template>
                                <template v-if="['pdf'].includes(getFileExt(file))">
                                    <img src="@goods/assets/img/pdf.png">
                                </template>
                            </div>
                        </div>
                        <el-upload
                            :action="uploadUrl"
                            :show-file-list="false"
                            :on-success="onUploadSuccess"
                            :before-upload="beforeUpload"
                            :class="$style.upload"
                            name="file1">
                            <i class="icon-close"></i>
                        </el-upload>
                    </el-form-item>
                </el-form>
            </div>
            <div v-if="isProofed" :class="$style.proofContentView">
                <div :class="$style.proofItem"><span>判责方案：</span><p>{{ data.result }}</p></div>
                <div :class="$style.proofItem"><span>举证描述：</span><p>{{ data.proof_des }}</p></div>
                <div :class="$style.proofItem">
                    <span>附件上传：</span>
                    <div :class="$style.uploadFile">
                        <div v-for="(file, index) in data.attachment_info" :class="$style.fileItem" :key="index" >
                            <template v-if="['jpeg','png','jpg'].includes(getFileExt(file))">
                                <img :src="file">
                            </template>
                            <template v-if="['doc','docx'].includes(getFileExt(file))">
                                <img src="@goods/assets/img/doc.png">
                            </template>
                            <template v-if="['pdf'].includes(getFileExt(file))">
                                <img src="@goods/assets/img/pdf.png">
                            </template>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="notProofed" :class="$style.btns">
                <el-button>取消</el-button>
                <el-button type="primary" @click="handleSaveClick">确认</el-button>
            </div>
        </section>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { deepCopy } from '@/assets/js/utils/types';
    import { serviceOrderAccountabilityDetail, serviceOrderAccountabilityProof } from '@order/services/accountability.js';

    export default {
        name: 'OrderAccountabilityDetail',

        inject: ['reload'],

        data() {
            return {
                dateFormat,
                data: '',
                table: [],
                uploadUrl: '/order/accountability/attachment/upload',
                form: {
                    proof_des: '',
                    attachment_files: [],
                    proof_type: ''
                },
                rules: {
                    proof_type: [
                        {
                            required: true,
                            validator(rules, value, callback) {
                                if (value === '') {
                                    callback(new Error('请选择举证类型'));
                                }
                                callback();
                            }
                        }
                    ],
                    proof_des: [
                        {
                            required: true,
                            type: 'string',
                            trigger: 'change',
                            validator: (rules, value, callback) => {
                                if (this.form.proof_type === 2) {
                                    if (!value.length) {
                                        callback(new Error('请输入举证内容'));
                                    }
                                    if (value.length > 500) {
                                        callback(new Error('500字符以内'));
                                    }
                                    if (value.length < 10) {
                                        callback(new Error('限10个字符以上'));
                                    }
                                }
                                callback();
                            }
                        }
                    ]
                }
            };
        },

        computed: {
            // 未举证
            notProofed() {
                return this.data.is_proofed === 0 && this.data.service_status === '30';
            },
            // 已举证
            isProofed() {
                return this.data.is_proofed === 1;
            }
        },

        created() {
            this.init();
        },

        methods: {
            init() {
                this.getOrderAccountabilityDetail();
            },

            // 订单问责详情
            async getOrderAccountabilityDetail() {
                const params = {
                    service_no: this.$route.params.serviceNo
                };
                const { status, data } = await serviceOrderAccountabilityDetail.http({ params });
                if (status === 0) {

                    this.data = data;
                    this.table.push(data);
                }
            },

            // 服务状态格式化
            serviceStatusFormat(val) {
                if (val === '30') {
                    return '卖家举证';
                }
                if (val === '50') {
                    return '已完成';
                }
                return '待判责';
            },

            serviceTypeFormat(val) {
                if (val === '1') {
                    return '退货退款';
                }
                if (val === '2') {
                    return '退款';
                }
                return '';
            },

            deliveryMode(val) {
                if (val === '1') {
                    return '直发';
                }
                if (val === '2') {
                    return '入仓';
                }
                return '';
            },

            finishedTypeFormat(val) {
                if (val === 1) {
                    return '否';
                }
                if (val === 2) {
                    return '是';
                }
                return '';
            },
            // 金额格式化
            priceFormat(val) {
                const price = Number(val);
                if (!Number.isNaN(price)) {
                    return `$${price.toFixed(2)}`;
                }
                return '0';
            },

            // 校验表单
            validateForm() {
                return new Promise((resolve, reject) => {
                    this.$refs.form.validate((valid) => {
                        if (valid) {
                            resolve();
                        } else {
                            reject();
                        }
                    });
                });
            },

            // 获取数据
            getData() {
                const formData = deepCopy(this.form);
                formData.attachment_files = formData.attachment_files.join(',');
                const { serviceNo } = this.$route.params;
                return {
                    ...formData,
                    service_no: serviceNo
                };
            },

            // 保存举证
            async handleSaveClick() {
                await this.validateForm();
                const data = this.getData();
                this.accountabilityProof(data);
            },

            // 举证
            async accountabilityProof(data) {
                const reply = await serviceOrderAccountabilityProof.http({ data });
                if (reply.status === 0) {
                    const msg = this.form.proof_type === 1
                        ? '提交成功，已同意平台判责结果'
                        : '举证成功，已拒绝平台判责结果，请等待平台审核';
                    this.$message.success(msg);
                    this.routerToList();
                }
            },

            // 上传成功
            onUploadSuccess({ data, status, msg }) {
                const images = this.form.attachment_files;
                if (status === 0) {
                    this.$set(images, images.length, data.shift());
                } else {
                    this.$message.error(msg);
                }
            },

            // 上传之前
            beforeUpload(file) {
                const type = this.getFileExt(file.name);
                const validType = ['jpg', 'jpeg', 'png', 'doc', 'docx', 'pdf'].includes(type);
                const validSize = file.size < 3 * 1024 * 1024;
                const validCount = this.form.attachment_files.length < 6;

                if (!validType) {
                    this.$message.error('请上传jpg、png、doc、docx、pdf格式');
                }
                if (!validSize) {
                    this.$message.error('请上传小于5M的文件');
                }
                if (!validCount) {
                    this.$message.error('最多上传6个文件');
                }

                return validType && validSize && validCount;
            },

            // 跳转判责列表
            routerToList() {
                this.$router.push({
                    name: 'OrderAccountability'
                });
            },

            getFileExt(val) {
                const ext = /.+\.(.+)$/;
                const match = val.match(ext);
                return match[1] || '';
            },

        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
        padding: 20px;
    }

    .tips {
        margin-bottom: 20px;
    }

    .title {
        font-size: var(--font-size-largest);
        margin-bottom: 20px;
    }

    .detailContent {
        padding: 30px 20px;
        border: 1px solid #eee;
    }

    .detailContent dl:first-child {
        margin-bottom: 30px;
    }

    .detailContent dt {
        margin-bottom: 17px;
        font-size: var(--font-size-larger);
        color: var(--color-text-primary);
    }

    .detailContent dd {
        padding-left: 28px;
        color: var(--color-text-regular);
        font-size: var(--font-size-base);
        line-height: 1.5;
    }

    .detailContent dd > span {
        color: var(--color-text-primary);
    }

    .detailContent .warning {
        color: var(--color-warning);
    }

    .detailContent .danger {
        color: var(--color-danger);
    }

    .goodsCard {
        display: flex;
    }

    .goodsImage {
        width: 60px;
        height: 60px;
        flex-shrink: 0;
        margin-right: 20px;
    }

    .goodsImage img {
        width: 100%;
        height: 100%;
    }

    .goods {
        margin-top: 30px;
    }

    .proof {
        margin-top: 30px;
    }

    .proofContent, .proofContentView {
        padding: 30px 20px;
        border: 1px solid #eee;
    }

    .upload {
        position: relative;
        width: 80px;
        height: 80px;
        border: 1px dashed #d9d9d9;
        border-radius: 4px;
        cursor: pointer;
        overflow: hidden;
        text-align: center;
        margin-top: 10px;
    }

    .upload [class^="icon-close"] {
        display: inline-block;
        font-size: 28px;
        line-height: 80px;
        text-align: center;
        color: rgba(153,153,153,1);
        transform: rotate(45deg);
    }

    .btns {
        margin-top: 50px;
        text-align: center;
    }


    .uploadFile {
        display: flex;
    }

    .uploadFile img {
        width: 60px;
        height: 60px;
        margin-right: 10px;
        object-fit: cover;
    }

    .proofItem {
        display: flex;
        margin-bottom: 15px;
    }

    .proofItem span {
        display: inline-block;
        width: 100px;
    }
</style>
