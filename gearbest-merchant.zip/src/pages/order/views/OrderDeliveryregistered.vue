<template>
    <div :class="$style.container">
        <!-- 收货信息 -->
        <div :class="$style.infor">
            <h3 :class="$style.title">收货信息</h3>
            <div :class="$style.inforContent">
                <el-row>
                    <el-col :span="8" :class="$style.addressBox">
                        <div
                            v-if="shippingInfo.lastName"
                            :class="$style.item">
                            <span :class="$style.itemLabel">收货人姓: </span>
                            <span :class="$style.black">{{ shippingInfo.lastName }}</span>
                        </div>
                        <div
                            v-if="shippingInfo.firstName"
                            :class="$style.item">
                            <span :class="$style.itemLabel">收货人名: </span>
                            <span :class="$style.black">{{ shippingInfo.firstName }}</span>
                        </div>
                        <div
                            v-if="shippingInfo.middleName"
                            :class="$style.item">
                            <span :class="$style.itemLabel">中间名: </span>
                            <span :class="$style.black">{{ shippingInfo.middleName }}</span>
                        </div>
                        <div
                            v-if="shippingInfo.country || shippingInfo.province || shippingInfo.city"
                            :class="$style.item">
                            <span :class="$style.itemLabel">国家,省/区/州,城市: </span>
                            <span :class="$style.black">
                                {{ shippingInfo.country }} {{ shippingInfo.province }} {{ shippingInfo.city }}
                            </span>
                        </div>
                        <div
                            v-if="shippingInfo.addressLine1"
                            :class="$style.item">
                            <span :class="$style.itemLabel">地址1: </span>
                            <span :class="$style.black">{{ shippingInfo.addressLine1 }}</span>
                        </div>
                        <div
                            v-if="shippingInfo.addressLine2"
                            :class="$style.item">
                            <span :class="$style.itemLabel">地址2: </span>
                            <span :class="$style.black"> {{ shippingInfo.addressLine2 }}</span>
                        </div>
                    </el-col>
                    <el-col :span="16">
                        <div
                            v-if="shippingInfo.addressLine3"
                            :class="$style.item">
                            <span :class="$style.itemLabel">备用地址1: </span>
                            <span :class="$style.black">{{ shippingInfo.addressLine3 }}</span>
                        </div>
                        <div
                            v-if="shippingInfo.addressLine4"
                            :class="$style.item">
                            <span :class="$style.itemLabel">备用地址2: </span>
                            <span :class="$style.black">{{ shippingInfo.addressLine4 }}</span>
                        </div>
                        <div
                            v-if="shippingInfo.postalCode"
                            :class="$style.item">
                            <span :class="$style.itemLabel">邮编：</span>
                            <span :class="$style.black">{{ shippingInfo.postalCode }}</span>
                        </div>
                        <div
                            v-if="shippingInfo.phone"
                            :class="$style.item">
                            <span :class="$style.itemLabel">手机: </span>
                            <span :class="$style.black"> {{ shippingInfo.phone }}</span>
                        </div>
                    </el-col>
                </el-row>
            </div>
        </div>
        <!-- 包裹信息 -->
        <div
            v-for="(packageItem, packageIndex) in packageList"
            :class="$style.packageWrap"
            :key="packageIndex">
            <!-- 头部 -->
            <el-row>
                <el-col :span="12" align="left">
                    <span :class="$style.sectionTitle">包裹{{ packageIndex + 1 }}</span>
                </el-col>
                <el-col :span="12" align="right">
                    <template
                        v-if="packageIndex == packageList.length - 1">
                        <el-button
                            v-if="packageIndex > 0"
                            :disabled="packageItem.delivered"
                            size="small" type="danger"
                            @click="removePackage(packageIndex)">
                            删除包裹
                        </el-button>
                        <el-button
                            size="small" type="primary"
                            @click="addPackage">
                            增加包裹
                        </el-button>
                    </template>
                </el-col>
            </el-row>
            <!-- 内容 -->
            <div :class="$style.section">
                <div :class="$style.sectionLine">
                    <div :class="$style.sectionItem">
                        <div :class="$style.sectionLeble">物流方式: </div>
                        <div :class="$style.sectionItemContent">
                            <el-select
                                v-model="packageItem.logisticsModeIndex"
                                :disabled="packageItem.delivered"
                                placeholder="请选择">
                                <el-option
                                    v-for="(logisticsItem, logisticsIndex) in publicLogistics"
                                    :value="logisticsIndex"
                                    :label="logisticsItem.cnName"
                                    :key="logisticsIndex">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                    <div :class="$style.sectionItem">
                        <div :class="$style.sectionLeble">物流单号: </div>
                        <div :class="$style.sectionItemContent">
                            <el-input
                                :class="$style.inputWidth"
                                :disabled="packageItem.delivered"
                                v-model="packageItem.logisticsNum"
                                maxlength="30"
                                placeholder="请输入"></el-input>
                        </div>
                    </div>
                    <div :class="$style.sectionItem">
                        <a
                            v-if="!packageItem.addtransfer && !packageItem.delivered"
                            :class="$style.sectionItemLink"
                            href="javascript:;"
                            @click="addtransfer(packageItem)">
                            增加转运单号
                        </a>
                    </div>
                </div>
                <!-- 转单号 -->
                <div
                    v-if="packageItem.addtransfer"
                    :class="$style.sectionLine">
                    <div :class="$style.sectionItem"></div>
                    <div :class="$style.sectionItem">
                        <div :class="$style.sectionLeble">转运单号: </div>
                        <div :class="$style.sectionItemContent">
                            <el-input
                                v-model="packageItem.transferNumber"
                                maxlength="30"
                                placeholder="请输入"></el-input>
                        </div>
                    </div>
                    <div :class="$style.sectionItem">
                        <a
                            :class="[$style.sectionItemLink, $style.red]"
                            href="javascript:;"
                            @click="removeTransfer(packageItem)">
                            删除转运单号
                        </a>
                    </div>
                </div>
                <!-- 商品区 -->
                <div
                    v-for="(goodsItem, goodsIndex) in packageItem.goodsList"
                    :key="goodsItem.sku"
                    :class="$style.sectionLine">
                    <div :class="$style.sectionItem">
                        <div :class="$style.sectionLeble">商品编号: </div>
                        <div :class="$style.sectionItemContent">
                            <el-select
                                v-model="goodsItem.sku"
                                :disabled="packageItem.delivered"
                                placeholder="请选择"
                                @change="fillValue(goodsItem)">
                                <el-option
                                    v-for="(value, key) in goodsObj.info"
                                    :value="key"
                                    :label="key"
                                    :disabled="value.added >= value.sum"
                                    :key="key">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                    <div :class="$style.sectionItem">
                        <div :class="$style.sectionLeble">数量: </div>
                        <div :class="$style.sectionItemContent">
                            <el-input-number
                                :disabled="packageItem.delivered"
                                :class="$style.inputWidth"
                                v-model="goodsItem.num"
                                :max="goodsItem.max"
                                :step="1" :min="1"
                                @change="updateGoodsInfo">
                            </el-input-number>
                        </div>
                    </div>
                    <div
                        v-if="goodsIndex == packageItem.goodsList.length - 1"
                        :class="$style.sectionItem">
                        <a
                            v-if="!goodsObj.isSelected && !packageItem.delivered"
                            :class="$style.sectionItemLink"
                            href="javascript:;"
                            @click="addGoods(packageIndex)">
                            增加商品
                        </a>
                        <a
                            v-if="goodsIndex !== 0"
                            :class="[$style.sectionItemLink, $style.red]"
                            href="javascript:;"
                            @click="removeGoods(packageIndex, goodsIndex)">
                            删除商品
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div align="center">
            <el-button @click="backOrderDetail">返回</el-button>
            <el-button type="primary" @click="postExpress">确认</el-button>
        </div>
    </div>
</template>

<script>
    import { deepCopy } from '@/assets/js/utils/types';
    import {
        getExpressBaseInfo,
        postAddExpressPackage,
        getAllLogisticsWay,
        getOrderPackage
    } from '../services';

    export default {
        data() {
            return {
                orderSn: this.$route.params.orderSn,
                // 基础数据
                publicLogistics: [],
                shippingInfo: {},
                goodsObj: {
                    isSelected: false,
                    info: {}
                },
                // 包裹数据
                historyPackList: [],
                packageList: [],
                packageItemData: {
                    logisticsModeIndex: '', // 选中的物流方式
                    logisticsNum: '', // 物流单号
                    addtransfer: false, // 增加转运单号
                    transferNumber: '', // 转运单号
                    goodsList: [{
                        sku: '',
                        max: 10000,
                        num: 1
                    }],
                },
            };
        },
        watch: {
            goodsObj: {
                handler() {
                    let index = 0;
                    let sign = 0;
                    for (const item in this.goodsObj.info) {
                        const thisGoods = this.goodsObj.info[item];
                        index += 1;
                        if (thisGoods.sum <= thisGoods.added) sign += 1;
                    }
                    this.goodsObj.isSelected = sign >= index;
                },
                deep: true
            },
        },
        created() {
            const vm = this;
            // 初始化第一条数据
            vm.$set(vm.packageList, 0, JSON.parse(JSON.stringify(vm.packageItemData)));
            vm.getOrderPackage();
            vm.getDetaileData();
            vm.getLogisticsPlatformWay();
        },
        methods: {
            backOrderDetail() {
                const vm = this;
                vm.$router.push({
                    name: 'OrderDetails',
                    params: { orderSn: vm.orderSn }
                });
            },
            // ----- 数据处理 -----
            addPackage() { // 增加包裹
                if (this.packageList.length < 5) {
                    this.$set(
                        this.packageList,
                        this.packageList.length,
                        deepCopy(this.packageItemData)
                    );
                } else {
                    this.$message.error('最多可添加5个包裹');
                }
            },
            removePackage(index) { // 删除包裹
                this.$delete(this.packageList, index);
                this.updateGoodsInfo();
            },
            addtransfer(packageItem) { // 增加转运单号
                packageItem.addtransfer = true;
            },
            removeTransfer(packageItem) { // 删除转运单号
                packageItem.addtransfer = false;
                packageItem.transferNumber = '';
            },
            addGoods(item) { // 增加商品
                const vm = this;
                const index = vm.packageList[item].goodsList.length;
                this.$set(vm.packageList[item].goodsList, index, { sku: '', num: 1 });
            },
            removeGoods(item, index) { // 删除商品
                this.$delete(this.packageList[item].goodsList, index);
                this.updateGoodsInfo();
            },
            updateGoodsInfo() { // 更新商品数据
                const vm = this;
                // 选中清空重算
                for (const item in vm.goodsObj.info) {
                    vm.goodsObj.info[item].added = 0;
                }
                vm.packageList.forEach((packageItem) => {
                    packageItem.goodsList.forEach((goodsItem) => {
                        if (goodsItem.sku) vm.goodsObj.info[goodsItem.sku].added += goodsItem.num;
                    });
                });
                vm.changeMax();
            },
            changeMax() { // 更新所有最大值
                const vm = this;
                vm.packageList.forEach((packageItem) => {
                    packageItem.goodsList.forEach((goodsItem) => {
                        if (goodsItem.sku) {
                            goodsItem.max = vm.goodsObj.info[goodsItem.sku].sum - vm.goodsObj.info[goodsItem.sku].added + goodsItem.num;
                        } else {
                            goodsItem.max = 0;
                        }
                    });
                });
            },
            fillValue(goodsItem) { // 填充商品数量
                goodsItem.num = 1;
                this.updateGoodsInfo();
                this.$nextTick(() => {
                    goodsItem.num = goodsItem.max;
                    this.updateGoodsInfo();
                });
            },
            // ----- 请求数据 -----
            async getOrderPackage() {
                const params = {
                    orderSn: this.orderSn
                };
                const { status, data } = await getOrderPackage.http({ params });

                if (status === 0) {
                    const packages = data.expressPackageRespList || [];
                    packages.forEach((item) => {
                        const temp = deepCopy(this.packageItemData);
                        temp.delivered = true;
                        temp.logisticsModeIndex = item.logisticsCode;
                        temp.logisticsNum = item.logisticsSn;
                        temp.addtransfer = !!item.transferNumber;
                        temp.transferNumber = item.transferNumber;

                        temp.goodsList = item.packageGoodsList.reduce((acc, goods) => {
                            acc.push({
                                sku: goods.goodsSn,
                                num: goods.qty
                            });
                            return acc;
                        }, []);

                        this.packageList.unshift(temp);
                    });
                    console.log(data);
                }
            },

            async getDetaileData() {
                const vm = this;
                const { status, data } = await getExpressBaseInfo.http({
                    params: {
                        orderSn: vm.orderSn
                    }
                });
                if (status === 0) {
                    vm.shippingInfo = data.shippingInfo;
                    const tempGoodsObj = {};
                    data.goodsInfo.forEach((goodsItem) => {
                        tempGoodsObj[goodsItem.goodsSn] = {
                            sum: goodsItem.totalQty,
                            added: 0,
                        };
                    });
                    vm.$set(vm.goodsObj, 'info', tempGoodsObj);
                } else {
                    vm.backOrderDetail();
                }
            },
            async getLogisticsPlatformWay() { // 请求公共物流方式数据
                const { status, data } = await getAllLogisticsWay.http();
                if (status === 0) {
                    this.publicLogistics = data.list;
                }
            },
            async postExpress() { // 请求登记发货
                const vm = this;
                const packageInfoList = [];
                vm.packageList.forEach(({
                    logisticsModeIndex,
                    logisticsNum,
                    addtransfer,
                    transferNumber,
                    goodsList,
                }) => {
                    if (logisticsModeIndex !== '') {
                        const switchKeyGoods = [];
                        const {
                            thirdLogisticsCode,
                            enName: logisticsName,
                            logisticsLevel,
                            logisticsBusinessCode
                        } = vm.publicLogistics[logisticsModeIndex];

                        goodsList.forEach(({ sku, num }) => {
                            switchKeyGoods.push({ goodsSn: sku, qty: num });
                        });
                        packageInfoList.push({
                            countryCode: vm.shippingInfo.countryCode,
                            logisticsCode: thirdLogisticsCode,
                            logisticsName,
                            logisticsLevel,
                            logisticsBusinessCode,
                            transferNumber,
                            logisticsSn: logisticsNum,
                            orderPackageGoodsList: switchKeyGoods
                        });
                    }
                });
                if (packageInfoList.length <= 0) return;
                const { status } = await postAddExpressPackage.http({
                    data: {
                        orderSn: vm.orderSn,
                        logisticsStatus: 0, // 发货单类型 0-新增；1-作废2-更新
                        packageInfoList
                    }
                });
                if (status === 0) {
                    vm.backOrderDetail();
                }
            },
        }
    };
</script>

<style module>
    .container {
        background-color: #fff;
        padding: 30px 20px;
        min-height: 740px;
    }

    .title {
        font-size: 18px;
        line-height: 25px;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .titleTxt {
        display: inline-block;
        vertical-align: middle;
        line-height: 25px;
        margin-right: 10px;
    }

    .item {
        color: #666;
        font-size: 14px;
        line-height: 24px;
    }

    .black {
        color: #000;
    }

    .red {
        color: #F00;
    }

    /* 订单摘要 */
    .infor {
        margin-bottom: 30px;
    }

    .inforContent {
        border: 1px solid #eee;
        margin-top: 20px;
        padding: 20px;
    }

    .addressBox {
        padding-right: 10px;
    }

    /* 包裹信息 */
    .packageWrap {
        margin-bottom: 30px;
    }

    .sectionTitle {
        line-height: 32px;
        font-size: 18px;
        font-weight: bold;
    }

    .section {
        margin-top: 20px;
        border: 1px solid #EEE;
        padding: 40px 0;
    }

    .sectionLine {
        margin-bottom: 20px;
    }

    .sectionLine:last-child {
        margin-bottom: 0;
    }

    .sectionItem {
        display: inline-block;
        vertical-align: top;
        width: 300px;
        font-size: 0;
    }

    .sectionLeble {
        display: inline-block;
        vertical-align: top;
        text-align: right;
        width: 100px;
        font-size: 14px;
        line-height: 40px;
        margin-right: 20px;
    }

    .sectionItemContent {
        display: inline-block;
        vertical-align: top;
        text-align: left;
        width: 180px;
    }

    .sectionItemLink {
        font-size: 14px;
        line-height: 40px;
        margin-left: 20px;
    }
</style>
