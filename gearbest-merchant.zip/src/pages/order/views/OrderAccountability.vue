<template>
    <div :class="$style.container">
        <div class="header">
            <div :class="$style.tips">
                <el-alert
                    v-if="showTipsWarning"
                    :closable="false"
                    title="请在72小时内进行举证，若超时未进行举证，则默认按照原判责结果执行。"
                    type="warning"
                    show-icon>
                </el-alert>
            </div>
            <div :class="$style.search">
                <el-form label-suffix="：" label-width="90px" inline>
                    <el-form-item label="商品编号">
                        <el-input v-model="search.sku_no"></el-input>
                    </el-form-item>
                    <el-form-item label="判责单号">
                        <el-input v-model="search.service_no"></el-input>
                    </el-form-item>
                    <el-form-item label="订单编号">
                        <el-input v-model="search.order_no"></el-input>
                    </el-form-item>
                    <el-form-item label="发起日期">
                        <el-date-picker
                            v-model="search.start_time"
                            value-format="timestamp"
                            type="datetime">
                        </el-date-picker>
                        至
                        <el-date-picker
                            v-model="search.end_time"
                            value-format="timestamp"
                            type="datetime">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item label="处理状态">
                        <el-select v-model="search.service_status">
                            <el-option
                                v-for="(item, index) in serviceStatus"
                                :key="index"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
                <el-button @click="handleClearSearch">重置</el-button>
                <el-button :loading="searching" type="primary" @click="handleSearch">搜索</el-button>
            </div>
        </div>
        <div class="content">
            <el-table :data="list" border load>
                <el-table-column label="判责服务单号" width="200px">
                    <template slot-scope="scope">
                        <p>单号:
                            <router-link :to="{ name: 'OrderAccountabilityDetail', params: { serviceNo: scope.row.service_no }}">
                                {{ scope.row.service_no }}
                            </router-link>
                        </p>
                        <p>发起时间: {{ dateFormat(scope.row.create_time) }}</p>
                    </template>
                </el-table-column>
                <el-table-column label="商品信息" width="300px">
                    <div slot-scope="scope" :class="$style.goodsCard">
                        <div :class="$style.goodsImage">
                            <img :src="scope.row.goods_image">
                        </div>
                        <div :class="$style.goodsInfo">
                            <a :href="scope.row.goods_url" target="_blank" v-text="scope.row.goods_title"></a>
                            <p>商品编号：{{ scope.row.sku_no }}</p>
                        </div>
                    </div>
                </el-table-column>
                <el-table-column prop="order_no" label="订单号" width="180px">
                    <router-link slot-scope="scope" :to="{ name: 'OrderDetails', params: { orderSn: scope.row.order_no }}">
                        {{ scope.row.order_no }}
                    </router-link>
                </el-table-column>
                <el-table-column label="商品实际退款金额">
                    <template slot-scope="scope">
                        {{ priceFormat(scope.row.sku_refund_total_price) }}
                    </template>
                </el-table-column>
                <el-table-column label="处理状态">
                    <template slot-scope="scope">
                        {{ serviceStatusFormat(scope.row.service_status) }}
                    </template>
                </el-table-column>
                <el-table-column prop="reason" label="判责原因" width="180px"/>
                <el-table-column label="判责结果" width="140px">
                    <template slot-scope="scope">
                        <p v-html="characterFormat(scope.row.result)"></p>
                    </template>
                </el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <router-link
                            v-if="scope.row.is_proofed === 0 && scope.row.service_status === '30'"
                            :to="{ name: 'OrderAccountabilityDetail', params: { serviceNo: scope.row.service_no }}">
                            判责处理
                        </router-link>
                        <router-link
                            v-else
                            :to="{ name: 'OrderAccountabilityDetail', params: { serviceNo: scope.row.service_no }}">
                            查看详情
                        </router-link>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div :class="$style.pagination">
            <el-pagination
                :current-page="search.page"
                :page-sizes="[10, 20, 50]"
                :page-size="search.page_size"
                :total="total"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
            />
        </div>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { deepCopy } from '@/assets/js/utils/types';
    import { serviceOrderAccountability } from '@order/services/accountability.js';

    const serviceStatus = [
        {
            label: '全部',
            value: ''
        },
        {
            label: '待判责',
            value: '10,20,40'
        },
        {
            label: '卖家举证',
            value: '30'
        },
        {
            label: '已完成',
            value: '50'
        }
    ];

    // 搜索参数
    const search = {
        page: 1,
        page_size: 20,
        sku_no: '',
        service_no: '',
        start_time: '',
        end_time: '',
        order_no: '',
        service_status: ''
    };


    export default {
        name: 'OrderAccountability',
        data() {
            return {
                dateFormat,
                serviceStatus,
                search: deepCopy(search),
                list: [],
                total: 0,
                searching: false
            };
        },

        computed: {
            query() {
                const query = this.$route.query;
                return {
                    ...query,
                    // 将其中的两个参数请求转为数字
                    page: +query.page || 1,
                    page_size: +query.page_size || 20
                };
            },
            composeParams() {
                const query = this.query;
                return Object.assign(this.search, query);
            },
            showTipsWarning() {
                return this.list.some(item => item.is_proofed === 0);
            }
        },
        created() {
            this.init();
        },

        methods: {
            init() {
                this.search = Object.assign({}, this.search, this.query);
                this.getOrderAccountability(this.composeParams);
            },
            // 处理分页
            handleSizeChange(val) {
                this.search.page_size = val;
                this.updateRouterQuery({ page_size: val });
                this.getOrderAccountability();
            },

            // 处理页码
            handleCurrentChange(page) {
                this.search.page = page;
                this.updateRouterQuery({ page });
                this.getOrderAccountability();
            },

            async getOrderAccountability() {
                const params = deepCopy(this.composeParams);
                // 毫秒转成秒
                params.end_time /= 1000;
                params.start_time /= 1000;

                const reply = await serviceOrderAccountability.http({ params });
                this.searching = false;

                if (reply.status === 0) {
                    this.list = reply.data.data || [];
                    this.total = +reply.data.total;
                }
            },

            // 将\r\r替换成<br>
            characterFormat(text) {
                if (text) {
                    return text.replace(/\r\n/g, '<br/>');
                }
                return '';
            },

            // 价格格式化
            priceFormat(val) {
                const price = Number(val);
                if (!Number.isNaN(price)) {
                    return `$${price.toFixed(2)}`;
                }
                return '0';
            },

            // 服务状态格式化
            serviceStatusFormat(val) {
                if (val === '30') {
                    return '卖家举证';
                }
                if (val === '50') {
                    return '已完成';
                }
                return '待判责';
            },

            // 更新路由参数
            updateRouterQuery(query) {
                this.$router.replace({
                    name: this.$route.name,
                    query: Object.assign({}, this.$route.query, query)
                });
            },

            // 处理搜索
            handleSearch() {
                if (!this.searching) {
                    this.updateRouterQuery(this.search);
                    this.searching = true;
                    this.getOrderAccountability();
                }
            },

            // 清除搜索
            handleClearSearch() {
                this.search = Object.assign({}, search);
                this.updateRouterQuery(this.search);
                // this.getOrderAccountability();
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .tips {
        margin-bottom: 20px;
    }

    .search {
        margin-bottom: 20px;
    }

    .content {
        margin-bottom: 20px;
    }

    .goodsCard {
        display: flex;
    }

    .goodsImage {
        width: 60px;
        height: 60px;
        flex-shrink: 0;
        margin-right: 20px;
    }

    .goodsImage img {
        width: 100%;
        height: 100%;
    }

    .pagination {
        margin-top: 30px;
        text-align: right;
    }
</style>
