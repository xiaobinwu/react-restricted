<template>
    <div :class="$style.container">
        <div :class="$style.topTip">
            <i :class="['el-icon-warning', $style.tipIcon]"></i>
            <span>{{ $t('order.aftersale.topTip', [5]) }}</span>
        </div>
        <!-- 摘要 -->
        <div>
            <h2 :class="$style.title">{{ $t('order.aftersale.sigest') }}</h2>
            <div :class="$style.abstractInfo">
                <ul :class="$style.abstractInfoBox">
                    <li :class="$style.abstractItem">
                        <span :class="$style.abstractItemTitle">{{ $t('order.aftersale.serviceNumber') }}:</span>
                        <span>{{ detail.serviceNo }}</span>
                    </li>
                    <li :class="$style.abstractItem">
                        <span :class="$style.abstractItemTitle">{{ $t('order.aftersale.orderNumber') }}:</span>
                        <router-link v-if="!!detail.orderSn" :to="{ name: 'OrderDetails', params: { orderSn: detail.orderSn }}" :class="$style.blue">
                            {{ detail.orderSn }}
                        </router-link>
                    </li>
                    <li :class="$style.abstractItem">
                        <span :class="$style.abstractItemTitle">{{ $t('order.aftersale.processingState') }}:</span>
                        <span :class="$style.golden">{{ smsState.serviceStatus[detail.serviceStatus] }}</span>
                    </li>
                    <li :class="$style.abstractItem">
                        <span :class="$style.abstractItemTitle">{{ $t('order.aftersale.serviceType') }}:</span>
                        <span>{{ smsState.serviceType[detail.serviceType] }}</span>
                    </li>
                    <li :class="$style.abstractItem">
                        <span :class="$style.abstractItemTitle">{{ $t('order.aftersale.refundAmount') }}:</span>
                        <span>{{ `$${detail.refundAmount || '0.00'}` }}</span>
                    </li>
                    <li :class="$style.abstractItem">
                        <span :class="$style.abstractItemTitle">{{ $t('order.aftersale.actualRefundAmount') }}:</span>
                        <span :class="$style.warning">{{ `$${detail.realRefundAmount || '0.00'}` }}</span>
                    </li>
                    <!-- 按钮区 -->
                    <li :class="$style.abstractBtn">
                        <el-button
                            v-if="detail.serviceStatus == 30"
                            type="primary"
                            @click="aftersaleAlert">
                            {{ $t('order.aftersale.treatment') }}
                        </el-button>
                        <el-button
                            v-if="detail.serviceType == 1 && detail.serviceStatus == 45"
                            :disabled="disabledServiceStatusBtn"
                            type="primary"
                            @click="confirmReceipt">
                            {{ disabledServiceStatusBtn ? $t('order.aftersale.confirmRseceipted') : $t('order.aftersale.confirmRseceipt') }}
                        </el-button>
                    </li>
                </ul>
                <el-table
                    v-if="detail.packageList.length > 0"
                    :class="$style.abstractGoodsList"
                    :data="detail.packageList"
                    stripe>
                    <el-table-column
                        :label="$t('order.aftersale.goodsNumber')"
                        prop="goods_sn"
                        align="center">
                        <template slot-scope="scope">
                            <a :href="scope.row.goods_url">{{ scope.row.goods_sn }}</a>
                        </template>
                    </el-table-column>
                    <el-table-column
                        :label="$t('order.aftersale.amount')"
                        prop="qty"
                        align="center">
                    </el-table-column>
                    <el-table-column
                        :label="$t('order.aftersale.package')"
                        prop="package_sn"
                        align="center">
                    </el-table-column>
                    <el-table-column
                        :label="$t('order.aftersale.logisticsMode')"
                        prop="logistics_name"
                        align="center">
                    </el-table-column>
                    <el-table-column
                        :label="$t('order.aftersale.logisticsNumber')"
                        prop="logistics_sn"
                        align="center">
                    </el-table-column>
                    <el-table-column
                        :label="$t('order.aftersale.conversionNumber')"
                        prop="transfer_number"
                        align="center">
                        <template slot-scope="scope">
                            {{ scope.row.transfer_number || '-' }}
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <!-- 协商记录 -->
        <div>
            <h2 :class="$style.title">{{ $t('order.aftersale.negotiationProcess') }}</h2>
            <div :class="$style.consultBox">
                <div
                    v-for="(locusItem, locusIndex) in detail.locusList"
                    :key="locusIndex"
                    :class="[
                        locusItem.deal_type == 1 ? $style.buyer : (locusItem.deal_type == 2 ? $style.seller : $style.system),
                        $style.consultItem]">
                    <p :class="$style.consultTitle">
                        {{ `${
                            locusItem.deal_type == 1 ? $t('order.aftersale.buyer') : (
                                locusItem.deal_type == 2 ? $t('order.aftersale.seller') : $t('order.aftersale.platformIntervention')
                            )
                        } ${$t('order.aftersale.at')} ${$dateFormat(locusItem.adddate)}` }}
                    </p>
                    <!-- 买家 卖家 -->
                    <ul
                        v-if="locusItem.deal_type == 1"
                        :class="$style.consultInfo">
                        <li :class="$style.consultInfoItem">
                            <span :class="$style.consultInfoItemLable">{{ $t('order.aftersale.operate_depict') }}:</span>
                            <span :class="$style.consultInfoItemTxt">{{ locusItem.remark }}</span>
                        </li>
                        <li :class="$style.consultInfoItem">
                            <span :class="$style.consultInfoItemLable">{{ $t('order.aftersale.orderNumber') }}:</span>
                            <router-link
                                :to="{ name: 'OrderDetails', params: { orderSn: detail.orderSn }}"
                                :class="[$style.consultInfoItemTxt, $style.blue]">
                                {{ detail.orderSn }}
                            </router-link>
                        </li>
                        <li :class="$style.consultInfoItem">
                            <span :class="$style.consultInfoItemLable">{{ $t('order.aftersale.goodsNumber') }}:</span>
                            <a
                                :href="detail.goodsUrl"
                                :class="[$style.consultInfoItemTxt, $style.blue]"
                                target="_blank">{{ detail.goodsSn }}
                            </a>
                        </li>
                        <li :class="$style.consultInfoItem">
                            <span :class="$style.consultInfoItemLable">{{ $t('order.aftersale.serviceType') }}:</span>
                            <span :class="$style.consultInfoItemTxt">{{ smsState.serviceType[detail.serviceType] }}</span>
                        </li>
                        <li :class="$style.consultInfoItem">
                            <span :class="$style.consultInfoItemLable">{{ $t('order.aftersale.enclosure') }}:</span>
                            <a
                                v-for="(annexItem, annexIndex) in detail.annexList"
                                :key="annexIndex"
                                :href="annexItem"
                                :class="[$style.consultInfoItemTxt, $style.blue, $style.consultInfoItemUrl]">
                                {{ $t('order.aftersale.enclosure') }}{{ annexIndex + 1 }}
                            </a>
                        </li>
                    </ul>
                    <ul v-else-if="locusItem.deal_type == 2">
                        <li :class="$style.consultInfoItem">
                            <span :class="$style.consultInfoItemLable">{{ $t('order.aftersale.operate_depict') }}:</span>
                            <span :class="$style.consultInfoItemTxt">{{ locusItem.remark }}</span>
                        </li>
                    </ul>
                    <div
                        v-else
                        :class="$style.consultInfoSys">
                        {{ locusItem.remark }}
                    </div>
                </div>
            </div>
        </div>
        <!-- 消息记录 | 临时屏蔽-->
        <div id="jumpId"></div>
        <message-log
            :list-data="logData.listData"
            :show-group="false"
            :show-delete="Boolean(msgId)"
            :current-page="logData.currentPage"
            :total="logData.total"
            :page-size="logData.pageSize"
            :page-sizes="logData.pageSizes"
            @setRoute="setRoute"
            @deletLog="deleteLog">
        </message-log>
        <!-- 消息回复 -->
        <message-reply
            v-if="msgId"
            :class="$style.reply"
            :nike-name="replyNickname"
            @sendMSG="sendMessage">
        </message-reply>
        <!-- 弹窗 -->
        <el-dialog
            :visible.sync="isAftersaleAlert"
            :title="$t('order.aftersale.treatment')"
            width="28%">
            <aftersale-treatment
                v-if="isAftersaleAlert"
                :types="afterSaleTreatment.type"
                :is-ship="afterSaleTreatment.isShip"
                :max-amount="afterSaleTreatment.maxAmount"
                @cancleEvent="isAftersaleAlert = false"
                @confrimEvent="treatmentFn">
            </aftersale-treatment>
        </el-dialog>
    </div>
</template>

<script>
    import {
        getAfterSalesDetail,
        changeAftersalesStatus,
        getSmsStatus
    } from '../services/aftersale.js';
    import {
        getMessageList,
        getMessageDelet,
        messageReply
    } from '../services';

    export default {
        name: 'OrderAftersaledetail',
        data() {
            return {
                shopCode: this.$store.state.user.userInfo.defaultShop.shopCode || '',
                // 状态数据映射
                smsState: {
                    serviceType: {},
                    serviceStatus: {},
                },
                // 服务单详情
                detail: {
                    serviceNo: this.$route.params.id,
                    orderSn: '',
                    serviceType: '',
                    serviceStatus: '',
                    refundAmount: '',
                    realRefundAmount: '',
                    goodsSn: '',
                    goodsUrl: '',
                    annexList: [], // 附件地址
                    packageList: [],
                    locusList: []
                },
                isAftersaleAlert: false,
                afterSaleTreatment: {
                    type: 0,
                    isShip: '',
                    maxAmount: 0,
                    submitInfo: null,
                },
                // 消息记录
                msgId: '',
                replyNickname: '',
                logData: {
                    listData: [],
                    currentPage: 1,
                    total: 0,
                    pageSize: 10,
                    pageSizes: [10, 20, 30]
                },
                disabledServiceStatusBtn: false
            };
        },
        watch: {
            $route(to, from) {
                this.mergeParam();
            },
        },
        created() {
            const vm = this;
            // 请求 SMS 状态映射表
            getSmsStatus.http().then((smsData) => {
                const { status, data } = smsData;
                if (status === 0) {
                    vm.smsState.serviceType = data.ServiceType;
                    vm.smsState.serviceStatus = data.ServiceStatus;
                }
            });
            vm.getDetailInfo();
        },
        methods: {
            treatmentFn(data) {
                const vm = this;
                const reqDat = Object.assign(vm.afterSaleTreatment.submitInfo, data);
                vm.changeStatus(reqDat);
            },
            aftersaleAlert() {
                const vm = this;
                vm.isAftersaleAlert = true;
                vm.afterSaleTreatment.type = vm.detail.serviceType;
                vm.afterSaleTreatment.isShip = vm.detail.isShip;
                vm.afterSaleTreatment.maxAmount = vm.detail.refundAmount;
                vm.afterSaleTreatment.submitInfo = {
                    merchant_no: vm.detail.goodsSn,
                    service_no: vm.detail.serviceNo
                };
            },
            confirmReceipt() {
                const vm = this;
                vm.$alert(vm.$t('order.aftersale.confirmRseceiptTip'), vm.$t('order.aftersale.confirmRseceipt'), {
                    confirmButtonText: vm.$t('order.aftersale.confirm'),
                }).then(() => {
                    vm.changeStatus({
                        action: 'confirm',
                        merchant_no: vm.detail.goodsSn,
                        service_no: vm.detail.serviceNo,
                        service_type: vm.detail.serviceType
                    }).then((data) => {
                        this.disabledServiceStatusBtn = true;
                    });
                }).catch(() => {
                    // console.log('已取消')
                });
            },
            toMsgBlock() {
                const jump = document.getElementById('jumpId');
                const total = jump.offsetTop;
                document.body.scrollTop = total;
                document.documentElement.scrollTop = total;
                window.pageYOffset = total;
            },
            // ----- 请求数据 -----
            async getDetailInfo() {
                const vm = this;
                const { status, data } = await getAfterSalesDetail.http({
                    loading: true,
                    params: {
                        service_no: this.detail.serviceNo
                    }
                });
                if (status === 0) {
                    Object.assign(vm.detail, {
                        orderSn: data.order_no,
                        serviceType: data.service_type,
                        serviceStatus: data.service_status,
                        refundAmount: data.refund_amount,
                        realRefundAmount: data.real_refund_amount,
                        goodsSn: data.sku,
                        goodsUrl: data.goods_url,
                        annexList: data.annex_list,
                        locusList: data.locus,
                        packageList: data.package_info,
                        isShip: data.is_ship
                    });
                    // 调取消息记录
                    vm.mergeParam();
                } else {
                    vm.$router.push({ name: 'OrderAftersale' });
                }

                // 点击名称跳转
                if (vm.$route.params.jump) {
                    vm.$nextTick(() => {
                        vm.toMsgBlock();
                    });
                }
            },
            async changeStatus(params) {
                const vm = this;
                const { status } = await changeAftersalesStatus.http({
                    loading: true,
                    data: params
                });
                if (status === 0) {
                    vm.isAftersaleAlert = false;
                    vm.mergeParam();
                    return Promise.resolve();
                }
                return Promise.reject();
            },
            // ----- 消息记录 -----
            setRoute(queryData) { // 将参数写入路由
                const vm = this;
                vm.$router.push({
                    name: 'OrderAftersaledetail',
                    query: queryData
                });
            },
            mergeParam() { // 从路由读取参数
                const vm = this;
                const urlQuery = vm.$route.query || {};
                // 根据链接参数初始化默认值
                vm.getMessageList({
                    shopCode: vm.shopCode,
                    page: +urlQuery.currentPage || 1,
                    pageSize: +urlQuery.pageSize || 10,
                    orderNumber: vm.detail.orderSn,
                });
            },
            async getMessageList(params) { // 列表数据
                const vm = this;
                const { status, data } = await getMessageList.http({
                    loading: true,
                    params
                });
                if (status === 0) {
                    const dataArr = [];
                    vm.msgId = data.id;
                    vm.replyNickname = data.nick_name;
                    // 消息记录数据结构标准格式化
                    data.data.forEach((item) => {
                        dataArr.push({
                            title: '',
                            time: item.create_time,
                            primary: item.message_type === 1 ? 1 : 2,
                            nickname: +item.message_type === 1 ? vm.$t('order.module.message.me') : (
                                +item.message_type === 2 ? vm.replyNickname : vm.$t('order.module.message.system')),
                            contentType: item.content_type,
                            content: item.content,
                            groupType: 2, // 写死为订单
                            groupValue: params.orderNumber,
                            goodsInfo: null,
                        });
                    });
                    // 翻页器数据保存
                    Object.assign(vm.logData, {
                        listData: dataArr,
                        total: status === 0 ? data.total : 0,
                        currentPage: params.page,
                        pageSize: +params.pageSize,
                    });
                    // 异常情况特殊处理
                    if (data.total > 0 && vm.logData.listData.length <= 0) vm.setRoute();
                }
            },
            async deleteLog() {
                const vm = this;
                const { status, msg } = await getMessageDelet.http({
                    data: {
                        id: vm.msgId,
                        shopCode: vm.shopCode
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                vm.mergeParam();
            },
            async sendMessage(sendData, success, error) { // 回复消息
                const vm = this;
                const reqData = {
                    id: vm.msgId,
                    shopCode: vm.shopCode,
                    sourceType: 2,
                    sourceTypeValue: vm.detail.orderSn,
                };
                const reqArr = [];
                if (sendData.textarea) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.textarea,
                        contentType: 1
                    }));
                }
                if (sendData.files && sendData.files[0]) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.files[sendData.files.length - 1],
                        contentType: 2
                    }));
                }
                const servicesArr = [];
                reqArr.forEach((item) => {
                    servicesArr.push(new Promise(async (resolve) => {
                        resolve(await messageReply.http({
                            errorPorp: false,
                            isCancel: false,
                            loading: true,
                            data: item,
                        }));
                    }));
                });
                const response = await Promise.all(servicesArr);
                let status = 0;
                let msg = '';
                response.forEach((resItem) => {
                    status += resItem.status;
                    msg = resItem.msg;
                });
                if (status === 0) {
                    success(msg);
                    vm.mergeParam();
                } else {
                    error(msg);
                }
            },
        }
    };
</script>

<style module>
    .container {
        background: #fff;
        padding: 30px 20px;
        min-height: 740px;
    }

    .topTip {
        line-height: 32px;
        padding: 0 10px;
        border: 1px solid #FFEBCC;
        border-radius: 4px;
        background: #FFF5E6;
        color: #666666;
        margin-bottom: 20px;
    }

    .tipIcon {
        color: #FFB403;
    }

    .title {
        line-height: 50px;
        font-size: 18px;
        color: #000;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .blue {
        color: #2774FF;
    }

    .golden {
        color: #F6A92A;
    }

    .warning {
        color: #FF0000;
    }

    /* 摘要 */
    .abstractInfo {
        border: 1px solid #eee;
        padding: 20px 19px;
        margin-bottom: 20px;
    }

    .abstractInfoBox {
        position: relative;
    }

    .abstractBtn {
        position: absolute;
        top: 50%;
        right: 40px;
        transform: translateY(-50%);
    }

    .abstractGoodsList {
        margin-top: 10px;
    }

    .abstractItem {
        line-height: 26px;
        font-size: 14px;
        color: #000;
    }

    .abstractItemTitle {
        display: inline-block;
        vertical-align: top;
        text-align: right;
        width: 90px;
        margin-right: 8px;
        color: #999;
    }

    /* 协商 */
    .consultBox {
        border: 1px solid #eee;
        margin-bottom: 20px;
    }

    .consultItem {
        padding: 20px 19px;
        border-bottom: 1px solid #eee;
    }

    .consultItem:last-child {
        border-bottom: 0;
    }

    .seller {
        background: #FAFAFA;
    }

    .system {
        background: #F7FBFF;
    }

    .consultTitle {
        line-height: 30px;
        color: #000;
    }

    .consultInfoItem {
        line-height: 26px;
        font-size: 14px;
        color: #000;
    }

    .consultInfoItemLable {
        display: inline-block;
        vertical-align: top;
        text-align: right;
        width: 90px;
        margin-right: 8px;
        color: #999;
    }

    .consultInfoItemTxt {
        display: inline-block;
        vertical-align: top;
        text-align: left;
        max-width: 700px;
    }

    .consultInfoItemUrl {
        margin-right: 8px;
    }

    .consultInfoSys {
        padding: 5px 20px;
        line-height: 20px;
        color: #999;
    }
</style>
