<!-- 全部 -->
<template>
    <div :class="$style.container">
        <!-- 进度条 -->
        <div
            v-if="tabState > 0"
            :class="$style.stepBlock">
            <el-steps :active="tabState" simple>
                <el-step
                    v-for="(step, index) in stateStore.stepTitle"
                    :title="step" :key="index">
                </el-step>
            </el-steps>
        </div>
        <!-- 订单摘要 -->
        <div :class="$style.abstractBlock">
            <h3 :class="$style.title">订单摘要</h3>
            <div :class="$style.abstractContent">
                <div :class="$style.item">
                    <span :class="$style.itemLabel">订单编号：</span>
                    <span :class="$style.black">{{ detailData.orderSn }}</span>
                </div>
                <div :class="$style.item">
                    <span :class="$style.itemLabel">case状态：</span>
                    <span :class="$style.black">
                        {{ stateStore.caseStatus[detailData.caseStatus] || detailData.caseStatus }}
                    </span>
                </div>
                <div :class="$style.item">
                    <span :class="$style.itemLabel">订单状态：</span>
                    <span :class="$style.orange">
                        {{ stateStore.orderStatusSequ[detailData.orderStatusSequ] || detailData.orderStatusSequ }}
                    </span>
                </div>
                <div :class="$style.item">
                    <span :class="$style.itemLabel">支付方式：</span>
                    <span :class="$style.black">{{ detailData.payChannel }}</span>
                </div>
                <div :class="$style.abstractBtn">
                    <!-- 退款处理 判断条件：完全支付payStatus=3 取消申请中orderStatus=5 未审核过 checkStatus=0 -->
                    <el-button
                        v-if="detailData.payStatus == 3 && detailData.checkStatus == 0 && detailData.orderStatus == 5"
                        type="primary"
                        @click="refundMoney(detailData.orderSn)">
                        退款处理
                    </el-button>
                    <!-- 发货登记：(待配货、部分配货、待发货、部分发货) 且 不为FBG(入仓) -->
                    <el-button
                        v-if="[2, 13, 3, 14].includes(detailData.orderStatusSequ) && detailData.deliveryType != 2"
                        type="primary"
                        @click="$router.push({ name: 'OrderDeliveryregistered', params: { orderSn: detailData.orderSn } })">
                        发货登记
                    </el-button>
                </div>
            </div>
        </div>
        <!-- tab -->
        <el-tabs :class="$style.tabsBlock" type="border-card">
            <!-- 订单详情 -->
            <el-tab-pane label="订单详情">
                <div :class="$style.tabsSection">
                    <h3 :class="$style.title">买家信息</h3>
                    <div :class="$style.item">
                        <span>买家昵称：</span>
                        <span :class="$style.black">{{ orderDetail.address.firstName }} {{ orderDetail.address.lastName }}</span>
                    </div>
                </div>
                <div :class="$style.tabsSection">
                    <div :class="$style.title">
                        <span :class="$style.titleTxt">收货信息</span>
                        <el-button
                            :class="$style.copyBtn"
                            type="primary" size="mini"
                            @click="copyAddress">
                            复制
                        </el-button>
                        <input id="copyTxt" style="opacity: 0; position: fixed; left: -999px; bottom: -999px;">
                    </div>
                    <el-row>
                        <el-col :span="8" :class="$style.addressBox">
                            <div
                                v-if="orderDetail.address.lastName"
                                :class="$style.item">
                                <span>收货人姓：</span>
                                <span :class="$style.black">{{ orderDetail.address.lastName }}</span>
                            </div>
                            <div
                                v-if="orderDetail.address.firstName"
                                :class="$style.item">
                                <span>收货人名：</span>
                                <span :class="$style.black">{{ orderDetail.address.firstName }}</span>
                            </div>
                            <div
                                v-if="orderDetail.address.middleName"
                                :class="$style.item">
                                <span>中间名：</span>
                                <span :class="$style.black">{{ orderDetail.address.middleName }}</span>
                            </div>
                            <div
                                v-if="orderDetail.address.country || orderDetail.address.province || orderDetail.address.city"
                                :class="$style.item">
                                <span>国家, 省/区/州, 城市：</span>
                                <span :class="$style.black">
                                    {{ orderDetail.address.country }}, {{ orderDetail.address.province }}, {{ orderDetail.address.city }}
                                </span>
                            </div>
                            <div
                                v-if="orderDetail.address.addressLine1"
                                :class="$style.item">
                                <span>地址1：</span>
                                <span :class="$style.black">{{ orderDetail.address.addressLine1 }}</span>
                            </div>
                            <div
                                v-if="orderDetail.address.addressLine2"
                                :class="$style.item">
                                <span>地址2：</span>
                                <span :class="$style.black">{{ orderDetail.address.addressLine2 }}</span>
                            </div>
                        </el-col>
                        <el-col :span="16">
                            <div
                                v-if="orderDetail.address.addressLine3"
                                :class="$style.item">
                                <span>备用地址1：</span>
                                <span :class="$style.black">{{ orderDetail.address.addressLine3 }}</span>
                            </div>
                            <div
                                v-if="orderDetail.address.addressLine4"
                                :class="$style.item">
                                <span>备用地址2：</span>
                                <span :class="$style.black">{{ orderDetail.address.addressLine4 }}</span>
                            </div>
                            <div
                                v-if="orderDetail.address.postalCode"
                                :class="$style.item">
                                <span>邮编：</span>
                                <span :class="$style.black">{{ orderDetail.address.postalCode }}</span>
                            </div>
                            <div
                                v-if="orderDetail.address.phone"
                                :class="$style.item">
                                <span>手机：</span>
                                <span :class="$style.black">{{ orderDetail.address.phone }}</span>
                            </div>
                        </el-col>
                    </el-row>
                </div>
                <div :class="$style.tabsSection">
                    <h3 :class="$style.title">商品清单</h3>
                    <el-table :data="orderDetail.goodsList">
                        <el-table-column
                            :index="handleTableIndex"
                            label="序号"
                            type="index"
                            align="center">
                        </el-table-column>
                        <el-table-column
                            label="商品信息"
                            width="250"
                            align="center">
                            <template slot-scope="scope">
                                <div :class="$style.goodsMsg">
                                    <img :src="scope.row.goodImage" :class="$style.goodsMsgImg" />
                                    <div :class="$style.goodsMsgWrap">
                                        <a
                                            :class="$style.goodsMsgTitle"
                                            :href="scope.row.goodsUrl"
                                            target="_blank">
                                            {{ scope.row.goodName }}
                                        </a>
                                        <p>编号：{{ scope.row.goodsSn }}</p>
                                        <p>属性：{{ scope.row.color }}</p>
                                        <p>尺码：{{ scope.row.size }}</p>
                                        <p>单价：{{ scope.row.price }}</p>
                                        <p>数量：{{ scope.row.qty }}</p>
                                    </div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column label="备注" prop="goodsMark" align="center"></el-table-column>
                        <el-table-column
                            label="运费模板"
                            prop="extendList"
                            align="center">
                            <template slot-scope="scope">
                                <span v-for="(item, index) in scope.row.extendList" :key="index">
                                    模板{{ item.sellerTemplateId }}{{ scope.row.extendList.length - 1 > index ? ',' : '' }}
                                </span>
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="物流分组"
                            prop="logisticsLevel"
                            align="center">
                            <template slot-scope="scope">
                                {{ stateStore.logisticsLevel[scope.row.logisticsLevel] || scope.row.logisticsLevel }}
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="运费"
                            prop="shippingAmount"
                            align="center">
                            <template slot-scope="scope">
                                ${{ scope.row.shippingAmount }}
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="优惠"
                            prop="discountAmount"
                            align="center">
                            <template slot-scope="scope">
                                ${{ scope.row.discountAmount }}
                            </template>
                        </el-table-column>
                        <el-table-column
                            label="订单金额"
                            prop="orderAmount"
                            align="center">
                            <template slot-scope="scope">
                                ${{ scope.row.orderAmount }}
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </el-tab-pane>
            <!-- 时间记录 -->
            <el-tab-pane label="时间记录">
                <div :class="$style.tabsSection">
                    <h3 :class="$style.title">时间记录</h3>
                    <div :class="$style.timeBlock">
                        <div v-for="(time, index) in timeLog" :class="$style.logStep" :key="index">
                            {{ time.logNote }}: {{ $dateFormat(time.logTime) }}
                        </div>
                    </div>
                </div>
            </el-tab-pane>
            <!-- 物流追踪 -->
            <el-tab-pane
                v-if="[14, 10, 5, 18].includes(detailData.orderStatusSequ)"
                :label="`物流追踪`">
                <!-- 包裹信息 -->
                <div>
                    <el-button
                        v-for="(logTrackItem, indlogTrackIndex) in logistics.trackData"
                        :key="indlogTrackIndex"
                        :type="logistics.active === indlogTrackIndex ? 'primary' : ''"
                        size="mini"
                        @click="getTrackShipping(logTrackItem.logisticsSn, logTrackItem.transferNumber, indlogTrackIndex)">
                        包裹{{ indlogTrackIndex + 1 }}
                    </el-button>
                </div>
                <h4 :class="$style.logisticsTitle">物流信息</h4>
                <div
                    v-if="logistics.trackData[logistics.active]">
                    <table
                        :class="$style.logisticsTable"
                        cellpadding="0" cellspacing="0">
                        <tr>
                            <td :class="$style.logisticsTableTd">商品编号</td>
                            <td
                                v-for="(goodsItem, goodsIndex) in logistics.trackData[logistics.active].packageGoodsList"
                                :key="goodsIndex"
                                :class="$style.logisticsTableTd">
                                {{ goodsItem.goodsSn }}
                            </td>
                        </tr>
                        <tr>
                            <td :class="$style.logisticsTableTd">商品数量</td>
                            <td
                                v-for="(goodsItem, goodsIndex) in logistics.trackData[logistics.active].packageGoodsList"
                                :key="goodsIndex"
                                :class="$style.logisticsTableTd">
                                {{ goodsItem.qty }}
                            </td>
                        </tr>
                    </table>

                    <div :class="$style.logisticsInfo">
                        <div :class="$style.item">
                            <span>物流方式: </span>
                            <span :class="$style.black">{{ logistics.trackData[logistics.active].logisticsName }}</span>
                            <a
                                v-if="logistics.trackData[logistics.active].transferNumber"
                                href="javascript:;"
                                @click="logistics.dialog = true">
                                增加转运单号
                            </a>
                        </div>
                        <div :class="$style.item">
                            <span>物流单号: </span>
                            <span :class="$style.black">{{ logistics.trackData[logistics.active].logisticsSn }}</span>
                        </div>
                        <div :class="$style.item">
                            <span>物流状态: </span>
                            <span :class="$style.black">{{ stateStore.logisticsStatus[logistics.trackData[logistics.active].logisticsStatus] }}</span>
                        </div>
                    </div>
                    <!-- 包裹轨迹 -->
                    <div>
                        <div
                            v-for="(trace, index) in logistics.traceLog"
                            :key="index"
                            :class="$style.logStep">
                            {{ trace.ondate }} <span :class="$style.logisticsStep">{{ trace.status }}</span>
                        </div>
                    </div>
                </div>
            </el-tab-pane>
        </el-tabs>
        <!-- 增加转运单号 -->
        <el-dialog
            :visible.sync="logistics.dialog"
            title="包裹一转运单号"
            width="28%">
            <div :class="$style.transferItem">
                <span :class="$style.transferItemLabel">填写转运单号：</span>
                <div :class="$style.transferItemValue">
                    <el-input
                        v-model="logistics.transferNumber"
                        :class="$style.transferItemInput"
                        placeholder="请输入单号">
                    </el-input>
                </div>
            </div>
            <div slot="footer" align="center">
                <el-button @click="logistics.dialog = false">取消</el-button>
                <el-button type="primary" @click="sureTransfer">确定</el-button>
            </div>
        </el-dialog>
        <!-- 消息记录 -->
        <div id="jumpId"></div>
        <message-log
            :list-data="logData.listData"
            :show-group="false"
            :show-delete="Boolean(msgId)"
            :current-page="logData.currentPage"
            :total="logData.total"
            :page-size="logData.pageSize"
            :page-sizes="logData.pageSizes"
            @setRoute="setRoute"
            @deletLog="deleteLog">
        </message-log>
        <!-- 消息回复 -->
        <message-reply
            v-if="msgId"
            :class="$style.reply"
            :nike-name="replyNickname"
            @sendMSG="sendMessage">
        </message-reply>

        <!-- 弹出层内容 -->
        <el-dialog
            :visible.sync="dialogTableVisible"
            :title="$t('order.list.refundProcess')"
            width="450px">
            <div :class="$style.refundItem">
                <span :class="$style.refundItemLabel">{{ $t('order.list.refundReason') }}：</span>
                <div :class="$style.refundItemValue">
                    {{ $t('order.list.notNeed') }}
                </div>
            </div>
            <div :class="$style.refundItem">
                <span :class="[$style.refundItemLabel, $style.refundItemLabelRequier]">{{ $t('order.list.select') }}：</span>
                <div :class="$style.refundItemValue">
                    <el-radio v-model="refundSelect" :label="1">{{ $t('order.list.accept') }}</el-radio>
                    <el-radio v-model="refundSelect" :label="2">{{ $t('order.list.refused') }}</el-radio>
                </div>
            </div>
            <div v-if="refundSelect === 2" :class="$style.refundItem">
                <span :class="[$style.refundItemLabel, $style.refundItemLabelRequier]">{{ $t('order.list.reasonThat') }}：</span>
                <div :class="$style.refundItemValue">
                    <el-select v-model="refuseReason">
                        <el-option
                            v-for="(value, key) in stateStore.returnReason"
                            :label="value"
                            :value="key"
                            :key="key">
                        </el-option>
                    </el-select>
                </div>
            </div>
            <div slot="footer" align="center">
                <el-button @click="dialogTableVisible = false">{{ $t('order.list.cancel') }}</el-button>
                <el-button type="primary" @click="sureRefund">
                    {{ refundSelect === 2 ? $t('order.list.sureDelivery') : $t('order.list.sure') }}
                </el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import {
        getOrderDetail,
        getOrderPackage,
        getOrderTrackShipping,
        setAddTransferNumber,
        getMessageList,
        getMessageDelet,
        messageReply,
        auditCancelOrder,
    } from '../services';
    import { getOrderStatus } from '../utils/statusStore.js';

    export default {
        name: 'OrderDetails',
        data() {
            return {
                shopCode: this.$store.state.user.userInfo.defaultShop.shopCode || '',
                // 状态映射数据
                stateStore: {
                    stepTitle: ['待付款', '待发货', '待收货', '已完成'], // 步骤条
                    orderStatusSequ: {},
                    caseStatus: {},
                    logisticsLevel: {},
                    logisticsStatus: {},
                    returnReason: {},
                },
                // 订单摘要数据
                detailData: {
                    orderSn: this.$route.params.orderSn,
                    caseStatus: '',
                    payChannel: '',
                    deliveryType: '',
                    orderStatusSequ: '', // 组合展示状态
                    // 各个维度 - 单一状态
                    payStatus: '', // 支付状态
                    orderStatus: '', // 订单
                    checkStatus: '', // 审核
                },
                // tab - 订单详情数据
                orderDetail: {
                    address: {},
                    goodsList: []
                },
                // tab - 时间记录
                timeLog: [],
                // tab - 物流追踪
                logistics: {
                    transferNumber: '', // 填写转运单号
                    dialog: false,
                    active: 0,
                    trackData: [], // 包裹数据
                    traceLog: [], // 包裹轨迹
                },
                // 消息记录
                msgId: '',
                replyNickname: '',
                logData: {
                    listData: [],
                    currentPage: 1,
                    total: 0,
                    pageSize: 10,
                    pageSizes: [10, 20, 30]
                },
                // 弹窗数据 - 退款申请
                dialogTableVisible: false,
                refundOrderSn: '',
                refundSelect: 1,
                refuseReason: '',
            };
        },
        computed: {
            tabState() {
                let status = -1;
                // 待付款
                if ([1, 12, 11].includes(this.detailData.orderStatusSequ)) status = 0;
                // 待发货
                if ([17, 2, 13, 3, 14].includes(this.detailData.orderStatusSequ)) status = 1;
                // 待收货
                if ([10].includes(this.detailData.orderStatusSequ)) status = 3;
                // 已完成
                if ([5, 18].includes(this.detailData.orderStatusSequ)) status = 4;
                return status;
            },
        },
        watch: {
            $route(to, from) {
                this.mergeParam();
            },
        },
        created() {
            const vm = this;
            // 获取状态映射数据
            getOrderStatus([
                'orderStatusSequ', 'caseStatus', 'logisticsLevel', 'logisticsStatus',
                'returnReason'
            ]).then((resolved) => {
                vm.stateStore.caseStatus = resolved.caseStatus;
                vm.stateStore.orderStatusSequ = resolved.orderStatusSequ;
                vm.stateStore.logisticsLevel = resolved.logisticsLevel;
                vm.stateStore.logisticsStatus = resolved.logisticsStatus;
                vm.stateStore.returnReason = resolved.returnReason;
            });
            vm.getOrderDetail();
        },
        methods: {
            copyAddress() {
                const vm = this;
                let sign = 0;
                let msg = '';
                const copyTemplate = `收件姓：${
                    vm.orderDetail.address.lastName || ''
                }；收件人名：${
                    vm.orderDetail.address.firstName || ''
                }；国家、省/区/州、城市：${
                    vm.orderDetail.address.country || ''
                }、${
                    vm.orderDetail.address.province || ''
                }、${
                    vm.orderDetail.address.city || ''
                }；地址1：${
                    vm.orderDetail.address.addressLine1 || ''
                }；地址2：${
                    vm.orderDetail.address.addressLine2 || ''
                }；备用地址1：${
                    vm.orderDetail.address.addressLine3 || ''
                }；备用地址2：${
                    vm.orderDetail.address.addressLine4 || ''
                }；邮编${
                    vm.orderDetail.address.email || ''
                }；手机号：${
                    vm.orderDetail.address.phone || ''
                }；`;
                const cpt = document.getElementById('copyTxt');
                cpt.value = copyTemplate;
                cpt.select();
                try {
                    if (document.execCommand('copy', false, null)) {
                        cpt.value = '';
                        sign = 1;
                        msg = '复制成功';
                    } else {
                        sign = 0;
                        msg = '浏览器不可用复制';
                    }
                } catch (err) {
                    sign = 1;
                    msg = err;
                }
                vm.$message({
                    type: sign === 1 ? 'success' : 'error',
                    message: msg
                });
            },
            refundMoney(orderSn) {
                this.dialogTableVisible = true;
                this.refundOrderSn = orderSn;
            },
            handleTableIndex(index) {
                return index + 1;
            },
            toMsgBlock() {
                const jump = document.getElementById('jumpId');
                const total = jump.offsetTop;
                document.body.scrollTop = total;
                document.documentElement.scrollTop = total;
                window.pageYOffset = total;
            },
            // ---- 请求数据 ----
            async getOrderDetail() {
                const vm = this;
                const { status, data } = await getOrderDetail.http({
                    params: {
                        orderSn: vm.detailData.orderSn
                    }
                });
                if (status === 0) {
                    // 摘要信息
                    Object.assign(vm.detailData, {
                        caseStatus: data.caseStatus,
                        payChannel: data.payChannel,
                        deliveryType: data.deliveryType,
                        orderStatusSequ: data.orderStatusSequ,
                        payStatus: data.payStatus,
                        orderStatus: data.orderStatus,
                        checkStatus: data.checkStatus,
                    });
                    // tab - 订单详情数据
                    vm.orderDetail.address = data.orderAddressResp;
                    const goodsListArr = [];
                    data.orderGoodsRespList.forEach((item) => {
                        goodsListArr.push({
                            goodName: item.goodName,
                            goodsSn: item.goodsSn,
                            goodsUrl: item.goodsUrl,
                            goodImage: item.imgUrl,
                            color: item.goodsAttrResp.color,
                            size: item.goodsAttrResp.size,
                            price: item.price,
                            qty: item.qty,
                            goodsMark: item.goodsMark,
                            logisticsLevel: data.logisticsLevel,
                            shippingAmount: data.shippingAmount,
                            discountAmount: data.discountAmount,
                            orderAmount: data.orderAmount,
                            extendList: item.orderGoodsExtendRespList, // 特殊处理
                        });
                    });
                    vm.orderDetail.goodsList = goodsListArr;
                    // tab - 时间记录
                    vm.timeLog = data.orderLogResp;

                    // 获取订单包裹
                    if (![0].includes(vm.detailData.orderStatusSequ)) {
                        vm.getLogisticsTrack();
                    }

                    // 请求消息记录
                    vm.mergeParam();
                }

                // 点击名称跳转
                if (vm.$route.params.jump) {
                    vm.$nextTick(() => {
                        vm.toMsgBlock();
                    });
                }
            },
            async getLogisticsTrack() { // 获取订单包裹
                const vm = this;
                const { status, data } = await getOrderPackage.http({
                    params: {
                        orderSn: vm.detailData.orderSn
                    }
                });
                if (status === 0) {
                    vm.logistics.trackData = data.expressPackageRespList || [];
                    const fristTrackData = vm.logistics.trackData[0];
                    if (fristTrackData) vm.getTrackShipping(fristTrackData.logisticsSn, fristTrackData.transferNumber);
                }
            },
            async getTrackShipping(logisticsSn, transferNumber, index = 0) { // 获取物流轨迹
                const vm = this;
                vm.logistics.active = index;
                const { status, data } = await getOrderTrackShipping.http({
                    params: {
                        logisticsSn,
                        transferNumber
                    }
                });
                if (status === 0) {
                    this.logistics.traceLog = data || [];
                }
            },
            async sureTransfer() {
                const vm = this;
                vm.logistics.dialog = false;
                const { status } = await setAddTransferNumber.http({
                    params: {
                        orderSn: vm.detailData.orderSn,
                        packageSn: vm.logistics.trackData[vm.logistics.active].packageSn,
                        transferNumber: vm.logistics.transferNumber
                    }
                });
                if (status === 0) {
                    // 重新查询包裹信息
                    vm.getLogisticsTrack();
                }
            },
            async sureRefund() { // 确定退款
                const vm = this;
                if (vm.refundSelect === 2 && vm.refuseReason !== 0 && !vm.refuseReason) { // 拒绝原因必填
                    vm.$message({
                        type: 'error',
                        message: '请选择原因说明'
                    });
                    return;
                }
                vm.dialogTableVisible = false;
                const { status, msg } = await auditCancelOrder.http({
                    params: {
                        orderSn: vm.refundOrderSn,
                        status: vm.refundSelect,
                        msg: vm.refuseReason
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                if (status === 0) {
                    if (vm.refundSelect === 2) {
                        vm.$router.push({
                            name: 'OrderDeliveryregistered',
                            params: {
                                orderSn: vm.refundOrderSn
                            }
                        });
                    } else {
                        vm.$router.push({
                            name: 'OrderDetails',
                            params: { orderSn: vm.refundOrderSn }
                        });
                    }
                }
            },
            // ----- 消息记录 -----
            setRoute(queryData) { // 将参数写入路由
                const vm = this;
                vm.$router.push({
                    name: 'OrderDetails',
                    query: queryData
                });
            },
            mergeParam() { // 从路由读取参数
                const vm = this;
                const urlQuery = vm.$route.query || {};
                // 根据链接参数初始化默认值
                vm.getMessageList({
                    shopCode: vm.shopCode,
                    page: +urlQuery.currentPage || 1,
                    pageSize: +urlQuery.pageSize || 10,
                    orderNumber: vm.detailData.orderSn,
                });
            },
            async getMessageList(params) { // 列表数据
                const vm = this;
                const { status, data } = await getMessageList.http({
                    loading: true,
                    params
                });
                if (status === 0) {
                    const dataArr = [];
                    vm.msgId = data.id;
                    vm.replyNickname = data.nick_name;
                    // 消息记录数据结构标准格式化
                    data.data.forEach((item) => {
                        dataArr.push({
                            title: '',
                            time: item.create_time,
                            primary: item.message_type === 1 ? 1 : 2,
                            nickname: +item.message_type === 1 ? vm.$t('order.module.message.me') : (
                                +item.message_type === 2 ? vm.replyNickname : vm.$t('order.module.message.system')),
                            contentType: item.content_type,
                            content: item.content,
                            groupType: 2, // 写死为订单
                            groupValue: params.orderNumber,
                            goodsInfo: null,
                        });
                    });
                    // 翻页器数据保存
                    Object.assign(vm.logData, {
                        listData: dataArr,
                        total: status === 0 ? data.total : 0,
                        currentPage: params.page,
                        pageSize: +params.pageSize,
                    });
                    // 异常情况特殊处理
                    if (data.total > 0 && vm.logData.listData.length <= 0) vm.setRoute();
                }
            },
            async deleteLog() {
                const vm = this;
                const { status, msg } = await getMessageDelet.http({
                    data: {
                        id: vm.msgId,
                        shopCode: vm.shopCode
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                vm.mergeParam();
            },
            async sendMessage(sendData, success, error) { // 回复消息
                const vm = this;
                const reqData = {
                    id: vm.msgId,
                    shopCode: vm.shopCode,
                    sourceType: 2,
                    sourceTypeValue: vm.detailData.orderSn,
                };
                const reqArr = [];
                if (sendData.textarea) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.textarea,
                        contentType: 1
                    }));
                }
                if (sendData.files && sendData.files[0]) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.files[sendData.files.length - 1],
                        contentType: 2
                    }));
                }

                const servicesArr = [];
                reqArr.forEach((item) => {
                    servicesArr.push(new Promise(async (resolve) => {
                        resolve(await messageReply.http({
                            errorPorp: false,
                            isCancel: false,
                            loading: true,
                            data: item,
                        }));
                    }));
                });
                const response = await Promise.all(servicesArr);
                let status = 0;
                let msg = '';
                response.forEach((resItem) => {
                    status += resItem.status;
                    msg = resItem.msg;
                });
                if (status === 0) {
                    success(msg);
                    vm.mergeParam();
                } else {
                    error(msg);
                }
            },
        }
    };
</script>

<style module>
    .container {
        background-color: #fff;
        padding: 30px 20px;
        min-height: 740px;
    }

    .title {
        font-size: 18px;
        line-height: 25px;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .titleTxt {
        display: inline-block;
        vertical-align: middle;
        line-height: 25px;
        margin-right: 10px;
    }

    .item {
        color: #666;
        font-size: 14px;
        line-height: 24px;
    }

    .black {
        color: #000;
    }

    .orange {
        color: #F5A623;
    }

    /* 进度条 */
    .stepBlock {
        margin-bottom: 20px;
    }

    /* 订单摘要 */
    .abstractBlock {
        margin-bottom: 30px;
    }

    .abstractContent {
        position: relative;
        border: 1px solid #eee;
        margin-top: 20px;
        padding: 20px;
    }

    .abstractBtn {
        position: absolute;
        top: 50%;
        right: 40px;
        transform: translateY(-50%);
    }

    /* tab - 订单详情 */
    .tabsBlock {
        margin-bottom: 30px;
    }

    .tabsSection {
        margin-bottom: 20px;
    }

    .copyBtn {
        vertical-align: top;
    }

    .addressBox {
        padding-right: 10px;
    }

    .goodsMsg {
        font-size: 0;
    }

    .goodsMsgImg {
        display: inline-block;
        vertical-align: middle;
        width: 60px;
        height: 60px;
        margin-right: 20px;
    }

    .goodsMsgWrap {
        display: inline-block;
        vertical-align: middle;
        text-align: left;
        width: 150px;
        font-size: 14px;
    }

    .goodsMsgTitle {
        margin-bottom: 5px;
    }

    /* tab - 时间记录 */
    .timeBlock{
        margin-top: 15px;
    }

    /* tab - 物流追踪 */
    .logisticsTitle {
        margin: 20px 0;
        font-size: 16px;
    }

    .logisticsTable {
        margin-bottom: 20px;
        line-height: 40px;
        text-align: center;
        border-top: 1px solid #D8D8D8;
        border-left: 1px solid #D8D8D8;
    }

    .logisticsTableTd {
        padding: 0 20px;
        border-right: 1px solid #D8D8D8;
        border-bottom: 1px solid #D8D8D8;
    }

    .logisticsInfo {
        margin-bottom: 20px;
    }

    /* 轨迹样式 */
    .logStep {
        position: relative;
        color: #000;
        font-size: 14px;
        line-height: 1;
        margin-bottom: 20px;
        margin-left: 30px;
    }
    .logStep::after, .logStep::before{
        content: '';
        position: absolute;
    }
    .logStep::after{
        left: -26px;
        top: 4px;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #ECECEC;
    }
    .logStep::before{
        left: -24px;
        top: 14px;
        width: 4px;
        height: 22px;
        background-color: #ECECEC;
    }
    .logStep:last-child::before{
        display: none;
    }

    .logisticsStep{
        margin-left: 20px;
    }

    /* 弹窗 */
    .transferItem {
        color: #000;
        font-size: 0;
        margin-bottom: 10px;
    }

    .transferItemLabel {
        display: inline-block;
        vertical-align: top;
        text-align: right;
        width: 145px;
        margin-right: 10px;
        line-height: 40px;
        font-size: 14px;
    }

    .transferItemValue {
        display: inline-block;
        vertical-align: top;
        text-align: left;
        width: 340px;
        line-height: 40px;
        font-size: 14px;
    }

    .transferItemInput {
        width: 250px;
    }

    /* 弹窗 */
    .refundItem {
        color: #000;
        font-size: 0;
        margin-bottom: 10px;
    }

    .refundItemLabel {
        display: inline-block;
        vertical-align: top;
        text-align: right;
        width: 140px;
        margin-right: 10px;
        line-height: 40px;
        font-size: 14px;
    }

    .refundItemLabelRequier:before {
        content: '*';
        color: #c00;
    }

    .refundItemValue {
        display: inline-block;
        vertical-align: top;
        text-align: left;
        width: 260px;
        line-height: 40px;
        font-size: 14px;
    }
</style>
