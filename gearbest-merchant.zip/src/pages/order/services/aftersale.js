/**
 * Created by GUOXIU on 2019/01/05.
 */

import Service from '@/assets/js/Service/index.js';


/**
 * 售后列表
 * @type {GbService}
 */
export const getAfterSales = new Service({
    url: '/shop/after-sales',
    method: 'GET',
});


/**
 * 售后更改状态
 * @type {GbService}
 */
export const changeAftersalesStatus = new Service({
    url: '/shop/after-sales/change-status',
    method: 'POST',
    showError: true
});


/**
 * 售后详情
 * @type {GbService}
 */
export const getAfterSalesDetail = new Service({
    url: '/shop/after-sales/detail',
    method: 'GET',
});


/**
 * 获取物流地址列表
 * @type {GbService}
 */
export const getLogisticsList = new Service({
    url: '/public/return-goods-address/list',
    method: 'GET',
});


/**
 * 获取 SMS 服务码映射状态表
 * @type {GbService}
 */
export const getSmsStatus = new Service({
    url: '/public/sms/status',
    method: 'GET',
    usePreResult: true,
});
