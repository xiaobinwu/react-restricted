import Service from '@/assets/js/Service/index.js';


/**
 * 订单列表
 * @type {GbService}
 */
export const getOrderList = new Service({
    url: '/order/list',
    method: 'POST',
});


/**
 * 审核取消的订单（也适用退款）
 * @type {GbService}
 */
export const auditCancelOrder = new Service({
    method: 'POST',
    url: '/order/audit-cancel-order',
});


/**
 * 订单详情
 * @type {GbService}
 */
export const getOrderDetail = new Service({
    method: 'GET',
    url: '/order/detail',
});


/**
 * 订单包裹
 * @type {GbService}
 */
export const getOrderPackage = new Service({
    method: 'GET',
    url: '/order/package',
});


/**
 * 包裹物流轨迹
 * @type {GbService}
 */
export const getOrderTrackShipping = new Service({
    method: 'GET',
    url: '/order/trace-shipping',
});


/**
 * 添加转单号
 * @type {GbService}
 */
export const setAddTransferNumber = new Service({
    url: '/order/add-transfer-number',
    method: 'POST',
});


/**
 * 发货登记页面 - 详情
 * @type {GbService}
 */
export const getExpressBaseInfo = new Service({
    method: 'GET',
    url: '/order/express-base-info',
});


/**
 * 发货登记
 * @type {GbService}
 */
export const postAddExpressPackage = new Service({
    url: '/order/add-express-package',
    method: 'POST',
});


/**
 * 所有物流方式
 * @type {GbService}
 */
export const getAllLogisticsWay = new Service({
    method: 'GET',
    url: '/logistics/shipping-template/deliver-logistics-list',
    params: {
        pageNo: 1,
        pageSize: 200
    }
});


/**
 * 获取 订单公共配置信息
 * @type {GbService}
 */
export const getOrderCommonStatus = new Service({
    url: '/order/common-status',
    method: 'GET',
    usePreResult: true,
});


/**
 * 留言列表
 * @type {GbService}
 */
export const getMessageList = new Service({
    url: '/shop/messages/order-records',
    method: 'GET',
});


/**
 * 留言删除
 * @type {GbService}
 */
export const getMessageDelet = new Service({
    url: '/shop/messages/delete',
    method: 'POST',
});


/**
 * 留言回复
 * @type {GbService}
 */
export const messageReply = new Service({
    url: '/shop/messages/reply',
    method: 'POST',
});
