import Service from '@/assets/js/Service/index.js';

export const serviceOrderAccountability = new Service({
    url: '/order/accountability-list',
    method: 'get',
    showError: true,
    loading: true
});

export const serviceOrderAccountabilityDetail = new Service({
    url: '/order/accountability/detail',
    method: 'get',
    showError: true,
    loading: true
});

export const serviceOrderAccountabilityProof = new Service({
    url: '/order/accountability/proof',
    method: 'post',
    showError: 'true',
    loading: true
});
