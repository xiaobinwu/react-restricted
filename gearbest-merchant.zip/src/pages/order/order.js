import Vue from 'vue';
import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import orderLang from '@/lang/order';
import router from './router';
import MessageReply from '@/components/MessageReply';
import MessageLog from '@/components/MessageLog';
import AftersaleTreatment from './components/AftersaleTreatment';
import { dateFormat } from '@/assets/js/utils/date';

Vue.component(MessageReply.name, MessageReply); // 消息回复模块
Vue.component(MessageLog.name, MessageLog); // 消息记录
Vue.component(AftersaleTreatment.name, AftersaleTreatment); // 售后处理

Vue.prototype.$dateFormat = dateFormat; // 时间格式工具

(async () => {
    const langInstance = await lang({ local: orderLang, moduleName: 'order' });
    app({ lang: langInstance, router });
})();
