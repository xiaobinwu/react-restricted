export default function getHasValueObj(obj) {
    const filterObj = {};
    if (typeof obj === 'object') {
        Object.entries(obj).forEach(([key, value]) => {
            if (typeIsTrue(value)) {
                filterObj[key] = value;
            }
        });
    }
    return filterObj;
}

export function typeIsTrue(val) {
    return typeof val !== 'undefined';
}

export function checkEqualObject(prev, current) {
    const valPrev = getHasValueObj(prev);
    const valCurrent = getHasValueObj(current);
    let isEqual = Object.keys(valPrev).length === Object.keys(valCurrent).length;
    if (isEqual) {
        for (const key in valPrev) {
            if (valPrev[key] !== valCurrent[key]) isEqual = false;
        }
    }
    return isEqual;
}
