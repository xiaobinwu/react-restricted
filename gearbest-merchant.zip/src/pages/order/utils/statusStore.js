/**
 * Created by GuoXiu on 2019/1/17.
 */

import { getOrderCommonStatus } from '../services/index.js';


export const backupData = {
    orderListTab: { // 订单状态
        0: '全部',
        1: '待付款',
        2: '待发货',
        3: '待收货',
        4: '退款申请',
        5: '已完成',
        6: '已退款',
        7: '已取消',
    },
    orderStatusSequ: { // soa 订单组合状态
        1: '待支付',
        2: '待配货(备货)',
        3: '待发货(完全配货)',
        4: '已删除',
        5: '已签收',
        6: '已取消',
        7: '申请退款',
        8: '已退款',
        9: '退款中',
        10: '待签收(完全发货)',
        11: 'pending',
        12: '部分支付',
        13: '部分配货',
        14: '部分发货',
        15: '已评论',
        16: '已拒签',
        17: '待审核',
        18: '已完结',
    },
    deliveryType: { // 发货模式
        1: '直发',
        2: '入仓',
    },
    returnReason: { // 申请退款 - 拒绝原因
        0: '商品已发货',
    },
    caseStatus: { // case状态
        0: '正常',
        1: '处理中',
        2: '已完成',
        3: '已关闭',
    },
    logisticsLevel: { // 物流级别
        0: '平邮',
        1: '慢',
        2: '中',
        3: '快',
        4: '自提',
    },
    logisticsStatus: { // 物流状态
        0: '已发货',
        1: '已更新',
        2: '已作废',
        3: '已签收',
    }
};

/**
 * 订单模块 - 获取接口返回的数据
 * @param selectArr
 * @return {*|{...}}
 */
export async function getOrderStatus(selectArr) {
    const returnData = {};
    let orderStatusData = {};
    const { status, data } = await getOrderCommonStatus.http();
    if (status === 0) {
        orderStatusData = data;
    }
    selectArr.forEach((item) => {
        returnData[item] = orderStatusData[item] || backupData[item] || {};
    });
    return returnData;
}
