<template>
    <div>
        <el-dialog
            :visible.sync="visible"
            :close-on-click-modal="false"
            :title="options.title"
            width="560px"
            @open="display = true"
            @closed="display = false">
            <component v-if="display" :is="componentName" :options="options" :visible.sync="visible"></component>
        </el-dialog>
    </div>
</template>

<script>
    import AppealCreate from './AppealCreate';
    import AppealDetail from './AppealDetail';

    export default {
        name: 'Container',
        components: {
            AppealCreate,
            AppealDetail
        },
        data() {
            return {
                type: '',
                visible: false,
                display: false,
                options: {},
            };
        },
        computed: {
            componentName() {
                return this.type;
            }
        },
    };
</script>
