<template>
    <div :class="$style.container">
        <p :class="$style.hint">申诉产生的金额在下期账单体现，如有异议，请在3个月内提交申诉</p>
        <ul :class="$style.timeLine">
            <li v-for="(item, index) in timeLine" :key="index" :class="$style.timeLineItem">
                <p>{{ item.status | formatStatus }}：<span :class="$style.time">{{ item.update_time | dateFormat }}</span></p>
                <p>{{ item.appeal_content }}</p>
            </li>
        </ul>
    </div>
</template>

<script>
    import Map from '@capital/utils/map';
    import { reqAppealDetail } from '@capital/services/fas';
    import { dateFormat } from '@/assets/js/utils/date';

    const mapOfAppealStatus = new Map('appealStatus');

    export default {
        name: 'AppealDetail',
        filters: {
            dateFormat,
            formatStatus(code) {
                return mapOfAppealStatus.getInfoByCode(code).lang;
            }
        },

        props: {
            options: {
                type: Object,
                default: () => ({}),
            },
            visible: {
                require: true,
                type: Boolean,
                default: false
            }
        },

        data() {
            return {
                billCode: this.options.billCode || '', // 账单编号
                timeLine: [],
            };
        },

        async created() {
            const { status, data } = await reqAppealDetail.http({
                params: {
                    order_code: this.billCode
                }
            });
            if (status === 0) {
                this.timeLine = (data.items || []).sort((a, b) => a.status > b.status);
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        color: var(--color-black);
    }

    .hint {
        margin-bottom: 20px;
        color: var(--color-error);
    }

    .timeLine {
        margin-left: 4px;
    }

    .timeLineItem {
        position: relative;
        line-height: 28px;
        padding-left: 25px;
        margin-bottom: 20px;

        &:last-of-type {
            margin-bottom: 0;

            &:before {
                display: none;
            }
        }

        &:before {
            content: '';
            position: absolute;
            top: 22px;
            left: 0;
            height: 100%;
            padding-bottom: 4px;
            box-sizing: content-box;
            border-left: 1px solid var(--border-color-light);
        }

        &:after {
            content: '';
            position: absolute;
            top: 10px;
            left: -3px;
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background-color: var(--border-color-light);
        }
    }

    .time {
        color: var(--color-text-secondary);
    }
</style>
