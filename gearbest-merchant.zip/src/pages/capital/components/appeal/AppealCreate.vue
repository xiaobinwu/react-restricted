<template>
    <div :class="$style.container">
        <p :class="$style.hint">申诉产生的金额在下期账单体现，如有异议，请在3个月内提交申诉</p>

        <el-form ref="form" :model="formData" :rules="rules" :hide-required-asterisk="true" label-suffix="：" label-width="90px" label-position="left">
            <el-form-item prop="email" label="联系邮箱">
                <el-input v-model="formData.email" maxlength="50"></el-input>
            </el-form-item>
            <el-form-item prop="content" label="申诉内容">
                <el-input v-model="formData.content" :rows="5" type="textarea" placeholder="请输入" maxlength="200"></el-input>
            </el-form-item>
        </el-form>

        <footer :class="$style.btnGroup">
            <el-button :class="$style.btnItem" @click="handleClose">取消</el-button>
            <el-button :class="$style.btnItem" type="primary" @click="handleConfirm">确定</el-button>
        </footer>
    </div>
</template>

<script>
    import { reqAppealCreate } from '@capital/services/fas';
    import store from '@/assets/js/store';


    export default {
        name: 'AppealCreate',
        props: {
            options: {
                type: Object,
                default: () => ({}),
            },
            visible: {
                require: true,
                type: Boolean,
                default: false
            }
        },

        data() {
            return {
                billType: this.options.billType || '', // 账单类型
                billCode: this.options.billCode || '', // 账单编号
                formData: {
                    email: '',
                    content: ''
                },
                rules: {
                    email: [{
                        required: true,
                        message: '请输入联系邮箱',
                        trigger: 'blur'
                    }, {
                        type: 'email',
                        message: '邮箱格式错误',
                        trigger: 'blur'
                    }],
                    content: [{
                        required: true,
                        message: '请输入申诉内容',
                        trigger: 'blur'
                    }]
                }
            };
        },

        created() {
            console.log(store.state.user);
        },

        methods: {
            /**
             * 关闭操作
             */
            handleClose() {
                this.$emit('update:visible', false);
            },

            /**
             * 确认操作
             */
            handleConfirm() {
                this.$refs.form.validate(async (valid) => {
                    if (valid) {
                        const { status } = await reqAppealCreate.http({
                            data: {
                                bill_type: this.billType,
                                order_code: this.billCode,
                                email: this.formData.email,
                                appeal_content: this.formData.content
                            }
                        });

                        if (status === 0) {
                            this.$message({
                                type: 'success',
                                message: '操作成功！'
                            });
                            this.options.callback();
                        } else {
                            this.$message({
                                type: 'error',
                                message: '操作失败！请稍后再试！'
                            });
                        }
                        this.handleClose();
                    }
                });
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        color: var(--color-black);
    }

    .btnGroup {
        margin-top: 30px;
        text-align: center;
    }

    .btnItem {
        width: 120px;
        margin: 0 10px;
    }

    .hint {
        margin-bottom: 20px;
        color: var(--color-error);
    }
</style>
