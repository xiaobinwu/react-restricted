/**
 * Created by Jiazhan Li on 2018/12/27.
 */

import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    // 放款查询
    {
        path: '/capital/loan-query',
        name: 'LoanQuery',
        meta: {
            title: 'capital.menu.loanQuery'
        },
        component: () => asyncComponent(import('@capital/views/loan-query/LoanQuery'))
    },

    // 订单资金查询
    {
        path: '/capital/order-capital-query',
        name: 'OrderCapitalQuery',
        meta: {
            title: 'capital.menu.orderCapitalQuery'
        },
        component: () => asyncComponent(import('@capital/views/order-capital-query/OrderCapitalQuery'))
    },

    // 结算账单列表
    {
        path: '/capital/bill-list',
        name: 'BillList',
        meta: {
            title: 'capital.menu.bill'
        },
        component: () => asyncComponent(import('@capital/views/bill-list/BillList'))
    },

    // 结算账单详情
    {
        path: '/capital/bill-detail',
        name: 'BillDetail',
        meta: {
            title: 'capital.menu.billDetail',
            focusMenu: '/capital/bill-list',
        },
        component: () => asyncComponent(import('@capital/views/bill-detail/BillDetail'))
    },

    // 结算账户首页
    {
        path: '/capital/settlement-account',
        name: 'SettlementAccount',
        meta: {
            title: 'capital.menu.settlementAccount'
        },
        component: () => asyncComponent(import('@capital/views/settlement-account/SettlementAccount'))
    },

    // 资金明细记录
    {
        path: '/capital/capital-report',
        name: 'CapitalReport',
        meta: {
            title: 'capital.menu.capitalReport',
            focusMenu: '/capital/settlement-account',
        },
        component: () => asyncComponent(import('@capital/views/capital-report/CapitalReport'))
    },

    // 服务资金查询
    {
        path: '/capital/service-capital-query',
        name: 'ServiceCapitalQuery',
        meta: {
            title: 'capital.menu.serviceCapitalQuery'
        },
        component: () => asyncComponent(import('@capital/views/service-capital-query/ServiceCapitalQuery'))
    },

    // 仓储账单列表
    {
        path: '/capital/warehouse-bill-list',
        name: 'WarehouseBillList',
        meta: {
            title: 'capital.menu.warehouseBill'
        },
        component: () => asyncComponent(import('@capital/views/warehouse-bill-list/WarehouseBillList'))
    },

    // 仓储账单详情
    {
        path: '/capital/warehouse-bill-detail/:billCode',
        name: 'WarehouseBillDetail',
        meta: {
            title: 'capital.menu.warehouseBillDetail',
            focusMenu: '/capital/warehouse-bill-list',
        },
        component: () => asyncComponent(import('@capital/views/warehouse-bill-detail/WarehouseBillDetail'))
    },

    // 服务账户
    {
        path: '/capital/service-account',
        name: 'ServiceAccount',
        meta: {
            title: 'capital.menu.serviceAccount',
            focusMenu: '/capital/service-account',
        },
        component: () => asyncComponent(import('@capital/views/service-account/ServiceAccount'))
    },

    // 服务账户充值（详情）
    {
        path: '/capital/service-account-detail',
        name: 'ServiceAccountDetail',
        meta: {
            title: 'capital.menu.serviceAccountDetail',
            focusMenu: '/capital/service-account',
        },
        component: () => asyncComponent(import('@capital/views/service-account-detail/ServiceAccountDetail'))
    },

    // 设置收款账户
    {
        path: '/capital/receiving-account',
        name: 'ReceivingAccount',
        meta: {
            title: 'capital.menu.receivingAccount',
            focusMenu: '/capital/settlement-account',
        },
        component: () => asyncComponent(import('@capital/views/receiving-account/ReceivingAccount'))
    },

    // 提现页面
    {
        path: '/capital/withdrawal',
        name: 'Withdrawal',
        meta: {
            title: 'capital.menu.withdrawal',
            focusMenu: '/capital/settlement-account',
        },
        component: () => asyncComponent(import('@capital/views/withdrawal/Withdrawal'))
    },
];
