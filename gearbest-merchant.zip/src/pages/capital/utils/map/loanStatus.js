/**
 * 放款状态
 * Created by Jiazhan Li on 2019/2/23.
 */

export default [{
    // 待放款
    name: 'WAITING_LOAN',
    code: '1',
    lang: '待放款'
}, {
    // 已放款
    name: 'ALREADY_LOAN',
    code: '2',
    lang: '已放款'
}];
