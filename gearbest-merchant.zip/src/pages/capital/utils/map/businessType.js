/**
 * 业务类型
 * Created by Jiazhan Li on 2019/2/25.
 */

export default [{
    // 放款
    name: 'LOAN',
    code: '1',
    lang: '放款'
}, {
    // 售后责任金额
    name: 'AFTER_SALE',
    code: '2',
    lang: '售后责任金额'
}, {
    // 调整金额
    name: 'ADJUST',
    code: '3',
    lang: '调整金额'
}, {
    // 退款
    name: 'REFUND',
    code: '4',
    lang: '退款'
}];
