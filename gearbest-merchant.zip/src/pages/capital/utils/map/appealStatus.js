/**
 * 申诉状态
 * Created by Jiazhan Li on 2019/2/23.
 */

export default [{
    // 正常
    name: 'NORMAL',
    code: '0',
    lang: '正常'
}, {
    // 待处理
    name: 'WAITING',
    code: '1',
    lang: '待处理'
}, {
    // 处理中
    name: 'UNDERWAY',
    code: '2',
    lang: '处理中'
}, {
    // 已处理
    name: 'COMPLETE',
    code: '3',
    lang: '已处理'
}];
