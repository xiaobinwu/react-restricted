/**
 * 状态管理
 * Created by Jiazhan Li on 2019/2/23.
 */

const context = require.context('.', false, /\.js$/);
const maps = {};

context.keys().forEach((key) => {
    if (key !== './index.js') {
        const fileName = key.replace(/(\.\/|\.js)/g, '');
        maps[fileName] = context(key).default;
    }
});

export default class {
    constructor(fileName) {
        this.mapByName = {};
        this.mapByCode = {};

        if (Array.isArray(maps[fileName])) {
            maps[fileName].forEach((item) => {
                this.mapByName[item.name] = item;
                this.mapByCode[item.code] = item;
            });
        } else {
            console.error(`文件（${fileName}.js）对外输出必须为数组`);
        }
    }

    getInfoByName(name) {
        return this.mapByName[name] || {};
    }

    getInfoByCode(code) {
        return this.mapByCode[code] || {};
    }
}
