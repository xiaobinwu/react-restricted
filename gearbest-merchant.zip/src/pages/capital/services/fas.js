/**
 * Created by Jiazhan Li on 2019/2/27.
 */

import Service from '@/assets/js/Service';

// 结算账单列表
export const reqBillList = new Service({
    url: '/fas/sale-bill/list',
    method: 'GET',
    loading: true
});

// 结算账单详情
export const reqBillDetail = new Service({
    url: '/fas/sale-bill/info',
    method: 'GET',
    loading: true
});

// 结算账单确认
export const reqConfirmBill = new Service({
    url: '/fas/sale-bill/confirm',
    method: 'POST',
    loading: true
});

// 资金记录列表
export const reqCapitalList = new Service({
    url: '/fas/capital/capital-list',
    method: 'GET',
    loading: true
});

// 提现记录列表
export const reqWithdrawalList = new Service({
    url: '/fas/capital/withdrawal-list',
    method: 'GET',
    loading: true
});

// 操作费列表
export const reqOperationList = new Service({
    url: '/fas/service-fund/operation-list',
    method: 'GET',
    loading: true
});

// 仓储费列表
export const reqWarehouseLeaseList = new Service({
    url: '/fas/service-fund/warehouse-lease-list',
    method: 'GET',
    loading: true
});

// 增值服务费列表
export const reqValueAddedSerivceList = new Service({
    url: '/fas/service-fund/value-added-serivce-list',
    method: 'GET',
    loading: true
});

// 调整费列表
export const reqAdjustFeeList = new Service({
    url: '/fas/service-fund/adjust-fee-list',
    method: 'GET',
    loading: true
});

// 物流费列表
export const reqLogisticsFeeList = new Service({
    url: '/fas/service-fund/logistics-fee-list',
    method: 'GET',
    loading: true
});

// 仓储账单列表
export const reqWarehouseBillList = new Service({
    url: '/fas/warehouse-bill/list',
    method: 'GET',
    loading: true
});

// 仓储账单列表
export const reqWarehouseBillInfo = new Service({
    url: '/fas/warehouse-bill/info',
    method: 'GET',
    loading: true
});

// 放款查询
export const reqLoanList = new Service({
    url: '/fas/loan/loan-list',
    method: 'GET',
    loading: true
});

// 订单记录查询
export const reqOrderList = new Service({
    url: '/fas/order-trans-record/order-list',
    method: 'GET',
    loading: true
});

// 放款记录查询
export const reqNetList = new Service({
    url: '/fas/order-trans-record/net-list',
    method: 'GET',
    loading: true
});

// 售后责任记录查询
export const reqRmaList = new Service({
    url: '/fas/order-trans-record/rma-list',
    method: 'GET',
    loading: true
});

// 调整记录查询
export const reqAdjustList = new Service({
    url: '/fas/order-trans-record/adjust-list',
    method: 'GET',
    loading: true
});

// 申诉
export const reqAppealCreate = new Service({
    url: '/fas/appeal/create',
    method: 'POST',
    loading: true
});

// 申诉详情
export const reqAppealDetail = new Service({
    url: '/fas/appeal/info',
    method: 'GET'
});

// 账户总览
export const reqCapitalIndex = new Service({
    url: '/fas/capital/index',
    method: 'GET'
});

// 服务账户-所有明细
export const reqServiceAccountAll = new Service({
    url: '/fas/store-account-trade/all',
    method: 'GET',
    loading: true,
});

// 服务账户-物流明细
export const reqServiceAccountLogistics = new Service({
    url: '/fas/store-account-trade/logistics-trade-list',
    method: 'GET',
    loading: true,
});

// 服务账户-仓储明细
export const reqServiceAccountStorage = new Service({
    url: '/fas/store-account-trade/store-bill-list',
    method: 'GET',
    loading: true,
});

// 服务账户-账户信息
export const reqServiceAccountInfo = new Service({
    url: '/fas/store-account-trade/store-account',
    method: 'GET',
    loading: true,
});

/**
 * 获取国家区号
 * @type {}
 */

export const phonecodeList = new Service({
    url: '/phonecode-list',
    method: 'get',
    showError: true,
});

/* 地址管理-查询国家-级联选择器 */
export const countrysListGet = new Service({
    url: '/public/logistics/country/list',
    method: 'get',
    showError: true,
});

/* 地址管理-查询省份-级联选择器 */
export const provincesListGet = new Service({
    url: '/public/logistics/country/get-provinces-by',
    method: 'get',
    showError: true,
    isCancel: false,
});

/* 地址管理-查询城市-级联选择器 */
export const citysListGet = new Service({
    url: '/public/logistics/country/get-cities-by',
    method: 'get',
    showError: true,
    isCancel: false,
});


// 获取用户信息
export const getUserInfo = new Service({
    url: '/user/info',
    method: 'get',
    showError: true,
});

// 提交审核
export const submitAudit = new Service({
    url: '/fas/capital/update-financial',
    method: 'post',
    showError: true,
});

// 恢复之前的收款账号
export const reqRecoverFinancial = new Service({
    url: '/fas/capital/recover-financial',
    method: 'get',
    showError: true,
});

// 发送安全密码重置邮件
export const sendEmail = new Service({
    url: '/user/send-reset-safe-email',
    method: 'get',
    showError: true,
});

// 提现
export const reqWithdrawal = new Service({
    url: '/fas/capital/withdrawal',
    method: 'POST',
    showError: true,
});
