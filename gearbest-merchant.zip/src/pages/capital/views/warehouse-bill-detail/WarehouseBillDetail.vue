<!--仓储账单-->
<template>
    <div :class="$style.container">
        <header :class="$style.header">
            <span :class="$style.dataItem">账单编号：{{ billCode }}</span>
            <span :class="$style.dataItem">账期：{{ billDateRange }}</span>
            <span :class="[$style.dataItem, $style.fr]">合计：<b>{{ sum }}</b></span>
        </header>

        <el-form :inline="true" label-suffix="：">
            <!-- <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item> -->
        </el-form>

        <div :class="$style.toolbar">
            <el-button :disabled="tableData.length === 0" @click="exportTable">导出表格</el-button>
        </div>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column :formatter="formatDate" prop="deduct_time" label="交易时间" align="center" fixed min-width="130"></el-table-column>
            <el-table-column prop="order_type" label="单据类型" align="center" min-width="110"></el-table-column>
            <el-table-column prop="type" label="费用项目" align="center" min-width="110"></el-table-column>
            <el-table-column prop="amount" label="资金明细" align="center" min-width="100"></el-table-column>
        </el-table>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { openNewPage } from '@/assets/js/utils/url';
    import { reqWarehouseBillInfo } from '@capital/services/fas';

    export default {
        name: 'WarehouseBillDetail',
        data() {

            // 默认数据
            const DATA = {
                orderCode: '', // 账单编号
            };

            return {
                DATA,
                billCode: this.$route.params.billCode, // 账单编号
                billDateRange: '', // 账期
                sum: 0, // 扣款总金额
                downloadLink: '', // 下载链接
                filter: {
                    orderCode: DATA.orderCode, // 账单编号
                },
                tableData: [], // 表格数据对象
            };
        },

        created() {
            this.getData();
        },

        methods: {

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async getData() {
                const { status, data } = await reqWarehouseBillInfo.http({
                    params: {
                        order_code: this.billCode,
                    }
                });
                if (status === 0) {
                    this.billDateRange = `${dateFormat(data.process_date_start, 'yyyy/MM/dd')} - ${dateFormat(data.process_date_end, 'yyyy/MM/dd')}`;
                    this.sum = data.total_amount;
                    this.downloadLink = data.downloadLink;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                console.log('重置搜索条件');
            },

            /**
             * 搜索
             */
            handleSearch() {
                console.log('搜索');
            },

            /**
             * 导出表格
             */
            exportTable() {
                if (this.tableData.length > 0 && this.downloadLink) {
                    openNewPage(this.downloadLink);
                }
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .header {
        height: 40px;
        padding: 0 20px;
        margin-bottom: 20px;
        line-height: 40px;
        background-color: var(--background-color-base);
    }

    .dataItem {
        display: inline-block;
        margin-right: 30px;
    }

    .fr {
        float: right;
    }

    .toolbar {
        margin-bottom: 10px;
        text-align: right;
    }
</style>
