<template>
    <div :class="$style.container">
        <el-form :inline="true" label-suffix="：">
            <el-form-item label="订单编号">
                <el-input v-model="filter.orderSn" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="放款状态">
                <el-select v-model="filter.loanStatus" placeholder="请选择">
                    <el-option v-for="item in loanStatusOptions"
                               :key="item.value"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="支付时间">
                <el-date-picker
                    v-model="filter.paymentTime"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <el-table :data="tableData" :cell-class-name="$style.transparent" :span-method="spanMethod" border>
            <div slot="empty">暂无数据</div>
            <el-table-column label="订单信息" header-align="center" min-width="160">
                <dl slot-scope="scope" :class="$style.orderInfo">
                    <dt>订单编号：</dt>
                    <dd><a href="javascript:;" @click="gotoOrderDetail(scope.row.orderSn)">{{ scope.row.orderSn }}</a></dd>
                    <dt>下单时间：</dt>
                    <dd>{{ scope.row.orderTime }}</dd>
                </dl>
            </el-table-column>
            <el-table-column prop="orderAmount" label="订单总额" align="center"></el-table-column>
            <el-table-column label="商品编号" align="center" min-width="140">
                <a slot-scope="scope" :href="scope.row.goodsUrl">{{ scope.row.goodsSn }}</a>
            </el-table-column>
            <el-table-column prop="goodsCount" label="商品数量" align="center"></el-table-column>
            <el-table-column prop="goodsAmount" label="商品金额" align="center"></el-table-column>
            <el-table-column prop="refundAmount" label="退款金额" align="center"></el-table-column>
            <el-table-column prop="waitLoanAmount" label="待放款金额" align="center"></el-table-column>
            <el-table-column prop="alreadyLoanAmount" label="已放款金额" align="center"></el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import Map from '@capital/utils/map';
    import { dateFormat } from '@/assets/js/utils/date';
    import { reqLoanList } from '@capital/services/fas';

    const mapOfLoanStatus = new Map('loanStatus');

    export default {
        name: 'LoanQuery',
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                orderSn: '', // 订单编号
                loanStatus: mapOfLoanStatus.getInfoByName('WAITING_LOAN').code, // 放款状态
                paymentTime: [now - 2592000000, now], // 支付时间，推前一个月筛选
                pageSize: 20, // 每页显示条数
                pageNo: 1 // 当前页码
            };

            return {
                DATA,
                filter: {
                    orderSn: DATA.orderSn, // 订单编号
                    loanStatus: DATA.loanStatus, // 放款状态
                    paymentTime: DATA.paymentTime, // 支付时间，推前一个月筛选
                },
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象

                // 放款状态下拉菜单列表
                loanStatusOptions: ['WAITING_LOAN', 'ALREADY_LOAN'].map((item) => {
                    const statusInfo = mapOfLoanStatus.getInfoByName(item);
                    return {
                        label: statusInfo.lang,
                        value: statusInfo.code,
                    };
                }),
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        orderSn,
                        loanStatus,
                        startTime,
                        endTime,
                        pageSize,
                        pageNo
                    } = this.$route.query;

                    this.filter.orderSn = orderSn || this.DATA.orderSn;
                    this.filter.loanStatus = loanStatus || this.DATA.loanStatus;
                    this.filter.paymentTime = startTime && endTime ? [startTime * 1000, endTime * 1000] : this.DATA.paymentTime;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.filter.orderSn !== this.DATA.orderSn) query.orderSn = this.filter.orderSn;
                if (this.filter.loanStatus !== this.DATA.loanStatus) query.loanStatus = this.filter.loanStatus;
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                if (this.filter.paymentTime !== this.DATA.paymentTime && (this.filter.paymentTime || []).length) {
                    query.startTime = Math.floor(this.filter.paymentTime[0] / 1000);
                    query.endTime = Math.floor(this.filter.paymentTime[1] / 1000);
                }
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqLoanList.http({
                    params: {
                        order_sn: this.filter.orderSn,
                        loan_status: this.filter.loanStatus,
                        last_match_time_start: (this.filter.paymentTime || [])[0] ? Math.floor(this.filter.paymentTime[0] / 1000) : '',
                        last_match_time_end: (this.filter.paymentTime || [])[1] ? Math.floor(this.filter.paymentTime[1] / 1000) : '',
                        offset: this.pageNo,
                        limit: this.pageSize
                    }
                });
                if (status === 0) {
                    this.totalCount = data.total || 0;
                    this.tableData = this.getTableData(data);
                }
            },

            /**
             * 将原数据拆分为待渲染的表格数据格式
             */
            getTableData(data) {
                const result = [];
                (data.items || []).forEach((order) => {
                    result.push(...order.good_list.map((item, index) => ({
                        orderSn: order.order_sn, // 订单编号
                        orderTime: dateFormat(order.order_time), // 下单时间
                        orderAmount: order.total_order_amount, // 订单总额
                        goodsUrl: (data.goodsUrls || {})[item.goods_sn] || 'javascript:;', // 商品链接
                        goodsSn: item.goods_sn, // 商品编码
                        goodsCount: item.goods_quantity, // 商品数量
                        goodsAmount: item.order_amount, // 商品金额
                        refundAmount: item.refund_amount, // 退款金额
                        waitLoanAmount: item.net_amount, // 待放款金额
                        alreadyLoanAmount: item.loan_amount, // 已放款金额
                        rowspan: index === 0 ? order.good_list.length : 0
                    })));
                });
                return result;
            },

            /**
             * 合并单元格
             */
            spanMethod(param) {
                if ([0, 1].includes(param.columnIndex)) {
                    return [param.row.rowspan, 1];
                }
                return [1, 1];
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    orderSn: this.DATA.orderSn,
                    loanStatus: this.DATA.loanStatus,
                    paymentTime: this.DATA.paymentTime,
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 跳转到订单详情页
             * @param orderSn 《订单编号》
             */
            gotoOrderDetail(orderSn) {
                this.$router.gbPush(`/order/details/${orderSn}`);
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .pagination {
        margin-top: 20px;
    }

    .orderInfo {
        padding: 0 10px;
        white-space: nowrap;
        margin-top: -10px;

        dt {
            margin-top: 10px;
            color: var(--color-text-regular);
        }
    }

    .transparent {
        background-color: transparent !important;
    }
</style>
