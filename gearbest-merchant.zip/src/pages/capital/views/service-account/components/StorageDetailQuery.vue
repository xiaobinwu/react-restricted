<template>
    <div>
        <el-form :inline="true" label-suffix="：">
            <el-form-item label="账单编号">
                <el-input v-model="filter.orderNo" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="扣款时间">
                <el-date-picker
                    v-model="filter.deductTime"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <div :class="$style.toolBar">
            <el-button :disabled="tableData.length <= 0" @click="exportData">导出表格</el-button>
        </div>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column label="账单编号" align="center" min-width="200">
                <template slot-scope="scope">
                    <a href="javascript:;" @click="goToBillDetail(scope.row.order_no)">{{ scope.row.order_no }}</a>
                </template>
            </el-table-column>
            <el-table-column :formatter="formatBillDate" label="账期" align="center" width="180"></el-table-column>
            <el-table-column prop="total_amount" label="扣款金额" align="center" min-width="100"></el-table-column>
            <el-table-column :formatter="formatDate" prop="deduct_time" label="扣款时间" align="center" min-width="150"></el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { openNewPage } from '@/assets/js/utils/url';
    import { reqServiceAccountStorage } from '@capital/services/fas';

    export default {
        name: 'StorageDetailQuery',
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                orderNo: '', // 账单编码
                deductTime: [now - 2592000000, now], // 扣款时间
                pageSize: 10, // 每页显示条数
                pageNo: 1 // 当前页码
            };

            return {
                DATA,
                type: 'StorageDetailQuery',
                filter: {
                    orderNo: DATA.orderNo, // 账单编码
                    deductTime: DATA.deductTime, // 扣款时间
                },
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                downloadLink: '', // 导出表格下载链接
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        orderNo,
                        startTime,
                        endTime,
                        pageSize,
                        pageNo
                    } = this.$route.query;

                    this.filter.orderNo = orderNo || this.DATA.orderNo;
                    this.filter.deductTime = startTime && endTime ? [startTime * 1000, endTime * 1000] : this.DATA.deductTime;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.filter.orderNo !== this.DATA.orderNo) query.orderNo = this.filter.orderNo;
                if (this.filter.deductTime !== null && this.filter.deductTime !== this.DATA.deductTime) {
                    query.startTime = Math.floor(this.filter.deductTime[0] / 1000);
                    query.endTime = Math.floor(this.filter.deductTime[1] / 1000);
                }
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                query.type = this.type;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqServiceAccountStorage.http({
                    params: {
                        limit: this.pageSize,
                        offset: this.pageNo,
                        order_no: this.filter.orderNo,
                        deduct_time_start: this.filter.deductTime.length === 0 ? '' : Math.floor(this.filter.deductTime[0] / 1000),
                        deduct_time_end: this.filter.deductTime.length === 0 ? '' : Math.floor(this.filter.deductTime[1] / 1000),
                    }
                });
                if (status === 0) {
                    this.downloadLink = data.downloadLink;
                    this.totalCount = data.total || 0;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    orderNo: this.DATA.orderNo,
                    deductTime: this.DATA.deductTime,
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * 格式化账期时间
             * @return {string}
             */
            formatBillDate(row, column, cellValue) {
                let resultText = '';

                if (row.process_date_start && row.process_date_end) {
                    resultText = `${dateFormat(row.process_date_start, 'yyyy/MM/dd')} - ${dateFormat(row.process_date_end, 'yyyy/MM/dd')}`;
                } else {
                    resultText = '--';
                }

                return resultText;
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 导出表格
             */
            exportData() {
                if (this.tableData.length > 0 && this.downloadLink) {
                    openNewPage(this.downloadLink);
                }
            },

            /**
             * 跳转到仓储账单详情页
             * @param billCode
             */
            goToBillDetail(billCode) {
                this.$router.gbPush(`/capital/warehouse-bill-detail/${billCode}`);
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .pagination {
        margin-top: 20px;
    }

    .toolBar {
         text-align: right;
         margin: 0 0 15px;
     }
</style>
