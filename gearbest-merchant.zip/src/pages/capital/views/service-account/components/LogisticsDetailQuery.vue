<template>
    <div>
        <el-form :inline="true" label-suffix="：">
            <el-form-item label="订单编号">
                <el-input v-model="filter.orderSn" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="包裹单号">
                <el-input v-model="filter.outWarehouseNumber" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="扣款时间">
                <el-date-picker
                    v-model="filter.payDate"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <div :class="$style.toolBar">
            <el-button :disabled="tableData.length <= 0" @click="exportData">导出表格</el-button>
        </div>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column :formatter="formatDate" prop="pay_time" label="扣款时间" align="center" width="150"></el-table-column>
            <el-table-column label="费用项目" align="center" width="100">
                <template slot-scope="scope">
                    {{ itemTexts[scope.row.item] }}
                </template>
            </el-table-column>
            <el-table-column prop="settlement_amount" label="结算金额" align="center" width="100"></el-table-column>
            <el-table-column label="订单编号" align="center" min-width="200">
                <template slot-scope="scope">
                    <a href="javascript:;" @click="goToOrderDetail(scope.row.order_sn)">{{ scope.row.order_sn }}</a>
                </template>
            </el-table-column>
            <el-table-column prop="out_warehouse_number" label="包裹单号" align="center" min-width="200"></el-table-column>
            <el-table-column prop="logistics_name" label="物流服务名称" align="center" min-width="120"></el-table-column>
            <el-table-column prop="weight" label="包裹重量（KG）" align="center" width="130"></el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { openNewPage } from '@/assets/js/utils/url';
    import { reqServiceAccountLogistics } from '@capital/services/fas';

    export default {
        name: 'LogisticsDetailQuery',
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                outWarehouseNumber: '', // 包裹单号
                orderSn: '', // 订单编号
                payDate: [now - 2592000000, now], // 扣款时间
                pageSize: 10, // 每页显示条数
                pageNo: 1 // 当前页码
            };

            return {
                DATA,
                type: 'LogisticsDetailQuery',
                filter: {
                    outWarehouseNumber: DATA.outWarehouseNumber, // 包裹单号
                    orderSn: DATA.orderSn, // 订单编号
                    payDate: DATA.payDate, // 扣款时间
                },
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                downloadLink: '', // 导出表格下载链接

                // 费用项目
                itemTexts: {
                    101: '基础运费',
                    102: '燃油附加费',
                    103: '附加费',
                    104: '关税',
                    105: '增值税',
                    106: '索赔费用',
                }
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        outWarehouseNumber,
                        orderSn,
                        startTime,
                        endTime,
                        pageSize,
                        pageNo
                    } = this.$route.query;

                    this.filter.outWarehouseNumber = outWarehouseNumber || this.DATA.outWarehouseNumber;
                    this.filter.orderSn = orderSn || this.DATA.orderSn;
                    this.filter.payDate = startTime && endTime ? [startTime * 1000, endTime * 1000] : this.DATA.payDate;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.filter.outWarehouseNumber !== this.DATA.outWarehouseNumber) query.outWarehouseNumber = this.filter.outWarehouseNumber;
                if (this.filter.orderSn !== this.DATA.orderSn) query.orderSn = this.filter.orderSn;
                if (this.filter.payDate !== null && this.filter.payDate !== this.DATA.payDate) {
                    query.startTime = Math.floor(this.filter.payDate[0] / 1000);
                    query.endTime = Math.floor(this.filter.payDate[1] / 1000);
                }
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                query.type = this.type;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqServiceAccountLogistics.http({
                    params: {
                        limit: this.pageSize,
                        offset: this.pageNo,
                        out_warehouse_number: this.filter.outWarehouseNumber,
                        order_sn: this.filter.orderSn,
                        pay_date_start: this.filter.payDate.length === 0 ? '' : Math.floor(this.filter.payDate[0] / 1000),
                        pay_date_end: this.filter.payDate.length === 0 ? '' : Math.floor(this.filter.payDate[1] / 1000),
                    }
                });
                if (status === 0) {
                    this.downloadLink = data.downloadLink;
                    this.totalCount = data.total || 0;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    orderSn: this.DATA.orderSn,
                    outWarehouseNumber: this.DATA.outWarehouseNumber,
                    payDate: this.DATA.payDate,
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 跳转到订单详情页
             * @param orderSn
             */
            goToOrderDetail(orderSn) {
                this.$router.gbPush(`/order/details/${orderSn}`);
            },

            /**
             * 导出表格
             */
            exportData() {
                if (this.tableData.length > 0 && this.downloadLink) {
                    openNewPage(this.downloadLink);
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .pagination {
        margin-top: 20px;
    }

    .toolBar {
         text-align: right;
         margin: 0 0 15px;
     }
</style>
