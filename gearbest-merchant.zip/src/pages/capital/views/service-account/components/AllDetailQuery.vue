<template>
    <div>
        <el-form :inline="true" label-suffix="：">
            <!-- <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item> -->
        </el-form>

        <div :class="$style.toolBar">
            <el-button :disabled="tableData.length <= 0" @click="exportData">导出表格</el-button>
        </div>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column :formatter="formatDate" prop="trade_date" label="交易时间" align="center" width="150"></el-table-column>
            <el-table-column label="业务类型" align="center" width="110">
                <template slot-scope="scope">
                    {{ billTypeTexts[scope.row.bill_type] }}
                </template>
            </el-table-column>
            <el-table-column label="交易信息" align="center" min-width="230">
                <template slot-scope="scope">
                    <span v-if="scope.row.trade_order === ''">--</span>
                    <label v-else-if="Number(scope.row.bill_type) === 1">
                        账单编码：
                        <a href="javascript:;" @click="goToBillDetail(scope.row.trade_order)">{{ scope.row.trade_order }}</a>
                    </label>
                    <label v-else>
                        订单编号：
                        <a href="javascript:;" @click="goToOrderDetail(scope.row.trade_order)">{{ scope.row.trade_order }}</a>
                    </label>
                </template>
            </el-table-column>
            <el-table-column prop="trade_amount" label="资金明细" align="center" min-width="200"></el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { openNewPage } from '@/assets/js/utils/url';
    import { reqServiceAccountAll } from '@capital/services/fas';

    export default {
        name: 'AllDetailQuery',
        data() {

            // 默认数据
            const DATA = {
                pageSize: 10, // 每页显示条数
                pageNo: 1 // 当前页码
            };

            return {
                DATA,
                type: 'AllDetailQuery',
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                downloadLink: '', // 导出表格下载链接

                // 项目费用类型
                billTypeTexts: {
                    1: '仓储服务',
                    2: '销售订单',
                    3: '物流服务',
                }
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        pageSize,
                        pageNo
                    } = this.$route.query;

                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                query.type = this.type;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqServiceAccountAll.http({
                    params: {
                        limit: this.pageSize,
                        offset: this.pageNo,
                    }
                });
                if (status === 0) {
                    this.downloadLink = data.downloadLink;
                    this.totalCount = data.total || 0;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                console.log('重置搜索条件');
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * 格式化交易信息
             */
            formatTransactionInfo(row, column, cellValue) {
                let resultText = '';

                if (cellValue === '') {
                    resultText = '--';
                } else if (row.bill_type === 1) {
                    resultText = `账单编码：${cellValue}`;
                } else {
                    resultText = `订单编号：${cellValue}`;
                }

                return resultText;
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 导出表格
             */
            exportData() {
                if (this.tableData.length > 0 && this.downloadLink) {
                    openNewPage(this.downloadLink);
                }
            },

            /**
             * 跳转到仓储账单详情页
             * @param billCode
             */
            goToBillDetail(billCode) {
                this.$router.gbPush(`/capital/warehouse-bill-detail/${billCode}`);
            },

            /**
             * 跳转到订单详情页
             * @param orderSn
             */
            goToOrderDetail(orderSn) {
                this.$router.gbPush(`/order/details/${orderSn}`);
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .pagination {
        margin-top: 20px;
    }

    .toolBar {
        text-align: right;
        margin: 0 0 15px;
    }
</style>
