<template>
    <div :class="$style.container">
        <div :class="$style.account">
            <label :class="$style.title">账户余额</label>
            <label :class="$style.money">{{ `${accountData.currency || ''}  ${accountData.balance_amount || ''}` }}</label>
            <label v-if="Number(accountData.status) === 2" :class="$style.noMoney">
                <i class="el-icon-warning"></i>
                账户余额不足，已终止发货等物流仓储服务，请尽快充值。
            </label>
            <a :class="$style.link" href="javascript:;" @click="goToAccountDetail">>>点击查看充值账户</a>
        </div>

        <el-tabs v-model="type" type="card" @tab-click="tabClick">
            <el-tab-pane label="所有明细" name="AllDetailQuery"></el-tab-pane>
            <el-tab-pane label="物流明细" name="LogisticsDetailQuery"></el-tab-pane>
            <el-tab-pane label="仓储明细" name="StorageDetailQuery"></el-tab-pane>
        </el-tabs>

        <component :is="type"></component>
    </div>
</template>

<script>
    import { reqServiceAccountInfo } from '@capital/services/fas';
    import AllDetailQuery from './components/AllDetailQuery';
    import LogisticsDetailQuery from './components/LogisticsDetailQuery';
    import StorageDetailQuery from './components/StorageDetailQuery';

    export default {
        name: 'OrderCapitalQuery',
        components: {
            AllDetailQuery,
            LogisticsDetailQuery,
            StorageDetailQuery,
        },

        data() {
            return {
                type: this.getTypeName(),
                accountData: Object,
            };
        },

        watch: {
            $route() {
                this.type = this.getTypeName();
            }
        },

        created() {
            this.getAccountInfo();
        },

        methods: {
            /**
             * 返回有效的类型名称
             */
            getTypeName() {
                const typeName = this.$route.query.type;
                return [
                    'AllDetailQuery',
                    'LogisticsDetailQuery',
                    'StorageDetailQuery',
                ].includes(typeName) ? typeName : 'AllDetailQuery';
            },

            /**
             * 切换Tabs标签页的时候更新URL的type参数
             */
            tabClick(tab) {
                this.$router.push({
                    query: {
                        type: tab.name
                    }
                });
            },

            /**
             * 获取账户信息
             */
            async getAccountInfo() {
                const { status, data } = await reqServiceAccountInfo.http();
                if (status === 0) {
                    this.accountData = data;
                }
            },

            /**
             * 跳转到服务账户充值（详情）
             */
            goToAccountDetail() {
                this.$router.gbPush('service-account-detail');
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .account {
        border: 1px solid rgba(221,221,221,1);
        margin-bottom: 20px;
        height: 100px;
        line-height: 100px;
        padding-left: 130px;
    }

    .title {
        color: #000000;
        font-size: 14px;
        font-weight: 400;
        margin-right: 20px;
    }

    .money {
        color: #000000;
        font-size: 18px;
        font-weight: 800;
        margin-right: 20px;
    }

    .link {
        color: #2774FF;
        font-size: 14px;
        font-weight: 400;
    }

    .noMoney {
        color: #FF0000;
        font-size: 12px;
    }

    .noMoney > i {
        font-size: 16px;
        margin-right: 5px;
    }
</style>
