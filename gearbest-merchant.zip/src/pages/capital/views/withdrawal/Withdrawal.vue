<template>
    <div :class="$style.container">
        <h1 :class="$style.caption">账户总览</h1>
        <article :class="$style.content">
            <progress-bar :class="$style.progressBar" :active="stepIndex" :steps="stepsData"></progress-bar>
            <el-form v-if="stepIndex === 0"
                     ref="form" :class="$style.form" :model="formData" :rules="rules"
                     label-width="25%" label-suffix="：">
                <el-form-item label="目标账户">
                    <div :class="$style.bankCardInfo">
                        <el-radio checked>
                            <span v-if="bankAccountInfo.type === 'P'">Payoneer(派安盈)账户：{{ bankAccountInfo.bankAccountNo }}</span>
                            <span v-if="bankAccountInfo.type === 'USD'" :class="$style.radioContent">
                                {{ bankAccountInfo.bankAccountNo }} &nbsp;&nbsp; {{ bankAccountInfo.bankAccountName }}
                                <span :class="$style.bankName">{{ bankAccountInfo.bankName }}</span>
                            </span>
                        </el-radio>
                    </div>
                    <p :class="$style.hint">
                        <i class="icon-tips"></i>
                        如果你想提现至其他账号，请至
                        <a href="javascript:;" @click="editBankAccount">收款账户管理</a>
                        进行设置。
                    </p>
                </el-form-item>
                <el-form-item prop="withdrawalAmount" label="提现金额 (USD)">
                    <el-input v-model.number="formData.withdrawalAmount" :class="$style.input" :placeholder="maxWithdrawalAmount"
                              type="number"></el-input>
                </el-form-item>
                <el-form-item prop="tradePassword" label="安全密码">
                    <el-input v-model="formData.tradePassword" :class="$style.input" type="password"></el-input>
                    <el-button :class="$style.textBtn" type="text" @click="setTradePassword">忘记密码？</el-button>
                    <p :class="$style.hint">预计到账时间：7个工作日内</p>
                </el-form-item>
                <el-form-item>
                    <el-button :class="$style.submit" type="primary" @click="toNextStep">下一步</el-button>
                </el-form-item>
            </el-form>

            <div v-if="stepIndex === 1" :class="$style.confirmInfo">
                <div :class="$style.confirmInfoInner">
                    <dl>
                        <dt>目标账户：</dt>
                        <dd>Payoneer(派安盈)账户：{{ bankAccountInfo.bankAccountNo }}</dd>
                    </dl>
                    <dl>
                        <dt>提现金额：</dt>
                        <dd>
                            {{ formatAmount(formData.withdrawalAmount) }}
                            <span :class="$style.warn"><i class="icon-warn"></i>提现产生的手续费由卖家承担。</span>
                        </dd>
                    </dl>
                </div>
                <div>
                    <el-button :class="$style.btn" @click="back">返回修改</el-button>
                    <el-button :class="$style.btn" type="primary" @click="confirm">确认</el-button>
                </div>
            </div>

            <div v-if="stepIndex === 2" :class="$style.complete">
                <i :class="$style.iconSuccess" class="icon-success"></i>
                <div>
                    <h1 :class="$style.completeTitle">提现请求已成功提交受理！金额为 {{ formatAmount(formData.withdrawalAmount) }}</h1>
                    <ul :class="$style.completeContent">
                        <li>此笔资金将提现至您的账户 {{ bankAccountInfo.bankAccountNo }}，请您及时关注提现状态变化。</li>
                        <li>Payoneer (派安盈) 账户当日或次日即可收到款项，美金结算银行卡通常在5-7工作日收到款项。</li>
                        <li>如一周仍未收到款项，建议您及时去开户行查询原因，如遇特殊情况，可联系我司。</li>
                    </ul>
                </div>
            </div>
        </article>
    </div>
</template>

<script>
    import ProgressBar from '@/components/ProgressBar';
    import { reqCapitalIndex, reqWithdrawal, sendEmail } from '@capital/services/fas';

    export default {
        name: 'Withdrawal',
        components: { ProgressBar },
        data() {
            const self = this;
            return {
                stepsData: ['填写提现信息', '确认提现信息', '提交完成'],
                stepIndex: 0, // 进度索引
                formData: {
                    withdrawalAmount: '', // 提现金额
                    tradePassword: '', // 交易密码
                },
                rules: {
                    withdrawalAmount: [{
                        required: true,
                        message: '请输入提现金额',
                        trigger: 'blur'
                    }, {
                        validator(rule, value, callback) {
                            if (value > self.balanceAmount) {
                                callback(self.maxWithdrawalAmount);
                            }
                            callback();
                        },
                        trigger: 'blur'
                    }],
                    tradePassword: [{
                        required: true,
                        message: '请输入交易密码',
                        trigger: 'blur'
                    }]
                },
                // 银行卡信息
                bankAccountInfo: {
                    type: 'USD', // 银行卡类型，P => P卡 | USD => 美金卡
                    bankAccountNo: '5654 **** 4432', // 银行卡号
                    bankAccountName: 'Payments_Dail***@yeah.net', // 银行户名
                    bankName: 'Bank of China (BKCHCNBJ45A)', // 银行名称
                },
                freezeAmount: '', // 提现中金额
                balanceAmount: '', // 最大可用金额
            };
        },
        computed: {
            maxWithdrawalAmount() {
                return `最大提现金额为 $${this.balanceAmount}`;
            }
        },
        created() {
            this.init();
        },
        methods: {
            /**
             * 初始化页面
             */
            async init() {
                const { status, data } = await reqCapitalIndex.http();
                if (status === 0) {
                    if ((data.bankAccount.shopFinancial || {}).bankAccountNo) {
                        this.bankAccountInfo.type = data.bankAccount.shopFinancial.accountType === 1 ? 'USD' : 'P';
                        this.bankAccountInfo.bankAccountNo = data.bankAccount.shopFinancial.bankAccountNo;
                        this.bankAccountInfo.bankAccountName = data.bankAccount.shopFinancial.bankAccountName;
                        this.bankAccountInfo.bankName = data.bankAccount.shopFinancial.bankName;
                    }
                    this.freezeAmount = Number(data.capitalAccount.freeze_amount);
                    this.balanceAmount = Number(data.capitalAccount.balance_amount);
                }
            },

            /**
             * 格式化金额
             */
            formatAmount(val) {
                return `USD $${val}`;
            },

            /**
             * 设置交易密码
             */
            setTradePassword() {
                this.$confirm('重置密码需要通过邮箱设置，是否确定重置？', '提示').then(async () => {
                    const { status } = await sendEmail.http();
                    if (status === 0) {
                        this.$router.gbPush('/transaction/safe-email');
                    }
                }).catch(() => {});
            },

            /**
             * 下一步
             */
            toNextStep() {
                this.$refs.form.validate(async (valid) => {
                    if (valid) {
                        this.stepIndex = 1;
                    }
                });
            },

            /**
             * 返回修改
             */
            back() {
                this.stepIndex = 0;
            },

            /**
             * 确认
             */
            async confirm() {
                const { status } = await reqWithdrawal.http({
                    data: {
                        bank_card_number: this.bankAccountInfo.bankAccountNo,
                        cash_withdrawal_amount: this.formData.withdrawalAmount,
                        password: this.formData.tradePassword,
                    }
                });
                if (status === 0) {
                    this.stepIndex = 2;
                }
            },

            /**
             * 修改收款账户
             */
            editBankAccount() {
                if (Number(this.freezeAmount) === 0) {
                    // 提现中的金额为0时才允许修改收款账户
                    this.$router.push({
                        name: 'ReceivingAccount'
                    });
                } else {
                    this.$alert('您有提现申请尚在处理中，暂不支持修改收款账户，请耐心等待！');
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';
    .container {
        padding-bottom: 100px;
        background-color: var(--color-white);
    }
    .caption {
        display: flex;
        align-items: center;
        position: relative;
        height: 50px;
        padding-left: 35px;
        line-height: 50px;
        font-size: var(--font-size-largest);
        background-color: var(--background-color-lighter);

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 3px;
            background-color: var(--color-primary-darken);
        }
    }
    .content {
        padding: 20px;
    }
    .progressBar {
        margin-bottom: 50px !important;
    }
    .form {
        width: 70%;
        margin: 0 auto;
    }
    .input,
    .submit {
        width: 300px;
    }
    .textBtn {
        margin-left: 20px;
    }
    .hint {
        line-height: 28px;
        color: var(--color-text-secondary);
        i {
            position: relative;
            top: 2px;
            color: var(--color-primary-icon);
        }
    }
    .bankCardInfo {
        padding: 10px 20px;
        margin-top: -10px;
        background-color: var(--background-color-lighter);
    }
    .bankName {
        display: block;
        padding: 10px 0;
        color: var(--color-text-secondary);
    }
    .radioContent {
        display: inline-block;
        vertical-align: top;
    }
    .confirmInfo {
        padding-top: 20px;
        text-align: center;
    }
    .confirmInfoInner {
        display: inline-block;
        margin-bottom: 40px;
        text-align: left;
        line-height: 30px;
        dl {
            display: table-row;
        }
        dt {
            display: table-cell;
            padding-right: 20px;
        }
    }
    .warn {
        margin-left: 20px;
        color: var(--color-error);
        i {
            margin-right: 10px;
            color: var(--color-error);
        }
    }
    .btn {
        width: 100px;
        margin: 0 15px;
    }
    .complete {
        padding-top: 20px;
        display: flex;
        justify-content: center;
    }
    .iconSuccess {
        font-size: 60px;
        margin-right: 20px;
        color: var(--color-success);
    }
    .completeTitle {
        margin-bottom: 20px;
        font-size: var(--font-size-largest);
    }
    .completeContent {
        line-height: 28px;
        li {
            &:before {
                content: '•';
                margin-right: 5px;
            }
        }
    }
</style>
