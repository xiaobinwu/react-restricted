<template>
    <div :class="$style.container">
        <h1 :class="$style.caption">账户总览</h1>
        <article :class="[$style.content, $style.baseInfo]">
            <dl :class="$style.flexItem">
                <dt>总金额</dt>
                <dd>{{ rechargeAmount }}</dd>
            </dl>
            <dl :class="$style.flexItem">
                <dt>可用金额</dt>
                <dd :class="$style.red">{{ balanceAmount }}</dd>
            </dl>
            <dl :class="$style.flexItem">
                <dt>
                    提现中金额
                    <a :class="$style.textBtn" href="javascript:;" @click="toCapitalReport">查看明细</a>
                </dt>
                <dd>{{ freezeAmountStr }}</dd>
            </dl>
            <div :class="$style.flexItem">
                <el-button :disabled="isStoreFreeze" type="primary" @click="handleWithdrawal">提现</el-button>
            </div>
        </article>

        <h1 :class="$style.caption">收款账户
            <el-button v-if="accountStatus !== 'NONE' && !isStoreFreeze"
                       :class="$style.textBtn" type="text"
                       @click="editBankAccount">修改收款账户</el-button>
        </h1>
        <article :class="$style.content">
            <div v-if="accountStatus === 'NONE'">
                您尚未设置收款账户
                <el-button :class="$style.textBtn" type="text" @click="addBankAccount">前往设置</el-button>
            </div>
            <div v-if="accountStatus !== 'NONE' && curBankAccountInfo.type === 'P'">
                <div :class="$style.bankInfoItem">
                    <label :class="$style.bankInfoLabel">Payoneer(派安盈)账户：</label>
                    <span :class="$style.bankInfoValue">{{ curBankAccountInfo.bankAccountNo }}</span>
                    <a v-if="accountStatusBtn.visible" :class="accountStatusBtn.className" href="javascript:;" @click="clickStatusBtn">
                        {{ accountStatusBtn.text }}
                    </a>
                </div>
            </div>
            <span v-if="accountStatus !== 'NONE' && curBankAccountInfo.type === 'USD'">
                <div :class="$style.bankInfoItem">
                    <label :class="$style.bankInfoLabel">Bank Account No.（银行账号）：</label>
                    <span :class="$style.bankInfoValue">{{ curBankAccountInfo.bankAccountNo }}</span>
                    <a v-if="accountStatusBtn.visible" :class="accountStatusBtn.className" href="javascript:;" @click="clickStatusBtn">
                        {{ accountStatusBtn.text }}
                    </a>
                </div>
                <div :class="$style.bankInfoItem">
                    <label :class="$style.bankInfoLabel">Beneficiary Name（银行户名）：</label>
                    <span :class="$style.bankInfoValue">{{ curBankAccountInfo.bankAccountName }}</span>
                </div>
                <div :class="$style.bankInfoItem">
                    <label :class="$style.bankInfoLabel">Bank Name（银行名称）：</label>
                    <span :class="$style.bankInfoValue">{{ curBankAccountInfo.bankName }}</span>
                </div>
                <div :class="$style.bankInfoItem">
                    <label :class="$style.bankInfoLabel">Swift Code（银行电汇代码）：</label>
                    <span :class="$style.bankInfoValue">{{ curBankAccountInfo.bankCode }}</span>
                </div>
                <div :class="$style.bankInfoItem">
                    <label :class="$style.bankInfoLabel">Bank Address（银行地址）：</label>
                    <span :class="$style.bankInfoValue">{{ curBankAccountInfo.bankAddress }}</span>
                </div>
            </span>
        </article>

        <h1 :class="$style.caption">安全密码</h1>
        <article :class="$style.content">
            <div v-if="!isSetSafePassword && !isStoreFreeze">
                您尚未设置安全密码
                <el-button :class="$style.textBtn" type="text" @click="setSafePassword">前往设置</el-button>
            </div>
            <div v-if="isSetSafePassword && !isStoreFreeze">
                提现或修改收款账户信息时输入，保护账户资金安全
                <el-button :class="$style.textBtn" type="text" @click="resetSafePassword">重置</el-button>
            </div>
        </article>

        <h1 :class="$style.caption">
            最近资金记录
            <el-button :class="$style.textBtn" type="text" @click="toCapitalReport">查看全部</el-button>
        </h1>
        <article :class="$style.content">
            <el-table :data="tableData" border>
                <div slot="empty">暂无数据</div>
                <el-table-column prop="createTime" label="操作时间" align="center" width="150"></el-table-column>
                <el-table-column prop="type" label="业务类型" align="center"></el-table-column>
                <el-table-column prop="tradeContent" label="交易信息" align="center"></el-table-column>
                <el-table-column prop="amount" label="资金明细" align="center"></el-table-column>
            </el-table>
        </article>

        <el-dialog :visible.sync="visibleReasonDialog" width="640px">
            <div :class="$style.reasonTitle">
                <span>抱歉，您提交的收款账户审核未通过，原因如下</span>
                <a :class="$style.textBtn" href="javascript:;" @click="addBankAccount">前往修改</a>
            </div>
            <pre>{{ bankAccountInfoApply.checkRemark }}</pre>
            <div v-if="bankAccountInfo.bankAccountNo" :class="$style.preBankAccountInfo">
                <p>审核拒绝，是否使用之前的收款账户？</p>
                <div :class="$style.preBankAccountInfoInner">
                    <div :class="$style.bankInfoItem">
                        <label :class="$style.bankInfoLabel">Bank Account No.（银行账号）：</label>
                        <span :class="$style.bankInfoValue">{{ bankAccountInfo.bankAccountNo }}</span>
                    </div>
                    <div :class="$style.bankInfoItem">
                        <label :class="$style.bankInfoLabel">Beneficiary Name（银行户名）：</label>
                        <span :class="$style.bankInfoValue">{{ bankAccountInfo.bankAccountName }}</span>
                    </div>
                    <div :class="$style.bankInfoItem">
                        <label :class="$style.bankInfoLabel">Bank Name（银行名称）：</label>
                        <span :class="$style.bankInfoValue">{{ bankAccountInfo.bankName }}</span>
                    </div>
                    <div :class="$style.bankInfoItem">
                        <label :class="$style.bankInfoLabel">Swift Code（银行电汇代码）：</label>
                        <span :class="$style.bankInfoValue">{{ bankAccountInfo.bankCode }}</span>
                    </div>
                    <div :class="$style.bankInfoItem">
                        <label :class="$style.bankInfoLabel">Bank Address（银行地址）：</label>
                        <span :class="$style.bankInfoValue">{{ bankAccountInfo.bankAddress }}</span>
                    </div>
                </div>
                <div :class="$style.center">
                    <el-button @click="hideReasonDialog">取消</el-button>
                    <el-button type="primary" @click="usePreBankAccount">确定使用之前的收款账户</el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import {
        reqCapitalIndex,
        reqCapitalList,
        sendEmail,
        reqRecoverFinancial
    } from '@capital/services/fas';
    import store from '@/assets/js/store';

    export default {
        name: 'SettlementAccount',
        data() {
            return {
                rechargeAmount: '', // 总金额
                balanceAmount: '', // 可用金额
                freezeAmount: '', // 提现中金额
                isStoreFreeze: store.state.user.shopFreeze, // 店铺是否冻结
                accountStatus: '', // 提现账户状态（未设置、正常、审核中、审核拒绝）
                isSetSafePassword: false, // 是否设置安全密码
                tableData: [], // 最新资金交易记录

                // 当前银行卡信息
                bankAccountInfo: {
                    type: '', // 银行卡类型，P => P卡 | USD => 美金卡
                    bankAccountNo: '', // 银行卡号
                    bankAccountName: '', // 银行户名
                    bankName: '', // 银行名称
                    bankCode: '', // 银行电汇代码
                    bankAddress: '', // 银行地址
                    checkRemark: '' // 审核备注
                },

                bankAccountInfoApply: {}, // 格式同 bankAccountInfo
                visibleReasonDialog: false
            };
        },

        computed: {
            accountStatusBtn() {
                const info = {};
                info.visible = ['UNDERWAY', 'FAIL'].includes(this.accountStatus);
                info.className = info.visible ? this.$style[this.accountStatus] : '';
                info.text = this.accountStatus === 'UNDERWAY' ? '审核中' : '审核拒绝';
                return info;
            },

            curBankAccountInfo() {
                return this.accountStatus === 'OK' ? this.bankAccountInfo : this.bankAccountInfoApply;
            },

            freezeAmountStr() {
                return this.formatAmount(this.freezeAmount);
            }
        },

        created() {
            this.init();
            this.getFundReport();
        },

        methods: {
            /**
             * 初始化页面
             */
            async init() {
                const { status, data } = await reqCapitalIndex.http();
                if (status === 0) {
                    this.rechargeAmount = this.formatAmount(data.capitalAccount.recharge_amount || 0);
                    this.balanceAmount = this.formatAmount(data.capitalAccount.balance_amount || 0);
                    this.freezeAmount = data.capitalAccount.freeze_amount || 0;
                    this.accountStatus = this.formatAccountStatus(data.bankAccount.status);
                    this.isSetSafePassword = data.isSetSafePassword === 1;
                    if (data.bankAccount.shopFinancial) {
                        this.bankAccountInfo = this.formatBankAccountInfo(data.bankAccount.shopFinancial);
                    }
                    if (data.bankAccount.shopFinancialApply) {
                        this.bankAccountInfoApply = this.formatBankAccountInfo(data.bankAccount.shopFinancialApply);
                    }
                }
            },

            /**
             * 过滤格式化银行信息
             */
            formatBankAccountInfo(data) {
                return {
                    type: data.accountType === 1 ? 'USD' : 'P',
                    bankAccountNo: data.bankAccountNo,
                    bankAccountName: data.bankAccountName,
                    bankName: data.bankName,
                    bankCode: data.bankCode,
                    bankAddress: `${data.bankAddress.cityName} ${data.bankAddress.addressDetail}`,
                    checkRemark: data.checkRemark
                };
            },

            /**
             * 显示最近资金记录
             */
            async getFundReport() {
                const now = new Date();
                const { status, data } = await reqCapitalList.http({
                    params: {
                        limit: 10,
                        offset: 1,
                        create_time_start: Math.floor((now - 2592000000) / 1000),
                        create_time_end: Math.floor(now / 1000),
                        type: '',
                    }
                });
                if (status === 0) {
                    this.tableData = (data.items || []).map(item => ({
                        createTime: dateFormat(item.create_time),
                        type: item.type === 1 ? '提现' : '放款',
                        tradeContent: item.trade_content,
                        amount: item.amount,
                    }));
                }
            },

            /**
             * 格式化价格
             * @param value
             */
            formatAmount(value) {
                return `USD $${value}`;
            },

            /**
             * 格式化账号状态
             */
            formatAccountStatus(status) {
                if (String(status) === '-2') return 'NONE'; // 未设置
                if (String(status) === '0') return 'UNDERWAY'; // 审核中
                if (String(status) === '2') return 'FAIL'; // 审核不通过
                return 'OK';
            },

            /**
             * 点击审核状态按钮
             */
            clickStatusBtn() {
                if (this.accountStatus === 'UNDERWAY') {
                    // 审核中
                    this.$alert('收款账户审核中，审核一般需要3-5个工作日，请耐心等待！ 审核通过后，将使用新的收款账户进行资金结算。');
                } else if (this.accountStatus === 'FAIL') {
                    // 审核拒绝
                    this.visibleReasonDialog = true;
                }
            },

            /**
             * 提现
             */
            handleWithdrawal() {
                if (this.accountStatus === 'NONE') {
                    // 未设置
                    this.addBankAccount();
                } else if (this.accountStatus === 'UNDERWAY') {
                    // 审核中
                    this.$alert('收款账户审核中，审核一般需要3-5个工作日，请耐心等待！ 审核通过后，将使用新的收款账户进行资金结算。');
                } else {
                    // 账户正常或审核拒绝
                    this.$router.push({
                        name: 'Withdrawal'
                    });
                }
            },

            /**
             * 修改收款账户
             */
            editBankAccount() {
                if (Number(this.freezeAmount) === 0) {
                    // 提现中的金额为0时才允许修改收款账户
                    this.$router.push({
                        name: 'ReceivingAccount'
                    });
                } else {
                    this.$alert('您有提现申请尚在处理中，暂不支持修改收款账户，请耐心等待！');
                }
            },

            /**
             * 添加收款账户
             */
            addBankAccount() {
                this.$router.push({
                    name: 'ReceivingAccount'
                });
            },

            /**
             * 设置安全密码
             */
            setSafePassword() {
                this.$router.gbPush('/transaction/reset-password');
            },

            /**
             * 重置安全密码
             */
            resetSafePassword() {
                this.$confirm('重置密码需要通过邮箱设置，是否确定重置？', '提示').then(async () => {
                    const { status } = await sendEmail.http();
                    if (status === 0) {
                        this.$router.gbPush('/transaction/safe-email');
                    }
                }).catch(() => {});
            },

            /**
             * 跳转至资金明细
             */
            toCapitalReport() {
                this.$router.push({
                    name: 'CapitalReport',
                    query: {
                        activeName: 'WithdrawalsRecord'
                    }
                });
            },

            /**
             * 关闭弹框
             */
            hideReasonDialog() {
                this.visibleReasonDialog = false;
            },

            /**
             * 使用之前的收款账户
             */
            async usePreBankAccount() {
                const { status } = await reqRecoverFinancial.http();
                if (status === 0) {
                    this.hideReasonDialog();
                    window.location.reload();
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    .container {
        padding-bottom: 100px;
        background-color: var(--color-white);
    }
    .caption {
        display: flex;
        align-items: center;
        position: relative;
        height: 50px;
        padding-left: 35px;
        line-height: 50px;
        font-size: var(--font-size-largest);
        background-color: var(--background-color-lighter);

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 3px;
            background-color: var(--color-primary-darken);
        }
    }
    .textBtn {
        margin-left: 20px;
    }
    .content {
        padding: 30px 20px;
    }
    .baseInfo {
        display: flex;

        dt {
            margin-bottom: 10px;
            line-height: 20px;
        }
        dd {
            font-size: var(--font-size-largest);
            line-height: 25px;
            white-space: nowrap;
        }
    }
    .flexItem {
        padding-left: 20px;
        flex: 1;
    }
    .red {
        color: var(--color-danger);
    }
    .bankInfoItem {
        display: table-row;
        line-height: 28px;
    }
    .bankInfoLabel {
        display: table-cell;
        min-width: 190px;
        padding-right: 10px;
        text-align: right;
        white-space: nowrap;
        color: var(--color-text-secondary);
    }
    .bankInfoValue {
        display: table-cell;
        word-break: break-word;
        word-wrap: break-word;
    }
    .UNDERWAY {
        margin-left: 20px;
        color: var(--color-warning) !important;
    }
    .FAIL {
        margin-left: 20px;
        color: var(--color-danger) !important;
    }
    .reasonTitle {
        margin-bottom: 20px;
    }
    .preBankAccountInfo {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid var(--border-color-lighter);
    }
    .preBankAccountInfoInner {
        padding: 20px 0;
    }
    .center {
        text-align: center;
    }
</style>
