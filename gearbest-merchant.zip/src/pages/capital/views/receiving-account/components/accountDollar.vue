<template>
    <el-form
        ref="formCollectionInfo"
        :model="formCollectionInfo"
        :rules="rules"
        label-position="right"
        label-width="350px"
        class="demo-ruleForm">
        <div :class="$style.info">
            <el-form-item :label="$t('capital.bankaccount.no')" prop="bankAccountNo">
                <el-input
                    :class="$style.formLargeInput"
                    :placeholder="$t('capital.payoneer.place.bankno')"
                    v-model="formCollectionInfo.bankAccountNo" maxlength="100" @change="validateAccountNo"></el-input>
            </el-form-item>
            <el-form-item :label="$t('capital.beneficiary.name')" prop="bankAccountName">
                <el-input
                    :class="$style.formLargeInput"
                    :placeholder="$t('capital.payoneer.place.en')"
                    v-model="formCollectionInfo.bankAccountName" maxlength="100" @change="validateAccountName"></el-input>
            </el-form-item>
            <el-form-item :label="$t('capital.bank.name')" prop="bankName">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('capital.payoneer.place.en')"
                    v-model="formCollectionInfo.bankName" maxlength="100" @change="validateBankName"></el-input>
            </el-form-item>
            <el-form-item :label="$t('capital.bank.swiftcode')" prop="bankCode">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('capital.payoneer.place.bankcode')"
                    v-model="formCollectionInfo.bankCode" maxlength="100" @change="validateBankCode"></el-input>
            </el-form-item>

            <el-form-item :label="$t('capital.bank.address')" prop="bankAddress">
                <address-linkage v-model="formCollectionInfo.bankAddress" :countrys="countrys" :is-en="true">
                    <el-input
                        v-model="formCollectionInfo.bankAddress.addressDetail"
                        :placeholder="$t('capital.payoneer.place.en')"
                        maxlength="200"
                        @change="validateDetailed('bankAddress')"></el-input>
                </address-linkage>
            </el-form-item>
            <el-form-item
                :label="$t('capital.bank.postalcode')"
                :rules="[
                    { required: true, message: this.$t('capital.postalcode.validate.empty'), trigger: 'blur' },
                    { max: 30, message: this.$t('capital.postalcode.validate.errlength'), trigger: 'blur' }
                ]"
                prop="bankAddress.zipCode">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('capital.payoneer.place.number')"
                    v-model="formCollectionInfo.bankAddress.zipCode"
                    maxlength="30"
                    @change="zipCodeValidata"></el-input>
            </el-form-item>
            <el-form-item :label="$t('capital.business.address')" prop="businessAddress">
                <address-linkage v-model="formCollectionInfo.businessAddress" :countrys="countrys" :is-en="true">
                    <el-input
                        v-model="formCollectionInfo.businessAddress.addressDetail"
                        :placeholder="$t('capital.payoneer.place.en')"
                        maxlength="200"
                        @change="validateDetailed('businessAddress')" ></el-input>
                </address-linkage>
            </el-form-item>
            <el-form-item :label="$t('capital.notify.mobileno')" prop="mobileNo">
                <el-input
                    :class="$style.formSmallInput"
                    v-model="formCollectionInfo.mobileNo"
                    :placeholder="$t('capital.contact.prompt.phone')"
                    :maxlength="phoneMaxLength"
                    class="input-with-select"
                    @change="phoneValidata">
                    <el-select
                        slot="prepend"
                        :class="$style.codeSelect"
                        v-model="formCollectionInfo.mobileAreaCode"
                        @change="changeCountryCode">
                        <el-option
                            v-for="item in mobileAreaCodeList"
                            :key="item.country+'_'+item.phoneCode"
                            :label="'+'+item.phoneCode"
                            :value="item.phoneCode"></el-option>
                    </el-select>
                </el-input>
            </el-form-item>

            <el-form-item :label="$t('capital.account.scan')" prop="scanUrlList">
                <p :class="$style.uploadTitle">
                    <a :href="`${getAssistPath('bank-account-information.doc')}`" download="bank-account-information">
                        {{ $t('capital.account.scan.clickDownload') }} </a>
                    {{ $t('capital.accountscan.title') }}
                </p>
                <el-upload
                    :class="[formCollectionInfo.scanUrlList.length < 3 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadLegal"
                    :on-success="successLegal"
                    :on-remove="removeLegal"
                    :show-file-list="true"
                    :file-list="formCollectionInfo.scanUrlList"
                    :data="{ method: 'bankAccountAuth' }"
                    action="/image-manage/image-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('capital.accountscan.condition') }}</p>
            </el-form-item>
        </div>
        <div :class="$style.buttonBox">
            <slot></slot>
            <el-button type="primary" @click="submitForm('formCollectionInfo')">{{ $t('capital.account.submitaudit') }}</el-button>
        </div>
    </el-form>
</template>

<script>
    import {
        phonecodeList,
        countrysListGet
    } from '@capital/services/fas';
    import addressLinkage from './AddressLinkage';
    import { getAssistPath } from '@/assets/js/utils/assist';

    export default {
        name: 'Material',
        components: {
            'address-linkage': addressLinkage
        },
        props: {
            userInfo: {
                type: Object,
                required: true,
            },
        },
        data() {
            const validatePhone = (rule, value, callback) => {
                const reg = /^[1]+.?[0-9]*$/;
                if (!reg.test(value)) {
                    callback(new Error(this.$t('capital.notifymobile.validate.empty')));
                } else {
                    callback();
                }
            };
            const validateAddre = (rule, value, callback) => {
                if (!value.countryCode || !value.addressDetail) {
                    callback(new Error(this.$t('capital.collectionaddress.validate.empty')));
                } else {
                    callback();
                }
            };
            return {
                getAssistPath,
                phoneMaxLength: Number,
                dialogImageUrl: '',
                countrys: [],
                mobileAreaCodeList: [],
                formCollectionInfo: {
                    accountType: 1,
                    bankAccountNo: '',
                    bankAccountName: '',
                    bankName: '',
                    bankCode: '',
                    mobileAreaCode: '86',
                    mobileNo: '',
                    scanUrlList: [],
                    bankAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: '',
                        zipCode: ''
                    },
                    businessAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    }
                },
                // 校验规则
                rules: {
                    bankAccountNo: [
                        {
                            required: true, // 是否必填
                            message: this.$t('capital.bankaccount.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('capital.collection.validate.errlength'),
                        }
                    ],
                    bankAccountName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('capital.beneficiary.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('capital.collection.validate.errlength'),
                        },
                    ],
                    bankName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('capital.bankname.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('capital.collection.validate.errlength'),
                        }
                    ],
                    bankCode: [
                        {
                            required: true, // 是否必填
                            message: this.$t('capital.swiftcode.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('capital.collection.validate.errlength'),
                        }
                    ],
                    mobileNo: [
                        {
                            required: true, // 是否必填
                            message: this.$t('capital.contact.validate.phone.empty'),
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validatePhone,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    bankAddress: [
                        {
                            required: true, // 是否必填
                            validator: validateAddre,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    businessAddress: [
                        {
                            required: true, // 是否必填
                            validator: validateAddre,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    scanUrlList: [
                        {
                            required: true, // 是否必填
                            message: this.$t('capital.accountscan.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                }
            };
        },
        watch: {
            userInfo() {
                // 初始化表单
                this.init();
            },
        },
        created() {
            this.init();
            this.getCountrys();
            this.getPhonecode();
            this.changeCountryCode();
        },
        methods: {
            init() {
                this.formCollectionInfo.mobileAreaCode = this.userInfo.landlinePhoneAreaCode || '';
                this.formCollectionInfo.mobileNo = this.userInfo.landlinePhone;
            },

            // 获取国家
            async getCountrys() {
                const { status, data } = await countrysListGet.http({
                    showError: true
                });
                if (status === 0) {
                    this.countrys = data;
                }
            },
            // 获取手机区号
            async getPhonecode() {
                const { status, data } = await phonecodeList.http();
                if (status === 0) {
                    this.mobileAreaCodeList = data;
                }
            },

            // 提交表单
            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {

                        // int类型处理（提交数据时把空字符串转为0）
                        this.formCollectionInfo.bankAddress.cdpProvinceId = this.formCollectionInfo.bankAddress.cdpProvinceId || 0;
                        this.formCollectionInfo.bankAddress.cdpCityId = this.formCollectionInfo.bankAddress.cdpCityId || 0;
                        this.formCollectionInfo.businessAddress.cdpProvinceId = this.formCollectionInfo.businessAddress.cdpProvinceId || 0;
                        this.formCollectionInfo.businessAddress.cdpCityId = this.formCollectionInfo.businessAddress.cdpCityId || 0;
                        this.$emit('update', this.formCollectionInfo);
                    }
                });
            },
            changeCountryCode() {
                const vm = this;
                vm.phoneMaxLength = vm.formCollectionInfo.mobileAreaCode === '86' ? 11 : 30;
                if (vm.formCollectionInfo.mobileAreaCode === '86') {
                    const validatePhone = (rule, value, callback) => {
                        const reg = /^[1]+.?[0-9]*$/;
                        if (!reg.test(value)) {
                            callback(new Error(vm.$t('capital.notifymobile.validate.empty')));
                        } else {
                            callback();
                        }
                    };
                    this.rules.mobileNo = [
                        {
                            required: true, // 是否必填
                            message: vm.$t('capital.contact.validate.phone.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validatePhone,
                        },
                    ];
                    if (this.formCollectionInfo.mobileNo.length > 11) {
                        this.formCollectionInfo.mobileNo = this.formCollectionInfo.mobileNo.substr(0, 11);
                    }
                } else {
                    this.rules.mobileNo = [
                        {
                            required: true, // 是否必填
                            message: vm.$t('capital.contact.validate.phone.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ];
                }

            },

            // 图片上传前验证
            beforeUploadFn(file) {
                console.log(file);
                const isJPG = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'].indexOf(file.type) >= 0;
                const isLt2M = file.size / 1024 / 1024 < 1;

                if (!isJPG) {
                    this.$message.error(this.$t('capital.accountscan.validate.errformat'));
                }
                if (!isLt2M) {
                    this.$message.error(this.$t('capital.accountscan.validate.errsize'));
                }
                return isJPG && isLt2M;
            },

            // 图片删除
            removeUploadFn(file, urlList) {
                this.formCollectionInfo[urlList].forEach((item, index) => {
                    if (item.url === file.url) {
                        this.formCollectionInfo[urlList].splice(index, 1);
                    }
                });
            },

            // 上传法人身份证前
            beforeUploadLegal(file) {
                return this.beforeUploadFn(file);
            },
            // 上传法人身份证成功
            successLegal(res, file) {
                const { status, data, msg } = res;
                if (status === 0) {
                    this.formCollectionInfo.scanUrlList[this.formCollectionInfo.scanUrlList.length] = { url: data.url };
                } else {
                    this.$message.error(msg);
                }
            },
            // 删除法人身份证
            removeLegal(file) {
                this.removeUploadFn(file, 'scanUrlList');
            },
            // 地址只能输入英文
            validateDetailed(ev) {
                this.formCollectionInfo[ev].addressDetail = this.formCollectionInfo[ev].addressDetail.replace(
                    /[^\d\w\s!@#$%^&*()_+<>?:,./;’]/g, ''
                );
            },
            phoneValidata() {
                this.formCollectionInfo.mobileNo = this.formCollectionInfo.mobileNo.replace(/[^0-9]/g, '');
            },
            zipCodeValidata() {
                this.formCollectionInfo.bankAddress.zipCode = this.formCollectionInfo.bankAddress.zipCode.replace(/[^0-9]/g, '');
            },
            validateAccountName() {
                this.formCollectionInfo.bankAccountName = this.formCollectionInfo.bankAccountName.replace(/[^\d\w\s]/g, '');
            },
            validateBankName() {
                this.formCollectionInfo.bankName = this.formCollectionInfo.bankName.replace(/[^\d\w\s]/g, '');
            },
            validateAccountNo() {
                this.formCollectionInfo.bankAccountNo = this.formCollectionInfo.bankAccountNo.replace(/[^0-9]/g, '');
            },
            validateBankCode() {
                this.formCollectionInfo.bankCode = this.formCollectionInfo.bankCode.replace(/[^0-9-A-Za-z]/g, '');
            }

        },
    };
</script>

<style module>
    @import 'variable.css';

    .overstepLimit [class~="el-upload"]{
        display: none;
    }
    .codeSelect {
        width: 80px;
        padding: 0;
        text-align: left;
    }
    .codeSelect [class~="el-input__inner"]{
        width: 60px;
        padding: 0 5px;
        text-align: center;
    }
    .codeSelect [class~="el-input__suffix"]{
        right: 0;
    }
    .info{
        width: 100%;
        margin: 30px auto 50px;
    }
    .formLargeInput{
        width: 550px;
    }
    .formSmallInput{
        width: 300px;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px;
        text-align: right;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
    }
    .uploadTitle{
        color: var(--color-black);
        margin-bottom: 10px;
    }
    .uploadCondition{
        color: var(--color-text-regular);
        margin-top: 20px;
    }
    .uploadPdf [class~="el-upload-list__item"]{
        background: url('@user/assets/img/pdf-bg.png') center no-repeat;
        background-size: 80%;
    }
    .uploadPdf [class~="el-upload-list__item-thumbnail"]{
        background-color: var(--color-white);
    }
</style>
