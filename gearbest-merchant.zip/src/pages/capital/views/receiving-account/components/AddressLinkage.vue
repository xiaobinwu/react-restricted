<template>
    <el-row>
        <el-col :class="$style.marginRight" :span="4">
            <el-select
                :class="$style.selectedItme"
                :value="countryCode"
                :placeholder="isEn ? $t('capital.please.choose.en') : $t('capital.please.choose')"
                clearable
                filterable
                @input="changeAddress($event, 'countryCode')"
                @change="getProvince($event)"
            >
                <el-option
                    v-for="(item, index) in countrys"
                    :key="index"
                    :value="item.countryCode"
                    :label="positions === 'CN' ? item.countryCnName : item.countryName"
                />
            </el-select>

        </el-col>
        <el-col :class="$style.marginRight" :span="4">
            <!-- <el-input
                v-if="provinces.length === 0"
                :disabled="countryCode === ''"
                :value="cdpProvinceId"
                :placeholder="isEn ? $t('capital.please.choose.en') : $t('capital.please.choose')"
                @input="changeAddress($event, 'cdpProvinceId')"
                @change="validateEntryEn('cdpProvinceId')"
            /> -->
            <el-select
                :class="$style.selectedItme"
                :disabled="countryCode === ''"
                :value="cdpProvinceId"
                :placeholder="isEn ? $t('capital.please.choose.en') : $t('capital.please.choose')"
                clearable
                filterable
                @input="changeAddress($event, 'cdpProvinceId')"
                @change="getCity($event)"
            >
                <el-option
                    v-for="(item, index) in provinces"
                    :key="index"
                    :value="item.cdpProvinceId"
                    :label="positions === 'CN' ? item.provinceCnName : item.provinceName"
                />
            </el-select>
        </el-col>
        <el-col :class="$style.marginRight" :span="4">
            <!-- <el-input
                v-if="citys.length === 0"
                :disabled="cdpProvinceId === ''"
                :value="cityName"
                :placeholder="isEn ? $t('capital.please.choose.en') : $t('capital.please.choose')"
                @input="changeAddress($event, 'cityName')"
                @change="validateEntryEn('cityName')"
            /> -->
            <el-select
                :class="$style.selectedItme"
                :value="cdpCityId"
                :disabled="cdpProvinceId === ''"
                :placeholder="isEn ? $t('capital.please.choose.en') : $t('capital.please.choose')"
                clearable
                filterable
                @input="changeAddress($event, 'cdpCityId', 'cityName')"
            >
                <el-option
                    v-for="(item, index) in citys"
                    :key="index"
                    :value="item.cdpCityId"
                    :label="positions === 'CN' ? item.cityCnName : item.cityName"
                />
            </el-select>
        </el-col>
        <el-col :class="$style.marginRight" :span="8">
            <slot></slot>
        </el-col>
        <el-col :span="2">
            <slot name="ditto"></slot>
        </el-col>
    </el-row>
</template>
<script>
    import {
        provincesListGet,
        citysListGet
    } from '@capital/services/fas';

    export default {
        name: 'AddressCascadedSelect',
        props: {
            value: {
                type: Object,
                required: true,
                default() {
                    return {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: ''
                    };
                }
            },
            countrys: {
                type: Array,
                required: true,
            },
            isEn: {
                type: Boolean,
                default: false
            },
            positions: {
                type: String,
                default: '',
            },
            ditto: {
                type: Boolean,
                default: false
            },
        },
        data() {
            return {
                provinces: [],
                citys: []
            };
        },
        computed: {
            countryCode() {
                return this.value.countryCode;
            },
            cdpProvinceId() {
                return this.value.cdpProvinceId;
            },
            cdpCityId() {
                return this.value.cdpCityId;
            },
        },
        watch: {
            'value.countryCode': {
                handler(val, oldVal) {
                    if (!oldVal && this.cdpProvinceId) {
                        this.getProvince(val);
                    } else if (!val || (val !== oldVal)) {
                        this.$emit('input', { ...this.value, cdpProvinceId: '', cdpCityId: '' });
                        this.provinces = [];
                        this.citys = [];
                    }
                }
            },
            'value.cdpProvinceId': {
                handler(val, oldVal) {
                    if (!oldVal && this.cdpCityId) {
                        this.getCity(val);
                    } else if (!val || (val !== oldVal)) {
                        this.$emit('input', { ...this.value, cdpCityId: '' });
                        this.citys = [];
                    }
                }
            },
        },
        mounted() {
            this.setDefaultValue();
        },
        methods: {
            // 设置默认值
            setDefaultValue() {
                if (this.countryCode) {
                    this.getProvince(this.countryCode);
                }
                if (this.cdpProvinceId) {
                    this.getCity(this.cdpProvinceId);
                }
            },

            // 获取省份
            async getProvince(val) {
                if (!val) {
                    return;
                }
                const params = {
                    countryCode: val
                };
                const { status, data } = await provincesListGet.http({
                    showError: true,
                    params: {
                        ...params
                    }
                });
                if (status === 0) {
                    this.provinces = data;
                }
            },
            // 获取城市
            async getCity(val) {
                if (!val) {
                    return;
                }
                const params = {
                    provinceCode: val
                };
                const { status, data } = await citysListGet.http({
                    showError: true,
                    params: {
                        ...params
                    }
                });
                if (status === 0) {
                    this.citys = data;
                }
            },
            changeAddress(val, key, cityidKey) {
                let cityName = '';
                if (cityidKey && this.citys) {
                    this.citys.forEach((item) => {
                        if (item.cdpCityId === val) {
                            cityName = item.cityName;
                        }
                    });
                }
                if (cityName) {
                    this.$emit('input', { ...this.value, [key]: val, [cityidKey]: cityName });
                } else {
                    this.$emit('input', { ...this.value, [key]: val });
                }
            },
            validateEntryEn(ev) {
                if (this.isEn) {
                    this.value[ev] = this.value[ev].replace(/[^0-9-a-z]/g, '');
                }
            }
        }
    };
</script>

<style module>
    .marginRight{
        margin-right: 10px;
    }
    .selectedItme{
        width: 100%;
    }
</style>
