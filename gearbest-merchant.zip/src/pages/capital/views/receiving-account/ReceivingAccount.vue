<template>
    <div :class="$style.container">
        <!-- 收款账户信息 -->
        <div :class="$style.radioBox">
            <label :class="$style.radioLabel">{{ $t('capital.account.collection') }}</label>
            <el-radio-group v-model="accountType">
                <el-radio
                    v-for="item in AccountTypeList"
                    :key="item.val"
                    :label="item.val">{{ $t(`capital.account.${item.name}`) }}</el-radio>
            </el-radio-group>
            <p :class="$style.accountWarning">
                <i class="el-icon-warning"></i>
                {{ $t('capital.account.warning') }}
            </p>
        </div>
        <account-dollar
            v-if="accountType === 1"
            :user-info="userInfo"
            @update="postAccountInfo">
            <router-link :to="{name: 'SettlementAccount'}" class="el-button">{{ $t('capital.cancel') }}</router-link>
        </account-dollar>
        <account-payoneer
            v-if="accountType === 2"
            :user-info="userInfo"
            @update="postAccountInfo">
            <router-link :to="{name: 'SettlementAccount'}" class="el-button">{{ $t('capital.cancel') }}</router-link>
        </account-payoneer>

    </div>
</template>

<script>
    import {
        getUserInfo,
        submitAudit
    } from '@capital/services/fas';
    import accountDollar from './components/accountDollar';
    import accountPayoneer from './components/accountPayoneer';

    export default {
        name: 'Entry',
        components: {
            'account-dollar': accountDollar,
            'account-payoneer': accountPayoneer,
        },
        data() {
            return {
                userInfo: {},
                accountType: 1,
                AccountTypeList: [
                    { name: 'dollar', val: 1 },
                    { name: 'payoneer', val: 2 }
                ]
            };
        },

        async created() {
            await this.init();
            // const { accountStatus } = this.userInfo;
            // if (accountStatus === 0) {
            //     this.stepNo = 0;
            // } else if (accountStatus === 1 || accountStatus === 2) {
            //     this.stepNo = 4;
            // }
        },
        methods: {
            async init() {
                const { status, data } = await getUserInfo.http();
                if (status === 0) {
                    this.userInfo = data;
                }
            },

            async postAccountInfo(accountInfo) {
                this.$confirm('收款账户审核期间暂不可用，审核需要3-5个工作日。 审核通过后，将使用新的收款账户进行资金结算。', {
                    center: true
                }).then(async () => {
                    const urlList = [];
                    accountInfo.scanUrlList.forEach((item) => {
                        urlList.push(item.url);
                    });
                    const postInfo = { ...accountInfo, scanUrlList: urlList };
                    const { status, msg } = await submitAudit.http({
                        data: {
                            ...postInfo
                        }
                    });

                    if (status !== 0) {
                        this.$message.error(msg);
                    } else {
                        this.$router.push({
                            name: 'SettlementAccount'
                        });
                    }
                }).catch(() => {});
            }
        }

    };
</script>

<style module>
    @import 'variable.css';

    .container{
        margin: 0 auto;
        padding: 1px;
        background-color: var(--color-white);
    }
    .container [class~="line"]{
        text-align: center;
    }
    .container [class~="el-input-group__prepend"]{
        background-color: var(--color-white);
    }
    .radioBox{
        margin: 30px auto 0;
    }
    .radioLabel{
        display: inline-block;
        width: 200px;
        text-align: right;
        padding: 0 12px 0 0;
    }
    .accountWarning{
        display: inline-block;
        color: var(--color-error );
        margin-left: 30px;
    }


</style>
