<!--增值服务费记录查询-->
<template>
    <div>
        <el-form :inline="true" label-suffix="：">
            <el-form-item label="流水单号">
                <el-input v-model="filter.orderNo"></el-input>
            </el-form-item>
            <el-form-item label="结算状态">
                <el-select v-model="filter.settlementStatus" clearable placeholder="请选择">
                    <el-option v-for="(item, index) in settlementStatusTests" :label="item" :value="index" :key="index"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="账单编号">
                <el-input v-model="filter.orderCode"></el-input>
            </el-form-item>
            <el-form-item label="扣款时间">
                <el-date-picker
                    v-model="filter.deductTime"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="服务时间">
                <el-date-picker
                    v-model="filter.serviceDate"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <div :class="$style.toolBar">
            <el-button :disabled="tableData.length <= 0" @click="exportData">导出表格</el-button>
        </div>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column :formatter="formatDate" prop="deduct_time" label="扣款时间" align="center" width="150"></el-table-column>
            <el-table-column label="账单编号" align="center" min-width="180">
                <template slot-scope="scope">
                    <a href="javascript:;" @click="goToBillDetail(scope.row.order_code)">{{ scope.row.order_code }}</a>
                </template>
            </el-table-column>
            <el-table-column label="结算状态" align="center" width="100">
                <template slot-scope="scope">
                    {{ settlementStatusTests[scope.row.settlement_status] }}
                </template>
            </el-table-column>
            <el-table-column prop="project_name" label="费用项目" align="center" width="100"></el-table-column>
            <el-table-column prop="settlement_amount" label="结算金额" align="center" min-width="100"></el-table-column>
            <el-table-column prop="order_no" label="流水单号" align="center" min-width="200"></el-table-column>
            <el-table-column :formatter="formatDate" prop="service_date" label="服务日期" align="center" width="150"></el-table-column>
            <el-table-column prop="number" label="数量" align="center" width="100"></el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="offset"
            :page-size="limit"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { openNewPage } from '@/assets/js/utils/url';
    import { reqValueAddedSerivceList } from '@capital/services/fas';

    export default {
        name: 'ValueAddedSerivceRecordQuery',
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                limit: 10, // 每页显示条数
                offset: 1, // 当前页码
                settlementStatus: '', // 结算状态
                orderType: '', // 项目费用类型
                serviceDate: [now - 2592000000, now], // 服务时间
                deductTime: [], // 扣款时间
                orderNo: '', // 订单号
                orderCode: '', // 账单编码
                projectId: '', // 费用项目ID
            };

            return {
                DATA,
                activeName: 'ValueAddedSerivceRecordQuery',
                filter: {
                    settlementStatus: DATA.settlementStatus, // 结算状态
                    orderType: DATA.orderType, // 项目费用类型
                    serviceDate: DATA.serviceDate, // 服务时间
                    deductTime: DATA.deductTime, // 扣款时间
                    orderNo: DATA.orderNo, // 订单号
                    orderCode: DATA.orderCode, // 账单编码
                    projectId: DATA.projectId, // 费用项目ID
                },
                limit: DATA.limit, // 每页显示条数
                offset: DATA.offset, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                downloadLink: '', // 导出表格下载链接

                // 结算状态
                settlementStatusTests: {
                    1: '待结算',
                    2: '已生成账单',
                    3: '账单已审核',
                    4: '已扣款',
                    5: '扣款失败',
                },
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        limit,
                        offset,
                        settlementStatus,
                        orderType,
                        serviceDateStart,
                        serviceDateEnd,
                        deductTimeStart,
                        deductTimeEnd,
                        orderNo,
                        orderCode,
                        projectId,
                    } = this.$route.query;

                    this.limit = Number(limit) || this.DATA.limit;
                    this.offset = Number(offset) || this.DATA.offset;
                    this.filter.settlementStatus = settlementStatus || this.DATA.settlementStatus;
                    this.filter.orderType = orderType || this.DATA.orderType;
                    this.filter.serviceDate = serviceDateStart && serviceDateEnd
                        ? [serviceDateStart * 1000, serviceDateEnd * 1000] : this.DATA.serviceDate;
                    this.filter.deductTime = deductTimeStart && deductTimeEnd
                        ? [deductTimeStart * 1000, deductTimeEnd * 1000] : this.DATA.deductTime;
                    this.filter.orderNo = orderNo || this.DATA.orderNo;
                    this.filter.orderCode = orderCode || this.DATA.orderCode;
                    this.filter.projectId = projectId || this.DATA.projectId;

                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.limit !== this.DATA.limit) query.limit = this.limit;
                if (this.offset !== this.DATA.offset) query.offset = this.offset;
                if (this.filter.settlementStatus !== this.DATA.settlementStatus) query.settlementStatus = this.filter.settlementStatus;
                if (this.filter.orderType !== this.DATA.orderType) query.orderType = this.filter.orderType;
                if (this.filter.serviceDate !== null && this.filter.serviceDate !== this.DATA.serviceDate) {
                    query.serviceDateStart = Math.floor(this.filter.serviceDate[0] / 1000);
                    query.serviceDateEnd = Math.floor(this.filter.serviceDate[1] / 1000);
                }
                if (this.filter.deductTime !== null && this.filter.deductTime !== this.DATA.deductTime) {
                    query.deductTimeStart = Math.floor(this.filter.deductTime[0] / 1000);
                    query.deductTimeEnd = Math.floor(this.filter.deductTime[1] / 1000);
                }
                if (this.filter.orderNo !== this.DATA.orderNo) query.orderNo = this.filter.orderNo;
                if (this.filter.orderCode !== this.DATA.orderCode) query.orderCode = this.filter.orderCode;
                if (this.filter.projectId !== this.DATA.projectId) query.projectId = this.filter.projectId;
                query.activeName = this.activeName;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqValueAddedSerivceList.http({
                    params: {
                        limit: this.limit,
                        offset: this.offset,
                        settlement_status: this.filter.settlementStatus,
                        service_date_start: this.filter.serviceDate.length === 0 ? '' : Math.floor(this.filter.serviceDate[0] / 1000),
                        service_date_end: this.filter.serviceDate.length === 0 ? '' : Math.floor(this.filter.serviceDate[1] / 1000),
                        deduct_time_start: this.filter.deductTime.length === 0 ? '' : Math.floor(this.filter.deductTime[0] / 1000),
                        deduct_time_end: this.filter.deductTime.length === 0 ? '' : Math.floor(this.filter.deductTime[1] / 1000),
                        order_no: this.filter.orderNo,
                        order_code: this.filter.orderCode,
                        projectId: this.filter.projectId,
                    }
                });
                if (status === 0) {
                    this.downloadLink = data.downloadLink;
                    this.totalCount = data.total || 0;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    settlementStatus: this.DATA.settlementStatus,
                    orderType: this.DATA.orderType,
                    serviceDate: this.DATA.serviceDate,
                    deductTime: this.DATA.deductTime,
                    orderNo: this.DATA.orderNo,
                    orderCode: this.DATA.orderCode,
                    projectId: this.DATA.projectId,
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.offset = 1;
                this.updateUrl();
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * limit 改变时会触发
             */
            handleSizeChange(val) {
                this.limit = val;
                this.offset = 1;
                this.updateUrl();
            },

            /**
             * offset 改变时会触发
             */
            handleCurrentChange(val) {
                this.offset = val;
                this.updateUrl();
            },

            /**
             * 导出表格
             */
            exportData() {
                if (this.tableData.length > 0 && this.downloadLink) {
                    openNewPage(this.downloadLink);
                }
            },

            /**
             * 跳转到仓储账单详情页
             * @param billCode
             */
            goToBillDetail(billCode) {
                this.$router.gbPush(`/capital/warehouse-bill-detail/${billCode}`);
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .pagination {
        margin-top: 20px;
    }

    .toolBar {
        text-align: right;
        margin: 0 0 15px;
    }
</style>
