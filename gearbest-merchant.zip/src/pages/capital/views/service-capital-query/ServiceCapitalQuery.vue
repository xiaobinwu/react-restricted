<!--服务资金查询-->
<template>
    <div :class="$style.container">
        <el-tabs v-model="activeName" type="card" @tab-click="tabClick">
            <el-tab-pane label="操作费记录查询" name="OperationRecordQuery"></el-tab-pane>
            <el-tab-pane label="仓储费记录查询" name="WarehouseRecordQuery"></el-tab-pane>
            <el-tab-pane label="增值服务费记录查询" name="ValueAddedSerivceRecordQuery"></el-tab-pane>
            <el-tab-pane label="物流明细查询" name="LogisticsRecordQuery"></el-tab-pane>
            <el-tab-pane label="调整记录查询" name="AdjustRecordQuery"></el-tab-pane>
        </el-tabs>

        <component :is="activeName"></component>
    </div>
</template>

<script>
    import OperationRecordQuery from './components/OperationRecordQuery';
    import WarehouseRecordQuery from './components/WarehouseRecordQuery';
    import ValueAddedSerivceRecordQuery from './components/ValueAddedSerivceRecordQuery';
    import LogisticsRecordQuery from './components/LogisticsRecordQuery';
    import AdjustRecordQuery from './components/AdjustRecordQuery';

    export default {
        name: 'ServiceCapitalQuery',
        components: {
            OperationRecordQuery,
            WarehouseRecordQuery,
            ValueAddedSerivceRecordQuery,
            LogisticsRecordQuery,
            AdjustRecordQuery
        },

        data() {
            return {
                activeName: this.getTypeName()
            };
        },

        watch: {
            $route() {
                this.activeName = this.getTypeName();
            }
        },

        methods: {
            /**
             * 返回有效的类型名称
             */
            getTypeName() {
                const typeName = this.$route.query.activeName;
                return [
                    'OperationRecordQuery',
                    'WarehouseRecordQuery',
                    'ValueAddedSerivceRecordQuery',
                    'LogisticsRecordQuery',
                    'AdjustRecordQuery'
                ].includes(typeName) ? typeName : 'OperationRecordQuery';
            },

            /**
             * 切换Tabs标签页的时候更新URL的type参数
             */
            tabClick(tab) {
                this.$router.push({
                    query: {
                        activeName: tab.name
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }
</style>
