<!--仓储账单-->
<template>
    <div :class="$style.container">
        <el-form :inline="true" label-suffix="：">
            <el-form-item label="账单编号">
                <el-input v-model="filter.orderNo"></el-input>
            </el-form-item>
            <el-form-item label="申诉状态">
                <el-select v-model="filter.operateStatus" placeholder="请选择" clearable>
                    <el-option v-for="item in appealStatusOptions"
                               :key="item.value"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="扣款时间">
                <el-date-picker
                    v-model="filter.deductTime"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column label="账单编号" align="center" min-width="180">
                <template slot-scope="scope">
                    <a href="javascript:;" @click="goToBillDetail(scope.row.order_no)">{{ scope.row.order_no }}</a>
                </template>
            </el-table-column>
            <el-table-column :formatter="formatBillDate" label="账期" align="center" width="180"></el-table-column>
            <el-table-column prop="operate_amount_sum" label="操作费" align="center" min-width="100"></el-table-column>
            <el-table-column prop="service_amount_sum" label="增值服务费" align="center" min-width="100"></el-table-column>
            <el-table-column prop="lease_amount_sum" label="仓储费" align="center" min-width="100"></el-table-column>
            <el-table-column prop="adjust_amount_sum" label="账单调整" align="center" min-width="100"></el-table-column>
            <el-table-column prop="total_amount" label="扣款金额" align="center" min-width="100"></el-table-column>
            <el-table-column :formatter="formatDate" prop="deduct_time" label="扣款时间" align="center" width="150"></el-table-column>
            <el-table-column :class-name="$style.handles" label="操作" align="center" min-width="100">
                <el-row slot-scope="scope">
                    <el-button v-if="Number(scope.row.operate_status) === 0" type="text"
                               @click="handleAppeal(scope)">申诉</el-button>
                    <el-button v-if="Number(scope.row.operate_status) === 1" :class="$style.yellow" type="text"
                               @click="handleViewProgress(scope.row)">待处理</el-button>
                    <el-button v-if="Number(scope.row.operate_status) === 2" :class="$style.yellow" type="text"
                               @click="handleViewProgress(scope.row)">处理中</el-button>
                    <el-button v-if="Number(scope.row.operate_status) === 3" :class="$style.gray" type="text"
                               @click="handleViewProgress(scope.row)">已处理</el-button>
                </el-row>
            </el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="offset"
            :page-size="limit"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import Map from '@capital/utils/map';
    import { dateFormat } from '@/assets/js/utils/date';
    import { appealCreate, viewAppealDetail } from '@capital/components/appeal';
    import { reqWarehouseBillList } from '@capital/services/fas';

    const mapOfAppealStatus = new Map('appealStatus');

    export default {
        name: 'WarehouseBillList',
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                limit: 10, // 每页显示条数
                offset: 1, // 当前页码
                deductTime: [now - 2592000000, now], // 扣款时间
                orderNo: '', // 订单编号
                operateStatus: '', // 申诉状态
            };

            return {
                DATA,
                filter: {
                    deductTime: DATA.deductTime, // 扣款时间
                    orderNo: DATA.orderNo, // 订单编号
                    operateStatus: DATA.operateStatus, // 申诉状态
                },
                limit: DATA.limit, // 每页显示条数
                offset: DATA.offset, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                downloadLink: '', // 导出表格下载链接

                // 申诉状态下拉菜单列表
                appealStatusOptions: ['WAITING', 'UNDERWAY', 'COMPLETE'].map((item) => {
                    const statusInfo = mapOfAppealStatus.getInfoByName(item);
                    return {
                        label: statusInfo.lang,
                        value: statusInfo.code,
                    };
                }),
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        limit,
                        offset,
                        deductTimeStart,
                        deductTimeEnd,
                        orderNo,
                        operateStatus,
                    } = this.$route.query;

                    this.limit = Number(limit) || this.DATA.limit;
                    this.offset = Number(offset) || this.DATA.offset;
                    this.filter.deductTime = deductTimeStart && deductTimeEnd
                        ? [deductTimeStart * 1000, deductTimeEnd * 1000] : this.DATA.deductTime;
                    this.filter.orderNo = orderNo || this.DATA.orderNo;
                    this.filter.operateStatus = operateStatus || this.DATA.operateStatus;

                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.limit !== this.DATA.limit) query.limit = this.limit;
                if (this.offset !== this.DATA.offset) query.offset = this.offset;
                if (this.filter.deductTime !== null && this.filter.deductTime !== this.DATA.deductTime) {
                    query.deductTimeStart = Math.floor(this.filter.deductTime[0] / 1000);
                    query.deductTimeEnd = Math.floor(this.filter.deductTime[1] / 1000);
                }
                if (this.filter.orderNo !== this.DATA.orderNo) query.orderNo = this.filter.orderNo;
                if (this.filter.operateStatus !== this.DATA.operateStatus) query.operateStatus = this.filter.operateStatus;
                query.activeName = this.activeName;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqWarehouseBillList.http({
                    params: {
                        limit: this.limit,
                        offset: this.offset,
                        deduct_time_start: this.filter.deductTime.length === 0 ? '' : Math.floor(this.filter.deductTime[0] / 1000),
                        deduct_time_end: this.filter.deductTime.length === 0 ? '' : Math.floor(this.filter.deductTime[1] / 1000),
                        order_no: this.filter.orderNo,
                        operate_status: this.filter.operateStatus,
                    }
                });
                if (status === 0) {
                    this.downloadLink = data.downloadLink;
                    this.totalCount = data.total || 0;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    deductTime: this.DATA.deductTime,
                    orderNo: this.DATA.orderNo,
                    operateStatus: this.DATA.operateStatus,
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.offset = 1;
                this.updateUrl();
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * 格式化账期时间
             * @return {string}
             */
            formatBillDate(row, column, cellValue) {
                let resultText = '';

                if (row.process_date_start && row.process_date_end) {
                    resultText = `${dateFormat(row.process_date_start, 'yyyy/MM/dd')} - ${dateFormat(row.process_date_end, 'yyyy/MM/dd')}`;
                } else {
                    resultText = '--';
                }

                return resultText;
            },

            /**
             * limit 改变时会触发
             */
            handleSizeChange(val) {
                this.limit = val;
                this.offset = 1;
                this.updateUrl();
            },

            /**
             * offset 改变时会触发
             */
            handleCurrentChange(val) {
                this.offset = val;
                this.updateUrl();
            },

            /**
             * 申诉
             */
            handleAppeal({ row, $index }) {
                appealCreate({
                    billType: '1',
                    billCode: row.order_no
                }).then(() => {
                    // 改变当前行状态为待处理
                    this.tableData[$index].operate_status = mapOfAppealStatus.getInfoByName('WAITING').code;
                });
            },

            /**
             * 查看申诉进度
             */
            handleViewProgress(row) {
                viewAppealDetail({
                    title: mapOfAppealStatus.getInfoByCode(row.operate_status).lang,
                    billCode: row.order_no
                });
            },

            /**
             * 跳转到仓储账单详情页
             * @param billCode
             */
            goToBillDetail(billCode) {
                this.$router.gbPush(`/capital/warehouse-bill-detail/${billCode}`);
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .pagination {
        margin-top: 20px;
    }

    .handles {
        padding: 0 !important;
    }

    .yellow {
        color: var(--color-warning);
    }

    .gray {
        color: var(--color-text-disable);
    }
</style>
