<template>
    <div :class="$style.container">
        <el-tabs v-model="type" type="card" @tab-click="tabClick">
            <el-tab-pane label="订单记录查询" name="OrderRecordQuery"></el-tab-pane>
            <el-tab-pane label="放款记录查询" name="LoanRecordQuery"></el-tab-pane>
            <!-- <el-tab-pane label="退款记录查询" name="RefundRecordQuery"></el-tab-pane> -->
            <el-tab-pane label="售后责任记录查询" name="DutyRecordQuery"></el-tab-pane>
            <el-tab-pane label="调整记录查询" name="AdjustRecordQuery"></el-tab-pane>
        </el-tabs>

        <component :is="type"></component>
    </div>
</template>

<script>
    import OrderRecordQuery from './components/OrderRecordQuery';
    import LoanRecordQuery from './components/LoanRecordQuery';
    /* import RefundRecordQuery from './components/RefundRecordQuery'; */
    import DutyRecordQuery from './components/DutyRecordQuery';
    import AdjustRecordQuery from './components/AdjustRecordQuery';

    export default {
        name: 'OrderCapitalQuery',
        components: {
            OrderRecordQuery,
            LoanRecordQuery,
            // RefundRecordQuery,
            DutyRecordQuery,
            AdjustRecordQuery
        },

        data() {
            return {
                type: this.getTypeName()
            };
        },

        watch: {
            $route() {
                this.type = this.getTypeName();
            }
        },

        methods: {
            /**
             * 返回有效的类型名称
             */
            getTypeName() {
                const typeName = this.$route.query.type;
                return [
                    'OrderRecordQuery',
                    'LoanRecordQuery',
                    // 'RefundRecordQuery',
                    'DutyRecordQuery',
                    'AdjustRecordQuery',
                ].includes(typeName) ? typeName : 'OrderRecordQuery';
            },

            /**
             * 切换Tabs标签页的时候更新URL的type参数
             */
            tabClick(tab) {
                this.$router.push({
                    query: {
                        type: tab.name
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }
</style>
