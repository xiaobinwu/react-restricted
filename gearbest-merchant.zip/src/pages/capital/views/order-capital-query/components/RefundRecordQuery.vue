<template>
    <div>
        <el-form :inline="true" label-suffix="：">
            <el-form-item label="订单编号">
                <el-input v-model="filter.orderSn" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="商品编号">
                <el-input v-model="filter.goodSn" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="退款时间">
                <el-date-picker
                    v-model="filter.refundTime"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="结算状态">
                <el-select v-model="filter.settlementStatus" clearable placeholder="请选择">
                    <el-option v-for="(item, index) in settlementStatusText" :label="item" :value="index" :key="index"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="账单编号">
                <el-input v-model="filter.billNumber" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <div :class="$style.toolBar">
            <el-button>导出表单</el-button>
        </div>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column :formatter="formatDate" prop="refundTime" label="退款时间" align="center" width="150"></el-table-column>
            <el-table-column prop="billNumber" label="账单编号" align="center" min-width="120"></el-table-column>
            <el-table-column label="结算状态" align="center" width="110">
                <template slot-scope="scope">
                    {{ settlementStatusText[scope.row.settlementStatus] }}
                </template>
            </el-table-column>
            <el-table-column label="订单编号" align="center" min-width="150">
                <template slot-scope="scope">
                    <a href="javascript:;" @click="gotoOrderDetail(scope.row.orderSn)">{{ scope.row.orderSn }}</a>
                </template>
            </el-table-column>
            <el-table-column :formatter="formatDate" prop="orderTime" label="订单支付时间" align="center" width="150"></el-table-column>
            <el-table-column label="商品编号" align="center" min-width="150">
                <a slot-scope="scope" :href="scope.row.goodsUrl">{{ scope.row.goodsSn }}</a>
            </el-table-column>
            <el-table-column prop="goodsCount" label="商品数量" align="center"></el-table-column>
            <el-table-column :formatter="formatPrice" prop="orderAmount" label="订单金额" align="center" min-width="110"></el-table-column>
            <el-table-column :formatter="formatPrice" prop="buyerRefundAmount" label="买家退款金额" align="center" min-width="110"></el-table-column>
            <el-table-column :formatter="formatPrice" prop="platformCommissionRefund" label="平台佣金退回" align="center" min-width="110"></el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';

    export default {
        name: 'OrderRecordQuery',
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                orderSn: '', // 订单编号
                goodSn: '', // 商品编号
                refundTime: [now - 2592000000, now], // 退款时间
                settlementStatus: '', // 结算状态
                billNumber: '', // 账单编号
                pageSize: 10, // 每页显示条数
                pageNo: 1 // 当前页码
            };

            return {
                DATA,
                type: 'RefundRecordQuery',
                filter: {
                    orderSn: DATA.orderSn, // 订单编号
                    goodSn: DATA.goodSn, // 商品编号
                    refundTime: DATA.refundTime, // 退款时间
                    settlementStatus: DATA.settlementStatus, // 结算状态
                    billNumber: DATA.billNumber, // 账单编号
                },
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象

                // 结算状态
                settlementStatusText: {
                    1: '待结算',
                    2: '已生成账单',
                    3: '账单已审核',
                    4: '已扣款',
                    5: '已放款',
                    6: '扣款失败',
                    7: '卖家已确认',
                    8: '已部分生成账单'
                }
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        orderSn,
                        goodSn,
                        startTime,
                        endTime,
                        settlementStatus,
                        billNumber,
                        pageSize,
                        pageNo
                    } = this.$route.query;

                    this.filter.orderSn = orderSn || this.DATA.orderSn;
                    this.filter.goodSn = goodSn || this.DATA.goodSn;
                    this.filter.refundTime = startTime && endTime ? [startTime * 1000, endTime * 1000] : this.DATA.refundTime;
                    this.filter.settlementStatus = settlementStatus || this.DATA.settlementStatus;
                    this.filter.billNumber = billNumber || this.DATA.billNumber;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.filter.orderSn !== this.DATA.orderSn) query.orderSn = this.filter.orderSn;
                if (this.filter.goodSn !== this.DATA.goodSn) query.goodSn = this.filter.goodSn;
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                if (this.filter.refundTime !== this.DATA.refundTime) {
                    query.startTime = Math.floor(this.filter.refundTime[0] / 1000);
                    query.endTime = Math.floor(this.filter.refundTime[1] / 1000);
                }
                if (this.filter.settlementStatus !== this.DATA.settlementStatus) query.settlementStatus = this.filter.settlementStatus;
                if (this.filter.billNumber !== this.DATA.billNumber) query.billNumber = this.filter.billNumber;
                query.type = this.type;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const tempData = [
                    {
                        refundTime: '',
                        billNumber: '545555',
                        settlementStatus: 0,
                        orderSn: '506827455871615',
                        orderTime: '1545460532',
                        goodsUrl: 'http://www.baidu.com',
                        goodsSn: '32833556770',
                        goodsCount: '2',
                        orderAmount: '',
                        buyerRefundAmount: '17.8',
                        platformCommissionRefund: '0.99',
                    },
                    {
                        refundTime: '',
                        billNumber: '545556',
                        settlementStatus: 1,
                        orderSn: '506827455871615',
                        orderTime: '1545460532',
                        goodsUrl: 'http://www.baidu.com',
                        goodsSn: '32833556770',
                        goodsCount: '2',
                        orderAmount: '18.74',
                        buyerRefundAmount: '',
                        platformCommissionRefund: '0.94',
                    },
                    {
                        refundTime: '1550817332',
                        billNumber: '545555',
                        settlementStatus: 2,
                        orderSn: '506827455871615',
                        orderTime: '1545460532',
                        goodsUrl: 'http://www.baidu.com',
                        goodsSn: '32833556770',
                        goodsCount: '2',
                        orderAmount: '18.74',
                        buyerRefundAmount: '17.8',
                        platformCommissionRefund: '',
                    }
                ];

                this.totalCount = 66;
                this.tableData = tempData;
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    orderSn: this.DATA.orderSn,
                    goodsSn: this.DATA.goodSn,
                    refundTime: this.DATA.refundTime,
                    settlementStatus: this.DATA.settlementStatus,
                    billNumber: this.DATA.billNumber,
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * 格式化金额
             * @return {string}
             */
            formatPrice(row, column, cellValue) {
                return cellValue ? `$ ${cellValue}` : '--';
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 跳转到订单详情页
             * @param orderSn
             */
            gotoOrderDetail(orderSn) {
                this.$router.gbPush(`/order/details/${orderSn}`);
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .pagination {
        margin-top: 20px;
    }

    .toolBar {
        text-align: right;
        margin: 0 0 15px;
    }
</style>
