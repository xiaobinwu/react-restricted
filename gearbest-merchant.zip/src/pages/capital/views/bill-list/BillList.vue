<template>
    <div :class="$style.container">
        <div :class="$style.prompt">
            <i class="icon-tips"></i>
            <p :class="$style.promptItem">账单生成后请尽快确认，确认后才可进入结算环节</p>
            <p :class="$style.promptItem">申诉有效期为出账后3个月内，每个账单仅可以申诉一次</p>
        </div>

        <el-form :inline="true" label-suffix="：">
            <el-form-item label="账单编号">
                <el-input v-model="filter.billCode" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="放款状态">
                <el-select v-model="filter.loanStatus" placeholder="请选择" clearable>
                    <el-option v-for="item in loanStatusOptions"
                               :key="item.value"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="放款时间">
                <el-date-picker
                    v-model="filter.loanTimeRange"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="申诉状态">
                <el-select v-model="filter.appealStatus" placeholder="请选择" clearable>
                    <el-option v-for="item in appealStatusOptions"
                               :key="item.value"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="出账时间">
                <el-date-picker
                    v-model="filter.processTimeRange"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column label="账单编号" align="center" min-width="140">
                <a slot-scope="scope" href="javascript:;" type="text" @click="gotoBillDetail(scope.$index)">{{ scope.row.order_code }}</a>
            </el-table-column>
            <el-table-column :formatter="formatBillTime" label="账期" align="center" min-width="150"></el-table-column>
            <el-table-column prop="loan_amount" label="放款总金额" align="center"></el-table-column>
            <el-table-column :formatter="formatDate" prop="process_date" label="出账时间" align="center" min-width="110"></el-table-column>
            <el-table-column :formatter="formatDate" prop="loan_time" label="放款时间" align="center" min-width="110"></el-table-column>
            <el-table-column :formatter="formatLoanStatus" label="放款状态" align="center"></el-table-column>
            <el-table-column :class-name="$style.handles" label="操作" align="center" min-width="100">
                <el-row slot-scope="scope">
                    <el-col :span="12" :class="$style.space">
                        <el-button v-if="showConfirmBtn(scope.row)" type="text" @click="handleConfirm(scope)">确认</el-button>
                    </el-col>
                    <el-col :span="12">
                        <el-button v-if="Number(scope.row.operate_status) === 0" type="text"
                                   @click="handleAppeal(scope)">申诉</el-button>
                        <el-button v-if="Number(scope.row.operate_status) === 1" :class="$style.yellow" type="text"
                                   @click="handleViewProgress(scope.row)">待处理</el-button>
                        <el-button v-if="Number(scope.row.operate_status) === 2" :class="$style.yellow" type="text"
                                   @click="handleViewProgress(scope.row)">处理中</el-button>
                        <el-button v-if="Number(scope.row.operate_status) === 3" :class="$style.gray" type="text"
                                   @click="handleViewProgress(scope.row)">已处理</el-button>
                    </el-col>
                </el-row>
            </el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>

        <bill-confirm :visible.sync="showBillConfirm" @onConfirm="confirmBill">
            <a :class="$style.viewBill" href="javascript:;" type="text" @click="gotoBillDetail(currentRowIndex)">点击查看账单</a>
        </bill-confirm>
    </div>
</template>

<script>
    import Map from '@capital/utils/map';
    import { dateFormat } from '@/assets/js/utils/date';
    import { reqBillList, reqConfirmBill } from '@capital/services/fas';
    import { appealCreate, viewAppealDetail } from '@capital/components/appeal';
    import BillConfirm from './BillConfirm';

    const mapOfLoanStatus = new Map('loanStatus');
    const mapOfAppealStatus = new Map('appealStatus');

    export default {
        name: 'BillList',
        components: { BillConfirm },
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                billCode: '', // 账单编号
                loanStatus: '', // 放款状态
                appealStatus: '', // 申诉状态
                loanTimeRange: null, // 放款时间
                processTimeRange: [now - 2592000000, now], // 出账时间，推前一个月筛选
                pageSize: 20, // 每页显示条数
                pageNo: 1 // 当前页码
            };

            return {
                DATA,
                filter: {
                    billCode: DATA.billCode, // 账单编号
                    loanStatus: DATA.loanStatus, // 放款状态
                    appealStatus: DATA.appealStatus, // 申诉状态
                    loanTimeRange: DATA.loanTimeRange, // 放款时间
                    processTimeRange: DATA.processTimeRange, // 出账时间
                },
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                showBillConfirm: false, // 是否显示账单确认弹框
                currentRowIndex: -1, // 表格当前行数据

                // 放款状态下拉菜单列表
                loanStatusOptions: ['WAITING_LOAN', 'ALREADY_LOAN'].map((item) => {
                    const statusInfo = mapOfLoanStatus.getInfoByName(item);
                    return {
                        label: statusInfo.lang,
                        value: statusInfo.code,
                    };
                }),

                // 申诉状态下拉菜单列表
                appealStatusOptions: ['WAITING', 'UNDERWAY', 'COMPLETE'].map((item) => {
                    const statusInfo = mapOfAppealStatus.getInfoByName(item);
                    return {
                        label: statusInfo.lang,
                        value: statusInfo.code,
                    };
                }),
            };
        },

        watch: {
            $route: {
                immediate: true,
                /**
                 * 每次路由更新，获取URL上的参数，初始化数据
                 */
                handler() {
                    const {
                        billCode, // 账单编号
                        loanStatus, // 放款状态
                        appealStatus, // 申诉状态
                        loanTimeStart, // 放款开始时间
                        loanTimeEnd, // 放款结束时间
                        processTimeStart, // 出账开始时间
                        processTimeEnd, // 出账结束时间
                        pageSize, // 每页显示条数
                        pageNo // 当前页码
                    } = this.$route.query;

                    this.filter.billCode = billCode || this.DATA.billCode;
                    this.filter.loanStatus = loanStatus || this.DATA.loanStatus;
                    this.filter.appealStatus = appealStatus || this.DATA.appealStatus;
                    this.filter.loanTimeRange = loanTimeStart && loanTimeEnd ? [loanTimeStart * 1000, loanTimeEnd * 1000] : this.DATA.loanTimeRange;
                    this.filter.processTimeRange = processTimeStart && processTimeEnd
                        ? [processTimeStart * 1000, processTimeEnd * 1000]
                        : this.DATA.processTimeRange;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.filter.billCode !== this.DATA.billCode) query.billCode = this.filter.billCode;
                if (this.filter.loanStatus !== this.DATA.loanStatus) query.loanStatus = this.filter.loanStatus;
                if (this.filter.appealStatus !== this.DATA.appealStatus) query.appealStatus = this.filter.appealStatus;

                if (this.filter.loanTimeRange !== this.DATA.loanTimeRange && (this.filter.loanTimeRange || []).length) {
                    query.loanTimeStart = Math.floor(this.filter.loanTimeRange[0] / 1000);
                    query.loanTimeEnd = Math.floor(this.filter.loanTimeRange[1] / 1000);
                }
                if (this.filter.processTimeRange !== this.DATA.processTimeRange && (this.filter.processTimeRange || []).length) {
                    query.processTimeStart = Math.floor(this.filter.processTimeRange[0] / 1000);
                    query.processTimeEnd = Math.floor(this.filter.processTimeRange[1] / 1000);
                }
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqBillList.http({
                    params: {
                        order_code: this.filter.billCode,
                        loan_status: this.filter.loanStatus,
                        operate_status: this.filter.appealStatus,
                        loan_time_start: (this.filter.loanTimeRange || [])[0] ? Math.floor(this.filter.loanTimeRange[0] / 1000) : '',
                        loan_time_end: (this.filter.loanTimeRange || [])[1] ? Math.floor(this.filter.loanTimeRange[1] / 1000) : '',
                        process_time_start: (this.filter.processTimeRange || [])[0] ? Math.floor(this.filter.processTimeRange[0] / 1000) : '',
                        process_time_end: (this.filter.processTimeRange || [])[1] ? Math.floor(this.filter.processTimeRange[1] / 1000) : '',
                        offset: this.pageNo,
                        limit: this.pageSize
                    }
                });
                if (status === 0) {
                    this.totalCount = data.total || 0;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    billCode: this.DATA.billCode, // 账单编号
                    loanStatus: this.DATA.loanStatus, // 放款状态
                    appealStatus: this.DATA.appealStatus, // 申诉状态
                    loanTimeRange: this.DATA.loanTimeRange, // 放款时间
                    processTimeRange: this.DATA.processTimeRange, // 出账时间
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * 格式化账期
             * @param process_date_start 《出账开始时间》
             * @param process_date_end 《出账结束时间》
             */
            formatBillTime({ process_date_start: start, process_date_end: end }) {
                const startTime = dateFormat(start, 'yyyy/MM/dd');
                const endTime = dateFormat(end, 'yyyy/MM/dd');
                return `${startTime} - ${endTime}`;
            },

            /**
             * 格式化放款状态
             * @param loan_status 《放款状态》
             */
            formatLoanStatus({ loan_status: loanStatus }) {
                return mapOfLoanStatus.getInfoByCode(loanStatus).lang;
            },

            /**
             * 格式化日期
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue) : '-';
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 是否显示确认按钮
             * @param loan_status
             * @return {boolean}
             */
            showConfirmBtn({ loan_status: loanStatus }) {
                return String(loanStatus) === mapOfLoanStatus.getInfoByName('WAITING_LOAN').code;
            },

            /**
             * 确认操作
             * @param $index 《操作项在列表中的索引值》
             */
            handleConfirm({ $index }) {
                this.currentRowIndex = $index;
                this.showBillConfirm = true;
            },

            /**
             * 确认订单
             */
            async confirmBill() {
                const { status } = await reqConfirmBill.http({
                    data: {
                        order_code: this.tableData[this.currentRowIndex].order_code
                    }
                });

                if (status === 0) {
                    this.$message({
                        type: 'success',
                        message: '操作成功！'
                    });
                    // 更新列表项为已确认状态
                    this.tableData[this.currentRowIndex].loan_status = mapOfLoanStatus.getInfoByName('ALREADY_LOAN').code;
                } else {
                    this.$message({
                        type: 'error',
                        message: '操作失败！请稍后再试！'
                    });
                }
            },

            /**
             * 申诉
             */
            handleAppeal({ row, $index }) {
                appealCreate({
                    billType: '2',
                    billCode: row.order_code
                }).then(() => {
                    // 改变当前行状态为待处理
                    this.tableData[$index].operate_status = mapOfAppealStatus.getInfoByName('WAITING').code;
                });
            },

            /**
             * 查看申诉进度
             */
            handleViewProgress(row) {
                viewAppealDetail({
                    title: mapOfAppealStatus.getInfoByCode(row.operate_status).lang,
                    billCode: row.order_code
                });
            },

            /**
             * 跳转到账单详情页
             * @param row
             */
            gotoBillDetail(rowIndex) {
                if (this.tableData[rowIndex]) {
                    this.$router.push({
                        name: 'BillDetail',
                        query: { billCode: this.tableData[rowIndex].order_code || '' }
                    });
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .prompt {
        position: relative;
        padding: 10px 36px 8px;
        margin-bottom: 20px;
        border: 1px solid var(--border-color-prompt);
        background-color: var(--background-color-prompt);
        border-radius: var(--border-radius);
        color: var(--color-text-regular);
        font-size: var(--font-size-small);

        i {
            position: absolute;
            top: 50%;
            left: 10px;
            margin-top: -8px;
            color: var(--color-primary);
        }
    }

    .promptItem {
        line-height: 21px;

        &:before {
            content: '•';
            display: inline-block;
            margin-right: 5px;
        }
    }

    .pagination {
        margin-top: 20px;
    }

    .handles {
        padding: 0 !important;
    }

    .space {
        min-height: 1px;
    }

    .yellow {
        color: var(--color-warning);
    }

    .gray {
        color: var(--color-text-disable);
    }

    .viewBill {
        margin-left: 20px;
    }
</style>
