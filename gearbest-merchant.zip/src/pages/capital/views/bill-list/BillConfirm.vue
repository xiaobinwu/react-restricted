<template>
    <div>
        <el-dialog :visible.sync="dialogVisible" title="账单确认" width="560px">
            <div :class="$style.content">
                <span>账单确认后，才能进入结算环节。账单确认不影响申诉流程</span>
                <slot></slot>
            </div>
            <span slot="footer">
                <el-button @click="handleClose">取消</el-button>
                <el-button type="primary" @click="handleConfirm">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: 'BillConfirm',
        props: {
            visible: {
                require: true,
                type: Boolean,
                default: false
            }
        },
        computed: {
            dialogVisible: {
                get() {
                    return this.visible;
                },
                set(newValue) {
                    this.$emit('update:visible', newValue);
                }
            }
        },
        methods: {
            /**
             * 取消
             */
            handleClose() {
                this.dialogVisible = false;
            },

            /**
             * 确定
             */
            handleConfirm() {
                this.$emit('onConfirm');
                this.handleClose();
            }
        }
    };
</script>

<style module>
    .content {
        text-align: center;
    }
</style>
