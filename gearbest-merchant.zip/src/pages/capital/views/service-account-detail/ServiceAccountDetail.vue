<template>
    <div :class="$style.container">
        <div :class="$style.prompt">
            <i class="icon-tips"></i>
            <p :class="$style.promptTitle">重要说明</p>
            <p :class="$style.promptItem">① 线上充值流程暂未开通，需走线下充值流程。</p>
        </div>
        <div :class="$style.process">
            <p :class="$style.processTitle">线下充值流程：</p>
            <p :class="$style.processItem">① 线下充值，将款项打入以下收款账号（<span>需备注店铺名称</span>）；</p>
            <p :class="$style.processItem">② 财务核实；</p>
            <p :class="$style.processItem">③ 充值成功。</p>
        </div>
        <div :class="$style.account">
            <p :class="$style.accountTitle">收款帐户</p>
            <div :class="$style.accountWrap">
                <el-form label-suffix="：" label-width="181px">
                    <el-form-item :class="$style.accountItemTitle" label="Account name">
                        <span :class="$style.accountItemText">LIDA LOGISTIC SERVICE (HK) LIMITED</span>
                    </el-form-item>
                    <el-form-item :class="$style.accountItemTitle" label="Account number">
                        <span :class="$style.accountItemText">OSA90000330448100</span>
                    </el-form-item>
                    <el-form-item :class="$style.accountItemTitle" label="Bank Name">
                        <span :class="$style.accountItemText">BANK OF COMMUNICATIONS CO.,LTD OFFSHORE BANKING UNIT</span>
                    </el-form-item>
                    <el-form-item :class="$style.accountItemTitle" label="Account adress">
                        <span :class="$style.accountItemText">NO 188,YINCHENG ZHONG ROAD,SHANGHAI,CHINA</span>
                    </el-form-item>
                    <el-form-item :class="$style.accountItemTitle" label="SWIFT Code">
                        <span :class="$style.accountItemText">COMMCN3XOBU</span>
                    </el-form-item>
                </el-form>
            </div>
            <div :class="$style.bottomWrap">
                <p :class="$style.bottomTips">如有任何疑问，请咨询客服。</p>
                <p :class="$style.bottomTips">客服邮箱：seller-support@gearbest.com</p>
            </div>
        </div>
    </div>
</template>

<script>
    import store from '@/assets/js/store';

    export default {
        name: 'ServiceAccountDetail',
        data() {
            return {
                userInfo: store.state.user.userInfo, // 店铺信息
            };
        },
        computed: {
            shopName() {
                return this.userInfo.defaultShop.shopName;
            }
        },
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

     .prompt {
        position: relative;
        padding: 10px 36px 8px;
        margin-bottom: 20px;
        border: 1px solid var(--border-color-prompt);
        background-color: var(--background-color-prompt);
        border-radius: var(--border-radius);
        color: #666666;
        font-size: var(--font-size-small);

        i {
            position: absolute;
            top: 50%;
            left: 10px;
            margin-top: -8px;
            color: var(--color-primary);
        }
    }

    .promptTitle {
        color: #333333;
        font-size: 14px;
        font-weight: 400;
        margin-bottom: 5px;
    }

    .promptItem {
        line-height: 21px;
        font-size: 12px;
        font-weight: 400;
    }

    .process {
        margin-top: 38px;
    }

    .processTitle {
        font-size: 16px;
        color: var(--color-text-primary );
        margin-bottom: 10px;
    }

    .processItem {
        font-size: 14px;
        color: var(--color-text-primary );
        line-height:25px;

        span {
            color: #FF5757;
        }
    }

    .account {
        margin-top: 38px
    }

    .accountTitle {
        font-size: 16px;
        color: var(--color-text-primary );
        margin-bottom: 10px;
    }

    .accountWrap {
        border-radius: 4px;
        border: 1px solid rgba(216,216,216,1);
    }

    .accountItemTitle {
        margin-bottom: 0!important;
        label {
            color: #666666!important;
        }
    }

    .accountItemText {
        font-size: 14px;
        font-weight: 400;
        color: var(--color-text-primary );
    }

    .bottomWrap {
        margin-top: 20px;
    }

    .bottomTips {
        color: #666666;
        font-size: 14px;
        line-height: 25px;
    }
</style>
