<template>
    <div>
        <el-form :inline="true" label-suffix="：">
            <el-form-item label="提现流水号">
                <el-input v-model="filter.cashWithdrawalNo"></el-input>
            </el-form-item>
            <el-form-item label="提现状态">
                <el-select v-model="filter.payStatus" clearable placeholder="请选择">
                    <el-option v-for="(item, index) in payStatusText" :label="item" :value="index" :key="index"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="提交时间">
                <el-date-picker
                    v-model="filter.create_time"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="更新时间">
                <el-date-picker
                    v-model="filter.update_time"
                    type="daterange"
                    range-separator="至"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <div :class="$style.toolBar">
            <el-button :disabled="tableData.length <= 0" @click="exportData">导出表格</el-button>
        </div>

        <el-table :data="tableData" border>
            <div slot="empty">暂无数据</div>
            <el-table-column :formatter="formatDate" prop="create_time" label="提交时间" align="center" width="150"></el-table-column>
            <el-table-column :formatter="formatDate" prop="update_time" label="更新时间" align="center" width="150"></el-table-column>
            <el-table-column prop="cash_withdrawal_no" label="提现流水号" align="center"></el-table-column>
            <el-table-column prop="bank_card_number" label="交易信息" align="center"></el-table-column>
            <el-table-column
                :formatter="formatPrice"
                prop="cash_withdrawal_amount" label="提现金额" align="center" width="120"></el-table-column>
            <el-table-column label="状态" align="center" width="100">
                <template slot-scope="scope">
                    {{ payStatusText[scope.row.pay_status] }}
                </template>
            </el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { openNewPage } from '@/assets/js/utils/url';
    import { reqWithdrawalList } from '@capital/services/fas';

    export default {
        name: 'WithdrawalsRecord',
        data() {
            const now = Date.now();

            // 默认数据
            const DATA = {
                pageSize: 10, // 每页显示条数
                pageNo: 1, // 当前页码
                payStatus: '', // 提现状态
                cashWithdrawalNo: '', // 提现流水号
                create_time: [now - 2592000000, now], // 交易时间
                update_time: [], // 更新时间
            };

            return {
                DATA,
                activeName: 'WithdrawalsRecord',
                filter: {
                    create_time: DATA.create_time, // 交易时间
                    update_time: DATA.update_time, // 更新时间
                    payStatus: DATA.payStatus, // 提现状态
                    cashWithdrawalNo: DATA.cashWithdrawalNo, // 提现流水号
                },
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                downloadLink: '', // 导出表格下载链接

                // 提现状态
                payStatusText: {
                    1: '提现处理中',
                    2: '提现成功',
                    3: '提现失败'
                }
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    /**
                     * 每次路由更新，获取URL上的参数，初始化数据
                     */
                    const {
                        createStartTime,
                        createEndTime,
                        updateStartTime,
                        updateEndTime,
                        payStatus,
                        cashWithdrawalNo,
                        pageSize,
                        pageNo
                    } = this.$route.query;

                    this.filter.create_time = createStartTime && createEndTime ? [createStartTime * 1000, createEndTime * 1000]
                    : this.DATA.create_time;
                    this.filter.update_time = updateStartTime && updateEndTime ? [updateStartTime * 1000, updateEndTime * 1000]
                    : this.DATA.update_time;
                    this.filter.payStatus = payStatus || this.DATA.payStatus;
                    this.filter.cashWithdrawalNo = cashWithdrawalNo || this.DATA.cashWithdrawalNo;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                if (this.filter.create_time !== null && this.filter.create_time !== this.DATA.create_time) {
                    query.createStartTime = Math.floor(this.filter.create_time[0] / 1000);
                    query.createEndTime = Math.floor(this.filter.create_time[1] / 1000);
                }
                if (this.filter.update_time !== null && this.filter.update_time !== this.DATA.update_time) {
                    query.updateStartTime = Math.floor(this.filter.update_time[0] / 1000);
                    query.updateEndTime = Math.floor(this.filter.update_time[1] / 1000);
                }
                if (this.filter.payStatus !== this.DATA.payStatus) query.payStatus = this.filter.payStatus;
                if (this.filter.cashWithdrawalNo !== this.DATA.cashWithdrawalNo) query.cashWithdrawalNo = this.filter.cashWithdrawalNo;
                query.activeName = this.activeName;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqWithdrawalList.http({
                    params: {
                        limit: this.pageSize,
                        offset: this.pageNo,
                        create_time_start: this.filter.create_time.length === 0 ? '' : Math.floor(this.filter.create_time[0] / 1000),
                        create_time_end: this.filter.create_time.length === 0 ? '' : Math.floor(this.filter.create_time[1] / 1000),
                        update_time_start: this.filter.update_time.length === 0 ? '' : Math.floor(this.filter.update_time[0] / 1000),
                        update_time_end: this.filter.update_time.length === 0 ? '' : Math.floor(this.filter.update_time[1] / 1000),
                        pay_status: this.filter.payStatus,
                        cash_withdrawal_no: this.filter.cashWithdrawalNo,
                    }
                });
                if (status === 0) {
                    this.downloadLink = data.downloadLink;
                    this.totalCount = data.total || 0;
                    this.tableData = data.items || [];
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    create_time: this.DATA.create_time,
                    update_time: this.DATA.update_time,
                    payStatus: this.DATA.payStatus,
                    cashWithdrawalNo: this.DATA.cashWithdrawalNo,
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * 格式化金额
             * @return {string}
             */
            formatPrice(row, column, cellValue) {
                return cellValue ? `$ ${cellValue}` : '--';
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 跳转到订单详情页
             * @param orderSn
             */
            goToOrderDetail(orderSn) {
                this.$router.gbPush(`/order/details/${orderSn}`);
            },

            /**
             * 导出表格
             */
            exportData() {
                if (this.tableData.length > 0 && this.downloadLink) {
                    openNewPage(this.downloadLink);
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .pagination {
        margin-top: 20px;
    }

    .toolBar {
        text-align: right;
        margin: 0 0 15px;
    }
</style>
