<template>
    <div :class="$style.container">
        <el-tabs v-model="activeName" type="card" @tab-click="tabClick">
            <el-tab-pane label="资金记录" name="CapitalRecord"></el-tab-pane>
            <el-tab-pane label="提现记录" name="WithdrawalsRecord"></el-tab-pane>
        </el-tabs>

        <component :is="activeName"></component>
    </div>
</template>

<script>
    import CapitalRecord from './components/CapitalRecord';
    import WithdrawalsRecord from './components/WithdrawalsRecord';

    export default {
        name: 'CapitalReport',
        components: {
            CapitalRecord,
            WithdrawalsRecord
        },

        data() {
            return {
                activeName: this.getTypeName()
            };
        },

        watch: {
            $route() {
                this.activeName = this.getTypeName();
            }
        },

        methods: {
            /**
             * 返回有效的类型名称
             */
            getTypeName() {
                const typeName = this.$route.query.activeName;
                return [
                    'CapitalRecord',
                    'WithdrawalsRecord',
                ].includes(typeName) ? typeName : 'CapitalRecord';
            },

            /**
             * 切换Tabs标签页的时候更新URL的type参数
             */
            tabClick(tab) {
                this.$router.push({
                    query: {
                        activeName: tab.name
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }
</style>
