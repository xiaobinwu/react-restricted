<template>
    <div :class="$style.container">
        <header :class="$style.header">
            <span :class="$style.dataItem">账单编号：{{ billCode }}</span>
            <span :class="$style.dataItem">账期：{{ billDateRange }}</span>
            <span :class="[$style.dataItem, $style.fr]">合计：<b>{{ sum }}</b></span>
        </header>

        <el-form :inline="true" label-suffix="：">
            <el-form-item label="订单编号">
                <el-input v-model="filter.orderSn" placeholder="精准匹配"></el-input>
            </el-form-item>
            <el-form-item label="商品编号">
                <el-input v-model="filter.goodsSn" placeholder="精准匹配"></el-input>
            </el-form-item>
            <!--<el-form-item label="业务类型">
                <el-select v-model="filter.businessType" placeholder="请选择">
                    <el-option v-for="item in businessTypeOptions"
                               :key="item.value"
                               :label="item.label"
                               :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>-->
            <!--<el-form-item label="交易时间">
                <el-date-picker v-model="filter.tradeTimeRange"
                                type="daterange"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                </el-date-picker>
            </el-form-item>-->
            <el-form-item>
                <el-button @click="handleReset">重置</el-button>
                <el-button type="primary" @click="handleSearch">搜索</el-button>
            </el-form-item>
        </el-form>

        <div :class="$style.toolbar">
            <el-button :disabled="tableData.length === 0" @click="exportTable">导出表格</el-button>
            <el-button v-if="Number(loanStatus) === 1" type="primary" @click="handleConfirm">确认账单</el-button>
        </div>

        <el-table :data="tableData" border style="width: 100%">
            <div slot="empty">暂无数据</div>
            <el-table-column prop="tradeTime" label="交易时间" align="center" fixed min-width="130"></el-table-column>
            <el-table-column prop="businessType" label="业务类型" align="center" min-width="110"></el-table-column>
            <el-table-column prop="moneyChange" label="资金明细" align="center" min-width="100"></el-table-column>
            <el-table-column label="订单编号" align="center" min-width="180">
                <a slot-scope="scope" href="javascript:;" @click="gotoOrderDetail(scope.row.orderSn)">{{ scope.row.orderSn }}</a>
            </el-table-column>
            <el-table-column label="商品编号" align="center" min-width="180">
                <a slot-scope="scope" :href="scope.row.goodsUrl">{{ scope.row.goodsSn }}</a>
            </el-table-column>
            <el-table-column prop="goodsCount" label="商品数量" align="center" min-width="90"></el-table-column>
            <el-table-column prop="orderAmount" label="订单金额" align="center" min-width="90"></el-table-column>
            <el-table-column prop="buyerRefundAmount" label="买家退款金额" align="center" min-width="110"></el-table-column>
            <el-table-column prop="commissionAmount" label="平台佣金扣除" align="center" min-width="110"></el-table-column>
            <el-table-column prop="commissionRefundAmount" label="平台佣金退回" align="center" min-width="110"></el-table-column>
        </el-table>

        <el-pagination :class="$style.pagination"
                       :current-page="pageNo"
                       :page-size="pageSize"
                       :total="totalCount"
                       layout="->, total, sizes, prev, pager, next, jumper"
                       @size-change="handleSizeChange"
                       @current-change="handleCurrentChange">
        </el-pagination>

        <bill-confirm :visible.sync="showBillConfirm" @onConfirm="confirmBill"></bill-confirm>
    </div>
</template>

<script>
    import Map from '@capital/utils/map';
    import { dateFormat } from '@/assets/js/utils/date';
    import { openNewPage } from '@/assets/js/utils/url';
    import { reqBillDetail, reqConfirmBill } from '@capital/services/fas';
    import BillConfirm from '../bill-list/BillConfirm';

    const mapOfLoanStatus = new Map('loanStatus');
    const mapOfBusinessType = new Map('businessType');

    export default {
        name: 'BillDetail',
        components: { BillConfirm },
        data() {
            // const now = Date.now();

            // 默认数据
            const DATA = {
                orderSn: '', // 订单编号
                goodsSn: '', // 商品编号
                // businessType: '', // 交易类型
                // tradeTimeRange: [now - 2592000000, now], // 交易时间，推前一个月筛选
                pageSize: 20, // 每页显示条数
                pageNo: 1 // 当前页码
            };

            return {
                DATA,
                billCode: this.$route.query.billCode, // 账单编号
                billDateRange: '', // 账期
                sum: 0, // 合计
                downloadLink: '', // 下载链接
                filter: {
                    orderSn: DATA.orderSn, // 订单编号
                    goodsSn: DATA.goodsSn, // 商品编号
                    // businessType: DATA.businessType, // 交易类型
                    // tradeTimeRange: DATA.tradeTimeRange, // 交易时间
                },
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
                showBillConfirm: false, // 是否显示账单确认弹框
                loanStatus: '',

                // 放款状态下拉菜单列表
                // businessTypeOptions: ['LOAN', 'REFUND', 'AFTER_SALE', 'ADJUST'].map((item) => {
                //     const statusInfo = mapOfBusinessType.getInfoByName(item);
                //     return {
                //         label: statusInfo.lang,
                //         value: statusInfo.code,
                //     };
                // }),
            };
        },

        watch: {
            $route: {
                immediate: true,
                /**
                 * 每次路由更新，获取URL上的参数，初始化数据
                 */
                handler() {
                    const {
                        billCode, // 账单编号
                        orderSn, // 订单编号
                        goodsSn, // 商品编号
                        // businessType, // 交易类型
                        // tradeTimeStart, // 交易开始时间
                        // tradeTimeEnd, // 交易结束时间
                        pageSize, // 每页显示条数
                        pageNo // 当前页码
                    } = this.$route.query;

                    this.billCode = billCode || this.billCode;
                    this.filter.orderSn = orderSn || this.DATA.orderSn;
                    this.filter.goodsSn = goodsSn || this.DATA.goodsSn;
                    // this.filter.businessType = businessType || this.DATA.businessType;
                    // this.filter.tradeTimeRange = tradeTimeStart && tradeTimeEnd
                    //     ? [tradeTimeStart * 1000, tradeTimeEnd * 1000] : this.DATA.tradeTimeRange;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    this.updateTableData();
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                query.billCode = this.billCode;
                if (this.filter.orderSn !== this.DATA.orderSn) query.orderSn = this.filter.orderSn;
                if (this.filter.goodsSn !== this.DATA.goodsSn) query.goodsSn = this.filter.goodsSn;
                // if (this.filter.businessType !== this.DATA.businessType) query.businessType = this.filter.businessType;
                // if (this.filter.tradeTimeRange !== this.DATA.tradeTimeRange && (this.filter.tradeTimeRange || []).length) {
                //     query.tradeTimeStart = Math.floor(this.filter.tradeTimeRange[0] / 1000);
                //     query.tradeTimeEnd = Math.floor(this.filter.tradeTimeRange[1] / 1000);
                // }
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                this.$router.push({ query });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqBillDetail.http({
                    params: {
                        order_code: this.billCode,
                        order_sn: this.filter.orderSn,
                        goods_sn: this.filter.goodsSn,
                        // type: this.filter.businessType,
                        // order_time_start: (this.filter.tradeTimeRange || [])[0] ? Math.floor(this.filter.tradeTimeRange[0] / 1000) : '',
                        // order_time_end: (this.filter.tradeTimeRange || [])[1] ? Math.floor(this.filter.tradeTimeRange[1] / 1000) : '',
                        offset: this.pageNo,
                        limit: this.pageSize
                    }
                });
                if (status === 0) {
                    const billDateStart = dateFormat((data.bill || {}).process_date_start, 'yyyy/MM/dd');
                    const billDateEnd = dateFormat((data.bill || {}).process_date_end, 'yyyy/MM/dd');

                    this.totalCount = data.total || 0;
                    this.billDateRange = `${billDateStart} - ${billDateEnd}`;
                    this.sum = (data.bill || {}).order_amount;
                    this.downloadLink = data.downloadLink || '';
                    this.loanStatus = data.loan_status || '';
                    this.tableData = (data.items || []).map(item => ({
                        tradeTime: dateFormat(item.order_time),
                        businessType: mapOfBusinessType.getInfoByCode(item.type).lang,
                        moneyChange: item.net_amount,
                        orderSn: item.order_sn,
                        goodsSn: item.goods_sn,
                        goodsUrl: (data.goodsUrls || {})[item.goods_sn] || 'javascript:;',
                        goodsCount: item.goods_quantity,
                        orderAmount: item.order_amount,
                        buyerRefundAmount: item.buyer_refund_amount,
                        commissionAmount: item.commission_amount,
                        commissionRefundAmount: item.commission_refund_amount,
                    }));
                }
            },

            /**
             * 重置搜索条件
             */
            handleReset() {
                this.filter = {
                    orderSn: this.DATA.orderSn, // 订单编号
                    goodsSn: this.DATA.goodsSn, // 商品编号
                    // businessType: this.DATA.businessType, // 交易类型
                    // tradeTimeRange: this.DATA.tradeTimeRange, // 交易时间
                };
            },

            /**
             * 搜索
             */
            handleSearch() {
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 跳转到订单详情页
             * @param orderSn 《订单编号》
             */
            gotoOrderDetail(orderSn) {
                this.$router.gbPush(`/order/details/${orderSn}`);
            },

            /**
             * 导出表格
             */
            exportTable() {
                if (this.tableData.length > 0 && this.downloadLink) {
                    openNewPage(this.downloadLink);
                }
            },

            /**
             * 确认操作
             */
            handleConfirm() {
                this.showBillConfirm = true;
            },

            /**
             * 确认订单
             */
            async confirmBill() {
                const { status } = await reqConfirmBill.http({
                    data: {
                        order_code: this.billCode
                    }
                });

                if (status === 0) {
                    this.$message({
                        type: 'success',
                        message: '操作成功！'
                    });
                    // 更新列表项为已确认状态
                    this.loanStatus = mapOfLoanStatus.getInfoByName('ALREADY_LOAN').code;
                } else {
                    this.$message({
                        type: 'error',
                        message: '操作失败！请稍后再试！'
                    });
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .header {
        height: 40px;
        padding: 0 20px;
        margin-bottom: 20px;
        line-height: 40px;
        background-color: var(--background-color-base);
    }

    .dataItem {
        display: inline-block;
        margin-right: 30px;
    }

    .fr {
        float: right;
    }

    .pagination {
        margin-top: 20px;
    }

    .toolbar {
        margin-bottom: 10px;
        text-align: right;
    }
</style>
