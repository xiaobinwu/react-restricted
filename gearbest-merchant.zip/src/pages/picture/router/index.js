import router from '@/assets/js/router';
import children from './routes';
import Layout from '@/components/Layout';

// Layout 为布局组件
// 所有的视图挂在它下面
const routes = [
    {
        path: '/',
        component: Layout,
        redirect: '/picture/list',
        meta: {
            requireAuth: true
        },
        children
    }
];

export default router({ routes });
