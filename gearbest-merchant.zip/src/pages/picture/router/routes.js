import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    // 相册列表
    {
        path: '/picture/album',
        name: 'pictureAlbum',
        meta: {
            title: 'base.menu.picture.album'
        },
        component: () => asyncComponent(import('@picture/views/Album'))
    },
    // 相册图片列表
    {
        path: '/picture/album/:albumCode',
        name: 'pictureAlbumPhoto',
        meta: {
            title: 'base.menu.picture.albumPhoto',
            focusMenu: '/picture/album',
        },
        component: () => asyncComponent(import('@picture/views/AlbumPhoto'))
    }
];
