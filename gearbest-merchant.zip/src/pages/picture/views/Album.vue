<template>
    <div :class="$style.container">
        <div :class="$style.header">
            <span :class="$style.totalTips" v-text="usedTips"></span>
            <div :class="$style.headerBtns">
                <album-photo-input-file @change="handleChange">
                    <el-button>上传图片</el-button>
                </album-photo-input-file>
                <el-button type="primary" @click="handleAlbumAddOrUpdate()">创建相册</el-button>
            </div>
        </div>
        <div class="content">
            <ul :class="$style.albumBox">
                <li v-for="(album, index) in albumList" :key="index" :class="$style.album">
                    <div :class="$style.img" @click="routerToAlbumImages(album)">
                        <i v-if="!album.albumThumb" :class="$style.defaultImg"></i>
                        <img v-else :src="album.albumThumb | thumb(200, 200)">
                    </div>
                    <p :class="$style.albumName">{{ album.albumName }}（{{ album.count }}张）</p>
                    <div v-if="album.albumDefault !== '1'" class="operation">
                        <el-button size="mini" type="danger" @click="handleAlbumDelete(album)">删除</el-button>
                        <el-button size="mini" type="primary" @click="handleAlbumAddOrUpdate(album)">修改</el-button>
                    </div>
                </li>
            </ul>
        </div>

        <album-photo-upload
            ref="upload"
            :visible.sync="dialogAlbumUpload"
            :data="{method: 'albumImage'}"
            action="/image-manage/image-upload"
            name="uploadFile"
            @save="getAlbumList">
        </album-photo-upload>

        <album-create
            :visible.sync="dialogAlbumUpdate"
            :is-editor="isEditor"
            :data="albumUpdate"
            @save="getAlbumList">
        </album-create>
    </div>
</template>

<script>
    import { serviceAlbumList, serviceAlbumDelete, serviceAlbumAccount } from '@picture/services/picture';

    import AlbumPhotoUpload from '@/components/album-photo-upload/AlbumPhotoUpload.vue';
    import AlbumPhotoInputFile from '@/components/album-photo-upload/AlbumPhotoInputFile.vue';
    import AlbumPhotoSelect from '@/components/AlbumPhotoSelect';
    import AlbumCreate from '@/components/AlbumCreate';

    export default {
        name: 'PictureAlbum',

        components: {
            AlbumPhotoUpload,
            AlbumPhotoInputFile,
            AlbumPhotoSelect,
            AlbumCreate
        },

        filters: {
            thumb(val, width, height) {
                if (!val) return '';
                const ext = val.match(/.+\.(.+)$/)[1] || '';
                return `${val}_${width}x${height}.${ext}`;
            }
        },

        data() {
            return {
                // 当前页面
                currentPage4: 1,
                // 相册列表

                albumList: [],
                // 相册信息
                albumInfo: '',

                // 新增/修改相册弹窗
                dialogAlbumUpdate: false,
                isEditor: false,
                albumUpdate: {},

                // 上传图片
                dialogAlbumUpload: false,
            };
        },

        computed: {
            usedTips() {
                const albumInfo = this.albumInfo;
                if (this.albumInfo) {
                    return `您共有${albumInfo.albums}个相册，
                    ${albumInfo.uploadFiles}张图片。
                    目前您已使用${albumInfo.totalMb}中的${albumInfo.usedMb}，
                    占总容量的${albumInfo.percent}`;
                }
                return '';
            }
        },

        created() {
            this.init();
        },

        methods: {
            handleSizeChange() {},

            handleCurrentChange() {},

            // main
            init() {
                this.getAlbumList();
                this.getAlbumAccount();
            },

            // 获取相册列表
            async getAlbumList() {
                const { status, data } = await serviceAlbumList.http();
                if (status === 0) {
                    this.albumList = data;
                }
            },

            // 获取相册信息
            async getAlbumAccount() {
                const { status, data } = await serviceAlbumAccount.http();

                // 大于1024KB显示MB
                const bitFormatter = (bit) => {
                    const kb = (bit / 1024).toFixed(2);
                    const mb = (kb / 1024).toFixed(2);
                    if (kb < 1024) {
                        return `${kb}KB`;
                    }
                    return `${mb}MB`;
                };

                if (status === 0) {
                    // 单位转换
                    data.usedMb = bitFormatter(data.usedBit);
                    data.totalMb = bitFormatter(data.totalBit);
                    data.percent = `${(data.usedBit / data.totalBit * 100).toFixed(2)}%`;
                    this.albumInfo = data;
                }
            },

            // 删除相册
            async deleteAlbum(data) {
                const { status, msg } = await serviceAlbumDelete.http({ data });
                if (status === 0) {
                    this.$message.success(msg);
                    return Promise.resolve();
                }
                return Promise.reject();
            },

            // 处理相册删除事件
            handleAlbumDelete({ albumCode, count }) {
                const message = count > 0 ? '删除可能导致正在使用的商品资料图片丢失！是否确定继续删除？' : '确定删除相册？';
                this.$confirm(message, '删除相册', {
                    cancelButtonText: '取消',
                    confirmButtonText: '确认'
                }).then(
                    (async () => {
                        await this.deleteAlbum({ albumCode });
                        this.getAlbumList();
                    })
                );
            },

            // 跳转相册图片列表
            routerToAlbumImages({ albumCode, albumName, createTime }) {
                this.$router.push({
                    name: 'pictureAlbumPhoto',
                    params: {
                        albumCode
                    },
                    query: {
                        albumName,
                        createTime
                    }
                });
            },

            // 处理文件上传事件
            handleChange(files) {
                this.dialogAlbumUpload = true;
                this.$refs.upload.addFile(files);
            },

            // 相册更新/新增
            handleAlbumAddOrUpdate(data) {
                this.isEditor = !!data;
                if (data) {
                    this.albumUpdate = Object.assign({}, {
                        albumCode: data.albumCode,
                        albumName: data.albumName
                    });
                }
                this.dialogAlbumUpdate = true;
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
    }

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 20px 10px 20px;
    }

    .totalTips {
        color: var(--color-text-regular);
        font-size: var(--font-size-base);
    }

    .headerBtns {
        display: flex;
    }

    .headerBtns button {
        margin-left: 20px;
    }

    .albumBox {
        display: flex;
        flex-wrap: wrap;
        padding: 0 20px 20px 20px;
    }

    .album {
        width: 120px;
        display: flex;
        flex-direction: column;
        align-items: center;
        /* justify-content: center; */
        margin-right: 66px;
        margin-bottom: 30px;
    }

    .album:nth-child(5n) {
        margin-right: 0;
    }

    .album .img {
        position: relative;
        width: 100px;
        height: 100px;
        border-radius: 4px;
        border:1px solid rgba(211,230,255,1);
        overflow: hidden;
        cursor: pointer;
    }

    .album img {
        width: 100px;
        height: 100px;
        border-radius: 4px;
        object-fit: cover;
    }

    .defaultImg {
        position: absolute;
        top: 50%;
        left: 50px;
        transform: translate(-50%, -50%);
        display: block;
        width: 30px;
        height: 25px;
        background: url('@picture/assets/img/icon-ablum.png') no-repeat;
        background-size: 30px 25px;
    }

    .albumName {
        width: 120px;
        padding: 16px 0;
        font-size: var(--font-size-base);
        color: var(--color-text-primary);
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        line-height: 1;
        text-align: center;
    }

    .bottom {
        padding: 20px;
        text-align: right;
    }

    .btnGroup {
        padding-top: 8px;
        font-size: 0;
        text-align: center;
    }

    .btnGroup button:last-of-type {
        margin-left: 20px;
    }
</style>
