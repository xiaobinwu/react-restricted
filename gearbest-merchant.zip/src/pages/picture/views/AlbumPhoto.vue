<template>
    <layout-card :name="layoutCardTitle">
        <div :class="$style.header">
            <el-form label-width="100px" label-suffix=":" inline>
                <el-form-item label="图片搜索">
                    <el-input v-model="params.fileName"></el-input>
                </el-form-item>
                <el-button type="primary" @click="handleImageSearch">搜索</el-button>
            </el-form>
            <album-photo-input-file @change="handleChange">
                <el-button>上传图片</el-button>
            </album-photo-input-file>
        </div>
        <div class="content">
            <div :class="$style.imageList">
                <div v-for="(img, index) in albumImages" :key="index" :class="$style.imageItem" >
                    <el-checkbox v-model="img.checked"></el-checkbox>
                    <div :class="$style.image">
                        <img :src="img.filePath | thumb(200, 200)" @click="handleImageDetail(img)">
                        <p :class="$style.imageName">{{ img.fileRealName }}</p>
                    </div>
                    <div :class="$style.imageitemOperation">
                        <el-button type="text" size="mini" @click="handleDeleteImage(img.fileCode)">删除</el-button>
                        <el-button type="text" size="mini" @click="copyLink(img)">复制链接</el-button>
                    </div>
                </div>
            </div>
            <div :class="$style.imageOperation">
                <el-checkbox :class="$style.selectAll" v-model="checkedAll">全选</el-checkbox>
                <el-button
                    :disabled="!batchOperation"
                    size="small"
                    type="danger"
                    @click="handleBatchImageDelete">
                    批量删除
                </el-button>
                <el-button
                    :disabled="!batchOperation"
                    size="small"
                    type="primary"
                    @click="handleAlbumPoster()">
                    设置相册封面
                </el-button>
                <el-button
                    :disabled="!batchOperation"
                    size="small"
                    type="primary"
                    @click="handleMoveImageDialog">
                    移动到其他相册
                </el-button>
            </div>
            <div :class="$style.albumInfo">
                <p>相册名称: {{ composeParams.albumName }}</p>
                <p>相册创建时间：{{ dateFormat(composeParams.createTime) }}</p>
            </div>
        </div>
        <div :class="$style.pagination">
            <el-pagination
                :total="imagesCount"
                :current-page="composeParams.page"
                :page-sizes="[24]"
                :page-size="composeParams.pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>

        <el-dialog :visible.sync="dialogMoveImage" :title="dialogMoveImageTitle" width="600px">
            <el-form label-width="150px" label-suffix=":" label-position="left">
                <el-form-item label="移动图片至相册">
                    <el-select v-model="toAlbum">
                        <el-option
                            v-for="(album, index) in albumList"
                            :key="index"
                            :label="album.albumName"
                            :value="album.albumCode">
                        </el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <div :class="$style.btnGroup">
                <el-button @click="dialogMoveImage = !dialogMoveImage">取消</el-button>
                <el-button :loading="imageMoving" type="primary" @click="handleMoveImage">确定</el-button>
            </div>
        </el-dialog>

        <el-dialog
            :visible.sync="dialogImageDetail.show"
            :custom-class="$style.imageDetail"
            width="440px"
            title="图片详情">
            <div :class="$style.imageContent">
                <img :src="dialogImageDetail.img" :style="{
                    width: dialogImageDetail.width,
                    height: dialogImageDetail.height,
                    position: 'absolute',
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)'}">
            </div>
            <div :class="$style.imageProps">
                <p :class="$style.imageProp">
                    <span>图片名称：</span>{{ dialogImageDetail.fileName }}
                </p>
                <p :class="$style.imageProp">
                    <span>所在相册：</span>{{ dialogImageDetail.albumName }}
                </p>
                <p :class="$style.imageProp">
                    <span>图片大小：</span>{{ dialogImageDetail.fileSize | bitFormat }}
                </p>
                <p :class="$style.imageProp">
                    <span>图片尺寸：</span>{{ dialogImageDetail.fileDimension }}
                </p>
                <p :class="$style.imageProp">
                    <span>更新时间：</span>{{ dialogImageDetail.createTime }}
                </p>
            </div>
            <div :class="$style.btnGroup">
                <el-button type="danger" size="small" @click="handleDeleteImage(dialogImageDetail.fileCode)">删除</el-button>
                <el-button type="primary" size="small" @click="handleAlbumPoster(dialogImageDetail.img)">设置为封面</el-button>
            </div>
        </el-dialog>

        <album-photo-upload
            ref="upload"
            :lock-album="true"
            :album-code="composeParams.albumCode"
            :visible.sync="dialogAlbumUpload"
            :data="{method: 'albumImage'}"
            action="/image-manage/image-upload"
            name="uploadFile"
            @save="getAlbumImages">
        </album-photo-upload>

    </layout-card>
</template>

<script>
    import {
        serviceAlbumImages,
        serviceImageDelete,
        serviceImageMove,
        serviceAlbumList,
        serviceAlbumPoster
    } from '@picture/services/picture';
    import { clipboard, preloadImage } from '@/assets/js/utils/assist';
    import { dateFormat } from '@/assets/js/utils/date';

    import AlbumPhotoUpload from '@/components/album-photo-upload/AlbumPhotoUpload.vue';
    import AlbumPhotoInputFile from '@/components/album-photo-upload/AlbumPhotoInputFile.vue';

    export default {
        name: 'AlbumImages',

        components: {
            AlbumPhotoUpload,
            AlbumPhotoInputFile
        },

        filters: {
            thumb(val, width, height) {
                if (!val) return '';
                const ext = val.match(/.+\.(.+)$/)[1] || '';
                return `${val}_${width}x${height}.${ext}`;
            },
            bitFormat(val) {
                if (!val) return '';
                const byte = (val / 1024).toFixed(2);
                return `${byte}KB`;
            }
        },
        data() {
            return {
                dateFormat,
                params: {
                    fileName: '',
                    page: 1,
                    pageSize: 24
                },
                albumImages: [],
                albumList: [],
                imagesCount: 0,
                checkedAll: false,
                dialogMoveImage: false,
                dialogMoveImageTitle: '',
                dialogAlbumUpload: false,
                toAlbum: '',
                imageMoving: false,
                dialogImageDetail: {
                    show: false,
                    dialogWidth: '600px',
                    filePath: '',
                    fileSize: '',
                    albumName: '',
                    fileName: '',
                    fileDimension: ''
                }
            };
        },

        computed: {
            query() {
                const query = this.$route.query;
                return {
                    ...query,
                    page: +query.page || 1,
                    pageSize: +query.pageSize || 24
                };
            },
            composeParams() {
                const { albumCode } = this.$route.params;

                return Object.assign({
                    ...this.query,
                    albumCode,
                }, this.params);
            },
            checked() {
                return this.albumImages.filter(item => item.checked);
            },
            checkedCount() {
                return this.checked.length;
            },
            batchOperation() {
                return this.checkedCount > 0;
            },
            layoutCardTitle() {
                const { albumName } = this.$route.query;
                const count = this.imagesCount;
                return `当前相册：${albumName}（${count}张）`;
            }
        },

        watch: {
            checkedCount(val) {
                const total = this.albumImages.length;
                this.checkedAll = val === total;
            },
            checkedAll(val) {
                this.albumImages.forEach((item) => {
                    this.$set(item, 'checked', val);
                });
            }
        },
        created() {
            this.init();
        },

        methods: {
            // pageSize 改变时会触发
            handleSizeChange(pageSize) {
                this.params.pageSize = pageSize;
                this.updateRouterQuery({ pageSize });
                this.getAlbumImages();
            },

            // currentPage 改变时会触发
            handleCurrentChange(page) {
                this.params.page = page;
                this.updateRouterQuery({ page });
                this.getAlbumImages();
            },

            // main
            init() {
                this.params = Object.assign({}, this.params, this.query);
                this.getAlbumImages();
            },

            // 获取相册图片
            async getAlbumImages() {
                const params = this.composeParams;
                const { status, data } = await serviceAlbumImages.http({ params });
                if (status === 0) {
                    this.albumImages = data.list;
                    this.imagesCount = data.count;
                }
            },

            // 删除照片
            async deleteImage(data) {
                const { status } = await serviceImageDelete.http({ data });
                if (status === 0) {
                    return Promise.resolve();
                }
                return Promise.reject();
            },

            // 移动照片
            async moveImage(data) {
                this.imageMoving = true;
                const { status } = await serviceImageMove.http({ data });
                this.imageMoving = false;
                if (status === 0) {
                    return Promise.resolve();
                }
                return Promise.reject();
            },

            // 获取相册列表
            async getAlbumList() {
                const { status, data } = await serviceAlbumList.http();
                if (status === 0) {
                    return Promise.resolve(data || []);
                }
                return Promise.reject();
            },

            // 更新相册 - 只支持修改封面
            async updateAblum(data) {
                const { status } = await serviceAlbumPoster.http({ data });
                if (status === 0) {
                    return Promise.resolve();
                }
                return Promise.reject();
            },

            // 更新路由参数
            updateRouterQuery(query) {
                this.$router.replace({
                    name: this.$route.name,
                    query: Object.assign({}, this.$route.query, query)
                });
            },

            // 复制连接
            copyLink(img) {
                const res = clipboard(img.filePath);
                if (res) {
                    this.$message.success('已成功复制到剪贴板');
                } else {
                    this.$message.error('复制失败');
                }
            },

            // 处理图片删除
            handleDeleteImage(fileCode) {
                fileCode = Array.isArray(fileCode) ? fileCode : [fileCode];
                this.$confirm('删除可能导致对应的商品资料图片丢失！是否确定继续删除？', '删除相册图片', {
                    cancelButtonText: '取消',
                    confirmButtonText: '确认'
                }).then(
                    (async () => {
                        const params = {
                            albumCode: this.$route.params.albumCode,
                            fileCode: fileCode.join(',')
                        };

                        await this.deleteImage(params);
                        this.$message.success('删除成功');
                        this.getAlbumImages();

                        if (this.dialogImageDetail) {
                            this.dialogImageDetail = false;
                        }
                    })
                );
            },

            // 处理图片移动弹窗
            async handleMoveImageDialog() {
                const data = await this.getAlbumList();
                const { albumCode } = this.$route.params;
                this.albumList = data.filter(item => item.albumCode !== albumCode);

                if (this.albumList.length === 0) {
                    this.$message.error('当前只有一个相册，无法移动');
                } else {
                    this.dialogMoveImage = true;
                    this.dialogMoveImageTitle = `将所选${this.checkedCount}张图片移动至以下相册`;
                    this.toAlbum = this.albumList[0].albumCode;
                }
            },

            // 处理图片移动
            async handleMoveImage() {
                if (!this.imageMoving) {
                    const fileCode = this.checked.map(item => item.fileCode).join(',');
                    await this.moveImage({
                        fileCode: fileCode || [],
                        albumCode: this.toAlbum,
                        isAllMove: this.checkedCount === this.albumImages.length
                    });
                    this.$message.success('操作成功');
                    this.dialogMoveImage = false;
                    this.getAlbumImages();
                }
            },

            // 批量删除图片
            handleBatchImageDelete() {
                const fileCode = this.checked.map(item => item.fileCode);
                this.handleDeleteImage(fileCode);
            },

            // 设置封面
            async handleAlbumPoster(filePath) {
                if (this.checkedCount > 1) {
                    this.$message.error('只能选择一张图片设为封面');
                } else {
                    const album = this.checked[0];
                    const data = {
                        albumCode: this.$route.params.albumCode,
                        albumThumb: filePath || album.filePath
                    };

                    await this.updateAblum(data);

                    this.$message.success('设置成功');
                }
            },

            // 处理图片搜索
            handleImageSearch() {
                const fileName = this.params.fileName;
                this.updateRouterQuery({ fileName });
                this.getAlbumImages();
            },

            // 返回相册列表
            routerGoAlbum() {
                this.$router.push({
                    name: 'pictureAlbum'
                });
            },

            // 展示相册详情
            async handleImageDetail(image) {
                this.dialogImageDetail.show = true;
                const originalPath = image.filePath.split('_')[0];

                // 兼容图片宽高不存在的情况
                if (!image.fileWidth || !image.fileHeight) {
                    const imgData = await preloadImage(originalPath);
                    image.fileWidth = imgData.width;
                    image.fileHeight = imgData.height;
                }

                const size = this.scaleimage(image.fileWidth, image.fileHeight);
                const data = {
                    fileCode: image.fileCode,
                    img: originalPath,
                    width: `${size.width}px`,
                    height: `${size.height}px`,
                    fileName: image.fileRealName,
                    fileSize: image.fileSize,
                    fileDimension: `${image.fileWidth}*${image.fileHeight}`,
                    albumName: this.$route.query.albumName,
                    createTime: dateFormat(image.createTime) || '',
                };

                this.dialogImageDetail = Object.assign({}, this.dialogImageDetail, data);
            },

            // 按比例缩小图片
            scaleimage(width, height, as = 400) {
                const max = width > height ? width : height;
                const res = { width, height };

                if (height > as || width > as) {
                    const sacleRatio = as / max;

                    res.height *= sacleRatio;
                    res.width *= sacleRatio;
                }

                return res;
            },

            handleChange(files) {
                this.dialogAlbumUpload = true;
                this.$refs.upload.addFile(files);
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 20px 0 20px;
    }

    .imageList {
        display: flex;
        flex-wrap: wrap;
        padding: 20px;
        margin: 20px 20px 0 20px;
        border: var(--border-base-style);
    }

    .imageItem {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        margin-right: 25.5px;
        margin-bottom: 25px;
    }

    .imageItem:nth-child(8n) {
        margin-right: 0;
    }

    .image {
        width: 80px;
        margin-top: 10px;
        text-align: center;
    }

    .image img {
        width: 80px;
        height: 80px;
        object-fit: cover;
        cursor: pointer;
    }

    .imageName {
        margin-top: 10px;
        font-size: 12px;
        color: var(--color-text-primary);
        text-overflow: ellipsis;
        overflow: hidden;
        width: 100%;
        white-space: nowrap;
    }

    .imageitemOperation {
        margin-top: 10px;
    }

    .imageitemOperation button:first-child {
        color: var(--color-danger);
    }

    .imageOperation {
        margin: 0 20px;
        padding: 13px;
        border: var(--border-base-style);
        border-top: 0;
        background: var(--background-color-light);
    }

    .selectAll {
        margin-right: 10px;
    }

    .albumInfo {
        margin: 0 20px 20px 20px;
        padding: 16px 20px;
        background:rgba(242,242,242,1);
        color: var(--color-text-primary);
        line-height: 17px;
    }

    .pagination {
        padding: 20px;
        text-align: right;
    }

    .btnGroup {
        padding-top: 8px;
        font-size: 0;
        text-align: center;
    }

    .btnGroup button:last-of-type {
        margin-left: 20px;
    }

    .imageDetail [class^="el-dialog__body"] {
        padding: 0 20px 30px 20px;
    }

    .imageContent {
        position: relative;
        border: var(--border-base-style);
        width: 400px;
        height: 400px;
        margin: 0 auto;
        box-sizing: content-box;
    }

    .imageContent img {
        width: 100%;
        height: auto;
    }

    .imageProps {
        padding: 20px 0;
    }

    .imageProp {
        font-size: var(--font-size-larger);
        color: var(--color-text-primary);
        line-height: 1.875;
        word-wrap: break-word;
    }

    .imageProp span {
        color: var(--color-text-regular);
    }

</style>
