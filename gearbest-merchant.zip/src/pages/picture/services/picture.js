import Service from '@/assets/js/Service/index';

/**
 * 相册列表
 */
export const serviceAlbumList = new Service({
    url: '/image-manage/album-list',
    method: 'get',
    showError: true,
    loading: true
});


/**
 * 删除相册
 */
export const serviceAlbumDelete = new Service({
    url: '/image-manage/album-delete',
    method: 'post',
    showError: true
});

/**
 * 新建相册
 */
export const serviceAlbumCreate = new Service({
    url: '/image-manage/album-create',
    method: 'post',
    showError: true
});

/**
 * 更新
 */
export const serviceAlbumUpdate = new Service({
    url: '/image-manage/album-modify',
    method: 'post',
    showError: true
});


/**
 * 相册图片列表
 */
export const serviceAlbumImages = new Service({
    url: '/image-manage/album-file-list',
    method: 'get',
    showError: true,
    loading: true
});

/**
 * 删除图片
 */
export const serviceImageDelete = new Service({
    url: '/image-manage/album-file-delete',
    method: 'post',
    showError: true
});

/**
 * 移动图片
 */
export const serviceImageMove = new Service({
    url: '/image-manage/album-file-move',
    method: 'post',
    showError: true
});


/**
 * 设置封面
 */
export const serviceAlbumPoster = new Service({
    url: '/image-manage/album-modify',
    method: 'post',
    showError: true
});

export const serviceAlbumFileCreate = new Service({
    url: '/image-manage/album-file-create',
    method: 'post',
    showError: true
});

/**
 * 获取相册使用情况
 */
export const serviceAlbumAccount = new Service({
    url: '/image-manage/album-account',
    method: 'get',
    showError: true
});
