import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import pictureLang from '@/lang/picture';
import router from './router';


(async () => {
    const langInstance = await lang({ local: pictureLang, moduleName: 'picture' });
    app({ lang: langInstance, router });
})();
