<template>
    <el-row>
        <el-col :span="7">
            <el-select
                :value="countryCode"
                :placeholder="$t('logistics.location.placeholderCountry')"
                clearable
                filterable
                @input="changeAddress($event, 'country')"
            >
                <el-option
                    v-for="(item, index) in countrysArr"
                    :key="index"
                    :value="item"
                    :label="countrys[item]"
                />
            </el-select>
        </el-col>
        <el-col
            :span="1"
            :class="$style.divider"
        >
            -
        </el-col>
        <el-col :span="7">
            <el-input
                v-if="provincesArr.length === 0"
                :disabled="countryCode === ''"
                :value="provinceCode"
                :placeholder="$t('logistics.location.placeholderProvince')"
                @input="changeAddress($event, 'province')"
            />
            <el-select
                v-else
                :disabled="countryCode === ''"
                :value="provinceCode"
                :placeholder="$t('logistics.location.placeholderSprovince')"
                clearable
                filterable
                @input="changeAddress($event, 'province')"
            >
                <el-option
                    v-for="(item, index) in provincesArr"
                    :key="index"
                    :value="item"
                    :label="provinces[item]"
                />
            </el-select>
        </el-col>
        <el-col
            :span="1"
            :class="$style.divider"
        >
            -
        </el-col>
        <el-col :span="7">
            <el-input
                v-if="citysArr.length === 0"
                :disabled="provinceCode === ''"
                :value="cityCode"
                :placeholder="$t('logistics.location.placeholderCity')"
                @input="changeAddress($event, 'city')"
            />
            <el-select
                v-else
                :value="cityCode"
                :disabled="provinceCode === ''"
                :placeholder="$t('logistics.location.placeholderScity')"
                clearable
                filterable
                @input="changeAddress($event, 'city')"
            >
                <el-option
                    v-for="(item, index) in citysArr"
                    :key="index"
                    :value="item"
                    :label="citys[item]"
                />
            </el-select>
        </el-col>
    </el-row>
</template>
<script>
    import {
        countrysListGet,
        provincesListGet,
        citysListGet
    } from '@logistics/services/logisticsServices';

    export default {
        name: 'AddressCascadedSelect',
        props: {
            value: {
                type: Object,
                required: true,
                default() {
                    return {
                        countryCode: '',
                        provinceCode: '',
                        cityCode: '',
                        countryName: '',
                        provinceName: '',
                        cityName: ''
                    };
                }
            }
        },
        data() {
            return {
                countrys: {},
                provinces: {},
                citys: {}
            };
        },
        computed: {
            countrysArr() {
                return Object.keys(this.countrys);
            },
            provincesArr() {
                return Object.keys(this.provinces);
            },
            citysArr() {
                return Object.keys(this.citys);
            },
            countryCode() {
                return this.value.countryCode;
            },
            provinceCode() {
                return this.value.provinceCode;
            },
            cityCode() {
                return this.value.cityCode;
            },
        },
        watch: {
            'value.countryCode': {
                handler(val, oldVal) {
                    if (!val || (val !== oldVal)) {
                        this.getProvince(this.countryCode);
                    }
                }
            },
            'value.provinceCode': {
                handler(val, oldVal) {
                    if (!val || (val !== oldVal)) {
                        this.getCity(this.provinceCode);
                    }
                }
            }
        },
        created() {
            this.getCountrys();
        },
        mounted() {
            this.setDefaultValue();
        },
        methods: {
            // 设置默认值
            setDefaultValue() {
                if (this.countryCode) {
                    this.getProvince(this.countryCode);
                }
                if (this.provinceCode) {
                    this.getCity(this.provinceCode);
                }
            },
            // 获取国家
            async getCountrys() {
                const { status, data } = await countrysListGet.http({
                    showError: true
                });
                if (status === 0) {
                    const countrys = {};
                    data.forEach((item) => {
                        countrys[item.countryCode] = item.countryName;
                    });
                    this.countrys = countrys;
                }
            },
            // 获取省份
            async getProvince(val) {
                if (!val) {
                    return;
                }
                const params = {
                    countryCode: val
                };
                const { status, data } = await provincesListGet.http({
                    showError: true,
                    params
                });
                if (status === 0) {
                    const provinces = {};
                    data.forEach((item) => {
                        provinces[item.cdpProvinceId] = item.provinceName;
                    });
                    this.provinces = provinces;
                }
            },
            // 获取城市
            async getCity(val) {
                if (!val) {
                    return;
                }
                const params = {
                    provinceCode: val
                };
                const { status, data } = await citysListGet.http({
                    showError: true,
                    params
                });
                if (status === 0) {
                    const citys = {};
                    data.forEach((item) => {
                        citys[item.cdpCityId] = item.cityName;
                    });
                    this.citys = citys;
                }
            },
            changeAddress(val, key) {
                let name;
                if (key === 'country') {
                    if (val !== this.countryCode) {
                        this.$emit('input', {
                            ...this.value,
                            provinceCode: '',
                            cityCode: '',
                            provinceName: '',
                            cityName: ''
                        });
                    }
                    name = this.countrys[val];
                } else if (key === 'province') {
                    if (this.provincesArr.length > 0) {
                        if (val !== this.provinceCode) {
                            this.$emit('input', { ...this.value, cityCode: '', cityName: '' });
                        }
                        name = this.provinces[val];
                    } else {
                        name = val;
                    }
                } else if (this.citysArr.length > 0) {
                    name = this.citys[val];
                } else {
                    name = val;
                }
                this.$nextTick(() => {
                    this.$emit('input', { ...this.value, [`${key}Code`]: val, [`${key}Name`]: name });
                });
            }
        }
    };
</script>

<style module>
    .divider {
        text-align: center;
    }
</style>
