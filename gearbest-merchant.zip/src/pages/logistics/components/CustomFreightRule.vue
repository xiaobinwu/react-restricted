<template>
    <div>
        <!-- 运费配置 -->
        <template v-if="originalRuleInfoList.length > 0">
            <h3 :class="$style.title">{{ $t('logistics.tpl.added') }}</h3>
            <el-row
                v-for="(ruleInfo, index) in originalRuleInfoList"
                :key="index"
                :class="[$style.row, index === selectedIndex ? $style.selected : '']"
            >
                <el-col :span="18">
                    <el-popover
                        :popper-class="$style.popper"
                        :offset="105"
                        placement="bottom"
                        width="840"
                        trigger="hover"
                    >
                        <div :class="ruleInfo.closeCountry && ruleInfo.closeCountry.length > 0 ? $style.additionalCountries : ''">
                            <h3>已添加国家：</h3>
                            <p>
                                <span>{{ (ruleInfo.countryList || []).map(item => allCountrys[item]).join(', ') }}</span><span
                                    v-if="ruleInfo.countryList &&
                                        ruleInfo.countryList.length > 0 &&
                                        ruleInfo.closeCountry &&
                                    ruleInfo.closeCountry.length > 0">, </span>
                                <span :class="$style.closedCountry">
                                    {{ (ruleInfo.closeCountry || []).map(item => allCountrys[item]).join(', ') }}
                                </span>
                            </p>
                        </div>
                        <div v-if="ruleInfo.closeCountry && ruleInfo.closeCountry.length > 0">
                            <h3>其中系统关闭国家：</h3>
                            <p>{{ (ruleInfo.closeCountry || []).map(item => allCountrys[item]).join(', ') }}</p>
                        </div>
                        <div
                            slot="reference"
                            :class="$style.countryCol"
                        >
                            <span>{{ (ruleInfo.countryList || []).map(item => allCountrys[item]).join(', ') }}</span><span
                                v-if="ruleInfo.countryList &&
                                    ruleInfo.countryList.length > 0 &&
                                    ruleInfo.closeCountry &&
                                ruleInfo.closeCountry.length > 0">, </span>
                            <span :class="$style.closedCountryAsh">
                                {{ (ruleInfo.closeCountry || []).map(item => allCountrys[item]).join(', ') }}
                            </span>
                        </div>
                    </el-popover>
                </el-col>
                <el-col :span="3">
                    {{ types[ruleInfo.feeType] }}
                </el-col>
                <el-col :span="3">
                    <el-button v-if="!rule.isClose" type="text" @click="editRule(ruleInfo, index)">{{ $t('logistics.edit') }}</el-button>
                    <el-button type="text" @click="deleteRule(ruleInfo, index)">{{ $t('logistics.delete') }}</el-button>
                </el-col>
            </el-row>
        </template>
        <div v-show="isExpand">
            <country-select
                ref="countrySelect"
                :countrys="countrys"
                :exclude-countrys="excludeCountrys"
                :selected-countrys="selectedCountrys"
                :handled-countrys="handledCountrys"
            />
            <h3 :class="$style.title">{{ $t('logistics.tpl.ruleSet') }}</h3>
            <el-form ref="form" :model="form" :rules="rules" :class="$style.ruleForm" label-suffix=":" label-width="120px">
                <el-form-item :label="$t('logistics.tpl.type')" prop="feeType">
                    <el-select v-model="form.feeType" :style="{ width: '240px' }" :placeholder="$t('logistics.tpl.typePlace')">
                        <template v-for="(value, key) in types">
                            <template v-if="key === '2'">
                                <el-option v-if="type === 3" :key="key" :label="value" :value="key"></el-option>
                            </template>
                            <template v-else>
                                <el-option :key="key" :label="value" :value="key"></el-option>
                            </template>
                        </template>
                    </el-select>
                </el-form-item>
                <el-form-item v-if="form.feeType === '1'" :label="$t('logistics.tpl.culType')" prop="countType">
                    <el-select v-model="form.countType" :style="{ width: '240px' }" :placeholder="$t('logistics.tpl.culTypePlace')">
                        <el-option :label="$t('logistics.tpl.typeVal1')" value="1"></el-option>
                        <el-option :label="$t('logistics.tpl.typeVal2')" value="2"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item v-if="form.countType === '1' && form.feeType === '1'" label="" label-width="0px">
                    <h4 :class="$style.formTitle">{{ $t('logistics.tpl.culSet') }}:</h4>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item
                                :rules="[{ required: true, validator: validateRule }]"
                                :label="$t('logistics.tpl.firstWeight')"
                                prop="firstWeight"
                                label-width="94px"
                            >
                                <el-input v-model="form.firstWeight" @change="changeFirstWeight($event, 0)"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item
                                :rules="[{ required: true, validator: validateRule }]"
                                :label="$t('logistics.tpl.firstHeavyFreight')"
                                prop="firstHeavyFreight"
                            >
                                <el-input v-model="form.firstHeavyFreight"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item
                    v-if="form.countType === '1' && form.feeType === '1'"
                    key="freight"
                    :style="{ marginTop: '10px' }"
                    label=""
                    label-width="0px"
                >
                    <el-row v-for="(item, index) in form.paramRangeList" :key="index" :style="{ marginTop: '20px' }">
                        <el-col :span="20" :class="$style.condition">
                            <el-row>
                                <el-col :span="9" :style="{ 'textAlign': 'right' }">
                                    <span>{{ $t('logistics.tpl.weightRange') }}:</span>
                                    <el-form-item
                                        :prop="'paramRangeList.' + index + '.scopeStart'"
                                        :style="{ 'display': 'inline-block' }"
                                        :rules="[
                                            { required: true, validator: validateRule },
                                            { validator: validateWeightStartRange }
                                        ]"
                                    >
                                        <el-input v-model.trim.lazy="item.scopeStart" :style="{ 'width': '70px' }" :disabled="true"></el-input>
                                    </el-form-item>
                                    <span>-</span>
                                    <el-form-item
                                        :prop="'paramRangeList.' + index + '.scopeEnd'"
                                        :style="{ 'display': 'inline-block' }"
                                        :rules="[
                                            { required: true, validator: validateRule },
                                            { validator: validateWeightEndRange }
                                        ]"
                                    >
                                        <el-input
                                            v-model.trim.lazy="item.scopeEnd"
                                            :style="{ 'width': '70px' }"
                                            @change="changeFirstWeight($event, index + 1)" />
                                    </el-form-item>
                                </el-col>
                                <el-col :span="7">
                                    <el-form-item
                                        :prop="'paramRangeList.' + index + '.overlayNum'"
                                        :rules="[
                                            { required: true, validator: validateRule },
                                            { validator: validateOverlayNum },
                                        ]"
                                        :class="$style.overlayNumInput"
                                        :label="$t('logistics.tpl.overlayNum')"
                                        label-width="140px"
                                    >
                                        <el-input v-model.trim.lazy="item.overlayNum" :style="{ 'width': '70px' }"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="7">
                                    <el-form-item
                                        :prop="'paramRangeList.' + index + '.addFee'"
                                        :rules="[{ required: true, validator: validateRule }]"
                                        :label="$t('logistics.tpl.addFee')"
                                    >
                                        <el-input v-model.trim.lazy="item.addFee"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                        </el-col>
                        <el-col :span="4" :class="$style.conditionBtn">
                            <el-button
                                v-if="form.paramRangeList.length - 1 === index && form.paramRangeList.length !== 10"
                                type="primary"
                                size="small"
                                @click="addParamRange"
                            >{{ $t('logistics.add') }}</el-button>
                            <el-button
                                v-if="form.paramRangeList.length - 1 === index && form.paramRangeList.length !== 1"
                                type="danger"
                                size="small"
                                @click="removeParamRange(index)"
                            >{{ $t('logistics.delete') }}</el-button>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item v-if="form.countType === '2' && form.feeType === '1'" key="pieces" label="" label-width="0px">
                    <h4 :class="$style.formTitle">{{ $t('logistics.tpl.culSet') }}:</h4>
                    <el-row>
                        <el-col :span="7" :style="{ 'textAlign': 'right' }">
                            <span>{{ $t('logistics.tpl.pieceRange') }}:</span>
                            <el-form-item
                                :rules="[
                                    { required: true, validator: validatePieces },
                                    { validator: validatePiecesStartRange }
                                ]"
                                :style="{ 'display': 'inline-block' }"
                                prop="firstItemStart"
                            >
                                <el-input v-model="form.firstItemStart" :style="{ 'width': '70px' }" :disabled="true"></el-input>
                            </el-form-item>
                            <span>-</span>
                            <el-form-item
                                :rules="[
                                    { required: true, validator: validatePieces },
                                    { validator: validatePiecesEndRange }
                                ]"
                                :style="{ 'display': 'inline-block' }"
                                prop="firstItemEnd"
                            >
                                <el-input v-model="form.firstItemEnd" :style="{ 'width': '70px' }"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="6">
                            <el-form-item
                                :rules="[{ required: true, validator: validateRule }]"
                                :label="$t('logistics.tpl.firstHeavyItem')"
                                prop="firstHeavyItem"
                            >
                                <el-input v-model="form.firstHeavyItem"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="5">
                            <el-form-item
                                :rules="[{ required: true, validator: validatePieces }]"
                                :label="$t('logistics.tpl.addPiece')"
                                prop="addPiece"
                            >
                                <el-input v-model="form.addPiece"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="6">
                            <el-form-item
                                :rules="[{ required: true, validator: validateRule }]"
                                :label="$t('logistics.tpl.addFee')"
                                prop="continueShipping"
                            >
                                <el-input v-model="form.continueShipping"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form-item>
                <template v-if="form.feeType === '2'">
                    <h4 :class="$style.formTitle">{{ $t('logistics.tpl.culSet') }}:</h4>
                    <el-form-item
                        :rules="[
                            { validator: validateInteger.bind(this, 100) }
                        ]"
                        :label="$t('logistics.tpl.reduceRate')"
                        prop="reduceRate"
                    >
                        <el-input v-model="form.reduceRate" :style="{ 'width': '150px' }">
                            <template slot="append">%</template>
                        </el-input>
                    </el-form-item>
                </template>
                <el-form-item :class="$style.addBtn" label-width="0px">
                    <el-button :style="{ marginLeft: '30px' }" @click="cancelOperate">{{ $t('logistics.cancel.text') }}</el-button>
                    <el-button type="primary" @click="sureOperate">{{ $t('logistics.tpl.sureAdd') }}</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div v-show="!isExpand">
            <el-button v-if="!rule.isClose" :class="$style.expandLink" @click="isExpand = true">
                <i class="el-icon-circle-plus-outline"></i>
                <span>{{ $t('logistics.tpl.combined') }}</span>
            </el-button>
            <div :class="$style.addBtn">
                <el-button :style="{ marginLeft: '30px' }" @click="closeModal">{{ $t('logistics.cancel.text') }}</el-button>
                <el-button type="primary" @click="save">{{ $t('logistics.save.text') }}</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    import CountrySelect from '@logistics/components/CountrySelect';

    const defaultFormOption = {
        index: '',
        countType: '1', // 计算类型
        feeType: '1', // 运费规则类型
        reduceRate: 0, // 标准运费减免率

        firstWeight: '', // 首重
        firstHeavyFreight: '', // 首重运费

        firstItemStart: '1', // 首件起始值
        firstItemEnd: '', // 首件结束值
        firstHeavyItem: '', // 首件运费
        addPiece: '', // 每增加件数
        continueShipping: '', // 续加运费

        // 运费规则数据列表
        paramRangeList: [
            {
                scopeStart: '',
                scopeEnd: '',
                overlayNum: '',
                addFee: ''
            }
        ]
    };
    export default {
        name: 'CustomFreightRule',
        components: {
            'country-select': CountrySelect
        },
        props: {
            // 规则
            rule: {
                type: Object,
                required: true
            },
            // 模板类型
            type: {
                type: [String, Number],
                required: true
            },
            // 运费类型
            types: {
                type: Object,
                required: true
            },
            // 可发国家
            countrys: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            // 所有国家
            countryslist: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            // 是否显示，监控每次打开都执行initData函数
            isshow: {
                type: Boolean,
                required: true
            },
        },
        data() {
            const list = JSON.parse(JSON.stringify(this.rule.ruleInfoList));
            return {
                form: JSON.parse(JSON.stringify(defaultFormOption)),
                rules: {
                    feeType: [
                        { required: true, message: this.$t('logistics.tpl.typePlace'), trigger: 'change' },
                    ],
                    countType: [
                        { required: true, message: this.$t('logistics.tpl.culTypePlace'), trigger: 'change' }
                    ]
                },
                selectedCountrys: [],
                selectedIndex: '',
                originalRuleInfoList: list,
                isExpand: list.length === 0,
            };
        },
        computed: {
            // 运费配置列表
            ruleInfoList() {
                if (this.selectedIndex > -1 && this.selectedCountrys.length > 0) {
                    return this.originalRuleInfoList.filter((item, index) => this.selectedIndex !== index);
                }
                return this.originalRuleInfoList;
            },
            // 排除的国家简码
            excludeCountrys() {
                const countryCodes = [];
                // 运费配置
                if (this.ruleInfoList && this.ruleInfoList.length > 0) {
                    this.ruleInfoList.forEach((item) => {
                        if (item.countryRels) {
                            item.countryRels.forEach((country) => {
                                countryCodes.push(country.countryCode);
                            });
                        }
                    });
                }
                return countryCodes;
            },
            // 可发国家装换成对象形式
            handledCountrys() {
                const countrys = {};
                if (this.countrys && this.countrys.length > 0) {
                    this.countrys.forEach((item) => {
                        countrys[item.countryCode] = item.countryName;
                    });
                }
                return countrys;
            },

            // 国家换成对象形式
            allCountrys() {
                const countryList = {};
                if (this.countryslist && this.countryslist.length > 0) {
                    this.countryslist.forEach((item) => {
                        countryList[item.countryCode] = item.countryName;
                    });
                }
                return countryList;
            }
        },
        watch: {
            'rule.ruleInfoList': {
                deep: true,
                handler(val) {
                    this.originalRuleInfoList = JSON.parse(JSON.stringify(val));
                    if (this.originalRuleInfoList.length === 0) {
                        this.isExpand = true;
                    }
                }
            },
            isshow: {
                handler(val) {
                    this.initData();
                }
            },
        },
        created() {
            this.initData();
        },
        methods: {
            // 初始把已选中的国家简码提取出来
            async initData() {
                let countryList = [];
                let closeCountry = [];
                const isCopy = this.$route.query.copy;
                this.originalRuleInfoList.forEach((item) => {
                    countryList = [];
                    closeCountry = [];
                    if (item.countryRels) {
                        item.countryRels.forEach((country) => {
                            if (country.status === 1) {
                                countryList.push(country.countryCode);
                            }

                            if (country.status === 0 && !isCopy) {
                                closeCountry.push(country.countryCode);
                            }
                        });
                        item.countryList = countryList;
                        item.closeCountry = closeCountry;
                    }
                });
            },

            // 首重值改变
            changeFirstWeight(value, index) {
                if (index < this.form.paramRangeList.length) {
                    this.form.paramRangeList[index].scopeStart = value;
                    this.$refs.form.validateField([`paramRangeList.${index}.scopeStart`]);
                }
            },
            // 校验-整数
            validateInteger(max, rule, value, callback) {
                if (value === '') {
                    return callback();
                }
                const pattern = /^[0-9]\d*$/;
                if (!pattern.test(value)) {
                    return callback(new Error(this.$t('logistics.verify.int')));
                }
                if (max && Number(value) > Number(max)) {
                    return callback(new Error(this.$t('logistics.verify.max', [max])));
                }
                return callback();
            },
            // 校验-重量必须大于0小于9999，小数点仅保留两位
            validateRule(rule, value, callback) {
                let isObjectField = false;
                const fields = rule.field.split('.');
                const numberValue = Number(value);
                // 区分续重区间段和首重
                if (fields[0] === 'paramRangeList') {
                    isObjectField = true;
                }
                if (value === '') {
                    return callback(this.$t('logistics.tpl.write'));
                }
                const setValue = (val) => {
                    if (isObjectField) {
                        this.form.paramRangeList[fields[1]][fields[2]] = val;
                    } else {
                        this.form[fields[0]] = val;
                    }
                };
                if (/^[^0-9.]+$/.test(value) || numberValue < 0) {
                    setValue('');
                    return callback(new Error());
                }
                if (numberValue > 9999) {
                    setValue(9999);
                    return callback(new Error());
                }
                const pattern = /^\d+(.\d+)?$/;
                if (!pattern.test(value)) {
                    return callback(new Error(' '));
                }
                const arr = String(value).split('.');
                if (arr.length === 2 && arr[1].length > 2) {
                    setValue(numberValue.toFixed(3));
                }
                return callback();
            },
            // 校验-续重范围A必须<B
            validateWeightStartRange(rule, value, callback) {
                const index = rule.field.split('.')[1];
                if (this.form.paramRangeList[index].scopeEnd !== '') {
                    this.$refs.form.validateField(`paramRangeList.${index}.scopeEnd`);
                }
                callback();
            },
            validateWeightEndRange(rule, value, callback) {
                const index = rule.field.split('.')[1];
                if (Number(value) <= Number(this.form.paramRangeList[index].scopeStart)) {
                    return callback(new Error(' '));
                }
                return callback();
            },
            // 验证每增加重量
            validateOverlayNum(rule, value, callback) {
                const index = rule.field.split('.')[1];
                const diff = this.form.paramRangeList[index].scopeEnd - this.form.paramRangeList[index].scopeStart;
                if (Number(value) > diff) {
                    // this.form.paramRangeList[index].overlayNum = '';
                    return callback(new Error(this.$t('logistics.verify.overlayNum')));
                }
                return callback();
            },
            // 校验，件数必须为正整数
            validatePieces(rule, value, callback) {
                if (value === '') {
                    return callback(this.$t('logistics.tpl.write'));
                }
                const pattern = /^[1-9]\d*$/;
                if (!pattern.test(value)) {
                    this.form[rule.field] = '';
                    return callback(new Error(' '));
                }
                if (parseFloat(value) > 9999) {
                    this.form[rule.field] = 9999;
                    return callback(new Error());
                }
                return callback();
            },
            // 校验-首件范围A必须<B
            validatePiecesStartRange(rule, value, callback) {
                if (this.form.firstItemStart !== '') {
                    this.$refs.form.validateField('firstItemEnd');
                }
                callback();
            },
            validatePiecesEndRange(rule, value, callback) {
                if (Number(value) <= Number(this.form.firstItemStart)) {
                    return callback(new Error(' '));
                }
                return callback();
            },
            // 关闭弹框
            closeModal() {
                this.$emit('close');
            },
            // 确认提交
            save() {
                const newRule = JSON.parse(JSON.stringify(this.rule));
                newRule.ruleInfoList = this.originalRuleInfoList;
                this.$emit('change', newRule);
            },
            // 添加运费计算规则
            addParamRange() {
                const len = this.form.paramRangeList.length;
                if (len === 10) {
                    return this.$message({
                        message: this.$t('logistics.verify.maxWeightRange', [10]),
                        type: 'warning'
                    });
                }
                this.form.paramRangeList.push({
                    scopeStart: this.form.paramRangeList[len - 1].scopeEnd || '',
                    scopeEnd: '',
                    overlayNum: '',
                    addFee: ''
                });
                return true;
            },
            // 移除运费计算规则
            removeParamRange(index) {
                this.form.paramRangeList.splice(index, 1);
            },
            // 确认添加
            sureOperate() {
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        const countryList = this.$refs.countrySelect.getSelectedCountrys();
                        if (countryList.length === 0) {
                            return this.$message({
                                message: this.$t('logistics.verify.country'),
                                type: 'error'
                            });
                        }
                        const originalRuleInfo = {};
                        // 数据重新组装
                        const { feeType, countType } = this.form;
                        originalRuleInfo.feeType = feeType;
                        // 获取已选中的国家
                        originalRuleInfo.countryRels = [];
                        countryList.forEach((item) => {
                            originalRuleInfo.countryRels.push(
                                {
                                    countryCnName: '',
                                    countryCode: item,
                                    countryName: '',
                                    status: 1,
                                    type: ''
                                }
                            );
                        });
                        // 自定义运费-按重量
                        if (feeType === '1' && countType === '1') {
                            const { firstWeight, firstHeavyFreight, paramRangeList } = this.form;
                            originalRuleInfo.countType = countType;
                            const paramItem = {
                                paramType: '1',
                                scopeStart: '0',
                                scopeEnd: firstWeight,
                                overlayNum: firstWeight,
                                addFee: firstHeavyFreight
                            };
                            const newParamRangeList = JSON.parse(JSON.stringify(paramRangeList)).map((item) => {
                                item.paramType = 0;
                                return item;
                            });
                            newParamRangeList.unshift(paramItem);
                            originalRuleInfo.paramRangeList = newParamRangeList;
                        }
                        // 自定义运费-按件
                        if (feeType === '1' && countType === '2') {
                            const {
                                firstItemStart,
                                firstItemEnd,
                                firstHeavyItem,
                                addPiece,
                                continueShipping
                            } = this.form;
                            originalRuleInfo.countType = countType;
                            const paramArrs = [
                                {
                                    paramType: '1',
                                    scopeStart: firstItemStart,
                                    scopeEnd: firstItemEnd,
                                    overlayNum: firstItemEnd,
                                    addFee: firstHeavyItem
                                },
                                {
                                    paramType: '0',
                                    scopeStart: firstItemEnd,
                                    scopeEnd: '9999', // 给个大的数
                                    overlayNum: addPiece,
                                    addFee: continueShipping
                                }
                            ];
                            originalRuleInfo.paramRangeList = paramArrs;
                        }
                        // 标准运费
                        if (feeType === '2') {
                            originalRuleInfo.reduceRate = this.form.reduceRate || 0;
                        }
                        const newOriginalRuleInfo = JSON.parse(JSON.stringify(originalRuleInfo));
                        if (this.form.index) {
                            // 编辑情况
                            this.originalRuleInfoList.splice(Number(this.form.index), 1, newOriginalRuleInfo);
                        } else {
                            // 新增情况
                            this.originalRuleInfoList.push(newOriginalRuleInfo);
                        }
                        this.$nextTick(() => {
                            this.cancelOperate();
                        });
                        return true;
                    }
                    console.log('error submit!!');
                    return false;
                });
            },
            // 重置表单值
            resetFields() {
                this.form = JSON.parse(JSON.stringify(defaultFormOption));
                this.$nextTick(() => {
                    this.$refs.form.clearValidate();
                });
            },
            // 取消添加或编辑运费规则
            cancelOperate() {
                this.selectedIndex = '';
                this.selectedCountrys = [];
                this.resetFields();
                this.$nextTick(() => {
                    this.isExpand = false;
                });
                // this.$refs.countrySelect.reset();
                this.initData();
            },
            // 编辑
            editRule(rule, index) {
                const feeType = String(rule.feeType);
                this.isExpand = true;
                this.selectedIndex = index;
                this.selectedCountrys = rule.countryList;
                this.form.index = String(index);
                this.form.feeType = feeType;
                // 自定义运费 - 按重量
                if (feeType === '1' && String(rule.countType) === '1') {
                    this.form.countType = String(rule.countType);
                    this.form.firstWeight = rule.paramRangeList[0].scopeEnd;
                    this.form.firstHeavyFreight = rule.paramRangeList[0].addFee;
                    this.form.paramRangeList = rule.paramRangeList.filter(item => String(item.paramType) === '0');
                }
                // 自定义运费 - 按件数
                if (feeType === '1' && String(rule.countType) === '2') {
                    this.form.countType = String(rule.countType);
                    this.form.firstItemStart = rule.paramRangeList[0].scopeStart;
                    this.form.firstItemEnd = rule.paramRangeList[0].scopeEnd;
                    this.form.firstHeavyItem = rule.paramRangeList[0].addFee;
                    this.form.addPiece = rule.paramRangeList[1].overlayNum;
                    this.form.continueShipping = rule.paramRangeList[1].addFee;
                }
                // 标准运费
                if (feeType === '2') {
                    this.form.reduceRate = rule.reduceRate;
                }
            },
            // 删除
            deleteRule(rule, index) {
                this.originalRuleInfoList.splice(index, 1);
                if (index === this.selectedIndex) {
                    this.selectedIndex = '';
                    this.selectedCountrys = [];
                    // this.$refs.countrySelect.reset();
                }
            },
            // 重置data属性
            resetData() {
                this.$nextTick(() => {
                    this.isExpand = false;
                    this.resetFields();
                    this.$refs.form.clearValidate();
                    this.selectedIndex = '';
                    this.selectedCountrys = [];
                    this.originalRuleInfoList = JSON.parse(JSON.stringify(this.rule.ruleInfoList));
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';
    .title {
        margin-bottom: 20px;
    }
    .formTitle {
        color: var(--color-text-regular);
        font-weight: normal;
        padding-left: 20px;
        margin-bottom: 20px;
    }
    .row {
        border: 1px solid var(--border-color-lighter);
        margin-bottom: 12px;
        :global .el-col {
            height: 40px;
            line-height: 40px;
        }
    }
    .selected {
        :global .el-button:first-child {
            color: var(--color-success);
        }
    }
    .countryCol {
        padding-left: 10px;
        @extend %nowrap;
    }
    .popper {
        word-break: break-all;
        word-wrap: break-word;
        line-height: 24px;
    }
    .ruleForm {
        padding: 20px 0;
    }
    .condition {
        padding: 20px 0;
        border: 1px var(--border-color-base) solid;
    }
    .conditionBtn {
        line-height: 82px;
        padding-left: 8px;
    }
    .addBtn {
        text-align: center;
        margin-top: 40px;
        margin-bottom: 0;
        :global .el-button {
            width: 120px;
        }
    }
    .expandLink {
        margin-bottom: 20px;
    }
    .overlayNumInput {
        :global .el-form-item__error {
            position: absolute;
            top: 100%;
            left: 0px;
            width: 295px;
            line-height: 16px;
        }
    }
    .additionalCountries{
        border-bottom: 2px solid var(--border-color-lighter);
        padding-bottom: 10px;
        margin-bottom: 10px;
    }
    .closedCountry{
        color: var(--color-error);
    }
    .closedCountryAsh{
        color: var(--border-color-light);
    }
</style>
