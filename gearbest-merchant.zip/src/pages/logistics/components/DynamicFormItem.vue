<template>
    <el-form-item
        ref="formItem"
        :prop="item.key"
        v-bind="item.formItem"
    >
        <!-- 关键$attrs与$listeners，继承父作用域的特性和事件监听器 -->
        <el-input
            v-if="item.type==='input'"
            :type="item.subtype"
            :style="{ width: attrs.width || '100%' }"
            v-bind="attrs"
            v-on="$listeners"
        >
            <slot name="prefix"/>
            <slot name="suffix"/>
            <slot name="prepend"/>
            <slot name="prepend"/>
        </el-input>

        <el-select
            v-else-if="item.type==='select'"
            v-bind="attrs"
            v-on="$listeners"
        >
            <el-option
                v-for="o in attrs.options"
                :key="o.value"
                :label="o.label"
                :value="o.value"
                :disabled="o.disabled" />
        </el-select>

        <el-checkbox
            v-else-if="item.type==='checkbox'"
            v-bind="attrs"
            v-on="$listeners"
        >
            {{ attrs.text }}
        </el-checkbox>

        <!-- 自定义表单组件 -->
        <!-- 地址联动选择器 -->
        <address-cascaded-select
            v-else-if="item.type==='cascadedAddress'"
            v-bind="attrs"
            v-on="$listeners"
        />
    </el-form-item>
</template>

<script>
    // 地址联动器
    import AddressCascadedSelect from '@logistics/components/AddressCascadedSelect';
    import { isObject } from '@/assets/js/utils/types';

    export default {
        name: 'DynamicFormItem',
        components: {
            'address-cascaded-select': AddressCascadedSelect,
        },
        props: {
            item: {
                type: Object,
                required: true
            }
        },
        computed: {
            attrs() {
                const { formComponent } = this.item;
                const setting = isObject(formComponent) ? formComponent : {};
                return { ...this.$attrs, ...setting };
            }
        },
        methods: {
            getRef() {
                return this.$refs.formItem;
            }
        }
    };
</script>

<style module>

</style>
