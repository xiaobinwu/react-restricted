<template>
    <div>
        <paginated-table
            v-loading="loading"
            :data="list"
            :columns="columns"
            :attrs="attrs"
            :pagination="pagination"
            :class="$style.table"
            @pagesize-change="changePageSize"
            @page-change="changePage"
        >
            <template
                slot="feeType"
                slot-scope="scope"
            >
                {{ feeTypes.length > 0 && feeTypes.find(item => String(item.value) === String(scope.row.feeType)).name }}
            </template>
            <template
                slot="charges"
                slot-scope="scope"
            >
                <template v-if="scope.row.feeType === 1">
                    <template v-if="scope.row.countType === 1">
                        <template v-if="scope.row.paramRangeList && scope.row.paramRangeList.length > 0">
                            <p>
                                {{ $t('logistics.detail.freightDec1', [scope.row.paramRangeList[0].scopeEnd, scope.row.paramRangeList[0].addFee]) }}
                            </p>
                            <p v-for="(item, index) in scope.row.paramRangeList" v-if="index !== 0" :key="index">
                                {{ $t('logistics.detail.freightDec2', [`${item.scopeStart}-${item.scopeEnd}`, item.overlayNum, item.addFee]) }}
                            </p>
                        </template>
                    </template>
                    <template v-else-if="scope.row.countType === 2">
                        <template v-if="scope.row.paramRangeList && scope.row.paramRangeList.length > 0">
                            <p>
                                {{ $t('logistics.detail.freightDec3',
                                      [`${scope.row.paramRangeList[0].scopeStart}-${scope.row.paramRangeList[0].scopeEnd}`,
                                       scope.row.paramRangeList[0].addFee]) }}
                            </p>
                            <p v-for="(item, index) in scope.row.paramRangeList" v-if="index !== 0" :key="index">
                                {{ $t('logistics.detail.freightDec4', [item.overlayNum, item.addFee]) }}
                            </p>
                        </template>
                    </template>
                </template>
                <template v-if="scope.row.feeType === 2">
                    {{ $t('logistics.detail.freightDec5', [scope.row.reduceRate || 0]) }}
                </template>
            </template>
            <template
                slot="countrys"
                slot-scope="scope"
            >
                {{ $t('logistics.detail.coun', [scope.row.countryCodes.length]) }}
                <el-button type="text" @click="viewMore(scope.row)">（{{ $t('logistics.detail.more') }}）</el-button>
            </template>
        </paginated-table>
        <el-dialog
            :visible.sync="viewVisible"
            width="560px"
        >
            <p :class="$style.dailogType"><strong>{{ $t('logistics.detail.freightType') }}：</strong> {{ currentFeeType }}</p>
            <h4 :class="$style.dialogTitle">{{ $t('logistics.detail.setCoun') }}：</h4>
            <p>{{ currentCountrys }}</p>
        </el-dialog>
    </div>
</template>

<script>
    import { shippingFreightGet } from '@logistics/services/logisticsServices';
    import PaginatedTable from '@logistics/components/PaginatedTable';

    export default {
        name: 'FreightRuleDetail',
        components: {
            'paginated-table': PaginatedTable
        },
        props: {
            id: {
                type: [String, Number],
                required: true
            },
            feeTypes: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            type: {
                type: [String, Number],
                required: true
            },
            countrys: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            }
        },
        data() {
            return {
                loading: false,
                list: [],
                columns: [{
                    prop: 'levelName',
                    label: this.$t('logistics.detail.level'),
                    align: 'center',
                    'header-align': 'center'
                }, {
                    prop: 'feeType',
                    label: this.$t('logistics.detail.freightType'),
                    align: 'center',
                    'header-align': 'center',
                    scope: true
                }, {
                    prop: 'charges',
                    label: this.$t('logistics.detail.standard'),
                    width: '400px',
                    scope: true
                }, {
                    prop: 'countrys',
                    label: this.$t('logistics.detail.delCoun'),
                    width: '260px',
                    scope: true
                }],
                attrs: {
                    stripe: true
                },
                pagination: {
                    pageNo: 1,
                    pageSize: 15,
                    totalCount: 0
                },
                viewVisible: false,
                currentFeeType: 0,
                currentCountrys: ''
            };
        },
        watch: {
            $route(to, from) {
                if (this.type === '3' || (this.type === '2' && to.query.activeName === 'freight')) {
                    this.init();
                }
            }
        },
        created() {
            this.init();
        },
        methods: {
            init() {
                const { pageNo, pageSize, activeName } = this.$route.query;
                const params = {
                    pageNo: 1,
                    pageSize: 15
                };
                if (pageNo && pageSize) {
                    if (this.type === '3' || (this.type === '2' && activeName === 'freight')) {
                        params.pageNo = Number(pageNo);
                        params.pageSize = Number(pageSize);
                    }
                }
                this.getList(params);
            },
            async getList(params) {
                this.loading = true;
                const reParams = { ...params, id: this.id };
                const { status, data } = await shippingFreightGet.http({
                    showError: true,
                    params: reParams
                });
                if (status === 0 && data) {
                    const { list, totalCount } = data.ruleInfoList;
                    list.forEach((item) => {
                        if (item.feeType === 1 && item.countType === 1) {
                            item.paramRangeList.forEach((it) => {
                                it.scopeStart = it.scopeStart.toFixed(1);
                                it.scopeEnd = it.scopeEnd.toFixed(1);
                                it.addFee = it.addFee.toFixed(2);
                                it.overlayNum = it.overlayNum.toFixed(1);
                            });
                        }
                        if (item.feeType === 1 && item.countType === 2) {
                            item.paramRangeList.forEach((it) => {
                                it.addFee = it.addFee.toFixed(2);
                            });
                        }
                    });
                    this.updateSearch(params);
                    this.list = list;
                    this.pagination.totalCount = totalCount;
                }
                this.$nextTick(() => {
                    this.loading = false;
                });
            },
            // 搜索条件赋值
            updateSearch(params) {
                this.pagination.pageNo = params.pageNo;
                this.pagination.pageSize = params.pageSize;
            },
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
            },
            viewMore(row) {
                this.currentFeeType = this.feeTypes.length > 0 && this.feeTypes.find(item => String(item.value) === String(row.feeType)).name;
                const currentCountrys = [];
                this.countrys.forEach((item) => {
                    if (row.countryCodes.includes(item.countryCode)) {
                        currentCountrys.push(item.countryName);
                    }
                });
                this.currentCountrys = currentCountrys.join('，');
                this.viewVisible = true;
            },
            turnUrl() {
                this.$nextTick(() => {
                    const { pageNo, pageSize } = this.pagination;
                    this.$router.push({
                        name: 'shippingDetail',
                        query: {
                            ...this.$route.query,
                            pageNo,
                            pageSize,
                            ...(this.type === '2' ? { activeName: 'freight' } : {})
                        }
                    });
                });
            },
        }
    };
</script>

<style module>
@import 'variable.css';
.table {
    :global .el-table {
        border: 1px var(--border-color-lighter) solid;
    }
}
.dialogTitle {
    margin-bottom: 10px;
}
.dailogType {
    margin-bottom: 20px;
}
</style>
