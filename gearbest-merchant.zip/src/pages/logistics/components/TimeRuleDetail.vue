<template>
    <div>
        <paginated-table
            v-loading="loading"
            :data="list"
            :columns="columns"
            :attrs="attrs"
            :pagination="pagination"
            :class="$style.table"
            @pagesize-change="changePageSize"
            @page-change="changePage"
        >
            <template
                slot="time"
                slot-scope="scope"
            >
                {{ scope.row.minDay }} - {{ scope.row.maxDay }}
            </template>

            <template
                slot="countrys"
                slot-scope="scope"
            >
                {{ $t('logistics.detail.coun', [scope.row.countryCodes.length]) }}
                <el-button type="text" @click="viewMore(scope.row)">（{{ $t('logistics.detail.more') }}）</el-button>
            </template>
        </paginated-table>
        <el-dialog
            :visible.sync="viewVisible"
            width="560px"
        >
            <p :class="$style.dailogType"><strong>{{ $t('logistics.detail.delTime') }}：</strong> {{ currentTime }}</p>
            <h4 :class="$style.dialogTitle">{{ $t('logistics.detail.setCoun') }}：</h4>
            <p>{{ currentCountrys }}</p>
        </el-dialog>
    </div>
</template>

<script>
    import { shippingTimeGet } from '@logistics/services/logisticsServices';
    import PaginatedTable from '@logistics/components/PaginatedTable';

    export default {
        name: 'TimeRuleDetail',
        components: {
            'paginated-table': PaginatedTable
        },
        props: {
            id: {
                type: [String, Number],
                required: true
            },
            countrys: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            type: {
                type: [String, Number],
                required: true
            },
        },
        data() {
            return {
                loading: false,
                list: [],
                columns: [{
                    prop: 'time',
                    label: this.$t('logistics.detail.delTime'),
                    align: 'center',
                    'header-align': 'center',
                    scope: true
                }, {
                    prop: 'levelName',
                    label: this.$t('logistics.detail.level'),
                    align: 'center',
                    'header-align': 'center'
                }, {
                    prop: 'countrys',
                    label: this.$t('logistics.detail.delCoun'),
                    width: '260px',
                    scope: true
                }],
                attrs: {
                    stripe: true
                },
                pagination: {
                    pageNo: 1,
                    pageSize: 15,
                    totalCount: 0
                },
                viewVisible: false,
                currentTime: '',
                currentCountrys: ''
            };
        },
        watch: {
            $route(to, from) {
                if (this.type === '2' && to.query.activeName === 'time') {
                    this.init();
                }
            }
        },
        created() {
            this.init();
        },
        methods: {
            init() {
                const { pageNo, pageSize, activeName } = this.$route.query;
                const params = {
                    pageNo: 1,
                    pageSize: 15
                };
                if (pageNo && pageSize) {
                    if (this.type === '2' && activeName === 'time') {
                        params.pageNo = Number(pageNo);
                        params.pageSize = Number(pageSize);
                    }
                }
                this.getList(params);
            },
            async getList(params) {
                this.loading = true;
                const reParams = { ...params, id: this.id };
                const { status, data } = await shippingTimeGet.http({
                    showError: true,
                    params: reParams
                });
                if (status === 0 && data) {
                    const { list, totalCount } = data;
                    this.updateSearch(params);
                    this.list = list;
                    this.pagination.totalCount = totalCount;
                }
                this.$nextTick(() => {
                    this.loading = false;
                });
            },
            // 搜索条件赋值
            updateSearch(params) {
                this.pagination.pageNo = params.pageNo;
                this.pagination.pageSize = params.pageSize;
            },
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
            },
            viewMore(row) {
                this.currentTime = `${row.minDay}-${row.maxDay}`;
                const currentCountrys = [];
                this.countrys.forEach((item) => {
                    if (row.countryCodes.includes(item.countryCode)) {
                        currentCountrys.push(item.countryName);
                    }
                });
                this.currentCountrys = currentCountrys.join('，');
                this.viewVisible = true;
            },
            turnUrl() {
                this.$nextTick(() => {
                    const { pageNo, pageSize } = this.pagination;
                    this.$router.push({
                        name: 'shippingDetail',
                        query: {
                            ...this.$route.query,
                            pageNo,
                            pageSize,
                            ...(this.type === '2' ? { activeName: 'time' } : {})
                        }
                    });
                });
            },
        }
    };
</script>

<style module>
@import 'variable.css';
.table {
    :global .el-table {
        border: 1px var(--border-color-lighter) solid;
    }
}
.dialogTitle {
    margin-bottom: 10px;
}
.dailogType {
    margin-bottom: 20px;
}
</style>
