<template>
    <div :style="{ margin: '25px 0' }">
        <h3 :class="$style.title">{{ $t('logistics.verify.countryTitle') }}</h3>
        <el-row>
            <el-col :span="12">
                <div :class="$style.searchInput">
                    <span>{{ $t('logistics.verify.countrySearch') }}：</span>
                    <el-input v-model="countryName" />
                    <el-button type="primary" @click="search">{{ $t('logistics.search') }}</el-button>
                </div>
            </el-col>
            <el-col :span="12" :style="{ textAlign: 'right' }">
                <el-button :class="$style.letter" type="text" @click="letterSearch(false)">{{ $t('logistics.allText') }}</el-button>
                <el-button
                    v-for="letter in letters"
                    :key="letter"
                    :class="$style.letter"
                    type="text"
                    @click="letterSearch(letter)"
                >
                    {{ letter }}
                </el-button>
            </el-col>
        </el-row>
        <el-checkbox v-model="checkedAll" :class="$style.checkAll" @change="changeCheckBox">{{ $t('logistics.tpl.selectAll') }}</el-checkbox>
        <div :class="$style.checkContainer">
            <div v-for="country in countrysList" :key="country.countryCode" :class="$style.checkItem">
                <el-checkbox
                    v-model="country.checked"
                    :disabled="country.disabled"
                    :title="country.countryName"
                    @change="changeSingleCheckBox($event, country)"
                >{{ country.countryName }}</el-checkbox>
            </div>
        </div>
        <div v-if="selectCountrys.length > 0" :class="$style.selectedCountrys">
            <p :class="$style.selectedCountrysTitle">{{ $t('logistics.tpl.selectedCoun') }}：</p>
            <el-popover
                :content="selectCountrys.map(item => handledCountrys[item]).join(' / ')"
                :popper-class="$style.popper"
                placement="bottom"
                width="840"
                trigger="hover"
            >
                <p slot="reference" :class="$style.selectedCountrysList">{{ selectCountrys.map(item => handledCountrys[item]).join('/') }}</p>
            </el-popover>
        </div>
    </div>
</template>

<script>
    const letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
                     'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
    export default {
        name: 'CountrySelect',
        props: {
            excludeCountrys: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            selectedCountrys: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            countrys: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            handledCountrys: {
                type: Object,
                required: true,
                default() {
                    return {};
                }
            }
        },
        data() {
            return {
                countryName: '',
                letters,
                checkedAll: false,
                tmpCountrysList: [],
                countrysList: [],
                selectCountrys: []
            };
        },
        watch: {
            // 初始化选中的国家
            selectedCountrys(value) {
                this.selectCountrys = JSON.parse(JSON.stringify(value));
            },
            // 监听可选国家的变化
            countrys(val) {
                this.tmpCountrysList = this.getCountrysList(val);
                this.countrysList = this.tmpCountrysList;
            },
            // 监听排除国家编码的变化，从而需要更新可发国家的变化
            excludeCountrys() {
                this.checkedAll = false;
                this.tmpCountrysList = this.getCountrysList(this.countrys);
                this.countrysList = this.tmpCountrysList;
                this.$nextTick(() => {
                    this.updateSelectCountrys();
                });
            }
        },
        methods: {
            getCountrysList(countrys) {
                return countrys.map((item, index) => {
                    let disabled = false;
                    let checked = false;
                    const i = this.excludeCountrys.findIndex(it => it === item.countryCode);
                    const s = this.selectedCountrys.findIndex(it => it === item.countryCode);
                    if (i > -1) {
                        disabled = true;
                    }
                    if (s > -1) {
                        checked = true;
                    }
                    return {
                        ...item,
                        disabled,
                        checked
                    };
                });
            },
            // 关键字搜索
            search() {
                this.countrysList = this.tmpCountrysList.filter(
                    item => (item.countryName.toLocaleLowerCase().includes(this.countryName.toLocaleLowerCase()))
                );
                this.$nextTick(() => {
                    this.computedCheckedCountry(this.countrysList);
                });
            },
            // 字母模糊搜索
            letterSearch(letter) {
                this.countryName = '';
                if (!letter) {
                    this.countrysList = this.tmpCountrysList;
                } else {
                    this.countrysList = this.tmpCountrysList.filter(
                        item => item.countryName.toLocaleLowerCase().charAt(0) === letter.toLocaleLowerCase()
                    );
                }
                this.$nextTick(() => {
                    this.computedCheckedCountry(this.countrysList);
                });
            },
            // 选中全部
            changeCheckBox(value) {
                const countrysList = Array.from(this.countrysList);
                countrysList.forEach((item) => {
                    if (!item.disabled) {
                        item.checked = value;
                    }
                });
                this.countrysList = countrysList;
                this.updateSelectCountrys();
            },
            // 全量更新最新选中的国家
            updateSelectCountrys() {
                this.selectCountrys = this.tmpCountrysList.filter(item => !item.disabled && item.checked).map(item => item.countryCode);
            },
            // 单个checkbox改变更新选中国家
            changeSingleCheckBox(val, country) {
                const index = this.selectCountrys.findIndex(item => item === country.countryCode);
                if (index > -1 && !val) {
                    this.selectCountrys.splice(index, 1);
                }
                if (index === -1) {
                    this.selectCountrys.push(country.countryCode);
                    // this.selectCountrys.sort();
                }
            },
            // 计算选中国家，判断全部checkbox是否选中
            computedCheckedCountry(countrysList) {
                const filterCountrys = countrysList.filter(item => !item.disabled);
                if (filterCountrys.length !== 0 && filterCountrys.length === filterCountrys.filter(item => item.checked).length) {
                    this.checkedAll = true;
                } else {
                    this.checkedAll = false;
                }
            },
            // 重置配置
            reset() {
                this.countryName = '';
                this.checkedAll = false;
                this.selectCountrys = [];
            },
            // 提供选中国家获取方法
            getSelectedCountrys() {
                return this.selectCountrys || [];
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';
    .searchInput span {
        font-size: var(--font-size-base);
    }
    .searchInput {
        :global .el-input {
            width: 200px;
        }
        :global .el-button {
            width: 100px;
            margin-left: 20px;
        }
    }
    .letter {
        font-size: 12px;
        margin-left: 3px!important;
    }
    .title {
        margin-bottom: 20px;
    }
    .checkContainer {
        height: 166px;
        overflow: auto;
        border: 1px solid var(--border-color-lighter);
    }
    .checkAll {
        margin: 15px 0;
    }
    .checkItem {
        width: 20%;
        float: left;
        padding: 2px 0;
        :global .el-checkbox__label {
            max-width: 150px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            vertical-align: middle;
        }
    }
    .selectedCountrys {
        margin-top: 12px;
        padding: 20px;
        background-color: #eaf4fe;
        border: 1px #d5e8fc solid;
    }
    .selectedCountrysList {
        @extend %nowrap;
        margin-top: 5px;
    }
    .popper {
        word-break: break-all;
        word-wrap: break-word;
    }
</style>
