<template>
    <div>
        <!-- 运输时效配置 -->
        <template v-if="originalTimeInfoList.length > 0">
            <h3 :class="$style.title">{{ $t('logistics.tpl.added') }}</h3>
            <el-row
                v-for="(timeInfo, index) in originalTimeInfoList"
                :key="index"
                :class="[$style.row, index === selectedIndex ? $style.selected : '']"
            >
                <el-col :span="21">
                    <el-popover
                        :popper-class="$style.popper"
                        :offset="50"
                        placement="bottom"
                        width="840"
                        trigger="hover"
                    >
                        <div :class="timeInfo.closeCountry && timeInfo.closeCountry.length > 0 ? $style.additionalCountries : ''">
                            <h3>已添加国家：</h3>
                            <p>
                                <span>{{ (timeInfo.countryList || []).map(item => allCountrys[item]).join(', ') }}</span><span
                                    v-if="timeInfo.countryList &&
                                        timeInfo.countryList.length > 0 &&
                                        timeInfo.closeCountry &&
                                    timeInfo.closeCountry.length > 0">, </span>
                                <span :class="$style.closedCountry">
                                    {{ (timeInfo.closeCountry || []).map(item => allCountrys[item]).join(', ') }}
                                </span>
                            </p>
                        </div>
                        <div v-if="timeInfo.closeCountry && timeInfo.closeCountry.length > 0">
                            <h3>其中系统关闭国家：</h3>
                            <p>{{ (timeInfo.closeCountry || []).map(item => allCountrys[item]).join(', ') }}</p>
                        </div>
                        <div
                            slot="reference"
                            :class="$style.countryCol"
                        >
                            <span>{{ (timeInfo.countryList || []).map(item => allCountrys[item]).join(', ') }}</span><span
                                v-if="timeInfo.countryList &&
                                    timeInfo.countryList.length > 0 &&
                                    timeInfo.closeCountry &&
                                timeInfo.closeCountry.length > 0">, </span>
                            <span :class="$style.closedCountryAsh">
                                {{ (timeInfo.closeCountry || []).map(item => allCountrys[item]).join(', ') }}
                            </span>
                        </div>
                    </el-popover>
                </el-col>
                <el-col :span="3">
                    <el-button v-if="!rule.isClose" type="text" @click="editRule(timeInfo, index)">{{ $t('logistics.edit') }}</el-button>
                    <el-button type="text" @click="deleteRule(timeInfo, index)">{{ $t('logistics.delete') }}</el-button>
                </el-col>
            </el-row>
        </template>
        <div v-show="isExpand">
            <country-select
                ref="countrySelect"
                :countrys="countrys"
                :exclude-countrys="excludeCountrys"
                :selected-countrys="selectedCountrys"
                :handled-countrys="handledCountrys"
            />
            <h3 :class="$style.title">{{ $t('logistics.tpl.timeSet') }}</h3>
            <el-form ref="form" :model="form" :class="$style.ruleForm" label-suffix=":" label-width="120px" label-position="left">
                <el-form-item :label="$t('logistics.tpl.expectedTime')">
                    <el-form-item
                        :rules="[
                            { validator: validateInteger.bind(this, 100) },
                            { validator: validateTimeStartRange}
                        ]"
                        :style="{ 'display': 'inline-block' }"
                        prop="minDay"
                    >
                        <el-input v-model="form.minDay" :style="{ 'width': '120px' }"></el-input>
                    </el-form-item>
                    <span>-</span>
                    <el-form-item
                        :rules="[
                            { validator: validateInteger.bind(this, 100) },
                            { validator: validateTimeEndRange }
                        ]"
                        :style="{ 'display': 'inline-block' }"
                        prop="maxDay"
                    >
                        <el-input v-model="form.maxDay" :style="{ 'width': '120px' }"></el-input>
                    </el-form-item>
                    <span :class="$style.tip">{{ $t('logistics.tpl.timeTip') }}</span>
                </el-form-item>
                <el-form-item :class="$style.addBtn" label-width="0px">
                    <el-button :style="{ marginLeft: '30px' }" @click="cancelOperate">{{ $t('logistics.cancel.text') }}</el-button>
                    <el-button type="primary" @click="sureOperate">{{ $t('logistics.tpl.sureAdd') }}</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div v-show="!isExpand">
            <el-button v-if="!rule.isClose" :class="$style.expandLink" @click="isExpand = true">
                <i class="el-icon-circle-plus-outline"></i>
                <span>{{ $t('logistics.tpl.addTimeSet') }}</span>
            </el-button>
            <div :class="$style.addBtn">
                <el-button :style="{ marginLeft: '30px' }" @click="closeModal">{{ $t('logistics.cancel.text') }}</el-button>
                <el-button type="primary" @click="save">{{ $t('logistics.save.text') }}</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    import CountrySelect from '@logistics/components/CountrySelect';

    export default {
        name: 'CustomTimeRule',
        components: {
            'country-select': CountrySelect
        },
        props: {
            // 规则
            rule: {
                type: Object,
                required: true
            },
            // 模板类型
            type: {
                type: [String, Number],
                required: true
            },
            // 可发国家
            countrys: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            // 所有国家
            countryslist: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            // 是否显示，监控每次打开都执行initData函数
            isshow: {
                type: Boolean,
                required: true
            },
        },
        data() {
            const list = JSON.parse(JSON.stringify(this.rule.timeInfoList));
            return {
                form: {
                    index: '',
                    minDay: '', // 预计运输时间最小值
                    maxDay: '', // 预计运输时间最大值
                },
                selectedCountrys: [],
                selectedIndex: '',
                originalTimeInfoList: list,
                isExpand: list.length === 0
            };
        },
        computed: {

            // 运输时效列表
            timeInfoList() {
                if (this.selectedIndex > -1 && this.selectedCountrys.length > 0) {
                    return this.originalTimeInfoList.filter((item, index) => this.selectedIndex !== index);
                }
                return this.originalTimeInfoList;
            },
            // 排除的国家简码
            excludeCountrys() {
                const countryCodes = [];
                // 运输时效
                if (this.timeInfoList && this.timeInfoList.length > 0) {
                    this.timeInfoList.forEach((item) => {
                        item.countryRels.forEach((country) => {
                            countryCodes.push(country.countryCode);
                        });
                    });
                }
                return countryCodes;
            },
            // 可发国家装换成对象形式
            handledCountrys() {
                const countrys = {};
                if (this.countrys && this.countrys.length > 0) {
                    this.countrys.forEach((item) => {
                        countrys[item.countryCode] = item.countryName;
                    });
                }
                return countrys;
            },

            // 国家换成对象形式
            allCountrys() {
                const countryList = {};
                if (this.countryslist && this.countryslist.length > 0) {
                    this.countryslist.forEach((item) => {
                        countryList[item.countryCode] = item.countryName;
                    });
                }
                return countryList;
            }
        },
        watch: {
            'rule.timeInfoList': {
                deep: true,
                handler(val) {
                    this.originalTimeInfoList = JSON.parse(JSON.stringify(val));
                    if (this.originalTimeInfoList.length === 0) {
                        this.isExpand = true;
                    }
                }
            },
            isshow: {
                handler(val) {
                    this.initData();
                }
            },
        },
        created() {
            this.initData();
        },
        methods: {
            // 初始把已选中的国家简码提取出来
            async initData() {
                let countryList = [];
                let closeCountry = [];
                const isCopy = this.$route.query.copy;
                this.originalTimeInfoList.forEach((item) => {
                    countryList = [];
                    closeCountry = [];
                    item.countryRels.forEach((country) => {
                        if (country.status === 1) {
                            countryList.push(country.countryCode);
                        }

                        if (country.status === 0 && !isCopy) {
                            closeCountry.push(country.countryCode);
                        }
                    });
                    item.countryList = countryList;
                    item.closeCountry = closeCountry;
                });
            },
            // 校验-整数
            validateInteger(max, rule, value, callback) {
                const pattern = /^[1-9]\d*$/;
                if (!pattern.test(value)) {
                    return callback(new Error(this.$t('logistics.verify.int')));
                }
                if (max && Number(value) > Number(max)) {
                    return callback(new Error(this.$t('logistics.verify.max', [100])));
                }
                return callback();
            },
            // 校验-预计运输时间A必须<B
            validateTimeStartRange(rule, value, callback) {
                if (value === '') {
                    return callback(this.$t('logistics.tpl.write'));
                }
                if (this.form.maxDay !== '') {
                    this.$refs.form.validateField('maxDay');
                }
                return callback();
            },
            validateTimeEndRange(rule, value, callback) {
                if (value === '') {
                    return callback(this.$t('logistics.tpl.write'));
                }
                if (Number(value) <= Number(this.form.minDay)) {
                    return callback(new Error(' '));
                }
                return callback();
            },
            // 确认添加
            sureOperate() {
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        const countryList = this.$refs.countrySelect.getSelectedCountrys();
                        if (countryList.length === 0) {
                            return this.$message({
                                message: this.$t('logistics.verify.country'),
                                type: 'error'
                            });
                        }
                        const originalTimeInfo = {};
                        // 获取已选中的国家
                        originalTimeInfo.countryRels = [];
                        countryList.forEach((item) => {
                            originalTimeInfo.countryRels.push(
                                {
                                    countryCnName: '',
                                    countryCode: item,
                                    countryName: '',
                                    status: 1,
                                    type: ''
                                }
                            );
                        });
                        const { minDay, maxDay } = this.form;
                        originalTimeInfo.minDay = minDay;
                        originalTimeInfo.maxDay = maxDay;
                        const newOriginalTimeInfo = JSON.parse(JSON.stringify(originalTimeInfo));
                        if (this.form.index) {
                            // 编辑情况
                            this.originalTimeInfoList.splice(Number(this.form.index), 1, newOriginalTimeInfo);
                        } else {
                            // 新增情况
                            this.originalTimeInfoList.push(newOriginalTimeInfo);
                        }
                        this.$nextTick(() => {
                            this.cancelOperate();
                        });
                        return true;
                    }
                    console.log('error submit!!');
                    return false;
                });
            },
            // 取消添加或编辑运费规则
            cancelOperate() {
                this.isExpand = false;
                this.selectedIndex = '';
                this.selectedCountrys = [];
                this.form.index = '';
                this.$refs.form.clearValidate();
                this.$refs.form.resetFields();
                // this.$refs.countrySelect.reset();
                this.initData();
            },
            // 关闭弹框
            closeModal() {
                this.$emit('close');
            },
            // 确认提交
            save() {
                const newRule = JSON.parse(JSON.stringify(this.rule));
                newRule.timeInfoList = this.originalTimeInfoList;
                this.$emit('change', newRule);
            },
            // 编辑
            editRule(rule, index) {
                this.isExpand = true;
                this.selectedIndex = index;
                this.selectedCountrys = rule.countryList;
                this.form.index = String(index);
                this.form.minDay = rule.minDay;
                this.form.maxDay = rule.maxDay;
            },
            // 删除
            deleteRule(rule, index) {
                this.originalTimeInfoList.splice(index, 1);
                if (index === this.selectedIndex) {
                    this.selectedIndex = '';
                    this.selectedCountrys = [];
                    // this.$refs.countrySelect.reset();
                }
            },
            // 重置data属性
            resetData() {
                this.$nextTick(() => {
                    this.isExpand = false;
                    this.$refs.form.clearValidate();
                    this.$refs.form.resetFields();
                    this.selectedIndex = '';
                    this.selectedCountrys = [];
                    this.originalTimeInfoList = JSON.parse(JSON.stringify(this.rule.timeInfoList));
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';
    .title {
        margin-bottom: 20px;
    }
    .row {
        border: 1px solid var(--border-color-lighter);
        margin-bottom: 12px;
        :global .el-col {
            height: 40px;
            line-height: 40px;
        }
    }
    .selected {
        :global .el-button:first-child {
            color: var(--color-success);
        }
    }
    .countryCol {
        padding-left: 10px;
        @extend %nowrap;
    }
    .popper {
        word-break: break-all;
        word-wrap: break-word;
    }
    .ruleForm {
        padding: 20px 0;
    }
    .tip {
        margin-left: 30px;
        color: var(--color-danger);
    }
    .addBtn {
        text-align: center;
        margin-top: 40px;
        margin-bottom: 0;
        :global .el-button {
            width: 120px;
        }
    }
    .expandLink {
        margin-bottom: 20px;
    }
    .additionalCountries{
        border-bottom: 2px solid var(--border-color-lighter);
        padding-bottom: 10px;
        margin-bottom: 10px;
    }
    .closedCountry{
        color: var(--color-error);
    }
    .closedCountryAsh{
        color: var(--border-color-light);
    }
</style>
