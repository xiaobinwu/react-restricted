<template>
    <el-form
        ref="form"
        :model="value"
        :inline="config.inline"
        :label-position="config.labelPosition"
        :label-width="config.labelWidth"
        :size="config.size"
        v-bind="config.formExtra"
    >
        <slot name="prefix" />
        <!-- 组件内不能直接修改props，所以使用转发input事件 -->
        <dynamic-form-item
            v-for="item in config.formList"
            v-if="value[item.key]!==undefined"
            :ref="item.key"
            :key="item.key"
            :item="item"
            :value="value[item.key]"
            @input="handleFormItem($event, item.key)" />
        <slot name="suffix" />
        <el-form-item>
            <el-button
                :style="{ width: '120px' }"
                :icon="config.btnIcon"
                type="primary"
                @click="onSubmit"
            >
                {{ config.btnText || $t('logistics.save.text') }}
            </el-button>
        </el-form-item>
    </el-form>
</template>

<script>
    import DynamicFormItem from './DynamicFormItem';

    export default {
        name: 'DynamicForm',
        components: {
            'dynamic-form-item': DynamicFormItem
        },
        props: {
            config: {
                type: Object,
                required: true
            },
            value: {
                type: Object,
                required: true
            }
        },
        mounted() {
            this.setDefaultValue();
        },
        methods: {
            // 获取表单ref
            getFormRef() {
                return this.$refs.form;
            },
            // 设置默认值
            setDefaultValue() {
                const formData = { ...this.value };
                this.config.formList.forEach(({ key, value }) => {
                    if (formData[key] === undefined || formData[key] === null) {
                        formData[key] = value;
                    }
                });
                this.$emit('input', formData);
            },
            // 更新表单项的值
            handleFormItem(val, key) {
                this.$emit('input', { ...this.value, [key]: val });
            },
            // 表单项进行重置
            resetField(key) {
                const formItemRef = this.$refs[key].getRef();
                formItemRef.resetField();
            },
            // 重置所有表单项
            resetFields() {
                this.$refs.form.resetFields();
            },
            // 清除验证
            clearValidate() {
                this.$refs.form.clearValidate();
            },
            // 表单提交
            onSubmit() {
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        this.$emit('success');
                    } else {
                        console.log('error submit!!');
                    }
                });
            }
        }
    };
</script>

<style module>

</style>
