import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import logisticsLang from '@/lang/logistics';
import router from './router';

(async () => {
    const logisticsLangInstance = await lang({ local: logisticsLang, moduleName: 'logistics' });
    app({ lang: logisticsLangInstance, router });
})();
