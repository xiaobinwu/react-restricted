<template>
    <div :class="$style.container">
        <el-alert :class="$style.alert">
            <h2 :class="$style.title">{{ $t('logistics.tpl.title1') }}</h2>
            <p :class="$style.dec">
                {{ $t('logistics.tpl.dec1') }}
                <a href="javascript:;;" @click="openLogisticsModal">【{{ $t('logistics.tpl.link1') }}】</a>
            </p>
            <h2 :class="$style.title">{{ $t('logistics.tpl.title2') }}</h2>
            <p :class="$style.dec">
                <a href="javascript:;;" @click="applyVisible=true">{{ $t('logistics.tpl.link2') }}</a>
            </p>
            <h2 :class="$style.title">{{ $t('logistics.tpl.title3') }}</h2>
            <p :class="$style.dec">
                {{ $t('logistics.tpl.dec3') }}
                <a href="javascript:;;">{{ $t('logistics.tpl.link3') }}</a>
            </p>
            <p :class="$style.tip">{{ $t('logistics.tpl.tip') }}</p>
        </el-alert>
        <el-dialog
            :visible.sync="logisticsVisible"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            :title="$t('logistics.tpl.link1')"
            width="1050px"
        >
            <dynamic-form
                ref="logisticsForm"
                :config="logisticsFormConfig"
                v-model="logisticsForm"
                @success="searchLogistics"
            />

            <paginated-table
                v-loading="logisticsLoading"
                :data="logisticsList"
                :columns="logisticsColumns"
                :attrs="logisticsAttrs"
                :pagination="logisticsPagination"
                :class="$style.table"
                @pagesize-change="changeLogisticsPageSize"
                @page-change="changeLogisticsPage"
            >
                <template
                    slot="aging"
                    slot-scope="scope"
                >
                    {{ scope.row.minDay }} - {{ scope.row.maxDay }}
                </template>
            </paginated-table>
        </el-dialog>
        <el-dialog
            :visible.sync="applyVisible"
            :title="$t('logistics.logis.title')"
            width="560px"
        >
            {{ $t('logistics.logis.content') }}
        </el-dialog>
        <el-dialog
            :visible.sync="noDelVisible"
            :title="$t('logistics.tpl.delTip')"
            width="560px"
        >
            <p>{{ $t('logistics.tpl.delContent') }}</p>
        </el-dialog>
        <div :class="$style.content">
            <el-row :style="{ margin: '30px 0' }">
                <el-col :span="21">
                    <dynamic-form
                        ref="form"
                        :config="formConfig"
                        v-model="form"
                        @success="search"
                    />
                </el-col>
                <el-col :span="3" :style="{ textAlign: 'right' }">
                    <router-link :to="{ name: 'shippingOperate' }">
                        <el-button type="primary" plain>
                            {{ $t('logistics.tpl.add') }}
                        </el-button>
                    </router-link>
                </el-col>
            </el-row>
            <paginated-table
                v-loading="loading"
                :data="list"
                :columns="columns"
                :attrs="attrs"
                :pagination="pagination"
                :class="$style.table"
                @pagesize-change="changePageSize"
                @page-change="changePage"
            >
                <template
                    slot="name"
                    slot-scope="scope"
                >
                    <router-link :to="{
                        name: 'shippingDetail',
                        query: { id: scope.row.id, type: scope.row.type, name: scope.row.name } }">
                        <div :class="$style.name" :title="scope.row.name">{{ scope.row.name }}</div>
                    </router-link>
                </template>
                <template
                    slot="operate"
                    slot-scope="scope"
                >
                    <div :class="$style.btn">
                        <router-link :to="{ name: 'shippingOperate', query: { id: scope.row.id, type: scope.row.type } }">
                            <el-button type="text">
                                {{ $t('logistics.edit') }}
                            </el-button>
                        </router-link>
                    </div>
                    <div :class="$style.btn">
                        <router-link :to="{ name: 'shippingOperate', query: { id: scope.row.id, type: scope.row.type, copy: true } }">
                            <el-button
                                type="text"
                            >{{ $t('logistics.copy') }}</el-button>
                        </router-link>
                    </div>
                    <div :class="$style.btn">
                        <el-button
                            :class="$style.delete"
                            type="text"
                            @click="deleteShipping(scope.row)"
                        >{{ $t('logistics.delete') }}</el-button>
                    </div>
                </template>
                <template
                    slot="rule"
                    slot-scope="scope"
                >
                    <div v-html="getRules(scope.row)" />
                </template>
                <template
                    slot="type"
                    slot-scope="scope"
                >
                    {{ tplTypesObj[scope.row.type] }}
                </template>
            </paginated-table>
        </div>
    </div>
</template>

<script>
    import {
        shippingListGet,
        logisticsListGet,
        feeTypesGet,
        levelsGet,
        shippingDelete,
        shippingTypesGet
    } from '@logistics/services/logisticsServices';
    import DynamicForm from '@logistics/components/DynamicForm';
    import PaginatedTable from '@logistics/components/PaginatedTable';

    export default {
        name: 'ShippingList',
        components: {
            'dynamic-form': DynamicForm,
            'paginated-table': PaginatedTable
        },
        data() {
            return {
                loading: false,
                tplTypes: [],
                tplTypesObj: {},
                // 列表配置
                list: [],
                columns: [{
                    prop: 'id',
                    label: 'ID',
                    align: 'center',
                    'header-align': 'center'
                }, {
                    prop: 'name',
                    label: this.$t('logistics.tplList.name'),
                    align: 'center',
                    'header-align': 'center',
                    'min-width': '100px',
                    scope: true
                }, {
                    prop: 'type',
                    label: this.$t('logistics.tplList.type'),
                    align: 'center',
                    'header-align': 'center',
                    scope: true
                }, {
                    prop: 'rule',
                    label: this.$t('logistics.tplList.rule'),
                    'min-width': '200px',
                    scope: true
                }, {
                    prop: 'operate',
                    label: this.$t('logistics.operate.text'),
                    width: '80px',
                    align: 'center',
                    'header-align': 'center',
                    scope: true
                }],
                attrs: {
                    stripe: true
                },
                pagination: {
                    pageNo: 1,
                    pageSize: 15,
                    totalCount: 0
                },
                form: {
                    name: '',
                    type: ''
                },
                types: [],
                levels: [],
                applyVisible: false,
                logisticsVisible: false,
                noDelVisible: false,
                logisticsList: [],
                logisticsLoading: false,
                // 指定物流table配置
                logisticsPagination: {
                    pageNo: 1,
                    pageSize: 15,
                    totalCount: 0
                },
                logisticsColumns: [{
                    prop: 'cnName',
                    label: this.$t('logistics.logisList.name')
                }, {
                    prop: 'levelName',
                    label: this.$t('logistics.logisList.level')
                }, {
                    prop: 'aging',
                    label: this.$t('logistics.logisList.aging'),
                    scope: true
                }, {
                    prop: 'url',
                    label: this.$t('logistics.logisList.url')
                }, {
                    prop: 'remark',
                    label: this.$t('logistics.logisList.remark')
                }],
                logisticsAttrs: {
                    stripe: true
                },
                // 指定物流表单配置
                logisticsForm: {
                    searchType: '1',
                    searchKey: '',
                    groupId: ''
                }
            };
        },
        computed: {
            // 物流方式表单搜索配置
            logisticsFormConfig() {
                return {
                    inline: true,
                    labelWidth: '100px',
                    btnText: this.$t('logistics.search'),
                    btnIcon: 'el-icon-search',
                    formList: [
                        {
                            key: 'searchKey',
                            type: 'input',
                            value: '',
                            subtype: 'text',
                            formItem: {
                                label: this.$t('logistics.logisSearch.name')
                            },
                            formComponent: {
                                placeholder: this.$t('logistics.tplSearch.place1'),
                            }
                        },
                        {
                            type: 'select',
                            value: '',
                            key: 'groupId',
                            formItem: {
                                label: this.$t('logistics.logisSearch.level')
                            },
                            formComponent: {
                                options: this.levels,
                            }
                        }
                    ]
                };
            },
            // 列表搜索表单配置
            formConfig() {
                return {
                    inline: true,
                    labelWidth: '100px',
                    btnText: this.$t('logistics.search'),
                    formList: [
                        {
                            key: 'name',
                            type: 'input',
                            value: '',
                            subtype: 'text',
                            formItem: {
                                label: this.$t('logistics.tplSearch.name')
                            },
                            formComponent: {
                                placeholder: this.$t('logistics.tplSearch.place1'),
                            }
                        },
                        {
                            type: 'select',
                            value: '',
                            key: 'type',
                            formItem: {
                                label: this.$t('logistics.tplSearch.type')
                            },
                            formComponent: {
                                options: [{
                                    value: '',
                                    label: this.$t('logistics.all')
                                }, ...this.tplTypes],
                                placeholder: this.$t('logistics.tplSearch.place2'),
                            }
                        }
                    ]
                };
            }
        },
        watch: {
            $route(to, from) {
                this.init();
            }
        },
        mounted() {
            this.getTplTypes();
            this.getTypes();
            this.getLevels();
            this.init();
        },
        methods: {
            // query驱动数据变化
            init() {
                const {
                    pageNo,
                    pageSize,
                    name,
                    type
                } = this.$route.query;
                const params = {};
                params.pageNo = Number(pageNo) || 1;
                params.pageSize = Number(pageSize) || 15;
                if (name) {
                    params.name = name;
                }
                if (type) {
                    params.type = Number(type);
                }
                this.getList(params);
            },
            // 获取数据
            async getList(params) {
                this.loading = true;
                const { status, data } = await shippingListGet.http({
                    showError: true,
                    params
                });
                if (status === 0 && data) {
                    const { list, totalCount } = data;
                    list.forEach((item, index) => {
                        const { totalInfoList } = item;
                        const rules = {};
                        if (totalInfoList) {
                            totalInfoList.forEach((it, idx) => {
                                if (!rules[it.feeType]) {
                                    rules[it.feeType] = [];
                                }
                                rules[it.feeType].push(`${it.levelName}（${this.$t('logistics.tpl.coun', [it.num])}）`);
                            });
                        }
                        item.rules = rules;
                    });
                    this.updateSearch(params);
                    this.list = list;
                    this.pagination.totalCount = totalCount;
                }
                this.$nextTick(() => {
                    this.loading = false;
                });
            },
            // 搜索条件赋值
            updateSearch(params) {
                this.pagination.pageNo = params.pageNo;
                this.pagination.pageSize = params.pageSize;
                this.form.name = params.name || '';
                this.form.type = params.type || '';
            },
            // 运费规则类型
            async getTypes() {
                const { status, data } = await feeTypesGet.http({
                    showError: true
                });
                if (status === 0 && data) {
                    this.types = data;
                }
            },
            // 运费模板类型
            async getTplTypes() {
                const { status, data } = await shippingTypesGet.http({
                    showError: true
                });
                const tplTypesObj = {};
                if (status === 0 && data) {
                    data.forEach((item) => {
                        tplTypesObj[item.value] = item.name;
                        item.label = item.name;
                    });
                    this.tplTypes = data;
                    this.tplTypesObj = tplTypesObj;
                }
            },
            getRules(row) {
                if (row.rules) {
                    const { rules } = row;
                    const result = this.types.map((item, index) => {
                        if (rules[item.value] && rules[item.value].length > 0) {
                            return `<p>${item.name}：${rules[item.value].join('、')}</p>`;
                        }
                        return '';
                    });
                    return result.join('');
                }
                return '';
            },
            // 物流分组级别
            async getLevels() {
                const { status, data } = await levelsGet.http({
                    showError: true,
                    params: {
                        type: 2 // 直发
                    }
                });
                if (status === 0 && data) {
                    this.levels = data.map((item, index) => ({
                        label: item.levelName,
                        value: item.groupId
                    }));
                    this.levels.unshift({
                        label: this.$t('logistics.all'),
                        value: ''
                    });
                }
            },
            openLogisticsModal() {
                this.logisticsVisible = true;
                this.searchLogistics();
            },
            async searchLogistics() {
                this.logisticsLoading = true;
                const params = { ...this.logisticsPagination, ...this.logisticsForm };
                const { status, data } = await logisticsListGet.http({
                    showError: true,
                    params
                });
                if (status === 0 && data) {
                    const { list, totalCount } = data;
                    this.logisticsList = list;
                    this.logisticsPagination.totalCount = totalCount;
                }
                this.$nextTick(() => {
                    this.logisticsLoading = false;
                });
            },
            async search() {
                this.pagination.pageNo = 1;
                this.turnUrl();
            },
            changeLogisticsPageSize(value) {
                this.logisticsPagination.pageSize = value;
                this.searchLogistics();
            },
            changeLogisticsPage(value) {
                this.logisticsPagination.pageNo = value;
                this.searchLogistics();
            },
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
            },
            deleteShipping(row) {
                // this.noDelVisible = true;
                this.$confirm(this.$t('logistics.tpl.delTip'), this.$t('logistics.tpl.delconfirm'), {
                    confirmButtonText: this.$t('logistics.sure.text'),
                    cancelButtonText: this.$t('logistics.cancel.text'),
                }).then(() => {
                    (async () => {
                        const { status } = await shippingDelete.http({
                            showError: true,
                            data: {
                                id: row.id
                            }
                        });
                        if (status === 0) {
                            this.$message({
                                type: 'success',
                                message: this.$t('logistics.delete.success')
                            });
                            this.init();
                        }
                    })();
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: this.$t('logistics.delete.fail')
                    });
                });
            },
            // url变化
            turnUrl() {
                const { name, type } = this.form;
                const { pageNo, pageSize } = this.pagination;
                this.$router.push({
                    name: 'shippingList',
                    query: {
                        pageNo,
                        pageSize,
                        name,
                        type
                    }
                });
            },
        }
    };
</script>

<style module>
@import 'variable.css';
@import 'utils.css';
.container {
    padding-bottom: 20px;
}
.alert {
    color: var(--color-text-regular);
    padding: 28px 20px;
    background-color: var(--color-white);
    :global .el-alert__closebtn {
        font-size: var(--font-size-larger);
    }
}
.dec {
    margin-bottom: 27px;
    line-height: 22px;
}
.title {
    font-weight: 400;
    color: var(--color-black);
    margin-bottom: 6px;
}
.tip {
    color: var(--color-danger);
}
.table {
    :global .el-table {
        border: 1px var(--border-color-lighter) solid;
    }
    :global .el-button+.el-button {
        margin-left: 0;
    }
}
.delete {
    color: var(--color-danger);
}
.content {
    background-color: var(--color-white);
    padding: 20px;
    margin-top: 20px;
}
.name {
    display: inline-block;
    @extend %nowrap;
}
</style>
