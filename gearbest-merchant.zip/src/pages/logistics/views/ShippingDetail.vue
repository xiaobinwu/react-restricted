<template>
    <div :class="$style.container">
        <h4 :class="$style.title">{{ name }}</h4>
        <el-tabs v-if="type === '2'" v-model="activeName" type="border-card">
            <el-tab-pane :label="$t('logistics.detail.tab1')" name="freight">
                <freight-rule-detail :id="id" :fee-types="feeTypes" :type="type" :countrys="countrys"/>
            </el-tab-pane>
            <el-tab-pane :label="$t('logistics.detail.tab2')" name="time">
                <time-rule-detail :id="id" :countrys="countrys" :type="type"/>
            </el-tab-pane>
        </el-tabs>
        <freight-rule-detail v-else-if="type === '3'" :id="id" :fee-types="feeTypes" :type="type" :countrys="countrys"/>
    </div>
</template>

<script>
    import FreightRuleDetail from '@logistics/components/FreightRuleDetail';
    import TimeRuleDetail from '@logistics/components/TimeRuleDetail';
    import {
        feeTypesGet,
        countrysListGet
    } from '@logistics/services/logisticsServices';

    export default {
        name: 'ShippingDetail',
        components: {
            'freight-rule-detail': FreightRuleDetail,
            'time-rule-detail': TimeRuleDetail
        },
        data() {
            return {
                id: '',
                type: '',
                name: '',
                feeTypes: [],
                countrys: [],
                activeName: 'freight'
            };
        },
        created() {
            const {
                id,
                type,
                name,
                activeName
            } = this.$route.query;
            this.id = id;
            this.type = String(type);
            this.name = name;
            this.activeName = activeName || 'freight';
            this.getTypes();
            this.getCountrys();
        },
        methods: {
            // 获取国家
            async getCountrys() {
                const { status, data } = await countrysListGet.http({
                    showError: true
                });
                if (status === 0) {
                    this.countrys = data;
                }
            },
            // 获取运费收费类型
            async getTypes() {
                const { status, data } = await feeTypesGet.http({
                    showError: true
                });
                if (status === 0 && data) {
                    this.feeTypes = data;
                }
            }
        }
    };
</script>

<style module>
@import 'variable.css';
.container {
    padding: 30px 20px;
    background-color: var(--color-white);
}
.title {
    font-size: var(--font-size-largest);
    color: var(--color-black);
    margin-bottom: 20px;
    font-weight: 400;
}
</style>
