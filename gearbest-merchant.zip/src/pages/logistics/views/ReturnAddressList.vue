<template>
    <div :class="$style.container">
        <h3 :class="$style.title">{{ $t('logistics.returnAddress.title') }}</h3>
        <div :class="$style.content">
            <div :class="$style.btn">
                <el-button
                    type="primary"
                    @click="openModal"
                >{{ $t('logistics.returnAddress.add') }}</el-button>
            </div>
            <paginated-table
                v-loading="loading"
                :data="list"
                :attrs="attrs"
                :columns="columns"
                :pagination="pagination"
                :class="$style.table"
                @pagesize-change="changePageSize"
                @page-change="changePage"
            >
                <template
                    slot="contacts"
                    slot-scope="scope"
                >
                    {{ scope.row.contacts }}
                    <el-tag
                        v-if="scope.row.is_default"
                        size="mini"
                    >
                        {{ $t('logistics.default.text') }}
                    </el-tag>
                </template>
                <template
                    slot="operate"
                    slot-scope="scope"
                >
                    <el-button
                        type="text"
                        @click="openModal(scope.row)"
                    >{{ $t('logistics.edit') }}</el-button>
                    <el-button
                        :class="$style.delete"
                        type="text"
                        @click="rowDelete(scope.row)"
                    >{{ $t('logistics.delete') }}</el-button>
                </template>
            </paginated-table>
            <el-dialog
                :visible.sync="visible"
                :title="statusText"
                width="880px"
            >
                <el-form
                    ref="form"
                    :model="form"
                    label-position="right"
                    label-width="100px"
                >
                    <el-form-item
                        :label="$t('logistics.returnAddress.name')"
                        :rules="[{ required: true, message: $t('logistics.returnAddress.formName'), trigger: 'blur' }]"
                        prop="name"
                    >
                        <el-input v-model="form.name" :style="{ width: '300px' }" :placeholder="$t('logistics.returnAddress.formName')"/>
                    </el-form-item>
                    <el-form-item
                        :label="$t('logistics.returnAddress.listContacts')"
                        :rules="[{ required: true, message: $t('logistics.returnAddress.formContacts'), trigger: 'blur' }]"
                        prop="contacts"
                    >
                        <el-input v-model="form.contacts" :style="{ width: '300px' }" :placeholder="$t('logistics.returnAddress.formContacts')"/>
                    </el-form-item>
                    <el-form-item
                        :label="$t('logistics.returnAddress.listLoaction')"
                        :rules="[{ required: true, validator: validateAddress }]"
                        prop="cascadedAddress"
                    >
                        <address-cascaded-select v-model="form.cascadedAddress" />
                    </el-form-item>
                    <el-form-item
                        :label="$t('logistics.returnAddress.listAddress')"
                        :rules="[{ required: true, message: $t('logistics.returnAddress.formAddress'), trigger: 'blur' }]"
                        prop="address_detail"
                    >
                        <el-input v-model="form.address_detail" :style="{ width: '300px' }" :placeholder="$t('logistics.returnAddress.formAddress')"/>
                    </el-form-item>
                    <!-- <el-form-item
                        :label="$t('logistics.returnAddress.listPhone')"
                        :rules="[
                            { required: true, message: $t('logistics.returnAddress.formPhone'), trigger: 'blur' },
                            { validator: validatePhone }
                        ]"
                        prop="telephone"
                    >
                        <el-input v-model="form.telephone" :style="{ width: '300px' }" :placeholder="$t('logistics.returnAddress.formPhonetip')"/>
                    </el-form-item> -->
                    <el-form-item
                        :label="$t('logistics.returnAddress.listPhone')"
                        :rules="[
                            { required: true, message: $t('logistics.returnAddress.formPhone'), trigger: 'blur' },
                            { validator: validatePhone }
                        ]"
                        :show-message="phoneRules"
                        prop="telephone">
                        <el-input
                            v-model="form.telephone"
                            :placeholder="$t('logistics.returnAddress.formPhonetip')"
                            :style="{ width: '300px' }"
                            :class="$style.telephone">
                            <el-form-item
                                slot="prepend"
                                :rules="[
                                    { required: true, message: $t('logistics.returnAddress.formPhoneCode'), trigger: 'blur' },
                                    { validator: validatePhoneCode }
                                ]"
                                :show-message="phoneCodeRules"
                                prop="telephoneCode">
                                <span> + </span>
                                <el-input
                                    :class="$style.telephoneCode"
                                    v-model="form.telephoneCode"
                                    :placeholder="$t('logistics.returnAddress.formPhonecodetip')"
                                    maxlength="4">
                                </el-input>
                                <!-- <el-select
                                    :value="countryCode"
                                    :placeholder="$t('user.please.choose')"
                                    clearable
                                    filterable
                                    @input="changeAddress($event, 'countryCode')"
                                    @change="getProvince($event)"
                                >
                                    <el-option
                                        v-for="(item, index) in countrys"
                                        :key="index"
                                        :value="item.countryCode"
                                        :label="positions === 'CN' ? item.countryCnName : item.countryName"
                                    />
                                </el-select> -->
                            </el-form-item>
                        </el-input>
                    </el-form-item>


                    <el-form-item
                        :label="$t('logistics.returnAddress.listPostcode')"
                        :rules="[
                            { required: true, message: $t('logistics.returnAddress.formCode'), trigger: 'blur' },
                        ]"
                        prop="postcode"
                    >
                        <el-input v-model="form.postcode" :style="{ width: '300px' }" />
                    </el-form-item>
                    <el-form-item
                        :label="$t('logistics.returnAddress.listCompany')"
                        prop="company_name"
                    >
                        <el-input v-model="form.company_name" :style="{ width: '300px' }" />
                    </el-form-item>
                    <el-form-item
                        :label="$t('logistics.returnAddress.listRemark')"
                        prop="remark"
                    >
                        <el-input v-model="form.remark" :style="{ width: '300px' }" />
                    </el-form-item>
                    <el-form-item
                        prop="is_default"
                    >
                        <el-checkbox
                            v-model="form.is_default"
                            :true-label="1"
                            :false-label="0"
                        >
                            {{ $t('logistics.returnAddress.formDefault') }}
                        </el-checkbox>
                    </el-form-item>
                    <el-form-item>
                        <el-button
                            :style="{ width: '120px', marginRight: '10px' }"
                            type="primary"
                            @click="onSubmit"
                        >
                            {{ $t('logistics.save.text') }}
                        </el-button>
                        <el-button
                            :style="{ width: '120px' }"
                            type="primary"
                            @click="visible=false"
                        >
                            {{ $t('logistics.cancel.text') }}
                        </el-button>
                    </el-form-item>
                </el-form>
            </el-dialog>
        </div>
    </div>
</template>

<script>

    import {
        returnAddressListGet,
        returnAddressAdd,
        returnAddressUpdate,
        returnAddressDelete,
    } from '@logistics/services/logisticsServices';
    import PaginatedTable from '@logistics/components/PaginatedTable';
    import AddressCascadedSelect from '@logistics/components/AddressCascadedSelect';

    export default {
        name: 'ReturnAddressList',
        components: {
            'paginated-table': PaginatedTable,
            'address-cascaded-select': AddressCascadedSelect
        },
        formDefaultOption: {
            name: '',
            contacts: '',
            address_detail: '',
            telephone: '',
            telephoneCode: '',
            postcode: '',
            company_name: '',
            remark: '',
            cascadedAddress: {
                countryCode: '',
                provinceCode: '',
                cityCode: '',
                countryName: '',
                provinceName: '',
                cityName: ''
            },
            is_default: 0
        },
        data() {
            const { formDefaultOption } = this.$options;
            return {
                loading: false,
                visible: false,
                isEdit: false,
                // 表单配置
                list: [],
                form: { ...formDefaultOption },
                // table配置
                attrs: {
                    style: 'width: 100%',
                    stripe: true
                },
                columns: [{
                    prop: 'id',
                    label: 'ID',
                    align: 'center',
                    'header-align': 'center',
                }, {
                    prop: 'contacts',
                    label: this.$t('logistics.returnAddress.listContacts'),
                    scope: true
                }, {
                    prop: 'address_detail',
                    label: this.$t('logistics.returnAddress.listAddress')
                }, {
                    prop: 'telephone',
                    label: this.$t('logistics.returnAddress.listPhone')
                }, {
                    prop: 'postcode',
                    label: this.$t('logistics.returnAddress.listPostcode')
                }, {
                    prop: 'company_name',
                    label: this.$t('logistics.returnAddress.listCompany')
                }, {
                    prop: 'operate',
                    label: this.$t('logistics.operate.text'),
                    scope: true,
                    width: '120px',
                    align: 'center',
                    'header-align': 'center',
                }],
                pagination: {
                    pageNo: 1,
                    pageSize: 15,
                    totalCount: 0
                },
                phoneCodeRules: true,
                phoneRules: false,
                countryPhoneCodes: []
            };
        },
        computed: {
            statusText() {
                return this.isEdit ? this.$t('logistics.returnAddress.edit') : this.$t('logistics.returnAddress.add');
            },
            countryCode() {
                return this.form.cascadedAddress.countryCode;
            }
        },
        watch: {
            countryCode: {
                handler(val, oldVal) {
                    if (!this.form.telephone) {
                        this.form.telephoneCode = this.countryPhoneCodes[val];
                    }
                }
            },
        },
        created() {
            this.init();
        },
        methods: {
            init() {
                const { pageNo, pageSize } = this.$route.query;
                if (pageNo && pageSize) {
                    this.pagination.pageNo = Number(pageNo);
                    this.pagination.pageSize = Number(pageSize);
                }
                this.getReturnAddressList();
            },
            validatePhoneCode(rule, value, callback) {
                if (/^(\d{1,4})$/.test(value)) {
                    this.phoneRules = true;
                    return callback();
                }
                this.phoneRules = false;
                return callback(this.$t('logistics.returnAddress.formPhoneCodeErr'));
            },
            validatePhone(rule, value, callback) {
                if (/^([\d-]{1,20})$/.test(value)) {
                    this.phoneCodeRules = true;
                    return callback();
                }
                this.phoneCodeRules = false;
                return callback(this.$t('logistics.returnAddress.formPhoneErr'));
            },
            validateAddress(rule, value, callback) {
                if (Object.keys(value).every(item => value[item])) {
                    return callback();
                }
                return callback(this.$t('logistics.returnAddress.loactionTip'));
            },

            openModal(record) {
                const that = this;
                if (record.id) {
                    record = { ...record };
                    this.isEdit = true;
                    record.cascadedAddress = {
                        countryCode: record.country_code,
                        provinceCode: record.province_code,
                        cityCode: record.city_code,
                        countryName: record.country,
                        provinceName: record.province,
                        cityName: record.city
                    };
                    const index = record.telephone.indexOf('-');
                    record.telephoneCode = record.telephone.substring(0, index);
                    record.telephone = record.telephone.substring(index + 1, record.telephone.length);
                    this.form = record;
                } else {
                    const { formDefaultOption } = this.$options;
                    this.isEdit = false;
                    this.form = { ...formDefaultOption };
                }
                this.visible = true;
                this.$nextTick(() => {
                    that.$refs.form.clearValidate();
                });
            },
            async getReturnAddressList() {
                this.loading = true;
                const { pageNo, pageSize } = this.pagination;
                const { status, data } = await returnAddressListGet.http({
                    showError: true,
                    params: {
                        pageNo,
                        pageSize
                    }
                });
                const { list, totalCount, countryPhoneCodes } = data;
                if (status === 0) {
                    this.countryPhoneCodes = countryPhoneCodes;
                    this.list = list;
                    this.pagination.totalCount = totalCount;
                }
                this.$nextTick(() => {
                    this.loading = false;
                });
            },
            async rowDelete(row) {
                this.$confirm(this.$t('logistics.returnAddress.deleteTitle'), this.$t('logistics.tip.text'), {
                    confirmButtonText: this.$t('logistics.sure.text'),
                    cancelButtonText: this.$t('logistics.cancel.text'),
                }).then(() => {
                    (async () => {
                        const { status } = await returnAddressDelete.http({
                            showError: true,
                            data: {
                                id: row.id
                            }
                        });
                        if (status === 0) {
                            this.$message({
                                type: 'success',
                                message: this.$t('logistics.delete.success')
                            });
                            this.getReturnAddressList();
                        }
                    })();
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: this.$t('logistics.delete.fail')
                    });
                });
            },
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
                this.getReturnAddressList();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
                this.getReturnAddressList();
            },
            turnUrl() {
                const { pageNo, pageSize } = this.pagination;
                this.$router.push({
                    name: 'returnAddressList',
                    query: {
                        pageNo,
                        pageSize
                    }
                });
            },
            onSubmit() {
                this.$refs.form.validate(async (valid) => {
                    if (valid) {
                        const formData = { ...this.form };
                        const fetch = this.isEdit ? returnAddressUpdate : returnAddressAdd;
                        if (!this.isEdit) {
                            delete formData.id;
                        }
                        const {
                            countryCode,
                            provinceCode,
                            cityCode,
                            countryName,
                            provinceName,
                            cityName
                        } = formData.cascadedAddress;
                        formData.country_code = countryCode;
                        formData.province_code = provinceCode;
                        formData.city_code = cityCode;
                        formData.country = countryName;
                        formData.province = provinceName;
                        formData.city = cityName;
                        formData.telephone = `${formData.telephoneCode}-${formData.telephone}`;
                        const { status, msg } = await fetch.http({
                            showError: true,
                            data: formData
                        });
                        if (status === 0) {
                            this.$message({
                                type: 'success',
                                message: msg || this.$t('logistics.save.success')
                            });
                            this.visible = false;
                            this.getReturnAddressList();
                        }
                    } else {
                        console.log('error submit!!');
                    }
                });
            }
        }
    };
</script>

<style module>
@import 'variable.css';
.container {
    background-color: var(--color-white);
    padding-bottom: 20px;
}
.title {
    height: 50px;
    line-height: 50px;
    background-color: #fafafa;
    font-size: 18px;
    font-weight: 500;
    padding: 0 20px 0 40px;
    position: relative;
}
.title:before {
    content: '';
    width: 5px;
    height: 16px;
    display: inline-block;
    background-color: var(--color-primary-darken);
    border-radius: 3px;
    position: absolute;
    left: 20px;
    top: 17px;
}
.table {
    :global .el-table {
        border: 1px var(--border-color-lighter) solid;
    }
}
.content {
    padding: 0 20px;
}
.btn {
    margin: 20px 0;
    text-align: right;
}
.input {
    width: 300px;
}
.delete {
    color: var(--color-danger);
}
.telephone [class~="el-input-group__prepend"]{
    padding: 0 5px 0 8px;
}
.telephone [class~="el-form-item__content"]{
    line-height: 38px;
}


.telephoneCode{
    border: none;
}
.telephoneCode [class~="el-input__inner"]{
    padding: 0;
    width: 40px;
    border: none;
    height: 38px;
    background-color: var(--background-color-base);
}
</style>
