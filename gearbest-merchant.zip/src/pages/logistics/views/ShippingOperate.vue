<template>
    <div :class="$style.container">
        <el-form
            ref="form"
            :model="form"
            :rules="rules"
            label-width="120px"
            label-position="left"
            label-suffix=":"
        >
            <el-form-item :label="$t('logistics.tplList.name')" prop="name">
                <el-input v-model="form.name" :style="{ width: '420px' }" :placeholder="$t('logistics.verify.name')"></el-input>
            </el-form-item>
            <el-form-item :label="$t('logistics.tplList.type')" prop="type">
                <el-select
                    ref="select"
                    :value="form.type"
                    :style="{ width: '420px' }"
                    :disabled="isEdit && !$route.query.copy"
                    @input="willChangeTplType"
                >
                    <el-option v-for="(item, index) in tplTypes" :key="index" :label="item.name" :value="item.value"></el-option>
                </el-select>
            </el-form-item>
        </el-form>
        <h4 :class="$style.title">{{ $t('logistics.tpl.set') }}:</h4>
        <paginated-table
            v-loading="loading"
            :data="levels"
            :columns="columns"
            :class="$style.table"
            :attrs="attrs"
        >
            <template
                slot="checked"
                slot-scope="scope"
            >
                <el-checkbox v-model="scope.row.checked" />
            </template>
            <template
                slot="level"
                slot-scope="scope"
            >
                {{ scope.row.levelName }}
            </template>
            <template
                slot="setting"
                slot-scope="scope"
            >
                <div :class="$style.customFreight">
                    <h4 :class="$style.setHeader">{{ $t('logistics.tpl.coustom') }}</h4>
                    <p :class="$style.setTitle">
                        <el-button
                            v-if="scope.row.ruleCountryNum"
                            :disabled="!scope.row.checked"
                            type="text"
                            @click="setRule(scope.row, 'ruleVisible')"
                        >{{ $t('logistics.tpl.setted', [scope.row.ruleCountryNum]) }}</el-button>
                        <el-button
                            v-else
                            :disabled="!scope.row.checked"
                            type="text"
                            @click="setRule(scope.row, 'ruleVisible')"
                        >{{ $t('logistics.tpl.notSet') }}</el-button>
                        <i
                            v-if="shownNotification(scope.row) && !$route.query.copy"
                            v-show="scope.row.checked"
                            :class="$style.notificationBtn"
                            class="el-icon-warning"
                            @click="notiVisible = true"></i>
                    </p>
                </div>
                <div v-if="form.type === 2" :class="$style.customTime">
                    <h4 :class="$style.setHeader">{{ $t('logistics.tpl.coustomTime') }}</h4>
                    <p :class="$style.setTitle">
                        <el-button
                            v-if="scope.row.timeCountryNum"
                            :disabled="!scope.row.checked"
                            type="text"
                            @click="setRule(scope.row, 'timeVisible')"
                        >{{ $t('logistics.tpl.timeSetted', [scope.row.timeCountryNum]) }}</el-button>
                        <el-button
                            v-else
                            :disabled="!scope.row.checked"
                            type="text" @click="setRule(scope.row, 'timeVisible')"
                        >{{ $t('logistics.tpl.notSetTime') }}</el-button>
                        <i
                            v-if="shownNotification(scope.row) && !$route.query.copy"
                            v-show="scope.row.checked"
                            :class="$style.notificationBtn"
                            class="el-icon-warning"
                            @click="notiVisible = true"></i>
                    </p>
                </div>
            </template>
        </paginated-table>
        <div :class="$style.btn">
            <el-button @click="cancel">{{ $t('logistics.cancel.text') }}</el-button>
            <el-button :disabled="clickSave" type="primary" @click="save">{{ $t('logistics.save.text') }}</el-button>
        </div>
        <el-dialog
            :visible.sync="ruleVisible"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            width="880px"
            @close="handleClose('freight')"
        >
            <custom-freight-rule
                ref="freight"
                :countrys="countrys"
                :countryslist="allCountrys"
                :rule="currentRule"
                :type="form.type"
                :types="types"
                :isshow="ruleVisible"
                @change="changeRule($event)"
                @close="ruleVisible=false"
            />
        </el-dialog>
        <el-dialog
            v-if="form.type === 2"
            :visible.sync="timeVisible"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            width="880px"
            @close="handleClose('time')"
        >
            <custom-time-rule
                ref="time"
                :countryslist="allCountrys"
                :countrys="countrys"
                :rule="currentRule"
                :type="form.type"
                :isshow="timeVisible"
                @change="changeRule($event)"
                @close="timeVisible=false"
            />
        </el-dialog>

        <el-dialog
            :visible.sync="notiVisible"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            width="500px"
            @close="notiVisible=false"
        >
            <p :class="$style.notificationInfo">{{ $t('logistics.notification.text') }}</p>
        </el-dialog>
    </div>
</template>

<script>
    import {
        levelsGet,
        shippingDetail,
        shippingAdd,
        shippingEdit,
        shippingCountrysGet,
        feeTypesGet,
        shippingTypesGet,
        countrysListGet
    } from '@logistics/services/logisticsServices';
    import PaginatedTable from '@logistics/components/PaginatedTable';
    import CustomTimeRule from '@logistics/components/CustomTimeRule';
    import CustomFreightRule from '@logistics/components/CustomFreightRule';

    export default {
        name: 'ShippingOperate',
        components: {
            'paginated-table': PaginatedTable,
            'custom-freight-rule': CustomFreightRule,
            'custom-time-rule': CustomTimeRule
        },
        data() {
            return {
                allCountrys: [],
                tplTypes: [],
                loading: false,
                ruleVisible: false,
                timeVisible: false,
                notiVisible: false,
                currentRule: null,
                countrys: [],
                form: {
                    id: '',
                    type: 2,
                    name: ''
                },
                attrs: {
                    'cell-style': { height: '134px' }
                },
                rules: {
                    name: [
                        { required: true, message: this.$t('logistics.tpl.ruleName1'), trigger: 'blur' },
                        {
                            min: 1,
                            max: 200,
                            message: this.$t('logistics.tpl.ruleName2'),
                            trigger: 'blur'
                        }
                    ],
                    type: [
                        { required: true, message: this.$t('logistics.tplSearch.place2'), trigger: 'blur' },
                    ]
                },
                columns: [{
                    prop: 'checked',
                    'header-align': 'center',
                    align: 'center',
                    width: '80px',
                    scope: true
                }, {
                    prop: 'level',
                    label: this.$t('logistics.detail.level'),
                    'header-align': 'center',
                    align: 'center',
                    scope: true
                }, {
                    prop: 'setting',
                    label: this.$t('logistics.tpl.set'),
                    'header-align': 'center',
                    width: '450px',
                    scope: true
                }],
                isEdit: false,
                levels: [],
                types: {},
                clickSave: false,
            };
        },
        computed: {

        },
        created() {
            // 判断是否为编辑
            const { id } = this.$route.query;
            if (id) {
                this.form.id = id;
                this.isEdit = true;
            }
            this.getTplTypes();
            this.getTypes();
            this.getLevels();
            this.getAllCountrys();
        },
        methods: {
            // 后台是否存数据变动
            shownNotification(data) {
                let isShow = false;
                data.ruleInfoList.forEach((item) => {
                    if (item.countryRels) {
                        item.countryRels.forEach((country) => {
                            if (country.status === 0) {
                                isShow = true;
                            }
                        });
                    }
                });
                return isShow;
            },
            // 更改模板类型
            willChangeTplType(value) {
                this.$confirm(this.$t('logistics.tpl.typeConfirm'), this.$t('logistics.tip.text'), {
                    confirmButtonText: this.$t('logistics.sure.text'),
                    cancelButtonText: this.$t('logistics.cancel.text'),
                }).then(() => {
                    this.form.type = value;
                    this.getLevels(value);
                });
            },
            // 运费模板类型
            async getTplTypes() {
                const { status, data } = await shippingTypesGet.http({
                    showError: true
                });
                if (status === 0 && data) {
                    this.tplTypes = data;
                }
            },
            // 获取物流级别
            async getLevels(tplType) {
                this.loading = true;
                // 默认设置
                const setDefault = (item) => {
                    item.timeInfoList = [];
                    item.ruleInfoList = [];
                    item.timeCountryNum = 0;
                    item.ruleCountryNum = 0;
                    item.checked = false;
                };
                const { status, data } = await levelsGet.http({
                    showError: true,
                    params: {
                        type: tplType || this.$route.query.type || 2
                    }
                });
                if (status === 0 && data) {
                    // 编辑时，组装编辑时的配置数据
                    if (this.isEdit) {
                        const { status: code, data: detailData } = await shippingDetail.http({
                            showError: true,
                            params: {
                                id: this.$route.query.id
                            }
                        });
                        if (code === 0) {
                            const { id, name, type } = detailData;
                            if (this.$route.query.copy) {
                                this.form = { id: '', name, type: Number(type) };
                            } else {
                                this.form = { id, name, type: Number(type) };

                                // 此处对编辑运费模板时，被禁用的物流分组依然支持查看，卖家保存数据
                                detailData.ruleList.forEach((item, index) => {
                                    const idx = data.findIndex(n => item.groupId === n.groupId);
                                    if (idx === -1) {
                                        data.push({
                                            enName: '',
                                            groupId: item.groupId,
                                            levelName: item.levelName,
                                            isClose: true,
                                        });
                                    }
                                });
                            }

                            data.forEach((item, index) => {
                                const idx = detailData.ruleList.findIndex(n => item.groupId === n.groupId);
                                if (idx > -1) {
                                    item.timeInfoList = detailData.ruleList[idx].timeInfoList;
                                    item.ruleInfoList = detailData.ruleList[idx].ruleInfoList;
                                    let timeCountryNum = 0;
                                    let ruleCountryNum = 0;
                                    if (item.timeInfoList.length > 0) {
                                        // 如果是复制时，把已关闭国家去掉
                                        if (this.$route.query.copy) {
                                            item.timeInfoList.forEach((it, i) => {
                                                if (it.countryRels && it.countryRels.length > 0) {
                                                    it.countryRels.forEach((country) => {
                                                        if (country.status === 1) {
                                                            timeCountryNum += 1;
                                                        }
                                                    });
                                                }
                                            });
                                        } else {
                                            item.timeInfoList.forEach((it, i) => {
                                                timeCountryNum += it.countryRels.length;
                                            });
                                        }
                                        item.timeCountryNum = timeCountryNum;
                                    }
                                    if (item.ruleInfoList.length > 0) {
                                        item.checked = true;
                                        // 如果是复制时，把已关闭国家去掉
                                        if (this.$route.query.copy) {
                                            item.ruleInfoList.forEach((it, i) => {
                                                if (it.countryRels && it.countryRels.length > 0) {
                                                    it.countryRels.forEach((country) => {
                                                        if (country.status === 1) {
                                                            ruleCountryNum += 1;
                                                        }
                                                    });
                                                }
                                            });
                                        } else {
                                            item.ruleInfoList.forEach((it, i) => {
                                                ruleCountryNum += it.countryRels.length;
                                            });
                                        }
                                        // item.ruleInfoList.forEach((it, i) => {
                                        //     ruleCountryNum += it.countryRels.length;
                                        // });
                                        item.ruleCountryNum = ruleCountryNum;
                                    }
                                } else {
                                    setDefault(item);
                                }
                            });
                        }
                    } else {
                        data.forEach((item, index) => {
                            setDefault(item);
                        });
                    }
                    this.levels = data;
                    this.$nextTick(() => {
                        this.loading = false;
                    });
                }
            },
            // 获取运费类型
            async getTypes() {
                const { status, data } = await feeTypesGet.http({
                    showError: true
                });
                if (status === 0 && data) {
                    const types = {};
                    data.forEach((item) => {
                        types[String(item.value)] = item.name;
                    });
                    this.types = types;
                }
            },
            // 取消
            cancel() {
                this.$confirm(this.$t('logistics.tpl.confirm'), this.$t('logistics.tip.text'), {
                    confirmButtonText: this.$t('logistics.sure.text'),
                    cancelButtonText: this.$t('logistics.cancel.text'),
                }).then(() => {
                    this.$router.push({ name: 'shippingList' });
                });
            },
            // 设置自定义规则（运费与运输时间）
            setRule(row, type) {
                this.currentRule = row;
                this[type] = true;
                this.$nextTick(() => {
                    this.getShippingCountrys();
                });
            },
            // 改变后的自定义规则（运费与运输时间）
            changeRule(rule, type) {
                let timeCountryNum = 0;
                let ruleCountryNum = 0;
                if (rule.timeInfoList.length > 0) {
                    rule.timeInfoList.forEach((it, i) => {
                        timeCountryNum += it.countryRels.length;
                    });
                    rule.timeCountryNum = timeCountryNum;
                } else {
                    rule.timeCountryNum = 0;
                }
                if (rule.ruleInfoList.length > 0) {
                    rule.checked = true;
                    rule.ruleInfoList.forEach((it, i) => {
                        ruleCountryNum += it.countryRels.length;
                    });
                    rule.ruleCountryNum = ruleCountryNum;
                } else {
                    rule.ruleCountryNum = 0;
                }
                const index = this.levels.findIndex(item => String(item.groupId) === String(rule.groupId));
                this.levels.splice(index, 1, rule);
                this.$nextTick(() => {
                    this.ruleVisible = false;
                    this.timeVisible = false;
                });
            },
            // 获取可发国家
            async getShippingCountrys() {
                const { type } = this.form;
                const { groupId } = this.currentRule;
                const { status, data } = await shippingCountrysGet.http({
                    showError: true,
                    params: {
                        type,
                        groupId
                    }
                });
                if (status === 0) {
                    this.countrys = data;
                }
            },
            // 获取所有国家
            async getAllCountrys() {
                const { status, data } = await countrysListGet.http();
                if (status === 0) {
                    this.allCountrys = data;
                }
            },
            // 弹框关闭回调
            handleClose(type) {
                this.$refs[type].resetData();
            },

            // 跳转至引用页面
            routerToRefPage() {
                const { ref } = this.$route.query;
                if (ref) {
                    this.$router.gbReplace(ref);
                }
            },

            // 保存操作
            save() {
                if (this.clickSave) {
                    return false;
                }
                this.clickSave = true;
                this.$refs.form.validate(async (valid) => {
                    const h = this.$createElement;
                    const that = this;
                    const executeFetch = async (arr) => {
                        // 把countryRels数据提取到countryCodes
                        arr.forEach((item) => {
                            if (item.ruleInfoList) {
                                item.ruleInfoList.forEach((ruleItem) => {
                                    ruleItem.countryCodes = [];
                                    if (ruleItem.countryRels) {
                                        ruleItem.countryRels.forEach((countryItem) => {
                                            ruleItem.countryCodes.push(countryItem.countryCode);
                                        });
                                    }
                                });
                            }
                            if (item.timeInfoList) {
                                item.timeInfoList.forEach((timeItem) => {
                                    timeItem.countryCodes = [];
                                    if (timeItem.countryRels) {
                                        timeItem.countryRels.forEach((countryItem) => {
                                            timeItem.countryCodes.push(countryItem.countryCode);
                                        });
                                    }
                                });
                            }
                        });
                        const params = { ...that.form, ruleList: arr };
                        let fetch;
                        if (that.isEdit) {
                            if (that.$route.query.copy) {
                                delete params.id;
                                fetch = shippingAdd;
                            } else {
                                fetch = shippingEdit;
                            }
                        } else {
                            delete params.id;
                            fetch = shippingAdd;
                        }
                        const { status, msg } = await fetch.http({
                            showError: true,
                            data: params
                        });
                        if (status === 0) {
                            that.$message({
                                type: 'success',
                                message: msg || that.$t('logistics.save.success')
                            });
                            that.routerToRefPage();
                            that.$router.push({ name: 'shippingList' });
                            return true;
                        }
                        that.clickSave = false;
                        return false;
                    };
                    if (valid) {
                        let isEmpty = true;
                        const currentSelectedArr = [];
                        this.levels.forEach((it, i) => {
                            if (it.checked) {
                                isEmpty = false;
                                currentSelectedArr.push(it);
                            }
                        });
                        if (isEmpty) {
                            return this.$message({
                                type: 'error',
                                message: this.$t('logistics.verify.set1')
                            });
                        }
                        const errorIndex = currentSelectedArr.findIndex(it => it.ruleInfoList.length === 0);
                        if (errorIndex > -1) {
                            return this.$message({
                                type: 'error',
                                message: this.$t('logistics.verify.set2', [currentSelectedArr[errorIndex].levelName])
                            });
                        }
                        const filterCurrentSelectedArr = currentSelectedArr.filter(it => it.timeInfoList.length === 0);
                        if (filterCurrentSelectedArr.length > 0 && this.form.type === 2) {
                            const result = filterCurrentSelectedArr.map(it => it.levelName);
                            const vMessage = h('div', [
                                h('p', { style: { fontWeight: 600 } }, this.$t('logistics.verify.noeSetTime', [result.join('，')]))
                            ]);
                            return this.$confirm(vMessage, this.$t('logistics.tip.text'), {
                                confirmButtonText: this.$t('logistics.sure.text'),
                                cancelButtonText: this.$t('logistics.cancel.text'),
                            }).then(() => {
                                executeFetch(currentSelectedArr);
                            });
                        }
                        executeFetch(currentSelectedArr);
                        return true;
                    }
                    console.log('error submit!!');
                    return false;
                });
                return true;
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    .container {
        background-color: var(--color-white);
        padding: 30px 20px;
    }
    .table {
        :global .el-table {
            border: 1px var(--border-color-lighter) solid;
        }
        :global .el-checkbox__input.is-checked+.el-checkbox__label {
            color: var(--color-black);
        }
    }
    .title {
        color: var(--color-text-regular);
        font-weight: normal;
        margin: 30px 0 15px 0;
    }
    .title:before {
        content: "*";
        color: #ff5757;
        margin-right: 4px;
    }
    .setHeader {
        font-weight: normal;
    }
    .setTitle {
        :global .el-button {
            padding: 8px 0;
        }
    }
    .customTime {
        margin-top: 10px;
    }
    .btn {
        text-align: center;
        margin-top: 30px;
        :global .el-button {
            width: 120px;
            height: 40px;
        }
        :global .el-button+.el-button {
            margin-left: 30px;
        }
    }
    .notificationBtn{
        cursor: pointer;
    }
    .notificationInfo{
        margin: 30px 30px 50px;
        line-height: 32px;
        text-align: center;
        font-size: var(--font-size-largest);
    }
</style>
