/**
 * Created by xiaobin_wu on 2018/12/21.
 */

import Service from '@/assets/js/Service';


/* 地址管理-退货地址-列表 */
export const returnAddressListGet = new Service({
    url: '/logistics/return-goods-address/list',
    method: 'get',
    loading: true
});

/* 地址管理-退货地址-新增 */
export const returnAddressAdd = new Service({
    url: '/logistics/return-goods-address/create',
    method: 'post'
});

/* 地址管理-退货地址-更新 */
export const returnAddressUpdate = new Service({
    url: '/logistics/return-goods-address/update',
    method: 'post'
});

/* 地址管理-退货地址-删除 */
export const returnAddressDelete = new Service({
    url: '/logistics/return-goods-address/delete',
    method: 'post'
});

/* 地址管理-查询国家-级联选择器 */
export const countrysListGet = new Service({
    url: '/public/logistics/country/list',
    method: 'get'
});

/* 地址管理-查询省份-级联选择器 */
export const provincesListGet = new Service({
    url: '/public/logistics/country/get-provinces-by',
    method: 'get'
});

/* 地址管理-查询城市-级联选择器 */
export const citysListGet = new Service({
    url: '/public/logistics/country/get-cities-by',
    method: 'get'
});

/* 运费模板-指定物流-级别列表 */
export const levelsGet = new Service({
    url: '/public/logistics/shipping-template/logistics-levels',
    method: 'get'
});

/* 运费模板-指定物流列表 */
export const logisticsListGet = new Service({
    url: '/logistics/shipping-template/deliver-logistics-list',
    method: 'get'
});

/* 运费模板-运费模板列表 */
export const shippingListGet = new Service({
    url: '/logistics/shipping-template/list',
    method: 'get'
});

/* 运费模板-模板类型 */
export const shippingTypesGet = new Service({
    url: '/public/logistics/shipping-template/get-types',
    method: 'get'
});

/* 运费模板-运费模板删除 */
export const shippingDelete = new Service({
    url: '/logistics/shipping-template/delete',
    method: 'post'
});

/* 运费模板-运费模板详情 */
export const shippingDetail = new Service({
    url: '/logistics/shipping-template/info',
    method: 'get'
});

/* 运费模板-运费模板新增 */
export const shippingAdd = new Service({
    url: '/logistics/shipping-template/create',
    method: 'post',
    loading: true,
});

/* 运费模板-运费模板编辑 */
export const shippingEdit = new Service({
    url: '/logistics/shipping-template/update',
    method: 'post',
    loading: true,
});

/* 运费模板-运费规则类型 */
export const feeTypesGet = new Service({
    url: '/public/logistics/shipping-template/fee-types',
    method: 'get'
});

/* 运费模板-获取可发国家 */
export const shippingCountrysGet = new Service({
    url: '/logistics/shipping-template/get-countrys-by',
    method: 'get'
});

/* 运费模板-获取运费组合明细 */
export const shippingFreightGet = new Service({
    url: '/logistics/shipping-template/get-rule-detail-by',
    method: 'get'
});

/* 运费模板-获取运输时效明细 */
export const shippingTimeGet = new Service({
    url: '/logistics/shipping-template/get-time-detail-by',
    method: 'get'
});
