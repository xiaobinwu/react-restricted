import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    {
        path: '/logistics/returnAddressList',
        name: 'returnAddressList',
        meta: {
            title: 'base.menu.logistics.returnAddress',
        },
        component: () => asyncComponent(import('@logistics/views/ReturnAddressList'))
    },
    {
        path: '/logistics/shippingList',
        name: 'shippingList',
        meta: {
            title: 'base.menu.logistics.shippingList',
        },
        component: () => asyncComponent(import('@logistics/views/ShippingList'))
    },
    {
        path: '/logistics/shippingOperate',
        name: 'shippingOperate',
        meta: {
            title: 'logistics.page.operate',
            focusMenu: '/logistics/shippingList'
        },
        component: () => asyncComponent(import('@logistics/views/ShippingOperate'))
    },
    {
        path: '/logistics/shippingDetail',
        name: 'shippingDetail',
        meta: {
            title: 'logistics.page.detail',
        },
        component: () => asyncComponent(import('@logistics/views/ShippingDetail'))
    }
];
