/**
 * 优惠券发放状态
 * Created by Jiazhan Li on 2019/2/23.
 */

export default [{
    // 全部
    name: 'ALL',
    code: '0',
    lang: '全部'
}, {
    // 未开始
    name: 'NOT_STARTED',
    code: '1',
    lang: '未开始'
}, {
    // 进行中
    name: 'UNDERWAY',
    code: '2',
    lang: '进行中'
}, {
    // 已结束
    name: 'ENDED',
    code: '3',
    lang: '已结束'
}, {
    // 已停止
    name: 'STOPPED',
    code: '4',
    lang: '已停止'
}];
