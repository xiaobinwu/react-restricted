<template>
    <div :class="$style.container">
        <h1 :class="$style.title">查看优惠券活动报告</h1>
        <h2 :class="$style.caption">优惠券活动概况</h2>
        <div :class="$style.content">
            <el-table :data="tableCouponDetail" stripe>
                <div slot="empty">暂无数据</div>
                <el-table-column prop="couponName" label="活动名称" align="center" min-width="120"></el-table-column>
                <el-table-column :class-name="$style.time" :formatter="formatTime" label="发放时间" align="center" min-width="120"></el-table-column>
                <el-table-column :formatter="formatCondition" label="使用条件" align="center" min-width="120"></el-table-column>
                <el-table-column prop="publishTotalCount" label="发放数量" align="center"></el-table-column>
                <el-table-column prop="publishedCount" label="已领取" align="center"></el-table-column>
                <el-table-column prop="usedCount" label="已使用" align="center"></el-table-column>
                <el-table-column :formatter="formatStatus" label="当前状态" align="center"></el-table-column>
            </el-table>
        </div>
        <h2 :class="$style.caption">优惠券使用情况</h2>
        <div :class="$style.content">
            <el-table :data="tableCouponLog" stripe>
                <div slot="empty">暂无数据</div>
                <el-table-column prop="orderSn" label="订单编号" align="center"></el-table-column>
                <el-table-column :formatter="formatPrice" prop="orderAmount" label="订单金额" align="center"></el-table-column>
                <el-table-column :formatter="formatOrderStatus" label="订单状态" align="center"></el-table-column>
                <el-table-column :formatter="formatPrice" prop="couponPrice" label="优惠券面额" align="center"></el-table-column>
            </el-table>
            <el-pagination
                :class="$style.pagination"
                :current-page="pageNo"
                :page-size="pageSize"
                :total="totalCount"
                layout="->, total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
            <div :class="$style.btnGroup">
                <el-button :class="$style.btnItem" @click="gotoIndex">返回列表</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    import { reqCouponView, reqCouponLog } from '@promotion/services/coupon';
    import { dateFormat } from '@/assets/js/utils/date';
    import { backupData as statusStore } from '@order/utils/statusStore';
    import Map from '@promotion/utils/map';

    const mapOfStatus = new Map('couponStatus');

    export default {
        name: 'CouponReport',
        data() {
            // 默认数据
            const DATA = {
                pageSize: 20, // 每页显示条数
                pageNo: 1, // 当前页码
            };

            return {
                DATA,
                couponCode: this.$route.query.couponCode,
                tableCouponDetail: [], // 优惠券活动概况
                tableCouponLog: [], // 优惠券使用情况列表
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 订单总数
                couponPrice: 0, // 优惠券面额
            };
        },

        watch: {
            $route: {
                immediate: false,
                handler() {
                    const { couponCode, pageSize, pageNo } = this.$route.query;
                    this.pageSize = Number(pageSize) || this.DATA.pageSize;
                    this.pageNo = Number(pageNo) || this.DATA.pageNo;
                    if (couponCode !== this.couponCode) {
                        this.couponCode = couponCode;
                        this.init();
                    } else {
                        this.updateTableCouponLog();
                    }
                }
            }
        },

        created() {
            this.init();
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                this.$router.push({
                    query: {
                        couponCode: this.couponCode,
                        ...query
                    }
                });
            },

            async init() {
                const allPromise = await Promise.all([
                    this.updateTableCouponDetail(),
                    this.getCouponLog()
                ]);
                this.mergeTableCouponLog(allPromise[1]);
            },

            /**
             * 初始化优惠券活动概况
             */
            async updateTableCouponDetail() {
                const { status, data } = await reqCouponView.http({
                    params: { code: this.couponCode }
                });
                if (status === 0) {
                    this.tableCouponDetail = [data];
                    this.couponPrice = data.strategys.split('-')[1] || 0;
                }
            },

            /**
             * 获取优惠券使用记录列表
             * @return {Promise<array>}
             */
            async getCouponLog() {
                const { status, data } = await reqCouponLog.http({
                    params: {
                        code: this.couponCode,
                        pageNo: this.pageNo,
                        pageSize: this.pageSize
                    }
                });
                if (status === 0) {
                    this.totalCount = data.totalCount;
                    return data.list || [];
                }
                return [];
            },

            /**
             * 合并 tableCouponLog 数据
             */
            mergeTableCouponLog(logList = []) {
                this.tableCouponLog = logList.map(item => ({
                    ...item,
                    couponPrice: this.couponPrice
                }));
            },

            /**
             * 更新优惠券使用情况列表
             */
            async updateTableCouponLog() {
                const logList = await this.getCouponLog();
                this.mergeTableCouponLog(logList);
            },

            /**
             * 格式化发放时间
             * @param startTime 《发放开始时间》
             * @param endTime 《发放结束时间》
             * @return {string}
             */
            formatTime({ startTime, endTime }) {
                return this.$createElement('div', {
                    domProps: {
                        innerHTML: `<span>${dateFormat(startTime)}</span> 至 <span>${dateFormat(endTime)}</span>`
                    }
                });
            },

            /**
             * 格式化优惠券面额
             */
            formatPrice(row, column, cellValue = '') {
                return `US $${cellValue}`;
            },

            /**
             * 格式化使用条件
             * @param strategys 《优惠券使用策略字符串》
             */
            formatCondition({ strategys = '' }) {
                const [amount, price] = strategys.split('-');
                return amount === '0' ? '不限' : `满US $${amount}减US $${price}`;
            },

            /**
             * 格式化优惠券状态
             * @param currentStatus 《状态码》
             */
            formatStatus({ currentStatus }) {
                return mapOfStatus.getInfoByCode(currentStatus).lang;
            },

            /**
             * 格式化订单状态
             * @param orderStatusSequ 《订单状态码》
             */
            formatOrderStatus({ orderStatusSequ }) {
                return statusStore.orderStatusSequ[orderStatusSequ];
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },

            /**
             * 返回活动首页
             */
            gotoIndex() {
                this.$router.push({
                    name: 'StoreActivity',
                    query: { type: 'coupon' }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .title {
        line-height: 25px;
        font-size: 18px;
        margin-bottom: 20px;
    }

    .caption {
        position: relative;
        height: 50px;
        padding-left: 35px;
        margin: 0 -20px;
        line-height: 50px;
        font-size: 18px;
        background-color: #fafafa;

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }
    }

    .content {
        padding: 20px 0 30px;
    }

    .time span {
        display: inline-block;
    }

    .pagination {
        margin-top: 20px;
    }

    .btnGroup {
        padding: 50px 0 0;
        text-align: center;
    }

    .btnItem {
        width: 120px;
        margin: 0 15px;
    }
</style>
