<template>
    <div>
        <header :class="$style.tableHead">
            <h1 :class="$style.tableName">活动类型：领取型优惠券活动</h1>
            <div :class="$style.filterItem">
                <label :class="$style.filterLabel">发放状态：</label>
                <el-select v-model="status" @change="changeStatus">
                    <el-option
                        v-for="item in filterOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                    </el-option>
                </el-select>
            </div>
        </header>

        <el-table :data="tableData" stripe>
            <div slot="empty">暂无数据</div>
            <el-table-column prop="couponName" label="优惠券名称" align="center" min-width="120" show-overflow-tooltip></el-table-column>
            <el-table-column :formatter="formatDate" prop="startTime" label="活动开始时间" align="center" min-width="120"></el-table-column>
            <el-table-column :formatter="formatDate" prop="endTime" label="活动结束时间" align="center" min-width="120"></el-table-column>
            <el-table-column :formatter="formatPrice" label="面额" align="center"></el-table-column>
            <el-table-column prop="publishCount" label="发放数量" align="center"></el-table-column>
            <el-table-column :formatter="formatStatus" label="当前状态" align="center"></el-table-column>
            <el-table-column :class-name="$style.handles" label="操作" align="center" min-width="170">
                <el-row slot-scope="scope">
                    <el-col :span="9"><el-button type="text" @click="viewDetail(scope.row)">查看详情</el-button></el-col>
                    <el-col :span="10">
                        <el-button v-if="showReport(scope.row)" type="text" @click="viewReport(scope.row)">查看报告</el-button>
                        <el-button v-if="showEditor(scope.row)" type="text" @click="handleEdit(scope.row)">编辑</el-button>
                    </el-col>
                    <el-col v-if="showStopBtn(scope.row)" :span="5">
                        <el-button :class="$style.stopBtn" type="text" @click="handleStop(scope)">停止</el-button>
                    </el-col>
                </el-row>
            </el-table-column>
        </el-table>

        <el-pagination
            :class="$style.pagination"
            :current-page="pageNo"
            :page-size="pageSize"
            :total="totalCount"
            layout="->, total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { reqCouponList, reqInvalidCoupon } from '@promotion/services/coupon';
    import Map from '@promotion/utils/map';

    const mapOfStatus = new Map('couponStatus');

    export default {
        name: 'TableCoupon',
        data() {
            // 默认数据
            const DATA = {
                status: mapOfStatus.getInfoByName('ALL').code, // 当前发放状态
                pageSize: 20, // 每页显示条数
                pageNo: 1, // 当前页码
            };

            return {
                DATA,
                tableData: [], // 表格数据对象
                status: DATA.status, // 当前发放状态
                pageSize: DATA.pageSize, // 每页显示条数
                pageNo: DATA.pageNo, // 当前页码
                totalCount: Infinity, // 总条数

                // 发放状态下拉菜单列表
                filterOptions: ['ALL', 'NOT_STARTED', 'UNDERWAY', 'ENDED', 'STOPPED'].map((item) => {
                    const statusInfo = mapOfStatus.getInfoByName(item);
                    return {
                        label: statusInfo.lang,
                        value: statusInfo.code,
                    };
                }),
            };
        },

        watch: {
            $route: {
                immediate: true,
                handler() {
                    const {
                        type,
                        status,
                        pageSize,
                        pageNo
                    } = this.$route.query;

                    if (type !== 'coupon') {
                        this.updateUrl();
                    } else {
                        this.status = status || this.DATA.status;
                        this.pageSize = Number(pageSize) || this.DATA.pageSize;
                        this.pageNo = Number(pageNo) || this.DATA.pageNo;
                        this.updateTableData();
                    }
                }
            }
        },

        methods: {
            /**
             * 更新URL
             */
            updateUrl() {
                const query = {};
                if (this.status !== this.DATA.status) query.status = this.status;
                if (this.pageSize !== this.DATA.pageSize) query.pageSize = this.pageSize;
                if (this.pageNo !== this.DATA.pageNo) query.pageNo = this.pageNo;
                this.$router.push({
                    query: {
                        type: 'coupon',
                        ...query
                    }
                });
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { status, data } = await reqCouponList.http({
                    params: {
                        status: this.status,
                        pageNo: this.pageNo,
                        pageSize: this.pageSize
                    }
                });
                if (status === 0) {
                    this.tableData = data.list || [];
                    this.totalCount = data.totalCount || 0;
                }
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return dateFormat(cellValue);
            },

            /**
             * 格式化面额
             * PHP并没有直接返回面额属性，而是返回优惠策略字符串 strategys（"200-10" 表示满200减10块，面额就是10）
             * @return {string}
             */
            formatPrice({ strategys = '' }) {
                const price = strategys.split('-')[1];
                return price ? `US $${price}` : '???';
            },

            /**
             * 格式化状态，已结束和已停止的状态文字置灰
             * @param status 《活动状态》
             * @return {string}
             */
            formatStatus({ status }) {
                const statusInfo = mapOfStatus.getInfoByCode(status);
                if (['ENDED', 'STOPPED'].includes(statusInfo.name)) {
                    return this.$createElement('span', {
                        style: { color: '#999' },
                        domProps: { innerHTML: statusInfo.lang }
                    });
                }
                return statusInfo.lang;
            },

            /**
             * 查看详情
             * @param code 《优惠券编码》
             */
            viewDetail({ code }) {
                this.$router.push({
                    name: 'CouponDetail',
                    query: { couponCode: code }
                });
            },

            /**
             * 查看报告
             * @param code 《优惠券编码》
             */
            viewReport({ code }) {
                this.$router.push({
                    name: 'CouponReport',
                    query: { couponCode: code }
                });
            },

            /**
             * 编辑操作
             * @param code 《优惠券编码》
             */
            handleEdit({ code }) {
                this.$router.push({
                    name: 'CouponEdit',
                    query: { couponCode: code }
                });
            },

            /**
             * 停止操作
             * @param row 《表格行数据》
             * @param rowIndex 《操作项在列表中的索引值》
             */
            handleStop({ row, $index: rowIndex }) {
                this.$confirm('是否停止？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(async () => {
                    const { status } = await reqInvalidCoupon.http({
                        data: { code: row.code }
                    });
                    if (status === 0) {
                        this.$message({
                            type: 'success',
                            message: '操作成功！'
                        });
                        // 更新列表项为已停止状态
                        this.tableData[rowIndex].status = mapOfStatus.getInfoByName('STOPPED').code;
                    } else {
                        this.$message({
                            type: 'error',
                            message: '操作失败！请稍后再试！'
                        });
                    }
                }).catch(() => {
                    // 如果用户点击取消而且没在这里捕获的话控制台会报红！
                });
            },

            /**
             * 是否显示查看报告按钮（进行中、已结束、已停止）
             * @param status 《活动状态》
             * @return {boolean}
             */
            showReport({ status }) {
                return ['UNDERWAY', 'ENDED', 'STOPPED'].includes(mapOfStatus.getInfoByCode(status).name);
            },

            /**
             * 是否显示编辑按钮（未开始）
             * @param status 《活动状态》
             * @return {boolean}
             */
            showEditor({ status }) {
                return ['NOT_STARTED'].includes(mapOfStatus.getInfoByCode(status).name);
            },

            /**
             * 是否显示停止按钮（未开始、进行中）
             * @param status 《活动状态》
             * @return {boolean}
             */
            showStopBtn({ status }) {
                return ['NOT_STARTED', 'UNDERWAY'].includes(mapOfStatus.getInfoByCode(status).name);
            },

            /**
             * 切换活动状态的时候改变
             */
            changeStatus(val) {
                this.status = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateUrl();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateUrl();
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .tableHead {
        height: 40px;
        margin-bottom: 20px;
        @mixin clearfix;
    }

    .tableName {
        float: left;
        line-height: 40px;
    }

    .filterItem {
        float: right;
    }

    .filterLabel {
        display: inline-block;
        line-height: 40px;
    }

    .stopBtn {
        color: var(--color-error) !important;
    }

    .pagination {
        margin-top: 20px;
    }

    .handles {
        padding: 0 !important;
    }
</style>
