<template>
    <div>
        <nav :class="$style.menu">
            <router-link :class="$style.menuItem" :style="{ color: '#2774FF' }" :to="{ name: 'ActivityAdd' }">
                <img src="@promotion/assets/img/activity.png">
                <span :class="$style.menuItemName">创建满立减</span>
            </router-link>
            <router-link :class="$style.menuItem" :style="{ color: '#F5A623' }" :to="{ name: 'CouponAdd' }">
                <img src="@promotion/assets/img/coupon.png">
                <span :class="$style.menuItemName">添加优惠券</span>
            </router-link>
        </nav>

        <div :class="$style.content">
            <el-tabs v-model="type" :class="$style.tabs" type="border-card">
                <el-tab-pane label="满立减" name="activity">
                    <p :class="$style.promoDesc">
                        活动一旦开始不能编辑活动信息，只能停止活动；满减订单金额不包含运费。
                    </p>
                </el-tab-pane>
                <el-tab-pane label="店铺优惠券" name="coupon">
                    <p :class="$style.promoDesc">
                        1.领取型优惠劵活动：活动开始后，您设置的优惠劵信息会在店铺内、商品详情页、买家购物车展示，买家可通过“领取按钮”领取优惠券<br>
                        2.领取型优惠券，同一时间段内可创建多个领取型活动<br>
                        3.优惠券只可在活动未开始前进行修改；活动开始后只能停止活动
                    </p>
                </el-tab-pane>
            </el-tabs>

            <component :is="currentTable"></component>
        </div>
    </div>
</template>

<script>
    import TableActivity from './components/TableActivity';
    import TableCoupon from './components/TableCoupon';

    export default {
        name: 'StoreActivity',
        components: {
            TableActivity,
            TableCoupon
        },

        data() {
            return {
                type: this.getTypeName() // 活动类型：activity | coupon
            };
        },

        computed: {
            currentTable() {
                return {
                    activity: 'TableActivity',
                    coupon: 'TableCoupon',
                }[this.type];
            }
        },

        watch: {
            $route() {
                this.type = this.getTypeName();
            }
        },

        methods: {
            /**
             * 返回有效的类型名称
             */
            getTypeName() {
                const typeName = this.$route.query.type;
                return ['activity', 'coupon'].includes(typeName) ? typeName : 'activity';
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .menu {
        padding: 0 20px 20px;
        text-align: center;
        @mixin clearfix;
    }

    .menuItem {
        float: left;
        width: 200px;
        height: 90px;
        padding-top: 18px;
        margin-right: 30px;
        background-color: var(--color-white);
        border-radius: 4px;
        box-shadow: 0 1px 4px rgba(34,34,34,0.21);
    }

    .menuItemName {
        display: block;
        margin-top: 5px;
    }

    .content {
        padding: 20px;
        margin-bottom: 30px;
        background-color: var(--color-white);
    }

    .tabs {
        margin-bottom: 20px;
    }

    .promoDesc {
        line-height: 22px;
    }
</style>
