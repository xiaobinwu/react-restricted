<template>
    <div :class="$style.container">
        <progress-bar :active="0" :steps="stepsData"></progress-bar>
        <p :class="$style.explain">
            1.领取型优惠劵活动：活动开始后，您设置的优惠劵信息会在店铺内、商品详情页、买家购物车展示，买家可通过“领取按钮”领取优惠券<br>
            2.领取型优惠券，同一时间段内可创建多个领取型活动<br>
            3.优惠券只可在活动未开始前进行修改；活动开始后只能停止活动
        </p>
        <h1 :class="$style.title">活动类型：领取型优惠券活动</h1>

        <el-form ref="form" :model="formData" :rules="rules" label-width="20.48%">
            <h2 :class="$style.caption">活动基本信息</h2>

            <div :class="$style.fieldset">
                <el-form-item prop="couponName" label="优惠券名称：">
                    <el-input v-model="formData.couponName" placeholder="买家可见，最多输入32个字符" maxlength="32"></el-input>
                </el-form-item>

                <el-form-item v-if="!isEdit" label="活动使用范围：" required>
                    <el-radio-group v-model="formData.range">
                        <el-radio label="1">针对店铺内所有商品</el-radio>
                        <el-radio label="2">针对店铺内定向商品</el-radio>
                    </el-radio-group>
                </el-form-item>

                <el-form-item label="选择商品：" prop="goodsList">
                    <div v-if="forAllGoods">已选择全店商品</div>
                    <div v-if="!forAllGoods && !isEdit">
                        <el-button :class="$style.btnAddGoods" type="primary" size="small" @click="addGoods">添加商品</el-button>
                        <span>已选择商品<el-button type="text" @click="deleteGoods">{{ formData.goodsList.length }}</el-button>件</span>
                    </div>
                    <div v-if="!forAllGoods && isEdit"><el-button type="text" @click="viewGoods">查看已选商品</el-button></div>
                </el-form-item>

                <el-form-item prop="publishStartTime" label="发放时间：">
                    <el-date-picker v-model="formData.publishStartTime" :picker-options="pickerOptions"
                                    type="datetime" placeholder="选择日期时间"></el-date-picker>
                </el-form-item>

                <el-form-item prop="publishEndTime">
                    <el-date-picker v-model="formData.publishEndTime" :picker-options="pickerOptions"
                                    type="datetime" placeholder="选择日期时间"></el-date-picker>
                    <span :class="$style.inlineHint">可跨月设置，活动时间为UTC+8（北京时间）</span>
                </el-form-item>
            </div>

            <h2 :class="$style.caption">优惠券领取规则设置</h2>

            <div :class="$style.fieldset">
                <el-form-item label="领取条件：">
                    <el-radio>买家可通过“领取按钮”领取优惠券</el-radio>
                </el-form-item>

                <el-form-item label="优惠券面额：" prop="minusAmount">
                    <span :class="$style.mr7">US $</span>
                    <el-input v-model.number="formData.minusAmount" :class="$style.middleInput" type="number" placeholder="请输入正整数金额"></el-input>
                </el-form-item>

                <el-form-item label="发放总数量：" prop="publishTotalCount">
                    <el-input v-model.number="formData.publishTotalCount" :class="$style.middleInput" type="number" placeholder="请输入正整数"></el-input>
                    <span :class="$style.ml7">张</span>
                </el-form-item>

                <el-form-item label="每人限领：" prop="perUserReceiveCount">
                    <el-input v-model.number="formData.perUserReceiveCount" :class="$style.smallInput" type="number"></el-input>
                    <span :class="$style.ml7">次</span>
                    <span :class="$style.inlineHint">每次限领一张，注：用户需要使用后才能领取下一张</span>
                </el-form-item>
            </div>

            <h2 :class="$style.caption">优惠券使用规则设置</h2>

            <div :class="$style.fieldset">
                <el-form-item label="使用条件：" required>
                    <el-radio-group v-model="formData.condition">
                        <el-radio :label="0" :class="$style.radioLine">不限</el-radio>
                        <br>
                        <el-radio :label="1" :class="$style.radioLine">
                            <span :class="$style.mr7">订单金额满 US $</span>
                            <el-form-item :class="$style.inlineFormItem" prop="orderAmount">
                                <el-input v-model.number="formData.orderAmount"
                                          :class="$style.middleInput" :disabled="formData.condition !== 1"
                                          type="number" placeholder="请输入订单金额"></el-input>
                                <span :class="$style.inlineHint">（不包含运费）</span>
                            </el-form-item>
                        </el-radio>
                    </el-radio-group>
                </el-form-item>

                <el-form-item label="使用时间：" required>
                    <el-radio-group v-model="formData.dateType">
                        <el-radio :label="2" :class="$style.radioLine">
                            <span :class="$style.mr7">有效天数，买家领取成功时开始的</span>
                            <el-form-item :class="$style.inlineFormItem" prop="effectDays">
                                <el-input v-model.number="formData.effectDays"
                                          :class="$style.smallInput" :disabled="formData.dateType !== 2"
                                          type="number" placeholder="有效天数"></el-input>
                                <span :class="$style.ml7">天内</span>
                            </el-form-item>
                        </el-radio>
                        <br>
                        <el-radio :label="1" :class="$style.radioLine">
                            <span :class="$style.mr7">指定有效期</span>
                            <el-form-item :class="$style.inlineFormItem" prop="startTime">
                                <el-date-picker v-model="formData.startTime"
                                                :disabled="formData.dateType !== 1" :picker-options="pickerOptions"
                                                type="datetime" placeholder="选择日期时间"></el-date-picker>
                            </el-form-item>
                            <span :class="[$style.mr7, $style.ml7]">到</span>
                            <el-form-item :class="$style.inlineFormItem" prop="endTime">
                                <el-date-picker v-model="formData.endTime"
                                                :disabled="formData.dateType !== 1" :picker-options="pickerOptions"
                                                type="datetime" placeholder="选择日期时间"></el-date-picker>
                            </el-form-item>
                        </el-radio>
                    </el-radio-group>
                </el-form-item>
            </div>

            <h2 :class="$style.caption">优惠券买家可见位置提示</h2>

            <div :class="$style.content">
                创建成功并最终在活动开始后，您设置的优惠券信息将在店铺内、商品详情页、买家购物车三个位置向买家展示，买家可通过“领取按钮”领取优惠券
            </div>

            <div :class="$style.formBtns">
                <el-button :class="$style.formBtnItem" @click="goBack">返回</el-button>
                <el-button :class="$style.formBtnItem" type="primary" @click="submitForm()">{{ isEdit ? '确认修改' : '确认创建' }}</el-button>
            </div>
        </el-form>
    </div>
</template>

<script>
    import ProgressBar from '@/components/ProgressBar';
    import { addGoods, deleteGoods, viewGoods } from '@promotion/components/goods-selector';
    import { reqGoodsList } from '@promotion/services/common';
    import {
        reqAddCoupon,
        reqCouponInfo,
        reqEditCoupon,
        reqGoodsListBound
    } from '@promotion/services/coupon';
    import getRules from './rules';

    export default {
        name: 'CouponEditor',
        components: {
            ProgressBar,
        },

        data() {
            return {
                stepsData: ['1.设置活动信息', '2.完成'],
                couponCode: this.$route.query.couponCode, // 优惠券ID（编辑模式下有用）
                isEdit: this.$route.name === 'CouponEdit', // 是否是编辑模式，否则为新建
                rules: getRules(this), // 表单的校验规则放在另外一个文件管理（传入上下文对象）
                formData: {
                    couponName: '', // 优惠券名称
                    range: '1', // 活动使用范围，默认选择全店铺
                    goodsList: [], // 活动绑定的商品集合，{Object[]}
                    publishStartTime: '', // 发放开始时间
                    publishEndTime: '', // 发放结束时间
                    publishTotalCount: '', // 发放总数量
                    perUserReceiveCount: '', // 每人限领
                    condition: 0, // 使用条件（默认不限）
                    minusAmount: '', // 优惠券面额
                    orderAmount: '', // 订单条件金额
                    dateType: 2, // 日期类型（1-起止时间，2-生效天数）
                    effectDays: '', // 有效天数
                    startTime: '', // 使用开始时间
                    endTime: '', // 使用结束时间
                },
                pickerOptions: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 86400000;
                    }
                }
            };
        },

        computed: {
            // 是否作用于全店铺商品，否则为定向商品满立减
            forAllGoods() {
                return this.formData.range === '1';
            },

            condition() {
                return this.formData.condition;
            },

            dateType() {
                return this.formData.dateType;
            }
        },

        watch: {
            // 体验优化：切换活动使用范围时校验选择商品数量
            forAllGoods(val) {
                if (val) this.$refs.form.validateField('goodsList');
            },

            // 体验优化：切换使用条件时检验订单金额输入框
            condition(val) {
                if (val === 0) {
                    this.$refs.form.validateField('orderAmount');
                }
            },

            // 体验优化：切换使用时间时校验对应表单项
            dateType(val) {
                if (val === 1) {
                    this.$refs.form.validateField('effectDays');
                } else {
                    this.$refs.form.validateField(['startTime', 'endTime']);
                }
            },
        },

        async created() {
            this.initCouponInfo();
        },

        methods: {
            /**
             * 编辑模式初始化数据
             */
            async initCouponInfo() {
                if (this.isEdit) {
                    try {
                        const { status, data } = await reqCouponInfo.http({
                            params: { code: this.couponCode }
                        });
                        if (status === 0) {
                            if (data.couponName) this.formData.couponName = data.couponName;
                            if (data.goodsRange) this.formData.range = String(data.goodsRange);
                            if (data.publishStartTime) this.formData.publishStartTime = new Date(data.publishStartTime * 1000);
                            if (data.publishEndTime) this.formData.publishEndTime = new Date(data.publishEndTime * 1000);
                            if (data.publishTotalCount) this.formData.publishTotalCount = data.publishTotalCount;
                            if (data.perUserReceiveCount) this.formData.perUserReceiveCount = data.perUserReceiveCount;
                            if (data.strategys) {
                                const [orderAmount, minusAmount] = data.strategys.split('-');
                                if (orderAmount === '0' || orderAmount === '0.01') {
                                    this.formData.condition = 0;
                                } else {
                                    this.formData.condition = 1;
                                    this.formData.orderAmount = Number(orderAmount);
                                }
                                this.formData.minusAmount = Number(minusAmount);
                            }
                            if (data.dateType) {
                                this.formData.dateType = Number(data.dateType);
                                if (data.dateType === 2) {
                                    this.formData.effectDays = Number(data.effectDays);
                                } else {
                                    this.formData.startTime = new Date(data.startTime * 1000);
                                    this.formData.endTime = new Date(data.endTime * 1000);
                                }
                            }
                        }
                    } catch (e) {
                        console.error('初始化数据失败！');
                    }
                }
            },

            /**
             * 返回
             */
            goBack() {
                this.$router.back();
            },

            /**
             * 表单提交
             */
            submitForm() {
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        if (this.isEdit) {
                            this.editCoupon(); // 编辑操作
                        } else {
                            this.addCoupon(); // 新建操作
                        }
                    }
                });
            },

            /**
             * 新建优惠券
             * @return {Promise<void>}
             */
            async addCoupon() {
                const { status, data } = await reqAddCoupon.http({
                    data: this.serializeForm()
                });
                if (status === 0) {
                    this.$router.replace({
                        name: 'CouponSuccess',
                        query: { couponCode: data.code }
                    });
                }
            },

            /**
             * 编辑优惠券
             * @return {Promise<void>}
             */
            async editCoupon() {
                const { status } = await reqEditCoupon.http({
                    data: this.serializeForm()
                });
                if (status === 0) {
                    // 查看活动详情
                    this.$router.push({
                        name: 'CouponDetail',
                        query: {
                            couponCode: this.couponCode
                        }
                    });
                }
            },

            /**
             * 序列化表单
             */
            serializeForm() {
                const requestData = {
                    type: '12', // 固定值，表示满减活动
                    couponName: this.formData.couponName,
                    dateType: this.formData.dateType,
                    goodsRange: this.formData.range,
                    publishStartTime: Math.floor(this.formData.publishStartTime / 1000),
                    publishEndTime: Math.floor(this.formData.publishEndTime / 1000),
                    publishTotalCount: this.formData.publishTotalCount,
                    perUserReceiveCount: this.formData.perUserReceiveCount,

                    // 注意：当使用条件选择“不限”时，该字段 "-" 之前传的是 "0"，临时改动为 "0.01"，后期可能会有改动
                    strategys: `${this.formData.condition === 0 ? '0.01' : this.formData.orderAmount}-${this.formData.minusAmount}`,
                };

                if (this.formData.dateType === 2) {
                    requestData.effectDays = String(this.formData.effectDays);
                } else {
                    requestData.startTime = Math.floor(this.formData.startTime / 1000);
                    requestData.endTime = Math.floor(this.formData.endTime / 1000);
                }

                if (this.isEdit) {
                    requestData.code = this.couponCode;
                } else {
                    requestData.goodSns = this.forAllGoods ? 'ALL' : this.formData.goodsList.map(item => item.sku).join(',');
                }

                return requestData;
            },

            /**
             * 添加商品
             */
            addGoods() {
                addGoods({
                    cacheList: this.formData.goodsList,
                    getData: async (params) => {
                        const { status, data } = await reqGoodsList.http({
                            params: {
                                goodSnList: params.sku,
                                goodSpuList: params.spu,
                                platformCategoryIdList: params.category,
                                goodsPriceMin: params.minPrice,
                                goodsPriceMax: params.maxPrice,
                                pageNo: params.pageNo,
                                pageSize: params.pageSize,
                            }
                        });
                        if (status === 0) {
                            return {
                                totalCount: data.totalCount,
                                goodsList: (data.list || []).map(item => ({
                                    sku: item.goodSn,
                                    mainImage: (item.goodsMainImage || {}).thumbUrl,
                                    title: item.goodsTitle,
                                    stock: item.stockNum,
                                    price: item.goodsPrice,
                                    goodsStatus: item.goodsStatusList[0].goodsStatus
                                }))
                            };
                        }
                        return null;
                    }
                }).then((goodsList) => {
                    this.formData.goodsList = goodsList;
                    this.$refs.form.validateField('goodsList');
                });
            },

            /**
             * 删除商品
             */
            deleteGoods() {
                deleteGoods({
                    getData: ({ pageNo, pageSize }) => {
                        // 获取本地已绑定商品数据，且模拟分页
                        const cacheList = this.formData.goodsList;
                        return {
                            totalCount: cacheList.length,
                            goodsList: cacheList.slice((pageNo - 1) * pageSize, pageSize),
                        };
                    }
                }).then((goodsList) => {
                    if (goodsList.length > 0) {
                        this.formData.goodsList = this.formData.goodsList.filter(item => !goodsList.some(goodsItem => goodsItem.sku === item.sku));
                        this.$refs.form.validateField('goodsList');
                    }
                });
            },

            /**
             * 查看商品
             */
            viewGoods() {
                viewGoods({
                    getData: async ({ pageNo, pageSize }) => {
                        const { status, data } = await reqGoodsListBound.http({
                            params: {
                                code: this.couponCode,
                                pageNo,
                                pageSize,
                            }
                        });
                        if (status === 0) {
                            return {
                                totalCount: data.totalCount,
                                goodsList: (data.list || []).map(item => ({
                                    sku: item.goodSn,
                                    mainImage: (item.goodsMainImage || {}).thumbUrl,
                                    title: item.goodsTitle
                                }))
                            };
                        }
                        return null;
                    }
                });
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .fieldset {
        padding: 30px 17% 20px 0;
        line-height: 22px;
    }

    .explain {
        margin-bottom: 20px;
        line-height: 22px;
    }

    .title {
        line-height: 40px;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .caption {
        position: relative;
        height: 50px;
        padding-left: 35px;
        margin: 0 -20px;
        line-height: 50px;
        font-size: 18px;
        background-color: #fafafa;

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }
    }

    .inlineHint {
        display: inline-block;
        margin-left: 17px;
        color: var(--color-text-regular);
    }

    .btnAddGoods {
        margin-right: 7px;
    }

    .smallInput {
        display: inline-block;
        width: 100px;
    }

    .middleInput {
        display: inline-block;
        width: 220px;
    }

    .formBtns {
        padding: 30px 0 100px;
        text-align: center;
    }

    .formBtnItem {
        width: 120px;
        margin: 0 15px;
    }

    .mr7 {
        margin-right: 7px;
    }

    .ml7 {
        margin-left: 7px;
    }

    .inlineFormItem {
        display: inline-block;
    }

    .content {
        padding: 30px 0 20px;
        line-height: 22px;
    }

    .radioLine {
        line-height: 40px;
        margin: 0 0 20px;

        &:last-of-type {
            margin-bottom: 0;
        }
    }
</style>
