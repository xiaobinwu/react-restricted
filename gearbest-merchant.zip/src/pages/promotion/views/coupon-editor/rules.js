/**
 * 优惠券表单验证规则
 * Created by Jiazhan Li on 2019/1/3.
 */

export default function getRules(context) {
    return {
        // 优惠券名称
        couponName: [{
            required: true,
            message: '请输入优惠券名称',
            trigger: 'blur'
        }, {
            validator(rule, value, callback) {
                if (/[\u4e00-\u9fa5]+/.test(value)) {
                    callback('优惠券名称不能包含中文');
                }
                callback();
            },
            trigger: 'blur'
        }],

        // 活动商品，仅在新建活动且针对多商品的时候需要校验
        goodsList: [{
            required: true,
            validator(rule, value, callback) {
                const maxLength = 200;
                if (!context.isEdit && !context.forAllGoods) {
                    if (context.formData.goodsList.length < 1) {
                        callback(new Error('请至少选择一个商品'));
                    } else if (context.formData.goodsList.length > maxLength) {
                        callback(new Error(`单次添加不能超过${maxLength}个商品，如需添加更多商品，请在活动创建成功后前往活动详情页继续添加`));
                    }
                }
                callback();
            },
        }],

        // 发放开始时间
        publishStartTime: [{
            type: 'date',
            required: true,
            message: '请选择发放开始时间',
            trigger: 'change'
        }, {
            validator(rule, value, callback) {
                if (context.formData.publishEndTime) {
                    context.$refs.form.validateField('publishEndTime');
                }
                callback();
            },
            trigger: 'change'
        }],

        // 发放结束时间（必须大于开始时间）
        publishEndTime: [{
            type: 'date',
            required: true,
            message: '请选择发放结束时间',
            trigger: 'change'
        }, {
            validator(rule, value, callback) {
                if (value <= context.formData.publishStartTime) {
                    callback('发放结束时间必须大于开始时间');
                }
                callback();
            },
            trigger: 'change'
        }],

        // 发放总数量
        publishTotalCount: [{
            type: 'integer',
            required: true,
            min: 1,
            message: '请输入发放总数量（正整数）',
            trigger: 'blur'
        }],

        // 每人限领
        perUserReceiveCount: [{
            type: 'integer',
            required: true,
            min: 1,
            message: '请输入每人限领次数（正整数）',
            trigger: 'blur'
        }],

        // 优惠券面额
        minusAmount: [{
            type: 'integer',
            required: true,
            min: 1,
            message: '请输入正整数金额',
            trigger: 'blur'
        }, {
            type: 'integer',
            max: 99999,
            message: '金额不能大于99999',
            trigger: 'blur'
        }, {
            validator(rule, value, callback) {
                if (context.formData.orderAmount) {
                    context.$refs.form.validateField('orderAmount');
                }
                callback();
            },
            trigger: 'blur'
        }],

        // 订单金额
        orderAmount: [{
            validator(rule, value, callback) {
                if (context.formData.condition === 1 && (!Number.isInteger(value) || value <= context.formData.minusAmount)) {
                    callback('请输入大于优惠券面额的正整数');
                }
                if (context.formData.condition === 1 && value > 99999) {
                    callback('金额不能大于99999');
                }
                callback();
            },
            trigger: 'blur'
        }],

        // 有效天数
        effectDays: [{
            validator(rule, value, callback) {
                if (context.formData.dateType === 2 && (!Number.isInteger(value) || value <= 0)) {
                    callback('请输入有效天数（正整数）');
                }
                callback();
            },
            trigger: 'blur'
        }],

        // 使用开始时间
        startTime: [{
            validator(rule, value, callback) {
                if (context.formData.dateType === 1 && !(value instanceof Date)) {
                    callback('请选择使用开始时间');
                }
                if (context.formData.dateType === 1 && value <= context.formData.publishStartTime) {
                    callback('使用开始时间必须大于发放开始时间');
                }
                if (context.formData.endTime) {
                    context.$refs.form.validateField('endTime');
                }
                callback();
            },
            trigger: 'change'
        }],

        // 使用结束时间（必须大于开始时间）
        endTime: [{
            validator(rule, value, callback) {
                if (context.formData.dateType === 1 && value <= context.formData.startTime) {
                    callback('使用结束时间必须大于开始时间');
                }
                callback();
            },
            trigger: 'change'
        }],
    };
}
