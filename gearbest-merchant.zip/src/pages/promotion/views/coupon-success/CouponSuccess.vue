<template>
    <div :class="$style.container">
        <progress-bar :active="1" :steps="stepsData"></progress-bar>
        <div :class="$style.center">
            <i :class="$style.icon" class="icon-success"></i>
            <h2 :class="$style.title">店铺优惠券创建成功</h2>
            <div :class="$style.youcando">
                <span>您可以：</span>
                <el-button type="text" @click="viewDetail">查看活动详情</el-button>
                <span :class="$style.splitLine">|</span>
                <el-button type="text" @click="editHandle">修改该活动</el-button>
            </div>
            <el-button :class="$style.button" type="primary" @click="gotoIndex">返回优惠券列表</el-button>
        </div>
    </div>
</template>

<script>
    import ProgressBar from '@/components/ProgressBar';

    export default {
        name: 'CouponSuccess',
        components: {
            ProgressBar,
        },

        data() {
            return {
                stepsData: ['1.设置活动信息', '2.完成'],
                couponCode: this.$route.query.couponCode
            };
        },

        methods: {
            /**
             * 查看详情
             */
            viewDetail() {
                this.$router.push({
                    name: 'CouponDetail',
                    query: { couponCode: this.couponCode }
                });
            },

            /**
             * 编辑操作
             */
            handleEdit() {
                this.$router.push({
                    name: 'CouponEdit',
                    query: { couponCode: this.couponCode }
                });
            },

            /**
             * 返回活动首页
             */
            gotoIndex() {
                this.$router.push({
                    name: 'StoreActivity',
                    query: { type: 'coupon' }
                });
            }
        },
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .center {
        min-height: 656px;
        padding: 100px 0;
        text-align: center;
    }

    .icon {
        display: inline-block;
        margin: 0 auto 20px;
        font-size: 60px;
        color: var(--color-success);
    }

    .title {
        font-size: 18px;
        line-height: 25px;
        margin-bottom: 10px;
    }

    .youcando {
        margin-bottom: 30px;
        color: var(--color-text-regular);
    }

    .splitLine {
        display: inline-block;
        margin: 0 10px;
    }

    .button {
        min-width: 300px;
    }
</style>
