<template>
    <div v-loading="loading" :class="$style.container">
        <h1 :class="$style.title">优惠券活动详情</h1>
        <h2 :class="$style.caption">优惠券详情</h2>
        <div :class="$style.content">
            <dl><dt>活动状态：</dt><dd :class="$style.statusName">{{ couponStatusText }}</dd></dl>
            <dl><dt>优惠券名称：</dt><dd>{{ couponName }}</dd></dl>
            <dl><dt>发放时间：</dt><dd>{{ publishStartTime }}<br>{{ publishEndTime }}</dd></dl>
            <dl><dt>活动范围：</dt><dd>{{ rangeText }}</dd></dl>
            <dl v-if="!forAllGoods">
                <dt>活动使用范围：</dt>
                <dd>已选择<el-button :class="$style.textBtn" type="text" @click="clickGoodsCount">{{ goodsCount }}</el-button>件商品</dd>
            </dl>
        </div>
        <h2 :class="$style.caption">优惠券促销规则</h2>
        <div :class="$style.content">
            <dl><dt>领取条件：</dt><dd>买家可通过“领取按钮”领取优惠券</dd></dl>
            <dl><dt>优惠券面额：</dt><dd>{{ couponPrice }}</dd></dl>
            <dl><dt>发放总数量：</dt><dd>{{ publishTotalCount }}</dd></dl>
            <dl><dt>每人限领：</dt><dd>{{ perUserReceiveCount }}</dd></dl>
        </div>
        <h2 :class="$style.caption">优惠券使用规则设置</h2>
        <div :class="$style.content">
            <dl><dt>使用条件：</dt><dd>{{ useCondition }}</dd></dl>
            <dl><dt>使用时间：</dt><dd>{{ useTime }}</dd></dl>
        </div>
        <div :class="$style.btnGroup">
            <el-button :class="$style.btnItem" @click="gotoIndex">返回列表</el-button>
            <el-button v-if="allowEdit && !forAllGoods" :class="$style.btnItem" @click="addGoods">继续添加商品</el-button>
            <el-button v-if="allowEdit && !forAllGoods" :class="$style.btnItem" @click="deleteGoods">删除已选商品</el-button>
            <el-button v-if="allowEdit" :class="$style.btnItem" type="primary" @click="editCoupon">修改活动信息</el-button>
        </div>
    </div>
</template>

<script>
    import Map from '@promotion/utils/map';
    import { dateFormat } from '@/assets/js/utils/date';
    import { addGoods, deleteGoods, viewGoods } from '@promotion/components/goods-selector';
    import { reqGoodsList } from '@promotion/services/common';
    import {
        reqCouponInfo, // 获取优惠券详情
        reqCheckExistSku, // 检查商品是否已经绑定过活动
        reqGoodsListBound, // 请求已绑定的商品列表
        reqDeleteSku, // 活动删除绑定商品
        reqBindingSku // 活动绑定商品
    } from '@promotion/services/coupon';

    const mapOfStatus = new Map('couponStatus');

    export default {
        name: 'CouponDetail',
        data() {
            return {
                loading: true,
                couponCode: this.$route.query.couponCode, // 优惠券编码
                couponStatus: '', // 优惠券状态
                couponName: '', // 优惠券名称
                publishStartTime: '', // 发放开始时间
                publishEndTime: '', // 发放结束时间
                range: '1', // 活动范围
                goodsCount: 0, // 当前活动绑定的商品个数
                publishTotalCount: '', // 发放总数量
                perUserReceiveCount: '', // 每人限领
                useTime: '', // 使用时间
                strategys: '', // 优惠策略
            };
        },

        computed: {
            // 使用条件
            useCondition() {
                const amount = this.strategys.split('-')[0];
                if (amount === '0') return '不限';
                if (amount !== '') return `订单金额满US $${amount}`;
                return '???';
            },

            // 优惠券面额
            couponPrice() {
                const amount = this.strategys.split('-')[1];
                if (amount && amount !== '') return `US $${amount}`;
                return '???';
            },

            // 活动范围
            rangeText() {
                return this.range === '1' ? '针对店铺内所有商品' : '针对店铺内定向商品';
            },

            // 活动状态名
            couponStatusText() {
                return mapOfStatus.getInfoByCode(this.couponStatus).lang;
            },

            // 是否针对所有商品（全店铺）
            forAllGoods() {
                return this.range === '1';
            },

            // 只有当活动是未开始状态下才允许编辑活动或商品
            allowEdit() {
                return this.couponStatus === mapOfStatus.getInfoByName('NOT_STARTED').code;
            }
        },

        created() {
            this.getCouponInfo(); // 获取优惠券基本信息
        },

        methods: {
            /**
             * 获取优惠券基本信息
             */
            async getCouponInfo() {
                const { status, data } = await reqCouponInfo.http({
                    params: {
                        code: this.couponCode
                    }
                });

                if (status === 0) {
                    this.loading = false;
                    this.couponStatus = String(data.status);
                    this.couponName = data.couponName;
                    this.publishStartTime = dateFormat(data.publishStartTime);
                    this.publishEndTime = dateFormat(data.publishEndTime);
                    this.range = String(data.goodsRange);
                    this.publishTotalCount = data.publishTotalCount;
                    this.perUserReceiveCount = data.perUserReceiveCount;
                    this.strategys = data.strategys || '';
                    this.useTime = Number(data.dateType) === 1
                        ? `${dateFormat(data.startTime)} 到 ${dateFormat(data.endTime)}`
                        : `买家领取成功时开始的${data.effectDays}天内`;

                    /**
                     * 获取当前活动绑定的商品个数
                     * 随便请求哪一页的数据都可以，我们要的是返回的 totalCount 字段
                     */
                    if (this.range === '2') {
                        this.goodsCount = Number((await this.getGoodsListBound({
                            pageNo: 1,
                            pageSize: 10
                        })).totalCount || 0);
                    }
                }
            },

            /**
             * 返回活动首页
             */
            gotoIndex() {
                this.$router.push({
                    name: 'StoreActivity',
                    query: { type: 'coupon' }
                });
            },

            /**
             * 跳转到活动编辑页面
             */
            editCoupon() {
                this.$router.push({
                    name: 'CouponEdit',
                    query: { couponCode: this.couponCode }
                });
            },

            /**
             * 继续添加商品
             */
            addGoods() {
                addGoods({
                    getData: async (params) => {
                        const { totalCount = 0, goodsList = [] } = await this.getGoodsList(params);
                        const skusUnbound = await this.getSkusUnbound(goodsList); // 返回已绑定的SKU
                        return {
                            totalCount,
                            goodsList: goodsList.map(item => ({
                                selected: skusUnbound.indexOf(item.goodSn) >= 0, // 这个值将决定商品能不能被选中
                                sku: item.goodSn,
                                mainImage: (item.goodsMainImage || {}).thumbUrl,
                                title: item.goodsTitle,
                                stock: item.stockNum,
                                price: item.goodsPrice,
                                goodsStatus: item.goodsStatusList[0].goodsStatus
                            }))
                        };
                    }
                }).then(async (goodsList) => {
                    // 绑定商品到活动
                    if (goodsList.length > 0) {
                        const { status } = await reqBindingSku.http({
                            data: {
                                code: this.couponCode,
                                goodSns: goodsList.map(item => item.sku).join(',')
                            }
                        });
                        if (status === 0) {
                            this.goodsCount += goodsList.length; // 绑定成功后累加计数
                        }
                    }
                });
            },

            /**
             * 获取店铺商品列表
             * @return {object}
             */
            async getGoodsList(params) {
                const { status, data } = await reqGoodsList.http({
                    params: {
                        goodSnList: params.sku,
                        goodSpuList: params.spu,
                        platformCategoryIdList: params.category,
                        goodsPriceMin: params.minPrice,
                        goodsPriceMax: params.maxPrice,
                        pageNo: params.pageNo,
                        pageSize: params.pageSize,
                    }
                });
                if (status === 0) {
                    return {
                        totalCount: data.totalCount,
                        goodsList: data.list
                    };
                }
                return {};
            },

            /**
             * 过滤商品列表，返回已绑定的SKU
             * @return {Array<string>}
             */
            async getSkusUnbound(goodsList = []) {
                const { status, data } = await reqCheckExistSku.http({
                    data: {
                        code: this.couponCode,
                        goodSns: goodsList.map(item => item.goodSn).join(',')
                    }
                });
                if (status === 0) return data || [];
                return [];
            },

            /**
             * 点击已选择商品数字时，仅在活动未开始时才允许删除商品，否则查看商品
             */
            clickGoodsCount() {
                if (this.allowEdit) {
                    this.deleteGoods();
                } else {
                    this.viewGoods();
                }
            },

            /**
             * 删除商品
             */
            deleteGoods() {
                deleteGoods({
                    getData: this.getGoodsListBound
                }).then(async (goodsList) => {
                    if (goodsList.length > 0) {
                        const { status } = await reqDeleteSku.http({
                            data: {
                                code: this.couponCode,
                                goodSns: goodsList.map(item => item.sku).join(',')
                            }
                        });
                        if (status === 0) {
                            // 删除成功后更新商品个数
                            this.goodsCount -= goodsList.length;
                        } else if (status === 52108) {
                            this.$message({
                                type: 'error',
                                message: '活动商品不能为空'
                            });
                        }
                    }
                });
            },

            /**
             * 查看商品
             */
            viewGoods() {
                viewGoods({
                    getData: this.getGoodsListBound
                });
            },

            /**
             * 获取当前活动绑定的商品
             * @return {Promise<Object>}
             */
            async getGoodsListBound({ pageNo, pageSize }) {
                const { status, data } = await reqGoodsListBound.http({
                    params: {
                        code: this.couponCode,
                        pageNo,
                        pageSize,
                    }
                });
                if (status === 0) {
                    return {
                        totalCount: data.totalCount || 0,
                        goodsList: (data.list || []).map(item => ({
                            sku: item.goodSn,
                            mainImage: (item.goodsMainImage || {}).thumbUrl,
                            title: item.goodsTitle,
                            stock: item.stock,
                            price: item.goodsPrice
                        }))
                    };
                }
                return {};
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .title {
        line-height: 25px;
        font-size: 18px;
        margin-bottom: 20px;
    }

    .caption {
        position: relative;
        height: 50px;
        padding-left: 35px;
        margin: 0 -20px;
        line-height: 50px;
        font-size: 18px;
        background-color: #fafafa;

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }
    }

    .content {
        padding: 25px 0;

        dl {
            position: relative;
            min-height: 30px;
            padding-left: 200px;
            line-height: 30px;
        }

        dt {
            position: absolute;
            top: 0;
            left: 0;
            width: 190px;
            text-align: right;
            color: var(--color-text-regular);
        }
    }

    .statusName {
        color: var(--color-warning);
    }

    .btnGroup {
        padding: 50px 0 100px;
        text-align: center;
    }

    .btnItem {
        width: 120px;
        margin: 0 15px;
    }

    .textBtn {
        padding: 0 2px;
    }
</style>
