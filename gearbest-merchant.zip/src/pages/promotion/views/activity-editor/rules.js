/**
 * 满立减表单验证规则
 * Created by Jiazhan Li on 2019/1/3.
 */

export default function getRules(context) {
    return {
        // 活动名称
        activityName: [{
            required: true,
            message: '请输入活动名称',
            trigger: 'blur'
        }, {
            validator(rule, value, callback) {
                if (/[\u4e00-\u9fa5]+/.test(value)) {
                    callback('活动名称不能包含中文');
                }
                callback();
            },
            trigger: 'blur'
        }],

        // 活动开始时间
        startTime: [{
            type: 'date',
            required: true,
            message: '请选择活动开始时间',
            trigger: 'change'
        }, {
            validator(rule, value, callback) {
                if (context.formData.endTime) {
                    context.$refs.form.validateField('endTime');
                }
                callback();
            },
            trigger: 'change'
        }],

        // 活动结束时间（必须大于开始时间）
        endTime: [{
            type: 'date',
            required: true,
            message: '请选择活动结束时间',
            trigger: 'change'
        }, {
            validator(rule, value, callback) {
                if (value <= context.formData.startTime) {
                    callback('活动结束时间必须大于开始时间');
                }
                callback();
            },
            trigger: 'change'
        }],

        // 活动满减条件
        condition: [{
            validator(rule, value, callback) {
                const { isActived, orderAmount, minusAmount } = value;
                if (isActived) {
                    if (orderAmount <= 0 || minusAmount <= 0 || !Number.isInteger(orderAmount) || !Number.isInteger(minusAmount)) {
                        callback('请输入正整数金额');
                    } else if (orderAmount > 99999 || minusAmount > 99999) {
                        callback('金额不能大于99999');
                    } else if (orderAmount <= minusAmount) {
                        callback('立减金额必须小于买家消费金额');
                    } else {
                        callback();
                    }
                }
            },
            trigger: 'blur'
        }],

        // 活动商品，仅在新建活动且针对多商品的时候需要校验
        goodsList: [{
            required: true,
            validator(rule, value, callback) {
                const maxLength = 200;
                if (!context.isEdit && !context.forAllGoods) {
                    if (context.formData.goodsList.length < 1) {
                        callback(new Error('请至少选择一个商品'));
                    } else if (context.formData.goodsList.length > maxLength) {
                        callback(new Error(`单次添加不能超过${maxLength}个商品，如需添加更多商品，请在活动创建成功后前往活动详情页继续添加`));
                    }
                }
                callback();
            },
        }],
    };
}
