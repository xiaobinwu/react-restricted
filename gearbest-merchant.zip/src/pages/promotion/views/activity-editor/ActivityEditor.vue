<template>
    <div :class="$style.container">
        <progress-bar :active="0" :steps="stepsData"></progress-bar>
        <p :class="$style.explain">活动一旦开始不能编辑活动信息，只能停止活动；满减订单金额不包含运费</p>

        <el-form ref="form" :model="formData" :rules="rules" label-width="20.48%">
            <h2 :class="$style.caption">活动基本信息</h2>

            <div :class="$style.fieldset">
                <el-form-item prop="activityName" label="活动名称：">
                    <el-input v-model="formData.activityName" placeholder="买家可见，最多输入32个字符" maxlength="32"></el-input>
                </el-form-item>

                <el-form-item prop="startTime" label="活动开始时间：">
                    <el-date-picker v-model="formData.startTime" :picker-options="pickerOptions"
                                    type="datetime" placeholder="选择日期时间"></el-date-picker>
                </el-form-item>

                <el-form-item prop="endTime" label="活动结束时间：">
                    <el-date-picker v-model="formData.endTime" :picker-options="pickerOptions"
                                    type="datetime" placeholder="选择日期时间"></el-date-picker>
                    <span :class="$style.inlineHint">活动时间为UTC+8（北京时间）</span>
                </el-form-item>
            </div>

            <h2 :class="$style.caption">促销规则</h2>

            <div :class="$style.fieldset">
                <el-form-item v-if="!isEdit" label="活动范围：" required>
                    <el-radio-group v-model="formData.activityRange">
                        <el-radio label="1">全店铺满立减</el-radio>
                        <el-radio label="2">商品满立减</el-radio>
                    </el-radio-group>
                </el-form-item>

                <el-form-item label="选择商品：" prop="goodsList">
                    <div v-if="forAllGoods">已选择全店商品</div>
                    <div v-if="!forAllGoods && !isEdit">
                        <el-button :class="$style.btnAddGoods" type="primary" size="small" @click="addGoods">添加商品</el-button>
                        <span>已选择商品<el-button type="text" @click="deleteGoods">{{ formData.goodsList.length }}</el-button>件</span>
                    </div>
                    <div v-if="!forAllGoods && isEdit"><el-button type="text" @click="viewGoods">查看已选商品</el-button></div>
                </el-form-item>

                <el-form-item label="满减条件：" prop="condition" required>
                    <span>订单满</span>
                    <el-input v-model.number="formData.condition.orderAmount" :class="$style.amountInput" type="number"></el-input>
                    <span>美元 &nbsp;&nbsp;&nbsp; 减</span>
                    <el-input v-model.number="formData.condition.minusAmount" :class="$style.amountInput" type="number"></el-input>
                    <span>美元</span><br>
                    <el-checkbox v-model="formData.isAdditive">活动可累加 （即：当促销规则为满100减10时，则满200减20，满300减30，以此类推，上不封顶）</el-checkbox>
                </el-form-item>

                <el-form-item label="优惠券：">
                    <el-radio-group v-model="formData.isCoupon">
                        <el-radio :label="false">不可使用</el-radio>
                        <el-radio :label="true">仍可使用</el-radio>
                    </el-radio-group>
                </el-form-item>
            </div>
        </el-form>

        <div :class="$style.formBtns">
            <el-button :class="$style.formBtnItem" @click="goBack">返回</el-button>
            <el-button :class="$style.formBtnItem" type="primary" @click="submitForm()">提交</el-button>
        </div>
    </div>
</template>

<script>
    import ProgressBar from '@/components/ProgressBar';
    import { addGoods, deleteGoods, viewGoods } from '@promotion/components/goods-selector';
    import { reqGoodsList } from '@promotion/services/common';
    import {
        reqAddActivity,
        reqActivityInfo,
        reqEditActivity,
        reqGoodsListBound
    } from '@promotion/services/activity';
    import getRules from './rules';

    export default {
        name: 'ActivityEditor',
        components: {
            ProgressBar,
        },

        data() {
            return {
                stepsData: ['1.设置活动信息', '2.完成'],
                activityId: this.$route.query.activityId, // 活动ID（编辑模式下有用）
                isEdit: this.$route.name === 'ActivityEdit', // 是否是编辑模式，否则为新建
                rules: getRules(this), // 表单的校验规则放在另外一个文件管理（传入上下文对象）
                formData: {
                    activityName: '', // 活动名称
                    startTime: '', // 活动开始时间
                    endTime: '', // 活动结束时间
                    activityRange: '1', // 活动范围，默认选择全店铺
                    isAdditive: true, // 活动是否可累加（默认可累加）
                    isCoupon: false, // 是否可使用优惠券（默认可使用）
                    goodsList: [], // 活动绑定的商品集合，{Object[]}

                    // 满减条件
                    condition: {
                        orderAmount: '', // 订单消费金额，需超过消费金额才能实现满减
                        minusAmount: '', // 订单满足消费金额后扣减的金额
                        isActived: false, // 这个变量控制是否激活满减条件的验证规则
                    },
                },
                pickerOptions: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 86400000;
                    }
                }
            };
        },

        computed: {
            // 是否作用于全店铺商品，否则为定向商品满立减
            forAllGoods() {
                return this.formData.activityRange === '1';
            }
        },

        watch: {
            // 体验优化：切换活动使用范围时校验选择商品数量
            forAllGoods(val) {
                if (val) this.$refs.form.validateField('goodsList');
            }
        },

        created() {
            this.initActivityInfo();
        },

        methods: {
            /**
             * 编辑模式初始化数据
             */
            async initActivityInfo() {
                if (this.isEdit) {
                    try {
                        const { status, data } = await reqActivityInfo.http({
                            params: { activityId: this.activityId }
                        });
                        if (status === 0) {
                            if (data.activityName) this.formData.activityName = data.activityName;
                            if (data.startTime) this.formData.startTime = new Date(data.startTime * 1000);
                            if (data.endTime) this.formData.endTime = new Date(data.endTime * 1000);
                            if (data.activityRange) this.formData.activityRange = String(data.activityRange);
                            if (data.activityRules && data.activityRules[0]) {
                                this.formData.condition.orderAmount = Number(data.activityRules[0].meetAmount) || 0;
                                this.formData.condition.minusAmount = Number(data.activityRules[0].preferentialValue) || 0;
                            }
                            this.formData.isAdditive = !Number(data.isLimit);
                            this.formData.isCoupon = !!Number(data.isCoupon);
                            this.formData.condition.isActived = true; // 对于编辑页面可以提前激活该字段的验证规则
                        }
                    } catch (e) {
                        console.error('初始化数据失败！');
                    }
                }
            },

            /**
             * 返回
             */
            goBack() {
                this.$router.back();
            },

            /**
             * 表单提交
             */
            submitForm() {
                this.formData.condition.isActived = true; // 在提交表单的时候才激活满减条件的校验规则，增强用户体验
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        if (this.isEdit) {
                            this.editActivity(); // 编辑操作
                        } else {
                            this.addActivity(); // 新建操作
                        }
                    }
                });
            },

            /**
             * 新建活动
             * @return {Promise<void>}
             */
            async addActivity() {
                const { status, data } = await reqAddActivity.http({
                    data: this.serializeForm()
                });

                if (status === 0) {
                    this.$router.replace({
                        name: 'ActivitySuccess',
                        query: { activityId: data.activityId }
                    });
                }
            },

            /**
             * 编辑活动
             * @return {Promise<void>}
             */
            async editActivity() {
                const { status } = await reqEditActivity.http({
                    data: this.serializeForm()
                });
                if (status === 0) {
                    // 查看活动详情
                    this.$router.push({
                        name: 'ActivityDetail',
                        query: {
                            activityId: this.activityId
                        }
                    });
                }
            },

            /**
             * 序列化表单
             */
            serializeForm() {
                const requestData = {
                    type: 1, // 固定值，表示满减活动
                    activityName: this.formData.activityName,
                    startTime: Math.floor(this.formData.startTime / 1000),
                    endTime: Math.floor(this.formData.endTime / 1000),
                    activityRange: this.formData.activityRange,
                    activityRules: [{
                        // 满减条件
                        preferentialType: '0',
                        meetAmount: String(this.formData.condition.orderAmount),
                        preferentialValue: String(this.formData.condition.minusAmount),
                    }],
                    activityConditions: [{
                        // 活动是否封顶（可累加）
                        paramId: 'isLimit',
                        paramName: 'isLimit',
                        paramValue: this.formData.isAdditive ? '0' : '1'
                    }, {
                        // 是否可使用优惠券
                        paramId: 'isCoupon',
                        paramName: 'isCoupon',
                        paramValue: this.formData.isCoupon ? '1' : '0'
                    }],
                };

                if (this.isEdit) {
                    requestData.activityId = this.activityId;
                } else {
                    requestData.goodSns = this.formData.goodsList.map(item => item.sku).join(',');
                }

                return requestData;
            },

            /**
             * 添加商品
             */
            addGoods() {
                addGoods({
                    cacheList: this.formData.goodsList,
                    getData: async (params) => {
                        const { status, data } = await reqGoodsList.http({
                            params: {
                                goodSnList: params.sku,
                                goodSpuList: params.spu,
                                platformCategoryIdList: params.category,
                                goodsPriceMin: params.minPrice,
                                goodsPriceMax: params.maxPrice,
                                pageNo: params.pageNo,
                                pageSize: params.pageSize,
                            }
                        });
                        if (status === 0) {
                            return {
                                totalCount: data.totalCount,
                                goodsList: (data.list || []).map(item => ({
                                    sku: item.goodSn,
                                    mainImage: (item.goodsMainImage || {}).thumbUrl,
                                    title: item.goodsTitle,
                                    stock: item.stockNum,
                                    price: item.goodsPrice,
                                    goodsStatus: item.goodsStatusList[0].goodsStatus
                                }))
                            };
                        }
                        return null;
                    }
                }).then((goodsList) => {
                    this.formData.goodsList = goodsList;
                    this.$refs.form.validateField('goodsList');
                });
            },

            /**
             * 删除商品
             */
            deleteGoods() {
                deleteGoods({
                    getData: ({ pageNo, pageSize }) => {
                        // 获取本地已绑定商品数据，且模拟分页
                        const cacheList = this.formData.goodsList;
                        return {
                            totalCount: cacheList.length,
                            goodsList: cacheList.slice((pageNo - 1) * pageSize, pageSize),
                        };
                    }
                }).then((goodsList) => {
                    if (goodsList.length > 0) {
                        this.formData.goodsList = this.formData.goodsList.filter(item => !goodsList.some(goodsItem => goodsItem.sku === item.sku));
                        this.$refs.form.validateField('goodsList');
                    }
                });
            },

            /**
             * 查看商品
             */
            viewGoods() {
                viewGoods({
                    getData: async ({ pageNo, pageSize }) => {
                        const { status, data } = await reqGoodsListBound.http({
                            params: {
                                activityId: this.activityId,
                                pageNo,
                                pageSize,
                            }
                        });
                        if (status === 0) {
                            return {
                                totalCount: data.totalCount,
                                goodsList: (data.list || []).map(item => ({
                                    sku: item.goodSn,
                                    mainImage: (item.goodsMainImage || {}).thumbUrl,
                                    title: item.goodsTitle
                                }))
                            };
                        }
                        return null;
                    }
                });
            },
        },
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 20px;
        background-color: var(--color-white);
    }

    .fieldset {
        padding: 30px 17% 20px 0;
        line-height: 22px;
    }

    .explain {
        margin-bottom: 20px;
        line-height: 22px;
    }

    .caption {
        position: relative;
        height: 50px;
        padding-left: 35px;
        margin: 0 -20px;
        line-height: 50px;
        font-size: 18px;
        background-color: #fafafa;

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }
    }

    .inlineHint {
        display: inline-block;
        margin-left: 17px;
        color: var(--color-text-regular);
    }

    .btnAddGoods {
        margin-right: 7px;
    }

    .amountInput {
        display: inline-block;
        width: 100px;
        margin: 0 7px;
    }

    .formBtns {
        padding: 40px 0 100px;
        text-align: center;
    }

    .formBtnItem {
        width: 120px;
        margin: 0 15px;
    }
</style>
