/**
 * Created by Jiazhan Li on 2018/12/27.
 */

import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    // 活动列表首页
    {
        path: '/promotion/store-activity',
        name: 'StoreActivity',
        meta: {
            title: 'base.menu.promotion.storeActivity',
        },
        component: () => asyncComponent(import('@promotion/views/store-activity/StoreActivity'))
    },

    // 添加满立减活动
    {
        path: '/promotion/activity/add',
        name: 'ActivityAdd',
        meta: {
            title: 'base.menu.promotion.addActivity',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/activity-editor/ActivityEditor'))
    },

    // 编辑满立减活动
    {
        path: '/promotion/activity/edit',
        name: 'ActivityEdit',
        meta: {
            title: 'base.menu.promotion.addActivity',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/activity-editor/ActivityEditor'))
    },

    // 添加满立减成功页面
    {
        path: '/promotion/activity/success',
        name: 'ActivitySuccess',
        meta: {
            title: 'base.menu.promotion.addActivity',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/activity-success/ActivitySuccess'))
    },

    // 满立减活动详情
    {
        path: '/promotion/activity/detail',
        name: 'ActivityDetail',
        meta: {
            title: 'base.menu.promotion.viewDetail',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/activity-detail/ActivityDetail'))
    },

    // 添加优惠券
    {
        path: '/promotion/coupon/add',
        name: 'CouponAdd',
        meta: {
            title: 'base.menu.promotion.addCoupon',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/coupon-editor/CouponEditor'))
    },

    // 编辑优惠券
    {
        path: '/promotion/coupon/edit',
        name: 'CouponEdit',
        meta: {
            title: 'base.menu.promotion.addCoupon',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/coupon-editor/CouponEditor'))
    },

    // 添加优惠券成功页面
    {
        path: '/promotion/coupon/success',
        name: 'CouponSuccess',
        meta: {
            title: 'base.menu.promotion.addCoupon',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/coupon-success/CouponSuccess'))
    },

    // 优惠券活动详情
    {
        path: '/promotion/coupon/detail',
        name: 'CouponDetail',
        meta: {
            title: 'base.menu.promotion.viewDetail',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/coupon-detail/CouponDetail'))
    },

    // 查看优惠券活动报告
    {
        path: '/promotion/coupon/report',
        name: 'CouponReport',
        meta: {
            title: 'base.menu.promotion.viewReport',
            focusMenu: '/promotion/store-activity',
        },
        component: () => asyncComponent(import('@promotion/views/coupon-report/CouponReport'))
    },
];
