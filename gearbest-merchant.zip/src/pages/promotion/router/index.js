/**
 * Created by Jiazhan Li on 2018/12/27.
 */

import Layout from '@/components/Layout';
import router from '@/assets/js/router';
import children from './routes';

// Layout 为布局组件
// 所有的视图挂在它下面
const routes = [
    {
        path: '/',
        component: Layout,
        redirect: '/promotion/store-activity',
        meta: {
            requireAuth: true,
        },
        children
    }
];

export default router({ routes });
