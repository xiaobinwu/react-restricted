/**
 * Created by Jiazhan Li on 2018/12/29.
 */

import Service from '@/assets/js/Service';

// 请求优惠券列表
export const reqCouponList = new Service({
    url: '/promotion/store-coupon-list',
    method: 'GET'
});

// 请求停用优惠券
export const reqInvalidCoupon = new Service({
    url: '/promotion/store-coupon-invalid',
    method: 'POST',
    showError: true,
    loading: true
});

// 添加优惠券
export const reqAddCoupon = new Service({
    url: '/promotion/store-coupon-add',
    method: 'POST',
    showError: true,
    loading: true
});

// 获取优惠券详情
export const reqCouponInfo = new Service({
    url: '/promotion/store-coupon-info',
    method: 'GET'
});

// 编辑优惠券
export const reqEditCoupon = new Service({
    url: '/promotion/store-coupon-edit',
    method: 'POST',
    showError: true,
    loading: true
});

// 请求已绑定的商品列表
export const reqGoodsListBound = new Service({
    url: '/promotion/store-coupon-sku-list',
    method: 'GET'
});

// 检查商品是否已经绑定过活动
export const reqCheckExistSku = new Service({
    url: '/promotion/store-coupon-sku-exist',
    method: 'POST'
});

// 活动删除绑定商品
export const reqDeleteSku = new Service({
    url: '/promotion/store-coupon-sku-delete',
    method: 'POST',
    showError: true,
    loading: true
});

// 活动绑定商品
export const reqBindingSku = new Service({
    url: '/promotion/store-coupon-sku-add',
    method: 'POST',
    showError: true,
    loading: true
});

// 查看优惠券使用概况
export const reqCouponView = new Service({
    url: '/promotion/store-coupon-view',
    method: 'GET'
});

// 查看优惠券使用日志列表
export const reqCouponLog = new Service({
    url: '/promotion/store-coupon-log',
    method: 'GET'
});
