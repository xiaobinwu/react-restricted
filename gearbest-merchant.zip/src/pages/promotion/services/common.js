/**
 * Created by Jiazhan Li on 2018/12/29.
 */

import Service from '@/assets/js/Service';

// 请求店铺商品列表
export const reqGoodsList = new Service({
    url: '/goods/approved-goods-list',
    method: 'GET',
});

// 请求产品分类
export const reqCategoryTree = new Service({
    url: '/goods/category-tree',
    method: 'GET',
});
