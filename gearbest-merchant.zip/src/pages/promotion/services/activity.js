/**
 * Created by Jiazhan Li on 2018/12/29.
 */

import Service from '@/assets/js/Service';

// 请求满减活动列表
export const reqActivityList = new Service({
    url: '/promotion/activity-list',
    method: 'GET'
});

// 请求停用活动
export const reqInvalidActivity = new Service({
    url: '/promotion/activity-invalid',
    method: 'POST',
    showError: true,
    loading: true
});

// 创建活动
export const reqAddActivity = new Service({
    url: '/promotion/activity-add',
    method: 'POST',
    showError: true,
    loading: true
});

// 获取活动详情
export const reqActivityInfo = new Service({
    url: '/promotion/activity-info',
    method: 'GET'
});

// 编辑活动
export const reqEditActivity = new Service({
    url: '/promotion/activity-edit',
    method: 'POST',
    showError: true,
    loading: true
});

// 请求已绑定的商品列表
export const reqGoodsListBound = new Service({
    url: '/promotion/activity-sku-list',
    method: 'GET'
});

// 检查商品是否已经绑定过活动
export const reqCheckExistSku = new Service({
    url: '/promotion/activity-sku-exist',
    method: 'POST'
});

// 活动删除绑定商品
export const reqDeleteSku = new Service({
    url: '/promotion/activity-sku-delete',
    method: 'POST',
    showError: true,
    loading: true
});

// 活动绑定商品
export const reqBindingSku = new Service({
    url: '/promotion/activity-sku-add',
    method: 'POST',
    showError: true,
    loading: true
});
