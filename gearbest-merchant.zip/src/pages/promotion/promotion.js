/**
 * Created by Jiazhan Li on 2018/12/26.
 */

import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import localLang from '@/lang/promotion';
import router from './router';

(async () => {
    const langInstance = await lang({ local: localLang, moduleName: 'promotion' });
    app({ lang: langInstance, router });
})();
