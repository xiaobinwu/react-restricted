/**
 * 店铺商品操作（添加、删除、查看）
 * Created by Jiazhan Li on 2019/1/6.
 */

import Vue from 'vue';
import GoodsSelector from './GoodsSelector';

const Component = Vue.extend(GoodsSelector);
let instance = null;

/**
 * 初始化实例
 * 挂载在新建的DOM元素上
 */
function initInstance() {
    instance = new Component({
        el: document.createElement('div')
    });
}

/**
 * 显示弹框
 * @param type          弹框类型 AddGoods | DeleteGoods | ViewGoods
 * @param options       扩展参数
 */
function showDialog(type, options) {
    if (!instance) initInstance();
    if (!instance.visible) {
        instance.type = type;
        Object.assign(instance.options, options);
        document.body.appendChild(instance.$el);
        Vue.nextTick(() => {
            instance.visible = true;
        });
    }
}

/**
 * 添加商品
 * @param  {Promise<any>} getData({ sku, spu, category, minPrice, maxPrice, pageNo, pageSize }) 组件内部数据来源
 * @param  {Array}        cacheList       本地缓存列表
 * @param  {Number}       maxLength       单次添加最大商品数量
 * @return {Promise<any>}                 返回待添加的商品列表
 */
export function addGoods({ getData, cacheList, maxLength }) {
    return new Promise((resolve) => {
        showDialog('AddGoods', {
            getData,
            cacheList,
            maxLength,
            callback(goodsList) {
                resolve(goodsList);
            }
        });
    });
}

/**
 * 删除商品
 * @param  {Promise<any>} getData({ pageNo, pageSize })     组件内部数据来源
 * @return {Promise<any>}                                   返回待删除的商品列表
 */
export function deleteGoods({ getData }) {
    return new Promise((resolve) => {
        showDialog('DeleteGoods', {
            getData,
            callback(goodsList) {
                resolve(goodsList);
            }
        });
    });
}

/**
 * 查看商品
 * @param  {Promise<any>} getData({ pageNo, pageSize })     组件内部数据来源
 */
export function viewGoods({ getData }) {
    showDialog('ViewGoods', { getData });
}
