<template>
    <div :class="$style.container">
        <header :class="$style.header">
            <el-row :gutter="20">
                <el-col :span="7">
                    <el-input v-model="codeValue" :placeholder="codeValuePlaceholder">
                        <el-select slot="prepend" :class="$style.codeType" v-model="codeType">
                            <el-option label="SKU" value="SKU"></el-option>
                            <el-option label="SPU" value="SPU"></el-option>
                        </el-select>
                    </el-input>
                </el-col>

                <el-col :span="6">
                    <el-cascader
                        v-model="categoryId"
                        :options="categoryOptions"
                        :show-all-levels="false"
                        placeholder="产品分类"
                        filterable
                        clearable>
                    </el-cascader>
                </el-col>

                <el-col :span="8" :class="$style.priceField">
                    <span>本地售价：</span>
                    <el-input v-model.number="minPrice" :class="$style.priceInput" type="number"></el-input>
                    <span :class="$style.splitLine">-</span>
                    <el-input v-model.number="maxPrice" :class="$style.priceInput" type="number"></el-input>
                </el-col>

                <el-col :span="3">
                    <el-button :class="$style.searchBtn" type="primary" @click="updateTableData">搜索</el-button>
                </el-col>
            </el-row>
        </header>

        <el-table
            ref="table"
            :data="tableData"
            max-height="450"
            stripe
            @select="handleSelect"
            @select-all="handleSelect"
        >
            <div slot="empty">暂无数据</div>
            <el-table-column :selectable="selectable" type="selection" align="center" width="55"></el-table-column>
            <el-table-column prop="sku" label="SKU" align="center" width="150"></el-table-column>
            <el-table-column label="主图" align="center">
                <img slot-scope="scope" :class="$style.mainImage" :src="scope.row.mainImage">
            </el-table-column>
            <el-table-column prop="title" label="商品标题" header-align="center" width="300"></el-table-column>
            <el-table-column prop="stock" label="库存" align="center"></el-table-column>
            <el-table-column :formatter="formatStatus" label="商品状态" align="center"></el-table-column>
            <el-table-column :formatter="formatPrice" label="本店售价" align="center"></el-table-column>
        </el-table>

        <div :class="$style.pagination">
            <span :class="$style.stat">{{ statHint }}</span>
            <el-pagination
                :current-page="pageNo"
                :page-size="pageSize"
                :total="totalCount"
                layout="->, total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>

        <footer :class="$style.btnGroup">
            <el-button :class="$style.btnItem" @click="handleClose">取消</el-button>
            <el-button :class="$style.btnItem" type="primary" @click="handleConfirm">确认</el-button>
        </footer>
    </div>
</template>

<script>
    import { reqCategoryTree } from '@promotion/services/common';

    export default {
        name: 'AddGoods',
        props: {
            options: {
                type: Object,
                default: () => ({}),
            },
            visible: {
                require: true,
                type: Boolean,
                default: false
            }
        },

        data() {
            return {
                cacheList: Array.from(this.options.cacheList || []), // 本地缓存列表
                maxLength: this.options.maxLength || 200, // 最大商品添加数
                tableData: [], // 表格数据
                codeType: 'SKU', // 当前搜索的编号类型
                codeValue: '', // 当前搜索的编号
                categoryId: [], // 当前搜索的产品分类ID
                categoryOptions: [], // 产品分类选项数据
                minPrice: '', // 当前搜索的本地售价最小值
                maxPrice: '', // 当前搜索的本地售价最大值
                pageNo: 1, // 当前页码
                pageSize: 10, // 每页显示商品数量
                totalCount: 0, // 商品总数
            };
        },

        computed: {
            // 输入框提示文本
            codeValuePlaceholder() {
                return this.codeType === 'SKU' ? '请输入商品的SKU' : '请输入商品的SPU';
            },

            // 可选择商品数提示
            statHint() {
                return `已选 ${this.cacheList.length} 商品，还可以选择 ${this.maxLength - this.cacheList.length} 个商品`;
            }
        },

        created() {
            this.getCategoryOptions();
            this.updateTableData();
        },

        methods: {
            /**
             * 获取产品类目列表
             */
            async getCategoryOptions() {
                const { status, data } = await reqCategoryTree.http();
                if (status === 0) {
                    this.categoryOptions = this.mapCategoryOptions(data);
                }
            },

            /**
             * 格式化产品类目列表（递归）
             * @param options
             */
            mapCategoryOptions(options = []) {
                return options.map(item => ({
                    value: item.id,
                    label: item.name,
                    children: item.children && item.children.length > 0 ? this.mapCategoryOptions(item.children) : null
                }));
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { goodsList = [], totalCount = 0 } = await this.options.getData({
                    // 传入筛选条件，外部将根据入参请求商品列表
                    sku: this.codeType === 'SKU' ? this.codeValue : '',
                    spu: this.codeType === 'SPU' ? this.codeValue : '',
                    category: this.categoryId.slice(-1)[0],
                    minPrice: this.minPrice,
                    maxPrice: this.maxPrice,
                    pageNo: this.pageNo,
                    pageSize: this.pageSize
                }) || {};

                /**
                 * this.tableData {Array<Object>} 表格数据
                 * @attr sku 《商品SKU》
                 * @attr mainImage 《主图链接》
                 * @attr title 《商品标题》
                 * @attr stock 《库存》
                 * @attr goodsStatus 《商品状态》
                 * @attr price 《本店售价》
                 * @attr selected 《当前行是否已被选中》
                 */
                this.tableData = goodsList;
                this.totalCount = Number(totalCount);
                this.$nextTick(() => {
                    this.tableData.forEach((goodsItem) => {
                        // 设置默认选中项
                        if (goodsItem.selected || this.cacheList.some(item => item.sku === goodsItem.sku)) {
                            this.$refs.table.toggleRowSelection(goodsItem, true);
                        }
                    });
                });
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateTableData();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateTableData();
            },

            /**
             * 关闭操作
             */
            handleClose() {
                this.$emit('update:visible', false);
            },

            /**
             * 确认操作
             */
            handleConfirm() {
                this.options.callback(Array.from(this.cacheList));
                this.handleClose();
            },

            /**
             * 每次选择或取消商品的时候触发的事件方法
             * @param currentList 《当前选中的列表》
             * @param row 《当前操作的行》
             */
            handleSelect(currentList, row) {
                if (this.tableData.length === 0) return;

                if (row) {
                    if (currentList.includes(row)) {
                        this.cacheList.push(row); // 单行选中
                    } else {
                        this.cacheList = this.cacheList.filter(cacheItem => cacheItem.sku !== row.sku); // 单行不选中
                    }
                } else if (currentList.length > 0) {
                    // 全选
                    this.tableData.forEach((item) => {
                        if (!this.cacheList.some(cacheItem => cacheItem.sku === item.sku)) {
                            this.cacheList.push(item);
                        }
                    });
                } else {
                    // 全不选
                    this.cacheList = this.cacheList.filter(cacheItem => !this.tableData.some(item => item.sku === cacheItem.sku));
                }
            },

            /**
             * 决定每一行是否可以勾选
             * @param selected 《当前行是否已被选中》
             * @return {boolean}
             */
            selectable({ selected }) {
                return !selected;
            },

            /**
             * 格式化商品价格
             * @param price 《商品价格》
             * @return {string}
             */
            formatPrice({ price }) {
                return `$${price}`;
            },

            /**
             * 格式化商品状态
             * @param goodsStatus 《商品状态》
             * @return {*|string}
             */
            formatStatus({ goodsStatus }) {
                return {
                    1: '待发布',
                    2: '上架',
                    3: '下架',
                    4: '到货通知',
                    5: '谍照',
                }[goodsStatus] || '???';
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        color: var(--color-black);
    }

    .header {
        margin-bottom: 30px;
    }

    .codeType {
        width: 90px;
    }

    .priceInput {
        width: 100px;
    }

    .searchBtn {
        width: 100%;
    }

    .priceField {
        white-space: nowrap;
    }

    .splitLine {
        display: inline-block;
        margin: 0 10px;
    }

    .pagination {
        margin-top: 20px;
    }

    .stat {
        float: left;
        line-height: 28px;
    }

    .btnGroup {
        margin-top: 30px;
        text-align: center;
    }

    .btnItem {
        width: 120px;
        margin: 0 10px;
    }

    .mainImage {
        display: block;
        width: 60px;
        height: 60px;
        margin: 7px auto;
    }
</style>
