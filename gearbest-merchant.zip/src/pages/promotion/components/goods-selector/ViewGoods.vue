<template>
    <div :class="$style.container">
        <el-table
            ref="table"
            :data="tableData"
            max-height="450"
            stripe
        >
            <div slot="empty">暂无数据</div>
            <el-table-column prop="sku" label="SKU" align="center"></el-table-column>
            <el-table-column label="主图" align="center">
                <img slot-scope="scope" :class="$style.mainImage" :src="scope.row.mainImage">
            </el-table-column>
            <el-table-column prop="title" label="商品标题" header-align="center" width="550"></el-table-column>
        </el-table>

        <div :class="$style.pagination">
            <el-pagination
                :current-page="pageNo"
                :page-size="pageSize"
                :total="totalCount"
                layout="->, total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>

        <footer :class="$style.btnGroup">
            <el-button :class="$style.btnItem" type="primary" @click="handleClose">确认</el-button>
        </footer>
    </div>
</template>

<script>
    export default {
        name: 'ViewGoods',
        props: {
            options: {
                type: Object,
                default: () => ({}),
            },
            visible: {
                require: true,
                type: Boolean,
                default: false
            }
        },

        data() {
            return {
                tableData: [], // 表格数据
                pageNo: 1, // 当前页码
                pageSize: 10, // 每页显示商品数量
                totalCount: 0, // 商品总数
            };
        },

        created() {
            this.updateTableData();
        },

        methods: {
            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                const { goodsList = [], totalCount = 0 } = await this.options.getData({
                    // 传入筛选条件，外部将根据入参请求商品列表
                    pageNo: this.pageNo,
                    pageSize: this.pageSize,
                }) || {};

                /**
                 * this.tableData {Array<Object>} 表格数据
                 * @attr sku 《商品SKU》
                 * @attr mainImage 《主图链接》
                 * @attr title 《商品标题》
                 */
                this.tableData = goodsList;
                this.totalCount = Number(totalCount);
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.updateTableData();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateTableData();
            },

            /**
             * 关闭操作
             */
            handleClose() {
                this.$emit('update:visible', false);
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        color: var(--color-black);
    }

    .pagination {
        margin-top: 20px;
    }

    .btnGroup {
        margin-top: 30px;
        text-align: center;
    }

    .btnItem {
        width: 120px;
        margin: 0 10px;
    }

    .mainImage {
        display: block;
        width: 60px;
        height: 60px;
        margin: 7px auto;
    }
</style>
