<template>
    <div>
        <el-dialog
            :visible.sync="visible"
            :close-on-click-modal="false"
            :title="title"
            width="1000px"
            custom-class="goodsSelector"
            @open="display = true"
            @closed="display = false">
            <component v-if="display" :is="componentName" :options="options" :visible.sync="visible"></component>
        </el-dialog>
    </div>
</template>

<script>
    import AddGoods from './AddGoods';
    import DeleteGoods from './DeleteGoods';
    import ViewGoods from './ViewGoods';

    export default {
        name: 'GoodsSelector',
        components: {
            AddGoods,
            DeleteGoods,
            ViewGoods,
        },
        data() {
            return {
                type: '',
                visible: false,
                display: false,
                options: {},
            };
        },
        computed: {
            componentName() {
                return this.type;
            },
            title() {
                if (this.type === 'AddGoods') return '添加商品';
                if (this.type === 'DeleteGoods') return '删除商品';
                if (this.type === 'ViewGoods') return '查看已选商品';
                return '';
            }
        },
    };
</script>

<style>
    .goodsSelector {
        .el-dialog__body {
            padding-top: 10px;
        }
    }
</style>
