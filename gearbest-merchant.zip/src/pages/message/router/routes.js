import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    {
        path: '/message/leave',
        name: 'MessageLeave',
        meta: {
            title: 'base.menu.message.leave',
        },
        component: () => asyncComponent(import('../views/MessageLeave.vue'))
    },
    {
        path: '/message/leavedetail:id',
        name: 'MessageLeavedetail',
        meta: {
            title: 'base.menu.message.leavedetail',
            focusMenu: '/message/leave'
        },
        component: () => asyncComponent(import('../views/MessageLeavedetail.vue'))
    },
    {
        path: '/message/arbitrate',
        name: 'MessageArbitrate',
        meta: {
            title: 'base.menu.message.arbitrate',
        },
        component: () => asyncComponent(import('../views/MessageArbitrate.vue'))
    },
    {
        path: '/message/arbitratedetail:id',
        name: 'MessageArbitratedetail',
        meta: {
            title: 'base.menu.message.arbitratedetail',
            focusMenu: '/message/arbitrate'
        },
        component: () => asyncComponent(import('../views/MessageArbitratedetail.vue'))
    },
    {
        path: '/message/reminder',
        name: 'MessageReminder',
        meta: {
            title: 'base.menu.message.reminder',
        },
        component: () => asyncComponent(import('../views/MessageReminder.vue'))
    },
];
