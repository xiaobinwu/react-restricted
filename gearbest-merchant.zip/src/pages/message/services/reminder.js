/**
 * Created by GUOXIU on 2019/01/02.
 */

import Service from '@/assets/js/Service/index.js';


/**
 * 催单通知列表
 * @type {GbService}
 */
export const getReminderList = new Service({
    url: '/shop/reminder/records',
    method: 'GET',
});


/**
 * 催单通知删除
 * @type {GbService}
 */
export const deleteReminder = new Service({
    url: '/shop/reminder/records/delete',
    method: 'POST',
});


/**
 * 催单通知查看
 * @type {GbService}
 */
export const redReminder = new Service({
    url: '/shop/reminder/records/read',
    method: 'POST',
});
