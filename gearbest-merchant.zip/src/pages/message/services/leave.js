/**
 * Created by GUOXIU on 2018/12/25.
 */

import Service from '@/assets/js/Service/index.js';


/**
 * 留言列表
 * @type {GbService}
 */
export const getLeaveMessageList = new Service({
    url: '/shop/messages',
    method: 'GET',
});


/**
 * 留言删除
 * @type {GbService}
 */
export const deleteLeaveMessage = new Service({
    url: '/shop/messages/delete',
    method: 'POST',
});


/**
 * 留言回复
 * @type {GbService}
 */
export const replyLeaveMessage = new Service({
    url: '/shop/messages/reply',
    method: 'POST',
});


/**
 * 留言详情
 * @type {GbService}
 */
export const getLeaveDetailList = new Service({
    url: '/shop/messages/detail',
    method: 'GET',
});
