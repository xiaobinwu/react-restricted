/**
 * Created by GUOXIU on 2019/01/02.
 */

import Service from '@/assets/js/Service/index.js';


/**
 * 仲裁留言列表
 * @type {GbService}
 */
export const getArbitrateList = new Service({
    url: '/shop/arbitration/messages',
    method: 'GET',
});


/**
 * 仲裁留言删除
 * @type {GbService}
 */
export const deleteArbitrate = new Service({
    url: '/shop/arbitration/messages/delete',
    method: 'POST',
});


/**
 * 仲裁留言详情
 * @type {GbService}
 */
export const getArbitrateDetail = new Service({
    url: '/shop/arbitration/messages/detail',
    method: 'GET',
});


/**
 * 仲裁留言回复
 * @type {GbService}
 */
export const arbitrateReply = new Service({
    url: '/shop/arbitration/messages/reply',
    method: 'POST',
});
