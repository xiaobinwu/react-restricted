/**
 * Created by GUOXIU on 2019/01/13.
 */

import Service from '@/assets/js/Service/index.js';

/**
 * 获取 SMS 服务码映射状态表ß
 * @type {GbService}
 */
export const getSmsStatus = new Service({
    url: '/public/sms/status',
    method: 'GET',
    usePreResult: true,
});
