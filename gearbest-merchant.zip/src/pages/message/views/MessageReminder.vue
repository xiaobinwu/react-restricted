<template>
    <div :class="$style.container">
        <div :class="$style.listTop">
            <el-button type="danger" @click="deleteBatch">{{ $t('message.batchDeletion') }}</el-button>
        </div>
        <el-table
            :data="listData"
            :class="$style.listBox"
            stripe
            @selection-change="val => multipleSelection = val">
            <el-table-column
                type="selection"
                width="50"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('message.messageContent')"
                prop="nick_name"
                align="center">
                <template slot-scope="scope">
                    <p :class="[scope.row.is_read === 0 ? $style.itemIcon : '']">
                        {{ $t('message.reminder.fromMessage', [scope.row.nick_name]) }}
                    </p>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('message.orderNumber')"
                prop="order_sn"
                width="200"
                align="center">
                <template slot-scope="scope">
                    <p :class="$style.listItemLink" @click="redReminder(scope.row.id, scope.row.order_sn)">
                        {{ scope.row.order_sn }}
                    </p>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('message.payTime')"
                prop="paid_time"
                width="200"
                align="center">
                <template slot-scope="scope">
                    {{ $dateFormat(scope.row.paid_time) }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('message.remindTime')"
                prop="create_time"
                width="200"
                align="center">
                <template slot-scope="scope">
                    {{ $dateFormat(scope.row.create_time) }}
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
            :class="$style.pagination"
            :current-page="currentPage"
            :total="total"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            align="right"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import {
        getReminderList,
        deleteReminder,
        redReminder
    } from '../services/reminder.js';

    export default {
        name: 'MessageReminder',
        data() {
            return {
                shopCode: this.$store.state.user.userInfo.defaultShop.shopCode || '',
                // shopCode: 'lafermcode',
                listData: [],
                multipleSelection: [],
                total: 1,
                currentPage: 1,
                pageSize: 10,
                pageSizes: [10, 20, 30],
            };
        },
        watch: {
            $route(to, from) {
                this.mergeParam();
            }
        },
        created() {
            const vm = this;
            vm.mergeParam();
        },
        methods: {
            deleteBatch() {
                const vm = this;
                let deletId = '';
                vm.multipleSelection.forEach((item, index) => {
                    deletId += `${item.id}${index < vm.multipleSelection.length - 1 ? ',' : ''}`;
                });
                if (deletId) {
                    vm.$confirm(vm.$t('message.deletTip'), vm.$t('message.batchDeletion'), {
                        confirmButtonText: vm.$t('message.confirm'),
                        cancelButtonText: vm.$t('message.cancel'),
                        type: 'warning'
                    }).then(() => {
                        vm.deleteReminder(deletId);
                    }).catch(() => {
                        // console.log('已取消');
                    });
                }
            },
            handleSizeChange(val) {
                const vm = this;
                vm.pageSize = val;
                vm.setRoute();
            },
            handleCurrentChange(val) {
                const vm = this;
                vm.currentPage = val;
                vm.setRoute();
            },
            // ----- 页面逻辑 -----
            setRoute() { // 将参数写入路由
                const vm = this;
                const queryData = {};
                if (vm.currentPage && vm.currentPage !== 1) queryData.currentPage = vm.currentPage;
                if (vm.pageSize && vm.pageSize !== 10) queryData.pageSize = vm.pageSize;
                vm.$router.push({
                    name: 'MessageReminder',
                    query: queryData
                });
            },
            mergeParam() { // 从路由读取参数
                const vm = this;
                const urlQuery = vm.$route.query || {};
                // 根据链接参数初始化默认值
                const reqData = {
                    shopCode: vm.shopCode,
                    page: +urlQuery.currentPage || 1,
                    pageSize: +urlQuery.pageSize || 10,
                };
                vm.getList(reqData);
            },
            // ----- 请求数据 -----
            async getList(params) { // 列表数据
                const vm = this;
                const { status, data } = await getReminderList.http({
                    loading: true,
                    params
                });
                if (status === 0) {
                    vm.currentPage = params.page;
                    vm.pageSize = params.pageSize;
                    vm.total = data.total;
                    vm.listData = data.data;
                }
            },
            async deleteReminder(id) { // 删除
                const vm = this;
                const { status, msg } = await deleteReminder.http({
                    data: {
                        id,
                        shopCode: vm.shopCode
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                vm.currentPage = 1;
                vm.setRoute();
            },
            async redReminder(id, orderSn) {
                const vm = this;
                const { status } = await redReminder.http({
                    loading: true,
                    data: {
                        id,
                        shopCode: this.shopCode
                    }
                });
                if (status === 0) {
                    vm.$router.gbPush(`/order/details/${orderSn}`);
                }
            }
        }
    };
</script>

<style module>
    .container {
        background: #fff;
        padding: 30px 20px;
        min-height: 740px;
    }

    .listTop {
        margin-bottom: 20px;
    }

    .listBox {
        background: #fff;
    }

    .itemIcon:before {
        content: '';
        display: inline-block;
        vertical-align: top;
        width:10px;
        height:10px;
        margin-right: 5px;
        border-radius: 50%;
        background: #FF5757;
    }

    .listItemLink {
        display: inline-block;
        color: #2774FF;
        cursor: pointer;
    }

    .pagination {
        margin-top: 20px;
    }
</style>
