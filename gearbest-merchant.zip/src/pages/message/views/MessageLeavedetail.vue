<template>
    <div>
        <message-reply
            :class="$style.reply"
            :nike-name="replyNickname"
            :extra-data="replyData"
            @sendMSG="sendMessage">
        </message-reply>
        <message-log
            v-if="logData.listData.length > 0"
            :list-data="logData.listData"
            :current-page="logData.currentPage"
            :total="logData.total"
            :page-size="logData.pageSize"
            :page-sizes="logData.pageSizes"
            @setRoute="setRoute"
            @deletLog="deleteLeave">
        </message-log>
    </div>
</template>

<script>
    import {
        getLeaveDetailList,
        deleteLeaveMessage,
        replyLeaveMessage
    } from '../services/leave.js';

    export default {
        name: 'MessageLeavedetail',
        data() {
            return {
                shopCode: this.$store.state.user.userInfo.defaultShop.shopCode || '',
                // shopCode: 'lafermcode',
                id: this.$route.params.id || 0,
                replyNickname: '',
                replyData: null,
                logData: {
                    listData: [],
                    currentPage: 1,
                    total: 1,
                    pageSize: 10,
                    pageSizes: [10, 20, 30]
                },
            };
        },
        watch: {
            $route(to, from) {
                this.mergeParam();
            }
        },
        created() {
            const vm = this;
            vm.mergeParam();
        },
        methods: {
            setRoute(queryData) { // 将参数写入路由
                const vm = this;
                vm.$router.push({
                    name: 'MessageLeavedetail',
                    query: queryData
                });
            },
            mergeParam() { // 从路由读取参数
                const vm = this;
                const urlQuery = vm.$route.query || {};
                vm.getList({
                    shopCode: vm.shopCode,
                    id: vm.id,
                    pageSize: urlQuery.pageSize || 10,
                    page: +urlQuery.currentPage || 1,
                });
            },
            // ----- 请求数据 -----
            async getList(params) {
                const vm = this;
                const { status, data } = await getLeaveDetailList.http({
                    loadding: true,
                    params
                });
                const dataArr = [];
                if (status === 0) {
                    // 消息记录数据结构标准格式化
                    data.data.forEach((item) => {
                        dataArr.push({
                            title: vm.$t('message.aboutProduct'),
                            time: item.create_time,
                            primary: item.message_type,
                            nickname: +item.message_type === 1 ? vm.$t('message.me') : data.nick_name,
                            contentType: item.content_type,
                            content: item.content,
                            groupType: item.source_type,
                            groupValue: item.source_type_value,
                            goodsInfo: +item.source_type === 1 ? {
                                sku: item.goods_sku,
                                url: item.goods_url,
                                image: item.goods_image,
                                title: item.goods_title,
                            } : null,
                        });
                    });
                    vm.replyNickname = data.nick_name;
                } else {
                    vm.$router.push({ name: 'MessageLeave' });
                }
                // 翻页器数据保存
                Object.assign(vm.logData, {
                    listData: dataArr,
                    total: status === 0 ? data.total : 1,
                    currentPage: params.page,
                    pageSize: +params.pageSize,
                });
                // 回复时使用消息
                if (dataArr[0]) vm.replyData = dataArr[0];
            },
            async deleteLeave() { // 删除留言
                const vm = this;
                const { status, msg } = await deleteLeaveMessage.http({
                    data: {
                        id: vm.id,
                        shopCode: vm.shopCode
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                vm.$router.push({ name: 'MessageLeave' });
            },
            async sendMessage(sendData, success, error) { // 回复消息
                const vm = this;
                const reqData = {
                    id: vm.id,
                    shopCode: vm.shopCode,
                };
                if (sendData.extraData) {
                    reqData.sourceType = sendData.isNew ? 3 : sendData.extraData.groupType;
                    reqData.sourceTypeValue = sendData.isNew ? vm.shopCode : sendData.extraData.groupValue;
                    if (!sendData.isNew && sendData.extraData.goodsInfo) {
                        reqData.goodsSku = sendData.extraData.goodsInfo.sku;
                        reqData.goodsUrl = sendData.extraData.goodsInfo.url;
                        reqData.goodsTitle = sendData.extraData.goodsInfo.title;
                        reqData.goodsImage = sendData.extraData.goodsInfo.image;
                    }
                } else {
                    reqData.sourceType = 3;
                    reqData.sourceTypeValue = vm.shopCode;
                }
                const reqArr = [];
                if (sendData.textarea) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.textarea,
                        contentType: 1
                    }));
                }
                if (sendData.files && sendData.files.length > 0) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.files[sendData.files.length - 1],
                        contentType: 2
                    }));
                }
                const servicesArr = [];
                reqArr.forEach((item) => {
                    servicesArr.push(new Promise(async (resolve) => {
                        resolve(await replyLeaveMessage.http({
                            errorPorp: false,
                            isCancel: false,
                            loading: true,
                            data: item,
                        }));
                    }));
                });
                const response = await Promise.all(servicesArr);
                let status = 0;
                let msg = '';
                response.forEach((resItem) => {
                    status += resItem.status;
                    msg = resItem.msg;
                });
                if (status === 0) {
                    success(msg);
                    if (vm.logData.currentPage === 1 && vm.logData.pageSize === 10) {
                        vm.mergeParam();
                    } else {
                        vm.setRoute();
                    }
                } else {
                    error(msg);
                }
            },
        }
    };
</script>

<style module>
    .reply {
        margin-bottom: 20px;
    }
</style>
