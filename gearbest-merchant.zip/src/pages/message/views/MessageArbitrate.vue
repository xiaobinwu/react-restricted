<template>
    <div :class="$style.container">
        <!-- 顶部筛选 -->
        <el-form inline>
            <el-form-item v-if="false" :label="$t('message.handleState')">
                <el-select
                    v-model="processValue"
                    :class="$style.selectWidth"
                    placeholder="" value="">
                    <el-option :label="$t('message.all')" value="" />
                    <el-option v-for="(value, key) in smsState.arbitrationStatus" :key="key" :label="value" :value="key" />
                </el-select>
            </el-form-item>
            <el-form-item :label="$t('message.replyState')">
                <el-select
                    v-model="replyStatus"
                    :class="$style.selectWidth"
                    placeholder="" value="">
                    <el-option :label="$t('message.all')" value="" />
                    <el-option v-for="(value, key) in smsState.replyStatus" :key="key" :label="value" :value="key" />
                </el-select>
            </el-form-item>
            <el-form-item :label="$t('message.time')">
                <el-date-picker
                    v-model="screenTime"
                    :start-placeholder="$t('message.startTime')"
                    :end-placeholder="$t('message.endTime')"
                    :range-separator="$t('message.timeTo')"
                    value-format="timestamp"
                    type="datetimerange"
                    align="center">
                </el-date-picker>
            </el-form-item>
            <el-form-item label="">
                <el-button type="primary" icon="el-icon-search" @click="setRoute">{{ $t('message.search') }}</el-button>
            </el-form-item>
        </el-form>
        <!-- 列表 -->
        <div :class="$style.listTop">
            <el-button type="danger" @click="deleteBatch">{{ $t('message.batchDeletion') }}</el-button>
        </div>
        <el-table
            :data="listData"
            :class="$style.listBox"
            stripe
            @selection-change="val => multipleSelection = val">
            <el-table-column
                type="selection"
                width="50"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('message.messageContent')"
                prop="to_seller_content"
                align="center">
                <template slot-scope="scope">
                    <div :class="$style.listItem">
                        <span v-if="scope.row.seller_unread_count > 0" :class="$style.listItemIcon">
                            {{ scope.row.seller_unread_count }}
                        </span>
                        <router-link :class="$style.listItemLink" :to="{ name: 'MessageArbitratedetail', params: { id: scope.row.id }}">
                            {{ scope.row.to_seller_content_type === 1 ? scope.row.to_seller_content : '&lt;img&gt;' }}
                        </router-link>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('message.orderNumber')"
                prop="order_number"
                width="180"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('message.time')"
                prop="seller_update_time"
                width="130"
                align="center">
                <template slot-scope="scope">
                    {{ $dateFormat(scope.row.seller_update_time) }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('message.replyState')"
                prop="seller_reply_status"
                width="100"
                align="center">
                <template slot-scope="scope">
                    {{ smsState.replyStatus[scope.row.seller_reply_status] }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('message.handleState')"
                prop="ticket_arbitration_status"
                width="100"
                align="center">
                <template slot-scope="scope">
                    {{ (
                        scope.row.ticket_arbitration_status == 10
                        || scope.row.ticket_arbitration_status == 30
                        || scope.row.ticket_arbitration_status == 40
                    ) ? '仲裁中' : smsState.arbitrationStatus[scope.row.ticket_arbitration_status] }}
                </template>
            </el-table-column>
        </el-table>
        <el-pagination
            :class="$style.pagination"
            :current-page="currentPage"
            :total="total"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            align="right"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import {
        getSmsStatus
    } from '../services/common.js';
    import {
        getArbitrateList,
        deleteArbitrate
    } from '../services/arbitrate.js';

    export default {
        name: 'MessageArbitrate',
        data() {
            return {
                shopCode: this.$store.state.user.userInfo.defaultShop.shopCode || '',
                // shopCode: '554654522',
                // 状态数据映射
                smsState: {
                    replyStatus: {},
                    arbitrationStatus: {},
                },
                processValue: '',
                replyStatus: '',
                screenTime: null,
                listData: [],
                multipleSelection: [],
                total: 1,
                currentPage: 1,
                pageSize: 10,
                pageSizes: [10, 20, 30],
            };
        },
        watch: {
            $route(to, from) {
                this.mergeParam();
            }
        },
        created() {
            const vm = this;
            // 请求 SMS 状态映射表
            getSmsStatus.http().then((smsData) => {
                const { status, data } = smsData;
                if (status === 0) {
                    vm.smsState.replyStatus = data.ReplyStatus;
                    vm.smsState.arbitrationStatus = data.ArbitrationStatus;
                }
            });
            vm.mergeParam();
        },
        methods: {
            deleteBatch() {
                const vm = this;
                let deletId = '';
                let sign = 0;
                vm.multipleSelection.forEach((item, index) => {
                    deletId += `${item.id}${index < vm.multipleSelection.length - 1 ? ',' : ''}`;
                    if ([10, 30, 40].includes(+item.ticket_arbitration_status)) sign += 1;
                });
                if (deletId && !sign) {
                    vm.$confirm(vm.$t('message.deletTip'), vm.$t('message.batchDeletion'), {
                        confirmButtonText: vm.$t('message.confirm'),
                        cancelButtonText: vm.$t('message.cancel'),
                        type: 'warning'
                    }).then(() => {
                        vm.deleteArbitrate(deletId);
                    }).catch(() => {
                        // console.log('已取消');
                    });
                } else if (sign) {
                    vm.$message({
                        type: 'error',
                        message: vm.$t('message.deletErrorTip')
                    });
                }
            },
            handleSizeChange(val) {
                const vm = this;
                vm.pageSize = val;
                vm.setRoute();
            },
            handleCurrentChange(val) {
                const vm = this;
                vm.currentPage = val;
                vm.setRoute();
            },
            // ----- 页面逻辑 -----
            setRoute() { // 将参数写入路由
                const vm = this;
                const queryData = {};
                if (vm.currentPage && vm.currentPage !== 1) queryData.currentPage = vm.currentPage;
                if (vm.pageSize && vm.pageSize !== 10) queryData.pageSize = vm.pageSize;
                if (vm.replyStatus) queryData.replyStatus = vm.replyStatus;
                if (vm.screenTime) {
                    queryData.startTime = vm.screenTime[0];
                    queryData.endTime = vm.screenTime[1];
                }
                // 第二期 预留字段 - 处理状态
                if (vm.processValue) queryData.processValue = vm.processValue;
                vm.$router.push({
                    name: 'MessageArbitrate',
                    query: queryData
                });
            },
            mergeParam() { // 从路由读取参数
                const vm = this;
                const urlQuery = vm.$route.query || {};
                // 根据链接参数初始化默认值
                const reqData = {
                    shopCode: vm.shopCode,
                    page: +urlQuery.currentPage || 1,
                    pageSize: +urlQuery.pageSize || 10,
                };
                if (urlQuery.replyStatus) reqData.replyStatus = urlQuery.replyStatus;
                if (urlQuery.startTime && urlQuery.endTime) {
                    reqData.startTime = urlQuery.startTime / 1000;
                    reqData.endTime = urlQuery.endTime / 1000;
                }
                // 第二期 预留字段 - 处理状态
                if (urlQuery.processValue) reqData.processValue = urlQuery.processValue;
                vm.getList(reqData);
            },
            // ----- 请求数据 -----
            async getList(params) { // 列表数据
                const vm = this;
                const { status, data } = await getArbitrateList.http({
                    loading: true,
                    params
                });
                if (status === 0) {
                    if (params.startTime && params.endTime) vm.screenTime = [params.startTime * 1000, params.endTime * 1000];
                    vm.processValue = params.processValue || ''; // 第二期 预留字段 - 处理状态
                    vm.replyStatus = params.replyStatus || '';
                    vm.currentPage = params.page;
                    vm.pageSize = params.pageSize;
                    vm.total = data.total;
                    vm.listData = data.data;
                }
            },
            async deleteArbitrate(id) { // 删除
                const vm = this;
                const { status, msg } = await deleteArbitrate.http({
                    loading: true,
                    data: {
                        id,
                        shopCode: vm.shopCode
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                vm.mergeParam();
            }
        }
    };
</script>

<style module>
    .container {
        background: #fff;
        padding: 30px 20px;
        min-height: 740px;
    }

    .selectWidth {
        width: 110px;
    }

    .listTop {
        margin-top: 30px;
        margin-bottom: 20px;
    }

    .listBox {
        background: #fff;
    }

    .listItem {
        position: relative;
        padding: 0 30px;
    }

    .listItemIcon {
        position: absolute;
        left: 5px;
        top: 50%;
        margin-top: -10px;
        width: 20px;
        height: 20px;
        line-height: 20px;
        background: rgba(255,87,87,1);
        border-radius: 12px;
        color: #fff;
    }

    .listItemLink {
        max-width: 100%;
        display: inline-block;
        vertical-align: top;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        text-decoration: underline;
    }

    .pagination {
        margin-top: 20px;
    }
</style>
