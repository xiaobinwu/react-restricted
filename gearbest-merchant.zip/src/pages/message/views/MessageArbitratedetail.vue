<template>
    <div>
        <!-- 仲裁详情 -->
        <div :class="$style.info">
            <h4 :class="$style.title">{{ $t('message.arbitratedetail.afterSalesDigest') }}</h4>
            <p :class="$style.item">
                <span>{{ $t('message.arbitratedetail.orderNumber') }}:</span>
                <a
                    :class="[$style.itemCon, $style.blue]"
                    href="javascript:;"
                    @click="$router.gbPush(`/order/details/${detailInfo.orderNumber}`)">
                    {{ detailInfo.orderNumber }}
                </a>
            </p>
            <p :class="$style.item">
                <span>{{ $t('message.arbitratedetail.commodityNumber') }}:</span>
                <a :class="[$style.itemCon, $style.blue]" :href="detailInfo.goodsUrl">{{ detailInfo.sku }}</a>
            </p>
            <p :class="$style.item">
                <span>{{ $t('message.arbitratedetail.ticketNumber') }}:</span>
                <span :class="$style.itemCon">{{ detailInfo.ticketNumber }}</span>
            </p>
            <p :class="$style.item">
                <span>{{ $t('message.arbitratedetail.processingState') }}:</span>
                <span :class="[$style.itemCon, $style.gray]">
                    {{ (
                        detailInfo.processStatus == 10
                        || detailInfo.processStatus == 30
                        || detailInfo.processStatus == 40
                    ) ? '仲裁中' : smsState.arbitrationStatus[detailInfo.processStatus] }}
                </span>
            </p>
            <p :class="$style.item">
                <span>{{ $t('message.arbitratedetail.serviceType') }}:</span>
                <span :class="$style.itemCon">
                    {{ smsState.serviceType[detailInfo.ticketType] }}
                </span>
            </p>
        </div>
        <!-- 回复框 -->
        <message-reply
            v-if="isReply"
            :class="$style.reply"
            :nike-name="replyNickname"
            :extra-data="replyDat"
            @sendMSG="sendMessage">
        </message-reply>
        <!-- 消息记录 -->
        <message-log
            v-if="logData.listData.length > 0"
            :list-data="logData.listData"
            :current-page="logData.currentPage"
            :total="logData.total"
            :page-size="logData.pageSize"
            :page-sizes="logData.pageSizes"
            @setRoute="setRoute"
            @deletLog="deleteLog">
        </message-log>
    </div>
</template>

<script>
    import {
        getSmsStatus
    } from '../services/common.js';
    import {
        getArbitrateDetail,
        deleteArbitrate,
        arbitrateReply
    } from '../services/arbitrate.js';

    export default {
        name: 'MessageArbitratedetail',
        data() {
            return {
                shopCode: this.$store.state.user.userInfo.defaultShop.shopCode || '',
                id: this.$route.params.id,
                // 状态数据映射
                smsState: {
                    serviceType: {},
                    arbitrationStatus: {},
                },
                isReply: false,
                detailInfo: {
                    sku: '', // 商品sku
                    logisticsType: '', // 物流方式
                    logisticsNumber: '', // 物流单号
                    orderNumber: '', // 订单号
                    ticketNumber: '',
                    processStatus: '', // 处理状态
                    ticketType: '', // 服务单类型
                    goodsUrl: '', // 商品链接
                },
                logData: {
                    listData: [],
                    currentPage: 1,
                    total: 1,
                    pageSize: 10,
                    pageSizes: [10, 20, 30]
                },
                replyNickname: this.$t('message.system'),
                replyDat: null,
            };
        },
        watch: {
            $route(to, from) {
                this.mergeParam();
            }
        },
        created() {
            const vm = this;
            // 请求 SMS 状态映射表
            getSmsStatus.http().then((smsData) => {
                const { status, data } = smsData;
                if (status === 0) {
                    vm.smsState.serviceType = data.ServiceType;
                    vm.smsState.arbitrationStatus = data.ArbitrationStatus;
                }
            });
            vm.mergeParam();
        },
        methods: {
            // ----- 页面逻辑 -----
            setRoute(queryData) { // 将参数写入路由
                const vm = this;
                vm.$router.push({
                    name: 'MessageArbitratedetail',
                    query: queryData
                });
            },
            mergeParam() { // 从路由读取参数
                const vm = this;
                const urlQuery = vm.$route.query || {};
                vm.getList({
                    shopCode: vm.shopCode,
                    id: vm.id,
                    pageSize: urlQuery.pageSize || 10,
                    page: +urlQuery.currentPage || 1,
                });
            },
            // ----- 请求数据 -----
            async getList(params) {
                const vm = this;
                const { status, data } = await getArbitrateDetail.http({ params });
                if (status === 0) {
                    const dataArr = [];
                    // 仲裁单信息
                    Object.assign(vm.detailInfo, {
                        sku: data.sku, // 商品sku
                        logisticsType: data.logistics_type,
                        logisticsNumber: data.logistics_number,
                        orderNumber: data.order_number,
                        ticketNumber: data.service_ticket_number,
                        processStatus: data.ticket_arbitration_status,
                        ticketType: data.ticket_type,
                        goodsUrl: data.goods_url,
                    });
                    // 判断是否可以回复 归为仲裁中的可以回复
                    if (
                        +vm.detailInfo.processStatus === 10
                        || +vm.detailInfo.processStatus === 30
                        || +vm.detailInfo.processStatus === 40
                    ) vm.isReply = true;
                    // 消息记录数据结构标准格式化
                    data.data.forEach((item) => {
                        dataArr.push({
                            title: vm.$t('message.aboutProduct'),
                            time: item.create_time,
                            primary: item.type === 1 ? 1 : 2,
                            nickname: +item.type === 1 ? vm.$t('message.me') : (+item.type === 3 ? vm.replyNickname : 'Buyer nickname'),
                            contentType: item.content_type,
                            content: item.content,
                            groupType: 3, // 写死为店铺
                            groupValue: vm.shopCode,
                            goodsInfo: null,
                        });
                    });
                    // 翻页器数据保存
                    Object.assign(vm.logData, {
                        listData: dataArr,
                        total: status === 0 ? data.total : 1,
                        currentPage: params.page,
                        pageSize: +params.pageSize,
                    });
                } else {
                    vm.$router.push({ name: 'MessageArbitrate' });
                }
            },
            async deleteLog() { // 删除留言
                const vm = this;
                if ([10, 30, 40].includes(+vm.detailInfo.processStatus)) {
                    vm.$message({
                        type: 'error',
                        message: vm.$t('message.deletErrorTip')
                    });
                    return;
                }
                const { status, msg } = await deleteArbitrate.http({
                    data: {
                        id: vm.id,
                        shopCode: vm.shopCode
                    }
                });
                vm.$message({
                    type: status === 0 ? 'success' : 'error',
                    message: msg
                });
                vm.$router.push({ name: 'MessageArbitrate' });
            },
            async sendMessage(sendData, success, error) { // 回复消息
                const vm = this;
                const reqData = {
                    id: vm.id,
                    shopCode: vm.shopCode,
                    type: 1,
                    typeId: vm.shopCode,
                };
                const reqArr = [];
                if (sendData.textarea) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.textarea,
                        contentType: 1
                    }));
                }
                if (sendData.files && sendData.files.length > 0) {
                    reqArr.push(Object.assign({}, reqData, {
                        content: sendData.files[sendData.files.length - 1],
                        contentType: 2
                    }));
                }
                const servicesArr = [];
                reqArr.forEach((item) => {
                    servicesArr.push(new Promise(async (resolve) => {
                        resolve(await arbitrateReply.http({
                            errorPorp: false,
                            isCancel: false,
                            loading: true,
                            data: item,
                        }));
                    }));
                });
                const response = await Promise.all(servicesArr);
                let status = 0;
                let msg = '';
                response.forEach((resItem) => {
                    status += resItem.status;
                    msg = resItem.msg;
                });
                if (status === 0) {
                    success(msg);
                    if (vm.logData.currentPage === 1 && vm.logData.pageSize === 10) {
                        vm.mergeParam();
                    } else {
                        vm.setRoute();
                    }
                } else {
                    error(msg);
                }
            },
        }
    };
</script>

<style module>
    .info {
        background: #fff;
        padding: 20px;
        margin-bottom: 20px;
    }

    .title {
        line-height: 40px;
        font-size: 18px;
        color: #000;
    }

    .item {
        line-height: 30px;
        font-size: 16px;
        color: #666;
    }

    .itemCon {
        margin-left: 5px;
        color: #000;
    }

    .blue {
        color: #2774FF;
    }

    .gray {
        color: #AAAAAA;
    }

    .reply {
        margin-bottom: 20px;
    }
</style>
