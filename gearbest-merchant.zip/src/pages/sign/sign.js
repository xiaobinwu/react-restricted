import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import signLang from '@/lang/sign';
import router from './router';

(async () => {
    const langInstance = await lang({
        local: signLang,
        moduleName: 'sign'
    });

    app({
        lang: langInstance,
        router
    });
})();
