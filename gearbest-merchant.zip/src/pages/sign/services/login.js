
import Service from '@/assets/js/Service/index';

/**
 * 注册
 */
export const signRegister = new Service({
    url: '/account/register',
    method: 'POST',
});

/**
 * 更新验证码
 */
export const signCaptcha = () => `/captcha/default?${+new Date()}`;

/**
 * 发送激活邮件
 */
export const signSendEmail = new Service({
    url: '/account/send-active-email',
    method: 'POST',
    showError: true,
});

/**
 * 检查邮箱是否已注册
 */
export const signEmailIsRegisted = new Service({
    url: '/account/is-register',
    method: 'GET',
});

/**
 * 登录
 */
export const signLogin = new Service({
    url: '/account/login',
    method: 'POST',
});

/**
 * 注销
 */
export const signLogout = new Service({
    url: '/account/logout',
    method: 'GET',
    showError: true,
});

/**
 * 查看账号激活结果
 */
export const signResult = new Service({
    url: '/account/active-account',
    method: 'GET',
    showError: true,
});

/**
 * 发送重置密码邮件
 */
export const sendResetEmail = new Service({
    url: '/account/send-reset-email',
    method: 'POST',
    showError: true,
});

/**
 * 重置密码
 */
export const resetPassword = new Service({
    url: '/account/reset-password',
    method: 'POST',
    showError: true,
});

/**
 * 获取登录信息
 */
export const getLoginInfo = new Service({
    url: '/user/get-login-data',
    ignoreAuth: true, // 防止请求时自动跳转到登录页
    method: 'GET',
});
