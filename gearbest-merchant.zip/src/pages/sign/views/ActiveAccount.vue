<template>
    <div v-loading="accountStatus === -1" :class="$style.content">
        <div v-if="accountStatus === 0" class="accountStatus">
            <i :class="[$style.iconCheck, 'el-icon-circle-check']"></i>
            <p :class="$style.msg">{{ $t('sign.result.success') }}</p>
        </div>

        <div v-else-if="accountStatus === 10070004" class="accountStatus">
            <i :class="[$style.iconWarning, 'el-icon-warning']"></i>
            <p :class="$style.msg">{{ $t('sign.result.expired') }}</p>
        </div>

        <div v-else class="accountStatus">
            <i :class="[$style.iconWarning, 'el-icon-warning']"></i>
            <p :class="$style.msg">{{ msg }}</p>
        </div>
        <router-link :class="$style.signBtn" :to="{name: 'signLogin'}" type="primary">{{ $t('login.login') }}</router-link>
    </div>
</template>

<script>

    import { signResult } from '@sign/services/login';

    export default {
        data() {
            return {
                accountStatus: -1, // 0 注册成功 1 已激活 10070004 链接失效
                msg: '',
            };
        },
        async mounted() {
            const { query: { confirmCode } } = this.$route;
            const { status, msg } = await signResult.http({
                params: {
                    confirmCode,
                }
            });
            this.accountStatus = +status;
            this.msg = msg;
        },
    };
</script>

<style module>
    @import 'variable.css';

    .content{
        width: 420px;
        text-align: center;
        min-height: 500px;
        padding: 160px 0;
        margin:0 auto;
    }

    .iconCheck{
        font-size: 60px;
        color: #5BBA69;
    }

    .iconWarning{
        font-size: 60px;
        color: #FFB403;
    }

    .signBtn{
        color: #fff;
        display: block;
        line-height: 40px;
        background-color: var(--color-primary);
        border-radius: 4px;
        &:hover{
            color: #fff;
            background-color: var(--color-primary-darken);
        }
    }

    .msg{
        line-height: 26px;
        margin: 20px 0 40px;
    }
</style>
