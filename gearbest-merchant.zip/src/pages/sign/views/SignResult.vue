<template>
    <div :class="$style.container">
        <div :class="$style.emailSent" v-html="$t('sign.active.email.sent', [email])"></div>
        <p :class="$style.expireTip">{{ $t('sign.active.expire.tip') }}</p>
        <p :class="$style.noemail">{{ $t('sign.active.noemail') }}
            <span :class="$style.sentAgain" @click="sentAgain">{{ $t('sign.active.sent.again') }}</span>
        </p>
    </div>
</template>

<script>

    import { signSendEmail } from '@sign/services/login';

    export default {
        data() {
            return {
                sendStatus: 0,
                historyback: '',
                email: '',
            };
        },
        created() {
            const { query: { email, historyback } } = this.$route;
            this.historyback = historyback;
            this.email = email;
        },
        methods: {
            async sentAgain() {
                if (this.historyback) {
                    this.$router.replace({
                        name: 'findPassword',
                        query: {
                            email: this.email,
                        }
                    });
                } else if (this.email.length && this.sendStatus === 0) {
                    this.sendStatus = 1;
                    const { status, msg } = await signSendEmail.http({
                        data: {
                            email: this.email,
                        }
                    });

                    if (status === 0) {
                        this.$message({
                            message: this.$t('sign.active.sent.success'),
                            type: 'success',
                        });
                    } else {
                        this.$message.error(msg);
                    }
                    setTimeout(() => {
                        this.sendStatus = 0;
                    }, 1000);
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container{
        width: 420px;
        margin: 0 auto;
        padding: 160px 0;
        text-align: center;
        line-height: 20px;
        min-height: 500px;
    }

    .container [class^='emailAddress'] {
        color: #F5A623;
    }

    .emailSent{
        font-size: 18px;
        line-height: 26px;
        margin-bottom: 10px;
    }

    .expireTip{
        margin-bottom: 40px;
    }

    .sentAgain{
        cursor: pointer;
        color: var(--color-primary-darken);
    }
</style>
