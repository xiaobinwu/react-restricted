<template>
    <div :class="$style.bannerBg">
        <div :class="$style.container">
            <div :class="$style.content">
                <h2 :class="$style.title">{{ $t('login.title') }}</h2>
                <el-form ref="login" :model="form" :rules="rules" autocomplete="true">
                    <el-form-item :error="form.emailErr" prop="email">
                        <el-input
                            v-model="form.email"
                            :placeholder="$t('register.email')"
                            prefix-icon="el-icon-message" maxlength="50" autocomplete="on"></el-input>
                    </el-form-item>
                    <el-form-item prop="password">
                        <el-input
                            v-model="form.password"
                            :placeholder="$t('register.pw')"
                            prefix-icon="el-icon-date"
                            type="password" maxlength="16"></el-input>
                    </el-form-item>
                    <el-form-item :error="form.captchaCodeErr" prop="captchaCode">
                        <el-row :gutter="10">
                            <el-col :span="16">
                                <el-input
                                    v-model="form.captchaCode"
                                    :placeholder="$t('register.captcha.code')"
                                    prefix-icon="el-icon-date" maxlength="20"
                                    @focus="captchaCodeReset"></el-input>
                            </el-col>
                            <el-col :span="7">
                                <img :class="$style.captchaImg" :src="form.captchaImg" @click="getCaptcha">
                            </el-col>
                        </el-row>
                    </el-form-item>
                    <div :class="$style.buttonBox">
                        <el-button :class="$style.signBtn" :loading="submit" type="primary" @click="login">{{ $t('login.login') }}</el-button>
                    </div>
                    <div :class="$style.forget">
                        <router-link :to="{name: 'findPassword'}">{{ $t('login.forget.password') }}</router-link>
                    </div>
                    <div :class="$style.enterBox">
                        <p :class="$style.entertitle">{{ $t('login.apply.tip') }}</p>
                        <router-link :class="$style.applySign" :to="{name: 'signRegister'}">{{ $t('login.apply.btn') }}</router-link>
                    </div>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapMutations } from 'vuex';
    import { UPDATE_USER } from '@/assets/js/store/mutationTypes';
    import { signCaptcha, signLogin, signSendEmail } from '@sign/services/login';

    export default {
        name: 'SignIn',
        data() {
            return {
                submit: false,
                form: {
                    email: '',
                    emailErr: '',
                    password: '',
                    captchaCode: '',
                    captchaCodeErr: '',
                    captchaImg: '',
                },
                rules: {
                    email: [
                        { required: true, message: this.$t('register.validate.email.empty') },
                        {
                            max: 50, message: this.$t('register.validate.email.maxlength'), trigger: 'change'
                        },
                        { type: 'email', message: this.$t('register.validate.email.notlegal'), trigger: 'blur' },
                    ],
                    password: [
                        { required: true, message: this.$t('register.validate.pw.empty'), trigger: 'blur' },
                    ],
                    captchaCode: [
                        { required: true, message: this.$t('register.captcha.code.empty') },
                    ],
                }
            };
        },
        created() {
            this.getCaptcha();
            // 回车提交
            document.addEventListener('keydown', this.enterEvent, false);
        },
        beforeDestroy() {
            document.removeEventListener('keydown', this.enterEvent, false);
        },
        methods: {
            ...mapMutations({
                updateUserInfo: UPDATE_USER
            }),
            getCaptcha() {
                this.form.captchaImg = signCaptcha();
            },
            captchaCode(rule, value, callback) {
                if (value !== this.form.password) {
                    callback(new Error(this.$t('register.captcha.code.notpass')));
                }
                callback();
            },
            captchaCodeReset() {
                this.form.captchaCodeErr = '';
            },
            enterEvent(ev) {
                if (ev.keyCode === 13) {
                    this.login();
                }
            },
            login() {
                if (this.$refs.login && !this.submit && !this.form.emailErr) {
                    this.submit = true;
                    this.$refs.login.validate(async (valid) => {
                        if (valid) {
                            const date = new Date();
                            const utcTimezone = -date.getTimezoneOffset() / 60;
                            const timeZone = `${utcTimezone > 0 ? '+' : '-'}${utcTimezone}`;

                            const { status, msg, data } = await signLogin.http({
                                data: {
                                    email: this.form.email,
                                    password: this.form.password,
                                    captcha: this.form.captchaCode,
                                    timeZone,
                                }
                            }).finally(() => {
                                this.submit = false;
                                this.getCaptcha();
                            });

                            if (status === 10070002) {
                                // 验证码错误
                                this.form.captchaCodeErr = this.$t('register.captcha.code.notpass');
                            } else if (status !== 0) {
                                // 其他错误
                                this.$message.error(msg);
                            } else if (data.status === 0) {
                                // 未激活
                                const res = await signSendEmail.http({
                                    data: {
                                        email: this.form.email,
                                    }
                                });

                                if (res.status === 0) {
                                    this.$message.error(this.$t('sign.account.inactive'));
                                    setTimeout(() => {
                                        this.$router.push({
                                            name: 'signResult',
                                            query: {
                                                email: this.form.email,
                                            }
                                        });
                                    }, 1500);
                                } else {
                                    this.$message.error(res.msg);
                                }
                            } else if (data.status === 1) {
                                // 账户正常
                                window.location.reload();
                            } else if (data.status === 2) {
                                // 账户已封停
                                this.$message.error(this.$t('login.account.disable'));
                            }
                        } else {
                            this.submit = false;
                        }
                    });
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .title{text-align: center;
        font-size: 24px;
        line-height: 34px;
        margin-bottom: 20px;
    }
    .bodyPosition{
        position: relative;
    }
    .container{
        height: 700px;
        position: relative;
        width: var(--layout-safe-width);
        margin: 0 auto;
    }
    .content{
        width: 500px;
        height: 580px;
        position: absolute;
        right: 0;
        top: 60px;
        background-color: var(--color-white);
        padding: 30px 40px 20px;
        border-radius: 5px;
    }
    .bannerBg{
        background: url('https://uidesign.gbtcdn.com/GB/image/other/20190123_7365/dl_bj.png?imbypass=true') 50% 50% no-repeat;
    }
    .codeInput{
        width: 268px;
        margin: 10px 0;
    }
    i{
        color: var(--color-primary );
    }
    .captchaImg{
        cursor: pointer;
        display: block;
        height: 40px;
    }
    .buttonBox{
        margin: 40px 0 20px;
    }
    .signBtn{
        width: 100%;
    }
    .forget{
        color: var(--color-primary );
        text-align: right;
    }
    .enterBox{
        position: absolute;
        left: 40px;
        right: 40px;
        bottom: 20px;
    }
    .entertitle{
        margin-bottom: 20px;
        text-align: center;
        font-size: 18px;
    }
    .applySign{
        display: block;
        height:40px;
        line-height:40px;
        text-align: center;
        font-size: var(--font-size-base);
        background:rgba(250,250,250,1);
        color: var(--color-text-primary);
        border:1px solid var(--border-color-light);
        border-radius: 4px;
    }
</style>
