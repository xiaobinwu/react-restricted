<template>
    <div ref="siteWrap" :class="$style.siteWrap">
        <header :class="$style.siteHeader">
            <div :class="$style.headerContainer">
                <a :class="$style.logo" href="https://www.gearbest.com/"></a>
                <div :class="$style.anchorList">
                    <span @click="goAnchor('indexContainer')">{{ $t('sign.entry.index') }}</span>
                    <span @click="goAnchor('support')">{{ $t('sign.entry.merchant.support') }}</span>
                    <span @click="goAnchor('shop')">{{ $t('sign.entry.business') }}</span>
                </div>
                <div :class="$style.positionLeft">
                    <div :class="$style.account">
                        <i :class="$style.signIcon" class="icon-sign-in"></i>
                        <span v-if="isLogin" :class="$style.userEmail">{{ userInfo.email }}</span>
                        <router-link v-else :to="{name: 'signLogin'}" :class="$style.toLogin">
                            {{ $t('sign.in.en') }}
                        </router-link>
                        <div :class="$style.accountPopup">
                            <p v-if="!isLogin">{{ isLogin ? '' : $t('sign.new.customer') }}</p>
                            <a v-if="isLogin" :class="$style.accountPopupBtn" href="javascript:;" @click="logout">
                                <strong>{{ $t('sign.out.en') }}</strong>
                            </a>
                            <router-link v-else :to="{name: 'signRegister'}" :class="$style.accountPopupBtn">
                                <strong>{{ $t('sign.register.en') }}</strong>
                            </router-link>
                        </div>
                    </div>
                    <el-button :class="$style.enteyBtn" @click="promptlyEntry">{{ $t('sign.entry.instantly') }}</el-button>
                    <el-select v-model="value" placeholder="$t('sign.entry.choose.lang')" value="" size="mini">
                        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
                    </el-select>
                </div>
            </div>
        </header>
        <div ref="indexContainer" :class="$style.container">
            <div :class="$style.banner">
                <div :class="$style.bannerContent">
                    <h3>{{ $t('sign.entry.banner.title') }}</h3>
                    <p>{{ $t('sign.entry.banner.describe') }}</p>
                    <el-button :class="[$style.enteyBtn, $style.enteyBtnBanner]" @click="promptlyEntry">
                        {{ $t('sign.entry.instantly') }}
                    </el-button>
                </div>
            </div>
            <div :class="[$style.containerItem, $style.opportunity]">
                <h3 :class="$style.title">
                    {{ $t('sign.entry.manufacture.chance') }}
                </h3>
                <p :class="$style.titleDescribe">
                    {{ $t('sign.entry.chance.describe') }}
                </p>
                <div :class="$style.listBox">
                    <div :class="[$style.listItem, $style.itemNoBackgroung]">
                        <h4>{{ $t('sign.entry.chance.policy.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.chance.policy.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.itemHasBackgroung]">
                        <h4>{{ $t('sign.entry.chance.market.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.chance.market.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.itemHasBackgroung]">
                        <h4>{{ $t('sign.entry.chance.consumption.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.chance.consumption.describe') }}
                        </p>
                    </div>
                </div>
            </div>
            <div :class="[$style.containerItem, $style.worth]">
                <h3 :class="$style.title">
                    {{ $t('sign.entry.worth.title') }}
                </h3>
                <p :class="$style.titleDescribe">
                    {{ $t('sign.entry.worth.describe') }}
                </p>
                <div :class="$style.listBox">
                    <div :class="[$style.listItem, $style.worthItem]">
                        <img src="@sign/assets/img/100-gearbest-worth.png" alt="">
                        <h4>{{ $t('sign.entry.worth.industry.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.worth.industry.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.worthItem]">
                        <img src="@sign/assets/img/200+-gearbest-worth.png" alt="">
                        <h4>{{ $t('sign.entry.worth.country.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.worth.country.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.worthItem]">
                        <img src="@sign/assets/img/10+-gearbest-worth.png" alt="">
                        <h4>{{ $t('sign.entry.worth.lang.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.worth.lang.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.worthItem]">
                        <img src="@sign/assets/img/6-gearbest-worth.png" alt="">
                        <h4>{{ $t('sign.entry.worth.flow.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.worth.flow.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.worthItem]">
                        <img src="@sign/assets/img/category-gearbest-worth.png" alt="">
                        <h4>{{ $t('sign.entry.worth.category.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.worth.category.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.worthItem]">
                        <img src="@sign/assets/img/3000+-gearbest-worth.png" alt="">
                        <h4>{{ $t('sign.entry.worth.member.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.worth.member.describe') }}
                        </p>
                    </div>
                </div>

            </div>

            <div ref="support" :class="[$style.containerItem, $style.support]">
                <h3 :class="[$style.title, $style.titleSupport]">
                    {{ $t('sign.entry.policy.title') }}
                </h3>
                <p :class="[$style.titleDescribe, $style.titleDescribeSupport]">
                    {{ $t('sign.entry.policy.describe') }}
                </p>
                <div :class="$style.listBox">
                    <div :class="[$style.listItem, $style.supportItem]">
                        <img src="@sign/assets/img/0-deposit.png" alt="">
                        <div :class="$style.supporDescribe">
                            <h4>{{ $t('sign.entry.policy.deposit.title') }}</h4>
                            <p>
                                {{ $t('sign.entry.policy.deposit.describe') }}
                            </p>
                        </div>
                    </div>
                    <div :class="[$style.listItem, $style.supportItem]">
                        <img src="@sign/assets/img/intelligent-management.png" alt="">
                        <div :class="$style.supporDescribe">
                            <h4>{{ $t('sign.entry.policy.back.title') }}</h4>
                            <p>
                                {{ $t('sign.entry.policy.back.describe') }}
                            </p>
                        </div>
                    </div>
                    <div :class="[$style.listItem, $style.supportItem]">
                        <img src="@sign/assets/img/exclusive-operating-instructor.png" alt="">
                        <div :class="$style.supporDescribe">
                            <h4>{{ $t('sign.entry.policy.tutor.title') }}</h4>
                            <p>
                                {{ $t('sign.entry.policy.tutor.describe') }}
                            </p>
                        </div>
                    </div>
                    <div :class="[$style.listItem, $style.supportItem]">
                        <img src="@sign/assets/img/three-dimensional-marketing.png" alt="">
                        <div :class="$style.supporDescribe">
                            <h4>{{ $t('sign.entry.policy.Marketing.title') }}</h4>
                            <p>
                                {{ $t('sign.entry.policy.Marketing.describe') }}
                            </p>
                        </div>
                    </div>
                    <div :class="[$style.listItem, $style.supportItem]">
                        <img src="@sign/assets/img/storage-generation.png" alt="">
                        <div :class="$style.supporDescribe">
                            <h4>{{ $t('sign.entry.policy.storage.title') }}</h4>
                            <p>
                                {{ $t('sign.entry.policy.storage.describe') }}
                            </p>
                        </div>
                    </div>
                    <div :class="[$style.listItem, $style.supportItem]">
                        <img src="@sign/assets/img/logistics-service.png" alt="">
                        <div :class="$style.supporDescribe">
                            <h4>{{ $t('sign.entry.policy.logistics.title') }}</h4>
                            <p>
                                {{ $t('sign.entry.policy.logistics.describe') }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div :class="[$style.containerItem, $style.seller]">
                <h3 :class="[$style.title, $style.titleSeller]">
                    {{ $t('sign.entry.seller.title') }}
                </h3>
                <p :class="[$style.titleDescribe, $style.titleDescribeSeller]">
                    {{ $t('sign.entry.seller.describe') }}
                </p>
                <div :class="$style.listBox">
                    <div :class="[$style.listItem, $style.sellerItem]">
                        <img src="@sign/assets/img/seller-story-1.jpg" alt="">
                        <h4>{{ $t('sign.entry.seller.beelink.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.seller.beelink.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.sellerItem]">
                        <img src="@sign/assets/img/seller-story-2.jpg" alt="">
                        <h4>{{ $t('sign.entry.seller.cubot.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.seller.cubot.describe') }}
                        </p>
                    </div>
                    <div :class="[$style.listItem, $style.sellerItem]">
                        <img src="@sign/assets/img/seller-story.jpg" alt="">
                        <h4>{{ $t('sign.entry.seller.chuwi.title') }}</h4>
                        <p>
                            {{ $t('sign.entry.seller.chuwi.describe') }}
                        </p>
                    </div>
                </div>
                <div :class="$style.sellerArcBg"></div>
            </div>
            <div :class="[$style.containerItem, $style.brand]">
                <h3 :class="$style.title">
                    {{ $t('sign.entry.brand.title') }}
                </h3>
                <p :class="$style.titleDescribe">
                    {{ $t('sign.entry.brand.describe') }}
                </p>
                <div :class="$style.listBox">
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/xiaom.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/amazfit.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/AQara.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/colorful.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/vernee.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/uhans.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/Teclast.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/asus-logo.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/Boruit.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/Zeblaze.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/Yeelighta.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/WLtoys-eu-200px.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/VOYO-logo.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/utorch.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/logoju.cn_2016-09-07_06-27-34.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/ulefone LOGO.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/UMIDIGI.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/uhans.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/tronxy.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/tocool.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/TIANQU.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/Thieye-thieye-logo.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/SYMA.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/Syllable(2).png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/Sunvell.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/sunlu.png" alt="">
                    </div>
                    <div :class="$style.brandItem">
                        <img src="@sign/assets/img/sricam-logo.png" alt="">
                    </div>
                </div>
            </div>
            <div ref="shop" :class="[$style.containerItem, $style.shop]">
                <h3 :class="[$style.title, $style.titleShop]">
                    {{ $t('sign.entry.shop.title') }}
                </h3>
                <p :class="[$style.titleDescribe, $style.titleDescribeShop]">
                    {{ $t('sign.entry.shop.describe') }}
                </p>
                <div :class="$style.listBox">
                    <div :class="[$style.listItem, $style.shopItem]">
                        <img src="@sign/assets/img/online-registration.png" alt="">
                        <h4>{{ $t('sign.entry.online.registration') }}</h4>
                    </div>
                    <div :class="[$style.listItem, $style.shopItem]">
                        <img src="@sign/assets/img/online-decoration.png" alt="">
                        <h4>{{ $t('sign.entry.online.decoration') }}</h4>
                    </div>
                    <div :class="[$style.listItem, $style.shopItem]">
                        <img src="@sign/assets/img/upload-product.png" alt="">
                        <h4>{{ $t('sign.entry.upload.product') }}</h4>
                    </div>
                    <div :class="[$style.listItem, $style.shopItem]">
                        <img src="@sign/assets/img/shop-opening.png" alt="">
                        <h4>{{ $t('sign.entry.shop.opening') }}</h4>
                    </div>
                </div>
            </div>

            <div :class="$style.footer">
                <div :class="$style.footerContent">
                    <h3>{{ $t('sign.entry.business.overseas') }}</h3>
                    <p>{{ $t('sign.entry.newshop.giftpackage') }}</p>
                    <el-button :class="[$style.enteyBtn, $style.enteyBtnFooter]" @click="promptlyEntry">{{ $t('sign.entry.instantly') }}</el-button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    import { mapState, mapMutations } from 'vuex';
    import { UPDATE_USER } from '@/assets/js/store/mutationTypes';
    import { signLogout } from '@sign/services/login';

    export default {
        name: 'SignIndex',
        data() {
            return {
                value: 'zh-cn',
                options: [
                    {
                        value: 'zh-cn',
                        label: '中文简体'
                    }
                ]
            };
        },

        computed: {
            ...mapState({
                isLogin: state => state.user.isLogin,
                userInfo: state => state.user.userInfo
            })
        },
        methods: {
            ...mapMutations({
                updateUserInfo: UPDATE_USER
            }),
            async logout() {
                await signLogout.http();
                this.updateUserInfo({
                    userInfo: {},
                    isLogin: false,
                });
                this.$router.gbPush('/sign/login');
            },
            promptlyEntry() {
                const { accountStatus } = this.userInfo;
                if (!this.isLogin) {
                    this.$router.push({
                        name: 'signLogin'
                    });
                } else if (accountStatus === 0 || accountStatus === 1 || accountStatus === 2) {
                    this.$router.gbPush('/user/entry');
                } else if (accountStatus === 3) {
                    this.$router.gbPush('/index/home');
                }
            },
            goAnchor(goName) {
                this.$nextTick(() => {
                    window.scrollTo(0, this.$refs[goName].offsetTop - 100);
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import '../assets/styles/sign.css';

    .siteWrap{
        transition: width 2s;
    }
    .siteHeader{
        height: 100px;
        background-color: var(--color-black);
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        z-index: 2;
    }
    .container{
        max-width: 1440px;
        min-width: 1200px;
        margin: 100PX auto 0;
        padding-top: 20px;
    }
    .headerContainer{
        max-width: 1440px;
        min-width: 1200px;
        margin: 0 auto;
        padding-top: 20px;
    }
    .signIcon{
        color: var(--color-white);
    }
    .logo {
        float: left;
        margin: 3px 77px 0 0;
        width: 123px;
        height: 54px;
        background: url('@sign/assets/img/logo.png') center no-repeat;
        background-size: auto 100%;
    }
    .anchorList{
        display: inline-block;
        height: 30px;
        line-height: 30px;
        margin-top: 15px;
    }
    .anchorList span{
        margin: 0 40px;
        font-size: 18px;
        color: var(--color-white);
        cursor: pointer;
    }
    .positionLeft{
        float: right;
    }
    .account{
        display: inline-block;
        color: var(--color-white);
        font-size: 14px;
        height: 36px;
        line-height: 30px;
        margin: 15px 0 0 20px;
        position: relative;
    }
    .toLogin{
        color: var(--color-white);
    }
    .toLogin:hover{
        color: var(--background-entry-button-top);
    }
    .account:hover .accountPopup{
        display: block;
    }
    .account i{
        font-size: 20px;
    }
    .accountPopup{
        display: none;
        width: 300px;
        position: absolute;
        color: var(--color-black);
        background-color: var(--color-white);
        top: 38px;
        left: 50%;
        margin-left: -150px;
        padding: 20px;
        font-size: 14px;
    }
    .accountPopup::before{
        content: "";
        width: 0;
        height: 0;
        border-width: 8px;
        border-style: solid;
        border-color: transparent transparent var(--color-white);
        position: absolute;
        left: 142px;
        top: -16px;
        z-index: 2;
    }
    .userEmail{
        display: inline-block;
        max-width: 50px;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
        line-height: 14px;
    }
    .accountPopupBtn:hover{
        color: var(--color-white);
    }
    .accountPopupBtn{
        display: block;
        width: 260px;
        margin: 13px auto 0;
        height: 40px;
        line-height: 40px;
        text-align: center;
        font-size: 16px;
        color: var(--color-white);
        background-color: var(--color-account-button);
    }
    .enteyBtn{
        height: 38px;
        line-height: 38px;
        color: var(--color-white);
        border: none;
        border-radius: 50px;
        padding: 0 40px;
        margin: 0 60px;
        font-size: 18px;
        background-color: var(--background-entry-button);
        background: -webkit-linear-gradient(top, var(--background-entry-button-top), var(--background-entry-button-bottom));
    }
    .enteyBtn:hover{
        color: var(--color-white);
    }
    .banner{
        position: relative;
        height: 768px;
        background: url('@sign/assets/img/top-banner.jpg') center no-repeat;
    }
    .bannerContent{
        position: absolute;
        top: 416px;
        width: 100%;
        text-align: center;
    }
    .bannerContent h3{
        color: var(--color-black);
        font-size: 48px;
        font-weight: bold;
        line-height: 70px;
    }
    .bannerContent p{
        line-height: 70px;
        color: var(--color-black);
        font-size: 48px;
        font-weight: lighter;
    }
    .enteyBtnBanner{
        height: 72px;
        line-height: 72px;
        font-size: 32px;
        padding: 0 140px;
        margin-top:16px;
    }

    .containerItem{

        padding: 48px 0 20px;
        text-align: center;
    }
    .opportunity{
        background-color: var(--color-white);
        background: -webkit-linear-gradient(top, var(--color-white), var(--background-entry-opportunity-bottom));
    }
    .title{
        width: 1090px;
        margin: auto;
        font-size: 36px;
        color: var(--color-sign-title);
        font-weight: bold;
    }
    .title::before{
        content: '';
        display: inline-block;
        width: 70px;
        height: 24px;
        background: url('@sign/assets/img/title-left.png') center no-repeat;
    }
    .title::after{
        content: '';
        display: inline-block;
        width: 70px;
        height: 24px;
        background: url('@sign/assets/img/title-right.png') center no-repeat;
    }

    .titleDescribe{
        width: 1090px;
        margin: auto;
        color: var(--color-sign-title);
        font-size: 18px;
        margin-top: 20px;
    }
    .listBox{
        width: 1090px;
        margin: 40px auto;
        font-size: 0px;
    }
    .listItem{
        display: inline-block;
        width: 330px;
        margin: 0 24px;
        padding: 15px;
        color: var(--color-white);
        letter-spacing: 3px;
        vertical-align: top;
    }
    .listItem:first-child{
        margin-left: 0;
    }
    .listItem:last-child{
        margin-right: 0;
    }
    .listItem:nth-child(4n){
        margin-left: 0;
    }
    .listItem:nth-child(3n){
        margin-right: 0;
    }
    .listItem h4{
        font-size: 24px;
        margin-top: 10px;
    }
    .listItem p{
        font-size: 18px;
        margin-top: 10px;
        line-height: 24px;
        text-align: left;
    }
    .itemNoBackgroung{
        height: 418px;
        background: url('@sign/assets/img/opportunity-nobg.jpg') center no-repeat;
        background-size: 100% 100%;
    }
    .itemHasBackgroung{
        height: 418px;
        background: url('@sign/assets/img/market-size.jpg') center no-repeat;
    }
    .worth{
        text-align: center;
        background-color: var(--color-white);
    }
    .worthItem{
        padding: 0 10px;
        margin-top: 24px;
        margin-bottom: 30px;
    }
    .worthItem img{
        width: 120px;
        height: 120px;
    }
    .worthItem h4{
        font-size: 24px;
        margin-top: 20px;
        color: var(--color-black);
    }
    .worthItem p{
        font-size: 14px;
        margin-top: 15px;
        line-height: 24px;
        color: var(--color-entry-worth);
        text-align: center;
    }

    .support{
        background-color: var(--background-entry-support);
    }
    .titleSupport{
        color: var(--color-entry-suppor-title)
    }
    .titleDescribeSupport{
        color: var(--color-entry-suppor-title)
    }
    .supportItem{
        padding: 0;
        position: relative;
        margin-bottom: 30px;
        text-align: left;
    }
    .supportItem img{
        width: 100%
    }
    .supportItem h4{
        margin-top: 18px;
    }
    .supportItem p{
        line-height: 28px;
        margin-top: 12px;
    }
    .supporDescribe{
        position: absolute;
        top: 0;
        left: 0;
        padding: 10px 22px 22px;
    }
    .supporDescribe p{
        font-size: 14px;
    }

    .seller{
        background-color: var(--background-entry-seller);
        position: relative;
        overflow: hidden;
    }
    .seller>h3, .seller>p{
        position: relative;
        z-index: 1;
        color: var(--color-entry-title);
    }
    .sellerItem{
        height: 500px;
        padding: 0;
        background-color: var(--color-white);
        position: relative;
        z-index: 1;
    }
    .sellerItem img{
        width: 100%;
    }
    .sellerItem h4{
        margin-top: 25px;
        color: var(--color-black);
        padding: 0 20px;
    }
    .sellerItem p{
        margin-top: 15px;
        color: var(--color-entry-worth);
        font-size: 14px;
        padding: 0 20px;
    }
    .sellerArcBg{
        position: absolute;
        width: 2800px;
        height: 2800px;
        top: -2380px;
        left: 50%;
        margin-left: -1400px;
        background-color: var(--background-entry-seller-bottom);
        background: -webkit-linear-gradient(top, var(--color-white), var(--color-white), var(--color-white), var(--background-entry-seller-bottom));
        border-bottom-left-radius: 50%;
        border-bottom-right-radius: 50%;
        z-index: 0;
    }

    .brand{
        background-color: var(--color-white);
    }
    .brandItem{
        display: inline-block;
        vertical-align: top;
        width: 112px;
        height: 50px;
        line-height: 50px;
        background-color: var(--color-white);
        border: 1px solid var(--border-color-brand);
        margin: 4px;
    }
    .brandItem img{
        display: inline-block;
        vertical-align: middle;
    }

    .shop{
        background: url('@sign/assets/img/shop-4-steps.png') center no-repeat;
    }
    .titleShop{
        color: var(--color-entry-shop-title);
    }
    .titleShop::before{
        background: url('@sign/assets/img/title-on-left.png') center no-repeat;
    }
    .titleShop::after{
        background: url('@sign/assets/img/title-on-right.png') center no-repeat;
    }
    .titleDescribeShop{
        color: var(--color-entry-shop-title);
    }
    .shopItem{
        width: 255px;
        margin: 0 11px;
        background-color: var(--color-white);
        padding: 64px 0;
        text-align: center;
        box-shadow: 5px 5px 30px -11px var(--background-entry-button);
    }
    .shopItem:nth-child(3n){
        margin-right: 11px
    }
    .shopItem:nth-child(4n){
        margin: 0 0 0 11px;
    }
    .shopItem h4{
        color: var(--color-black);
        margin-top: 15px;
        padding: 0 15px;
    }

    .footer{
        position: relative;
        height: 500px;
        background: url('@sign/assets/img/bottom-banner.jpg') center no-repeat;
    }
    .footerContent{
        position: absolute;
        top: 80px;
        width: 100%;
        text-align: center;
    }
    .footerContent h3{
        color: var(--color-black);
        font-size: 48px;
        font-weight: bold;
        line-height: 70px;
    }
    .footerContent p{
        color: var(--color-black);
        font-size: 48px;
        line-height: 70px;
        font-weight: lighter;
    }
    .enteyBtnFooter{
        height: 72px;
        line-height: 72px;
        font-size: 36px;
        padding: 0 140px;
        margin-top: 50px
    }
</style>
