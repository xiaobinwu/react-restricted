<template>
    <div :class="$style.content">
        <h2 :class="$style.title">{{ $t('find.password') }}</h2>
        <p :class="$style.subTitle">{{ $t('find.password.tip') }}</p>
        <el-form ref="findpw" :model="form" :rules="rules" autocomplete="true">
            <el-form-item :error="form.emailErr" prop="email">
                <el-input
                    v-model="form.email"
                    :class="$style.inputStyle"
                    :placeholder="$t('register.email')"
                    prefix-icon="el-icon-message" maxlength="50"></el-input>
            </el-form-item>
            <el-form-item :error="form.captchaCodeErr" prop="captchaCode">
                <el-row :gutter="10">
                    <el-col :span="16">
                        <el-input
                            v-model="form.captchaCode"
                            :placeholder="$t('register.captcha.code')"
                            prefix-icon="el-icon-date"
                            maxlength="20"
                            @focus="captchaCodeReset"></el-input>
                    </el-col>
                    <el-col :span="7">
                        <img :class="$style.captchaImg" :src="form.captchaImg" @click="getCaptcha">
                    </el-col>
                </el-row>
            </el-form-item>
            <el-button :class="$style.continue" :loading="submit" type="primary" @click="nextStep">{{ $t('find.password.continue') }}</el-button>
        </el-form>
    </div>
</template>

<script>

    import { signEmailIsRegisted, signCaptcha, sendResetEmail } from '@sign/services/login';

    export default {
        data() {
            return {
                submit: false,
                form: {
                    email: '',
                    emailErr: '',
                    password: '',
                    captchaImg: '',
                    captchaCode: '',
                    captchaCodeErr: '',
                },
                rules: {
                    email: [
                        { required: true, message: this.$t('register.validate.email.empty') },
                        {
                            max: 50, message: this.$t('register.validate.email.maxlength'), trigger: 'change'
                        },
                        { type: 'email', message: this.$t('register.validate.email.notlegal'), trigger: 'blur' },
                        { type: 'email', validator: this.checkEmailIsRegisted, trigger: 'blur' },
                    ],
                    captchaCode: [
                        { required: true, message: this.$t('register.captcha.code.empty') },
                    ],
                }
            };
        },
        created() {
            const { query: { email } } = this.$route;
            this.form.email = email;

            this.getCaptcha();
            // 回车提交
            document.addEventListener('keydown', this.enterEvent, false);
        },
        beforeDestroy() {
            document.removeEventListener('keydown', this.enterEvent, false);
        },
        methods: {
            async checkEmailIsRegisted() {
                const { status, data } = await signEmailIsRegisted.http({
                    params: {
                        email: this.form.email,
                    }
                });

                if (status === 0) {
                    if (data === 0) {
                        this.form.emailErr = '';
                        setTimeout(() => {
                            this.form.emailErr = this.$t('sign.account.emailNotRegisted');
                        });
                    } else {
                        this.form.emailErr = '';
                    }
                } else {
                    this.form.emailErr = '';
                }
            },
            getCaptcha() {
                this.form.captchaImg = signCaptcha();
            },
            captchaCodeReset() {
                this.form.captchaCodeErr = '';
            },
            enterEvent(ev) {
                if (ev.keyCode === 13) {
                    this.nextStep();
                }
            },
            nextStep() {
                if (this.$refs.findpw && !this.submit && !this.form.emailErr) {
                    this.submit = true;
                    this.$refs.findpw.validate(async (valid) => {
                        if (valid) {

                            const { status, msg } = await sendResetEmail.http({
                                data: {
                                    email: this.form.email,
                                    captcha: this.form.captchaCode,
                                }
                            });

                            if (status === 10070002) {
                                // 验证码错误
                                this.form.captchaCodeErr = this.$t('register.captcha.code.notpass');
                                this.getCaptcha();
                            } else if (status !== 0) {
                                // 其他错误
                                this.$message.error(msg);
                            } else {
                                this.$router.push({
                                    name: 'signResult',
                                    query: {
                                        email: this.form.email,
                                        historyback: 1,
                                    }
                                });
                            }
                        }
                        setTimeout(() => {
                            this.submit = false;
                        }, 300);
                    });
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .content{
        width: 420px;
        min-height: 500px;
        padding: 80px 0 160px;
        margin:0 auto;
    }

    .content [class~="el-input__prefix"] {
        left: 15px;
        font-size: 20px;
    }

    .content [class~="el-input__inner"] {
        padding-left: 45px;
    }
    .content [class~="el-form-item__error"] {
        position: relative;
        font-size: 14px;
        line-height: 20px;
        padding: 10px 15px 0;
        color: var(--color-error);
    }
    .title{
        font-size:24px;
        margin-bottom: 10px;
        text-align: center;
    }

    .subTitle{
        line-height: 20px;
        margin-bottom: 30px;
        text-align: center;
        color: var(--color-text-regular);
    }
    i{
        color: var(--color-primary );
    }
    .captchaImg{
        cursor: pointer;
        display: block;
        height: 40px;
    }

    .continue{
        width: 100%;
        margin-top: 40px;
    }
</style>
