<template>
    <div :class="$style.container">
        <div :class="$style.content">
            <h2 :class="$style.title">{{ $t('register.title') }}</h2>
            <el-form ref="register" :model="form" :rules="rules" autocomplete="true">
                <el-form-item :error="form.emailErr" prop="email">
                    <el-input
                        v-model="form.email"
                        :placeholder="$t('register.email')" prefix-icon="el-icon-message" maxlength="50"></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input
                        v-model="form.password"
                        :placeholder="$t('register.pw')"
                        prefix-icon="el-icon-date"
                        type="password"
                        maxlength="16"></el-input>
                </el-form-item>
                <!-- <el-form-item v-if="showpwStrength">
                    <PwLevel :strength="pwStrengthLevel" />
                </el-form-item> -->
                <el-form-item prop="pwagain">
                    <el-input
                        v-model="form.pwagain"
                        :placeholder="$t('register.pw.again')"
                        prefix-icon="el-icon-date"
                        type="password"
                        maxlength="16"></el-input>
                </el-form-item>
                <el-form-item :error="form.captchaCodeErr" prop="captchaCode">
                    <el-row :gutter="10">
                        <el-col :span="16">
                            <el-input
                                v-model="form.captchaCode"
                                :placeholder="$t('register.captcha.code')"
                                prefix-icon="el-icon-date"
                                maxlength="20"
                                @focus="captchaCodeReset"></el-input>
                        </el-col>
                        <el-col :span="7">
                            <img :class="$style.captchaImg" :src="form.captchaImg" @click="getCaptcha">
                        </el-col>
                    </el-row>
                </el-form-item>
                <div :class="$style.buttonBox">
                    <el-button :class="$style.signBtn" :loading="submit" type="primary" @click="register">{{ $t('register.title') }}</el-button>
                </div>
                <div :class="$style.forget">{{ $t('register.hasaccount') }}
                    <router-link :to="{name: 'signLogin'}">{{ $t('register.login') }}</router-link>
                </div>
            </el-form>
        </div>
    </div>
</template>

<script>

    import { mapMutations } from 'vuex';
    import { UPDATE_USER } from '@/assets/js/store/mutationTypes';
    import { signEmailIsRegisted, signCaptcha, signRegister } from '@sign/services/login';

    export default {
        name: 'SignIn',
        components: {
            // PwLevel,
        },
        data() {
            return {
                // showpwStrength: false,
                // pwStrengthLevel: 0,
                submit: false,
                form: {
                    email: '',
                    emailErr: '',
                    password: '',
                    pwagain: '',
                    captchaCode: '',
                    captchaCodeErr: '',
                    captchaImg: '',
                },
                rules: {
                    email: [
                        { required: true, message: this.$t('register.validate.email.empty') },
                        {
                            max: 50, message: this.$t('register.validate.email.maxlength'), trigger: 'change'
                        },
                        { type: 'email', message: this.$t('register.validate.email.notlegal'), trigger: 'blur' },
                        { type: 'email', validator: this.checkEmailIsRegisted, trigger: 'blur' },
                    ],
                    password: [
                        { required: true, message: this.$t('register.validate.pw.empty'), trigger: 'blur' },
                        { validator: this.checkpw },
                    ],
                    pwagain: [
                        { required: true, message: this.$t('register.pw.again.empty') },
                        { validator: this.pwagain },
                    ],
                    captchaCode: [
                        { required: true, message: this.$t('register.captcha.code.empty') },
                    ],
                }
            };
        },
        created() {
            this.getCaptcha();
            // 回车提交
            document.addEventListener('keydown', this.enterEvent, false);
        },
        beforeDestroy() {
            document.removeEventListener('keydown', this.enterEvent, false);
        },
        methods: {
            ...mapMutations({
                updateUserInfo: UPDATE_USER
            }),
            async checkEmailIsRegisted() {
                const { status, data } = await signEmailIsRegisted.http({
                    params: {
                        email: this.form.email,
                    }
                });

                if (status === 0) {
                    if (data === 1) {
                        this.form.emailErr = '';
                        setTimeout(() => {
                            this.form.emailErr = this.$t('register.validate.email.exist');
                        });
                    } else {
                        this.form.emailErr = '';
                    }
                } else {
                    this.form.emailErr = '';
                }
            },
            getCaptcha() {
                this.form.captchaImg = signCaptcha();
            },
            // 检查密码类型
            checkpw(rule, value, callback) {
                if (value.length < 6 || value.length > 16) {
                    callback(new Error(this.$t('register.validate.pw.errlength')));
                }

                const pwTypes = {
                    numberic: /(\d+)/,
                    characters: /([a-zA-Z]+)/,
                    symbol: /\W+/,
                };
                let types = 0;

                for (const type in pwTypes) {
                    if (pwTypes[type].test(value)) {
                        types += 1;
                    }
                }

                if (types > 0) {
                    if (types === 1) {
                        callback(new Error(this.$t('register.validate.pw.tooeasy')));
                    }
                }
                callback();
            },
            pwagain(rule, value, callback) {
                if (value !== this.form.password) {
                    callback(new Error(this.$t('register.pw.again.notpass')));
                }
                callback();
            },
            captchaCode(rule, value, callback) {
                if (value !== this.form.password) {
                    callback(new Error(this.$t('register.captcha.code.notpass')));
                }
                callback();
            },
            captchaCodeReset() {
                this.form.captchaCodeErr = '';
            },
            enterEvent(ev) {
                if (ev.keyCode === 13) {
                    this.register();
                }
            },
            register() {
                if (this.$refs.register && !this.submit && !this.form.emailErr) {
                    this.submit = true;
                    this.$refs.register.validate(async (valid) => {
                        if (valid) {
                            const date = new Date();
                            const utcTimezone = -date.getTimezoneOffset() / 60;
                            const timeZone = `${utcTimezone > 0 ? '+' : '-'}${utcTimezone}`;

                            const { status, msg } = await signRegister.http({
                                data: {
                                    email: this.form.email,
                                    password: this.form.password,
                                    captcha: this.form.captchaCode,
                                    timeZone,
                                }
                            }).finally(() => {
                                this.submit = false;
                            });

                            if (status === 81001) {
                                // 邮箱已存在
                                this.form.emailErr = this.$t('register.validate.email.exist');

                            } else if (status === 10070002) {
                                // 验证码错误
                                this.form.captchaCodeErr = this.$t('register.captcha.code.notpass');
                                this.getCaptcha();
                            } else if (status !== 0) {
                                this.$message.error(msg);
                            } else {
                                // 校验通过
                                this.$router.push({
                                    name: 'signResult',
                                    query: {
                                        email: this.form.email,
                                    }
                                });
                            }
                        } else {
                            this.submit = false;
                        }
                    });
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .title{
        font-size: 24px;
        text-align: center;
        color: var(--color-black);
        margin-bottom: 30px;
    }
    .container{
        position: relative;
        padding: 80px 0 160px;
        width: var(--layout-safe-width);
        margin: 0 auto;

    }
    .container [class~="el-input__prefix"] {
        left: 15px;
        font-size: 20px;
    }
    .container [class~="el-input__inner"] {
        padding-left: 45px;
    }
    .container [class~="el-form-item__error"] {
        position: relative;
        font-size: 14px;
        line-height: 20px;
        padding: 10px 15px 0;
        color: var(--color-error);
    }
    .content{
        width: 420px;
        margin: 0 auto;
    }
    .captchaCode{
        width: 100px;
        margin:0 10px;
    }
    i{color: var(--color-primary);}
    .el-input__icon{
        font-size: 20px;
    }
    .captchaImg{
        cursor: pointer;
        display: block;
        height: 40px;
    }
    .buttonBox{
        margin: 30px 0 20px;
    }
    .signBtn{
        width: 100%;
    }
    .forget{
        text-align: center;
        line-height: 20px;
    }
    .enterBox{
        margin-top: 100px;
    }
    .entertitle{
        margin-bottom: 20px;
        text-align: center;
    }
</style>
