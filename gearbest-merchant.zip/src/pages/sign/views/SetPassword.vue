<template>
    <div :class="$style.container">
        <div v-if="expired" :class="[$style.content, $style.aligncenter]">
            <i :class="[$style.iconWarning, 'el-icon-warning']"></i>
            <p :class="$style.msg">{{ $t('sign.result.expired') }}</p>
        </div>
        <div v-else>
            <div v-if="passwordReseted" :class="$style.content">
                <div :class="$style.accountStatus">
                    <i :class="[$style.iconCheck, 'el-icon-circle-check']"></i>
                    <p :class="$style.msg">{{ $t('reset.password.success') }}</p>
                    <router-link :class="$style.signBtn" :to="{name: 'signLogin'}" type="primary">{{ $t('login.login') }}</router-link>
                </div>
            </div>
            <div v-else :class="$style.content">
                <h2 :class="$style.title">{{ $t('reset.password') }}</h2>
                <el-form ref="resetpw" :model="form" :rules="rules" autocomplete="true">
                    <el-form-item :error="form.emailNotRegisted" prop="password">
                        <el-input
                            v-model="form.password"
                            :placeholder="$t('reset.new.pw')"
                            type="password" maxlength="16"
                            prefix-icon="el-icon-date"></el-input>
                    </el-form-item>
                    <el-form-item prop="pwagain">
                        <el-input
                            v-model="form.pwagain"
                            :placeholder="$t('register.pw.again')"
                            prefix-icon="el-icon-date"
                            type="password"
                            maxlength="16"></el-input>
                    </el-form-item>
                    <el-button
                        :class="$style.continue"
                        :loading="submit"
                        type="primary"
                        @click="nextStep">{{ $t('reset.password.submit') }}</el-button>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>

    import { resetPassword } from '@sign/services/login';

    export default {
        data() {
            return {
                submit: false,
                expired: false,
                confirmCode: '',
                passwordReseted: false,
                form: {
                    password: '',
                    pwagain: '',
                },
                rules: {
                    password: [
                        { required: true, message: this.$t('register.validate.pw.empty'), trigger: 'blur' },
                        { validator: this.checkpw },
                    ],
                    pwagain: [
                        { required: true, message: this.$t('register.pw.again.empty') },
                        { validator: this.pwagain },
                    ],
                }
            };
        },
        created() {
            const { query: { confirmCode, expire } } = this.$route;
            if (+new Date() > expire * 1000) {
                this.expired = true;
            }
            this.confirmCode = confirmCode;
            // 回车提交
            document.addEventListener('keydown', this.enterEvent, false);
        },
        beforeDestroy() {
            document.removeEventListener('keydown', this.enterEvent, false);
        },
        methods: {
            // 检查密码类型
            checkpw(rule, value, callback) {
                if (value.length < 6 || value.length > 16) {
                    callback(new Error(this.$t('register.validate.pw.errlength')));
                }

                const pwTypes = {
                    numberic: /(\d+)/,
                    characters: /([a-zA-Z]+)/,
                    symbol: /\W+/,
                };
                let types = 0;

                for (const type in pwTypes) {
                    if (pwTypes[type].test(value)) {
                        types += 1;
                    }
                }

                if (types > 0) {
                    if (types === 1) {
                        callback(new Error(this.$t('register.validate.pw.tooeasy')));
                    }
                }
                callback();
            },
            pwagain(rule, value, callback) {
                if (value !== this.form.password) {
                    callback(new Error(this.$t('register.pw.again.notpass')));
                }
                callback();
            },
            enterEvent(ev) {
                if (ev.keyCode === 13) {
                    this.nextStep();
                }
            },
            nextStep() {
                if (this.$refs.resetpw && !this.submit) {
                    this.submit = true;
                    this.$refs.resetpw.validate(async (valid) => {
                        if (valid) {

                            const { status, msg } = await resetPassword.http({
                                data: {
                                    password: this.form.password,
                                    confirmCode: this.confirmCode,
                                }
                            });

                            if (status !== 0) {
                                // 其他错误
                                this.$message.error(msg);
                            } else {
                                this.passwordReseted = true;
                            }
                        }
                        setTimeout(() => {
                            this.submit = false;
                        }, 300);
                    });
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .content{
        width: 420px;
        min-height: 500px;
        padding: 80px 0 160px;
        margin:0 auto;
    }

    .aligncenter{text-align: center;}

    .content [class~="el-input__prefix"] {
        left: 15px;
        font-size: 20px;
    }

    .content [class~="el-input__inner"] {
        padding-left: 45px;
    }
    .content [class~="el-form-item__error"] {
        position: relative;
        font-size: 14px;
        line-height: 20px;
        padding: 10px 15px 0;
        color: var(--color-error);
    }
    .iconWarning{
        margin-top: 80px;
        font-size: 60px;
        color: #FFB403;
    }

    .msg{
        line-height: 26px;
        margin: 20px 0 40px;
    }
    .title{
        font-size:24px;
        margin-bottom: 10px;
        text-align: center;
    }

    .subTitle{
        line-height: 20px;
        margin-bottom: 30px;
        text-align: center;
        color: var(--color-text-regular);
    }

    .accountStatus{text-align: center;}

    .iconCheck{
        font-size: 60px;
        color: #5BBA69;
    }

    i{
        color: var(--color-primary );
    }
    .captchaImg{
        cursor: pointer;
        display: block;
        height: 40px;
    }

    .continue{
        width: 100%;
        margin-top: 40px;
    }
    .msg{
        line-height: 26px;
        margin: 20px 0 40px;
    }

    .signBtn{
        color: #fff;
        display: block;
        line-height: 40px;
        background-color: var(--color-primary);
        border-radius: 4px;
        &:hover{
            color: #fff;
            background-color: var(--color-primary-darken);
        }
    }

</style>
