import router from '@/assets/js/router';
import SignLayout from '@/components/SignLayout';
import EmptyLayout from '@/components/EmptyLayout';

import children from './routes';

const url = window.location.hash.split('?')[0];
const isIndex = url.indexOf('/sign/sign-index');

// Layout 为布局组件
// 所有的视图挂在它下面
const routes = [{
    path: '/',
    component: isIndex < 0 ? SignLayout : EmptyLayout,
    redirect: '/sign/sign-index',
    meta: {},
    children
}];

export default router({
    routes
});
