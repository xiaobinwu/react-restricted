import asyncComponent from '@/assets/js/common/asyncComponent';

export default [{
    path: '/sign/login',
    name: 'signLogin',
    meta: {
        title: 'login.title',
        showHeaderMenu: false,
        requireAuth: true
    },
    component: () => asyncComponent(import('@sign/views/Login')),
}, {
    path: '/sign/register',
    name: 'signRegister',
    meta: {
        title: 'register.title',
        showHeaderMenu: false,
        requireAuth: true
    },
    component: () => asyncComponent(import('@sign/views/Register'))
}, {
    path: '/sign/active-account',
    name: 'activeAccount',
    meta: {
        title: 'sign.active.title',
        showHeaderMenu: false
    },
    component: () => asyncComponent(import('@sign/views/ActiveAccount'))
}, {
    path: '/sign/sign-result',
    name: 'signResult',
    meta: {
        title: 'sign.result.title',
        showHeaderMenu: false
    },
    component: () => asyncComponent(import('@sign/views/SignResult'))
}, {
    path: '/sign/find-password',
    name: 'findPassword',
    meta: {
        title: 'find.password',
        showHeaderMenu: false
    },
    component: () => asyncComponent(import('@sign/views/FindPassword'))
}, {
    path: '/sign/reset-password',
    name: 'resetPassword',
    meta: {
        title: 'reset.password',
        showHeaderMenu: false
    },
    component: () => asyncComponent(import('@sign/views/SetPassword'))
}, {
    path: '/sign/sign-index',
    name: 'signIndex',
    meta: {
        title: 'entry.step5'
    },
    component: () => asyncComponent(import('@sign/views/signIndex'))
}];
