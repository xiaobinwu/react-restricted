import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import transactionLang from '@/lang/transaction';
import router from './router';

(async () => {
    const langInstance = await lang({
        local: transactionLang,
        moduleName: 'transaction'
    });

    app({
        lang: langInstance,
        router
    });
})();
