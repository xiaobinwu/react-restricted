<template>
    <div :class="$style.container">
        <div :class="$style.emailSent" v-html="$t('transaction.active.email.sent', [userInfo.email])"></div>
        <p :class="$style.expireTip">{{ $t('transaction.active.expire.tip') }}</p>
        <p :class="$style.noemail">{{ $t('transaction.active.noemail') }}
            <span :class="$style.sentAgain" @click="sentAgain">{{ $t('transaction.active.sent.again') }}</span>
        </p>
    </div>
</template>

<script>

    import { sendEmail } from '@transaction/services/transaction';
    import { mapState } from 'vuex';

    export default {
        data() {
            return {
                sendStatus: 0,
                email: '',
            };
        },
        computed: {
            ...mapState({
                userInfo: state => state.user.userInfo,
            })
        },
        methods: {
            async sentAgain() {
                if (this.sendStatus === 0) {
                    this.sendStatus = 1;
                    const { status, msg } = await sendEmail.http();

                    if (status === 0) {
                        this.$message({
                            message: this.$t('transaction.active.sent.success'),
                            type: 'success',
                        });
                    } else {
                        this.$message.error(msg);
                    }
                    setTimeout(() => {
                        this.sendStatus = 0;
                    }, 1000);
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container{
        width: 420px;
        margin: 0 auto;
        padding: 160px 0;
        text-align: center;
        line-height: 20px;
        min-height: 500px;
    }

    .container [class^='emailAddress'] {
        color: #F5A623;
    }

    .emailSent{
        font-size: 18px;
        line-height: 26px;
        margin-bottom: 10px;
    }

    .expireTip{
        margin-bottom: 40px;
    }

    .sentAgain{
        cursor: pointer;
        color: var(--color-primary-darken);
    }
</style>
