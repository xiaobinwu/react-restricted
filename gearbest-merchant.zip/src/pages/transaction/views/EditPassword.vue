<template>
    <div :class="$style.container">
        <div v-if="accountStatus === 1" :class="$style.content">
            <h2 :class="$style.title">{{ $t('transaction.reset.password') }}</h2>
            <el-form ref="resetpw" :model="form" :rules="rules" autocomplete="true">
                <el-form-item :error="form.emailNotRegisted" prop="password">
                    <el-input
                        v-model="form.password"
                        :placeholder="$t('transaction.reset.new.pw')"
                        type="password" maxlength="16"
                        prefix-icon="el-icon-date"></el-input>
                </el-form-item>
                <el-form-item prop="pwagain">
                    <el-input
                        v-model="form.pwagain"
                        :placeholder="$t('transaction.pw.again')"
                        prefix-icon="el-icon-date"
                        type="password"
                        maxlength="16"></el-input>
                </el-form-item>
                <el-button :class="$style.continue" :loading="submit" type="primary" @click="nextStep">
                    {{ $t('transaction.reset.password.submit') }}</el-button>
            </el-form>
        </div>

        <div v-else-if="accountStatus === 2" :class="$style.content">
            <div :class="$style.accountStatus">
                <i :class="[$style.iconCheck, 'el-icon-circle-check']"></i>
                <p :class="$style.msg">{{ $t('transaction.reset.password.success') }}</p>
                <el-button :class="$style.toCapital" type="primary" @click="toCapital">{{ $t('transaction.go.capital') }}</el-button>
            </div>
        </div>

        <div v-else-if="accountStatus === 3" :class="$style.content">
            <i :class="[$style.iconWarning, 'el-icon-warning']"></i>
            <p :class="$style.msg">{{ $t('transaction.result.expired') }}</p>
        </div>
    </div>
</template>

<script>

    import { editPassword, setPassword } from '@transaction/services/transaction';

    export default {
        data() {
            return {
                submit: false,
                confirmCode: '',
                accountStatus: 1,
                form: {
                    password: '',
                    pwagain: '',
                },
                rules: {
                    password: [
                        { required: true, message: this.$t('transaction.validate.pw.empty'), trigger: 'blur' },
                        { validator: this.checkpw },
                    ],
                    pwagain: [
                        { required: true, message: this.$t('transaction.pw.again.empty') },
                        { validator: this.pwagain },
                    ],
                }
            };
        },
        created() {
            const { query: { confirmCode, expire } } = this.$route;
            const currentTime = Math.ceil(new Date().getTime() / 1000);

            if (expire && currentTime > expire) {
                this.accountStatus = 3;
            }
            this.confirmCode = confirmCode;
            // 回车提交
            document.addEventListener('keydown', this.enterEvent, false);
        },
        beforeDestroy() {
            document.removeEventListener('keydown', this.enterEvent, false);
        },
        methods: {
            // 检查密码类型
            checkpw(rule, value, callback) {
                if (value.length < 6 || value.length > 16) {
                    callback(new Error(this.$t('transaction.validate.pw.errlength')));
                }

                const pwTypes = {
                    numberic: /(\d+)/,
                    characters: /([a-zA-Z]+)/,
                    symbol: /\W+/,
                };
                let types = 0;

                for (const type in pwTypes) {
                    if (pwTypes[type].test(value)) {
                        types += 1;
                    }
                }

                if (types > 0) {
                    if (types === 1) {
                        callback(new Error(this.$t('transaction.validate.pw.tooeasy')));
                    }
                }
                callback();
            },
            pwagain(rule, value, callback) {
                if (value !== this.form.password) {
                    callback(new Error(this.$t('transaction.pw.again.notpass')));
                }
                callback();
            },
            enterEvent(ev) {
                if (ev.keyCode === 13) {
                    this.nextStep();
                }
            },

            // 跳转到资金账户管理
            toCapital() {
                this.$router.gbPush('/capital/loan-query');
            },

            nextStep() {
                if (this.$refs.resetpw && !this.submit) {
                    this.submit = true;
                    this.$refs.resetpw.validate(async (valid) => {
                        if (valid) {
                            let postData = {};
                            let postInterface = null;
                            if (this.confirmCode) {
                                postData = {
                                    password: this.form.password,
                                    confirmCode: this.confirmCode,
                                };
                                postInterface = editPassword;
                            } else {
                                postData = {
                                    password: this.form.password,
                                };
                                postInterface = setPassword;
                            }
                            const { status, msg } = await postInterface.http({
                                data: postData
                            });

                            if (status === 0) {
                                this.accountStatus = 2;
                            } else if (status === 10070004) {
                                this.$message.error(msg);
                                this.accountStatus = 3;
                            } else {
                                // 其他错误
                                this.$message.error(msg);
                            }
                        }
                        setTimeout(() => {
                            this.submit = false;
                        }, 300);
                    });
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container{
        margin: 0 auto;
        padding: 1px;
        background-color: var(--color-white);
    }
    .content{
        width: 420px;
        min-height: 500px;
        padding: 80px 0 160px;
        margin:0 auto;
        text-align: center;
    }

    .content [class~="el-input__prefix"] {
        left: 15px;
        font-size: 20px;
    }

    .content [class~="el-input__inner"] {
        padding-left: 45px;
    }
    .content [class~="el-form-item__error"] {
        position: relative;
        font-size: 14px;
        line-height: 20px;
        padding: 10px 15px 0;
        color: var(--color-error);
    }
    .title{
        font-size:24px;
        margin-bottom: 25px;
        text-align: center;
    }

    .subTitle{
        line-height: 20px;
        margin-bottom: 30px;
        text-align: center;
        color: var(--color-text-regular);
    }

    .accountStatus{text-align: center;}

    .iconCheck{
        font-size: 60px;
        color: #5BBA69;
    }

    i{
        color: var(--color-primary );
    }
    .captchaImg{
        cursor: pointer;
        display: block;
        height: 40px;
    }

    .continue{
        width: 100%;
        margin-top: 20px;
    }
    .msg{
        line-height: 26px;
        margin: 20px 0 40px;
    }

    .toCapital{
        color: #fff;
        display: block;
        width: 100%;
        background-color: var(--color-primary);
        border-radius: 4px;
        &:hover{
            color: #fff;
            background-color: var(--color-primary-darken);
        }
    }
    .iconWarning{
        font-size: 60px;
        color: #FFB403;
        margin-top: 100px;
    }

</style>
