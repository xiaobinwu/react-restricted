/**
 * Created by Jiazhan Li on 2018/12/27.
 */

import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    // 设置交易密码
    {
        path: '/transaction/reset-password',
        name: 'EditPassword',
        meta: {
            title: 'transaction.menu.editPassword',
            showHeaderMenu: false
        },
        component: () => asyncComponent(import('@transaction/views/EditPassword'))
    },
    // 发送邮件页面
    {
        path: '/transaction/safe-email',
        name: 'SafeEmail',
        meta: {
            title: 'transaction.menu.safeEmail',
            showHeaderMenu: false
        },
        component: () => asyncComponent(import('@transaction/views/SafeEmail'))
    },
];
