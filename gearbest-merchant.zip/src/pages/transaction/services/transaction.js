/**
 * Created by Jiazhan Li on 2019/2/27.
 */

import Service from '@/assets/js/Service';

/**
 * 修改交易密码
 */
export const editPassword = new Service({
    url: '/account/reset-safe-password',
    method: 'POST',
    showError: true,
});

/**
 * 初次设置安全密码
 */
export const setPassword = new Service({
    url: '/user/set-safe-password',
    method: 'POST',
    showError: true,
});


// 发送安全密码重置邮件
export const sendEmail = new Service({
    url: '/user/send-reset-safe-email',
    method: 'get',
    showError: true,
});
