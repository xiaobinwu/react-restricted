<template>
    <div :class="$style.container">
        <progress-bar :active="stepNo" :steps="stepsData"></progress-bar>
        <!-- 个人资料填写 -->
        <contact-info
            v-if="stepNo === 0"
            :post-entry-info="postEntryInfo"
            @update="updateEntryInfo">
        </contact-info>

        <!-- 公司资料填写 -->
        <div v-if="stepNo === 1">
            <div :class="$style.radioBox">
                <label :class="$style.radioLabel">{{ $t('user.company.type.select') }}</label>
                <el-radio-group v-model="companyAreaCode">
                    <el-radio
                        v-for="item in companyAreaCodeList"
                        :key="item.bigName"
                        :label="item.bigName">{{ $t(`user.company.type.${item.smllName}`) }}</el-radio>
                </el-radio-group>
            </div>
            <company-info-mainland
                v-if="companyAreaCode === 'CN'"
                :post-entry-info="postEntryInfo"
                @update="updateEntryInfo">
                <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
                <el-button @click="stepNo=0">{{ $t('user.contact.previous.step') }}</el-button>
            </company-info-mainland>
            <company-info-hongkong
                v-if="companyAreaCode === 'HK'"
                :post-entry-info="postEntryInfo"
                @update="updateEntryInfo">
                <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
                <el-button @click="stepNo=0">{{ $t('user.contact.previous.step') }}</el-button>
            </company-info-hongkong>
        </div>

        <!-- 收款账户信息 -->
        <div v-if="stepNo === 2">
            <div :class="$style.radioBox">
                <label :class="$style.radioLabel">{{ $t('user.account.collection') }}</label>
                <el-radio-group v-model="accountType">
                    <el-radio
                        v-for="item in AccountTypeList"
                        :key="item.val"
                        :label="item.val">{{ $t(`user.account.${item.name}`) }}</el-radio>
                </el-radio-group>
                <p :class="$style.accountWarning">
                    <i class="el-icon-warning"></i>
                    {{ $t('user.account.warning') }}
                </p>
            </div>
            <collection-account-dollar
                v-if="accountType === 1"
                :post-entry-info="postEntryInfo"
                @update="updateEntryInfo">
                <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
                <el-button @click="stepNo=1">{{ $t('user.contact.previous.step') }}</el-button>
                <el-button @click="stepNo=3">{{ $t('user.skip.thisstep.account') }}</el-button>
            </collection-account-dollar>
            <collection-account-payoneer
                v-if="accountType === 2"
                :post-entry-info="postEntryInfo"
                @update="updateEntryInfo">
                <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
                <el-button @click="stepNo=1">{{ $t('user.contact.previous.step') }}</el-button>
                <el-button @click="stepNo=3">{{ $t('user.skip.thisstep.account') }}</el-button>
            </collection-account-payoneer>
        </div>
        <shop-reiew
            v-if="stepNo === 3"
            :post-entry-info="postEntryInfo"
            @update="updateEntryInfo">
            <el-button @click="stepNo=2">{{ $t('user.contact.previous.step') }}</el-button>
        </shop-reiew>
        <div v-if="stepNo === 4">
            <review-under v-if="postEntryInfo.checkStatus === 3"></review-under>
            <review-fail
                v-if="postEntryInfo.checkStatus === 2"
                @update="updateEntryInfo">
                <!-- <ul>
                    <li v-for="(item, index) in postEntryInfo.checkRemark" :key="index">{{ item }}</li>
                </ul> -->
                <pre :class="$style.checkRemark">{{ postEntryInfo.checkRemark }}</pre>
            </review-fail>
        </div>
    </div>
</template>

<script>
    import ProgressBar from '@/components/ProgressBar';
    import {
        getEntryInfo,
    } from '@user/services/user';
    import ContactInfo from '@user/components/ContactsInfo';
    import companyInfoMainland from '@user/components/CompanyInfoMainland';
    import companyInfoHongkong from '@user/components/CompanyInfoHongkong';
    import collectionAccountDollar from '@user/components/CollectionAccountDollar';
    import collectionAccountPayoneer from '@user/components/CollectionAccountPayoneer';
    import ShopReview from '@user/components/ShopsReview';
    import reviewUnder from '@user/components/ReviewUnder';
    import reviewFail from '@user/components/ReviewFail';
    import { mapState, mapMutations } from 'vuex';
    import { UPDATE_USER } from '@/assets/js/store/mutationTypes';

    export default {
        name: 'Entry',
        components: {
            'progress-bar': ProgressBar,
            'contact-info': ContactInfo,
            'company-info-mainland': companyInfoMainland,
            'company-info-hongkong': companyInfoHongkong,
            'collection-account-dollar': collectionAccountDollar,
            'collection-account-payoneer': collectionAccountPayoneer,
            'shop-reiew': ShopReview,
            'review-under': reviewUnder,
            'review-fail': reviewFail,
        },
        data() {
            return {
                stepNo: 0,
                stepsData: [
                    `1.${this.$t('user.entry.step1')}`,
                    `2.${this.$t('user.entry.step2')}`,
                    `3.${this.$t('user.entry.step3')}`,
                    `4.${this.$t('user.entry.step4')}`,
                    `5.${this.$t('user.entry.step5')}`,
                ],
                postEntryInfo: {},
                companyAreaCode: 'CN',
                companyAreaCodeList: [
                    { bigName: 'CN', smllName: 'cn' },
                    { bigName: 'HK', smllName: 'hk' }
                ],
                accountType: 1,
                AccountTypeList: [
                    { name: 'dollar', val: 1 },
                    { name: 'payoneer', val: 2 }
                ]
            };
        },

        computed: {
            ...mapState({
                userInfo: state => state.user.userInfo,
                isLogin: state => state.user.isLogin,
            })
        },
        async created() {
            await this.init();
            // const { accountStatus } = this.userInfo;
            // if (accountStatus === 0) {
            //     this.stepNo = 0;
            // } else if (accountStatus === 1 || accountStatus === 2) {
            //     this.stepNo = 4;
            // }
        },
        methods: {
            ...mapMutations({
                updateUserInfo: UPDATE_USER
            }),
            async updateEntryInfo(data) {
                this.stepNo = data.step;
                if (data.entryInfo) {
                    this.postEntryInfo = { ...this.postEntryInfo, ...data.entryInfo };
                }
                this.companyAreaCode = this.postEntryInfo.companyAreaCode ? this.postEntryInfo.companyAreaCode : 'CN';
                if (this.postEntryInfo.shopInfo && this.postEntryInfo.shopInfo.financialInfo
                    && this.postEntryInfo.shopInfo.financialInfo.accountType) {
                        this.accountType = this.postEntryInfo.shopInfo.financialInfo.accountType;
                    }
            },
            async init() {
                const { status, data } = await getEntryInfo.http();
                if (status === 0) {
                    this.postEntryInfo = data;
                    this.companyAreaCode = this.postEntryInfo.companyAreaCode ? this.postEntryInfo.companyAreaCode : 'CN';
                    if (this.postEntryInfo.shopInfo && this.postEntryInfo.shopInfo.financialInfo
                        && this.postEntryInfo.shopInfo.financialInfo.accountType) {
                            this.accountType = this.postEntryInfo.shopInfo.financialInfo.accountType;
                        }
                    if (this.postEntryInfo.checkStatus === 0) {
                        this.stepNo = 0;
                    } else if (this.postEntryInfo.checkStatus === 2 || this.postEntryInfo.checkStatus === 3) {
                        this.stepNo = 4;
                    } else if (this.postEntryInfo.checkStatus === 1) {
                        this.userInfo.accountStatus = 3;
                        this.updateUserInfo({ userInfo: this.userInfo, isLogin: true });
                        this.$router.gbPush('/index/home');
                    }
                }
            },
            returnMerchants() {
                this.$confirm(this.$t('user.whether.withdraw.application'), this.$t('user.prompt.message'), {
                    confirmButtonText: this.$t('user.confirm.text'),
                    cancelButtonText: this.$t('user.cancel.text'),
                    type: 'warning'
                }).then(() => {
                    this.$router.gbPush('/sign/sign-index');
                }).catch(() => {

                });
            },
        }

    };
</script>

<style module>
    @import 'variable.css';

    .container{
        width: var(--layout-safe-width);
        margin: 0 auto;
        padding-top: 30px;
    }
    .container [class~="line"]{
        text-align: center;
    }
    .container [class~="el-input-group__prepend"]{
        background-color: var(--color-white);
    }
    .radioBox{
        width: 1000px;
        margin: 50px auto 0;
    }
    .radioLabel{
        display: inline-block;
        width: 200px;
        text-align: right;
        padding: 0 12px 0 0;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
        cursor: pointer;
    }
    .accountWarning{
        display: inline-block;
        color: var(--color-error );
        margin-left: 30px;
    }
    .checkRemark{
        margin-top: 5px;
        white-space: normal;
    }


</style>
