import asyncComponent from '@/assets/js/common/asyncComponent';

export default [{
    path: '/user/entry',
    name: 'userEntry',
    meta: {
        title: '商家入驻',
        showHeaderLogout: false
    },
    component: () => asyncComponent(import('@user/views/Entry'))
}];
