<template>
    <div :class="$style.container">
        <el-form
            ref="formShopInfo"
            :model="formShopInfo"
            :rules="rules"
            label-position="right"
            label-width="120px"
            class="demo-ruleForm">
            <div :class="$style.info">
                <el-form-item :label="$t('user.shop.name')" prop="shopName">
                    <el-input
                        :class="$style.formLargeInput"
                        v-model="formShopInfo.shopName"
                        :placeholder="$t('user.shop.name.place')"
                        @change="validateShopName"></el-input>
                </el-form-item>
                <el-form-item :label="$t('user.shop.business')" prop="shopBusiness">
                    <el-checkbox
                        v-for="item in businessList"
                        :key="item.key"
                        v-model="item.checked"
                        @change="getCheckedBus">{{ item.value }}</el-checkbox>
                    <el-form-item :class="$style.formSmallInput" prop="shopBusinessOther">
                        <el-input
                            v-if="otherCheched"
                            v-model="formShopInfo.shopBusinessOther"
                            maxlength="50"></el-input>
                    </el-form-item>
                </el-form-item>
            </div>
            <div :class="$style.buttonBox">
                <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
                <slot></slot>
                <el-button type="primary" @click="submitForm('formShopInfo')">{{ $t('user.next.step.submit') }}</el-button>
            </div>
        </el-form>
    </div>
</template>

<script>
    import {
        getEnterData,
        checkShopName,
        updateEntryInfo,
    } from '@user/services/user';
    import { mapState, mapMutations } from 'vuex';
    import { UPDATE_USER } from '@/assets/js/store/mutationTypes';

    export default {
        name: 'ShopReview',
        props: {
            postEntryInfo: {
                type: Object,
                required: true,
            },
        },
        data() {
            const validateShop = async (rule, value, callback) => {
                const { status, data } = await checkShopName.http({
                    showError: true,
                    params: {
                        shopName: value,
                    }
                });
                if (status === 0) {
                    if (data === 1) {
                        callback(new Error(this.$t('user.shopname.validate.errrepeat')));
                    } else {
                        callback();
                    }
                }
            };
            return {
                entryInfo: {},
                businessList: [],
                otherKeyIndex: Number,
                otherCheched: false,
                formShopInfo: {
                    shopName: '',
                    shopBusiness: [],
                    shopBusinessOther: ''
                },
                // 校验规则
                rules: {
                    shopName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.shopname.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.shopname.validate.errlength'),
                        },
                        {
                            validator: validateShop,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    shopBusiness: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.shopbusiness.validate.empty'),
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    shopBusinessOther: [
                        {
                            max: 30,
                            message: this.$t('user.shopbusiness.other.validate.errlength'),
                        }
                    ],
                }
            };
        },
        computed: {
            ...mapState({
                userInfo: state => state.user.userInfo,
                shopFreeze: state => state.user.shopFreeze,
                isLogin: state => state.user.isLogin,
            })
        },
        watch: {
            postEntryInfo() {
                // 初始化表单
                this.init();
            }
        },
        async created() {
            await this.getBusiness();
            this.init();
        },
        methods: {
            ...mapMutations({
                updateUserInfo: UPDATE_USER
            }),
            // 初始化表单
            async init() {
                this.entryInfo = this.postEntryInfo;
                if (this.postEntryInfo.shopInfo) {
                    this.formShopInfo.shopName = this.postEntryInfo.shopInfo.shopName;
                }
                if (this.postEntryInfo.mainBusiness) {
                    const mainBusinessJson = JSON.parse(this.postEntryInfo.mainBusiness);
                    this.formShopInfo.shopBusiness = mainBusinessJson.ids;
                    this.formShopInfo.shopBusinessOther = mainBusinessJson.other;
                    this.formShopInfo.shopBusiness.forEach((ibsItem) => {
                        if (ibsItem === 100) {
                            this.otherCheched = true;
                        }
                        this.businessList.forEach((buItem) => {
                            if (ibsItem === buItem.key) {
                                buItem.checked = true;
                            }
                        });
                    });
                }
            },
            // 获取主营行业
            async getBusiness() {
                const vm = this;
                const { status, data } = await getEnterData.http();
                if (status === 0) {
                    data.mainBusiness.forEach((item, index) => {
                        item.checked = false;
                        vm.businessList.push(item);
                    });
                }
            },

            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.$confirm(this.$t('user.shop.promptnote'), this.$t('user.prompt.message'), {
                            confirmButtonText: this.$t('user.confirm.text'),
                            cancelButtonText: this.$t('user.cancel.text'),
                            type: 'warning'
                        }).then(async () => {
                            if (!this.entryInfo.shopInfo) {
                                this.entryInfo.shopInfo = {};
                            }
                            this.entryInfo.shopInfo.shopName = this.formShopInfo.shopName;
                            this.entryInfo.mainBusiness = JSON.stringify({
                                ids: this.formShopInfo.shopBusiness,
                                other: this.formShopInfo.shopBusinessOther
                            });
                            this.entryInfo.checkStatus = 3;
                            const { status, msg } = await updateEntryInfo.http({
                                data: {
                                    ...this.entryInfo
                                }
                            });
                            if (status === 0) {
                                // 更新用户状态
                                this.userInfo.accountStatus = 1;
                                this.updateUserInfo({ userInfo: this.userInfo, isLogin: true });
                                this.$emit('update', { entryInfo: this.entryInfo, step: 4 });
                            } else {
                                this.$message.error(msg);
                            }
                        }).catch(() => {

                        });
                    }
                });
                // const vm = this;
            },

            getCheckedBus() {
                const vm = this;
                vm.formShopInfo.shopBusiness = [];
                vm.businessList.forEach((item) => {
                    if (item.key === 100) {
                        vm.otherCheched = item.checked;
                    }
                    if (item.checked) {
                        vm.formShopInfo.shopBusiness.push(item.key);
                    }
                });
            },

            returnMerchants() {
                this.$confirm(this.$t('user.whether.withdraw.application'), this.$t('user.prompt.message'), {
                    confirmButtonText: this.$t('user.confirm.text'),
                    cancelButtonText: this.$t('user.cancel.text'),
                    type: 'warning'
                }).then(() => {
                    this.$router.gbPush('/sign/sign-index');
                }).catch(() => {

                });
            },
            validateShopName() {
                this.formShopInfo.shopName = this.formShopInfo.shopName.replace(
                    /[^\d\w\s!@#$%^&*()_+<>?:,./;’]/g, ''
                );
            },
        },
    };
</script>

<style module>
    @import 'variable.css';

    .container{
        width: var(--layout-safe-width);
        margin: 0 auto;
        padding-top: 20px;
    }
    .container [class~="el-checkbox"]{
        margin-left: 0;
        margin-right: 30px;
    }
    .info{
        width: 800px;
        margin: 50px auto;
    }
    .formLargeInput{
        width: 620px;
    }
    .formSmallInput{
        display: inline-block;
        width: 200px;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
        cursor: pointer;
    }
</style>
