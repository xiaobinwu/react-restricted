<template>
    <el-form
        ref="formCompanyInfo"
        :model="formCompanyInfo"
        :rules="rules"
        label-position="right"
        label-width="220px"
        class="demo-ruleForm">
        <div :class="$style.info">
            <el-form-item :label="$t('user.company.name')" prop="companyName">
                <el-input
                    :class="$style.formLargeInput"
                    v-model="formCompanyInfo.companyName"
                    :placeholder="$t('user.company.prompt.name')"
                    maxlength="50"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.company.renum')" :error="errorMse" prop="registerNumber">
                <el-input
                    :class="$style.formLargeInput"
                    v-model="formCompanyInfo.registerNumber"
                    :placeholder="$t('user.company.prompt.renum')"
                    maxlength="50"
                    @change="validateRegisterNum"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.company.legaldeputy')" prop="legalRepresentative">
                <el-input :class="$style.formSmallInput" v-model="formCompanyInfo.legalRepresentative" maxlength="50"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.company.established')">
                <el-date-picker
                    :class="$style.formSmallInput"
                    :placeholder="$t('user.please.choose')"
                    v-model="formCompanyInfo.establishTime"
                    value-format="timestamp"
                    type="date">
                </el-date-picker>
            </el-form-item>
            <el-form-item :label="$t('user.company.recapital')" prop="registerCapital">
                <el-input
                    :class="$style.formSmallInput"
                    v-model="formCompanyInfo.registerCapital"
                    :placeholder="$t('user.company.prompt.recapital')"
                    maxlength="20"></el-input>
                <span> {{ $t('user.company.unit.recapital') }} </span>
            </el-form-item>
            <el-form-item :label="$t('user.company.readdress')" prop="registerAddress">
                <address-linkage v-model="formCompanyInfo.registerAddress" :countrys="countrys" :positions="formCompanyInfo.companyAreaCode">
                    <el-input v-model="formCompanyInfo.registerAddress.addressDetail" maxlength="200"></el-input>
                </address-linkage>
            </el-form-item>
            <el-form-item :label="$t('user.company.ofaddress')" prop="companyAddress">
                <address-linkage v-model="formCompanyInfo.companyAddress" :countrys="countrys" :positions="formCompanyInfo.companyAreaCode">
                    <el-input v-model="formCompanyInfo.companyAddress.addressDetail" maxlength="200"></el-input>
                    <el-checkbox slot="ditto" v-model="addressChecked" @change="dittoAddress">{{ $t('user.sign.ditto') }}</el-checkbox>
                </address-linkage>
            </el-form-item>
            <el-form-item :label="$t('user.company.bnlicensetype')" prop="licenseType">
                <el-select :class="$style.formSmallInput" v-model="formCompanyInfo.licenseType" :placeholder="$t('user.please.choose')">
                    <el-option
                        v-for="item in licenseList"
                        :key="item.value"
                        :label="item.value"
                        :value="item.key">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item :label="$t('user.company.bnlicenseperiod')">
                <el-date-picker
                    v-model="formCompanyInfo.licenseStartDate"
                    :placeholder="$t('user.please.choose')"
                    value-format="timestamp"
                    type="date">
                </el-date-picker>
                <span>{{ $t('user.sign.to') }}</span>
                <el-date-picker
                    v-model="formCompanyInfo.licenseEndDate"
                    :placeholder="$t('user.please.choose')"
                    value-format="timestamp"
                    type="date">
                </el-date-picker>
                <el-checkbox :class="$style.enduringMargin" v-model="formCompanyInfo.licenseIsLong">{{ $t('user.sign.long') }}</el-checkbox>
            </el-form-item>
            <el-form-item :label="$t('user.company.bnscope')" prop="businessScope">
                <el-input
                    :class="$style.formLargeInput"
                    v-model="formCompanyInfo.businessScope"
                    :rows="4"
                    :placeholder="$t('user.please.enter.content')"
                    maxlength="300"
                    type="textarea">
                </el-input>
            </el-form-item>
            <el-form-item :label="$t('user.company.ofphone')">
                <el-col :span="3">
                    <el-form-item prop="businessPhoneAreaCode">
                        <el-input
                            v-model="formCompanyInfo.businessPhoneAreaCode"
                            :placeholder="$t('user.contact.prompt.zone')"
                            maxlength="4"
                            @change="phoneAreaCodeValidata"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="1" class="line">-</el-col>
                <el-col :span="6">
                    <el-form-item prop="businessPhone">
                        <el-input
                            v-model="formCompanyInfo.businessPhone"
                            :placeholder="$t('user.contact.prompt.zone')"
                            maxlength="8"
                            @change="businessPhoneValidata"></el-input>
                    </el-form-item>
                </el-col>
            </el-form-item>
            <el-form-item :label="$t('user.company.website')" prop="companyWebsite">
                <el-input :class="$style.formLargeInput" v-model="formCompanyInfo.companyWebsite" maxlength="50"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.company.bnmodel')">
                <el-col :span="9">
                    <el-form-item prop="bnmodel">
                        <el-select :class="$style.formSmallInput" v-model="formCompanyInfo.businessModel" :placeholder="$t('user.please.choose')">
                            <el-option
                                v-for="item in businessModelList"
                                :key="item.key"
                                :label="item.value"
                                :value="item.key">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col
                    v-if="formCompanyInfo.businessModel === 2 || formCompanyInfo.businessModel === 3"
                    :span="15">
                    <el-form-item
                        :label="$t('user.company.shoplink')"
                        prop="shopLink">
                        <el-input :class="$style.formSmallInput" v-model="formCompanyInfo.shopLink" ></el-input>
                    </el-form-item>
                </el-col>
            </el-form-item>
            <el-form-item :label="$t('user.company.idelectronic')" prop="legalUrls">
                <p :class="$style.uploadTitle">
                    {{ $t('user.company.idelectronic.title') }}
                    <i :class="$style.uploadIcon" class="el-icon-question">
                        <img :class="$style.uploadSample" src="@user/assets/img/id-card-template.png" alt="">
                    </i>
                </p>
                <el-upload
                    :class="[formCompanyInfo.legalUrls.length < 2 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadLegal"
                    :on-success="successLegal"
                    :on-remove="removeLegal"
                    :show-file-list="true"
                    :file-list="formCompanyInfo.legalUrls"
                    :data="{ method: 'corporateAuth' }"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.company.idelectronic.condition') }}</p>
            </el-form-item>
            <el-form-item :label="$t('user.company.licenseelectronic')" prop="licenseUrls">
                <p :class="$style.uploadTitle">
                    {{ $t('user.company.licenseelectronic.title') }}
                    <i :class="$style.uploadIcon" class="el-icon-question">
                        <img :class="$style.uploadSample" src="@user/assets/img/business-license-template.jpg" alt="">
                    </i>
                </p>
                <el-upload
                    :class="[formCompanyInfo.licenseUrls.length < 2 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadLicense"
                    :on-success="successLicense"
                    :on-remove="removeLicense"
                    :data="{ method: 'businessLicenceAuth' }"
                    :show-file-list="true"
                    :file-list="formCompanyInfo.licenseUrls"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.company.licenseelectronic.condition') }}</p>
            </el-form-item>
        </div>
        <div :class="$style.buttonBox">
            <slot></slot>
            <el-button type="primary" @click="submitForm('formCompanyInfo')">{{ $t('user.next.step.collection') }}</el-button>
        </div>
    </el-form>
</template>

<script>
    import addressLinkage from '@user/components/AddressLinkage';
    import {
        getEnterData,
        countrysListGet,
        getRegisterCount,
        updateEntryInfo
    } from '@user/services/user';

    export default {
        name: 'Material',
        components: {
            'address-linkage': addressLinkage
        },
        props: {
            postEntryInfo: {
                type: Object,
                required: true,
            },
        },
        data() {

            // 验证注册号是否超过六家
            const validateReNum = async (rule, value, callback) => {
                const { status, data } = await getRegisterCount.http({
                    showError: true,
                    params: {
                        registerNumber: this.formCompanyInfo.registerNumber
                    }
                });
                if (status === 0) {
                    if (data >= 6) {
                        callback(new Error(this.$t('user.company.validate.renum.errlimit')));
                    } else {
                        callback();
                    }
                }
            };
            // 区号验证
            const validatePhone = (rule, value, callback) => {
                const reg = /^[0]+.?[0-9]*$/;
                if (value === '') {
                    callback();
                } else if (!reg.test(value)) {
                    callback(new Error(this.$t('user.contact.validate.zone.err')));
                } else {
                    callback();
                }
            };
            // 资本验证
            const validateCapital = (rule, value, callback) => {
                const reg = /^[0-9-.]*$/;
                if (value === '') {
                    callback();
                } else if (!reg.test(value)) {
                    callback(new Error(this.$t('user.contact.validate.capital.err')));
                } else {
                    callback();
                }
            };
            // 资本验证
            const validateCapitalErr = (rule, value, callback) => {
                const reg = /^(([1-9]{1}\d*)|(0{1}))(\.\d{1,2})?$/;
                if (value === '') {
                    callback();
                } else if (!reg.test(value)) {
                    callback(new Error(this.$t('user.contact.validate.capital.errval')));
                } else {
                    callback();
                }
            };

            return {
                entryInfo: {},
                addressChecked: false,
                licenseList: [],
                dialogImageUrl: '',
                dialogVisible: false,
                countrys: [],
                businessModelList: [],
                errorMse: '',
                formCompanyInfo: {
                    companyAreaCode: 'CN',
                    companyName: '',
                    registerNumber: '',
                    legalRepresentative: '',
                    establishTime: null,
                    registerCapital: '',
                    licenseType: null,
                    licenseStartDate: null,
                    licenseEndDate: null,
                    licenseIsLong: true,
                    businessScope: '',
                    businessPhone: '',
                    businessPhoneAreaCode: '',
                    companyWebsite: '',
                    businessModel: '',
                    shopLink: '',
                    legalUrls: [],
                    licenseUrls: [],
                    registerAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    },
                    companyAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    }
                },
                // 校验规则
                rules: {
                    companyName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.company.validate.name.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.validate.errlength50'),
                        }
                    ],
                    registerNumber: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.company.validate.renum.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.validate.errlength50'),
                        },
                        {
                            validator: validateReNum,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    legalRepresentative: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.company.validate.legaldeputy.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.validate.errlength50'),
                        }
                    ],
                    businessPhoneAreaCode: [
                        {
                            min: 3,
                            max: 4,
                            message: this.$t('user.contact.validate.zone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validatePhone,
                        },
                    ],
                    businessPhone: [
                        {
                            min: 7,
                            max: 8,
                            message: this.$t('user.contact.validate.thlephone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    registerCapital: [
                        {
                            validator: validateCapital,
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validateCapitalErr,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    shopLink: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.company.validate.shoplink.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 200,
                            message: this.$t('user.company.validate.shoplink.errlength'),
                        }
                    ],
                    legalUrls: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.company.validate.idelectronic'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    licenseUrls: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.company.validate.licenseelectronic'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ]
                }
            };
        },
        watch: {
            postEntryInfo() {
                // 初始化表单
                this.init();
            },
            'formCompanyInfo.licenseEndDate': {
                handler(val, oldVal) {
                    if (val) {
                        this.formCompanyInfo.licenseIsLong = false;
                    } else {
                        this.formCompanyInfo.licenseIsLong = true;
                    }
                }
            }
        },
        created() {
            this.init();
            this.getCountrys();
            this.getBusiness();
        },
        methods: {
            // 初始化表单
            init() {
                this.entryInfo = this.postEntryInfo;
                const formCompanyInfo = this.formCompanyInfo;
                // 判断前一次提交的companyAreaCode是否当前类型，如不是则不宣染当前页
                if (this.postEntryInfo.companyAreaCode === formCompanyInfo.companyAreaCode) {
                    for (const key in formCompanyInfo) {
                        if (this.postEntryInfo[key]) {
                            if (['legalUrls', 'licenseUrls'].indexOf(key) >= 0) {
                                const urlList = [];
                                this.postEntryInfo[key].forEach((item) => {
                                    urlList.push({ url: item });
                                });
                                formCompanyInfo[key] = urlList;
                            } else if (['establishTime', 'licenseStartDate', 'licenseEndDate'].includes(key)) {
                                formCompanyInfo[key] = this.postEntryInfo[key] * 1000;
                            } else if (key === 'licenseIsLong') {
                                formCompanyInfo[key] = this.postEntryInfo[key] === 1;
                            } else {
                                formCompanyInfo[key] = this.postEntryInfo[key];
                            }
                        }
                    }

                    // int类型处理（为0是转成空字符串）
                    formCompanyInfo.companyAddress.cdpProvinceId = formCompanyInfo.companyAddress.cdpProvinceId || '';
                    formCompanyInfo.companyAddress.cdpCityId = formCompanyInfo.companyAddress.cdpCityId || '';
                    formCompanyInfo.registerAddress.cdpProvinceId = formCompanyInfo.registerAddress.cdpProvinceId || '';
                    formCompanyInfo.registerAddress.cdpCityId = formCompanyInfo.registerAddress.cdpCityId || '';
                }
                formCompanyInfo.companyAreaCode = 'CN';
            },
            // 获取国家
            async getCountrys() {
                const { status, data } = await countrysListGet.http({
                    showError: true
                });
                if (status === 0) {
                    data.forEach((item) => {
                        if (item.countryCode === 'CN') {
                            this.countrys.push(item);
                        }
                    });
                }
            },
            // 获取营业执照及经营模式
            async getBusiness() {
                const { status, data } = await getEnterData.http();
                if (status === 0) {
                    this.businessModelList = data.businessModel;
                    this.licenseList = data.licenseType;
                }
            },
            gerPostEntryInfo() {

            },
            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        const entryInfo = this.entryInfo;
                        for (const key in this.formCompanyInfo) {
                            if (['legalUrls', 'licenseUrls'].includes(key)) {
                                const urlList = [];
                                this.formCompanyInfo[key].forEach((item) => {
                                    urlList.push(item.url);
                                });
                                entryInfo[key] = urlList;
                            } else if (['establishTime', 'licenseStartDate', 'licenseEndDate'].includes(key)) {
                                entryInfo[key] = Math.ceil(this.formCompanyInfo[key] / 1000);
                            } else if (key === 'licenseIsLong') {
                                entryInfo[key] = this.formCompanyInfo[key] ? 1 : 0;
                            } else if (['licenseType', 'businessModel'].includes(key) && !this.formCompanyInfo[key]) {
                                entryInfo[key] = 0;
                            } else {
                                entryInfo[key] = this.formCompanyInfo[key];
                            }
                        }

                        // int类型处理（提交数据时把空字符串转为0）
                        entryInfo.companyAddress.cdpProvinceId = entryInfo.companyAddress.cdpProvinceId || 0;
                        entryInfo.companyAddress.cdpCityId = entryInfo.companyAddress.cdpCityId || 0;
                        entryInfo.registerAddress.cdpProvinceId = entryInfo.registerAddress.cdpProvinceId || 0;
                        entryInfo.registerAddress.cdpCityId = entryInfo.registerAddress.cdpCityId || 0;
                        const { status } = await updateEntryInfo.http({
                            data: {
                                ...entryInfo
                            }
                        });
                        if (status === 0) {
                            this.$emit('update', { entryInfo, step: 2 });
                        }
                    }
                });
            },
            dittoAddress() {
                const vm = this;
                if (vm.addressChecked) {
                    vm.formCompanyInfo.companyAddress = vm.formCompanyInfo.registerAddress;
                } else {
                    vm.formCompanyInfo.companyAddress = {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    };
                }
            },
            // 上传成功
            uploadSuccessFn(res, urlList) {
                const { status, data, msg } = res;
                if (status === 0) {
                    this.formCompanyInfo[urlList].push({ url: data.url });
                } else {
                    this.formCompanyInfo[urlList] = [];
                    this.$message.error(msg);
                }
            },

            // 图片上传前验证
            beforeUploadFn(file, isAnnual) {
                const isJPG = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'].indexOf(file.type) >= 0;
                const isLt2M = file.size / 1024 / 1024 < 1;

                if (!isJPG) {
                    this.$message.error(this.$t('user.company.validate.idelectronic.errformat'));
                }
                if (!isLt2M) {
                    this.$message.error(this.$t('user.company.validate.idelectronic.errsize'));
                }
                return isJPG && isLt2M;
            },

            // 上传营业执照前
            beforeUploadLicense(file) {
                return this.beforeUploadFn(file);
            },

            // 上传营业执照成功
            successLicense(res, file) {
                this.uploadSuccessFn(res, 'licenseUrls');
            },
            // 删除营业执照
            removeLicense(file) {
                this.formCompanyInfo.licenseUrls.forEach((item, index) => {
                    if (item.url === file.url) {
                        this.formCompanyInfo.licenseUrls.splice(index, 1);
                    }
                });
            },

            // 上传法人身份证前
            beforeUploadLegal(file) {
                return this.beforeUploadFn(file);
            },

            // 上传法人身份证成功
            successLegal(res, file) {
                console.log(file);
                this.uploadSuccessFn(res, 'legalUrls');
            },
            // 删除法人身份证
            removeLegal(file) {
                this.formCompanyInfo.legalUrls.forEach((item, index) => {
                    if (item.url === file.url) {
                        this.formCompanyInfo.legalUrls.splice(index, 1);
                    }
                });
            },


            businessPhoneValidata() {
                this.formCompanyInfo.businessPhone = this.formCompanyInfo.businessPhone.replace(/[^0-9]/g, '');
            },
            phoneAreaCodeValidata() {
                this.formCompanyInfo.businessPhoneAreaCode = this.formCompanyInfo.businessPhoneAreaCode.replace(/[^0-9]/g, '');
            },
            validateRegisterNum() {
                this.formCompanyInfo.registerNumber = this.formCompanyInfo.registerNumber.replace(/[^0-9-A-Za-z]/g, '');
            }

        },
    };
</script>

<style module>
    @import 'variable.css';

    .overstepLimit [class~="el-upload"]{
        display: none;
    }
    .info{
        width: 1000px;
        margin: 30px auto 50px;
    }
    .formLargeInput{
        width: 620px;
    }
    .formSmallInput{
        width: 300px;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
    }
    .enduringMargin{
        margin-left: 10px;
    }
    .uploadTitle{
        color: var(--color-black);
        margin-bottom: 10px;
    }
    .uploadCondition{
        color: var(--color-text-regular);
        margin-top: 20px;
    }
    .uploadIcon{
        position: relative;
        margin-left: 5px;
        cursor: pointer;
        font-size: 18px;
    }
    .uploadSample{
        display: none;
        position: absolute;
        bottom: 20px;
        left: 50%;
        width: 200px;
        margin-left: -100px;
        border: 1px solid var(--border-color-base);
    }
    .uploadIcon:hover .uploadSample{
        display: block;
    }
    .uploadPdf [class~="el-upload-list__item"]{
        background: url('@user/assets/img/pdf-bg.png') center no-repeat;
        background-size: 80%;
    }
    .uploadPdf [class~="el-upload-list__item-thumbnail"]{
        background-color: var(--color-white);
    }

</style>
