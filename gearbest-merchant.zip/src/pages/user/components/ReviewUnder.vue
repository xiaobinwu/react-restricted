<template>
    <div :class="$style.reviewInfo">
        <i :class="$style.underIcon" class="el-icon-info"></i>
        <p :class="$style.reviewNote">{{ $t('user.review.under.note') }}</p>
        <div :class="$style.buttonBox">
            <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
        </div>
    </div>
</template>

<script>
    export default {
        methods: {
            returnMerchants() {
                this.$router.gbPush('/sign/sign-index');
            },
        }
    };
</script>

<style module>
    @import 'variable.css';
    .reviewInfo{
        text-align: center;
        padding: 100px 0;
    }
    .underIcon{
        font-size: 60px;
        color: #4195FC;
    }
    .reviewTitle{
        margin-top: 20px;
        font-size: 18px;
    }
    .reviewNote{
        margin-top: 20px;
        font-size: 14px;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
        margin-top: 50px;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
        cursor: pointer;
    }
</style>
