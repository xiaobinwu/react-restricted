<template>
    <el-form
        ref="formCollectionInfo"
        :model="formCollectionInfo"
        :rules="rules"
        label-position="right"
        label-width="350px"
        class="demo-ruleForm">
        <div :class="$style.info">
            <el-form-item :label="$t('user.bankaccount.no')" prop="bankAccountNo">
                <el-input
                    :class="$style.formLargeInput"
                    :placeholder="$t('user.payoneer.place.bankno')"
                    v-model="formCollectionInfo.bankAccountNo" maxlength="100" @change="validateAccountNo"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.beneficiary.name')" prop="bankAccountName">
                <el-input
                    :class="$style.formLargeInput"
                    :placeholder="$t('user.payoneer.place.en')"
                    v-model="formCollectionInfo.bankAccountName" maxlength="100" @change="validateAccountName"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.bank.name')" prop="bankName">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('user.payoneer.place.en')"
                    v-model="formCollectionInfo.bankName" maxlength="100" @change="validateBankName"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.bank.swiftcode')" prop="bankCode">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('user.payoneer.place.bankcode')"
                    v-model="formCollectionInfo.bankCode" maxlength="100" @change="validateBankCode"></el-input>
            </el-form-item>

            <el-form-item :label="$t('user.bank.address')" prop="bankAddress">
                <address-linkage v-model="formCollectionInfo.bankAddress" :countrys="countrys" :is-en="true">
                    <el-input
                        v-model="formCollectionInfo.bankAddress.addressDetail"
                        :placeholder="$t('user.payoneer.place.en')"
                        maxlength="200"
                        @change="validateDetailed('bankAddress')"></el-input>
                </address-linkage>
            </el-form-item>
            <el-form-item
                :label="$t('user.bank.postalcode')"
                :rules="[
                    { required: true, message: this.$t('user.postalcode.validate.empty'), trigger: 'blur' },
                    { max: 30, message: this.$t('user.postalcode.validate.errlength'), trigger: 'blur' }
                ]"
                prop="bankAddress.zipCode">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('user.payoneer.place.number')"
                    v-model="formCollectionInfo.bankAddress.zipCode"
                    maxlength="30"
                    @change="zipCodeValidata"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.business.address')" prop="businessAddress">
                <address-linkage v-model="formCollectionInfo.businessAddress" :countrys="countrys" :is-en="true">
                    <el-input
                        v-model="formCollectionInfo.businessAddress.addressDetail"
                        :placeholder="$t('user.payoneer.place.en')"
                        maxlength="200"
                        @change="validateDetailed('businessAddress')" ></el-input>
                </address-linkage>
            </el-form-item>
            <el-form-item :label="$t('user.notify.mobileno')" prop="mobileNo">
                <el-input
                    :class="$style.formSmallInput"
                    v-model="formCollectionInfo.mobileNo"
                    :placeholder="$t('user.contact.prompt.phone')"
                    :maxlength="phoneMaxLength"
                    class="input-with-select"
                    @change="phoneValidata">
                    <el-select
                        slot="prepend"
                        :class="$style.codeSelect"
                        v-model="formCollectionInfo.mobileAreaCode"
                        @change="changeCountryCode">
                        <el-option
                            v-for="item in mobileAreaCodeList"
                            :key="item.country+'_'+item.phoneCode"
                            :label="'+'+item.phoneCode"
                            :value="item.phoneCode"></el-option>
                    </el-select>
                </el-input>
            </el-form-item>

            <el-form-item :label="$t('user.account.scan')" prop="scanUrlList">
                <p :class="$style.uploadTitle">
                    <a :href="`${getAssistPath('bank-account-information.doc')}`" download="bank-account-information">
                        {{ $t('user.account.scan.clickDownload') }} </a>
                    {{ $t('user.accountscan.title') }}
                </p>
                <el-upload
                    :class="[formCollectionInfo.scanUrlList.length < 3 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadLegal"
                    :on-success="successLegal"
                    :on-remove="removeLegal"
                    :show-file-list="true"
                    :file-list="formCollectionInfo.scanUrlList"
                    :data="{ method: 'bankAccountAuth' }"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.accountscan.condition') }}</p>
            </el-form-item>
        </div>
        <div :class="$style.buttonBox">
            <slot></slot>
            <el-button type="primary" @click="submitForm('formCollectionInfo')">{{ $t('user.next.step.shop') }}</el-button>
        </div>
    </el-form>
</template>

<script>
    import addressLinkage from '@user/components/AddressLinkage';
    import { getAssistPath } from '@/assets/js/utils/assist';
    import {
        phonecodeList,
        countrysListGet,
        updateEntryInfo,
    } from '@user/services/user';

    export default {
        name: 'Material',
        components: {
            'address-linkage': addressLinkage
        },
        props: {
            postEntryInfo: {
                type: Object,
                required: true,
            },
        },
        data() {
            const validatePhone = (rule, value, callback) => {
                const reg = /^[1]+.?[0-9]*$/;
                if (!reg.test(value)) {
                    callback(new Error(this.$t('user.contact.validate.phone.err')));
                } else {
                    callback();
                }
            };
            const validateAddre = (rule, value, callback) => {
                if (!value.countryCode || !value.addressDetail) {
                    callback(new Error(this.$t('user.collectionaddress.validate.empty')));
                } else {
                    callback();
                }
            };
            return {
                getAssistPath,
                entryInfo: {},
                accountType: 1,
                phoneMaxLength: Number,
                dialogImageUrl: '',
                countrys: [],
                mobileAreaCodeList: [],
                formCollectionInfo: {
                    bankAccountNo: '',
                    bankAccountName: '',
                    bankName: '',
                    bankCode: '',
                    mobileAreaCode: '86',
                    mobileNo: '',
                    scanUrlList: [],
                    bankAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: '',
                        zipCode: ''
                    },
                    businessAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    }
                },
                // 校验规则
                rules: {
                    bankAccountNo: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.bankaccount.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('user.collection.validate.errlength'),
                        }
                    ],
                    bankAccountName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.beneficiary.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('user.collection.validate.errlength'),
                        },
                    ],
                    bankName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.bankname.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('user.collection.validate.errlength'),
                        }
                    ],
                    bankCode: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.swiftcode.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('user.collection.validate.errlength'),
                        }
                    ],
                    mobileNo: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.contact.validate.phone.empty'),
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validatePhone,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    bankAddress: [
                        {
                            required: true, // 是否必填
                            validator: validateAddre,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    businessAddress: [
                        {
                            required: true, // 是否必填
                            validator: validateAddre,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    scanUrlList: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.accountscan.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                }
            };
        },
        watch: {
            postEntryInfo() {
                // 初始化表单
                this.init();
            }
        },
        created() {
            this.init();
            this.getCountrys();
            this.getPhonecode();
            this.changeCountryCode();
        },
        methods: {
            // 初始化表单
            async init() {
                this.entryInfo = this.postEntryInfo;
                const formCollectionInfo = this.formCollectionInfo;
                // 判断前一次提交的accountType是否当前类型，如不是则不宣染当前页
                if (this.postEntryInfo.shopInfo && this.postEntryInfo.shopInfo.financialInfo
                    && this.postEntryInfo.shopInfo.financialInfo.accountType === this.accountType) {
                        for (const key in formCollectionInfo) {
                            if (this.postEntryInfo.shopInfo.financialInfo[key]) {
                                if (key === 'scanUrlList') {
                                    const urlList = [];
                                    this.postEntryInfo.shopInfo.financialInfo[key].forEach((item) => {
                                        urlList.push({ url: item });
                                    });
                                    formCollectionInfo[key] = urlList;
                                } else {
                                    formCollectionInfo[key] = this.postEntryInfo.shopInfo.financialInfo[key];
                                }
                            }
                        }

                        // int类型处理（为0是转成空字符串）
                        formCollectionInfo.bankAddress.cdpProvinceId = formCollectionInfo.bankAddress.cdpProvinceId || '';
                        formCollectionInfo.bankAddress.cdpCityId = formCollectionInfo.bankAddress.cdpCityId || '';
                        formCollectionInfo.businessAddress.cdpProvinceId = formCollectionInfo.businessAddress.cdpProvinceId || '';
                        formCollectionInfo.businessAddress.cdpCityId = formCollectionInfo.businessAddress.cdpCityId || '';

                        // 如手机号码为空时带出个人资料所填手机号码
                        const functionalInfo = this.postEntryInfo.shopInfo ? this.postEntryInfo.shopInfo.financialInfo : '';
                        if (!functionalInfo || (functionalInfo && !functionalInfo.mobileNo)) {
                            formCollectionInfo.mobileNo = this.postEntryInfo.contactMethod;
                        }
                        if (!functionalInfo || (functionalInfo && !functionalInfo.mobileAreaCode)) {
                            formCollectionInfo.mobileAreaCode = this.postEntryInfo.contactAreaCode;
                        }
                } else {
                    // 默认带出手机号码
                    formCollectionInfo.mobileNo = this.postEntryInfo.contactMethod;
                    formCollectionInfo.mobileAreaCode = this.postEntryInfo.contactAreaCode;
                }
            },
            // 获取国家
            async getCountrys() {
                const { status, data } = await countrysListGet.http({
                    showError: true
                });
                if (status === 0) {
                    this.countrys = data;
                }
            },
            // 获取手机区号
            async getPhonecode() {
                const { status, data } = await phonecodeList.http();
                if (status === 0) {
                    this.mobileAreaCodeList = data;
                }
            },

            // 提交表单
            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        if (!this.entryInfo.shopInfo) {
                            this.entryInfo.shopInfo = {};
                            this.entryInfo.shopInfo.financialInfo = {};
                        } else if (!this.entryInfo.shopInfo.financialInfo) {
                            this.entryInfo.shopInfo.financialInfo = {};
                        }
                        const financial = this.entryInfo.shopInfo.financialInfo;
                        for (const key in this.formCollectionInfo) {
                            if (key === 'scanUrlList') {
                                const urlList = [];
                                this.formCollectionInfo[key].forEach((item) => {
                                    urlList.push(item.url);
                                });
                                financial[key] = urlList;
                            } else {
                                financial[key] = this.formCollectionInfo[key];
                            }
                        }
                        financial.accountType = this.accountType;

                        // int类型处理（提交数据时把空字符串转为0）
                        financial.bankAddress.cdpProvinceId = financial.bankAddress.cdpProvinceId || 0;
                        financial.bankAddress.cdpCityId = financial.bankAddress.cdpCityId || 0;
                        financial.businessAddress.cdpProvinceId = financial.businessAddress.cdpProvinceId || 0;
                        financial.businessAddress.cdpCityId = financial.businessAddress.cdpCityId || 0;
                        const { status } = await updateEntryInfo.http({
                            data: {
                                ...this.entryInfo
                            }
                        });
                        if (status === 0) {
                            this.$emit('update', { entryInfo: this.entryInfo, step: 3 });
                        }
                    }
                });
            },
            changeCountryCode() {
                const vm = this;
                vm.phoneMaxLength = vm.formCollectionInfo.mobileAreaCode === '86' ? 11 : 30;
                if (vm.formCollectionInfo.mobileAreaCode === '86') {
                    const validatePhone = (rule, value, callback) => {
                        const reg = /^[1]+.?[0-9]*$/;
                        if (!reg.test(value)) {
                            callback(new Error(vm.$t('user.contact.validate.phone.err')));
                        } else {
                            callback();
                        }
                    };
                    this.rules.mobileNo = [
                        {
                            required: true, // 是否必填
                            message: vm.$t('user.contact.validate.phone.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validatePhone,
                        },
                    ];
                    if (this.formCollectionInfo.mobileNo.length > 11) {
                        this.formCollectionInfo.mobileNo = this.formCollectionInfo.mobileNo.substr(0, 11);
                    }
                } else {
                    this.rules.mobileNo = [
                        {
                            required: true, // 是否必填
                            message: vm.$t('user.contact.validate.phone.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ];
                }

            },

            // 图片上传前验证
            beforeUploadFn(file) {
                console.log(file);
                const isJPG = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'].indexOf(file.type) >= 0;
                const isLt2M = file.size / 1024 / 1024 < 1;

                if (!isJPG) {
                    this.$message.error(this.$t('user.accountscan.validate.errformat'));
                }
                if (!isLt2M) {
                    this.$message.error(this.$t('user.accountscan.validate.errsize'));
                }
                return isJPG && isLt2M;
            },

            // 图片删除
            removeUploadFn(file, urlList) {
                this.formCollectionInfo[urlList].forEach((item, index) => {
                    if (item.url === file.url) {
                        this.formCollectionInfo[urlList].splice(index, 1);
                    }
                });
            },

            // 上传法人身份证前
            beforeUploadLegal(file) {
                return this.beforeUploadFn(file);
            },
            // 上传法人身份证成功
            successLegal(res, file) {
                const { status, data, msg } = res;
                if (status === 0) {
                    this.formCollectionInfo.scanUrlList.push({ url: data.url });
                } else {
                    this.formCollectionInfo.scanUrlList = [];
                    this.$message.error(msg);
                }
            },
            // 删除法人身份证
            removeLegal(file) {
                this.removeUploadFn(file, 'scanUrlList');
            },
            // 地址只能输入英文
            validateDetailed(ev) {
                this.formCollectionInfo[ev].addressDetail = this.formCollectionInfo[ev].addressDetail.replace(
                    /[^\d\w\s!@#$%^&*()_+<>?:,./;’]/g, ''
                );
            },
            phoneValidata() {
                this.formCollectionInfo.mobileNo = this.formCollectionInfo.mobileNo.replace(/[^0-9]/g, '');
            },
            zipCodeValidata() {
                this.formCollectionInfo.bankAddress.zipCode = this.formCollectionInfo.bankAddress.zipCode.replace(/[^0-9]/g, '');
            },
            validateAccountName() {
                this.formCollectionInfo.bankAccountName = this.formCollectionInfo.bankAccountName.replace(/[^\d\w\s]/g, '');
            },
            validateBankName() {
                this.formCollectionInfo.bankName = this.formCollectionInfo.bankName.replace(/[^\d\w\s]/g, '');
            },
            validateAccountNo() {
                this.formCollectionInfo.bankAccountNo = this.formCollectionInfo.bankAccountNo.replace(/[^0-9]/g, '');
            },
            validateBankCode() {
                this.formCollectionInfo.bankCode = this.formCollectionInfo.bankCode.replace(/[^0-9-A-Za-z]/g, '');
            }

        },
    };
</script>

<style module>
    @import 'variable.css';

    .overstepLimit [class~="el-upload"]{
        display: none;
    }
    .codeSelect [class~="el-input__inner"]{
        width: 50px;
        padding: 0;
        text-align: center;
    }
    .info{
        width: 100%;
        margin: 30px auto 50px;
    }
    .formLargeInput{
        width: 620px;
    }
    .formSmallInput{
        width: 300px;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
    }
    .uploadTitle{
        color: var(--color-black);
        margin-bottom: 10px;
    }
    .uploadCondition{
        color: var(--color-text-regular);
        margin-top: 20px;
    }
    .uploadPdf [class~="el-upload-list__item"]{
        background: url('@user/assets/img/pdf-bg.png') center no-repeat;
        background-size: 80%;
    }
    .uploadPdf [class~="el-upload-list__item-thumbnail"]{
        background-color: var(--color-white);
    }
</style>
