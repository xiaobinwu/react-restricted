<template>
    <div :class="$style.container">
        <el-form
            ref="formPersonalInfo"
            :model="formPersonalInfo"
            :rules="rules"
            label-position="right"
            label-width="120px"
            class="demo-ruleForm">
            <div :class="$style.info">
                <el-form-item :label="$t('user.contact.name')" prop="contact">
                    <el-input v-model="formPersonalInfo.contact"></el-input>
                </el-form-item>
                <el-form-item :label="$t('user.contact.phone')" prop="contactMethod">
                    <el-input
                        v-model="formPersonalInfo.contactMethod"
                        :placeholder="$t('user.contact.prompt.phone')"
                        :maxlength="phoneMaxLength"
                        class="input-with-select"
                        @change="phoneValidata">
                        <el-select
                            slot="prepend"
                            :class="$style.codeSelect"
                            v-model="formPersonalInfo.contactAreaCode"
                            @change="changeCountryCode">
                            <el-option
                                v-for="item in phoneAreaCodeList"
                                :key="item.country+'_'+item.phoneCode"
                                :label="'+'+item.phoneCode"
                                :value="item.phoneCode"></el-option>
                        </el-select>
                    </el-input>
                </el-form-item>
                <el-form-item :label="$t('user.contact.thlephone')">
                    <el-col :span="8">
                        <el-form-item prop="landlinePhoneAreaCode">
                            <el-input
                                v-model="formPersonalInfo.landlinePhoneAreaCode"
                                :placeholder="$t('user.contact.prompt.zone')"
                                :maxlength="phoneAreaCodeLenght"
                                @change="landlineAreaCodeValidata"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="2" class="line">-</el-col>
                    <el-col :span="14">
                        <el-form-item prop="landlinePhone">
                            <el-input
                                v-model="formPersonalInfo.landlinePhone"
                                :maxlength="landlinePhoneLength"
                                :placeholder="$t('user.contact.prompt.thlephone')"
                                @change="landlineMethodValidata"></el-input>
                        </el-form-item>
                    </el-col>
                </el-form-item>
                <el-form-item :label="$t('user.contact.email')" prop="contactEmail">
                    <el-input v-model="formPersonalInfo.contactEmail"></el-input>
                </el-form-item>
                <el-form-item :label="$t('user.contact.qq.num')" prop="qq">
                    <el-input v-model="formPersonalInfo.qq" @change="qqNumValidata"></el-input>
                </el-form-item>
            </div>
            <div :class="$style.buttonBox">
                <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
                <el-button type="primary" @click="submitForm('formPersonalInfo')">{{ $t('user.next.step.company') }}</el-button>
            </div>
        </el-form>
    </div>
</template>

<script>
    import {
        phonecodeList,
        updateEntryInfo
    } from '@user/services/user';

    export default {
        name: 'ContactInfo',
        props: {
            postEntryInfo: {
                type: Object,
                required: true,
            },
        },
        data() {
            const validatePass = (rule, value, callback) => {
                const reg = /^[1]+.?[0-9]*$/;
                if (!reg.test(value)) {
                    callback(new Error(this.$t('user.contact.validate.phone.err')));
                } else {
                    callback();
                }
            };
            return {
                entryInfo: {},
                phoneMaxLength: 11,
                landlinePhoneLength: 8,
                phoneAreaCodeLenght: 4,
                phoneAreaCodeList: [],
                phoneNum: Number,
                isNum: true,
                nextPage: '',
                formPersonalInfo: {
                    id: '',
                    contact: '',
                    landlinePhoneAreaCode: '',
                    landlinePhone: '',
                    contactMethod: '',
                    contactAreaCode: '86',
                    contactEmail: '',
                    qq: '',
                },
                // 校验规则
                rules: {
                    contact: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.contact.validate.name.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.contact.validate.name.errlength'),
                        }
                    ],
                    contactMethod: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.contact.validate.phone.empty'),
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validatePass,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    landlinePhoneAreaCode: [
                        {
                            min: 3,
                            max: 4,
                            message: this.$t('user.contact.validate.zone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    landlinePhone: [
                        {
                            min: 7,
                            max: 8,
                            message: this.$t('user.contact.validate.thlephone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    contactEmail: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.contact.validate.email.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            type: 'email',
                            message: this.$t('user.contact.validate.email.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.contact.validate.email.errlength'), // 规则
                        },
                    ],
                    qq: [
                        {
                            max: 50,
                            message: this.$t('user.contact.validate.errlength'), // 规则
                        },
                    ]
                }
            };
        },
        watch: {
            postEntryInfo() {
                // 初始化表单
                this.init();
            }
        },
        async created() {
            await this.init();
            this.getPhonecode();
        },
        methods: {
            // 初始化表单
            init() {
                this.entryInfo = this.postEntryInfo;
                this.formPersonalInfo.contactEmail = this.postEntryInfo.account;
                for (const key in this.formPersonalInfo) {
                    if (this.postEntryInfo[key]) {
                        this.formPersonalInfo[key] = this.postEntryInfo[key];
                    }
                }
                this.changeCountryCode();
            },
            // 获取手机区号
            async getPhonecode() {
                const { status, data } = await phonecodeList.http({
                    mock: true
                });
                if (status === 0) {
                    this.phoneAreaCodeList = data;
                }
            },

            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        for (const key in this.formPersonalInfo) {
                            if (key !== 'id' || (key === 'id' && this.formPersonalInfo[key])) {
                                this.entryInfo[key] = this.formPersonalInfo[key];
                            }
                        }
                        const { status, data } = await updateEntryInfo.http({
                            data: {
                                ...this.entryInfo
                            }
                        });
                        if (status === 0) {
                            this.entryInfo.id = data;
                            this.$emit('update', { entryInfo: this.entryInfo, step: 1 });
                        }
                    }
                });
            },
            changeCountryCode() {
                // 手机号选择国家时更新大陆和非大陆验证规则
                const vm = this;
                vm.phoneMaxLength = vm.formPersonalInfo.contactAreaCode === '86' ? 11 : 20;
                vm.landlinePhoneLength = vm.formPersonalInfo.contactAreaCode === '86' ? 8 : 20;
                vm.phoneAreaCodeLenght = vm.formPersonalInfo.contactAreaCode === '86' ? 4 : 20;
                if (vm.formPersonalInfo.contactAreaCode === '86') {
                    const validateMethod = (rule, value, callback) => {
                        const reg = /^[1]+.?[0-9]*$/;
                        if (!reg.test(value)) {
                            callback(new Error(vm.$t('user.contact.validate.phone.err')));
                        } else {
                            callback();
                        }
                    };
                    const validatePhone = (rule, value, callback) => {
                        const reg = /^[0]+.?[0-9]*$/;
                        if (value === '') {
                            callback();
                        } else if (!reg.test(value)) {
                            callback(new Error(vm.$t('user.contact.validate.zone.err')));
                        } else {
                            callback();
                        }
                    };
                    this.rules.contactMethod = [
                        {
                            required: true, // 是否必填
                            message: vm.$t('user.contact.validate.phone.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validateMethod,
                        },
                    ];
                    this.rules.landlinePhoneAreaCode = [
                        {
                            min: 3,
                            max: 4,
                            message: this.$t('user.contact.validate.zone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            validator: validatePhone,
                        },
                    ];
                    this.rules.landlinePhone = [
                        {
                            min: 7,
                            max: 8,
                            message: this.$t('user.contact.validate.thlephone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ];
                    if (this.formPersonalInfo.contactMethod.length > 11) {
                        this.formPersonalInfo.contactMethod = this.formPersonalInfo.contactMethod.substr(0, 11);
                    }
                } else {
                    this.rules.contactMethod = [
                        {
                            required: true, // 是否必填
                            message: vm.$t('user.contact.validate.phone.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ];
                    this.rules.landlinePhone = [
                        {
                            max: 20,
                            message: this.$t('user.contact.validate.thlephone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ];
                    this.rules.landlinePhoneAreaCode = [
                        {
                            max: 20,
                            message: this.$t('user.contact.validate.zone.err'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ];
                }

            },
            phoneValidata() {
                this.formPersonalInfo.contactMethod = this.formPersonalInfo.contactMethod.replace(/[^0-9]/g, '');
            },
            landlineAreaCodeValidata() {
                this.formPersonalInfo.landlinePhoneAreaCode = this.formPersonalInfo.landlinePhoneAreaCode.replace(/[^0-9]/g, '');
            },
            landlineMethodValidata() {
                this.formPersonalInfo.landlinePhone = this.formPersonalInfo.landlinePhone.replace(/[^0-9]/g, '');
            },
            qqNumValidata() {
                this.formPersonalInfo.qq = this.formPersonalInfo.qq.replace(/[^0-9]/g, '');
            },
            returnMerchants() {
                this.$confirm(this.$t('user.whether.withdraw.application'), this.$t('user.prompt.message'), {
                    confirmButtonText: this.$t('user.confirm.text'),
                    cancelButtonText: this.$t('user.cancel.text'),
                    type: 'warning'
                }).then(() => {
                    this.$router.gbPush('/sign/sign-index');
                }).catch(() => {

                });
            }
        },
    };
</script>

<style module>
    @import 'variable.css';

    .container{
        width: var(--layout-safe-width);
        margin: 0 auto;
    }
    .container [class~="line"]{
        text-align: center;
    }
    .container [class~="el-input-group__prepend"]{
        background-color: var(--color-white);
    }
    .container [class~="el-select__caret"]{
        display: none;
    }
    .codeSelect [class~="el-input__inner"]{
        width: 50px;
        padding: 0;
        text-align: center;
    }
    .info{
        width: 450px;
        margin: 50px auto;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
        cursor: pointer;
    }
</style>
