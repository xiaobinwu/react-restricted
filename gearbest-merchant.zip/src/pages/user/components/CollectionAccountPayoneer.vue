<template>
    <el-form
        ref="formCollectionInfo"
        :model="formCollectionInfo"
        :rules="rules"
        label-position="right"
        label-width="250px"
        class="demo-ruleForm">
        <div :class="$style.info">
            <el-form-item :label="$t('user.payoneer.account')" prop="bankAccountNo">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('user.payoneer.place.prohibitcn')"
                    v-model="formCollectionInfo.bankAccountNo"></el-input>
                <p :class="$style.formItemNote">
                    {{ $t('user.payoneer.account.title') }}
                    <a href="https://payouts.payoneer.com/partners/or.aspx?pid=YOYIZC74IO2s4KZQp7tgsw%3d%3d" target="_blank">
                        {{ $t('user.payoneer.go.register') }}
                    </a>
                </p>
            </el-form-item>
            <el-form-item :label="$t('user.payoneer.collectionname')" prop="bankAccountName">
                <el-input
                    :class="$style.formSmallInput"
                    :placeholder="$t('user.payoneer.collectionname.title')" v-model="formCollectionInfo.bankAccountName"></el-input>
                    <!-- <p :class="$style.formItemNote">
                    {{ $t('user.payoneer.collectionname.title') }}
                </p> -->
            </el-form-item>

            <el-form-item :label="$t('user.payoneer.scan')" prop="scanUrlList">
                <p :class="$style.uploadTitle">
                    {{ $t('user.payoneerscan.title') }}
                    <i :class="$style.uploadIcon" class="el-icon-question">
                        <img :class="$style.uploadSample" src="@user/assets/img/payoneer-account.png" alt="">
                    </i>
                </p>
                <el-upload
                    :class="[formCollectionInfo.scanUrlList.length < 3 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadLegal"
                    :on-success="successLegal"
                    :on-remove="removeLegal"
                    :show-file-list="true"
                    :file-list="formCollectionInfo.scanUrlList"
                    :data="{ method: 'bankAccountAuth' }"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.payoneerscan.condition') }}</p>
            </el-form-item>
        </div>
        <div :class="$style.buttonBox">
            <slot></slot>
            <el-button type="primary" @click="submitForm('formCollectionInfo')">{{ $t('user.next.step.shop') }}</el-button>
        </div>
    </el-form>
</template>

<script>
    import { updateEntryInfo } from '@user/services/user';
    import addressLinkage from '@user/components/AddressLinkage';

    export default {
        name: 'Material',
        components: {
            'address-linkage': addressLinkage
        },
        props: {
            postEntryInfo: {
                type: Object,
                required: true,
            },
        },
        data() {
            return {
                entryInfo: {},
                accountType: 2,
                dialogImageUrl: '',
                formCollectionInfo: {
                    bankAccountNo: '',
                    bankAccountName: '',
                    scanUrlList: [],
                },
                // 校验规则
                rules: {
                    bankAccountNo: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.payoneeraccount.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('user.payoneeraccount.validate.errlength'),
                        }
                    ],
                    bankAccountName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.collectionname.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 100,
                            message: this.$t('user.collectionname.validate.errlength'),
                        },
                    ],
                    scanUrlList: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.payoneerscan.validate.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                }
            };
        },
        watch: {
            postEntryInfo() {
                // 初始化表单
                this.init();
            }
        },
        created() {
            this.init();
        },
        methods: {
            // 初始化表单
            async init() {
                this.entryInfo = this.postEntryInfo;
                // 判断前一次提交的accountType是否当前类型，如不是则不宣染当前页
                if (this.postEntryInfo.shopInfo && this.postEntryInfo.shopInfo.financialInfo
                    && this.postEntryInfo.shopInfo.financialInfo.accountType === this.accountType) {
                        this.entryInfo.shopInfo = this.postEntryInfo.shopInfo;
                        for (const key in this.formCollectionInfo) {
                            if (this.postEntryInfo.shopInfo.financialInfo[key]) {
                                if (key === 'scanUrlList') {
                                    const urlList = [];
                                    this.postEntryInfo.shopInfo.financialInfo[key].forEach((item) => {
                                        urlList.push({ url: item });
                                    });
                                    this.formCollectionInfo[key] = urlList;
                                } else {
                                    this.formCollectionInfo[key] = this.postEntryInfo.shopInfo.financialInfo[key];
                                }
                            }
                        }

                        // 如账户名为空时带出公司名称
                        if (!this.postEntryInfo.shopInfo || !this.postEntryInfo.shopInfo.financialInfo
                            || !this.postEntryInfo.shopInfo.financialInfo.bankAccountName) {
                                this.formCollectionInfo.bankAccountName = this.postEntryInfo.companyName;
                            }
                } else {
                    // 默认带出公司名称
                    this.formCollectionInfo.bankAccountName = this.postEntryInfo.companyName;
                }

            },

            // 提交表单
            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        if (!this.entryInfo.shopInfo) {
                            this.entryInfo.shopInfo = {};
                            this.entryInfo.shopInfo.financialInfo = {};
                        } else if (!this.entryInfo.shopInfo.financialInfo) {
                            this.entryInfo.shopInfo.financialInfo = {};
                        }
                        for (const key in this.formCollectionInfo) {
                            if (key === 'scanUrlList') {
                                const urlList = [];
                                this.formCollectionInfo[key].forEach((item) => {
                                    urlList.push(item.url);
                                });
                                this.entryInfo.shopInfo.financialInfo[key] = urlList;
                            } else {
                                this.entryInfo.shopInfo.financialInfo[key] = this.formCollectionInfo[key];
                            }
                        }
                        this.entryInfo.shopInfo.financialInfo.accountType = this.accountType;
                        const { status } = await updateEntryInfo.http({
                            data: {
                                ...this.entryInfo
                            }
                        });
                        if (status === 0) {
                            this.$emit('update', { entryInfo: this.entryInfo, step: 3 });
                        }
                    }
                });
            },

            // 图片上传前验证
            beforeUploadFn(file) {
                console.log(file);
                const isJPG = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'].indexOf(file.type) >= 0;
                const isLt2M = file.size / 1024 / 1024 < 1;

                if (!isJPG) {
                    this.$message.error(this.$t('user.payoneerscan.validate.errformat'));
                }
                if (!isLt2M) {
                    this.$message.error(this.$t('user.payoneerscan.validate.errsize'));
                }
                return isJPG && isLt2M;
            },

            // 图片删除
            removeUploadFn(file, urlList) {
                this.formCollectionInfo[urlList].forEach((item, index) => {
                    if (item.url === file.url) {
                        this.formCollectionInfo[urlList].splice(index, 1);
                    }
                });
            },

            // 上传法人身份证前
            beforeUploadLegal(file) {
                return this.beforeUploadFn(file);
            },
            // 上传法人身份证成功
            successLegal(res, file) {
                const { status, data, msg } = res;
                if (status === 0) {
                    this.formCollectionInfo.scanUrlList.push({ url: data.url });
                } else {
                    this.formCollectionInfo.scanUrlList = [];
                    this.$message.error(msg);
                }
            },
            // 删除法人身份证
            removeLegal(file) {
                this.removeUploadFn(file, 'scanUrlList');
            },

        },
    };
</script>

<style module>
    @import 'variable.css';

    .overstepLimit [class~="el-upload"]{
        display: none;
    }
    .info{
        width: 1000px;
        margin: 30px auto 50px;
    }
    .formSmallInput{
        width: 300px;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
    }
    .uploadTitle{
        color: var(--color-black);
        margin-bottom: 10px;
    }
    .uploadCondition{
        color: var(--color-text-regular);
        margin-top: 20px;
    }
    .uploadIcon{
        position: relative;
        margin-left: 5px;
        cursor: pointer;
        font-size: 18px;
    }
    .uploadSample{
        display: none;
        position: absolute;
        bottom: 20px;
        left: 50%;
        width: 200px;
        margin-left: -100px;
        border: 1px solid var(--border-color-base);
    }
    .uploadIcon:hover .uploadSample{
        display: block;
    }
    .formItemNote{
        display: inline-block;
        margin-left: 20px;
        color: var(--color-text-regular);
    }
    .uploadPdf [class~="el-upload-list__item"]{
        background: url('@user/assets/img/pdf-bg.png') center no-repeat;
        background-size: 80%;
    }
    .uploadPdf [class~="el-upload-list__item-thumbnail"]{
        background-color: var(--color-white);
    }
</style>
