<template>
    <el-form
        ref="formCompanyInfo"
        :model="formCompanyInfo"
        :rules="rules"
        label-position="right"
        label-width="220px"
        class="demo-ruleForm">
        <div :class="$style.info">
            <el-form-item :label="$t('user.companyhk.name')" prop="companyName">
                <el-input
                    :class="$style.formLargeInput"
                    v-model="formCompanyInfo.companyName"
                    :placeholder="$t('user.companyhk.prompt.name')"
                    maxlength="50"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.companyhk.renum')" prop="registerNumber">
                <el-input
                    :class="$style.formLargeInput"
                    v-model="formCompanyInfo.registerNumber"
                    :placeholder="$t('user.companyhk.prompt.renum')"
                    @change="validateRegisterNum"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.companyhk.legaldeputy')" prop="legalRepresentative">
                <el-input
                    :class="$style.formSmallInput"
                    v-model="formCompanyInfo.legalRepresentative"
                    :placeholder="$t('user.companyhk.validate.legaldeputy.empty')"></el-input>
            </el-form-item>
            <el-form-item :label="$t('user.companyhk.established')">
                <el-date-picker
                    :class="$style.formSmallInput"
                    v-model="formCompanyInfo.establishTime"
                    :placeholder="$t('user.please.choose')"
                    value-format="timestamp"
                    type="date">
                </el-date-picker>
            </el-form-item>

            <el-form-item :label="$t('user.companyhk.readdress')" prop="registerAddress">
                <address-linkage v-model="formCompanyInfo.registerAddress" :countrys="countrys" :positions="formCompanyInfo.companyAreaCode">
                    <el-input v-model="formCompanyInfo.registerAddress.detailed"></el-input>
                </address-linkage>
            </el-form-item>
            <el-form-item :label="$t('user.companyhk.ofaddress')" prop="companyAddress">
                <address-linkage v-model="formCompanyInfo.companyAddress" :countrys="countrys" :positions="formCompanyInfo.companyAreaCode">
                    <el-input v-model="formCompanyInfo.companyAddress.detailed"></el-input>
                    <el-checkbox slot="ditto" v-model="addressChecked" @change="dittoAddress">{{ $t('user.sign.ditto') }}</el-checkbox>
                </address-linkage>
            </el-form-item>

            <el-form-item :label="$t('user.companyhk.bnlicenseperiod')">
                <el-date-picker
                    v-model="formCompanyInfo.licenseStartDate"
                    :placeholder="$t('user.please.choose')"
                    value-format="timestamp"
                    type="date">
                </el-date-picker>
                <span>{{ $t('user.sign.to') }}</span>
                <el-date-picker
                    v-model="formCompanyInfo.licenseEndDate"
                    :placeholder="$t('user.please.choose')"
                    value-format="timestamp"
                    type="date">
                </el-date-picker>
                <el-checkbox :class="$style.enduringMargin" v-model="formCompanyInfo.licenseIsLong">{{ $t('user.sign.long') }}</el-checkbox>
            </el-form-item>

            <el-form-item :label="$t('user.companyhk.idelectronic')" prop="legalUrls">
                <p :class="$style.uploadTitle">
                    {{ $t('user.companyhk.idelectronic.title') }}
                </p>
                <el-upload
                    :class="[formCompanyInfo.legalUrls.length < 2 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadLegal"
                    :on-success="successLegal"
                    :on-remove="removeLegal"
                    :show-file-list="true"
                    :file-list="formCompanyInfo.legalUrls"
                    :data="{ method: 'corporateAuth' }"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <i class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.companyhk.idelectronic.condition') }}</p>
            </el-form-item>
            <el-form-item :label="$t('user.companyhk.recertificate')" prop="licenseUrls">
                <p :class="$style.uploadTitle">
                    {{ $t('user.companyhk.recertificate.title') }}
                </p>
                <el-upload
                    :class="[formCompanyInfo.licenseUrls.length < 2 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadLicense"
                    :on-success="successLicense"
                    :on-remove="removeLicense"
                    :show-file-list="true"
                    :file-list="formCompanyInfo.licenseUrls"
                    :data="{ method: 'registrationAuth' }"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.companyhk.recertificate.condition') }}</p>
            </el-form-item>
            <el-form-item :label="$t('user.companyhk.business')" prop="businessUrls">
                <p :class="$style.uploadTitle">
                    {{ $t('user.companyhk.business.title') }}
                </p>
                <el-upload
                    :class="[formCompanyInfo.businessUrls.length < 2 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadBusiness"
                    :on-success="successBusiness"
                    :on-remove="removeBusiness"
                    :show-file-list="true"
                    :file-list="formCompanyInfo.businessUrls"
                    :data="{ method: 'businessLicenceAuth' }"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.companyhk.business.condition') }}</p>
            </el-form-item>
            <el-form-item :label="$t('user.companyhk.Incorporationtable')" prop="annualReturnUrls">
                <p :class="$style.uploadTitle">
                    {{ $t('user.companyhk.Incorporationtable.title') }}
                </p>
                <el-upload
                    :class="[formCompanyInfo.annualReturnUrls.length < 2 ? '' : $style.overstepLimit, $style.uploadPdf]"
                    :before-upload="beforeUploadAnnual"
                    :on-success="successAnnual"
                    :on-remove="removeAnnual"
                    :show-file-list="true"
                    :file-list="formCompanyInfo.annualReturnUrls"
                    :data="{ method: 'annualReturnAuth' }"
                    action="/imagemanage/anonymous-upload"
                    name="uploadFile"
                    list-type="picture-card">
                    <img v-if="dialogImageUrl" :src="dialogImageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <p :class="$style.uploadCondition">{{ $t('user.companyhk.Incorporationtable.condition') }}</p>
            </el-form-item>
        </div>
        <div :class="$style.buttonBox">
            <slot></slot>
            <el-button type="primary" @click="submitForm('formCompanyInfo')">{{ $t('user.next.step.collection') }}</el-button>
        </div>
    </el-form>
</template>

<script>
    import addressLinkage from '@user/components/AddressLinkage';
    import {
        countrysListGet,
        getRegisterCount,
        updateEntryInfo
    } from '@user/services/user';

    export default {
        name: 'Material',
        components: {
            'address-linkage': addressLinkage
        },
        props: {
            postEntryInfo: {
                type: Object,
                required: true,
            },
        },
        data() {
            const validateReNum = async (rule, value, callback) => {
                const { status, data } = await getRegisterCount.http({
                    showError: true,
                    params: {
                        registerNumber: this.formCompanyInfo.registerNumber
                    }
                });
                if (status === 0) {
                    if (data > 6) {
                        callback(new Error(this.$t('user.company.validate.renum.errlimit')));
                    } else {
                        callback();
                    }
                }
            };
            return {
                entryInfo: {},
                addressChecked: false,
                dialogImageUrl: '',
                countrys: [],
                formCompanyInfo: {
                    companyAreaCode: 'HK',
                    companyName: '',
                    registerNumber: '',
                    legalRepresentative: '',
                    licenseIsLong: true,
                    establishTime: null,
                    licenseStartDate: null,
                    licenseEndDate: null,
                    legalUrls: [],
                    licenseUrls: [],
                    businessUrls: [],
                    annualReturnUrls: [],
                    registerAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    },
                    companyAddress: {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    }
                },
                // 校验规则
                rules: {
                    companyName: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.companyhk.validate.name.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.validate.errlength50'),
                        }
                    ],
                    registerNumber: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.companyhk.validate.renum.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.contact.validate.errlength'),
                        },
                        {
                            validator: validateReNum,
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    legalRepresentative: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.companyhk.validate.legaldeputy.empty'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                        {
                            max: 50,
                            message: this.$t('user.companyhk.validate.errlength'),
                        }
                    ],
                    legalUrls: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.companyhk.validate.idelectronic'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    licenseUrls: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.companyhk.validate.recertificate'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    businessUrls: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.companyhk.validate.business'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ],
                    annualReturnUrls: [
                        {
                            required: true, // 是否必填
                            message: this.$t('user.companyhk.validate.Incorporationtable'), // 规则
                            trigger: 'blur', // 何事件触发
                        },
                    ]
                }
            };
        },
        watch: {
            postEntryInfo() {
                // 初始化表单
                this.init();
            },
            'formCompanyInfo.licenseEndDate': {
                handler(val, oldVal) {
                    if (val) {
                        this.formCompanyInfo.licenseIsLong = false;
                    } else {
                        this.formCompanyInfo.licenseIsLong = true;
                    }
                }
            }
        },
        created() {
            this.init();
            this.getCountrys();
        },
        methods: {
            // 初始化表单
            async init() {
                this.entryInfo = this.postEntryInfo;
                // 判断前一次提交的companyAreaCode是否当前类型，如不是则不宣染当前页
                if (this.postEntryInfo.companyAreaCode === this.formCompanyInfo.companyAreaCode) {
                    for (const key in this.formCompanyInfo) {
                        if (this.postEntryInfo[key]) {
                            if (['legalUrls', 'licenseUrls', 'businessUrls', 'annualReturnUrls'].includes(key)) {
                                const urlList = [];
                                this.postEntryInfo[key].forEach((item) => {
                                    urlList.push({ url: item });
                                });
                                this.formCompanyInfo[key] = urlList;
                            } else if (['establishTime', 'licenseStartDate', 'licenseEndDate'].includes(key)) {
                                this.formCompanyInfo[key] = this.postEntryInfo[key] * 1000;
                            } else if (key === 'licenseIsLong') {
                                this.formCompanyInfo[key] = this.postEntryInfo[key] === 1;
                            } else {
                                this.formCompanyInfo[key] = this.postEntryInfo[key];
                            }
                        }
                    }

                    // int类型处理（为0是转成空字符串）
                    this.formCompanyInfo.companyAddress.cdpProvinceId = this.formCompanyInfo.companyAddress.cdpProvinceId || '';
                    this.formCompanyInfo.companyAddress.cdpCityId = this.formCompanyInfo.companyAddress.cdpCityId || '';
                    this.formCompanyInfo.registerAddress.cdpProvinceId = this.formCompanyInfo.registerAddress.cdpProvinceId || '';
                    this.formCompanyInfo.registerAddress.cdpCityId = this.formCompanyInfo.registerAddress.cdpCityId || '';
                }
                this.formCompanyInfo.companyAreaCode = 'HK';
            },
            // 获取国家
            async getCountrys() {
                const { status, data } = await countrysListGet.http({
                    showError: true
                });
                if (status === 0) {
                    data.forEach((item) => {
                        if (item.countryCode === 'HK') {
                            this.countrys.push(item);
                        }
                    });
                }
            },
            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        for (const key in this.formCompanyInfo) {
                            if (['legalUrls', 'licenseUrls', 'businessUrls', 'annualReturnUrls'].indexOf(key) >= 0) {
                                const urlList = [];
                                this.formCompanyInfo[key].forEach((item) => {
                                    urlList.push(item.url);
                                });
                                this.entryInfo[key] = urlList;
                            } else if (['establishTime', 'licenseStartDate', 'licenseEndDate'].indexOf(key) >= 0) {
                                this.entryInfo[key] = Math.ceil(this.formCompanyInfo[key] / 1000);
                            } else if (key === 'licenseIsLong') {
                                this.entryInfo[key] = this.formCompanyInfo[key] ? 1 : 0;
                            } else {
                                this.entryInfo[key] = this.formCompanyInfo[key];
                            }
                        }

                        // int类型处理（提交数据时把空字符串转为0）
                        this.entryInfo.companyAddress.cdpProvinceId = this.entryInfo.companyAddress.cdpProvinceId || 0;
                        this.entryInfo.companyAddress.cdpCityId = this.entryInfo.companyAddress.cdpCityId || 0;
                        this.entryInfo.registerAddress.cdpProvinceId = this.entryInfo.registerAddress.cdpProvinceId || 0;
                        this.entryInfo.registerAddress.cdpCityId = this.entryInfo.registerAddress.cdpCityId || 0;
                        const { status } = await updateEntryInfo.http({
                            data: {
                                ...this.entryInfo
                            }
                        });
                        if (status === 0) {
                            this.$emit('update', { entryInfo: this.entryInfo, step: 2 });
                        }
                    }
                });
            },
            dittoAddress() {
                const vm = this;
                if (vm.addressChecked) {
                    vm.formCompanyInfo.companyAddress = vm.formCompanyInfo.registerAddress;
                } else {
                    vm.formCompanyInfo.companyAddress = {
                        countryCode: '',
                        cdpProvinceId: '',
                        cdpCityId: '',
                        cityName: '',
                        addressDetail: ''
                    };
                }
            },

            // 图片上传前验证
            beforeUploadFn(file, isAnnual) {
                const isJPG = isAnnual ? file.type === 'application/pdf'
                : ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'].indexOf(file.type) >= 0;
                const isLt2M = isAnnual ? file.size / 1024 / 1024 < 10 : file.size / 1024 / 1024 < 1;

                if (!isJPG) {
                    this.$message.error(isAnnual ? this.$t('user.companyhk.validate.Incorporationtable.errformat')
                    : this.$t('user.companyhk.validate.idelectronic.errformat'));
                }
                if (!isLt2M) {
                    this.$message.error(isAnnual ? this.$t('user.company.validate.Incorporationtable.errsize')
                    : this.$t('user.company.validate.idelectronic.errsize'));
                }
                return isJPG && isLt2M;
            },
            // 上传成功
            uploadSuccessFn(res, urlList) {
                const { status, data, msg } = res;
                if (status === 0) {
                    this.formCompanyInfo[urlList].push({ url: data.url });
                } else {
                    this.formCompanyInfo[urlList] = [];
                    this.$message.error(msg);
                }
            },

            // 图片删除
            removeUploadFn(file, urlList) {
                this.formCompanyInfo[urlList].forEach((item, index) => {
                    if (item.url === file.url) {
                        this.formCompanyInfo[urlList].splice(index, 1);
                    }
                });
            },

            // 上传法人身份证前
            beforeUploadLegal(file) {
                return this.beforeUploadFn(file);
            },
            // 上传法人身份证成功
            successLegal(res, file) {
                this.uploadSuccessFn(res, 'legalUrls');
            },
            // 删除法人身份证
            removeLegal(file) {
                this.removeUploadFn(file, 'legalUrls');
            },

            // 上传注册证书
            beforeUploadLicense(file) {
                return this.beforeUploadFn(file);
            },
            // 上传注册证书成功
            successLicense(res, file) {
                this.uploadSuccessFn(res, 'licenseUrls');
            },
            // 删除注册证书
            removeLicense(file) {
                this.removeUploadFn(file, 'legalUrls');
            },

            // 上传商业登记
            beforeUploadBusiness(file) {
                return this.beforeUploadFn(file);
            },
            // 上传注册证书成功
            successBusiness(res, file) {
                this.uploadSuccessFn(res, 'businessUrls');
            },
            // 删除注册证书
            removeBusiness(file) {
                this.removeUploadFn(file, 'businessUrls');
            },

            // 上传周年申报表
            beforeUploadAnnual(file) {
                return this.beforeUploadFn(file, true);
            },
            // 上传周年申报表成功
            successAnnual(res, file) {
                this.uploadSuccessFn(res, 'annualReturnUrls');
            },
            // 删除周年申报表
            removeAnnual(file) {
                this.removeUploadFn(file, 'annualReturnUrls');
            },
            // 注册号只能输入数字和字母
            validateRegisterNum() {
                this.formCompanyInfo.registerNumber = this.formCompanyInfo.registerNumber.replace(/[^0-9-A-Za-z]/g, '');
            }

        },
    };
</script>

<style module>
    @import 'variable.css';

    .overstepLimit [class~="el-upload"]{
        display: none;
    }
    .info{
        width: 1000px;
        margin: 30px auto 50px;
    }
    .formLargeInput{
        width: 620px;
    }
    .formSmallInput{
        width: 300px;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
    }
    .enduringMargin{
        margin-left: 10px;
    }
    .uploadTitle{
        color: var(--color-black);
        margin-bottom: 10px;
    }
    .uploadCondition{
        color: var(--color-text-regular);
        margin-top: 20px;
    }
    .uploadPdf [class~="el-upload-list__item"]{
        background: url('@user/assets/img/pdf-bg.png') center no-repeat;
        background-size: 80%;
    }
    .uploadPdf [class~="el-upload-list__item-thumbnail"]{
        background-color: var(--color-white);
    }

</style>
