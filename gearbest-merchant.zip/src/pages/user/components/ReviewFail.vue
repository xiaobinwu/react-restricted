<template>
    <div :class="$style.reviewInfo">
        <i :class="$style.failIcon" class="el-icon-error"></i>
        <h3 :class="$style.reviewTitle">{{ $t('user.review.fail') }}</h3>
        <div :class="$style.failReason">
            <P>{{ $t('user.review.fail.reason') }}</P>
            <slot></slot>
        </div>
        <p :class="$style.reviewNote">
            {{ $t('user.review.fail.note') }}
            <span :class="$style.perfect" @click="updatedInfo">{{ $t('user.review.fail.perfect') }}</span>
        </p>
        <div :class="$style.buttonBox">
            <span :class="$style.back" @click="returnMerchants">{{ $t('user.contact.back') }}</span>
        </div>
    </div>
</template>

<script>
    export default {
        methods: {
            updatedInfo() {
                this.$emit('update', { entryInfo: this.entryInfo, step: 0 });
            },
            returnMerchants() {
                this.$router.gbPush('/sign/sign-index');
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .reviewInfo{
        text-align: center;
        padding: 100px 0;
    }
    .failIcon{
        font-size: 60px;
        color: var(--color-danger);
    }
    .reviewTitle{
        margin-top: 20px;
        font-size: 18px;
    }
    .failReason{
        width: 200px;
        margin: 10px auto;
        text-align: left;
        line-height: 20px;
    }
    .reviewNote{
        margin-top: 20px;
        font-size: 14px;
    }
    .perfect{
        color: var(--color-primary-darken);
        cursor: pointer;
    }
    .buttonBox{
        border-top: 1px solid var(--background-color-base);
        padding: 40px 0;
        text-align: right;
        margin-top: 50px;
    }
    .back{
        color: var(--color-primary-darken);
        float: left;
        margin-top: 12px;
        cursor: pointer;
    }
</style>
