
import Service from '@/assets/js/Service/index';


/**
 * 提交入驻信息
 * @type {}
 */

export const postEntryInfo = new Service({
    url: '/user/update-enter-info',
    method: 'POST',
    showError: true,
});

/**
 * 获取国家区号
 * @type {}
 */

export const phonecodeList = new Service({
    url: '/phonecode-list',
    method: 'get',
    showError: true,
});

/**
 * 获取主营业务等信息
 * @type {}
 */

export const getEnterData = new Service({
    url: '/account/get-enter-data',
    method: 'get',
    showError: true,
});

/**
 * 查询公司注册号使用次数
 * @type {}
 */

export const getRegisterCount = new Service({
    url: '/account/register-number-count',
    method: 'get',
    showError: true,
});

/**
 * 检查店铺名是否已使用
 * @type {}
 */

export const checkShopName = new Service({
    url: '/account/check-shop-name',
    method: 'get',
    showError: true,
    isCancel: false,
});

/**
 * 获取入驻信息
 * @type {}
 */

export const getEntryInfo = new Service({
    url: '/user/get-enter-info',
    method: 'get',
    showError: true,
});


/**
 *更新入驻信息
 * @type {}
 */

export const updateEntryInfo = new Service({
    url: '/user/update-enter-info',
    method: 'post',
    showError: true,
});

/**
 *删除图片
 * @type {}
 */

export const deleteImage = new Service({
    url: '/image-manage/image-upload',
    method: 'post',
    showError: true,
});


/* 地址管理-查询国家-级联选择器 */
export const countrysListGet = new Service({
    url: '/public/logistics/country/list',
    method: 'get',
    showError: true,
});

/* 地址管理-查询省份-级联选择器 */
export const provincesListGet = new Service({
    url: '/public/logistics/country/get-provinces-by',
    method: 'get',
    showError: true,
    isCancel: false,
});

/* 地址管理-查询城市-级联选择器 */
export const citysListGet = new Service({
    url: '/public/logistics/country/get-cities-by',
    method: 'get',
    showError: true,
    isCancel: false,
});
