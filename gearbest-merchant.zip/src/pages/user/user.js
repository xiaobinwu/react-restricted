import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import userLang from '@/lang/user';
import router from './router';

(async () => {
    const langInstance = await lang({
        local: userLang,
        moduleName: 'user'
    });

    app({
        lang: langInstance,
        router
    });
})();
