import Service from '@/assets/js/Service';

/**
 * 获取店铺模板
 */
export const getDecoration = new Service({
    url: '/store/decoration/get-decoration',
    mock: false,
});

/**
 * 保存店铺模板
 */
export const updateDecoration = new Service({
    url: '/store/decoration/update-decoration',
    method: 'POST',
    mock: false,
});

/**
 * 图片上传
 */
export const imageUpload = new Service({
    url: '/image-manage/image-upload',
    method: 'POST',
    headers: {
        'Content-type': 'multipart/form-data'
    },
    mock: false,
});
