import router from '@/assets/js/router';
import Layout from '@/components/Layout';
import children from './routes';

const routes = [
    {
        path: '/',
        component: Layout,
        name: 'storeDecorate',
        redirect: '/store/decorate',
        meta: {
            requireAuth: true
        },
        children
    }
];

export default router({ routes });
