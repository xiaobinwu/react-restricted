import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    {
        path: '/store/decorate',
        name: 'storeDecorate',
        meta: {
            title: 'base.menu.store.name',
            focusMenu: '/store/decorate'
        },
        component: () => asyncComponent(import('@store/views/Decorate'))
    }
];
