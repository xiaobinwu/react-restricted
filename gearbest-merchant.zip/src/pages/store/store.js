import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import store from '@/lang/store';
import router from './router';

lang({ local: store, moduleName: 'store' }).then((langInstance) => {
    app({ lang: langInstance, router });
});
