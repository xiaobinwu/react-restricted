<template>
    <transition name="el-zoom-in-top">
        <div v-show="reviewData.status" :class="$style.reviewBox">
            <header :class="$style.header">
                <span :class="[$style.icon, { [$style.active]: imgType === 'pc'}]" @click="changeReview('pc')">
                    <i :class="[$style.pcIcon, $style.iconCommon]" class="icon-pc"></i>
                </span>
                <span :class="[$style.icon, { [$style.active]: imgType === 'mobile'}]" @click="changeReview('mobile')">
                    <i :class="[$style.mobileIcon, $style.iconCommon]" class="icon-phone"></i>
                </span>
                <div :class="$style.close" @click="$emit('close', 0)">X</div>
            </header>
            <img :class="$style.reviewImg" :src="imgType === 'pc' ? reviewData.imgObj.previewPc : reviewData.imgObj.previewM">
        </div>
    </transition>
</template>

<script>
    export default {
        props: {
            reviewData: {
                type: Object,
                default() {
                    return {
                        status: false,
                        imgObj: {}
                    };
                }
            }
        },
        data() {
            return {
                imgType: 'pc'
            };
        },
        methods: {
            changeReview(type) {
                this.imgType = type;
            }
        },
    };
</script>

<style module>
    .reviewBox{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: #F2F2F2;
        z-index: 9;
        text-align: center;
    }
    .header{
        display: block;
        height: 80px;
        background-color: #fff;
        font-size: 0;
        text-align: center;
        &::after{
            content: '';
            display: inline-block;
            width: 0;
            height: 100%;
            vertical-align: middle;
        }
    }
    .icon{
        display: inline-block;
        width: 100px;
        height: 40px;
        line-height: 40px;
        vertical-align: middle;
        border: 1px solid #EEE;
        cursor: pointer;
    }
    .iconCommon{
        font-size: 30px;
    }
    .active{
        background: #61A5FF;
        i{
            color: #fff;
        }
    }
    .close{
        position: absolute;
        top: 20px;
        right: 40px;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: 1px solid #ccc;
        cursor: pointer;
        color: #ccc;
        font-size: 25px;
        line-height: 40px;
        cursor: pointer;
    }
    .reviewImg{
        margin-top: 40px;
        display: inline-block;
    }
</style>
