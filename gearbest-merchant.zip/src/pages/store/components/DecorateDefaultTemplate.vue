<template>
    <div class="useTemplate">
        <h3 :class="$style.title">{{ title }}</h3>
        <img :class="$style.templateImg" :src="defaultItem.bannerPc">
        <div :class="$style.operate">
            <el-button v-if="defaultItem.selected" :class="[$style.btn, $style.use]" type="primary" @click="changeTemplate(1)">停止使用</el-button>
            <el-button v-else :class="[$style.btn, $style.use]" @click="changeTemplate(0)">使用</el-button>

            <el-button :class="[$style.btn, $style.preview]" @click="$emit('review', 1, defaultItem)">预览效果</el-button>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            title: {
                type: String,
                required: true
            },
            defaultItem: {
                type: Object,
                required: true
            },
            index: {
                type: Number,
                required: true
            }
        },
        data() {
            return {

            };
        },
        methods: {
            changeTemplate(status) {
                const options = {};
                if (!status) {
                    options.bannerPc = this.defaultItem.bannerPc;
                    options.bannerM = this.defaultItem.bannerM;
                }
                this.$emit('save-decoration', options, status, this.index);
            },
        }
    };
</script>

<style module>
    .useTemplate{
        margin: 20px;
    }
    .title{
        font-size: 14px;
        color: #000;
    }
    .templateImg{
        display: block;
        height: 65px;
        margin-top: 10px;
    }
    .operate{
        margin-top: 10px;
        font-size: 0;
    }
    .btn{
        display: inline-block;
        vertical-align: top;
    }
    .use{
        margin-right: 20px;
    }
</style>
