<template>
    <div :class="$style.main">
        <div :class="$style.diffPlatform">
            <span :class="$style.lableTitle">{{ $t('store.platform.pc') }}:</span>
            <el-upload
                :class="$style.avatarUploader"
                :show-file-list="false"
                :http-request="uploadImagePC"
                action="">
                <span v-if="customize.bannerPc" :class="$style.imgWrap">
                    <img :src="customize.bannerPc" :class="$style.bannerImg">
                    <i :class="$style.guanbi" class="icon-close" @click.stop="deleteImg('pc')"></i>
                </span>
                <el-button v-else type="primary">{{ $t('store.upload.browse') }}</el-button>
            </el-upload>
            <p :class="$style.tips">{{ $t('store.upload.pcTips') }}</p>
        </div>

        <div :class="$style.diffPlatform">
            <span :class="$style.lableTitle">{{ $t('store.platform.mobile') }}:</span>
            <el-upload
                :class="$style.avatarUploader"
                :show-file-list="false"
                :http-request="uploadImageM"
                action="">
                <span v-if="customize.bannerM" :class="$style.imgWrap">
                    <img :src="customize.bannerM" :class="$style.bannerImg">
                    <i :class="$style.guanbi" class="icon-close" @click.stop="deleteImg('mobile')"></i>
                </span>
                <el-button v-else type="primary">{{ $t('store.upload.browse') }}</el-button>
            </el-upload>
            <p :class="$style.tips">{{ $t('store.upload.mTips') }}</p>
        </div>

        <div :class="$style.submitBox">
            <el-button :class="$style.submit" type="primary" @click="submit">{{ $t('store.upload.sure') }}</el-button>
            <p :class="$style.submitTips">{{ $t('store.submit.tips') }}</p>
        </div>

    </div>
</template>

<script>
    import { getImgInfo } from '@/assets/js/utils/assist';
    import { imageUpload, updateDecoration } from '../services';

    export default {
        props: {
            customize: {
                type: Object,
                default() {
                    return {
                        bannerM: '',
                        bannerPc: ''
                    };
                }
            }
        },
        data() {
            return {
                imageUploadUrl: '/devApi/image-manage/image-upload',
            };
        },
        methods: {
            beforeAvatarUpload(file) {
                const isSuit = ['image/jpeg', 'image/gif'].includes(file.type);
                if (!isSuit) {
                    this.$message.error(this.$t('store.upload.pcTips'));
                }
                return isSuit;
            },
            deleteImg(plat) {
                if (plat === 'pc') this.customize.bannerPc = '';
                else this.customize.bannerM = '';
            },
            async submit() {
                const { bannerPc, bannerM } = this.customize;
                const { status, msg } = await updateDecoration.http({
                    params: {
                        bannerPc: this.getPathName(bannerPc),
                        bannerM: this.getPathName(bannerM),
                    }
                });
                if (status === 0) {
                    this.$message({
                        message: msg,
                        type: 'success'
                    });
                } else {
                    this.$message.error(msg);
                }
            },
            getPathName(url) {
                const urlVal = url.split('//');
                let pathName = '';
                if (urlVal.length === 2 && urlVal[1].includes('/')) {
                    pathName = urlVal[1].slice(urlVal[1].indexOf('/'));
                } else if (urlVal.length === 1) {
                    pathName = urlVal[0];
                }
                return pathName;
            },
            async uploadImage(fileLists) {
                const form = new FormData();
                form.append('method', 'storeBanner');
                form.append('uploadFile', fileLists);
                const { status, data: { url = '' } } = await imageUpload.http({
                    body: form
                });
                if (status === 0) {
                    return url;
                }
                return undefined;
            },
            checkUploadImg({
                platform,
                width,
                height,
                type,
                size
            }) {
                let upload = true;
                if (!['image/jpeg', 'image/gif'].includes(type)) {
                    this.$message.error(this.$t('store.upload.typeError'));
                    upload = false;
                } else if (size > 500) {
                    this.$message.error(this.$t('store.upload.sizeError'));
                    upload = false;
                }
                if (platform === 'PC' && (width !== 1920 || height !== 350)) {
                    this.$message.error(this.$t('store.upload.pcAttrError'));
                    upload = false;
                }
                if (platform === 'M' && (width !== 750 || height !== 300)) {
                    this.$message.error(this.$t('store.upload.mAttrError'));
                    upload = false;
                }
                return upload;
            },
            async uploadImagePC({ file }) {
                const fileImg = await getImgInfo(file);
                if (this.checkUploadImg({ platform: 'PC', ...fileImg })) {
                    this.customize.bannerPc = await this.uploadImage(file);
                }
            },
            async uploadImageM({ file }) {
                const fileImg = await getImgInfo(file);
                if (this.checkUploadImg({ platform: 'M', ...fileImg })) {
                    this.customize.bannerM = await this.uploadImage(file);
                }
            }
        }
    };
</script>

<style module>
    .main{
        margin-top: 20px;
    }
    .diffPlatform{
        margin-bottom: 20px;
        font-size: 0;
    }
    .imgWrap{
        position: relative;
        display: block;
        &:hover{
            &::after{
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.7);
            }
            .guanbi{
                display: block;
            }
        }
    }
    .guanbi{
        display: none;
        position: absolute;
        top: 50%;
        left: 50%;
        font-size: 18px;
        margin-left: -9px;
        margin-top: -9px;
        color: #fff;
        z-index: 1;
    }
    .bannerImg{
        max-width: 792px;
    }
    .tips{
        font-size: 14px;
        color: #666;
        margin-top: 10px;
        margin-left: 116px;
    }
    .lableTitle{
        display: inline-block;
        text-align: right;
        width: 96px;
        margin-right: 20px;
        font-size: 14px;
    }
    .avatarUploader{
        display: inline-block;
    }
    .submitBox{
        position: relative;
        display: block;
        width: 70px;
        margin: 30px auto 50px;
    }
    .submit{
        display: block;
    }
    .submitTips{
        position: absolute;
        white-space: nowrap;
        top: 100%;
        left: 130%;
        transform: translateY(-100%);
    }
</style>
