<template>
    <div>
        <div :class="$style.text">
            <span :class="$style.tips">{{ tipstext }}</span>
            <textarea :value="valuetext"
                      :class="$style.textInput"
                      :maxlength="index === 'slogan1' ? 16 : 18" @input="$emit('set-text', $event.target.value, index)"></textarea>
        </div>
        <div :data-index="index" :class="$style.tipsLength">
            <p v-if="index === 'slogan1'">{{ 16 - valuetext.length }}/16</p>
            <p v-else>{{ 18 - valuetext.length }}/18</p>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            tipstext: {
                type: String,
                required: true,
            },
            valuetext: {
                type: String,
                required: true,
            },
            index: {
                type: String,
                required: true,
            }
        },
        data() {
            return {

            };
        }
    };
</script>

<style module>
    .text{
        display: block;
        font-size: 0;
    }
    .tipsLength{
        padding-left: 125px;
        margin-bottom: 20px;
        margin-top: 5px;
    }
    .tips{
        display: inline-block;
        vertical-align: top;
        width: 105px;
        text-align: right;
        color: #000;
        font-size: 14px;
        margin-right: 20px;
    }
    .textInput{
        display: inline-block;
        vertical-align: top;
        width: 783px;
        height: 100px;
        font-size: 14px;
        resize: none;
        padding: 10px;
    }
</style>
