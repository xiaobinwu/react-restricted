<template>
    <div :class="$style.wrap">
        <div :class="$style.templateWrap">
            <div
                v-for="(defaultItem, index) in defaultList" :key="index" :class="[$style.templateLeft, { [$style.active]: defaultItem.selected }]">
                <DecorateDefaultTemplate
                    :default-item="defaultItem"
                    :title="templateTile[index]"
                    :index="index"
                    @save-decoration="saveDecoration"
                    @review="showReview"
                />
            </div>
        </div>
        <div :class="$style.textWrap">
            <DecorateDefaultText
                v-for="(value, key) in sloganList"
                :index="key"
                :key="key"
                :tipstext="sloganTitle[key]"
                :valuetext="value"
                @set-text="setText"
            />
            <div :class="$style.submitBox">
                <el-button :class="$style.textSubmit" type="primary" @click="saveText">{{ $t('store.upload.sure') }}</el-button>
                <p :class="$style.submitTips">{{ $t('store.submit.tips') }}</p>
            </div>

        </div>
        <DecorateDefaultReview :review-data="currentReview" @close="showReview" />
    </div>
</template>

<script>
    import DecorateDefaultTemplate from './DecorateDefaultTemplate.vue';
    import DecorateDefaultText from './DecorateDefaultText.vue';
    import DecorateDefaultReview from './DecorateDefaultReview.vue';
    import { updateDecoration } from '../services';

    export default {
        components: {
            DecorateDefaultTemplate,
            DecorateDefaultText,
            DecorateDefaultReview,
        },
        props: {
            defaultList: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            sloganList: {
                type: Object,
                required: true,
                default() {
                    return {
                        slogan1: '',
                        slogan2: ''
                    };
                }
            }
        },
        data() {
            return {
                templateTile: [this.$t('store.default.template.one'), this.$t('store.default.template.seccond')],
                defaultBanner: {},
                sloganTitle: {
                    slogan1: this.$t('store.default.firstLine'),
                    slogan2: this.$t('store.default.seccondLine')
                },
                currentReview: {
                    status: false,
                    imgObj: {}
                }
            };
        },
        computed: {
        },
        methods: {
            async sendData(options) {
                const data = await updateDecoration.http({
                    data: {
                        ...options
                    },
                });

                return data;


            },
            async saveDecoration(options, useStatus, index) {
                this.defaultBanner = options;
                if (useStatus) {
                    // 停止使用
                    this.defaultList[index].selected = 0;
                } else {
                    this.defaultList.forEach((value) => {
                        value.selected = 0;
                    });
                    this.defaultList[index].selected = 1;
                }
            },
            setText(text, index) {
                // 文案保存
                this.sloganList[index] = text;
            },
            async saveText() {
                const { status, msg } = await this.sendData({
                    slogan1: this.sloganList.slogan1,
                    slogan2: this.sloganList.slogan2,
                    ...this.defaultBanner
                });
                if (status === 0) {
                    this.$message({
                        type: 'success',
                        message: msg
                    });
                }
            },
            showReview(status, imgObj) {
                if (status) {
                    this.currentReview = {
                        status: true,
                        imgObj
                    };
                } else {
                    this.currentReview.status = false;
                }
            }
        }
    };
</script>

<style module>
    .textWrap{
        margin-top: 25px;
    }
    .templateWrap{
        display: flex;
        font-size: 0;
    }
    .templateLeft{
        display: inline-block;
        flex: 1;
        vertical-align: top;
        width: 456px;
        height: 195px;
        border: 1px solid #D2D2D2;
        border-radius: 4px;
        padding: 20px;
        &:first-child{
            margin-right: 20px;
        }
    }
    .submitBox{
        position: relative;
        display: block;
        width: 70px;
        margin: 30px auto 50px;
    }
    .textSubmit{
        display: block;
    }
    .submitTips{
        position: absolute;
        white-space: nowrap;
        top: 100%;
        left: 130%;
        transform: translateY(-100%);
    }
    .active{
        border-color: #2774FF;
    }
</style>
