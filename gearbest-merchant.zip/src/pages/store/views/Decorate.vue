<template>
    <div :class="$style.main">
        <el-tabs v-model="currentActive" type="border-card">
            <el-tab-pane :label="$t('store.tabs.custom')" name="customBanner">
                <DecorateCustom :customize="initData.customize" />
            </el-tab-pane>
            <el-tab-pane :label="$t('store.tabs.default')" name="defaultBanner">
                <DecorateDefault :default-list="initData.default" :slogan-list="initData.slogan" />
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>
    import DecorateCustom from '../components/DecorateCustom.vue';
    import DecorateDefault from '../components/DecorateDefault.vue';
    import { getDecoration } from '../services';

    export default {
        components: {
            DecorateCustom,
            DecorateDefault
        },
        data() {
            return {
                currentActive: 'customBanner',
                initData: {},
            };
        },
        beforeCreate() {
            getDecoration.http().then(({ data, status }) => {
                if (status === 0) {
                    this.initData = data;
                    if (Array.isArray(this.initData.customize)) {
                        this.currentActive = 'defaultBanner';
                        this.initData.customize = { // 定义默认字段，后台字段不统一
                            bannerM: '',
                            bannerPc: ''
                        };
                    }
                }
            });
        },
    };
</script>

<style module>
    .main{
        padding: 20px;
        background-color: #fff;
    }
</style>
