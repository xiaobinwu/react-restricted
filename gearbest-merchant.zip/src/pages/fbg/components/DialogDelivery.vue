<template>
    <el-dialog
        :visible.sync="visible"
        :before-close="close"
        :class="$style.eldialog"
        width="1500px">
        <p :class="$style.mdl_title">申请入仓商品:</p>
        <p :class="[$style.mdl_title, $style.mgb10]">{{ $t('fbg.moveout.selectGood') }}</p>
        <el-form :inline="true" :model="deliveryForm">
            <el-form-item>
                <el-input
                    v-model="deliveryForm.goodsNo"
                    placeholder="商品sku搜索"
                    type="number">
                    <el-select
                        slot="prepend"
                        :class="$style.codeSelect"
                        v-model="deliveryForm.goodSpu">
                        <el-option
                            v-for="item in searchList"
                            :key="item.name+'_'+item.code"
                            :label="item.name"
                            :value="item.code"></el-option>
                    </el-select>
                </el-input>
            </el-form-item>
            <el-form-item label="平台类目">
                <category-cascader :category_id="deliveryForm.category_id" @updateCategory="updateCategory"></category-cascader>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="getGoods">搜索</el-button>
            </el-form-item>
            <el-form-item :class="$style.delively_addGoods">已添加的商品</el-form-item>
        </el-form>
        <div :class="$style.delivelyTsf_wrapper">
            <div :class="$style.delivelyTsf_row">
                <el-table
                    :class="$style.deliveryTsf_cell"
                    :data="showGoods"
                    max-height="500"
                    style="width: 45%"
                    @selection-change="listSelectionChange">
                    <el-table-column type="selection"></el-table-column>
                    <el-table-column
                        prop="title"
                        label="商品标题"
                        width="270">
                        <template slot-scope="scope">
                            <div :class="$style.nowrap">
                                <img :class="$style.img" :src="scope.row.image_urls.length > 0 ? scope.row.image_urls[0] : ''" alt="">
                                <span :class="$style.link">{{ scope.row.title }}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="sku"
                        label="商品编码">
                    </el-table-column>
                    <el-table-column
                        prop="categoryName"
                        label="商品类目">
                    </el-table-column>
                </el-table>
                <div :class="[$style.deliveryTsf_cell, $style.deliveryTsf_btn]">
                    <el-button
                        type="primary"
                        @click="copySelectionChange">添加
                        <i class="el-icon-arrow-right"></i>
                    </el-button>
                    <el-button
                        :class="$style.deliveryBatch_Del"
                        type="danger"
                        @click="removeBatch">
                        <i class="el-icon-arrow-left"></i>
                        批量删除
                    </el-button>
                </div>
                <el-table
                    :class="$style.deliveryTsf_cell"
                    :data="showGoodsAdd"
                    max-height="500"
                    style="width: 45%"
                    @selection-change="delListSelectionChange">
                    <el-table-column type="selection"></el-table-column>
                    <el-table-column
                        prop="title"
                        label="商品标题">
                        <template slot-scope="scope">
                            <div :class="$style.nowrap">
                                <img :class="$style.img" :src="scope.row.image_urls.length > 0 ? scope.row.image_urls[0] : ''" alt="">
                                <span :class="$style.link">{{ scope.row.title }}</span>
                            </div>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="sku"
                        label="商品编码">
                    </el-table-column>
                    <el-table-column
                        label="申请入仓数量"
                        width="100">
                        <template slot-scope="scope">
                            <el-input
                                :class="!scope.row.error ? $style.error : ''"
                                v-model="scope.row.$feSendAmount"
                                maxlength="30" type="number"
                                @blur="checkNumber(scope.row)"></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column
                        label="操作"
                        width="100px">
                        <template slot-scope="scope">
                            <el-button :class="$style.delivelyDelBtn" type="text" @click="removeRow(scope.$index)">移除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>

            <!-- 分页 -->
            <div :class="$style.delivelyTsf_footer">
                <div :class="[$style.deliveryTsf_cell, $style.deliveryPage_wrapper]" style="width: 45%">
                    <el-pagination
                        :current-page.sync="listPage.currentPage"
                        :page-size="10"
                        :total="listPage.totalCount"
                        layout="total, prev, pager, next"
                        @current-change="handleCurrentChange">
                    </el-pagination>
                </div>
                <div :class="[$style.deliveryTsf_cell]" style="width: 10%"></div>
                <div :class="[$style.deliveryTsf_cell, $style.deliveryPage_wrapper]" style="width: 45%">
                    <el-pagination
                        :current-page.sync="addPage.currentPage"
                        :page-size="10"
                        :total="addPage.totalCount"
                        layout="total, prev, pager, next"
                        @current-change="addPageCurrentChange">
                    </el-pagination>
                </div>
            </div>
        </div>
        <div slot="footer" :class="[$style.center, 'dialog-footer']">
            <el-button @click="close">取 消</el-button>
            <el-button type="primary" @click="savegoods">保 存</el-button>
        </div>
    </el-dialog>
</template>

<script>

    import CategoryCascader from '@/components/CategoryCascader';
    import { fbgArrivalProvedGoods } from '@fbg/services/fbg';

    export default {
        name: 'DialogDelivery',
        components: {
            CategoryCascader
        },
        props: {
            visible: {
                type: Boolean,
                default: false,
            },
        },
        data() {
            return {
                goods: [],
                showGoods: [],
                listPage: {
                    currentPage: 1,
                    pageSize: 10,
                    totalCount: 0,
                },
                deliveryForm: {
                    goodsNo: '',
                    goodSpu: '111',
                    category_id: '',
                    review_status: 3,
                },
                listMultipleSelection: [],
                delListSelectionSku: [],
                addPage: {
                    currentPage: 1,
                    pageSize: 10,
                    totalCount: 0,
                },
                goodsAdd: [],
                showGoodsAdd: [],
                AddMultipleSelection: [],
                inputRules: /^\+?[1-9][0-9]*$/, // 正整数正则表达式
                searchList: [
                    { name: '商品', code: '111' },
                    { name: 'spu', code: '222' }
                ]
            };
        },
        /* watch: {
            visible: {
                handler(newVal) {
                    this.listPage.totalCount = this.goods.length;
                    // this.goodsAdd = [];
                    if (newVal) {
                        // this.getGoods();
                    }
                },
            },
        }, */
        created() {
            this.getGoods();
        },
        methods: {
            close() {
                this.$emit('close');
            },
            async getGoods() {
                const { listPage } = this;
                const params = {
                    ...this.deliveryForm,
                    page_index: listPage.currentPage,
                    page_size: listPage.pageSize,
                };

                const { status, data: { list, } } = await fbgArrivalProvedGoods.http({
                    params,
                });
                if (status === 0) {
                    this.goods = list;
                    this.listPage.totalCount = list.length;
                    this.showGoodsFun();
                }
            },
            handleCurrentChange(val) {

            },
            listSelectionChange(list) {
                this.listMultipleSelection = list;
            },
            showGoodsFun() {
                this.showGoods = [];
                const maxlength = this.listPage.totalCount >= (this.listPage.currentPage * this.listPage.pageSize)
                    ? this.listPage.currentPage * this.listPage.pageSize : this.listPage.totalCount;
                for (
                    let index = (this.listPage.currentPage - 1) * this.listPage.pageSize;
                    index < maxlength;
                    index += 1
                ) {
                    this.showGoods.push(this.goods[index]);

                }
                console.log(this.showGoods);
            },
            showGoodsAddFun() {
                this.showGoodsAdd = [];
                const maxlength = this.addPage.totalCount >= (this.addPage.currentPage * this.addPage.pageSize)
                    ? this.addPage.currentPage * this.addPage.pageSize : this.addPage.totalCount;
                for (
                    let index = (this.addPage.currentPage - 1) * this.addPage.pageSize;
                    index < maxlength;
                    index += 1
                ) {
                    this.showGoodsAdd.push(this.goodsAdd[index]);
                }
            },
            delListSelectionChange(list) {
                this.delListSelectionSku = [];
                list.forEach((item) => {
                    this.delListSelectionSku.push(item.sku);
                });
            },
            copySelectionChange() {
                // this.goodsAdd.forEach(() => {
                //     this.goodsAdd.splice(0, 1);
                // });
                this.goodsAdd = [];
                const temp = JSON.parse(JSON.stringify(this.listMultipleSelection));
                temp.forEach((goods, index) => {
                    let ishas = false;
                    this.goodsAdd.forEach((item) => {
                        if (item.sku === goods.sku) {
                            ishas = true;
                        }
                    });
                    if (!ishas) {
                        goods.error = false;
                        this.goodsAdd.push(goods);
                    }
                });
                this.addPage.totalCount = this.goodsAdd.length;
                this.showGoodsAddFun();
            },
            addPageCurrentChange(val) {
                this.showGoodsAddFun();
            },
            AddSelectionChange(list) {
                this.AddMultipleSelection = list;
            },
            removeRow(index) {
                this.goodsAdd.splice(index, 1);
                this.addPage.totalCount = this.goodsAdd.length;
                this.showGoodsAddFun();
            },
            removeBatch() {
                const delIndex = [];
                console.log(this.goodsAdd);
                for (let i = this.goodsAdd.length - 1; i >= 0; i -= 1) {
                    this.delListSelectionSku.forEach((item) => {
                        if (this.goodsAdd[i].sku === item) {
                            delIndex.push(i);
                        }
                    });
                }
                delIndex.forEach((index) => {
                    this.goodsAdd.splice(index, 1);
                });
                this.addPage.totalCount = this.goodsAdd.length;
                this.showGoodsAddFun();
            },
            updateCategory(data) {
                this.deliveryForm.category_id = data.category_id;
            },
            checkNumber(row) {
                if (this.inputRules.test(row.$feSendAmount) && row.$feSendAmount > 0) {
                    row.error = 1;
                } else {
                    row.error = 0;
                    this.$message.error('请输入正确数量');
                }
            },
            savegoods() {
                let totalAmount = 0;
                let error = false;
                const saved = [];
                this.goodsAdd.forEach((goods, index) => {
                    goods.$feSendAmount = +goods.$feSendAmount || 0;
                    totalAmount += goods.$feSendAmount;

                    if (!goods.error) {
                        error = true;
                    }

                    saved.push({
                        purchase_price: goods.present_price,
                        send_amount: goods.$feSendAmount,
                        category_id: goods.category_id,
                        title: goods.title,
                        sku: goods.sku,
                    });
                });

                if (!error && totalAmount > 0) {
                    this.$parent.saveData({
                        saved,
                        totalAmount,
                    });
                    this.$emit('close');
                } else {
                    this.$message.error('请输入申请入仓数量');
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .eldialog{
        :global .el-dialog__header{display: none;}
    }
    .center{text-align: center;}
    .mdl_title{
        font-size: 16px;
        font-weight:600;
        color:rgba(0,0,0,1);
        line-height: 30px;
    }
    .mdl_elm{
        line-height: 40px;
        display: inline-block;
    }
    .mgr60{
        margin-right: 60px;
    }
    .mgb10{
        margin-bottom: 10px;
    }
    .inlineBlock{
        display: inline-block;
    }
    .deliveryTsf_cell{
        display: table-cell;
    }
    .delivelyTsf_wrapper{
        display: table;
        width: 100%;
    }
    .delivelyTsf_row{
        display: table-row;
    }
    .deliveryTsf_btn{
        vertical-align: middle;
        display: table-cell;
        text-align: center;
    }
    .delively_addGoods{
        left: 55%;
        position: absolute;
    }
    .delively_addGoods span{
        font-size:16px;
        font-weight: 600;
    }
    .delivelyDelBtn, .delivelyDelBtn:hover, .delivelyDelBtn:active, .delivelyDelBtn:visited, .delivelyDelBtn:focus{
        color: var(--color-error);
    }
    .deliveryPage_wrapper{
        text-align: right;
        vertical-align: middle;
    }
    .deliveryBatch_Del{
        margin-top: 20px;
    }
    .delivelyTsf_footer{
        display: table-row;
        height: 60px;
    }
    .nowrap{white-space: nowrap;}
    .img{
        width: 50px;
        height: 50px;
        display: inline-block;
        vertical-align: middle;
    }

    .link {
        line-height: 16px;
        max-height: 32px;
        max-width: 200px;
        overflow: hidden;
        display: inline-block;
        vertical-align: middle;
        color: var(--color-primary-darken);
        white-space: normal;
        margin-left: 10px;
    }

    .error [class~="el-input__inner"]{
        border-color: var(--color-error);
    }

    .codeSelect [class~="el-input__inner"]{
        width: 60px;
        padding: 10px;
    }
    .codeSelect [class~="el-input__suffix"]{
        right: 0px;
    }
</style>
