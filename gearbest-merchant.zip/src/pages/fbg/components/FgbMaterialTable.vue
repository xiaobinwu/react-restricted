<template>
    <div :class="$style.arrivalGoods">
        <el-table
            v-loading="loading"
            :data="list"
            style="width: 100%">
            <el-table-column
                :label="$t('fbg.arrival.goodTitle')"
                prop="reqNo"
                width="350px"
                align="center">
                <template slot-scope="scope">
                    <img :class="$style.img" :src="scope.row.image_urls[0]" alt="">
                    <span :class="$style.imgSpan" @click="viewGoods">{{ scope.row.title }}</span>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodNo')"
                prop="sku"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodCat')"
                prop="categoryName"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.operate')"
                prop="applicationTime"
                align="center">
                <template slot-scope="scope">
                    <el-button>
                        <router-link :to="{name: 'fgbMaterialView', query: { sku: scope.row.sku }}">{{ $t('fbg.view') }}</router-link>
                    </el-button>
                    <el-button v-if="reviewStatus !== 1">
                        <router-link :to="{name: 'fgbMaterialEdit', query: { sku: scope.row.sku } }">{{ $t('fbg.edit') }}</router-link>
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <div :class="$style.pagination">
            <el-pagination
                :page-sizes="[20, 30, 40, 60]"
                :current-page="pagination.page_index"
                :page-size="pagination.page_size"
                :total="pagination.totalCount"
                align="right"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>
    </div>
</template>

<script>

    import { fbgArrivalProvedGoods, fbgArrivalUnprovedGoods } from '@fbg/services/fbg';

    export default {
        name: 'FgbMaterialTable',
        props: {
            reviewStatus: {
                type: Number,
                default() {
                    return 0;
                }
            }
        },
        data() {
            return {
                loading: false,
                pagination: {
                    page_index: 1,
                    page_size: 20,
                    totalCount: 0,
                },
                list: [],
            };
        },
        inject: ['material'],
        methods: {
            async getData(page, firstview = '') {
                this.loading = true;
                const params = {
                    ...this.pagination,
                    ...this.material.form,
                    review_status: this.reviewStatus,
                    ...(page || {})
                };
                delete params.totalCount;

                const { status, data } = await (params.review_status === 3 ? fbgArrivalProvedGoods : fbgArrivalUnprovedGoods).http({
                    params,
                });
                if (status === 0 && data) {
                    const { list, totalCount } = data;
                    this.list = list;
                    this.pagination.totalCount = totalCount;
                }
                this.$nextTick(() => {
                    this.turnUrl(firstview);
                    this.loading = false;
                });
            },
            handleSizeChange(val) {
                this.pagination.page_size = val;
                this.$nextTick(() => {
                    this.getData();
                });
            },
            handleCurrentChange(val) {
                this.pagination.page_index = val;
                this.$nextTick(() => {
                    this.getData();
                });
            },
            turnUrl(firstview) {
                const { acitveKey, form } = this.material;
                const { title, goodsNo } = form;
                const isFirstView = firstview ? 'replace' : 'push';
                this.$router[isFirstView]({
                    name: 'fgbMaterial',
                    query: {
                        title,
                        goodsNo,
                        acitveKey,
                        page_size: this.pagination.page_size,
                        page_index: this.pagination.page_index,
                        category_id: form.category_id,
                    }
                });
            },
            viewGoods(id) {
                // 跳转到商品模块
                this.$router.gbReplace(id);
            },
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';
    .img {
        position: relative;
        display: inline-block;
        width: 50px;
        height: 50px;
        vertical-align: middle;
    }
    .imgSpan {
        text-align: left;
        vertical-align: middle;
        width: 223px;
        display: inline-block;
        @extend %nowrap;
    }
    .pagination{
        margin-top: 20px;
    }
</style>
