<template>
    <el-dialog
        :visible.sync="visible"
        :before-close="close"
        :title="$t('fbg.selectBarGood')"
        width="50%">
        <el-form :inline="true" :model="form">
            <el-form-item :label="$t('fbg.good')">
                <el-input v-model="form.skus" :placeholder="$t('fbg.placeholder')" type="number"></el-input>
            </el-form-item>
            <el-form-item :label="$t('fbg.platformCat')">
                <category-cascader :category_id="form.category_id" @updateCategory="updateCategory"></category-cascader>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="getFbgGoods">{{ $t('fbg.search') }}</el-button>
            </el-form-item>
        </el-form>
        <el-table
            :class="$style.deliveryTsf_cell"
            :data="list"
            @selection-change="selectionChange">
            <el-table-column
                type="selection"
                width="55">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodTitle')"
                prop="goodsTitle">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodNo')"
                prop="good_sn">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodCat')"
                prop="categoryName">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.inAmount')"
                prop="send_amount">
            </el-table-column>
        </el-table>
        <el-pagination
            v-if="page.totalCount"
            :class="$style.mgt10"
            :total="page.totalCount"
            :page-size="page.pageSize"
            :current-page.sync="page.currentPage"
            layout="total, prev, pager, next"
            align="right"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
        <div :class="$style.btns">
            <el-button type="primary" @click="codeGenerater">{{ $t('fbg.newBarCode') }}</el-button>
            <span :class="$style.mgl20">{{ $t('fbg.barCodeTip') }}</span>
        </div>
        <div v-if="barcodes.length" id="printMe" :class="$style.printMe">
            <div v-for="(item, index) in barcodes"
                 :id="`${item.barcodeValue}_${index}`" :key="index"
                 :class="$style.barcodeWrap" :ref="`barcodes_${item.barcodeValue}`">
                <VueBarcode
                    :id="`barcodes_${index}`"
                    :value="item.barcodeValue"
                    text-position="top"
                    height="30" font-size="16"
                    font-options="bold">barcode generate fails.</VueBarcode>
            </div>
        </div>
        <div slot="footer" :class="[$style.aligncenter, 'dialog-footer']">
            <el-button @click="close">{{ $t('fbg.cancel') }}</el-button>
            <el-button type="primary" @click="codeDownload">{{ $t('fbg.downloadCode') }}</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import VueBarcode from 'vue-barcode';
    import CategoryCascader from '@/components/CategoryCascader';
    import { fbgArrivalGoods } from '@fbg/services/fbg.js';

    const domToImage = () => import('dom-to-image');

    export default {
        name: 'DialogPrintBarCode',
        components: {
            VueBarcode,
            CategoryCascader,
        },
        props: {
            visible: {
                type: Boolean,
                default: false,
            },
            printbarcode: {
                type: String,
                default: '',
            },
        },
        data() {
            return {
                id: '',
                page: {
                    currentPage: 1,
                    pageSize: 10,
                    totalCount: 0,
                },
                form: {
                    skus: '',
                    category_id: '',
                },
                barcodes: [],
                multipleSelection: [],
                list: [],
            };
        },
        methods: {
            close() {
                this.$emit('close');
                this.barcodes = [];
            },
            getGoods(id) {
                this.id = id;
                this.getFbgGoods();
            },
            async getFbgGoods() {
                const vm = this;
                if (!this.id) return;
                const formData = {
                    wid: vm.id,
                    skus: vm.form.skus,
                    category_id: vm.form.category_id,
                    page_index: vm.page.currentPage,
                    page_size: vm.page.pageSize,
                };

                const { status, data } = await fbgArrivalGoods.http({
                    params: formData,
                });

                if (status === 0) {
                    this.list = data.list;
                    this.page.totalCount = data.totalCount;
                }
            },
            handleSizeChange(val) {
                this.page.currentPage = val;
                this.getFbgGoods();
            },
            handleCurrentChange(val) {
                this.page.pageSize = val;
                this.getFbgGoods();
            },
            selectionChange(list) {
                this.multipleSelection = list;
            },
            codeGenerater() {
                this.barcodes = [];
                if (this.multipleSelection.length === 0) {
                    this.$message.error('请先勾选商品');
                } else {
                    this.multipleSelection.forEach((row) => {
                        this.barcodes.push({
                            barcodeValue: row.good_sn,
                            src: '',
                        });
                    });
                }
            },
            updateCategory(data) {
                this.form.category_id = data.category_id;
            },
            async codeDownload() {
                if (this.barcodes.length === 0) {
                    this.$message.error('请先生成条形码');
                } else {
                    const doToImg = await domToImage();
                    const doms = document.getElementById('printMe').children;

                    [...doms].forEach(async (dom) => {
                        const filename = dom.id.split('_')[0];
                        const dataUrl = await doToImg.toPng(document.getElementById(dom.id));
                        const link = document.createElement('a');
                        link.download = filename;
                        link.href = dataUrl;
                        link.click();
                    });
                }
            },
        },
    };
</script>

<style module>
    @import 'variable.css';

    .aligncenter{text-align: center;}
    .alignleft{text-align: left;}
    .btns{
        margin: 30px 0 20px;
    }
    .mgt10{
        margin-top: 10px;
    }
    .mgl20{
        margin-left: 20px;
    }
    .barcodes{
        border: 1px solid var(--border-color-base);
    }

    .img{
        width: 50px;
        height: 50px;
        display: inline-block;
        vertical-align: middle;
    }

    .link {
        line-height: 16px;
        max-height: 32px;
        max-width: 215px;
        overflow: hidden;
        display: inline-block;
        vertical-align: middle;
        color: var(--color-primary-darken);
        margin-left: 10px;
    }

    .barcodeWrap{
        display: inline-block;
        vertical-align: top;
    }

    .printMe{
        height: 85px;
        overflow-x: auto;
        white-space: nowrap;
    }
</style>
