<template>
    <div :class="$style.inventoryPage">
        <div :class="$style.inventoryInfo">
            <div :class="$style.btnBox">
                <el-button class="closePirint" @click="closePirint">{{ $t('fbg.print.close') }}</el-button>
                <el-button @click="inPirint">{{ $t('fbg.print.list') }}</el-button>
            </div>
            <table :class="$style.tableHeard" cellspacing="0" cellpadding="0" border="0">
                <tr>
                    <td colspan="2">
                        <h1>{{ $t('fbg.print.listtitle') }}</h1>
                    </td>
                </tr>
                <tr>
                    <td>
                        <VueBarcode
                            id="barcodes"
                            :value="headData.send_no"
                            text-position="top"
                            height="30" font-size="16"
                            font-options="bold">barcode generate fails.</VueBarcode>
                    </td>
                    <td>
                        <p>{{ $t('fbg.print.listnum') }}：{{ headData.send_no }} </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p>{{ $t('fbg.print.listtype') }}： {{ $t('fbg.print.listtypeval') }}</p>
                        <p>{{ $t('fbg.print.arrivaltime') }}：{{ dateFormat(headData.arrival_date) }} </p>
                    </td>
                    <td>
                        <p>{{ $t('fbg.print.receiving') }}：{{ headData.warehouse }} </p>
                        <p>{{ $t('fbg.print.supplier') }}：{{ headData.shop_name }} </p>
                    </td>
                </tr>
            </table>
            <el-table
                :data="list"
                style="width: 100%"
                border>
                <el-table-column
                    label="序号"
                    type="index"
                    align="center">
                </el-table-column>
                <el-table-column
                    :label="$t('fbg.arrival.goodNo')"
                    prop="good_sn"
                    align="center">
                </el-table-column>
                <el-table-column
                    :label="$t('fbg.arrival.goodTitle')"
                    prop="goodsTitle"
                    width="300"
                    align="center">
                </el-table-column>
                <el-table-column
                    :label="$t('fbg.arrival.actualAmount')"
                    prop="actualAmount"
                    width="120"
                    align="center">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<script>
    import VueBarcode from 'vue-barcode';
    import { dateFormat } from '@/assets/js/utils/date';
    import { warehouseDownload } from '@fbg/services/fbg';
    import { isNotEmptyObject } from '@/assets/js/utils/types';

    export default {
        name: 'InventoryPrint',
        components: {
            VueBarcode,
        },
        props: {
            inventoryList: {
                type: Array,
                default() {
                    return [];
                }
            }
        },
        data() {
            return {
                list: null,
                headData: {},
            };
        },
        watch: {
            inventoryList() {
                this.init();
            }
        },
        created() {
            this.dateFormat = dateFormat;
            this.init();
        },
        methods: {
            async init() {
                this.list = this.inventoryList;
                if (this.list.length > 0 && !isNotEmptyObject(this.headData)) {
                    const { status, data } = await warehouseDownload.http({
                        params: {
                            id: this.list[0].warehouse_id
                        },
                    });
                    if (status === 0) {
                        this.headData = data.info;
                    }
                }
            },
            async inPirint() {
                window.print();
            },
            closePirint() {
                document.querySelector('.previewList').style.display = 'none';
                document.getElementById('app').style.display = 'block';
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    @media print {
        .btnBox{
            display: none;
        }
    }
    .inventoryPage{
        background-color: var(--color-white);
    }
    .inventoryInfo{
        width: var(--layout-safe-width);
        margin: 0 auto;
        padding: 1px 1px 80px;
    }
    .btnBox{
        text-align: right;
        margin: 20px;
    }
    .tableHeard {
        width: 100%;
        border-collapse: collapse;
    }
    .tableHeard td{
        width: 50%;
        border: 1px solid var(--border-color-base);
        padding: 0 10px;
    }
    .tableHeard p{
        margin: 20px 0;
        text-align: left;
    }
    .tableHeard h1{
        margin: 20px 0;
        text-align: center;
    }
</style>
