<template>
    <div :class="$style.container">
        <header :class="$style.header">
            <el-row :gutter="20">
                <el-col :span="8">
                    <el-input v-model="codeValue">
                        <el-select slot="prepend" :class="$style.codeType" v-model="codeType">
                            <el-option label="商品标题" value="TITLE"></el-option>
                            <el-option label="商品编码" value="SKU"></el-option>
                        </el-select>
                    </el-input>
                </el-col>

                <el-col :span="3" :class="$style.searchTitle">
                    发布类目:
                </el-col>
                <el-col :span="6">
                    <el-cascader
                        v-model="categoryId"
                        :options="categoryOptions"
                        :show-all-levels="false"
                        placeholder="产品分类"
                        filterable
                        clearable>
                    </el-cascader>
                </el-col>

                <el-col :span="3">
                    <el-button :class="$style.searchBtn" type="primary" @click="updateTableData">搜索</el-button>
                </el-col>
            </el-row>
        </header>
        <el-table
            :data="tableData"
            max-height="450"
            stripe
            border
        >
            <div slot="empty">暂无数据</div>
            <el-table-column align="center" width="50">
                <el-radio
                    slot-scope="scope"
                    v-model="selectGoodSn"
                    :label="scope.row.variation_id"
                    :class="$style.custom_radio"
                    :disabled="scope.row.isSelected"></el-radio>
            </el-table-column>
            <el-table-column label="商品标题" header-align="center" width="80">
                <img slot-scope="scope" :class="$style.mainImage" :src="scope.row.image_urls[0]">
            </el-table-column>
            <el-table-column prop="title" header-align="center" width="300"></el-table-column>
            <el-table-column prop="variation_id" label="商品编码" align="center" width="200"></el-table-column>
            <el-table-column prop="category_name" label="发布类目" align="center"></el-table-column>
        </el-table>

        <div :class="$style.pagination">
            <el-pagination
                :current-page="pageNo"
                :page-size="pageSize"
                :total="totalCount"
                layout="->, total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>

        <footer :class="$style.btnGroup">
            <el-button :class="$style.btnItem" @click="handleClose">取消</el-button>
            <el-button :class="$style.btnItem" type="primary" @click="handleConfirm">确认</el-button>
        </footer>
    </div>
</template>

<script>
    import { materialsList, categoryTree } from '@fbg/services/fbg';

    export default {
        name: 'AddGoods',
        props: {
            options: {
                type: Object,
                default: () => ({}),
            },
            visible: {
                require: true,
                type: Boolean,
                default: false
            }
        },

        data() {
            return {
                tableData: this.options.tableData || [], // 表格数据
                codeType: 'TITLE', // 当前搜索的编号类型
                codeValue: '', // 当前搜索的编号
                categoryId: [], // 当前搜索的产品分类ID
                categoryOptions: [], // 产品分类选项数据
                pageNo: 1, // 当前页码
                pageSize: 10, // 每页显示商品数量
                totalCount: 0, // 商品总数
                selectGoodSn: this.options.selectGoodSn || ''
            };
        },

        created() {
            this.getCategoryOptions();
            this.updateTableData();
        },

        methods: {
            /**
             * 获取产品类目列表
             */
            async getCategoryOptions() {
                const { status, data } = await categoryTree.http();
                if (status === 0) {
                    this.categoryOptions = this.mapCategoryOptions(data);
                }
            },

            /**
             * 格式化产品类目列表（递归）
             * @param options
             */
            mapCategoryOptions(options = []) {
                return options.map(item => ({
                    value: item.id,
                    label: item.name,
                    children: item.children && item.children.length > 0 ? this.mapCategoryOptions(item.children) : null
                }));
            },

            /**
             * 更新表格数据
             * @return {Promise<void>}
             */
            async updateTableData() {
                console.log(this.categoryId);
                const { data = {} } = await materialsList.http({
                    // 传入筛选条件，外部将根据入参请求商品列表
                    params: {
                        title: this.codeType === 'TITLE' ? this.codeValue : '',
                        variation_ids: this.codeType === 'SKU' ? this.codeValue : '',
                        category_ids: this.categoryId.slice(-1)[0],
                        pageNo: this.pageNo,
                        pageSize: this.pageSize
                    }
                }) || {};


                this.tableData = data.list || [];
                this.totalCount = Number(data.totalCount || 0);
            },

            /**
             * pageSize 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.pageNo = 1;
                this.updateTableData();
            },

            /**
             * pageNo 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.updateTableData();
            },

            /**
             * 关闭操作
             */
            handleClose() {
                this.$emit('update:visible', false);
            },

            /**
             * 确认操作
             */
            handleConfirm() {
                this.$emit('selectGoods', {
                    table: this.tableData,
                    pageNo: this.pageNo,
                    totalCount: this.totalCount,
                    selectGoodSn: this.selectGoodSn,
                });
                this.handleClose();
            },

        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        color: var(--color-black);
    }

    .header {
        margin-bottom: 30px;
    }

    .codeType {
        width: 110px;
    }

    .codeType [class~="el-radio__label"]{
        display: none;
    }

    .priceInput {
        width: 100px;
    }

    .searchBtn {
        width: 100%;
    }

    .priceField {
        white-space: nowrap;
    }

    .splitLine {
        display: inline-block;
        margin: 0 10px;
    }

    .pagination {
        margin-top: 20px;
    }

    .stat {
        float: left;
        line-height: 28px;
    }

    .btnGroup {
        margin-top: 30px;
        text-align: center;
    }

    .btnItem {
        width: 120px;
        margin: 0 10px;
    }

    .mainImage {
        display: block;
        width: 60px;
        height: 60px;
        margin: 7px auto;
    }
    .searchTitle{
        line-height: 40px;
        text-align: right;
    }
    .custom_radio [class~="el-radio__label"]{
        display: none;
    }
</style>
