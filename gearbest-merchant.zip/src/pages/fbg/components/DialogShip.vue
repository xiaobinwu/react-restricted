<template>
    <el-dialog
        :class="$style.ship"
        :visible.sync="visible"
        :before-close="close"
        :title="$t('fbg.deliveryInfo')"
        width="470px">
        <p :class="$style.tip">{{ $t('fbg.deliveryTip') }}</p>
        <el-form
            ref="form"
            :class="$style.form"
            :model="form"
            :rules="rules"
            label-width="150px">
            <el-form-item :label="$t('fbg.mailing')">{{ $t('fbg.arrival.goodCat1') }}</el-form-item>
            <el-form-item :label="$t('fbg.logisticNo')" prop="logistics_no">
                <el-input v-model="form.logistics_no" :class="$style.fromItem"></el-input>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="submit">{{ $t('fbg.update') }}</el-button>
        </span>
    </el-dialog>
</template>

<script>
    import { fbgSendExpress } from '@fbg/services/fbg.js';

    export default {
        name: 'DialogShip',
        props: {
            visible: {
                type: Boolean,
                default: true,
            },
            purchase_sn: {
                type: String,
                default: '',
            },
            purchase_delivery_sn: {
                type: String,
                default: '',
            },
            stock_code: {
                type: String,
                default: '',
            },
        },
        data() {
            return {
                form: {
                    logistics_no: '',
                },
                rules: {
                    logistics_no: [
                        { required: true, message: this.$t('fbg.placeOrderNo'), trigger: 'blur' },
                    ]
                }
            };
        },
        methods: {
            close() {
                this.$refs.form.resetFields();
                this.$emit('close');
            },
            reset() {
                this.form = {
                    logistics_no: '',
                };
            },
            async submit() {
                this.$refs.form.validate(async (valid) => {
                    if (valid) {
                        const { status } = await fbgSendExpress.http({
                            data: {
                                stock_code: this.stock_code,
                                purchase_sn: this.purchase_sn,
                                purchase_delivery_sn: this.purchase_delivery_sn,
                                logistics_no: this.form.logistics_no,
                            },
                        });

                        if (status === 0) {
                            this.close();
                        }
                    }
                });
            },
        },
    };
</script>

<style module>

    .title{
        padding-bottom: 20px;
    }
    .tip{
        color: #666;
        line-height: 24px;
    }
    .form{
        margin-top: 15px;
    }
    .fromItem{
        width: 280px;
    }
</style>
