import router from '@/assets/js/router';
import children from './routes';

// Layout 为布局组件
// 所有的视图挂在它下面
const routes = [{
    path: '/',
    redirect: 'fbg/arrival',
    component: () => import('@/components/Layout'),
    meta: {
        requireAuth: true
    },
    children
}];

export default router({
    routes
});
