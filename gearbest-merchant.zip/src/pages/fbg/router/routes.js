import asyncComponent from '@/assets/js/common/asyncComponent';

export default [{
    path: '/fbg/arrival',
    name: 'fgbArrival',
    meta: {
        title: 'base.menu.fbg.arrival',
    },
    component: () => asyncComponent(import('@fbg/views/arrival/Arrival'))
}, {
    path: '/fbg/arrival-add',
    name: 'fgbArrivalAdd',
    meta: {
        title: 'fbg.title',
    },
    component: () => asyncComponent(import('@fbg/views/arrival/ArrivalAdd'))
}, {
    path: '/fbg/arrival-goods',
    name: 'fgbArrivalGoods',
    meta: {
        title: 'base.menu.fbg.arrival.goods',
    },
    component: () => asyncComponent(import('@fbg/views/arrival/ArrivalGoods'))
}, {
    path: '/fbg/arrival-inventory',
    name: 'fbgArrivalInventory',
    meta: {
        title: 'base.menu.fbg.arrival.goods',
    },
    component: () => asyncComponent(import('@fbg/views/arrival/ArrivalInventory'))
}, {
    path: '/fbg/goodsStock',
    name: 'fgbGoodsStock',
    meta: {
        title: 'base.menu.fbg.stock',
    },
    component: () => asyncComponent(import('@fbg/views/FbgGoodsStock'))
}, {
    path: '/fbg/orders',
    name: 'fgbOrders',
    meta: {
        title: 'base.menu.fbg.order',
    },
    component: () => asyncComponent(import('@fbg/views/FbgOrders'))
}, {
    path: '/fbg/material',
    name: 'fgbMaterial',
    meta: {
        title: 'fbg.title',
    },
    component: () => asyncComponent(import('@fbg/views/material/Material'))
}, {
    path: '/fbg/material-apply',
    name: 'fgbMaterialApply',
    meta: {
        title: 'fbg.title',
    },
    component: () => asyncComponent(import('@fbg/views/material/MaterialApply'))
}, {
    path: '/fbg/material-view',
    name: 'fgbMaterialView',
    meta: {
        title: 'base.menu.fbg.arrival.goods',
    },
    component: () => asyncComponent(import('@fbg/views/material/MaterialView'))
}, {
    path: '/fbg/material-edit',
    name: 'fgbMaterialEdit',
    meta: {
        title: 'base.menu.fbg.arrival.goods',
    },
    component: () => asyncComponent(import('@fbg/views/material/MaterialEdit'))
}];
