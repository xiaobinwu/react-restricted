import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import fbgLang from '@/lang/fbg';
import router from './router';

(async () => {
    const langInstance = await lang({
        local: fbgLang,
        moduleName: 'fbg'
    });
    app({
        lang: langInstance,
        router
    });
})();
