<template>
    <div :class="$style.container">
        <el-form :inline="true" :model="formData" label-suffix="：">
            <el-form-item :label="`${$t('fbg.moveout.goodName')}`">
                <el-input v-model="formData.goodsTitle" :placeholder="$t('fbg.moveout.exactMatch')"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.moveout.orderNo')}`">
                <el-input v-model="formData.orderSns" :placeholder="$t('fbg.moveout.exactMatch')"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.moveout.goodNo')}`">
                <el-input v-model="formData.goodsSn" :placeholder="$t('fbg.moveout.exactMatch')"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.moveout.orderStatus')}`" prop="orders">
                <el-select v-model="formData.orderCombinedStatus">
                    <el-option
                        v-for="(key, value) in orderState"
                        :key="key"
                        :label="key"
                        :value="value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.moveout.orderTime')}`">
                <el-date-picker
                    v-model="filterDate"
                    :start-placeholder="$t('fbg.arrival.startTime')"
                    :end-placeholder="$t('fbg.arrival.endTime')"
                    value-format="timestamp"
                    type="daterange"
                >
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="search">{{ $t('fbg.search') }}</el-button>
            </el-form-item>
        </el-form>
        <el-table
            :data="tableData"
            style="width: 100%">
            <el-table-column
                :label="$t('fbg.moveout.orderMes')"
                prop="order"
                header-align="center">
                <template slot-scope="scope">
                    {{ $t('fbg.moveout.order.createdTime') }}<br>{{ dateFormat(scope.row.createdTime, 'yyyy-MM-dd hh:mm:ss') }}<br><br>
                    {{ $t('fbg.moveout.order.sn') }}<br>{{ scope.row.orderSn }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.material.goodMes')"
                width="300"
                prop="goods"
                align="center">
                <template slot-scope="scope">
                    <div v-for="(goods, index) in scope.row.orderGoodsResp" :key="index" class="goodsList">
                        <div :class="$style.goods">
                            <div :class="[$style.inlineBlock, $style.img]">
                                <img :class="$style.imgs" :src="goods.imgUrl" alt="">
                            </div>
                            <div :class="[$style.inlineBlock, $style.goodsIntro]">
                                <a :href="goods.goodsUrl" :class="$style.link">{{ goods.goodsTitle }}</a>
                                编号: {{ goods.goodsSn }}<br>
                                属性: {{ goods.goodsAttrResp.color }}<br>
                                尺码: {{ goods.goodsAttrResp.size }}<br>
                                单价: {{ goods.price }}<br>
                                数量: {{ goods.qty }}<br>
                            </div>
                        </div>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.moveout.declaredPrice')"
                align="center">
                <template slot-scope="scope">
                    <div v-for="(goods, index) in scope.row.orderGoodsResp" :key="index" class="goodsList">
                        <div :class="$style.goods">{{ goods.declare_price ? `$${goods.declare_price}` : '--' }}</div>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.moveout.orderAmount')"
                prop="orderAmount"
                align="center">
                <template slot-scope="scope">${{ scope.row.orderAmount }}</template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.moveout.orderStatus')"
                align="center">
                <template slot-scope="scope">
                    {{ scope.row.orderStatus === 0 ?
                        $t('fbg.moveout.waitShip') : (scope.row.orderStatus === 5 ?
                    $t('fbg.moveout.refunding') : $t('fbg.moveout.refunded')) }}
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.moveout.shipping')"
                align="center">
                <template slot-scope="scope">{{ scope.row.logisticsWay }}</template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.moveout.receivingCountry')"
                prop="country"
                align="center">
            </el-table-column>
            <el-table-column
                :class="$style.btnWrapper"
                :label="$t('fbg.operate')"
                align="center">
                <template slot-scope="scope">
                    <el-button
                        v-if="scope.row.showDeclareBtn"
                        :class="$style.font14"
                        type="text" size="small"
                        @click="dialogSetDeclaredPrice(scope.row)">{{ $t('fbg.moveout.writeDeclaredPrice') }}</el-button>
                    <span v-else :class="$style.disabled">{{ $t('fbg.moveout.writeDeclaredPrice') }}</span>
                </template>
            </el-table-column>
        </el-table>
        <div :class="$style.pagination">
            <el-pagination
                :current-page="page.pageNo"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="page.pageSize"
                :total="tableData.length"
                align="right"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>
        <el-dialog
            :class="$style.layer"
            :visible.sync="dialogVisible"
            :title="$t('fbg.moveout.writeDeclaredPrice')"
            :before-close="close"
            width="600px">
            <p :class="$style.dialog_item">
                {{ $t('fbg.moveout.orderAmount') }}: <span :class="$style.colorBlack">{{ layerData.orderAmount }}</span>
            </p>
            <p :class="$style.dialog_item">
                {{ $t('fbg.moveout.shipping') }}: <span :class="$style.colorBlack">{{ layerData.logisticsCode }}</span>
            </p>
            <p :class="$style.dialog_item">
                {{ $t('fbg.moveout.receivingCountry') }}: <span :class="$style.colorBlack">{{ layerData.country }}</span>
            </p>
            <ul :class="$style.list">
                <li v-for="(goods, index) in layerData.orderGoodsResp" :key="index" :class="$style.li">
                    <div :class="$style.imgWrap">
                        <img :class="$style.imgs" :src="goods.imgUrl" alt="">
                    </div>
                    <div :class="$style.goodsInfo">
                        <p :class="$style.dialog_item">
                            {{ $t('fbg.moveout.unitPrice') }}: <span :class="$style.colorBlack">${{ goods.price }}</span>
                        </p>
                        <p :class="$style.dialog_item">
                            {{ $t('fbg.moveout.orderAmount') }}: <span :class="$style.colorBlack">${{ layerData.orderAmount }}</span>
                        </p>
                    </div>
                    <div :class="$style.priceWrap">
                        <span :class="$style.colorBlack">{{ $t('fbg.moveout.declaredPrice') }}:</span>
                        <el-input
                            :class="[$style.priceInput, goods.error ? $style.error : '']"
                            v-model="goods.declarePrice" type="number" maxlength="6"
                            @blur="checkNumber(goods)"></el-input>
                        <span :class="$style.unit">{{ $t('fbg.moveout.unit', ['USD']) }}</span>
                    </div>
                </li>
            </ul>
            <span slot="footer" :class="[$style.layerFooter, 'dialog-footer']">
                <el-button type="primary" @click="onSubmit">{{ $t('fbg.update') }}</el-button>
                <p :class="$style.layerTip">{{ $t('fbg.moveout.tip') }}</p>
            </span>
        </el-dialog>
    </div>
</template>

<script>

    import { getOrderList, getAllLogisticsWay } from '@order/services';
    import { fbgOrderDeclarePrice, fbgOrderSaveDeclare } from '@fbg/services/fbg';
    import { dateFormat } from '@/assets/js/utils/date';

    export default {
        name: 'FbgOrders',
        data() {
            return {
                page: {
                    pageNo: 1,
                    pageSize: 10,
                },
                formData: {
                    orderSns: '',
                    goodsSn: '',
                    goodsTitle: '',
                    orderCombinedStatus: '2',
                    deliveryType: 2,
                },
                filterDate: [],
                orderState: {
                    2: this.$t('fbg.moveout.waitShip'),
                    4: this.$t('fbg.moveout.refunding'),
                    6: this.$t('fbg.moveout.refunded'),
                },
                tableData: [],
                dialogVisible: false,
                layerData: {
                    country: '',
                    orderAmount: 0,
                    logisticsCode: '',
                    orderGoodsResp: [],
                },
                inputRules: /^(([1-9]{1}\d*)|(0{1}))(\.\d{1,2})?$/, // 正数保留两位小数
            };
        },
        watch: {
            $route(to, from) {
                this.init();
            }
        },
        created() {
            this.dateFormat = dateFormat;
            this.init();
        },
        methods: {
            init() {
                const now = Math.floor(+new Date() / 1000);
                const before = now - 60 * 60 * 24 * 30;
                this.filterDate = [before, now];
                console.log(this.filterDate);
                const {
                    pageNo,
                    pageSize,
                    createStartTime,
                    createEndtime,
                    ...formData
                } = this.$route.query;
                let params = {};
                params.pageNo = Number(pageNo) || 1;
                params.pageSize = Number(pageSize) || 10;
                params.createStartTime = createStartTime || before;
                params.createEndtime = createEndtime || now;
                params = { ...params, ...this.formData, ...formData };
                this.onSearch(params);
            },
            async onSearch(params) {
                const { status, data } = await getOrderList.http({
                    params
                });

                if (status === 0 && data.list && data.list.length) {

                    const allLogisticsWay = await getAllLogisticsWay.http();

                    if (allLogisticsWay.status === 0) {

                        const orderSns = [];
                        data.list.forEach((orders) => {
                            orders.showDeclareBtn = 0;
                            orders.logisticsWay = '';
                            orderSns.push(orders.orderSn);
                            orders.orderGoodsResp.forEach((goods) => {
                                goods.declare_price = '';
                            });
                        });

                        const response = await fbgOrderDeclarePrice.http({
                            data: { order_sn_list: orderSns }
                        });

                        if (response.status === 0) {
                            data.list.forEach((orders, index) => {
                                const { orderSn } = orders;
                                orders.showDeclareBtn = !response.data[orderSn].status;
                                if (orders.logisticsCode) {
                                    for (const key in response.data) {
                                        const logistics = response.data[key];
                                        if (logistics.logisticsCode === orders.logisticsCode) {
                                            orders.logisticsWay = logistics.cnName;
                                        }
                                    }
                                    if (orders.logisticsWay === '') {
                                        orders.logisticsWay = orders.logisticsCode;
                                    }
                                }

                                orders.orderGoodsResp.forEach((goods) => {
                                    const goodsList = response.data[orderSn];
                                    if (goodsList && goodsList.goods_sn_list && goodsList.goods_sn_list[goods.goodsSn]) {
                                        goods.declare_price = goodsList.goods_sn_list[goods.goodsSn].declare_price;
                                    }
                                });
                            });
                            this.updateSearch(params);
                            this.tableData = data.list;
                        }
                    }

                } else {
                    this.updateSearch(params);
                    this.tableData = [];
                }
            },
            updateSearch(params) {
                const {
                    pageNo,
                    pageSize,
                    createEndtime,
                    createStartTime,
                    ...formData
                } = params;
                this.page.pageNo = pageNo;
                this.page.pageSize = pageSize;
                this.filterDate = [new Date(createStartTime * 1000), new Date(createEndtime * 1000)];
                this.formData = Object.assign({}, this.formData, formData);
            },
            search() {
                this.page.pageNo = 1;
                this.turnUrl();
            },
            handleSizeChange(val) {
                this.page.pageSize = val;
                this.turnUrl();
            },
            handleCurrentChange(val) {
                this.page.pageNo = val;
                this.turnUrl();
            },
            close() {
                this.dialogVisible = false;
            },
            dialogSetDeclaredPrice(row) {
                this.dialogVisible = true;
                const order = JSON.parse(JSON.stringify(row));
                order.orderGoodsResp.forEach((goods) => {
                    goods.error = false;
                });
                Object.assign(this.layerData, order);
            },
            checkNumber(goods) {
                const price = this.inputRules.test(goods.declarePrice);
                if (price && goods.declarePrice > 0) {
                    goods.error = false;
                } else {
                    goods.error = true;
                    this.$message.error('请输入正数, 保留两位小数');
                }
            },
            async onSubmit() {
                let error = false;
                const goodsList = [];
                this.layerData.orderGoodsResp.forEach((goods) => {
                    if (goods.error) {
                        error = true;
                    } else {
                        goodsList.push({
                            goods_sn: goods.goodsSn,
                            declare_price: goods.declarePrice,
                        });
                    }
                });

                if (!error) {
                    const { status } = await fbgOrderSaveDeclare.http({
                        data: {
                            order_sn: this.layerData.orderSn,
                            goods_info_list: goodsList,
                        }
                    });
                    if (status === 0) {
                        this.dialogVisible = false;
                        this.init();
                    }
                }
            },
            // url变化
            turnUrl() {
                const { pageNo, pageSize } = this.page;
                let createStartTime;
                let createEndtime;
                if (this.filterDate && this.filterDate[0]) {
                    createStartTime = this.filterDate[0] / 1000;
                    createEndtime = this.filterDate[1] / 1000;
                }
                this.$router.push({
                    name: 'fgbOrders',
                    query: {
                        pageNo,
                        pageSize,
                        createStartTime,
                        createEndtime,
                        ...this.formData
                    }
                });
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
        padding: 30px 20px;
    }
    .inlineBlock{
        display: inline-block;
        vertical-align: middle;
    }
    .btnWrapper, .layerFooter{
        text-align: center;
    }
    .font14{
        font-size: var(--font-size-base);
    }
    .mgl10{
        margin-left: 10px;
    }
    .tip{
        cursor: pointer;
        color:var(--color-text-secondary);
    }
    .img{
        width: 60px;
        height: 60px;
        overflow: hidden;
    }
    .link{
        display: block;
    }
    .goodsIntro{
        width: 200px;
        text-align: left;
        margin-left: 10px;
    }
    .goods{
        border-top: 1px solid var(--background-color-base);
        &:first-child {
            border-top:0;
        }
    }
    .disabled{
        color: var(--color-text-disable);
    }

    .pagination{
        margin-top: 20px;
    }

    .layerFooter{
        display: block;
    }

    .layer{
        color:var(--color-text-regular);
    }
    .dialog_item{
        line-height: 28px;
    }
    .colorBlack{
        color: var(--color-text-primary);
    }
    .list{
        /* max-height: 500px; */
        overflow: auto;
    }
    .li{padding: 15px 0;
        overflow: hidden;
    }

    .imgWrap, .goodsInfo, .priceWrap{
        float: left;
    }
    .imgWrap{
        width: 60px;
        height: 60px;
        margin-right: 10px;
    }
    .imgs{max-width:100%;}
    .goodsInfo{
        width: 170px;
    }
    .priceWrap{
        width: 320px;
        padding-top: 8px;
    }
    .priceInput{
        width: 120px;
    }
    .unit{
        font-size: 12px;
        margin-left: 10px;
    }
    .error [class~="el-input__inner"]{
        border-color: var(--color-error);
    }
    .layerTip{
        margin-top: 10px;
        color: var(--color-text-secondary);
    }
</style>
