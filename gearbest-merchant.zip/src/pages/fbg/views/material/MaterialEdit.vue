<template>
    <div :class="$style.container">
        <div :class="$style.tabTitle">{{ $t('fbg.material.goodMes') }}</div>
        <div :class="$style.content">
            <el-form ref="form" :model="formData" :rules="rules" autocomplete="true">
                <el-form-item :label="`${$t('fbg.arrival.goodNo')}:`" prop="variation_id" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-input v-model="formData.variation_id" :disabled="true" maxlength="20"></el-input>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.applyCnName')}:`" prop="declare_name_cn" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-input v-model="formData.declare_name_cn" maxlength="100"></el-input>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.applyEnName')}:`" prop="declare_name_en" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-input v-model="formData.declare_name_en" maxlength="100"></el-input>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.customsCode')}:`" prop="custom_sn" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-input v-model="formData.custom_sn" maxlength="150"></el-input>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item
                    :class="$style.margin0"
                    :label="`${$t('fbg.material.selectTpl')}:`"
                    prop="logistics_template_id"
                    label-width="170px"
                    required>
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-select v-model="formData.logistics_template_id">
                                <el-option
                                    v-for="(item, index) in shipModel"
                                    :key="index" :label="item.name"
                                    :value="item.id">
                                </el-option>
                            </el-select>
                        </el-col>
                    </el-row>
                    <p :class="$style.shipModelTip">{{ $t('fbg.material.tip') }}</p>
                </el-form-item>

                <el-form-item :label="`${$t('fbg.material.chargerSpecifications')}:`" prop="charger_spec" label-width="170px">
                    <el-select v-model="formData.charger_spec" :class="$style.fromItem">
                        <el-option
                            v-for="(charger, index) in charger_specs"
                            :key="index" :label="charger.name"
                            :value="charger.id" :disabled="charger.status === 2"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.nature')}:`" required label-width="170px">
                    <el-button @click="dialogVisible=true">{{ $t('fbg.material.addNature') }}</el-button>
                    <p v-show="selectedNatureInfo" :class="$style.choosed">{{ $t('fbg.material.selectAttrs') }}：
                        <span :class="$style.selectedNatureInfo" :title="selectedNatureInfo">{{ selectedNatureInfo }}</span>
                    </p>
                </el-form-item>
                <el-row v-for="(battery, index) in formData.battery_info" :key="index" :class="$style.batteryGroup">
                    <el-form-item :label="`${$t('fbg.material.typeBattery')}:`" prop="battery_type" label-width="170px">
                        <el-input v-if="!battery.battery_type" v-model="battery.battery_type" :style="{ width: '158px' }" maxlength="50"></el-input>
                        <span v-else>{{ battery.battery_type }}</span>
                    </el-form-item>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryVoltage')}:`" prop="battery_voltage" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_voltage" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCurrent')}:`" prop="battery_current" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_current" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryPower')}:`" prop="battery_power" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_power" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <!-- <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryBrand')}:`" prop="battery_brand" label-width="170px">
                            <el-input v-model="battery.battery_brand" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col> -->
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCapacity')}:`" prop="battery_capacity" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_capacity" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <!-- <el-row>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.chargerSpecifications')}:`" prop="charger_spec" label-width="170px">
                            <el-select v-model="formData.charger_spec" :class="$style.fromItem">
                                <el-option
                                    v-for="(charger, index) in charger_specs"
                                    :key="index" :label="charger.name"
                                    :value="charger.id" :disabled="charger.status === 2"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryVoltage')}:`" prop="battery_voltage" label-width="170px">
                            <el-input v-model="formData.battery_voltage" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryIdentification')}:`" prop="battery_identification" label-width="170px">
                            <el-input v-model="formData.battery_identification" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCurrent')}:`" prop="battery_current" label-width="170px">
                            <el-input v-model="formData.battery_current" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.typeBattery')}:`" prop="battery_type" label-width="170px">
                            <el-input v-model="formData.battery_type" :style="{ width: '158px' }" maxlength="50"></el-input>
                            <el-popover
                                :title="$t('fbg.material.standardTitle')"
                                placement="top-start"
                                width="400"
                                trigger="hover">
                                <div v-html="$t('fbg.material.standardContent')"></div>
                                <el-button slot="reference">{{ $t('fbg.material.standardbtn') }}</el-button>
                            </el-popover>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryPower')}:`" prop="battery_power" label-width="170px">
                            <el-input v-model="formData.battery_power" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryBrand')}:`" prop="battery_brand" label-width="170px">
                            <el-input v-model="formData.battery_brand" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCapacity')}:`" prop="battery_capacity" label-width="170px">
                            <el-input v-model="formData.battery_capacity" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row> -->
                <div :class="$style.goodsDetail">
                    <el-form-item :label="`${$t('fbg.arrival.goodTitle')}:`" label-width="120px">{{ formData.title }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productPc')}:`" label-width="120px">
                        <el-row>
                            <el-col v-if="formData.image_urls.length" :span="4">
                                <img :src="formData.image_urls[0]" :style="{width: '90%'}" alt="" />
                            </el-col>
                        </el-row>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productBrand')}:`" label-width="120px">{{ formData.brand_name }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productCat')}:`" label-width="120px">{{ formData.category_name }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.goodWeight')}:`" label-width="120px" prop="package_weight">
                        <el-input
                            v-model="formData.package_weight"
                            :style="{ width: '300px' }"
                            @blur="checkWeight(formData.package_weight)">
                            <template slot="append">KG</template>
                        </el-input>
                        <!-- <span v-else>{{ formData.package_weight }} KG</span>
                        <el-button
                            :style="{ marginLeft: '10px' }"
                            type="text" @click="packageWeightEdit=!packageWeightEdit"
                        >{{ packageWeightEdit ? $t('fbg.cancel') : $t('fbg.edit') }}</el-button> -->
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.goodSize')}:`" label-width="120px">
                        <el-row>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.length') }}
                            </el-col>
                            <el-col :span="3" :class="$style.center">
                                <el-form-item prop="package_length">
                                    <el-input v-model="formData.package_length" @blur="checkNumber(formData.package_length)"></el-input>
                                </el-form-item>
                            </el-col>
                            <!-- <el-col v-else :span="2">
                                {{ formData.package_length }}
                            </el-col> -->
                            <el-col :span="1" :class="$style.center">
                                X
                            </el-col>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.width') }}
                            </el-col>
                            <el-col :span="3" :class="$style.center">
                                <el-form-item prop="package_width">
                                    <el-input v-model="formData.package_width" @blur="checkNumber(formData.package_width)"></el-input>
                                </el-form-item>
                            </el-col>
                            <!-- <el-col v-else :span="2">
                                {{ formData.package_width }}
                            </el-col> -->
                            <el-col :span="1" :class="$style.center">
                                X
                            </el-col>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.height') }}
                            </el-col>
                            <el-col :span="3" :class="$style.center">
                                <el-form-item prop="package_height">
                                    <el-input v-model="formData.package_height" @blur="checkNumber(formData.package_height)"></el-input>
                                </el-form-item>
                            </el-col>
                            <!-- <el-col v-else :span="2">
                                {{ formData.package_height }}
                            </el-col> -->
                            <el-col :span="2" :class="$style.center">
                                cm
                            </el-col>
                            <!-- <el-col :span="3" :class="$style.center">
                                <el-button
                                    type="text"
                                    @click="goodSizeEdit=!goodSizeEdit">{{ goodSizeEdit ? $t('fbg.cancel') : $t('fbg.edit') }}</el-button>
                            </el-col> -->
                        </el-row>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productAttr')}:`" label-width="120px">
                        <div :class="$style.goodsProps">
                            <dl>
                                <dt :class="$style.dt">{{ formData.sku_attributes[0].name }}:</dt>
                                <dd :class="$style.dd">{{ formData.sku_attributes[0].value.name }}</dd>
                            </dl>
                        </div>
                    </el-form-item>
                </div>
                <div :class="$style.formBtns">
                    <el-button :class="$style.middleSize" type="primary" @click="save">{{ $t('fbg.update') }}</el-button>
                    <p :class="$style.warning">{{ $t('fbg.material.tip1') }}</p>
                </div>
            </el-form>
        </div>
        <el-dialog
            :class="$style.layer"
            :visible.sync="dialogVisible"
            :title="$t('fbg.material.pnature')"
            width="880px">
            <el-checkbox-group v-model="formData.nature_id">
                <div v-for="(info, index) in natureInfo" :key="index" :class="$style.layerContent">
                    <div :class="$style.contentTitle">{{ info.group_name }}:</div>
                    <div :class="$style.contentDetail">
                        <el-checkbox
                            v-for="(natureItem, idx) in info.nature_list"
                            :label="String(natureItem.nature_id)"
                            :key="idx"
                        >
                            <span :title="natureItem.nature">{{ natureItem.nature }}</span>
                        </el-checkbox>
                    </div>
                </div>
            </el-checkbox-group>
            <div slot="footer" :class="[$style.center, 'dialog-footer']">
                <el-button @click="dialogVisible=false">{{ $t('fbg.cancel') }}</el-button>
                <el-button type="primary" @click="updateNature">{{ $t('fbg.save') }}</el-button>
            </div>
        </el-dialog>
        <el-dialog
            :visible.sync="successVisible"
            width="560px" center>
            <div :class="$style.successContent">
                <i class="el-icon-success"></i>
                <p>{{ $t('fbg.save.successTip', [formData.variation_id]) }}</p>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="goBackToList">{{ $t('fbg.save.goBackList') }}</el-button>
                <el-button type="primary" @click="continueAdd">{{ $t('fbg.save.continueAdd') }}</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>

    import FgbMaterialTable from '@fbg/components/FgbMaterialTable';
    import { isNotEmptyObject } from '@/assets/js/utils/types';
    import {
        shippingTemplateGet,
        fbgChargerSpec,
        natureInfoGet,
        fbgGetgoods,
        goodsSave,
    } from '@fbg/services/fbg';

    export default {
        components: {
            FgbMaterialTable,
        },
        data() {
            return {
                formData: {
                    variation_id: '',
                    product_id: '',
                    store_id: '',
                    sku: '',
                    declare_name_en: '',
                    declare_name_cn: '',
                    nature_id: [], // 产品性质
                    custom_sn: '',
                    logistics_template_id: '',
                    // 商品信息
                    title: '',
                    image_urls: [],
                    brand_code: '',
                    brand_name: '',
                    category_id: '',
                    category_name: '',
                    package_weight: '',
                    package_length: '',
                    package_width: '',
                    package_height: '',
                    present_price: '',
                    currency_unit: '',
                    sku_attributes: [{
                        name: '',
                        value: {}
                    }], // 商品属性
                    // 电池基本信息
                    charger_spec: null, // 充电器规格
                    // battery_voltage: '', // 电池电压
                    // battery_identification: '', // 电池标识
                    // battery_current: '', // 电池电流
                    // battery_type: '', // 电池类型
                    // battery_power: '', // 电池功率
                    // battery_brand: '', // 电池品牌
                    // battery_capacity: '', // 电池容量
                    battery_info: []
                },
                inputRules: /^(([1-9]{1}\d*)|(0{1}))(\.\d{1,3})?$/, // 正数保留三位小数
                inputWeightRules: /^(([1-9]{1}\d*)|(0{1}))(\.\d{1,4})?$/, // 正数保留四位小数
                filedError: false,
                nature_id_def: [], // 默认产品性质
                battery_info_def: [], // 默认电池信息
                charger_specs: [], // 充电器规格
                packageWeightEdit: false,
                goodSizeEdit: false,
                rules: {
                    variation_id: [
                        { required: true, message: this.$t('fbg.material.placeVariation'), trigger: 'blur' },
                    ],
                    declare_name_en: [
                        { required: true, message: this.$t('fbg.material.placeEn'), trigger: 'blur' },
                    ],
                    declare_name_cn: [
                        { required: true, message: this.$t('fbg.material.placeCn'), trigger: 'blur' },
                    ],
                    custom_sn: [
                        { required: true, message: this.$t('fbg.material.placeCustom'), trigger: 'blur' },
                    ],
                    logistics_template_id: [
                        { required: true, message: this.$t('fbg.material.placeTpl'), trigger: 'blur' },
                    ]
                },
                shipModel: [],
                natureInfo: [],
                natureInfoObj: {},
                selectedNatureInfo: '',
                dialogVisible: false,
                successVisible: false
            };
        },
        // watch: {
        //     natureInfoObj() {
        //         this.updateNature();
        //     }
        // },
        inject: ['reload'],
        created() {
            if (!this.$route.query.sku) {
                this.$router.push({ name: 'fgbMaterialApply' });
            }
        },
        mounted() {
            this.getShippingTemplate();
            this.getChargerSpec();
            this.getDetail();
            this.getNatureInfo();
        },
        methods: {
            // 编辑
            save() {
                if (!this.filedError) {
                    this.$refs.form.validate(async (valid) => {
                        if (valid) {
                            // 电池信息需要组装
                            // const batteryInfo = {
                            //     battery_voltage: this.formData.battery_voltage,
                            //     battery_identification: this.formData.battery_identification,
                            //     battery_current: this.formData.battery_current,
                            //     battery_power: this.formData.battery_power,
                            //     battery_brand: this.formData.battery_brand,
                            //     battery_capacity: this.formData.battery_capacity,
                            //     battery_type: this.formData.battery_type,
                            //     charger_spec: this.formData.charger_spec
                            // };
                            const params = this.formData;
                            const { status } = await goodsSave.http({
                                data: params
                            });
                            if (status === 0) {
                                this.successVisible = true;
                            }
                        } else {
                            console.log('error submit!!');
                        }
                    });
                }
            },
            // 获取运费模板
            async getShippingTemplate() {
                const { status, data } = await shippingTemplateGet.http({
                    params: {
                        type: 3
                    }
                });
                if (status === 0) {
                    this.shipModel = data;
                }
            },
            // 查看所有产品性质组及产品性质接口
            async getNatureInfo() {
                const natureNames = [];
                const { status, data } = await natureInfoGet.http();
                if (status === 0 && data) {
                    this.natureInfo = data;
                    const natureInfoObj = {};
                    data.forEach((item) => {
                        if (item.nature_list) {
                            item.nature_list.forEach((it) => {
                                natureInfoObj[it.nature_id] = it;
                            });
                        }
                    });
                    this.natureInfoObj = natureInfoObj;
                    if (isNotEmptyObject(this.natureInfoObj)) {
                        this.formData.nature_id.forEach((item) => {
                            if (this.natureInfoObj[item]) {
                                natureNames.push(this.natureInfoObj[item].nature);
                            }
                        });
                        this.selectedNatureInfo = natureNames.join(',');
                    }
                }
            },
            // 获取详情
            async getDetail() {
                const { status, data } = await fbgGetgoods.http({
                    params: {
                        sku: this.$route.query.sku
                    }
                });
                if (status === 0 && !Array.isArray(data) && isNotEmptyObject(data)) {
                    const natureIdList = data.nature_id.map(item => item.toString());
                    this.formData = {
                        ...this.formData,
                        sku: data.sku,
                        variation_id: data.variation_id,
                        product_id: data.product_id,
                        store_id: data.store_id,
                        declare_name_en: data.declare_name_en,
                        declare_name_cn: data.declare_name_cn,
                        custom_sn: data.custom_sn,
                        nature_id: natureIdList,
                        logistics_template_id: data.logistics_template_id,
                        title: data.title,
                        image_urls: data.image_urls,
                        present_price: data.present_price,
                        currency_unit: data.currency_unit,
                        brand_code: data.brand_code,
                        category_id: data.category_id,
                        brand_name: data.brand_name,
                        category_name: data.category_name,
                        sku_attributes: data.sku_attributes,
                        package_weight: data.package_weight,
                        package_length: data.package_length,
                        package_width: data.package_width,
                        package_height: data.package_height,
                        charger_spec: +data.charger_spec,
                        battery_info: data.battery_info

                    };
                    this.nature_id_def = data.nature_id;
                    this.battery_info_def = data.battery_info;
                }
            },
            // 产品性质点击
            updateNature() {
                const natureNames = [];
                this.formData.battery_info = [];
                if (isNotEmptyObject(this.natureInfoObj)) {
                    this.formData.nature_id.forEach((item) => {
                        natureNames.push(this.natureInfoObj[item].nature);
                        if (this.natureInfoObj[item].group_id === 2) {
                            if (this.nature_id_def.indexOf(item) >= 0) {
                                const index = this.nature_id_def.indexOf(item);
                                this.formData.battery_info.push(this.battery_info_def[index]);

                            } else {
                                const battery = {
                                    battery_type: this.natureInfoObj[item].type,
                                    battery_info: [{
                                        battery_voltage: '',
                                        battery_current: '',
                                        battery_power: '',
                                        battery_capacity: '',
                                    }]
                                };
                                this.formData.battery_info.push(battery);
                            }
                        }
                    });
                }
                this.selectedNatureInfo = natureNames.join(',');
                this.dialogVisible = false;
            },
            // 充电器规格
            async getChargerSpec() {
                const { status, data } = await fbgChargerSpec.http();
                if (status === 0) {
                    this.charger_specs = [];
                    this.charger_specs = data;
                }
            },

            // 返回列表
            goBackToList() {
                this.$router.push({ name: 'fgbMaterial' });
            },

            // 继续添加
            continueAdd() {
                // 重新渲染当前组件
                this.reload();
            },
            checkNumber(val) {
                const pass = this.inputRules.test(val);
                if (pass && val > 0) {
                    this.filedError = false;
                } else {
                    this.filedError = true;
                    this.$message.error('请输入正数, 保留三位小数');
                }
            },
            checkWeight(val) {
                const pass = this.inputWeightRules.test(val);
                if (pass && val > 0) {
                    this.filedError = false;
                } else {
                    this.filedError = true;
                    this.$message.error('请输入正数, 保留四位小数');
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';
    .container {
        position: relative;
        background-color: var(--color-white);
    }

    .content{padding: 26px 20px 60px;}

    .tabTitle{
        height: 40px;
        line-height: 40px;
        padding-left: 35px;
        position: relative;
        font-size: var(--font-size-largest);
        background: var(--background-color-lighter);
        &:before{
            content: '';
            width: 5px;
            height: 13px;
            border-radius: 3px;
            background: var(--color-primary-darken);
            position: absolute;
            top:50%; left:20px;
            margin-top: -7px;
        }
    }

    .colleft{
        width: 260px;
    }
    .colright{
        width: 450px;
        margin-left: 20px;
    }
    .colrowleft{
        width: 430px;
    }
    .colrowright{
        width: 450px;
        padding-left: 20px;
    }
    .margin0{
        margin-bottom:0;
    }
    .shipModelTip{
        color: var(--color-text-secondary);
        line-height: 20px;
        padding: 10px 0;
    }
    .formBtns{
        text-align: center;
    }
    .middleSize{
        min-width: 120px;
    }
    .warning{
        color: var(--color-error);
        line-height: 40px;
    }
    .choosed{
        line-height: 40px;
        display: inline-block;
        vertical-align: top;
        max-width: 450px;
        margin-left: 20px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .selectedNatureInfo {
        display: inline-block;
        width: 350px;
    }
    .goodsDetail{
        padding: 24px;
        margin-bottom: 30px;
        color: var(--color-black);
        background-color: var(--background-color-light);
    }

    .goodsProps dl{
        overflow: hidden;
    }
    .dt{
        width: 85px;
        float: left;
        text-align: center;
        color: var(--color-text-secondary);
    }
    .dd{
        width: 650px;
        float: left;
    }
    .center{
        text-align: center;
    }
    .layerContent {
        font-size: var(--font-size-base);
        display: flex;
        margin-bottom: 20px;
    }
    .contentTitle {
        text-align: center;
        flex: 1;
    }
    .contentDetail {
        flex: 5;
        :global .el-checkbox {
            width: 25%;
            margin-bottom: 5px;
        }
        :global .el-checkbox+.el-checkbox {
            margin-left: 0;
        }
        :global .el-checkbox__label {
            vertical-align: middle;
            width: 150px;
            @extend %nowrap;
        }
    }
    .successContent {
        width: 362px;
        text-align: center;
        margin: auto;
        line-height: 20px;
    }
    .successContent i {
        font-size: 42px;
        color: var(--color-success);
        margin-bottom: 10px;
    }
    .batteryGroup{
        margin: 20px 0;
        background-color: var(--background-color-base);
        padding-top: 20px;
    }
</style>
