<template>
    <div :class="$style.container">
        <div :class="$style.tabTitle">{{ $t('fbg.material.goodMes') }}</div>
        <div :class="$style.content">
            <el-form ref="login" :model="formData" autocomplete="true">
                <el-form-item :label="`${$t('fbg.arrival.goodNo')}:`" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">{{ formData.variation_id }}</el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.applyCnName')}:`" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">{{ formData.declare_name_cn }}</el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.applyEnName')}:`" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">{{ formData.declare_name_en }}</el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.customsCode')}:`" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">{{ formData.custom_sn }}</el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :class="$style.margin0" :label="`${$t('fbg.material.selectTpl')}:`" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">{{ formData.shipModel.name }}</el-col>
                    </el-row>
                    <p :class="$style.shipModelTip">{{ $t('fbg.material.tip') }}</p>
                </el-form-item>
                <!-- <el-row>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.chargerSpecifications')}:`" label-width="170px">
                            {{ formData.charger_spec }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryVoltage')}:`" label-width="170px">
                            {{ formData.battery_info.battery_voltage }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryIdentification')}:`" label-width="170px">
                            {{ formData.battery_info.battery_identification }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCurrent')}:`" label-width="170px">
                            {{ formData.battery_info.battery_current }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.typeBattery')}:`" label-width="170px">
                            {{ formData.battery_info.battery_type }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryPower')}:`" label-width="170px">
                            {{ formData.battery_info.battery_power }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryBrand')}:`" label-width="170px">
                            {{ formData.battery_info.battery_brand }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCapacity')}:`" label-width="170px">
                            {{ formData.battery_info.battery_capacity }}
                        </el-form-item>
                    </el-col>
                </el-row> -->


                <el-form-item :label="`${$t('fbg.material.chargerSpecifications')}:`" label-width="170px">
                    {{ charger_specs_name }}
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.nature')}:`" required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">{{ natureNames.join(',') }}</el-col>
                    </el-row>
                </el-form-item>
                <el-row v-for="(battery, index) in formData.battery_info" :key="index" :class="$style.batteryGroup">
                    <el-form-item :label="`${$t('fbg.material.typeBattery')}:`" prop="battery_type" label-width="170px">
                        {{ battery.battery_type }}
                    </el-form-item>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryVoltage')}:`" label-width="170px">
                            {{ battery.battery_info[0].battery_voltage }}
                        </el-form-item>
                    </el-col>

                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCurrent')}:`" label-width="170px">
                            {{ battery.battery_info[0].battery_current }}
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryPower')}:`" label-width="170px">
                            {{ battery.battery_info[0].battery_power }}
                        </el-form-item>
                    </el-col>

                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCapacity')}:`" label-width="170px">
                            {{ battery.battery_info[0].battery_capacity }}
                        </el-form-item>
                    </el-col>
                </el-row>

                <div :class="$style.goodsDetail">
                    <el-form-item :label="`${$t('fbg.arrival.goodTitle')}:`" label-width="120px">{{ formData.title }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productPc')}:`" label-width="120px">
                        <el-row>
                            <el-col v-if="formData.image_urls.length" :span="4">
                                <img :src="formData.image_urls[0]" :style="{width: '90%'}" alt="" />
                            </el-col>
                        </el-row>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productBrand')}:`" label-width="120px">{{ formData.brand_name }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productCat')}:`" label-width="120px">{{ formData.category_name }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.goodWeight')}:`" label-width="120px" prop="package_weight">
                        <span>{{ formData.package_weight }} KG</span>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.goodSize')}:`" label-width="120px">
                        <el-row>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.length') }}
                            </el-col>
                            <el-col :span="2">
                                {{ formData.package_length }}
                            </el-col>
                            <el-col :span="1" :class="$style.center">
                                X
                            </el-col>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.width') }}
                            </el-col>
                            <el-col :span="2">
                                {{ formData.package_width }}
                            </el-col>
                            <el-col :span="1" :class="$style.center">
                                X
                            </el-col>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.height') }}
                            </el-col>
                            <el-col :span="2">
                                {{ formData.package_height }}
                            </el-col>
                            <el-col :span="2" :class="$style.center">
                                cm
                            </el-col>
                        </el-row>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productAttr')}:`" label-width="120px">
                        <div>
                            <dl>
                                <dt :class="$style.dt">{{ formData.sku_attributes[0].name }}:</dt>
                                <dd :class="$style.dd">{{ formData.sku_attributes[0].value.name }}</dd>
                            </dl>
                        </div>
                    </el-form-item>
                </div>
            </el-form>
        </div>
    </div>
</template>

<script>

    import {
        fbgGetgoods,
        shippingTemplateGet,
        fbgChargerSpec,
        natureInfoGet
    } from '@fbg/services/fbg';
    import FgbMaterialTable from '@fbg/components/FgbMaterialTable';
    import { isNotEmptyObject } from '@/assets/js/utils/types';

    export default {
        components: {
            FgbMaterialTable,
        },
        data() {
            return {
                formData: {
                    variation_id: '',
                    product_id: '',
                    store_id: '',
                    sku: '',
                    declare_name_en: '',
                    declare_name_cn: '',
                    nature_id: [], // 产品性质
                    custom_sn: '',
                    logisticsTempName: '',
                    logistics_template_id: '',
                    // 商品信息
                    title: '',
                    image_urls: [],
                    brand_code: '',
                    brand_name: '',
                    category_id: '',
                    category_name: '',
                    package_weight: '',
                    package_length: '',
                    package_width: '',
                    package_height: '',
                    present_price: '',
                    currency_unit: '',
                    sku_attributes: [{
                        name: '',
                        value: {}
                    }], // 商品属性
                    // 电池基本信息
                    battery_info: [],
                    charger_spec: '', // 充电器规格
                    shipModel: {},
                },
                charger_specs_name: '',
                natureInfoObj: {},
                natureNames: []
            };
        },
        async created() {
            await this.getGoods();
            this.getChargerSpec();
            this.getNatureInfo();
        },
        methods: {
            // 获取运费模板
            async getShippingTemplate() {
                const { status, data } = await shippingTemplateGet.http();
                if (status === 0) {
                    this.formData.shipModel = data.find(temp => temp.id === this.formData.logistics_template_id);
                }
            },
            async getGoods() {
                const { sku } = this.$route.query;
                if (sku) {
                    const { status, data } = await fbgGetgoods.http({
                        params: { sku },
                    });
                    if (status === 0 && !Array.isArray(data) && isNotEmptyObject(data)) {
                        Object.assign(this.formData, data);
                        this.getShippingTemplate();
                    }
                }
            },

            // 充电器规格
            async getChargerSpec() {
                const { status, data } = await fbgChargerSpec.http();
                if (status === 0) {
                    data.forEach((item) => {
                        if (item.id === this.formData.charger_spec) {
                            this.charger_specs_name = item.name;
                        }
                    });
                }
            },

            // 查看所有产品性质组及产品性质接口
            async getNatureInfo() {
                const { status, data } = await natureInfoGet.http();
                if (status === 0 && data) {
                    this.natureInfo = data;
                    const natureInfoObj = {};
                    data.forEach((item) => {
                        if (item.nature_list) {
                            item.nature_list.forEach((it) => {
                                natureInfoObj[it.nature_id] = it.nature;
                            });
                        }
                    });
                    this.natureInfoObj = natureInfoObj;
                    if (isNotEmptyObject(this.natureInfoObj)) {
                        this.formData.nature_id.forEach((item) => {
                            this.natureNames.push(this.natureInfoObj[item]);
                        });
                    }
                }
            },

        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
    }

    .content{padding: 26px 20px 60px;}

    .tabTitle{
        height: 40px;
        line-height: 40px;
        padding-left: 35px;
        position: relative;
        font-size: var(--font-size-largest);
        background: var(--background-color-lighter);
        &:before{
            content: '';
            width: 5px;
            height: 13px;
            border-radius: 3px;
            background: var(--color-primary-darken);
            position: absolute;
            top:50%; left:20px;
            margin-top: -7px;
        }
    }

    .colleft{
        width: 260px;
    }
    .colright{
        width: 450px;
        margin-left: 20px;
    }
    .colrowleft{
        width: 430px;
    }
    .colrowright{
        width: 450px;
        padding-left: 20px;
    }
    .margin0{
        margin-bottom:0;
    }
    .shipModelTip{
        color: var(--color-text-secondary);
        line-height: 20px;
        padding: 10px 0;
    }
    .formBtns{
        text-align: center;
    }
    .middleSize{
        min-width: 120px;
    }
    .warning{
        color: var(--color-error);
        line-height: 40px;
    }
    .choosed{
        line-height: 40px;
        display: inline-block;
        vertical-align: top;
        max-width: 450px;
        margin-left: 20px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .goodsDetail{
        padding: 24px;
        margin-bottom: 30px;
        color: var(--color-black);
        background-color: var(--background-color-light);
    }

    .goodsDetail [class~="el-form-item"] {
        margin-bottom: 0;
    }
    .goodsProps{
        line-height: 30px;
        padding-top: 30px;
        dl{overflow: hidden;}
    }
    .dt{
        width: 85px;
        float: left;
        color: var(--color-text-secondary);
    }
    .dd{
        width: 600px;
        float: left;
    }
    .center{
        text-align: center;
    }
</style>
