<template>
    <div :class="$style.container">
        <el-form :inline="true" :model="form" :class="$style.marginb20" label-suffix="：">
            <el-form-item :label="`${$t('fbg.arrival.goodTitle')}`">
                <el-input :class="$style.formInline" v-model="form.title" :placeholder="$t('fbg.arrival.match')" maxlength="100"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodNo')}`">
                <el-input :class="$style.formInline" v-model="form.goodsNo" maxlength="30"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodCat')}`">
                <category-cascader :category_id="form.category_id" @updateCategory="updateCategory"></category-cascader>
            </el-form-item>
            <el-button type="primary" @click="onSearch">{{ $t('fbg.search') }}</el-button>
            <el-form-item :class="$style.addBtn">
                <router-link :to="{name: 'fgbMaterialApply'}"><el-button>{{ $t('fbg.material.inMaterial') }}</el-button></router-link>
            </el-form-item>
        </el-form>
        <el-tabs v-model="acitveKey" type="border-card" @tab-click="handleClick">
            <el-tab-pane :label="$t('fbg.material.passed')" name="passed">
                <FgbMaterialTable ref="passed" :review-status="3"></FgbMaterialTable>
            </el-tab-pane>
            <el-tab-pane :label="$t('fbg.material.passeing')" name="passeing">
                <FgbMaterialTable ref="passeing" :review-status="1"></FgbMaterialTable>
            </el-tab-pane>
            <el-tab-pane :label="$t('fbg.material.unpass')" name="unpass">
                <FgbMaterialTable ref="unpass" :review-status="2"></FgbMaterialTable>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>

    import CategoryCascader from '@/components/CategoryCascader';
    import FgbMaterialTable from '@fbg/components/FgbMaterialTable';

    export default {
        name: 'Material',
        components: {
            CategoryCascader,
            FgbMaterialTable,
        },
        data() {
            return {
                params: {
                    product_id: '',
                    categoryId: '',
                    review_type: ''
                },
                form: {
                    title: '',
                    goodsNo: '',
                    category_id: '',
                },
                acitveKey: 'passed'
            };
        },
        provide() {
            return {
                material: this
            };
        },
        mounted() {
            this.init();
        },
        methods: {
            init() {
                const {
                    title,
                    goodsNo,
                    acitveKey
                } = this.$route.query;
                const query = this.$route.query;
                Object.assign(this.form, {
                    title,
                    goodsNo,
                });

                if (acitveKey) {
                    this.acitveKey = acitveKey;
                    if (this.$refs[acitveKey] && query.page_index && query.page_size) {
                        this.$refs[acitveKey].getData({ page_index: query.page_index, page_size: query.page_size });
                    }
                } else {
                    this.$refs[this.acitveKey].getData({}, 'firstview');
                }
            },
            updateCategory(data) {
                this.form.category_id = data.category_id;
            },
            onSearch(data) {
                this.$refs[this.acitveKey].getData();
            },
            handleClick(tab) {
                this.$refs[tab.name].getData();
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
        padding: 20px;
    }

    .marginb20{
        margin-bottom: 20px;
    }

    .addBtn{
        display: block !important;
        margin:20px 0 0 !important;
        text-align: right;
    }

</style>
