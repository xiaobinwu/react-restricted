<template>
    <div :class="$style.container">
        <div :class="$style.tabTitle">{{ $t('fbg.material.goodMes') }}</div>
        <div :class="$style.content">
            <el-form ref="form" :model="formData" :rules="rules" autocomplete="true">
                <el-form-item :label="`${$t('fbg.arrival.goodNo')}:`" prop="variation_id" label-width="170px">
                    <el-row>
                        <el-col v-show="formData.variation_id" :span="5">
                            <!-- <el-input v-model="formData.variation_id" maxlength="20"></el-input> -->
                            <span>{{ formData.variation_id }}</span>
                        </el-col>
                        <el-col :class="[$style.colright, $style.nodeMagin]">
                            <el-button @click="goodsVisible = !goodsVisible">{{ $t('fbg.material.connectGood') }}</el-button>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.applyCnName')}:`" prop="declare_name_cn" label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-input v-model="formData.declare_name_cn" maxlength="100"></el-input>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.applyEnName')}:`" prop="declare_name_en" label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-input v-model="formData.declare_name_en" maxlength="100"></el-input>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.customsCode')}:`" prop="custom_sn" label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-input v-model="formData.custom_sn" maxlength="150"></el-input>
                        </el-col>
                        <el-col :class="$style.colright">
                            <el-popover
                                :content="$t('fbg.material.customscodedownloadtip')"
                                placement="top-start"
                                width="400"
                                trigger="hover">
                                <a
                                    slot="reference"
                                    :class="$style.block"
                                    :href="`${getAssistPath('customs-code-reference-form.csv')}`"
                                    class="el-button"
                                    download="customs-code-reference-form.csv">{{ $t('fbg.material.customsCodeDownload') }}</a>
                            </el-popover>
                        </el-col>
                    </el-row>
                </el-form-item>
                <el-form-item
                    :class="$style.margin0"
                    :label="`${$t('fbg.material.selectTpl')}:`"
                    prop="logistics_template_id"
                    required label-width="170px">
                    <el-row>
                        <el-col :class="$style.colleft">
                            <el-select v-model="formData.logistics_template_id">
                                <el-option
                                    v-for="(item, index) in shipModel"
                                    :key="index"
                                    :label="item.name"
                                    :value="item.id">
                                </el-option>
                            </el-select>
                        </el-col>
                    </el-row>
                    <p :class="$style.shipModelTip">{{ $t('fbg.material.tip') }}</p>
                </el-form-item>
                <el-form-item :label="`${$t('fbg.material.chargerSpecifications')}:`" prop="charger_spec" label-width="170px">
                    <el-select v-model="formData.charger_spec" :class="$style.fromItem">
                        <el-option
                            v-for="(charger, index) in charger_specs"
                            :key="index" :label="charger.name"
                            :value="charger.id" :disabled="charger.status === 2"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item :label="`${$t('fbg.material.nature')}:`" prop="selectedNatureInfo" required label-width="170px">
                    <el-button @click="dialogVisible=true">{{ $t('fbg.material.addNature') }}</el-button>
                    <p v-show="formData.selectedNatureInfo" :class="$style.choosed">{{ $t('fbg.material.selectAttrs') }}：
                        <span :class="$style.selectedNatureInfo" :title="formData.selectedNatureInfo">{{ formData.selectedNatureInfo }}</span>
                    </p>
                </el-form-item>
                <el-row v-for="(battery, index) in formData.battery_info" :key="index" :class="$style.batteryGroup">
                    <el-form-item :label="`${$t('fbg.material.typeBattery')}:`" prop="battery_type" label-width="170px">
                        <el-input
                            v-if="!battery.battery_type_empty"
                            v-model="battery.battery_type"
                            :style="{ width: '260px' }"
                            maxlength="50"></el-input>
                        <span v-else>{{ battery.battery_type }}</span>
                    </el-form-item>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryVoltage')}:`" prop="battery_voltage" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_voltage" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCurrent')}:`" prop="battery_current" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_current" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowleft">
                        <el-form-item :label="`${$t('fbg.material.batteryPower')}:`" prop="battery_power" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_power" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :class="$style.colrowright">
                        <el-form-item :label="`${$t('fbg.material.batteryCapacity')}:`" prop="battery_capacity" label-width="170px">
                            <el-input v-model="battery.battery_info[0].battery_capacity" maxlength="50"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <div v-show="goodsDetail" :class="$style.goodsDetail">
                    <el-form-item :label="`${$t('fbg.arrival.goodTitle')}:`" label-width="120px">{{ formData.title }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productPc')}:`" label-width="120px">
                        <el-row>
                            <el-col v-if="formData.image_urls.length" :span="4">
                                <img :src="formData.image_urls[0]" :style="{width: '90%'}" alt="" />
                            </el-col>
                        </el-row>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productBrand')}:`" label-width="120px">{{ formData.brand_name }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productCat')}:`" label-width="120px">{{ formData.category_name }}</el-form-item>
                    <el-form-item :label="`${$t('fbg.material.goodWeight')}:`" label-width="120px" prop="package_weight">
                        <el-input
                            v-if="packageWeightEdit" v-model="formData.package_weight"
                            :style="{ width: '300px' }"
                            @blur="checkWeight(formData.package_weight)">
                            <template slot="append">KG</template>
                        </el-input>
                        <span v-else>{{ formData.package_weight }} KG</span>
                        <el-button
                            :style="{ marginLeft: '10px' }" type="text"
                            @click="packageWeightEdit=!packageWeightEdit">{{ packageWeightEdit ? $t('fbg.cancel') : $t('fbg.edit') }}</el-button>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.goodSize')}:`" label-width="120px">
                        <el-row>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.length') }}
                            </el-col>
                            <el-col v-if="goodSizeEdit" :span="3" :class="$style.center">
                                <el-form-item prop="package_length">
                                    <el-input v-model="formData.package_length" @blur="checkNumber(formData.package_length)"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col v-else :span="2">
                                {{ formData.package_length }}
                            </el-col>
                            <el-col :span="1" :class="$style.center">X</el-col>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.width') }}
                            </el-col>
                            <el-col v-if="goodSizeEdit" :span="3" :class="$style.center">
                                <el-form-item prop="package_width">
                                    <el-input v-model="formData.package_width" @blur="checkNumber(formData.package_width)"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col v-else :span="2">
                                {{ formData.package_width }}
                            </el-col>
                            <el-col :span="1" :class="$style.center">
                                X
                            </el-col>
                            <el-col :span="2" :class="$style.center">
                                {{ $t('fbg.material.height') }}
                            </el-col>
                            <el-col v-if="goodSizeEdit" :span="3" :class="$style.center">
                                <el-form-item prop="package_height">
                                    <el-input v-model="formData.package_height" @blur="checkNumber(formData.package_height)"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col v-else :span="2">
                                {{ formData.package_height }}
                            </el-col>
                            <el-col :span="2" :class="$style.center">
                                cm
                            </el-col>
                            <el-col :span="3" :class="$style.center">
                                <el-button
                                    type="text"
                                    @click="goodSizeEdit=!goodSizeEdit"
                                >{{ goodSizeEdit ? $t('fbg.cancel') : $t('fbg.edit') }}</el-button>
                            </el-col>
                        </el-row>
                    </el-form-item>
                    <el-form-item :label="`${$t('fbg.material.productAttr')}:`" label-width="120px">
                        <div :class="$style.goodsProps">
                            <dl v-for="(attr, index) in formData.sku_attributes" :key="index">
                                <dt :class="$style.dt">{{ attr.name }}:</dt>
                                <dd :class="$style.dd">{{ attr.value.name }}</dd>
                            </dl>
                        </div>
                    </el-form-item>
                </div>
                <div :class="$style.formBtns">
                    <el-button :class="$style.middleSize" type="primary" @click="add">{{ $t('fbg.update') }}</el-button>
                    <p :class="$style.warning">{{ $t('fbg.material.tip1') }}</p>
                </div>
            </el-form>
        </div>
        <el-dialog
            :class="$style.layer"
            :visible.sync="dialogVisible"
            :title="$t('fbg.material.pnature')"
            width="880px">
            <el-checkbox-group v-model="formData.nature_id">
                <div v-for="(info, index) in natureInfo" :key="index" :class="$style.layerContent">
                    <div :class="$style.contentTitle">{{ info.group_name }}:</div>
                    <div :class="$style.contentDetail">
                        <el-checkbox
                            v-for="(natureItem, idx) in info.nature_list"
                            :label="natureItem.nature_id" :key="idx">
                            <span :title="natureItem.nature">{{ natureItem.nature }}</span>
                        </el-checkbox>
                    </div>
                </div>
            </el-checkbox-group>
            <div slot="footer" :class="[$style.center, 'dialog-footer']">
                <el-button @click="dialogVisible=false">{{ $t('fbg.cancel') }}</el-button>
                <el-button type="primary" @click="saveNature">{{ $t('fbg.save') }}</el-button>
            </div>
        </el-dialog>
        <el-dialog
            :visible.sync="successVisible"
            width="560px" center>
            <div :class="$style.successContent">
                <i class="el-icon-success"></i>
                <p>{{ $t('fbg.save.successTip', [formData.variation_id]) }}</p>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="goBackToList">{{ $t('fbg.save.goBackList') }}</el-button>
                <el-button type="primary" @click="continueAdd">{{ $t('fbg.save.continueAdd') }}</el-button>
            </span>
        </el-dialog>

        <el-dialog
            :visible.sync="goodsVisible"
            width="1100px" center>
            <add-goods :options="goodsOptions" :visible.sync="goodsVisible" @selectGoods="getGoodDetail"></add-goods>
        </el-dialog>

    </div>
</template>

<script>

    import FgbMaterialTable from '@fbg/components/FgbMaterialTable';
    import { isNotEmptyObject } from '@/assets/js/utils/types';
    import { getAssistPath } from '@/assets/js/utils/assist';
    import AddGoods from '@fbg/components/AddGoods';
    import {
        shippingTemplateGet,
        fbgChargerSpec,
        natureInfoGet,
        whGoodGet,
        goodsAdd
    } from '@fbg/services/fbg';

    export default {
        components: {
            FgbMaterialTable,
            AddGoods
        },
        data() {
            return {
                getAssistPath,
                formData: {
                    variation_id: '',
                    declare_name_en: '',
                    declare_name_cn: '',
                    nature_id: [], // 产品性质
                    custom_sn: '',
                    logistics_template_id: '',
                    // 商品信息
                    title: '',
                    image_urls: [],
                    brand_code: '',
                    brand_name: '',
                    category_id: '',
                    category_name: '',
                    package_weight: '',
                    package_length: '',
                    package_width: '',
                    package_height: '',
                    present_price: '',
                    currency_unit: '',
                    selectedNatureInfo: '',
                    sku_attributes: [], // 商品属性
                    // 电池基本信息
                    charger_spec: null, // 充电器规格
                    // battery_voltage: '', // 电池电压
                    // battery_identification: '', // 电池标识
                    // battery_current: '', // 电池电流
                    // battery_type: '', // 电池类型
                    // battery_power: '', // 电池功率
                    // battery_brand: '', // 电池品牌
                    // battery_capacity: '', // 电池容量
                    battery_info: []
                },
                charger_specs: [], // 充电器规格
                packageWeightEdit: false,
                goodSizeEdit: false,
                rules: {
                    variation_id: [
                        { required: true, message: this.$t('fbg.material.placeVariation'), trigger: 'blur' },
                    ],
                    declare_name_en: [
                        { required: true, message: this.$t('fbg.material.placeEn'), trigger: 'blur' },
                    ],
                    declare_name_cn: [
                        { required: true, message: this.$t('fbg.material.placeCn'), trigger: 'blur' },
                    ],
                    custom_sn: [
                        { required: true, message: this.$t('fbg.material.placeCustom'), trigger: 'blur' },
                    ],
                    selectedNatureInfo: [
                        { required: true, message: this.$t('fbg.material.placeNature'), trigger: 'blur' },
                    ],
                    logistics_template_id: [
                        { required: true, message: this.$t('fbg.material.placeTpl'), trigger: 'blur' },
                    ]
                },
                inputRules: /^(([1-9]{1}\d*)|(0{1}))(\.\d{1,3})?$/, // 正数保留三位小数
                inputWeightRules: /^(([1-9]{1}\d*)|(0{1}))(\.\d{1,4})?$/, // 正数保留四位小数
                filedError: false,
                shipModel: [],
                natureInfo: [],
                natureInfoObj: {},
                dialogVisible: false,
                successVisible: false,
                goodsDetail: false,
                goodsVisible: false,
                goodsOptions: {}
            };
        },
        inject: ['reload'],
        mounted() {
            this.getNatureInfo();
            this.getChargerSpec();
            this.getShippingTemplate();
        },
        methods: {
            // 新增
            add() {
                if (!this.filedError) {
                    this.$refs.form.validate(async (valid) => {
                        if (valid) {
                            // 电池信息需要组装
                            const params = this.formData;
                            const { status } = await goodsAdd.http({
                                data: params
                            });
                            if (status === 0) {
                                this.successVisible = true;
                            }
                        } else {
                            console.log('error submit!!');
                        }
                    });
                }
            },
            // 获取运费模板
            async getShippingTemplate() {
                const { status, data } = await shippingTemplateGet.http({
                    params: {
                        type: 3
                    }
                });
                if (status === 0) {
                    this.shipModel = data;
                }
            },
            // 查看所有产品性质组及产品性质接口
            async getNatureInfo() {
                const { status, data } = await natureInfoGet.http();
                if (status === 0 && data) {
                    this.natureInfo = data;
                    const natureInfoObj = {};
                    data.forEach((item) => {
                        if (item.nature_list) {
                            item.nature_list.forEach((it) => {
                                natureInfoObj[it.nature_id] = it;
                            });
                        }
                    });
                    this.natureInfoObj = natureInfoObj;
                }
            },

            // 获取商品详细信息
            async getGoodDetail(val) {
                this.goodsOptions = { ...val };
                this.formData.variation_id = val.selectGoodSn;
                const { status, data } = await whGoodGet.http({
                    params: {
                        sku: this.formData.variation_id
                    }
                });
                if (status === 0 && !Array.isArray(data) && isNotEmptyObject(data)) {
                    this.formData = {
                        ...this.formData,
                        title: data.title,
                        image_urls: data.image_urls,
                        brand_code: data.brand_code,
                        category_id: data.category_id,
                        brand_name: data.brand_info.name_en,
                        category_name: data.category_path.name_path,
                        sku_attributes: data.sku_attributes,
                        present_price: data.present_price,
                        currency_unit: data.currency_unit,
                        package_weight: data.logistics_info.package_weight,
                        package_length: data.logistics_info.package_length,
                        package_width: data.logistics_info.package_width,
                        package_height: data.logistics_info.package_height,
                    };
                    this.goodsDetail = true;
                }
            },
            // 产品性点击保存
            saveNature() {
                const natureNames = [];
                this.formData.battery_info = [];
                if (isNotEmptyObject(this.natureInfoObj)) {
                    this.formData.nature_id.forEach((item) => {
                        if (this.natureInfoObj[item]) {
                            natureNames.push(this.natureInfoObj[item].nature);
                        }
                        if (this.natureInfoObj[item].group_id === 2) {
                            const battery = {
                                battery_type: this.natureInfoObj[item].type,
                                battery_type_empty: this.natureInfoObj[item].type,
                                battery_info: [{
                                    battery_voltage: '',
                                    battery_current: '',
                                    battery_power: '',
                                    battery_capacity: '',
                                }]
                            };
                            this.formData.battery_info.push(battery);
                        }
                    });
                }
                this.formData.selectedNatureInfo = natureNames.join(',');
                this.dialogVisible = false;
            },
            // 充电器规格
            async getChargerSpec() {
                const { status, data } = await fbgChargerSpec.http();
                if (status === 0) {
                    this.charger_specs = [];
                    this.charger_specs = data;
                }
            },
            // 返回列表
            goBackToList() {
                this.$router.push({ name: 'fgbMaterial' });
            },

            // 继续添加
            continueAdd() {
                // 重新渲染当前组件
                this.reload();
            },
            checkNumber(val) {
                const pass = this.inputRules.test(val);
                if (pass && val > 0) {
                    this.filedError = false;
                } else {
                    this.filedError = true;
                    this.$message.error('请输入正数, 保留三位小数');
                }
            },
            checkWeight(val) {
                const pass = this.inputWeightRules.test(val);
                if (pass && val > 0) {
                    this.filedError = false;
                } else {
                    this.filedError = true;
                    this.$message.error('请输入正数, 保留四位小数');
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';
    .container {
        position: relative;
        background-color: var(--color-white);
    }

    .content{padding: 26px 20px 60px;}

    .tabTitle{
        height: 40px;
        line-height: 40px;
        padding-left: 35px;
        position: relative;
        font-size: var(--font-size-largest);
        background: var(--background-color-lighter);
        &:before{
            content: '';
            width: 5px;
            height: 13px;
            border-radius: 3px;
            background: var(--color-primary-darken);
            position: absolute;
            top:50%; left:20px;
            margin-top: -7px;
        }
    }

    .colleft{
        width: 260px;
    }
    .colright{
        width: 450px;
        margin-left: 20px;
    }
    .colrowleft{
        width: 430px;
    }
    .colrowright{
        width: 450px;
        padding-left: 20px;
    }
    .margin0{
        margin-bottom:0;
    }
    .shipModelTip{
        color: var(--color-text-secondary);
        line-height: 20px;
        padding: 10px 0;
    }
    .formBtns{
        text-align: center;
    }
    .middleSize{
        min-width: 120px;
    }
    .warning{
        color: var(--color-error);
        line-height: 40px;
    }
    .choosed{
        line-height: 40px;
        display: inline-block;
        vertical-align: top;
        max-width: 450px;
        margin-left: 20px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .selectedNatureInfo {
        display: inline-block;
        width: 350px;
    }
    .goodsDetail{
        padding: 24px;
        margin-bottom: 30px;
        color: var(--color-black);
        background-color: var(--background-color-light);
    }

    .goodsProps dl{
        overflow: hidden;
    }
    .dt{
        width: 85px;
        float: left;
        text-align: center;
        color: var(--color-text-secondary);
    }
    .dd{
        width: 650px;
        float: left;
    }
    .center{
        text-align: center;
    }
    .layerContent {
        font-size: var(--font-size-base);
        display: flex;
        margin-bottom: 20px;
    }
    .contentTitle {
        text-align: center;
        flex: 1;
    }
    .contentDetail {
        flex: 5;
        :global .el-checkbox {
            width: 25%;
            margin-bottom: 5px;
        }
        :global .el-checkbox+.el-checkbox {
            margin-left: 0;
        }
        :global .el-checkbox__label {
            vertical-align: middle;
            width: 150px;
            @extend %nowrap;
        }
    }
    .successContent {
        width: 362px;
        text-align: center;
        margin: auto;
        line-height: 20px;
    }
    .successContent i {
        font-size: 42px;
        color: var(--color-success);
        margin-bottom: 10px;
    }
    .batteryGroup{
        margin: 20px 0;
        background-color: var(--background-color-base);
        padding-top: 20px;
    }
    .colleftHide{
        display: none;
    }
    .nodeMagin{
        margin: 0;
    }
</style>
