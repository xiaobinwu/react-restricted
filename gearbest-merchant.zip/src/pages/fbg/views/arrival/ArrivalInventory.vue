<template>
    <div :class="$style.container">
        <el-form :inline="true" :model="formData" :class="$style.marginb20">
            <el-form-item :label="`${$t('fbg.arrival.goodTitle')}:`">
                <el-input :class="$style.formInline" v-model="formData.title" :placeholder="$t('fbg.arrival.match')"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodNo')}:`">
                <el-input :class="$style.formInline" v-model="formData.skus"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodCat')}:`">
                <category-cascader :category_id="formData.category_id" @updateCategory="updateCategory"></category-cascader>
            </el-form-item>
            <el-button type="primary" @click="onSearch">{{ $t('fbg.search') }}</el-button>
        </el-form>
        <el-table
            ref="multipleTable"
            :data="list"
            style="width: 100%"
            border
            @selection-change="listSelectionChange">
            <el-table-column type="selection"></el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodTitle')"
                header-align="center"
                prop="goodsTitle"
                width="300">
                <template slot-scope="scope">
                    <img :class="$style.img" :src="scope.row.image_urls[0]" alt="">
                    <router-link
                        :class="$style.link"
                        :to="{name: 'fgbMaterialView', query: { sku: scope.row.good_sn }}">{{ scope.row.goodsTitle }}</router-link>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodNo')"
                prop="good_sn"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodCat')"
                prop="categoryName"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.inAmount')"
                prop="send_amount"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.actualAmount')"
                prop="updatetime"
                width="120"
                align="center">
                <template slot-scope="scope">
                    <el-input
                        :class="[$style.formAmount, scope.row.error ? $style.error : '']"
                        v-model="scope.row.actualAmount"
                        :disabled="scope.row.isEditable"
                        @blur="checkNumber(scope.row)"></el-input>
                </template>
            </el-table-column>
        </el-table>
        <div v-if="page.totalCount" :class="$style.pagination">
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="page.pageSize"
                :total="page.totalCount"
                align="right"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>
        <div :class="$style.previewList">
            <el-button @click="previewList">{{ $t('fbg.print.previewlist') }}</el-button>
            <div :class="$style.noShow" class="previewList">
                <inventory-print :inventory-list="inventoryList"></inventory-print>
            </div>
        </div>

    </div>
</template>

<script>

    import { dateFormat } from '@/assets/js/utils/date';
    import CategoryCascader from '@/components/CategoryCascader';
    import { fbgArrivalGoods } from '@fbg/services/fbg';
    import InventoryPrint from '@fbg/components/InventoryPrint';

    export default {
        components: {
            CategoryCascader,
            InventoryPrint
        },
        data() {
            return {
                page: {
                    currentPage: 1,
                    pageSize: 10,
                    totalCount: 0,
                },
                formData: {
                    wid: '',
                    skus: '',
                    title: '',
                    category_id: '',
                },
                list: [],
                inventorySnList: [], // 已选择商品的sku
                inventoryList: [], // 已选择商品数据
                inputRules: /^\+?[1-9][0-9]*$/, // 正整数正则表达式
            };
        },
        created() {
            this.inventoryList = [];
            const { query: { wid } } = this.$route;
            this.formData.wid = wid;
            this.dateFormat = dateFormat;
            this.onSearch();
            this.removePreview();
        },
        destroyed() {
            document.querySelector('.previewList').style.display = 'none';
            document.getElementById('app').style.display = 'block';
        },
        methods: {
            // 清除去之前添加过的打印节点
            removePreview() {
                const previewDom = document.querySelector('body>.previewList');
                if (previewDom) {
                    document.querySelector('body').removeChild(previewDom);
                    this.removePreview();
                }
            },
            // 打印预览
            previewList() {
                let isAccord = true;
                this.inventoryList = [];
                this.inventorySnList.forEach((item) => {
                    const index = this.list.findIndex(n => item === n.good_sn);
                    if (index > -1) {
                        this.inventoryList.push(this.list[index]);
                        if (!this.inputRules.test(this.list[index].actualAmount)) {
                            isAccord = false;
                        }
                    }
                });
                if (this.inventoryList.length <= 0) {
                    this.$message.error(this.$t('fbg.print.listempty'));
                } else if (!isAccord) {
                    this.$message.error('请输入正确的数量');
                } else {
                    const preview = document.querySelector('.previewList');
                    document.getElementById('app').style.display = 'none';
                    document.body.appendChild(preview);
                    preview.style.display = 'block';
                }

            },
            async onSearch() {
                const vm = this;
                const formData = {
                    page_index: vm.page.currentPage,
                    page_size: vm.page.pageSize,
                    ...vm.formData
                };

                const { status, data } = await fbgArrivalGoods.http({
                    params: formData,
                });

                if (status === 0) {
                    vm.list = [];
                    data.list.forEach((item) => {
                        item.actualAmount = 0;
                        item.isEditable = false;
                        item.error = false;
                        vm.list.push(item);
                    });

                }
            },

            // 填写实际入仓数量
            checkNumber(row) {
                if (this.inputRules.test(row.actualAmount) && row.actualAmount > 0) {
                    row.error = false;
                } else {
                    row.error = true;
                    this.$message.error('请输入正确数量');
                }
            },
            handleSizeChange(val) {
                this.page.pageSize = val;
                this.onSearch();
            },
            handleCurrentChange(val) {
                this.page.currentPage = val;
                this.onSearch();
            },
            updateCategory(data) {
                this.formData.category_id = data.category_id;
            },
            listSelectionChange(list) {
                // this.list.forEach((item) => {
                //     item.isEditable = false;
                // });
                this.inventorySnList = [];
                list.forEach((item) => {
                    this.inventorySnList.push(item.good_sn);
                });
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
        padding: 20px;
    }

    .marginb20{
        margin-bottom: 20px;
    }

    .img{
        width: 50px;
        height: 50px;
        display: inline-block;
        vertical-align: middle;
    }

    .link {
        line-height: 16px;
        max-height: 32px;
        max-width: 215px;
        overflow: hidden;
        display: inline-block;
        vertical-align: middle;
        color: var(--color-primary-darken);
        margin-left: 10px;
    }

    .pagination{
        margin-top: 20px;
    }
    .formAmount{
        width: 80px;
    }
    .previewList{
        margin-top: 30px;
        text-align: center;
    }
    .noShow{
        display: none;
    }
    .error [class~="el-input__inner"]{
        border-color: var(--color-error);
    }

</style>
