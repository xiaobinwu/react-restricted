<template>
    <div :class="$style.container">
        <el-form :inline="true" :model="formData" :class="$style.marginb20">
            <el-form-item :label="`${$t('fbg.arrival.goodTitle')}:`">
                <el-input :class="$style.formInline" v-model="formData.title" :placeholder="$t('fbg.arrival.match')"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodNo')}:`">
                <el-input :class="$style.formInline" v-model="formData.skus"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodCat')}:`">
                <category-cascader :category_id="formData.category_id" @updateCategory="updateCategory"></category-cascader>
            </el-form-item>
            <el-button type="primary" @click="onSearch">{{ $t('fbg.search') }}</el-button>
        </el-form>
        <el-table
            :data="list"
            style="width: 100%">
            <el-table-column
                :label="$t('fbg.arrival.goodTitle')"
                header-align="center"
                prop="goodsTitle"
                width="300">
                <template slot-scope="scope">
                    <img :class="$style.img" :src="scope.row.image_urls[0]" alt="">
                    <router-link
                        :class="$style.link"
                        :to="{name: 'fgbMaterialView', query: { sku: scope.row.good_sn }}">{{ scope.row.goodsTitle }}</router-link>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodNo')"
                prop="good_sn"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodCat')"
                prop="categoryName"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.inAmount')"
                prop="send_amount"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.amount')"
                prop="amount"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.updateTime')"
                prop="updatetime"
                width="150"
                align="center">
                <template slot-scope="scope">{{ dateFormat(scope.row.updatetime) }}</template>
            </el-table-column>
        </el-table>
        <div v-if="page.totalCount" :class="$style.pagination">
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="page.pageSize"
                :total="page.totalCount"
                align="right"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>
    </div>
</template>

<script>

    import { dateFormat } from '@/assets/js/utils/date';
    import CategoryCascader from '@/components/CategoryCascader';
    import { fbgArrivalGoods } from '@fbg/services/fbg';

    export default {
        components: {
            CategoryCascader,
        },
        data() {
            return {
                page: {
                    currentPage: 1,
                    pageSize: 10,
                    totalCount: 0,
                },
                formData: {
                    wid: '',
                    skus: '',
                    title: '',
                    category_id: '',
                },
                list: [],
            };
        },
        created() {
            const { query: { wid } } = this.$route;
            this.formData.wid = wid;
            this.dateFormat = dateFormat;
            this.onSearch();
        },
        methods: {
            async onSearch() {
                const vm = this;
                const formData = {
                    page_index: vm.page.currentPage,
                    page_size: vm.page.pageSize,
                    ...vm.formData
                };

                const { status, data } = await fbgArrivalGoods.http({
                    params: formData,
                });

                if (status === 0) {
                    vm.list = data.list;
                }
            },
            handleSizeChange(val) {
                this.page.pageSize = val;
                this.onSearch();
            },
            handleCurrentChange(val) {
                this.page.currentPage = val;
                this.onSearch();
            },
            updateCategory(data) {
                this.formData.category_id = data.category_id;
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
        padding: 20px;
    }

    .marginb20{
        margin-bottom: 20px;
    }

    .img{
        width: 50px;
        height: 50px;
        display: inline-block;
        vertical-align: middle;
    }

    .link {
        line-height: 16px;
        max-height: 32px;
        max-width: 215px;
        overflow: hidden;
        display: inline-block;
        vertical-align: middle;
        color: var(--color-primary-darken);
        margin-left: 10px;
    }

    .pagination{
        margin-top: 20px;
    }
</style>
