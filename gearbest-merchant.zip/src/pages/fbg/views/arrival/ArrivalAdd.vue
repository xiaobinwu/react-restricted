<template>
    <div :class="$style.container">
        <div :class="$style.tabTitle">{{ $t('fbg.arrival.add') }}</div>
        <div :class="$style.content">
            <el-form ref="form" :model="formData" :rules="rules" label-width="140px">
                <el-form-item :label="$t('fbg.arrival.applyInFbg')" prop="wares">
                    <span v-if="isSelect">{{ isSelect }}</span>
                    <el-select v-else v-model="formData.wares" :placeholder="$t('fbg.arrival.pSelect')">
                        <el-option
                            v-for="(item, index) in wares"
                            :key="index"
                            :label="item.realWhName"
                            :value="item.realWhCode">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item :label="$t('fbg.arrival.date')" prop="filterDate" required>
                    <el-date-picker
                        v-model="formData.filterDate"
                        value-format="timestamp" type="date">
                    </el-date-picker>
                </el-form-item>
                <el-form-item :label="$t('fbg.arrival.applyInGood')" prop="goods" required>
                    <el-button :class="$style.marginRight" @click="DialogDelivery_visible=true">
                        {{ $t('fbg.arrival.gSelect') }}
                    </el-button>
                    <span v-if="total > 0">{{ $t('fbg.arrival.selectedSku') }}: {{ skus }}，{{ $t('fbg.arrival.allInNum') }}: {{ total }}</span>
                </el-form-item>
                <el-form-item label="">
                    <el-button :class="$style.btnwidth" type="primary" @click="submit">{{ $t('fbg.update') }}</el-button>
                </el-form-item>
            </el-form>
        </div>
        <DialogDelivery :visible="DialogDelivery_visible" @close="DialogDelivery_visible=false"></DialogDelivery>
    </div>
</template>

<script>
    import { fbgWarelist, fbgArrivalWareAdd } from '@fbg/services/fbg';
    import DialogDelivery from '@fbg/components/DialogDelivery';

    export default {
        components: {
            DialogDelivery
        },
        data() {
            return {
                skus: 0,
                total: 0,
                wares: [],
                isSelect: '',
                formData: {
                    wares: '',
                    goods: [],
                    filterDate: '',
                },
                rules: {
                    wares: [{ required: true, message: this.$t('fbg.arrival.requied') }],
                    filterDate: [{ required: true, message: this.$t('fbg.arrival.requied') }],
                    goods: [{ type: 'array', required: true, message: this.$t('fbg.arrival.requied') }],
                },
                DialogDelivery_visible: false,
            };
        },
        created() {
            this.getWares();
        },
        methods: {
            async getWares() {
                const { status, data } = await fbgWarelist.http();
                if (status === 0) {
                    data.forEach((ware) => {
                        if (ware.isSelect) {
                            this.isSelect = ware.realWhName;
                            this.formData.wares = ware.realWhCode;
                        }
                    });

                    if (!this.isSelect) {
                        this.wares = data;
                    }
                }
            },
            saveData(data) {
                const { totalAmount, saved } = data;
                this.skus = saved.length;
                this.total = totalAmount;
                this.formData.goods = saved;
            },
            submit() {
                this.$refs.form.validate(async (valid) => {
                    if (valid) {
                        const { status } = await fbgArrivalWareAdd.http({
                            data: {
                                stock_code: this.formData.wares,
                                arrival_date: Math.ceil(this.formData.filterDate / 1000),
                                arrival_amount: this.total,
                                items: this.formData.goods,
                            },
                        });

                        if (status === 0) {
                            this.$router.push({
                                name: 'fgbArrival'
                            });
                        }
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
    }

    .content{padding: 30px 20px;}

    .tabTitle{
        height: 40px;
        line-height: 40px;
        padding-left: 35px;
        position: relative;
        font-size: var(--font-size-largest);
        background: var(--background-color-lighter);
        &:before{
            content: '';
            width: 5px;
            height: 13px;
            border-radius: 3px;
            background: var(--color-primary-darken);
            position: absolute;
            top:50%; left:20px;
            margin-top: -7px;
        }
    }

    .marginRight{
        margin-right: 10px;
    }

    .btnwidth{
        width: 120px;
    }
</style>
