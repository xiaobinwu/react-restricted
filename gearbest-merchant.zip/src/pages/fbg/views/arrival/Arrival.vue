<template>
    <div :class="$style.container">
        <el-form :inline="true" :model="formData" label-suffix="：">
            <el-form-item :label="$t('fbg.arrival.orderNo')">
                <el-input v-model="formData.order_no"></el-input>
            </el-form-item>
            <el-form-item :label="$t('fbg.arrival.sendNo')">
                <el-input v-model="formData.send_no"></el-input>
            </el-form-item>
            <el-form-item :label="$t('fbg.arrival.time')">
                <el-date-picker
                    v-model="filterDate"
                    :start-placeholder="$t('fbg.arrival.startTime')"
                    :end-placeholder="$t('fbg.arrival.endTime')"
                    :picker-options="disabledEndDate"
                    value-format="timestamp"
                    type="daterange">
                </el-date-picker>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="search">{{ $t('fbg.search') }}</el-button>
            </el-form-item>
            <el-form-item :class="$style.floatRight">
                <router-link :to="{name: 'fgbArrivalAdd'}"><el-button>{{ $t('fbg.arrival.applyIn') }}</el-button></router-link>
            </el-form-item>
        </el-form>
        <el-table
            :data="list"
            style="width: 100%">
            <el-table-column
                prop="id"
                label="ID"
                width="40"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.orderNo')"
                prop="order_no"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.sendNo')"
                prop="send_no"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodNum')"
                align="center">
                <template slot-scope="scope">
                    <router-link :to="{ name: 'fgbArrivalGoods', query: { wid: scope.row.id } }">{{ $t('fbg.arrival.goodNum') }}</router-link>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.inAmount')"
                width="130"
                prop="arrival_amount"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.amount')"
                prop="amount"
                align="center">
                <template slot="header" slot-scope="scope">
                    <el-popover
                        :prop="scope.arrival_amount"
                        width="400" trigger="hover"
                        placement="bottom-start">
                        <div class="content">{{ $t('fbg.arrival.inAmountTip1') }}<br>{{ $t('fbg.arrival.inAmountTip2') }}</div>
                        <span slot="reference">{{ $t('fbg.arrival.amount') }}<i :class="$style.tip" class="el-icon-question"></i>
                        </span>
                    </el-popover>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.date')"
                align="center">
                <template slot-scope="scope">{{ dateFormat(scope.row.arrival_date) }}</template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.time')"
                align="center">
                <template slot-scope="scope">{{ dateFormat(scope.row.order_time) }}</template>
            </el-table-column>
            <el-table-column
                label="是否等待入仓"
                align="center">
                <template slot-scope="scope">{{ scope.row.status ? '否': '是' }}</template>
            </el-table-column>
            <el-table-column
                :class="$style.btnWrapper"
                :label="$t('fbg.operate')"
                width="150"
                align="center">
                <template slot-scope="scope">
                    <router-link :to="{ name: 'fbgArrivalInventory', query: { wid: scope.row.id } }">
                        {{ $t('fbg.print.generatelist') }}
                    </router-link>
                    <span :class="$style.block" @click="showrintBarCode(scope.row.id)">{{ $t('fbg.arrival.barCode') }}</span>
                    <span
                        v-if="scope.row.order_no && scope.row.send_no"
                        :class="$style.block"
                        type="text" size="middle"
                        @click="showShip(scope.row)">{{ $t('fbg.arrival.ship') }}</span>
                </template>
            </el-table-column>
        </el-table>
        <div v-if="page.totalCount" :class="$style.pagination">
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="page.pageSize"
                :total="page.totalCount"
                align="right"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>
        <DialogPrintBarCode ref="printbarcode" :visible="dialogVisible_PrintBarCode" @close="dialogVisible_PrintBarCode=false"></DialogPrintBarCode>
        <DialogShip
            :visible="dialogVisible_Ship"
            :stock_code="stock_code"
            :purchase_sn="purchase_sn"
            :purchase_delivery_sn="purchase_delivery_sn"
            @close="dialogVisible_Ship=false"></DialogShip>
    </div>
</template>

<script>

    import DialogPrintBarCode from '@fbg/components/DialogPrintBarCode';
    import DialogShip from '@fbg/components/DialogShip';

    import { dateFormat } from '@/assets/js/utils/date';
    import { fbgArrivalList } from '@fbg/services/fbg';

    export default {
        name: 'Arrival',
        components: {
            DialogPrintBarCode,
            DialogShip,
        },
        data() {
            return {
                disabledEndDate: {
                    disabledDate(time) {
                        return time.getTime() > Date.now();
                    },
                },
                page: {
                    currentPage: 1,
                    pageSize: 10,
                    totalCount: 0,
                },
                formData: {
                    order_no: '',
                    send_no: '',
                },
                filterDate: [],
                list: [],
                dialogVisible_PrintBarCode: false,
                dialogVisible_Ship: false,
                stock_code: '',
                purchase_sn: '',
                purchase_delivery_sn: '',
            };
        },
        watch: {
            $route(to, from) {
                this.init();
            }
        },
        created() {
            this.dateFormat = dateFormat;
            this.init();
        },
        methods: {
            init() {
                const {
                    page,
                    pageSize,
                    orderNo,
                    sendNo,
                    beginTime,
                    endTime
                } = this.$route.query;
                const params = {};
                params.page = Number(page) || 1;
                params.pageSize = Number(pageSize) || 10;
                if (orderNo) {
                    params.order_no = orderNo;
                }
                if (sendNo) {
                    params.send_no = sendNo;
                }
                if (beginTime && endTime) {
                    params.begin_time = beginTime;
                    params.end_time = endTime;
                }
                this.onSearch(params);
            },
            async onSearch(params) {
                const vm = this;
                const { status, data } = await fbgArrivalList.http({
                    params
                });
                if (status === 0) {
                    this.updateSearch(params);
                    vm.list = data.list;
                    vm.page.totalCount = data.totalCount;
                }
            },
            search() {
                this.page.currentPage = 1;
                this.turnUrl();
            },
            updateSearch(params) {
                this.page.currentPage = params.page;
                this.page.pageSize = params.pageSize;
                this.formData.order_no = params.order_no || '';
                this.formData.send_no = params.send_no || '';
                if (params.begin_time && params.end_time) {
                    this.filterDate = [new Date(params.begin_time * 1000), new Date(params.end_time * 1000)];
                } else {
                    this.filterDate = [];
                }
            },
            handleSizeChange(val) {
                this.page.pageSize = val;
                this.turnUrl();
            },
            handleCurrentChange(val) {
                this.page.currentPage = val;
                this.turnUrl();
            },
            // 打印
            showrintBarCode(id) {
                this.dialogVisible_PrintBarCode = true;
                this.$refs.printbarcode.getGoods(id);
            },
            // 发货
            showShip(row) {
                this.stock_code = row.stock_code;
                this.purchase_sn = row.order_no;
                this.purchase_delivery_sn = row.send_no;
                this.dialogVisible_Ship = true;
            },
            // url变化
            turnUrl() {
                const { currentPage, pageSize } = this.page;
                let beginTime;
                let endTime;
                if (this.filterDate && this.filterDate[0]) {
                    beginTime = this.filterDate[0] / 1000;
                    endTime = this.filterDate[1] / 1000;
                }
                this.$router.push({
                    name: 'fgbArrival',
                    query: {
                        page: currentPage,
                        pageSize,
                        orderNo: this.formData.order_no,
                        sendNo: this.formData.send_no,
                        beginTime,
                        endTime
                    }
                });
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
        padding: 30px 20px;
    }
    .floatRight{
        float: right;
    }

    .block{
        padding: 0;
        display: block;
        cursor: pointer;
        margin:10px auto !important;
        color:var(--color-primary-darken);
    }

    .btnWrapper{
        text-align: center;
    }
    .mgl10{
        margin-left: 10px;
    }
    .tip{
        cursor: pointer;
        color:var(--color-text-secondary);
    }

    .pagination{
        margin-top: 20px;
    }
</style>
