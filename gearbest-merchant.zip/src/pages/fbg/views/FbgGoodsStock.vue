<template>
    <div :class="$style.container">
        <el-form :inline="true" :model="formData" :class="$style.marginb20" label-suffix="：">
            <el-form-item :label="`${$t('fbg.arrival.goodTitle')}`">
                <el-input :class="$style.formInline" v-model="formData.goodsTitle" :placeholder="$t('fbg.arrival.match')"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodNo')}`">
                <el-input :class="$style.formInline" v-model="formData.goodSnList"></el-input>
            </el-form-item>
            <el-form-item :label="`${$t('fbg.arrival.goodCat')}`">
                <category-cascader ref="cascader" :category_id="formData.platformCategoryIdList" @updateCategory="updateCategory"></category-cascader>
            </el-form-item>
            <el-button type="primary" @click="search">{{ $t('fbg.search') }}</el-button>
        </el-form>
        <el-table
            :data="list"
            style="width: 100%">
            <el-table-column
                :label="$t('fbg.arrival.goodTitle')"
                header-align="center"
                width="300">
                <template slot-scope="scope">
                    <img :class="$style.img" :src="scope.row.goodsMainImage.thumbUrl" alt="">
                    <a :class="$style.link" :href="scope.row.goodsUrl" target="_blank">{{ scope.row.goodsTitle }}</a>
                </template>
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodNo')"
                prop="goodSn"
                align="center">
            </el-table-column>
            <el-table-column
                :label="$t('fbg.arrival.goodCat')"
                prop="platformCategoryPath.path"
                align="center">
            </el-table-column>
            <el-table-column
                label="价格"
                prop="goodsPrice"
                align="center">
            </el-table-column>
            <el-table-column
                label="可售库存数量"
                prop="stockNum"
                align="center">
            </el-table-column>
            <el-table-column
                label="操作"
                align="center">
                <template slot-scope="scope">
                    <router-link :to="{name: 'fgbArrivalAdd'}">补仓</router-link>
                </template>
            </el-table-column>
        </el-table>
        <div v-if="page.totalCount" :class="$style.pagination">
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="[10, 20, 30, 40]"
                :page-size="page.pageSize"
                :total="page.totalCount"
                align="right"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>
    </div>
</template>

<script>

    import { dateFormat } from '@/assets/js/utils/date';
    import { reqGoodsList } from '@promotion/services/common';
    import CategoryCascader from '@/components/CategoryCascader';

    export default {
        components: {
            CategoryCascader
        },
        data() {
            return {
                page: {
                    currentPage: 1,
                    pageSize: 10,
                    totalCount: 0,
                },
                formData: {
                    goodsTitle: '',
                    goodSnList: '',
                    platformCategoryIdList: '',
                    deliveryType: 2,
                },
                list: []
            };
        },
        watch: {
            $route(to, from) {
                this.init();
            }
        },
        created() {
            this.dateFormat = dateFormat;
            this.init();
        },
        methods: {
            init() {
                const {
                    pageNo,
                    pageSize,
                    goodsTitle,
                    goodSnList,
                    platformCategoryIdList,
                } = this.$route.query;
                const params = {};
                params.deliveryType = 2; // 默认必传
                params.pageNo = Number(pageNo) || 1;
                params.pageSize = Number(pageSize) || 10;
                if (goodsTitle) {
                    params.goodsTitle = goodsTitle;
                }
                if (goodSnList) {
                    params.goodSnList = goodSnList;
                }
                if (platformCategoryIdList) {
                    params.platformCategoryIdList = platformCategoryIdList;
                }
                this.onSearch(params);
            },
            async onSearch(params) {
                const vm = this;
                const { status, data } = await reqGoodsList.http({
                    params
                });

                if (status === 0) {
                    this.updateSearch(params);
                    vm.list = data.list;
                    vm.page.totalCount = data.totalCount;
                }
            },
            updateSearch(params) {
                this.page.currentPage = params.page;
                this.page.pageSize = params.pageSize;
                this.formData.goodsTitle = params.goodsTitle || '';
                this.formData.goodSnList = params.goodSnList || '';
                if (params.platformCategoryIdList) {
                    this.$refs.cascader.setValue(params.platformCategoryIdList);
                } else {
                    this.$refs.cascader.setValue('');
                }
            },
            search() {
                this.page.currentPage = 1;
                this.turnUrl();
            },
            handleSizeChange(val) {
                this.page.pageSize = val;
                this.turnUrl();
            },
            handleCurrentChange(val) {
                this.page.currentPage = val;
                this.turnUrl();
            },
            updateCategory(data) {
                this.formData.platformCategoryIdList = data.category_id;
            },
            // url变化
            turnUrl() {
                const { currentPage, pageSize } = this.page;
                this.$router.push({
                    name: 'fgbGoodsStock',
                    query: {
                        pageNo: currentPage,
                        pageSize,
                        ...this.formData
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
        padding: 20px;
    }

    .marginb20{
        margin-bottom: 20px;
    }

    .img{
        width: 50px;
        height: 50px;
        display: inline-block;
        vertical-align: middle;
    }

    .link {
        line-height: 16px;
        max-height: 32px;
        max-width: 215px;
        overflow: hidden;
        display: inline-block;
        vertical-align: middle;
        color: var(--color-primary-darken);
        margin-left: 10px;
    }

    .pagination{
        margin-top: 20px;
    }
</style>
