
import Service from '@/assets/js/Service/index';

/**
 * 入仓管理列表
 * @type {}
 */

export const fbgArrivalList = new Service({
    url: '/warehouse-list',
    method: 'GET',
    loading: true,
});

/**
 * 入仓商品列表
 * @type {}
 */

export const fbgArrivalGoods = new Service({
    url: '/warehouse-in-goods',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 添加入仓商品
 * @type {}
 */

export const fbgArrivalProvedGoods = new Service({
    url: '/fbg-approved-goods',
    method: 'GET',
    loading: true,
});

/**
 * 提交添加入仓
 * @type {}
 */

export const fbgArrivalWareAdd = new Service({
    url: '/warehouse-add',
    method: 'POST',
    showError: true,
    loading: true,
});

/**
 * 入仓商品物料
 * @type {}
 */

export const fbgArrivalUnprovedGoods = new Service({
    url: '/fbg-unproved-goods',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 入仓商品
 * @type {}
 */

export const fbgWarelist = new Service({
    url: '/public/fbg-stock-realWhList',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 入仓发货
 * @type {}
 */

export const fbgSendExpress = new Service({
    url: '/fbg-sendExpress',
    method: 'POST',
    showError: true,
    loading: true,
});

/*
 * 运费模板-获取所有的运费模板（公共）
 * @type {}
 */
export const shippingTemplateGet = new Service({
    url: '/public/logistics/shipping-template/get-all',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 运费模板-获取所有的运费模板（公共）
 * @type {}
 */

export const whGoodGet = new Service({
    url: '/goods/wh-good',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 查看所有产品性质组及产品性质接口
 * @type {}
 */

export const natureInfoGet = new Service({
    url: '/fbg-nature-info',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 添加入仓商品资料
 * @type {}
 */

export const goodsAdd = new Service({
    url: '/fbg-add-goods',
    method: 'POST',
    showError: true,
    loading: true,
});

/**
 * 更新入仓商品资料
 * @type {}
 */

export const goodsSave = new Service({
    url: '/fbg-save-goods',
    method: 'POST',
    showError: true,
    loading: true,
});

/**
 * 获取入仓商品资料
 * @type {}
 */

export const fbgGetgoods = new Service({
    url: '/fbg-goods-info',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 获取充电器规格
 * @type {}
 */

export const fbgChargerSpec = new Service({
    url: '/fbg-charger-spec',
    method: 'GET',
    showError: true,
    loading: true,
});

/**
 * 获取申报价
 * @type {}
 */

export const fbgOrderDeclarePrice = new Service({
    url: '/public/logistics/fbg-order-declare-price/get-status',
    method: 'POST',
    showError: true,
    loading: true,
});

/**
 * 提交申报价
 * @type {}
 */

export const fbgOrderSaveDeclare = new Service({
    url: '/logistics/fbg-order-declare-price/create',
    method: 'POST',
    showError: true,
    loading: true,
});


// 添加物料
export const materialsList = new Service({
    url: '/fbg-materials-list',
    loading: true,
    method: 'get',
    isCancel: false,
});

// 授权的发布类目
export const categoryTree = new Service({
    url: '/goods/category-tree',
    loading: true,
    method: 'get',
    isCancel: false,
});

// 仓库下载详情
export const warehouseDownload = new Service({
    url: '/fbg-warehouse-download',
    method: 'get',
    isCancel: false,
});
