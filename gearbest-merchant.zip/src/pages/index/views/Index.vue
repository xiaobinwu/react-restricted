<template>
    <div :class="$style.container">
        <div :class="$style.homeWrap">
            <!-- 左侧布局 s -->
            <div :class="$style.homeInfo">
                <!-- 店铺信息 s -->
                <div :class="$style.homeHeader">
                    <div :class="$style.homeHeaderLeft">
                        <div :class="$style.storeInfo">
                            <img :class="$style.headImg" src="../assets/img/headerImg.png" />
                            <div :class="$style.storeText">
                                <p :class="$style.storeName">{{ shopName }}</p>
                                <p :class="$style.storeStatus">
                                    店铺状态
                                    <span v-if="userInfo.shopInfo[0].status === 1" :class="$style.normalColor">正常</span>
                                    <span v-if="userInfo.shopInfo[0].status === 2" :class="$style.frozen">冻结</span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div :class="$style.homeHeaderRight">
                        <div :class="$style.leaveMsgWrap">
                            <i :class="$style.msgIcon"></i>
                            <label>
                                我的留言
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToMessageLeave">{{ homeData.messagesNum || 0 }}</a>
                            </label>
                        </div>
                    </div>
                </div>
                <!-- 店铺信息 e -->

                <!-- 我的工作台 s-->
                <div :class="$style.homeWorkbench">
                    <h2 :class="$style.caption"><span>我的工作台</span></h2>
                    <div :class="$style.workbenchItem">
                        <div :class="$style.workbenchTitle">
                            <i :class="$style.bgTransaction"></i>
                            <span>交易提醒</span>
                        </div>
                        <div :class="$style.workbenchText">
                            <p>
                                今天新订单：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToOrderLists('orderQtyToday')">{{ orderInfo.orderQtyToday || 0 }}</a>
                            </p>
                            <p>
                                待付款订单：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToOrderLists('waitToPayQty')">{{ orderInfo.waitToPayQty || 0 }}</a>
                            </p>
                        </div>
                        <div :class="$style.workbenchText">
                            <p>
                                待发货订单：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToOrderLists('waitDeliveryQty')">{{ orderInfo.waitDeliveryQty || 0 }}</a>
                            </p>
                            <p v-if="userInfo.shopInfo[0].deliverModeList.indexOf(2) > -1">
                                待申报订单：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToFgbOrders">{{ orderInfo.inStorageOrderQty || 0 }}</a>
                            </p>
                        </div>
                    </div>
                    <div :class="$style.workbenchLine"></div>
                    <div :class="$style.workbenchItem">
                        <div :class="$style.workbenchTitle">
                            <i :class="$style.bgProduct"></i>
                            <span>产品信息</span>
                        </div>
                        <div :class="$style.workbenchText">
                            <p>
                                出售中的商品：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToGoodsList('upperShelfNumber')">{{ goodsInfo.upperShelfNumber || 0 }}</a>
                            </p>
                            <p>
                                待审核的商品：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToGoodsList('underReviewData')">{{ underReviewData.total_num || 0 }}</a>
                            </p>
                        </div>
                        <div :class="$style.workbenchText">
                            <p>
                                已下架的商品：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToGoodsList('lowerShelfNumber')">{{ goodsInfo.lowerShelfNumber || 0 }}</a>
                            </p>
                            <p>
                                审核不通过的商品：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToGoodsList('notApprovedData')">{{ notApprovedData.total_num || 0 }}</a>
                            </p>
                        </div>
                    </div>
                    <div :class="$style.workbenchLine"></div>
                    <div :class="$style.workbenchItem">
                        <div :class="$style.workbenchTitle">
                            <i :class="$style.bgSale"></i>
                            <span>售后信息</span>
                        </div>
                        <div :class="$style.workbenchText">
                            <p>
                                纠纷待处理：
                                <a :class="$style.numberText"
                                   href="javascript:;"
                                   @click="goToOrderAftersale">{{ homeData.serviceNum || 0 }}</a>
                            </p>
                        </div>
                    </div>
                </div>
                <!-- 我的工作台 e-->
            </div>
            <!-- 左侧布局 e -->

            <!-- 右侧布局 s-->
            <div :class="$style.homeMessage">
                <div :class="$style.gettingStarted">
                    <h2 :class="$style.captionRight"><span>新手入门必读</span></h2>
                    <ul :class="$style.msgList">
                        <li v-for="(item, index) in tutorialData" :key="index">
                            <span :class="`${$style.wall} ${$style.itemLeft}`">
                                <a href="javascript:;" @click="goToTutorialDetail(item.id)">{{ item.title }}</a>
                            </span>
                        </li>
                    </ul>
                </div>
                <div :class="$style.notice">
                    <h2 :class="$style.captionRight">
                        <span>最新公告</span><a href="javascript:;" @click="goToshopNoticesList">更多</a>
                    </h2>
                    <ul :class="$style.msgList">
                        <li v-for="(item, index) in announcementData" :key="index">
                            <span :class="`${$style.w220} ${$style.itemLeft}`">
                                <a href="javascript:;" @click="goToshopNoticesDetail(item.id)">{{ item.title }}</a>
                            </span>
                            <span :class="$style.itemRight">{{ dateFormat(item.update_time, 'MM/dd') }}</span>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- 右侧布局 e-->
        </div>

        <el-dialog
            :visible.sync="isFrozen"
            width="560px"
            center>
            <div :class="$style.shopFrozenInfo">
                <p>
                    <i class="el-icon-warning"></i>
                    {{ $t('index.shop.frozen') }}
                </p>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button :class="$style.frozenBtn" type="primary" size="small" @click="isFrozen = false">{{ $t('index.confirm') }}</el-button>
            </span>
        </el-dialog>
    </div>
</template>


<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import {
        reqIndexInfo, reqUnderReviewGoods, reqNotApprovedGoods, reqTutorialList, reqAnnouncementList
    } from '@index/services/home';
    import store from '@/assets/js/store';

    export default {
        name: 'StoreIndex',
        data() {
            return {
                dateFormat,
                homeData: {},
                goodsInfo: {},
                orderInfo: {},
                isFrozen: false, // 是否冻结
                underReviewData: {}, // 待审核的商品
                notApprovedData: {}, // 审核不通过的商品
                tutorialData: [], // 新手教学列表
                announcementData: [], // 店铺公告列表
                userInfo: store.state.user.userInfo, // 店铺信息
            };
        },
        computed: {
            shopName() {
                return this.userInfo.defaultShop.shopName;
            }
        },
        created() {
            this.initData();
        },
        methods: {
            initData() {
                this.getHomeData();
                this.getUnderReviewGoods();
                this.getNotApprovedGoods();
                this.getTutorialList();
                this.getAnnouncementList();
                this.isFrozen = this.userInfo.shopInfo[0].status === 2;
            },

            /**
             * 获取店铺首页信息
             */
            async getHomeData() {
                const { status, data } = await reqIndexInfo.http();
                if (status === 0) {
                    this.homeData = data;
                    this.goodsInfo = data.goodsInfo;
                    this.orderInfo = data.orderInfo;
                }
            },

            /**
             * 待审核商品数
             */
            async getUnderReviewGoods() {
                const { status, data } = await reqUnderReviewGoods.http();
                if (status === 0) {
                    this.underReviewData = data;
                }
            },

            /**
             * 审核不通过数
             */
            async getNotApprovedGoods() {
                const { status, data } = await reqNotApprovedGoods.http();
                if (status === 0) {
                    this.notApprovedData = data;
                }
            },

            /**
             * 新手教学
             */
            async getTutorialList() {
                const { status, data } = await reqTutorialList.http({
                    params: {
                        pageNo: 1,
                        pageSize: 6
                    }
                });
                if (status === 0) {
                    this.tutorialData = data.lists;
                }
            },

            /**
             * 店铺公告
             */
            async getAnnouncementList() {
                const { status, data } = await reqAnnouncementList.http({
                    params: {
                        pageNo: 1,
                        pageSize: 6
                    }
                });
                if (status === 0) {
                    this.announcementData = data.lists;
                }
            },

            /**
             * 跳转到店铺公告列表
             */
            goToshopNoticesList() {
                this.$router.push({
                    name: 'shopNoticesList'
                });
            },

            /**
             * 跳转到店铺公告详情
             */
            goToshopNoticesDetail(id) {
                this.$router.gbPush(`/store/announcement/info/${id}`);
            },

            /**
             * 跳转到新手教学详情
             */
            goToTutorialDetail(id) {
                this.$router.gbPush(`/store/tutorial/info/${id}`);
            },

            /**
             * 跳转到消息管理-我的留言-未回复消息列表
             */
            goToMessageLeave() {
                this.$router.gbPush('/message/leave?replyStatus=2');
            },

            /**
             * 跳转到订单列表页
             * type: 类型
             */
            goToOrderLists(type) {
                let urlParams = '';

                // 今日新订单
                if (type === 'orderQtyToday') {
                    // 取得当天0点 / 23:59:59 时间
                    const start = new Date(new Date(new Date().toLocaleDateString()).getTime());
                    const end = new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000);
                    urlParams = `orderCombinedStatus=0&createStartTime=${start.getTime() / 1000}&createEndtime=${end.getTime() / 1000 - 1}`;
                }

                // 待付款订单
                if (type === 'waitToPayQty') {
                    urlParams = 'orderCombinedStatus=1';
                }

                // 待发货订单
                if (type === 'waitDeliveryQty') {
                    urlParams = 'orderCombinedStatus=2';
                }

                // 待审报订单
                if (type === 'inStorageOrderQty') {
                    urlParams = 'orderCombinedStatus=3';
                }

                console.log(urlParams);

                this.$router.gbPush(`/order/lists?${urlParams}&pageSize=10&pageNo=1`);
            },

            /**
             * 跳转到商品列表
             */
            goToGoodsList(type) {
                let urlParams = '';

                // 出售中的商品
                if (type === 'upperShelfNumber') {
                    urlParams = 'type=1&goodsStatus=2';
                }

                // 已下架的商品
                if (type === 'lowerShelfNumber') {
                    urlParams = 'type=1&goodsStatus=3';
                }

                // 待审核的商品
                if (type === 'underReviewData') {
                    urlParams = 'type=2';
                }

                // 审核不通过的商品
                if (type === 'notApprovedData') {
                    urlParams = 'type=4';
                }

                this.$router.gbPush(`/goods/list?${urlParams}&pageSize=10&pageNo=1`);
            },

            /**
             * 跳转到订单管理-售后处理-待处理列表页面
             */
            goToOrderAftersale() {
                this.$router.gbPush('/order/aftersale?serviceStatus=30');
            },

            /**
             * 跳转到FBG订单列表-待发货
             */
            goToFgbOrders() {
                this.$router.gbPush('/fbg/orders?orderCombinedStatus=2');
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {

    }

    .caption {
        position: relative;
        height: 50px;
        padding-left: 35px;
        line-height: 50px;
        font-size: 16px;
        background-color: var(--background-color-lighter);

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }
    }

    .captionRight {
        position: relative;
        height: 50px;
        padding-left: 25px;
        line-height: 50px;
        font-size: 16px;
        background-color: var(--background-color-lighter);

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 10px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }

        a {
            float: right;
            font-size: 14px;
            margin-right: 10px;
        }
    }

    .normalColor {
        margin-left: 10px;
        color: var(--color-primary);
    }

    .abnormalColor {
        margin-left: 10px;
        color: var(--color-error);
    }

    .numberText {
        color: #F30240;
        margin-left: 10px;
    }

    .homeWrap {
        display: flex;
        font-family: PingFang-SC-Regular;
    }

    .homeInfo {
        flex: 1;
    }

    .homeHeader {
        background-color: var(--color-white);
        height: 150px;
    }

    .homeHeaderLeft {
        float: left;
        margin: 30px 40px;
    }

    .storeInfo {
        position: relative;
    }

    .headImg {
        float: left;
        width: 90px;
        height: 90px;
        border: 1px solid gainsboro;
        border-radius: 50%;
    }

    .storeText {
        margin-left: 30px;
        float: left;
        margin-top: 18px;
    }

    .storeName {
        color: var(--color-text-primary);
        font-size: 18px;
        font-weight: 500;
    }

    .storeStatus {
        margin-top: 10px;
        color: #333333;
        font-size: 14px;
    }

    .homeHeaderRight {
        float: right;
    }

    .leaveMsgWrap {
        width: 200px;
        border-left: 1px solid rgba(242,242,242,1);
        padding-left: 44px;
        height: 70px;
        line-height: 70px;
        margin-top: 40px;
    }
    .msgIcon {
        background: url("../assets/img/notice.png") no-repeat;
        background-size: 100% 100%;
        display: inline-block;
        width: 30px;
        height: 30px;
        position: relative;
        top: 10px;
        margin-right: 10px;
    }

    .homeWorkbench {
        background-color: var(--color-white);
        margin-top: 20px;
    }

    .workbenchItem {
        padding: 46px 40px;
        div {
            display: inline-block;
        }
    }

    .workbenchText {
        vertical-align: top;
        margin-left: 90px;
        p:first-child {
            margin-bottom: 30px;
        }
    }

    .workbenchTitle {
        width: 64px;
        text-align: center;
        i {
            background-size: 100% 100%;
            display: block;
            width: 30px;
            height: 30px;
            margin-left: 17px;
        }
        span {
            display: block;
            margin-top: 13px;
            font-size: 16px;
        }
    }

    .workbenchLine {
        height: 1px;
        margin: 0 20px;
        background: var(--background-color-base);
    }

    .bgProduct {
        background: url("../assets/img/product.png") no-repeat;
    }

    .bgSale {
        background: url("../assets/img/sale.png") no-repeat;
    }

    .bgTransaction {
        background: url("../assets/img/transaction-reminder.png") no-repeat;
    }

    .homeMessage {
        float: right;
        width: 300px;
        margin-left: 20px;
    }

    .msgList {
        margin-left: 10px;
        overflow: auto;
        li {
            margin: 20px 10px 20px 0;
            height: 20px;
            line-height: 20px;
            a {
                color: var(--color-black);
            }
        }
    }

    .w220 {
        width: 220px;
    }

    .wall {
        width: 100%;
    }

    .itemLeft {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        &:before {
            content: ' • ';
            color: var(--color-primary-darken);
            padding-left: 10px;
            padding-right: 2px;
        }
    }

    .itemRight {
        float: right;
        color: var(--color-text-regular);
    }

    .gettingStarted {
        background-color: var(--color-white);
    }

    .notice {
        background-color: var(--color-white);
        margin-top: 20px;
    }

    .frozen {
        margin-left: 10px;
        color: var(--color-danger);
    }
    .shopFrozenInfo {
        width: 362px;
        text-align: center;
        margin: auto;
        line-height: 20px;
        font-size: 16px;
    }
    .shopFrozenInfo i {
        font-size: 20px;
        margin-right: 5px;
        position: relative;
        top: 2px;
    }
    .frozenBtn{
        font-size: 16px;
    }
</style>
