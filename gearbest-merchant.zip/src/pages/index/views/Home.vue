<template>
    <div :class="$style.main">
        <div :class="$style.header">
            <span :class="$style.welcomeTitle">{{ $t('index.tips.welcome') }}</span>
        </div>
        <div :class="$style.welcome"></div>
        <el-dialog
            :visible.sync="isFrozen"
            width="560px"
            center>
            <div :class="$style.shopFrozenInfo">
                <p>
                    <i class="el-icon-warning"></i>
                    {{ $t('index.shop.frozen') }}
                </p>
            </div>
            <span slot="footer" class="dialog-footer">
                <el-button :class="$style.frozenBtn" type="primary" size="small" @click="isFrozen = false">{{ $t('index.confirm') }}</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import { mapState } from 'vuex';

    export default {
        data() {
            return {
                welcomeIMG: '',
                isFrozen: false,
            };
        },
        computed: {
            ...mapState({
                userInfo: state => state.user.userInfo,
                isLogin: state => state.user.isLogin,
            })
        },
        mounted() {
            console.log('userInfo: ', this.userInfo);
            this.isFrozen = this.userInfo.shopInfo[0].status === 2;
        }
    };
</script>

<style module>
    .main{
        background-color: #fff;
        overflow: hidden;
    }
    .header{
        text-align: center;
        margin-top: 182px;;
    }
    .welcomeTitle{
        position: relative;
        font-size: 40px;
        font-weight: bold;
        color: #000;
        &::after{
            content: '';
            position: absolute;
            top: 55px;
            left: 0;
            width: 68px;
            height: 8px;
            border-radius: 4px;
            background-color: #2774FF;
        }
    }
    .welcome{
        display: block;
        width: 499px;
        height: 488px;
        margin: 64px auto 0;
        background: url("../assets/img/welcome.png") no-repeat;
        background-size: 100% 100%;
    }
    .shopFrozenInfo {
        width: 362px;
        text-align: center;
        margin: auto;
        line-height: 20px;
        font-size: 16px;
    }
    .shopFrozenInfo i {
        font-size: 20px;
        margin-right: 5px;
        position: relative;
        top: 2px;
    }
    .frozenBtn{
        font-size: 16px;
    }

</style>
