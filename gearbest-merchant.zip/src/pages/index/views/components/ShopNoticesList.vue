<!--店铺公告-->
<template>
    <div :class="$style.container">
        <h2 :class="$style.caption"><span>店铺公告</span></h2>
        <div :class="$style.tableWrap">
            <el-table :data="tableData" border>
                <div slot="empty">暂无数据</div>
                <el-table-column label="文章标题">
                    <template slot-scope="scope">
                        <a :class="$style.contentLink" href="javascript:;" @click="goToshopNoticesDetail(scope.row.id)">{{ scope.row.title }}</a>
                    </template>
                </el-table-column>
                <el-table-column :formatter="formatDate" prop="update_time" label="时间" width="150"></el-table-column>
            </el-table>

            <el-pagination
                :class="$style.pagination"
                :current-page="pageNo"
                :page-size="pageSize"
                :total="totalCount"
                layout="->, total, sizes, prev, pager, next, jumper"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { reqAnnouncementList } from '@index/services/home';

    export default {
        name: 'ShopNoticesList',
        data() {
            return {
                pageNo: 1, // 当前页数
                pageSize: 10, // 每页数量
                totalCount: Infinity, // 总条数
                tableData: [], // 表格数据对象
            };
        },

        created() {
            this.getAnnouncementList();
        },

        methods: {
            /**
             * 店铺公告
             */
            async getAnnouncementList() {
                const { status, data } = await reqAnnouncementList.http({
                    params: {
                        pageNo: this.pageNo,
                        pageSize: this.pageSize
                    }
                });
                if (status === 0) {
                    this.tableData = data.lists;
                    this.totalCount = data.totalCount || 0;
                }
            },

            /**
             * 改变时会触发
             */
            handleSizeChange(val) {
                this.pageSize = val;
                this.getAnnouncementList();
            },

            /**
             * 改变时会触发
             */
            handleCurrentChange(val) {
                this.pageNo = val;
                this.getAnnouncementList();
            },

            /**
             * 格式化时间
             * @return {string}
             */
            formatDate(row, column, cellValue) {
                return cellValue ? dateFormat(cellValue, 'yyyy/MM/dd hh:mm:ss') : '--';
            },

            /**
             * 跳转到店铺公告详情
             */
            goToshopNoticesDetail(id) {
                this.$router.gbPush(`/store/announcement/info/${id}`);
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding-bottom: 10px;
        background-color: var(--color-white);
    }

    .pagination {
        margin-top: 30px;
    }

    .caption {
        position: relative;
        height: 50px;
        padding-left: 35px;
        line-height: 50px;
        font-size: 16px;
        background-color: var(--background-color-lighter);

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }
    }


    .tableWrap {
        margin: 30px;
    }

    .contentLink {
        color: var(--color-black);
    }
</style>
