<!--店铺公告详情-->
<template>
    <div :class="$style.container">
        <div :class="$style.goBack">
            <a href="javascript:;" @click="goBack"><i class="el-icon-arrow-left"></i>返回</a>
            <span :class="$style.goBackName">店铺公告详情</span>
        </div>
        <div :class="$style.contentWrap">
            <p :class="$style.title">{{ data.title }}</p>
            <p :class="$style.time">{{ data.update_time ? dateFormat(data.update_time, 'yyyy/MM/dd') : '' }}</p>
            <div :class="$style.content" v-html="data.content"></div>
        </div>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { reqAnnouncementInfo } from '@index/services/home';

    export default {
        name: 'ShopNoticesDetail',
        data() {
            return {
                dateFormat,
                data: [],
            };
        },

        created() {
            this.getAnnouncementInfo();
        },

        methods: {
            /**
             * 店铺公告详情
             */
            async getAnnouncementInfo() {
                const { status, data } = await reqAnnouncementInfo.http({
                    params: {
                        id: this.$route.params.id
                    }
                });
                if (status === 0) {
                    this.data = data[0];
                }
            },

            /**
             * 返回
             */
            goBack() {
                window.history.go(-1);
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding-bottom: 10px;
    }

    .goBack {
        position: relative;
        height: 50px;
        padding-left: 20px;
        line-height: 50px;
        font-size: 18px;
        background-color: var(--background-color-lighter);
    }

    .goBackName {
        color: #666;
        font-size: 18px;
        margin-left: 10px;
    }

    .contentWrap {
        margin-top: 20px;
        padding: 20px;
        background-color: var(--color-white);
    }

    .title {
        font-size: 24px;
        text-align: center;
        padding-top: 70px;
    }

    .time {
        margin-top: 10px;
        text-align: center;
        margin-bottom: 60px;
    }
</style>
