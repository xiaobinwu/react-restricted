<!--新手教学详情-->
<template>
    <div :class="$style.container">
        <h2 :class="$style.caption"><span>新手教学详情</span></h2>
        <div :class="$style.contentWrap">
            <p :class="$style.title">{{ data.title }}</p>
            <div :class="$style.content" v-html="data.content"></div>
        </div>
    </div>
</template>

<script>
    import { reqTutorialInfo } from '@index/services/home';

    export default {
        name: 'ServiceCapitalQuery',
        data() {
            return {
                data: [],
            };
        },

        created() {
            this.getTutorialInfo();
        },

        methods: {
            /**
             * 新手教学详情
             */
            async getTutorialInfo() {
                const { status, data } = await reqTutorialInfo.http({
                    params: {
                        id: this.$route.params.id
                    }
                });
                if (status === 0) {
                    this.data = data[0];
                }
            },
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding-bottom: 10px;
    }

    .caption {
        position: relative;
        height: 50px;
        padding-left: 35px;
        line-height: 50px;
        font-size: 16px;
        background-color: var(--background-color-lighter);

        &:before {
            content: '';
            position: absolute;
            top: 17px;
            left: 20px;
            width: 5px;
            height: 16px;
            border-radius: 5px;
            background-color: var(--color-primary-darken);
        }
    }

    .contentWrap {
        margin-top: 20px;
        padding: 20px;
        background-color: var(--color-white);
    }

    .title {
        font-size: 24px;
        text-align: center;
        padding-top: 70px;
    }
</style>
