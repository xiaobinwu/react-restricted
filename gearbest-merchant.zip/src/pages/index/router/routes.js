import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    {
        path: '/index/home',
        name: 'indexHome',
        meta: {
            title: 'base.menu.index.name',
            breadVisible: false,
        },
        component: () => asyncComponent(import('@index/views/Index')),
    },
    {
        path: '/store/announcement/list',
        name: 'shopNoticesList',
        meta: {
            title: 'base.menu.index.shopNotices',
            breadVisible: false,
        },
        component: () => asyncComponent(import('@index/views/components/ShopNoticesList')),
    },
    {
        path: '/store/announcement/info/:id',
        name: 'shopNoticesDetail',
        meta: {
            title: 'base.menu.index.shopNoticesDetail',
            breadVisible: false,
        },
        component: () => asyncComponent(import('@index/views/components/ShopNoticesDetail')),
    },
    {
        path: '/store/tutorial/info/:id',
        name: 'TutorialDetail',
        meta: {
            title: 'base.menu.index.tutorialDetail',
            breadVisible: false,
        },
        component: () => asyncComponent(import('@index/views/components/TutorialDetail')),
    }
];
