import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import indexLang from '@/lang/index';
import router from './router';

lang({ local: indexLang, moduleName: 'index' }).then((langInstance) => {
    app({ lang: langInstance, router });
});
