/**
 * Created by zhongjinglin on 2019/3/2.
 */

import Service from '@/assets/js/Service';

// 首页信息
export const reqIndexInfo = new Service({
    url: '/index/index',
    method: 'GET',
    loading: true
});

// 待审核商品数
export const reqUnderReviewGoods = new Service({
    url: '/goods/under-review-goods-list?page_index=1&page_size=1',
    method: 'GET',
    loading: true
});

// 审核不通过数
export const reqNotApprovedGoods = new Service({
    url: '/goods/not-approved-goods-list?page_index=1&page_size=1',
    method: 'GET',
    loading: true
});

// 新手教学列表
export const reqTutorialList = new Service({
    url: '/store/tutorial/list',
    method: 'GET',
    loading: true
});

// 新手教学详情
export const reqTutorialInfo = new Service({
    url: '/store/tutorial/info',
    method: 'GET',
    loading: true
});

// 店铺公告列表
export const reqAnnouncementList = new Service({
    url: '/store/announcement/list',
    method: 'GET',
    loading: true
});

// 店铺公告详情
export const reqAnnouncementInfo = new Service({
    url: '/store/announcement/info',
    method: 'GET',
    loading: true
});
