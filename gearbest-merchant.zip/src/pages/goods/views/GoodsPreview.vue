<template>
    <div :class="$style.container">
        <!-- 头部截图 -->
        <div :class="$style.top">
            <img :class="$style.topImg" src="../assets/img/topimg.jpg" alt="">
        </div>
        <!-- 面包屑 -->
        <div :class="$style.crumbs">
            <ul :class="$style.crumbsBox">
                <li :class="$style.crumbsItem">Home ></li>
                <li
                    v-for="(pathItem, pathIndex) in goodsInfo.path"
                    :key="pathIndex"
                    :class="[$style.crumbsItem, goodsInfo.path.length - 1 > pathIndex ? '' : $style.black]">
                    {{ pathItem }} {{ goodsInfo.path.length - 1 > pathIndex ? '>' : '' }}
                </li>
            </ul>
        </div>
        <!-- 定位区 -->
        <div :class="$style.content">
            <!-- 商品简介 数据切换 -->
            <div :class="$style.goodsIntro">
                <div :class="$style.leftBox">
                    <div :class="$style.showImgbox">
                        <img
                            v-for="(imgItem, imgIndex) in goodsInfo.imgList"
                            v-show="imgItem.active"
                            :key="imgIndex"
                            :class="$style.showImg" :src="imgItem.url" alt="">
                    </div>
                    <div :class="$style.imgItemBox">
                        <span :class="[$style.imgItemArrow, $style.arrowLeft]">
                            <i :class="[
                                'el-icon-arrow-left',
                                $style.imgItemArrowIcon,
                                goodsInfo.imgList[0] && goodsInfo.imgList[0].isShow ? '' : $style.active
                            ]" @click="switchList(-1, goodsInfo.imgList[0].isShow)"></i>
                        </span>
                        <span :class="[$style.imgItemArrow, $style.arrowRight]">
                            <i :class="[
                                'el-icon-arrow-right',
                                $style.imgItemArrowIcon,
                                (
                                    goodsInfo.imgList[goodsInfo.imgList.length - 1] &&
                                    goodsInfo.imgList[goodsInfo.imgList.length - 1].isShow
                                ) ? '' : $style.active
                            ]" @click="switchList(1, goodsInfo.imgList[goodsInfo.imgList.length - 1].isShow)"></i>
                        </span>
                        <ul :class="$style.imgItemList">
                            <li
                                v-for="(imgItem, imgIndex) in goodsInfo.imgList"
                                v-show="imgItem.isShow"
                                :key="imgIndex"
                                :class="[$style.imgItem, imgItem.active ? $style.active : '']"
                                @click="selectImg(imgIndex)">
                                <img :class="$style.imgItemValue" :src="imgItem.url" alt="">
                            </li>
                        </ul>
                    </div>
                </div>
                <div :class="$style.rightBox">
                    <h4 :class="$style.goodsTitle">{{ goodsInfo.title }}</h4>
                    <p
                        v-if="goodsInfo.brandCode != 0"
                        :class="$style.goodsModel">
                        <span :class="$style.goodsModelLable">Brand:</span>
                        <span :class="$style.black">{{ goodsInfo.brandName }}</span>
                    </p>
                    <div :class="[$style.goodsItem, $style.goodsPriceBg]">
                        <span :class="$style.goodsItemLabel">price:</span>
                        <div :class="$style.goodsItemContent">
                            <span :class="$style.goodsPrice">${{ goodsInfo.price }}</span>
                        </div>
                    </div>
                    <div
                        v-for="(attrItem, attrIndex) in goodsInfo.attrs"
                        :key="attrIndex"
                        :class="$style.goodsItem">
                        <span :class="$style.goodsItemLabel" :title="attrItem.name">{{ attrItem.name }}:</span>
                        <div :class="$style.goodsItemContent">
                            <div :class="$style.goodsAttrBox">
                                <span
                                    v-for="(valueItem, valueIndex) in attrItem.value"
                                    :key="valueIndex"
                                    :class="[$style.goodsAttr, valueItem.select ? $style.active : '']"
                                    @click="switchSku(attrItem.id, valueItem)">
                                    {{ valueItem.name }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 导航条 -->
            <div :class="$style.navBar">
                <span :class="$style.naveBarItem">Description</span>
            </div>
            <!-- 商品信息 -->
            <div :class="$style.description">
                <!-- 视频 -->
                <template v-if="goodsInfo.videos.length > 0">
                    <div
                        v-for="(videoItem, videoIndex) in goodsInfo.videos"
                        :key="videoIndex"
                        :class="$style.videoBox">
                        <a
                            v-if="!videoItem.play"
                            :class="$style.videoImgBtn"
                            href="javascript:;"
                            @click="videoItem.play = 1">
                            <svg version="1.1" viewBox="0 0 68 48" width="68" height="48">
                                <path
                                    :class="$style.videoImgBtnBg"
                                    d="M66.52,7.74c-0.78-2.93-2.49-5.41-5.42-6.19C55.79,.13,34,0,34,0S12.21,
                                        .13,6.9,1.55 C3.97,2.33,2.27,4.81,1.48,7.74C0.06,13.05,0,24,0,24s0.06,
                                        10.95,1.48,16.26c0.78,2.93,2.49,5.41,5.42,6.19 C12.21,47.87,34,48,34,
                                        48s21.79-0.13,27.1-1.55c2.93-0.78,4.64-3.26,5.42-6.19C67.94,34.95,68,
                                        24,68,24S67.94,13.05,66.52,7.74z"
                                    fill="#212121"
                                    fill-opacity="0.8"></path>
                                <path d="M 45,24 27,14 27,34" fill="#fff"></path>
                            </svg>
                        </a>
                        <img
                            v-if="!videoItem.play"
                            :class="$style.videoImg"
                            :src="videoItem.img" alt="">
                        <iframe
                            v-else
                            :src="videoItem.url"
                            frameborder="0" width="100%" height="480"></iframe>
                    </div>
                </template>
                <!-- 描述 -->
                <div
                    v-if="goodsInfo.descriptionDetail"
                    :class="$style.detailInfo">
                    <h4 :class="$style.descTitle">Main Features</h4>
                    <div
                        :class="$style.detailContent"
                        v-html="goodsInfo.descriptionDetail"></div>
                </div>
                <!-- 属性 -->
                <div
                    v-if="goodsInfo.attrInfos.length > 0"
                    :class="$style.attrInfos">
                    <h4 :class="$style.descTitle">Specification</h4>
                    <!-- 表格 -->
                    <table
                        v-if="goodsInfo.attrInfos.length > 0"
                        :class="$style.table"
                        cellpadding="0" cellspacing="0" width="100%">
                        <tr
                            v-for="(item, index) in goodsInfo.attrInfos"
                            v-show="index < goodsInfo.tableShowNum"
                            :key="index">
                            <td
                                :class="$style.borderTd"
                                width="140"
                                align="right">
                                {{ item.name }}:
                            </td>
                            <td
                                :class="$style.borderTd">
                                <p
                                    v-for="(valueItem, valueIndex) in item.values"
                                    :key="valueIndex">
                                    {{ valueItem.name }}:{{ valueItem.unit_name }}
                                </p>
                            </td>
                        </tr>
                    </table>
                    <!-- 按钮 -->
                    <div
                        v-if="goodsInfo.attrInfos.length >= goodsInfo.tableShowNum"
                        :class="$style.attrInfosBtnBox">
                        <div
                            :class="$style.attrInfosBtn"
                            @click="goodsInfo.tableShowNum = 999">
                            <span :class="$style.attrInfosBtnTxt">View more</span>
                            <div :class="$style.attrInfosBtnIconBox">
                                <p :class="$style.attrInfosBtnIconBg">
                                    <i :class="['el-icon-arrow-down', $style.attrInfosBtnIcon]"></i>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- 图片 -->
                <div
                    v-if="goodsInfo.imgDetail"
                    :class="$style.imageDetailBox"
                    v-html="goodsInfo.imgDetail">
                    <!-- <img
                        v-for="(imageItem, imageIndex) in goodsInfo.imgDetail"
                        :key="imageIndex"
                        :class="$style.imageDetail"
                        :src="imageItem" alt=""> -->
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { getGoodsPreviewInfo } from '../services/goods';

    export default {
        name: 'GoodsPreview',
        data() {
            return {
                variationId: this.$route.params.id,
                reviewType: this.$route.params.type,
                // 商品数据
                goodsInfo: {
                    tableShowNum: 6,
                    path: [],
                    title: '',
                    brandCode: '',
                    brandName: '',
                    price: '',
                    imgList: [],
                    attrs: [],
                    imgDetail: '',
                    videos: [],
                    descriptionDetail: '',
                    attrInfos: [],
                    specifications: {},
                }
            };
        },
        watch: {
            $route(to, from) {
                this.variationId = this.$route.params.id;
                this.reviewType = this.$route.params.type;
                this.getGoodsInfo();
            }
        },
        created() {
            this.getGoodsInfo();
        },
        methods: {
            selectImg(activeIndex) {
                this.goodsInfo.imgList.forEach((item, index) => {
                    item.active = +(activeIndex === index);
                });
            },
            switchList(type, status) {
                const vm = this;
                if (status) return;
                const indexArr = [];
                vm.goodsInfo.imgList.forEach((item, index) => {
                    if (item.isShow) indexArr.push(index);
                });
                vm.goodsInfo.imgList.forEach((item, index) => {
                    item.isShow = 0;
                });
                indexArr.forEach((item, index) => {
                    vm.goodsInfo.imgList[item + type].isShow = 1;
                });
            },
            switchSku(id, thisItem) {
                const vm = this;
                const countArr = [];
                vm.goodsInfo.attrs.forEach((item) => {
                    if (item.id !== id) {
                        item.value.forEach((valueItem) => {
                            if (valueItem.select) countArr.push(valueItem.primeNumber);
                        });
                    }
                });
                let countValue = 1;
                countArr.forEach((item) => {
                    countValue *= item;
                });
                countValue *= thisItem.primeNumber;
                vm.$router.push({
                    name: 'GoodsPreview',
                    params: {
                        id: vm.goodsInfo.specifications[countValue],
                        type: vm.reviewType
                    }
                });
            },
            // ----- 请求数据 -----
            async getGoodsInfo() {
                const vm = this;
                const { status, data } = await getGoodsPreviewInfo.http({
                    loading: true,
                    params: {
                        variation_id: vm.variationId,
                        review_type: vm.reviewType,
                    }
                });
                if (status === 0 && data) {
                    const imgListArr = [];
                    const videosArr = [];
                    // 格式化图片
                    data.sale_infos.image_urls.forEach((item, index) => {
                        imgListArr.push({
                            url: item,
                            isShow: +(index < 5),
                            active: +(index === 0)
                        });
                    });
                    // 格式化视频
                    data.sale_infos.video_urls.forEach((item, index) => {
                        videosArr.push({
                            play: 0,
                            url: item.url,
                            img: item.img,
                        });
                    });
                    Object.assign(vm.goodsInfo, {
                        path: data.site_category_path,
                        title: data.base_infos.title,
                        brandCode: data.base_infos.brand_code,
                        brandName: data.base_infos.brand_name,
                        price: data.sale_infos.present_price,
                        attrs: data.sale_infos.sale_attrs,
                        imgList: imgListArr,
                        videos: videosArr,
                        imgDetail: data.sale_infos.image_detail,
                        descriptionDetail: data.sale_infos.description_detail,
                        attrInfos: data.attr_infos,
                        specifications: data.sale_infos.specifications
                    });
                } else {
                    vm.$router.push({ name: 'goodsList' });
                }
            }
        }
    };
</script>

<style module>
    .container {
        background: #fff;
        min-height: 800px;
        overflow: hidden;
    }

    .black {
        color: #000;
    }

    /* 头部截图 */
    .top {
        position: relative;
        font-size: 0;
        box-shadow: 0px 2px 4px 0px rgba(0,0,0,0.15);
        z-index: 1px;
    }

    .topImg {
        width: 100%;
    }

    /* 面包屑 */
    .crumbs {
        background: #F9F9F9;
    }

    .crumbsBox {
        width: 900px;
        margin: 0 auto;
        height: 40px;
        line-height: 40px;
        font-size: 0;
        color: #666666;
    }

    .crumbsItem {
        display: inline-block;
        vertical-align: top;
        font-size: 12px;
        margin: 0 2px;
    }

    /* 定位区 */
    .content {
        width: 900px;
        margin: 0 auto;
    }

    /* 商品属性 */
    .goodsIntro {
        padding: 20px 0;
        margin-bottom: 80px;
        font-size: 0;
    }

    .leftBox {
        display: inline-block;
        vertical-align: top;
        width: 400px;
        margin-right: 30px;
    }

    .showImgbox {
        height: 389px;
        border: 1px solid #ddd;
        margin-bottom: 20px;
    }

    .showImg {
        width: 100%;
        height: 100%;
    }

    .imgItemBox {
        position: relative;
        padding: 0 25px;
    }

    .imgItemArrow {
        position: absolute;
        top: 0;
        width: 40px;
        height: 60px;
    }

    .imgItemArrowIcon {
        line-height: 60px;
        font-size: 30px;
        color: #CCCCCC;
    }

    .imgItemArrowIcon.active {
        color: #000;
        cursor: pointer;
    }

    .arrowLeft {
        left: 0;
        text-align: left;
    }

    .arrowRight {
        right: 0;
        text-align: right;
    }

    .imgItemList {
        font-size: 0;
    }

    .imgItem {
        display: inline-block;
        vertical-align: top;
        width: 60px;
        height: 60px;
        margin: 0 5px;
        background: #FAFAFA;
        cursor: pointer;
    }

    .imgItem.active {
        width: 60px;
        height: 60px;
        border: 2px solid #FF8A00;
    }

    .imgItemValue {
        width: 100%;
        height: 100%;
    }

    .rightBox {
        display: inline-block;
        vertical-align: top;
        width: 470px;
    }

    .goodsTitle {
        line-height: 25px;
        font-size: 20px;
        color: #000;
    }

    .goodsModel {
        padding: 10px 0;
        line-height: 22px;
        font-size: 14px;
    }

    .goodsModelLable {
        color: #333333;
        margin-right: 10px;
    }

    .goodsItem {
        padding: 10px;
    }

    .goodsPriceBg {
        background: #FAFAFA;
    }

    .goodsItemLabel {
        display: inline-block;
        vertical-align: top;
        width: 80px;
        line-height: 40px;
        font-size: 14px;
        color: #666666;
        margin-right: 10px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .goodsItemContent {
        display: inline-block;
        vertical-align: top;
        width: 360px;
    }

    .goodsPrice {
        font-size: 30px;
        line-height: 40px;
        font-weight: bold;
        color: #F30240;
    }

    .goodsAttr {
        display: inline-block;
        vertical-align: top;
        height: 30px;
        line-height: 30px;
        font-size: 14px;
        padding: 0 20px;
        margin: 5px 10px 5px 0;
        color: #000;
        border: 1px solid #ccc;
        cursor: pointer;
    }

    .goodsAttr.active {
        border-color: #F30240;
        color: #F30240;
    }

    /* 导航条 */
    .navBar {
        font-size: 0;
        background: #F9F9F9;
        border-bottom: 2px solid #FFDA00;
        margin-bottom: 20px;
    }

    .naveBarItem {
        display: inline-block;
        vertical-align: top;
        padding: 0 20px;
        line-height: 44px;
        font-size: 14px;
        color: #000000;
        background: #FFDA00;
    }

    /* 视频 */
    .videoBox {
        position: relative;
        width: 855px;
        height: 480px;
        margin: 0 auto;
        text-align: center;
        background: #000;
        margin-bottom: 20px;
    }

    .videoImg {
        max-width: 100%;
        max-height: 100%;
    }

    .videoImgBtn {
        position:absolute;
        left:0;
        top:0;
        right:0;
        bottom:0;
        margin:auto;
        width:68px;
        height:48px;
    }

    .videoImgBtnBg {
        transition: fill ease .3s;
    }

    .videoImgBtn:hover .videoImgBtnBg {
        fill:#f00;
    }

    /* 描述 */
    .descTitle {
        font-size: 18px;
        color: #000;
        line-height: 50px;
    }

    .detailInfo {
        margin-bottom: 10px;
    }

    .detailContent {
        border-top: 1px solid #E0E0E0;
        padding: 10px 0;
        font-size: 14px;
        line-height: 25px;
        color: #333;
    }

    /* 属性 */
    .attrInfos {
        margin-bottom: 30px;
    }

    /* 表格 */
    .table {
        border-top: 1px solid #E0E0E0;
        border-left: 1px solid #E0E0E0;
        font-size: 14px;
        line-height: 26px;
        color: #666666;
        margin-bottom: 20px;
    }

    .borderTd {
        border-bottom: 1px solid #E0E0E0;
        border-right: 1px solid #E0E0E0;
        padding: 10px;
    }

    /* 按钮 */
    .attrInfosBtnBox {
        text-align: center;
    }

    .attrInfosBtn {
        display: inline-block;
        cursor: pointer;
    }

    .attrInfosBtnTxt {
        display: inline-block;
        vertical-align: top;
        height: 22px;
        line-height: 22px;
        margin-right: 5px;
        font-size: 14px;
        color: #000;
        font-weight: bold;
    }

    .attrInfosBtnIconBox {
        display: inline-block;
        vertical-align: top;
        width: 22px;
        height: 22px;
        padding: 2px;
        border: 1px solid #fff3af;
        border-radius: 50%;
        box-sizing: 1px 1px 1px 1px #fff3af;
    }

    .attrInfosBtnIconBg {
        border-radius: 50%;
        width: 100%;
        height: 100%;
        background: #ffda00;
        line-height: 16px;
        text-align: center;
    }

    .attrInfosBtnIcon {
        font-size: 10px;
        font-weight: bold;
    }

    /* 图片 */
    .imageDetailBox {
        padding-bottom: 30px;
    }

    /* .imageDetail {
        width: 100%;
    } */
</style>
