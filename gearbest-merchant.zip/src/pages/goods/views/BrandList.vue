<template>
    <div>
        <el-form ref="form" :model="form" :class="$style.brandAll">
            <el-form-item :label="$t('goods.brand.brandSearch')" style="margin-bottom: 0;">
                <el-select
                    v-model="brandCode"
                    :placeholder="$t('goods.brand.brandAllSearch')"
                    :loading="brandLoading"
                    :remote-method="getBrandList"
                    style="margin-bottom: 0; width: 300px;"
                    clearable
                    remote
                    filterable
                    @focus="getBrandList('')"
                    @clear="getBrandList('')">
                    <el-option v-for="(item, index) in brandList" :key="index" :label="item.label" :value="item.value">
                        <span :class="$style.optionLeft">{{ item.label }}</span>
                        <span :class="$style.optionRight">{{ item.other }}</span>
                    </el-option>
                </el-select>
            </el-form-item>
        </el-form>
        <div :class="$style.container">
            <el-tabs v-model="activeName" type="border-card" @tab-click="handleClick">
                <el-tab-pane type="approveChild" name="approveChild">
                    <span slot="label">{{ $t('goods.brand.successCheck') }}<span>({{ approveNum }})</span></span>
                    <div>
                        <brand-tab-item ref="approveChild" :type="2" @changeNum="changeNum">
                        </brand-tab-item>
                    </div>
                </el-tab-pane>
                <el-tab-pane type="disApproveChild" name="disApproveChild">
                    <span slot="label">{{ $t('goods.brand.failCheck') }}<span>({{ disApproveNum }})</span></span>
                    <div>
                        <brand-tab-item ref="disApproveChild" :type="3" @changeNum="changeNum"></brand-tab-item>
                    </div>
                </el-tab-pane>
                <el-tab-pane type="checkChild" name="checkChild">
                    <span slot="label">{{ $t('goods.brand.waitACheck') }}<span>({{ checkNum }})</span></span>
                    <div>
                        <brand-tab-item ref="checkChild" :type="1" @changeNum="changeNum"></brand-tab-item>
                    </div>
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>

<script>
    import BrandTabItem from '../components/brand/BrandTabItem';
    import { serviceBrandListGet } from '../services/goods';

    export default {
        name: 'BrandAuthList',
        components: { BrandTabItem },
        data() {
            return {
                dialogVisible: true,
                approveNum: 0,
                disApproveNum: 0,
                checkNum: 0,
                activeName: 'approveChild',
                brandLoading: true,
                brandList: [],
                brandCode: '',
                form: {
                    name: ''
                }
            };
        },
        created() {
            this.init();
        },
        methods: {
            async init() {
                const { type } = this.$route.query;
                if (type === '1') {
                    this.activeName = 'checkChild';
                } else if (type === '2') {
                    this.activeName = 'approveChild';
                } else if (type === '3') {
                    this.activeName = 'disApproveChild';
                }
            },
            async getBrandList(name = '', brand_codes = '') {
                const { status, data } = await serviceBrandListGet.http({
                    params: {
                        is_all: 1,
                        page_index: 1,
                        page_size: 500,
                        review_status: 2,
                        name,
                        brand_codes
                    }
                });
                this.brandLoading = false;
                if (status === 0) {
                    this.brandList = data.list.map(item => ({
                        label: item.name_en,
                        value: item.id,
                        other: item.brand_owner
                    }));
                }
            },
            handleClick(tab, event) {
                console.log(tab.$attrs.type);
                const type = tab.$attrs.type;
                this.$refs[type].getDataFirstPage();
            },
            callChildFn(ref) {
                console.log(this.$refs[ref]);
            },
            changeNum(data) {
                if (data.type === 1) {
                    this.checkNum = data.total;
                } else if (data.type === 2) {
                    this.approveNum = data.total;
                } else if (data.type === 3) {
                    this.disApproveNum = data.total;
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    .brandAll{
        background: #fff;
        font-size: 14px;
        margin-bottom: 20px;
        padding: 30px 20px;
    }
    .container {
        background: #fff;
        font-size: 14px;
        padding: 30px 20px;
    }
    .optionLeft {
        float: left;
        padding-right: 10px;
        max-width: 300px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .optionRight{
        float: right;
        padding-left: 10px;
        max-width: 300px;
        color: var(--color-text-secondary );
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: right;
    }
</style>
