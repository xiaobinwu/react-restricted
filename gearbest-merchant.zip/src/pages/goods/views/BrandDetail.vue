<template>
    <layout-card
        :name="$t('goods.brand.add')">
        <div :class="$style.container">
            <div :class="$style.check">
                <span :class="$style.checkText">{{ $t('goods.brand.check') }}</span>
                <a :class="$style.download" :href="internalClassifyNoUrl" style="margin-right: 50px">{{ $t('goods.brand.internalClassifyNo') }}</a>
                <span :class="$style.checkText">{{ $t('goods.brand.check') }}</span>
                <a :class="$style.download" :href="standardUrl">{{ $t('goods.brand.platformStandard') }}</a>
            </div>
            <div v-if="brandForm.review_status === 3" :class="$style.remark">
                <el-alert :closable="false" type="warning">
                    {{ $t('goods.brand.reviewRemark') }}{{ brandForm.review_remark }}
                </el-alert>
            </div>
            <el-form ref="brandForm" :model="brandForm" :rules="rules" label-width="200px" label-suffix=":">
                <el-form-item :label="$t('goods.brand.EName')" prop="name_en">
                    <el-input v-model="brandForm.name_en" :disabled="isDisable"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.brand.CName')" prop="name_zh">
                    <el-input v-model="brandForm.name_zh" :disabled="isDisable"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.brand.brandOwner')" prop="brand_owner">
                    <el-input v-model="brandForm.brand_owner" :disabled="isDisable"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.brand.brandLogo')" prop="brand_logo">
                    <span :class="$style.logoTip">
                        {{ $t('goods.brand.brandLogoUploadTip') }}
                    </span>
                    <el-upload
                        :action="uploadUrl"
                        :show-file-list="false"
                        :on-success="handleAvatarSuccess"
                        :before-upload="beforeAvatarUpload"
                        :class="brandForm.brand_logo ? $style['avatar-uploader'] : ''"
                        :disabled="isDisable"
                        :data="imgData"
                        :with-credentials="true"
                        name="Filedata"
                        list-type="picture-card">
                        <img v-if="brandForm.brand_logo" :src="domainName + brandForm.brand_logo" :class="$style.avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <div v-for="(item, index) in brandForm.register_infos" :key="index" :class="$style.registerArr">
                    <el-form-item :label="$t('goods.brand.registerAddr')" :rules="[
                        { required: true, message: $t('goods.brand.registerAddrEmpty'), trigger: 'change' }
                    ]" :prop="'register_infos.'+index + '.register_addr'" :class="[$style.register]">
                        <el-select v-model="item.register_addr" :placeholder="$t('goods.select')"
                                   :disabled="isDisable" filterable style="width: 180px">
                            <el-option v-for="(itemCountry, indexCountry) in countryList"
                                       :key="indexCountry" :label="itemCountry.label" :value="itemCountry.value"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item :label="$t('goods.brand.brandCode')" :rules="[
                        { required: true, message: $t('goods.brand.registerNoEmpty'), trigger: 'blur' },
                        { pattern: /^[A-Za-z0-9][A-Za-z0-9]*$/,message: $t('goods.brand.brandRegisterNoFormat'),trigger: 'blur'},
                        {min: 1, max: 20, message: $t('goods.brand.20wordLimit'), trigger: 'blur'}
                    ]" :prop="'register_infos.'+index + '.register_no'" :class="[$style.register, $style.registerNo]">
                        <el-input v-model="item.register_no" :class="$style.registerInput" :disabled="isDisable"></el-input>
                    </el-form-item>
                    <el-form-item :label="$t('goods.brand.classifyNo')" :prop="'register_infos.'+index + '.register_classify_no'" :rules=" [
                        { required: true, message: $t('goods.brand.registerClassifyEmpty'), trigger: 'blur' },
                        { pattern: /^[0-9][0-9,]*$/,message: $t('goods.brand.brandClassifyNoFormat'),trigger: 'blur'},
                        {
                            min: 1, max: 500, message: $t('goods.brand.500wordLimit'), trigger: 'blur'
                        }
                    ]" :class="[$style.register,$style.registerNo]">
                        <el-input v-model="item.register_classify_no" :class="$style.registerInput" :disabled="isDisable"></el-input>
                    </el-form-item>
                    <el-button v-if="!isDisable" type="primary" size="mini" @click="addRegister(index)">{{ $t('goods.add') }}</el-button>
                    <el-button v-if="brandForm.register_infos.length > 1 && !isDisable" size="mini" type="danger" @click="deleteRegister(index)">
                        {{ $t('goods.delete') }}</el-button>
                </div>
                <el-form-item>
                    <el-button @click="resetForm('brandForm')">{{ $t('goods.back') }}</el-button>
                    <el-button v-if="!isDisable" type="primary" @click="submitForm('brandForm')">{{ $t('goods.submitCheck') }}</el-button>
                </el-form-item>
            </el-form>
            <el-dialog
                :visible.sync="isSettedDialog"
                center
                width="560px">
                <div :class="$style.center">
                    <div>{{ $t('goods.brand.brandAlreadyExist') }}</div>
                    <div style="margin-top: 36px">
                        <el-form ref="form" :model="form" :class="$style.brandAll" label-suffix=":">
                            <el-form-item :label="$t('goods.brand.brandDirCheck')" :rules="[
                                { required: true, message: this.$t('goods.brand.selectBrandEmpty'), trigger: 'change' }
                            ]" prop="brandCode">
                                <el-select v-model="form.brandCode" :placeholder="$t('goods.brand.brandAllSearch')"
                                           filterable style="margin-bottom: 0; width: 300px;">
                                    <el-option v-for="(item, index) in brandList" :key="index" :label="item.label" :value="item.value">
                                        <span :class="$style.optionLeft">{{ item.label }}</span>
                                        <span :class="$style.optionRight">{{ item.other }}</span>
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-form>
                    </div>
                </div>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" @click="confirm('form')">{{ $t('goods.brand.applyAuth') }}</el-button>
                </span>
            </el-dialog>
        </div>
    </layout-card>
</template>

<script>
    import {
        serviceBrandAdd, serviceBrandDetail, serviceBrandEdit, serviceGetTrademarks, serviceBrandListGet
    } from '../services/goods';
    import { getImgInfo } from '@/assets/js/utils/assist';
    import { UPLOAD_LOGO } from '@/assets/js/constant/env.js';

    export default {
        name: 'BrandAuthDetail',
        data() {
            return {
                id: null,
                name: '',
                standardUrl: 'http://seller.gearbest.net/storage/document/platform-audit-standards.docx',
                internalClassifyNoUrl: 'http://seller.gearbest.net/storage/document/international-classification-number.docx',
                form: {
                    brandCode: '',
                },
                imgData: {
                    keyid: 'fe74b137e9e0ee3a00ddea36c89c59df',
                    platform: 'productCenter'
                },
                brandForm: {
                    review_status: '',
                    review_remark: '',
                    name_zh: '',
                    name_en: '',
                    brand_owner: '',
                    register_infos: [{
                        register_addr: '',
                        register_no: '',
                        register_classify_no: '',
                        register_info_id: ''
                    }],
                    brand_logo: ''
                },
                isSettedDialog: false,
                countryList: [],
                isDisable: false,
                brandList: [],
                rules: {
                    name_zh: [
                        { required: true, message: this.$t('goods.brand.brandCNameEmpty'), trigger: 'blur' },
                        {
                            min: 1, max: 100, message: this.$t('goods.brand.100wordLimit'), trigger: 'blur'
                        },
                    ],
                    name_en: [
                        { required: true, message: this.$t('goods.brand.brandENameEmpty'), trigger: 'blur' },
                        {
                            min: 1, max: 100, message: this.$t('goods.brand.100wordLimit'), trigger: 'blur'
                        },
                        {
                            pattern: /^[^\u4e00-\u9fa5\s)][^\u4e00-\u9fa5]*$/,
                            message: this.$t('goods.brand.brandENameFormat'),
                            trigger: 'blur'
                        },
                    ],
                    brand_logo: [
                        { required: true, message: this.$t('goods.brand.brandLogoEmpty'), trigger: 'blur' },
                    ],
                    brand_owner: [
                        { required: true, message: this.$t('goods.brand.brandOwnerEmpty'), trigger: 'blur' },
                        {
                            min: 1, max: 100, message: this.$t('goods.brand.100wordLimit'), trigger: 'blur'
                        },
                        {
                            pattern: /^[\u4e00-\u9fa5A-Za-z][\u4e00-\u9fa5\sA-Za-z]*$/,
                            message: this.$t('goods.brand.brandOwnerFormat'),
                            trigger: 'blur'
                        },
                    ]
                },
                domainName: UPLOAD_LOGO,
                uploadUrl: 'image-manage/logo-upload',
            };
        },
        async created() {
            const { name, params, query } = this.$route;
            this.name = name;
            this.type = Number(query.type);
            this.getRegisterAddrs();
            if ((name === 'brandEdit' || name === 'brandDetail') && Object.prototype.hasOwnProperty.call(params, 'id')) {
                this.id = params.id;
                this.getDetail();
            } else {
                const { status, data } = await serviceBrandListGet.http({
                    params: {
                        is_all: 1,
                        page_index: 1,
                        page_size: 10000000,
                        review_status: 2
                    }
                });
                if (status === 0) {
                    this.brandList = data.list.map(item => ({
                        label: item.name_en,
                        value: item.brand_code,
                        other: item.brand_owner
                    }));
                }
            }
            if (name === 'brandDetail') {
                this.isDisable = true;
            }
        },
        methods: {
            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        const postData = {
                            name_zh: this.brandForm.name_zh,
                            name_en: this.brandForm.name_en,
                            names: JSON.stringify({
                                en: this.brandForm.name_en,
                                zh: this.brandForm.name_zh
                            }),
                            brand_logo: this.brandForm.brand_logo,
                            brand_owner: this.brandForm.brand_owner,
                            register_infos: this.brandForm.register_infos
                        };
                        if (this.name === 'brandEdit') {
                            this.editBrand(postData);
                        } else {
                            this.addBrand(postData);
                        }
                    }
                });
            },
            resetForm(formName) {
                this.$router.back();
            },
            async getRegisterAddrs() {
                const { status, data, msg } = await serviceGetTrademarks.http({});
                if (status === 0) {
                    console.log(data);
                    this.countryList = data.map(item => ({
                        label: item.area_name_zh,
                        value: item.area_code
                    }));
                } else {
                    this.$message.error(msg);
                }
            },
            async getDetail() {
                const { status, data } = await serviceBrandDetail.http({
                    params: {
                        id: this.id,
                        review_status: this.type
                    }
                });
                if (status === 0) {
                    this.brandForm.review_remark = data.review_remark;
                    this.brandForm.review_status = data.review_status;
                    this.brandForm.name_zh = data.name_zh;
                    this.brandForm.name_en = data.name_en;
                    this.brandForm.brand_logo = data.brand_logo;
                    this.brandForm.brand_owner = data.brand_owner;
                    this.brandForm.register_infos = data.register_infos.map(item => ({
                        register_info_id: item.id,
                        register_classify_no: item.register_classify_no,
                        register_no: item.register_no,
                        register_addr: item.register_addr
                    }));
                }
            },
            async addBrand(postData) {
                const { status, msg } = await serviceBrandAdd.http({
                    data: postData
                });
                if (status === 0) {
                    this.$message({
                        message: this.$t('goods.brand.brandSubmitSuccess'),
                        type: 'success'
                    });
                    this.$router.push({
                        name: 'brandList'
                    });
                } else if (status === 47001) {
                    this.isSettedDialog = true;
                } else {
                    this.$message.error(msg);
                }
            },
            async editBrand(postData) {
                postData.id = this.id;
                postData.review_status = this.type;
                const { status, msg } = await serviceBrandEdit.http({
                    data: postData
                });
                if (status === 0) {
                    this.$message({
                        message: this.$t('goods.brand.brandSubmitSuccess'),
                        type: 'success'
                    });
                    this.$router.push({
                        name: 'brandList'
                    });
                } else {
                    this.$message.error(msg);
                }
            },
            addRegister(index) {
                this.brandForm.register_infos.splice(index + 1, 0, {
                    register_addr: '',
                    register_no: '',
                    register_classify_no: '',
                    register_info_id: ''
                });
            },
            deleteRegister(index) {
                this.brandForm.register_infos.splice(index, 1);
            },
            handleAvatarSuccess(res, file) {
                if (res.code === 0) {
                    this.brandForm.brand_logo = res.data;
                } else {
                    this.$message.error(res.message);
                }
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg';
                let isFormat;
                if (isJPG) {
                    isFormat = getImgInfo(file).then((info) => {
                        console.log(info);
                        const isLt1M = info.size <= 1024;
                        const isWidth = info.width >= 300;
                        const isHeight = info.height >= 150;
                        const ratio = info.width / info.height;
                        let isEqualRatio1 = false;
                        if (ratio === 2) {
                            isEqualRatio1 = true;
                        }
                        const result = isLt1M && isWidth && isHeight && isEqualRatio1;
                        if (result) {
                            return Promise.resolve();
                        }
                        this.$message.error(this.$t('goods.brand.brandLogoUploadTip'));
                        return Promise.reject();
                    }, (error) => {
                        this.$message.error(this.$t('goods.brand.brandLogoUploadTip'));
                        return Promise.reject();
                    });
                } else {
                    this.$message.error(this.$t('goods.brand.brandLogoUploadTip'));
                }
                return isJPG && isFormat;
            },
            confirm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        this.$router.push({
                            name: 'brandAuthAdd',
                            query: {
                                brandCode: this.form.brandCode
                            }
                        });
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    .container {
        background: #fff;
        font-size: 14px;
        padding: 30px 20px;
    }
    .logoTip{
        font-size: 14px;
        color: var(--color-text-regular);
    }
    .center{
        text-align: center;
        font-size: 16px;
    }
    .check{
        margin: 0 0 30px 100px;
    }
    .remark {
        padding-bottom: 30px;
    }
    .checkText{
        margin-right: 6px;
    }
    .download {
        text-decoration: underline;
    }
    .register{
        display: inline-block;
    }
    .registerNo{
        :global {
            label{
                width: auto!important;
                padding-right: 6px!important;
            }
            .el-form-item__content {
                margin-left: auto!important;
                display: inline-block!important;
            }
        }
    }
    .registerInput{
        width: 140px;
    }
    .registerArr{
        :global {
            .el-button+.el-button {
                margin-left: 0px!important;
            }
        }
    }
    /*上传样式*/
    .avatar-uploader :global {
        .el-upload--picture-card {
            border: 0;
        }
    }
    .avatar {
        width: 80px;
        height: 80px;
        display: block;
    }
    .optionLeft {
        float: left;
        padding-right: 10px;
        max-width: 300px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .optionRight{
        float: right;
        padding-left: 10px;
        max-width: 300px;
        color: var(--color-text-secondary );
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: right;
    }
</style>
