<template>
    <div :class="$style.container">
        <div :class="$style.header">
            <el-form ref="searchForm" :inline="true" :model="searchForm" label-suffix="：">
                <el-form-item :label="$t('goods.goodsList.goodsTitle')">
                    <el-input v-model="searchForm.goodsTitle"></el-input>
                </el-form-item>
                <el-form-item label="spu">
                    <el-input v-model="searchForm.goodSpuList"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.statusUpdateTime')">
                    <el-date-picker
                        v-model="searchForm.statusChangeTimeMin"
                        :class="$style.date"
                        :placeholder="$t('goods.selectDate')"
                        value-format="timestamp"
                        type="date">
                    </el-date-picker>
                    {{ $t('goods.goodsList.zhi') }}
                    <el-date-picker
                        v-model="searchForm.statusChangeTimeMax"
                        :class="$style.date"
                        :placeholder="$t('goods.selectDate')"
                        value-format="timestamp"
                        type="date">
                    </el-date-picker>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.shopGoodCode')">
                    <el-input v-model="searchForm.shopGoodSnList"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.goodsCode')">
                    <el-input v-model="searchForm.goodSnList"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.dispatchMode')">
                    <el-select v-model="searchForm.deliveryType" :placeholder="$t('goods.select')">
                        <el-option :label="$t('goods.goodsList.all')" value=""></el-option>
                        <el-option :value="2" label="FBG"></el-option>
                        <el-option :label="$t('goods.goodsList.direct')" :value="1"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.saleStatus')">
                    <el-select v-model="searchForm.goodsStatus" :placeholder="$t('goods.select')">
                        <el-option :label="$t('goods.goodsList.all')" value=""></el-option>
                        <el-option :label="$t('goods.goodsList.up')" :value="2"></el-option>
                        <el-option :label="$t('goods.goodsList.down')" :value="3"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item :class="$style.btnGroup">
                    <el-button type="primary" @click="search">{{ $t('goods.search') }}</el-button>
                    <router-link :to="{ name: 'goodsAdd' }">
                        <el-button>{{ $t('goods.goodsList.addGoods') }}</el-button>
                    </router-link>
                </el-form-item>
            </el-form>
            <div class="">
                <PaginatedTable
                    v-loading="loading"
                    ref="approve"
                    :data="tableData"
                    :columns="tableColumns"
                    :pagination="pagination"
                    :span-method="objectSpanMethod"
                    :class="$style.table"
                    ref-dom="approveTable"
                    @pagesize-change="changePageSize"
                    @page-change="changePage"
                    @select="handleSelectionChange"
                    @select-all="handleAllSelectionChange"
                >
                    <template
                        slot="goodsTitle"
                        slot-scope="scope"
                    >
                        <a :href="scope.row.goodsUrl" target="_blank">{{ scope.row.goodsTitle }}</a>
                    </template>
                    <template
                        slot="platformCategory"
                        slot-scope="scope"
                    >
                        <span>{{ scope.row.platformCategoryPath }}</span>
                    </template>
                    <template
                        slot="selectSku"
                        slot-scope="scope"
                    >
                        <el-checkbox v-model="scope.row.selectSku" @change="(value) => {
                            changeSkuSelect(value, scope.row)
                        }"></el-checkbox>
                    </template>
                    <template
                        slot="goodsInfo"
                        slot-scope="scope"
                    >
                        <div :class="$style.goodsInfo">
                            <div :class="$style.imageDiv">
                                <img :class="$style.image" :src="scope.row.goodsInfo.thumbUrl"/>
                            </div>
                            <div :class="$style.goodsAttr">
                                <div v-for="(item, index) in scope.row.goodsInfo.attrs" :key="index">
                                    {{ item.attrName }}: {{ item.attrValueAlias || item.attrValue }}
                                </div>
                            </div>
                        </div>
                    </template>
                    <template
                        slot="price"
                        slot-scope="scope"
                    >
                        <a @click="dialogChangePriceAndStock(scope.row,0)">${{ scope.row.price }} </a>
                    </template>
                    <template
                        slot="storage"
                        slot-scope="scope"
                    >
                        <a v-if="scope.row.dispatchModeCode === 1" @click="dialogChangePriceAndStock(scope.row,1)">{{ scope.row.storage }} </a>
                        <span v-else>{{ scope.row.storage }} </span>
                    </template>
                    <template
                        slot="goodsStatus"
                        slot-scope="scope"
                    >
                        <span v-if="scope.row.goodsStatus === 2">{{ $t('goods.goodsList.up') }}</span>
                        <span v-if="scope.row.goodsStatus === 3">{{ $t('goods.goodsList.down') }}</span>
                    </template>
                    <template
                        slot="operate"
                        slot-scope="scope"
                    >
                        <div>
                            <a v-if="scope.row.goodsStatus === 2" @click="approveTableEvent(0,3,scope.row)">{{ $t('goods.goodsList.down') }}</a>
                            <a v-if="scope.row.goodsStatus === 3 && scope.row.isUpGoods"
                               @click="approveTableEvent(2,2,scope.row)">
                                {{ $t('goods.goodsList.up') }}
                            </a>
                            <span v-if="scope.row.goodsStatus === 3 && !scope.row.isUpGoods"
                                  :class="$style.disable">
                                {{ $t('goods.goodsList.up') }}
                            </span>
                        </div>
                        <div>
                            <router-link :to="{ name: 'goodsEditor', query: { product_id: scope.row.spu, review_type: 4 }}">
                                {{ $t('goods.edit') }}
                            </router-link>
                        </div>
                    </template>

                    <div slot="headerBatch" :class="$style.headerBatch">
                        <el-button :disabled="isBatch" size="mini" type="danger" @click="approveTableEvent(3,2)">
                            {{ $t('goods.goodsList.up') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="approveTableEvent(1,3)">
                            {{ $t('goods.goodsList.down') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="dialogSetFreight">
                            {{ $t('goods.goodsList.setFreightTemplate') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="copySKU">
                            {{ $t('goods.goodsList.copySKU') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="copySPU">
                            {{ $t('goods.goodsList.copySPU') }}
                        </el-button>
                    </div>
                    <div slot="bottomBatch" :class="$style.bottomBatch">
                        <el-button :disabled="isBatch" size="mini" type="danger" @click="approveTableEvent(3,2)">
                            {{ $t('goods.goodsList.up') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="approveTableEvent(1,3)">
                            {{ $t('goods.goodsList.down') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="dialogSetFreight">
                            {{ $t('goods.goodsList.setFreightTemplate') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="copySKU">
                            {{ $t('goods.goodsList.copySKU') }}
                        </el-button>
                        <el-button :disabled="isBatch" size="mini" type="primary" @click="copySPU">
                            {{ $t('goods.goodsList.copySPU') }}
                        </el-button>
                    </div>
                </PaginatedTable>
                <!--todo: 把弹出框挪出做组件-->
                <!--批量设置运费模板弹框-->
                <el-dialog
                    :visible.sync="freightDialogVisible"
                    :title="$t('goods.goodsList.setFreightModule')"
                    :custom-class="$style.dialogFreight"
                    width="560px">
                    <div :class="$style.center">
                        <el-form ref="freightForm" :model="freightForm" :rules="freightFormRules" label-width="160px" label-suffix=":">
                            <el-form-item :label="$t('goods.goodsList.userFreightModule')" :class="$style.freightSelect" prop="shipTemplateCode">
                                <el-select v-model="freightForm.shipTemplateCode" :placeholder="$t('goods.select')" style="width: 300px">
                                    <el-option v-for="(item, index) in freightModuleArr" :key="index"
                                               :label="item.name" :value="item.id"></el-option>
                                </el-select>
                            </el-form-item>
                            <div :class="$style.freightTip">
                                {{ $t('goods.goodsList.selectFreightTip') }}
                            </div>
                        </el-form>
                    </div>
                    <span slot="footer" :class="$style.center">
                        <el-button @click="freightDialogVisible = false">{{ $t('goods.cancel') }}</el-button>
                        <el-button type="primary" @click="freightConfirm()">{{ $t('goods.confirm') }}</el-button>
                    </span>
                </el-dialog>
                <!--批量设置上下架-->
                <el-dialog
                    :visible.sync="statusDialogVisible"
                    :title="handleGoodsStatusTip[handleGoodsStatusTipIndex]"
                    :custom-class="$style.dialogFreight"
                    width="560px"
                    @close="() => {
                        $refs.statusForm.resetFields();
                }">
                    <div :class="$style.center">
                        <el-form ref="statusForm" :model="statusForm" label-width="160px" label-suffix=":">
                            <div v-if="handleGoodsStatusTipIndex===1 || handleGoodsStatusTipIndex===3"
                                 :class="$style.statusTip" :style="handleGoodsStatusTipIndex===3 ? {marginLeft: 0,textAlign:'center'}:null">
                                {{ $t('goods.goodsList.batchUpDownNum', [selectStatusType===2 ? '上':'下', selectRow.length]) }}
                            </div>
                            <el-form-item v-if="selectStatusType === 3" :label="$t('goods.goodsList.downReason')"
                                          :class="$style.freightSelect" :rules="[
                                              { required: false, message: this.$t('goods.goodsList.emptyDownReason'), trigger: 'blur' },
                            ]" prop="downReason">
                                <el-input v-model="statusForm.downReason" style="width: 300px"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <span slot="footer" :class="$style.center">
                        <el-button @click="statusDialogVisible = false">{{ $t('goods.cancel') }}</el-button>
                        <el-button type="primary" @click="statusConfirm()">{{ $t('goods.confirm') }}</el-button>
                    </span>
                </el-dialog>
                <!--设置单个商品价格和库存-->
                <el-dialog
                    :visible.sync="priceDialogVisible"
                    :title="priceAndStorageTitle[priceAndStorageIndex]"
                    width="560px"
                    @close="() => {
                        $refs.priceAndStorageForm.resetFields();
                }">
                    <div>
                        <ul>
                            <li :class="$style.info">
                                <div :class="$style.infoKey">
                                    {{ $t('goods.goodsList.goodsCode') }}
                                </div>
                                <div :class="$style.infoValue">
                                    {{ selectOneRow.sku }}
                                </div>
                            </li>
                            <li :class="$style.info">
                                <div :class="$style.infoKey">
                                    {{ $t('goods.goodsList.shopGoodCode') }}
                                </div>
                                <div :class="$style.infoValue">
                                    {{ selectOneRow.shopGoodCode }}
                                </div>
                            </li>
                            <li :class="$style.info">
                                <div :class="$style.infoKey">
                                    {{ $t('goods.goodsList.specification') }}
                                </div>
                                <div :class="$style.infoValue">
                                    {{ selectOneRow.sku }}
                                </div>
                            </li>
                        </ul>
                        <el-form ref="priceAndStorageForm" :model="priceAndStorageForm" label-width="110px" label-suffix=":">
                            <el-form-item :rules="priceAndStorageIndex===0?priceRules:stockRules"
                                          :label="priceAndStorageIndex===0?$t('goods.goodsList.price'):$t('goods.goodsList.storage')" prop="num">
                                <el-input v-model="priceAndStorageForm.num" style="width: 300px"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <span slot="footer" :class="$style.center">
                        <el-button @click="priceDialogVisible = false">{{ $t('goods.cancel') }}</el-button>
                        <el-button type="primary" @click="priceAndStockConfirm()">{{ $t('goods.confirm') }}</el-button>
                    </span>
                </el-dialog>
            </div>
        </div>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';
    import { clipboard } from '@/assets/js/utils/assist';
    import PaginatedTable from '../../../components/PaginatedTable.vue';
    import {
        serviceApproveGoodsList, serviceGetFreightList, serviceChangeFreight, serviceUpAndDownGoods, serviceChangePrice, serviceChangeStorage
    } from '../../../services/goods';
    import { storeDeliverMode } from '../../../services/logisitics';

    export default {
        name: 'GoodsApproveTab',
        components: { PaginatedTable },
        props: {
            type: {
                type: Number,
                default() {
                    return null;
                }
            },
            open: {
                type: String,
                default: ''
            }
        },
        data() {
            const priceValidatePass = (rule, value, callback) => {
                if (value > Number(1000000)) {
                    callback(new Error(this.$t('goods.goodsList.priceNumberErr')));
                } else {
                    callback();
                }
            };
            const stockValidatePass = (rule, value, callback) => {
                if (value > Number(1000000)) {
                    callback(new Error(this.$t('goods.goodsList.stockNumberErr')));
                } else {
                    callback();
                }
            };
            return {
                searchForm: {
                    goodsTitle: '',
                    goodSpuList: '',
                    statusChangeTimeMin: '',
                    statusChangeTimeMax: '',
                    shopGoodSnList: '',
                    goodSnList: '',
                    deliveryType: '',
                    goodsStatus: ''
                },
                // 设置运费模板的校验
                freightForm: {
                    shipTemplateCode: ''
                },
                freightFormRules: {
                    shipTemplateCode: [{ required: true, message: this.$t('goods.goodsList.selectFreight'), trigger: 'change' }]
                },
                freightDialogVisible: false,
                loading1: true,
                storeIsDirect: false,
                tableData: [],
                loading: false,
                rowData: {},
                tableColumns: [
                    {
                        label: '',
                        prop: 'spuSelect',
                        type: 'selection',
                        width: '55px',
                        align: 'center',
                        'header-align': 'center',
                        fixed: 'left',
                    },
                    {
                        label: this.$t('goods.goodsList.goodsTitle'),
                        prop: 'goodsTitle',
                        showSlot: true,
                        width: '250px',
                        scope: true,
                        align: 'center',
                        'header-align': 'center',
                        fixed: 'left',
                    },
                    {
                        label: this.$t('goods.goodsList.platformCategory'),
                        prop: 'platformCategory',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: 'spu',
                        prop: 'spu',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: '',
                        prop: 'selectSku',
                        width: '55px',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.goodsInfo'),
                        prop: 'goodsInfo',
                        showSlot: true,
                        scope: true,
                        width: '200px',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.freightTemplate'),
                        prop: 'shipTemplateName',
                        align: 'center',
                        'header-align': 'center',
                    },
                    {
                        label: this.$t('goods.goodsList.price'),
                        prop: 'price',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.shopGoodCode'),
                        prop: 'shopGoodCode',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.goodsCode'),
                        prop: 'sku',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.storage'),
                        prop: 'storage',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.dispatchMode'),
                        prop: 'dispatchMode',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.status'),
                        prop: 'goodsStatus',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.statusUpdateTime'),
                        prop: 'statusUpdateTime',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.remark'),
                        prop: 'remark',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.operate'),
                        showSlot: true,
                        scope: true,
                        prop: 'operate',
                        align: 'center',
                        fixed: 'right',
                        'header-align': 'center'
                    },
                ],
                pagination: {
                    pageNo: 1,
                    pageSize: 20,
                    totalCount: 0
                },
                rowIndex: '-1',
                sortDataIndex: [], // 对列表相同spu的排序在一起
                spuIndexArr: [], // 切分表格
                selectRow: [], // 被选择的行的数据
                freightModuleArr: [], // 模板数组
                isBatch: true, // 批量按钮是否可用
                handleGoodsStatusTip: [ // 弹框顶部标题
                    this.$t('goods.goodsList.downStatusTip'),
                    this.$t('goods.goodsList.batchDownStatusTip'),
                    this.$t('goods.goodsList.upStatusTip'),
                    this.$t('goods.goodsList.batchUpStatus'),
                ],
                handleGoodsStatusTipIndex: 0, // 用于标志使用哪个方式上下架, 0表示单品上架，1表示批量上架，2表示单品下架，3表示批量下架
                statusDialogVisible: false, // 上下架弹出框
                statusForm: { // 下架表单
                    downReason: ''
                },
                selectStatusType: 2, // 2表示上架，3表示下架
                selectOneRow: {}, // 单选行数据
                priceDialogVisible: false, // 设置单个商品的弹出框
                priceAndStorageIndex: 0, // 0表示修改价格，1表示修改库存数，
                priceAndStorageTitle: [ // 修改价格和库存弹出框标题
                    this.$t('goods.goodsList.changePrice'),
                    this.$t('goods.goodsList.changeStock')
                ],
                priceAndStorageForm: { // 修改价格和库存表单
                    num: 0
                },
                priceRules: [ // 价格校验
                    { required: true, message: this.$t('goods.goodsList.priceNumberErr'), trigger: 'blur' },
                    { pattern: /^[1-9]\d*$|^\d+(\.\d{1,2})$/, message: this.$t('goods.goodsList.priceNumberErr'), trigger: 'blur' },
                    { validator: priceValidatePass, trigger: 'blur' }
                ],
                stockRules: [ // 库存校验
                    { required: true, message: this.$t('goods.goodsList.stockNumberErr'), trigger: 'blur' },
                    { pattern: /^[1-9]\d*$|0$/, message: this.$t('goods.goodsList.stockNumberErr'), trigger: 'blur' },
                    { validator: stockValidatePass, trigger: 'blur' }
                ]
            };
        },
        watch: {
            selectRow() {
                this.isBatch = !(this.selectRow.length > 0);
            }
        },
        created() {
            this.init();
        },
        methods: {
            async init() {
                const {
                    title, spu, goodSn, shopGoodSn, startTime, endTime, deliveryType, goodsStatus, pageNo, pageSize
                } = this.$route.query;
                await this.getStoreMode();
                this.pagination.pageNo = Number(pageNo) || 1;
                this.pagination.pageSize = Number(pageSize) || 20;
                this.searchForm.goodsTitle = title;
                this.searchForm.goodSpuList = spu;
                this.searchForm.goodSnList = goodSn;
                this.searchForm.statusChangeTimeMin = startTime;
                this.searchForm.statusChangeTimeMax = endTime;
                this.searchForm.shopGoodSnList = shopGoodSn;
                this.searchForm.deliveryType = Number(deliveryType) || '';
                this.searchForm.goodsStatus = Number(goodsStatus) || '';
                this.loading = true;
                await this.getList();
            },

            search() {
                this.pagination.pageNo = 1;
                this.getList();
                this.turnUrl();
            },

            //  获取店铺发货模式
            async getStoreMode() {
                const { status, data, msg } = await storeDeliverMode.http();
                if (status === 0) {
                    if (!data.isOpenDirectMode) {
                        this.storeIsDirect = false;
                    } else {
                        this.storeIsDirect = true;
                    }
                } else {
                    this.$message.error(msg);
                }
            },

            // tab切换的回调函数
            getDataFirstPage() {
                this.initData();
                this.getList();
                this.turnUrl();
            },

            // 清空搜索数据
            initData() {
                this.pagination.pageNo = 1;
                this.pagination.pageSize = 20;
                this.searchForm.goodsTitle = '';
                this.searchForm.goodSpuList = '';
                this.searchForm.goodSnList = '';
                this.searchForm.statusChangeTimeMin = '';
                this.searchForm.statusChangeTimeMax = '';
                this.searchForm.shopGoodSnList = '';
                this.searchForm.deliveryType = '';
                this.searchForm.goodsStatus = '';
            },

            async getList() {
                this.tableData = [];
                this.loading = true;
                const { data, status } = await this.serviceGetList({
                    page: this.pagination.pageNo,
                    pageSize: this.pagination.pageSize,
                    searchForm: this.searchForm
                });
                this.loading = false;
                this.handleList({ data, status });
            },

            async serviceGetList({
                page = 1, pageSize = 20, searchForm
            }) {
                const res = await serviceApproveGoodsList.http({
                    params: {
                        pageNo: page,
                        pageSize,
                        goodsTitle: this.searchForm.goodsTitle,
                        goodSpuList: this.searchForm.goodSpuList,
                        statusChangeTimeMin: this.searchForm.statusChangeTimeMin ? this.searchForm.statusChangeTimeMin / 1000 : '',
                        statusChangeTimeMax: this.searchForm.statusChangeTimeMax ? this.searchForm.statusChangeTimeMax / 1000 : '',
                        shopGoodSnList: this.searchForm.shopGoodSnList,
                        goodSnList: this.searchForm.goodSnList,
                        deliveryType: this.searchForm.deliveryType,
                        goodsStatus: this.searchForm.goodsStatus
                    },
                });
                return res;
            },

            handleList({ status, data }) {
                if (status === 0) {
                    data.list.forEach((item, index) => {
                        const goodsStatusItem = item.goodsStatusList[0];
                        const obj = {
                            goodsUrl: item.goodsUrl,
                            goodsTitle: item.goodsTitle,
                            platformCategory: item.platformCategoryPath.path,
                            spu: item.goodSpu,
                            sku: item.goodSn,
                            virWhCode: item.virWhCode,
                            price: item.goodsPrice || 0,
                            shopGoodCode: item.shopGoodSn,
                            storage: item.stockNum,
                            dispatchModeCode: item.deliveryType,
                            shipTemplateName: item.shipTemplateName,
                            statusUpdateTime: goodsStatusItem ? dateFormat(goodsStatusItem.statusUpdateTime, 'yyyy-MM-dd hh:mm:ss') : '',
                            goodsStatus: goodsStatusItem ? goodsStatusItem.goodsStatus : '',
                            selectSku: false,
                            remark: goodsStatusItem
                                ? goodsStatusItem.upDownReasonMark === '新品同步'
                                    ? '审核通过待上架'
                                    : goodsStatusItem.upDownReasonMark
                                : '',
                            remarkType: goodsStatusItem ? goodsStatusItem.upDownReasonType : ''
                        };
                        if (item.deliveryType === 1) {
                            obj.dispatchMode = this.$t('goods.goodsList.direct');
                        } else if (item.deliveryType === 2) {
                            obj.dispatchMode = 'FBG';
                        } else {
                            obj.dispatchMode = '';
                        }
                        // 平台下架
                        if (obj.remarkType === 14 || obj.remarkType === 15 || obj.remarkType === 16) {
                            obj.remark = this.$t('goods.goodsList.platformDown');
                            obj.platformNotUpGoods = true;
                        } else {
                            obj.platformNotUpGoods = false;
                        }
                        // 如果是fbg商店，并且商品的发货模式是非fbg，则不能上架
                        if (!this.storeIsDirect && item.deliveryType !== 2) {
                            obj.storeTypeIsUpGoods = false;
                        } else {
                            obj.storeTypeIsUpGoods = true;
                        }
                        // 根据平台下架或者店铺的模式判断这个商品是否可以上架
                        if (obj.platformNotUpGoods || !obj.storeTypeIsUpGoods) {
                            obj.isUpGoods = false;
                        } else {
                            obj.isUpGoods = true;
                        }
                        obj.goodsInfo = {
                            thumbUrl: item.goodsMainImage ? item.goodsMainImage.thumbUrl : '',
                            attrs: item.goodsAttrList ? item.goodsAttrList : []
                        };
                        this.tableData.push(obj);
                    });
                    this.sortDataArr();
                    this.getOrderNumber();
                    this.$emit('changeNum', {
                        type: this.type,
                        total: data.totalCount
                    });
                    this.pagination.totalCount = data.totalCount;
                }
            },

            // 对相同sku排在一起整理
            sortDataArr() {
                this.sortDataIndex = [];
                const OrderObj = {};
                this.tableData.forEach((element, index) => {
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    this.sortDataIndex.push(OrderObj[k]);
                }
                const dataArr = [];
                for (let i = 0; i < this.sortDataIndex.length; i += 1) {
                    const element = this.sortDataIndex[i];
                    for (let j = 0; j < element.length; j += 1) {
                        dataArr.push(this.tableData[element[j]]);
                    }
                }
                this.tableData = dataArr;
            },

            // 获取相同的spu的数组
            getOrderNumber() {
                const OrderObj = {};
                this.sortDataIndex = [];
                this.spuIndexArr = [];
                this.tableData.forEach((element, index) => {
                    element.rowIndex = index;
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    // if (OrderObj[k].length > 1) {
                    this.spuIndexArr.push(OrderObj[k]);
                    // }
                }
            },

            objectSpanMethod({
                row, column, rowIndex, columnIndex
            }) {
                if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2 || columnIndex === 3) {
                    for (let i = 0; i < this.spuIndexArr.length; i += 1) {
                        const element = this.spuIndexArr[i];
                        for (let j = 0; j < element.length; j += 1) {
                            const item = element[j];
                            if (rowIndex === item) {
                                row.group = i;
                                if (j === 0) {
                                    return {
                                        rowspan: element.length,
                                        colspan: 1
                                    };
                                } if (j !== 0) {
                                    return {
                                        rowspan: 0,
                                        colspan: 0
                                    };
                                }
                            }
                        }
                    }
                }
                return {
                    rowspan: 1,
                    colspan: 1
                };
            },

            // sku勾选变化
            changeSkuSelect(value, row) {
                const item = this.spuIndexArr[row.group];
                if (value) {
                    for (let i = 0; i < item.length; i += 1) {
                        if (this.tableData[item[i]].selectSku === false) {
                            this.$refs.approve.$refs.approveTable.toggleRowSelection(this.tableData[item[0]], false);
                            this.tableData[item[0]].selectSPU = false;
                            this.selectRowData();
                            return;
                        }
                    }
                    this.$refs.approve.$refs.approveTable.toggleRowSelection(this.tableData[item[0]], true);
                    this.tableData[item[0]].selectSPU = true;
                } else {
                    this.$refs.approve.$refs.approveTable.toggleRowSelection(this.tableData[item[0]], false);
                    this.tableData[item[0]].selectSPU = false;
                }
                this.selectRowData();
            },

            // spu勾选变化
            handleSelectionChange(selection, row) {
                const flag = selection.includes(row);
                const element = this.spuIndexArr[row.group];
                if (flag) {
                    for (let i = 0; i < element.length; i += 1) {
                        this.tableData[element[i]].selectSku = true;
                        this.tableData[element[i]].selectSPU = true;
                        this.$refs.approve.$refs.approveTable.toggleRowSelection(this.tableData[element[i]], true);
                    }
                } else {
                    for (let i = 0; i < element.length; i += 1) {
                        this.tableData[element[i]].selectSku = false;
                        this.tableData[element[i]].selectSPU = false;
                        this.$refs.approve.$refs.approveTable.toggleRowSelection(this.tableData[element[i]], false);
                    }
                }
                this.selectRowData();
            },

            // 勾选全选和取消全选的变化
            handleAllSelectionChange(selection) {
                if (selection.length) {
                    for (let i = 0; i < this.tableData.length; i += 1) {
                        this.tableData[i].selectSku = true;
                        this.tableData[i].selectSPU = true;
                    }
                } else {
                    for (let i = 0; i < this.tableData.length; i += 1) {
                        this.tableData[i].selectSku = false;
                        this.tableData[i].selectSPU = true;
                    }
                }
                this.selectRowData();
            },

            async dialogSetFreight() {
                let flag;
                for (let i = 0; i < this.selectRow.length; i += 1) {
                    if (i !== 0) {
                        if (flag !== this.selectRow[i].dispatchModeCode) {
                            this.$message.error(this.$t('goods.goodsList.setFreightError'));
                            return;
                        }
                    } else {
                        flag = this.selectRow[i].dispatchModeCode;
                    }
                }
                this.freightDialogVisible = true;
                const { status, data, msg } = await serviceGetFreightList.http({
                    params: {
                        type: flag + 1 // 2表示直发，3表示fbg
                    }
                });
                if (status === 0) {
                    this.freightModuleArr = data;
                } else {
                    this.$message.error(msg);
                }
            },

            // 检查被选中的数据
            selectRowData() {
                this.selectRow = [];
                this.tableData.forEach((item, index) => {
                    if (item.selectSku) {
                        this.selectRow.push(item);
                    }
                });
            },

            // 运费模板确认
            freightConfirm() {
                const goodSnList = this.selectRow.map((item, index) => item.sku);
                this.$refs.freightForm.validate(async (valid) => {
                    if (valid) {
                        const { status, msg } = await serviceChangeFreight.http({
                            data: {
                                goodSnList,
                                shipTemplateCode: this.freightForm.shipTemplateCode
                            }
                        });
                        if (status === 0) {
                            this.$message({
                                message: this.$t('goods.setSuccess'),
                                type: 'success'
                            });
                            this.freightDialogVisible = false;
                            this.getList();
                        } else {
                            this.$message.error(msg);
                        }
                    }
                });
            },

            // 上下架弹出框
            approveTableEvent(index, selectStatusType, row) {
                console.log(this.selectRow);
                const notGoodsUpArr = [];
                if (index === 3) {
                    for (let i = 0; i < this.selectRow.length; i += 1) {
                        if (!this.selectRow[i].isUpGoods) {
                            notGoodsUpArr.push(this.selectRow[i].sku);
                        }
                    }
                    if (notGoodsUpArr.length) {
                        return this.$message({
                            message: this.$t('goods.goodsList.notUpGoods', [notGoodsUpArr]),
                            type: 'error',
                            customClass: 'errorInfo'
                        });
                    }
                }
                this.selectStatusType = selectStatusType;
                this.handleGoodsStatusTipIndex = index;
                this.statusDialogVisible = true;
                if (index === 0 || index === 2) {
                    this.selectOneRow = row;
                }
                return true;
            },

            // 商品状态确认
            statusConfirm() {
                this.$refs.statusForm.validate(async (valid) => {
                    if (valid) {
                        let goodSnAndVirWhCodeList;
                        if (this.handleGoodsStatusTipIndex === 0 || this.handleGoodsStatusTipIndex === 2) {
                            goodSnAndVirWhCodeList = [{
                                goodSn: this.selectOneRow.sku,
                                virWhCode: this.selectOneRow.virWhCode
                            }];
                        } else {
                            goodSnAndVirWhCodeList = this.selectRow.map(item => ({
                                goodSn: item.sku,
                                virWhCode: item.virWhCode
                            }));
                        }
                        const { status, msg } = await serviceUpAndDownGoods.http({
                            data: {
                                goodsStatus: this.selectStatusType,
                                goodSnAndVirWhCodeList,
                                reasonMark: this.statusForm.downReason
                            }
                        });
                        if (status === 0) {
                            this.$message({
                                message: this.$t('goods.setSuccess'),
                                type: 'success'
                            });
                            this.getList();
                        } else {
                            this.$message({
                                message: msg,
                                type: 'error',
                                customClass: 'errorInfo'
                            });
                        }
                        this.statusDialogVisible = false;
                        this.$refs.statusForm.resetFields();
                    }
                });
            },

            // 改变商品价格和库存弹出框
            dialogChangePriceAndStock(row, index) {
                this.priceDialogVisible = true;
                this.selectOneRow = row;
                this.priceAndStorageIndex = index;
                if (index === 0) {
                    this.priceAndStorageForm.num = row.price;
                } else {
                    this.priceAndStorageForm.num = row.storage;
                }
            },

            // 价格和库存确认按钮
            priceAndStockConfirm() {
                let postData;
                let res;
                this.$refs.priceAndStorageForm.validate(async (valid) => {
                    if (valid) {
                        if (this.priceAndStorageIndex === 0) {
                            postData = {
                                priceList: [{
                                    goodSn: this.selectOneRow.sku,
                                    virWhCode: this.selectOneRow.virWhCode,
                                    goodsPrice: this.priceAndStorageForm.num
                                }]
                            };
                            res = await serviceChangePrice.http({
                                data: postData
                            });
                        } else {
                            postData = {
                                directSendStock: [{
                                    goodSn: this.selectOneRow.sku,
                                    virWhCode: this.selectOneRow.virWhCode,
                                    stockNum: this.priceAndStorageForm.num
                                }]
                            };
                            res = await serviceChangeStorage.http({
                                data: postData
                            });
                        }
                        if (res.status === 0) {
                            this.$message({
                                message: this.$t('goods.setSuccess'),
                                type: 'success'
                            });
                            this.getList();
                        } else {
                            this.$message.error(res.msg);
                        }
                        this.priceDialogVisible = false;
                    }
                });
            },

            turnUrl() {
                this.$router.replace({
                    name: 'goodsList',
                    query: {
                        type: this.type,
                        pageSize: this.pagination.pageSize,
                        pageNo: this.pagination.pageNo,
                        title: this.searchForm.goodsTitle,
                        spu: this.searchForm.goodSpuList,
                        goodSn: this.searchForm.goodSnList,
                        startTime: this.searchForm.statusChangeTimeMin,
                        endTime: this.searchForm.statusChangeTimeMax,
                        shopGoodSn: this.searchForm.shopGoodSnList,
                        deliveryType: this.searchForm.deliveryType,
                        goodsStatus: this.searchForm.goodsStatus
                    }
                });
            },

            // 分页事件
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
                this.getList();
            },

            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
                this.getList();
            },

            // 复制SKU - 优选复制选中项否则全部
            copySKU() {
                const data = this.selectRow;
                const sku = data.map(item => item.sku);
                const res = clipboard(sku.join(','));

                if (!data.length) {
                    return this.$message.warning(this.$t('goods.selectSKUTips'));
                }

                if (res) {
                    this.$message.success(this.$t('goods.copySuccess'));
                } else {
                    this.$message.error(this.$t('goods.coppyFail'));
                }

                return sku;
            },

            // 复制SPU - 优选复制选中项否则全部
            copySPU() {
                const data = [];

                this.selectRow.forEach(({ selectSPU, spu }) => {
                    if (selectSPU && !data.includes(spu)) {
                        data.push(spu);
                    }
                });

                if (!data.length) {
                    return this.$message.warning(this.$t('goods.selectSPUTips'));
                }

                const res = clipboard(data.join(','));

                if (res) {
                    this.$message.success(this.$t('goods.copySuccess'));
                } else {
                    this.$message.error(this.$t('goods.copyFail'));
                }

                return data;
            }
        },
    };
</script>

<style module>
    @import 'variable.css';
    .container{
        font-size: 14px;
        color: #000;
    }
    .header{
        margin-bottom: 20px;
    }
    .input {
        width: 150px;
    }
    .header .date{
        width: 140px;
    }
    .goodsInfo{
        position: relative;
        min-height: 50px;
    }
    .imageDiv{
        height: 100%;
        vertical-align: middle;
    }
    .image {
        position: absolute;
        width: 50px;
        height: 50px;
        top: 50%;
        transform: translateY(-50%);
    }
    .goodsAttr{
        display: inline-block;
        margin-left: 60px;
        vertical-align: middle;
    }
    /*.btnGroup{*/
        /*float: right;*/
    /*}*/
    .dialogFreight{
        :global .el-dialog__footer{
            text-align: center;
        }
    }
    .freightTip{
        margin-left: 160px;
        font-size: 14px;
        color: #000;
        text-align: left;
    }
    .freightSelect{
        text-align: left;
    }
    :global .el-dialog__body {
        padding: 0 20px 10px;
    }
    .headerBatch{
        padding: 12px 16px;
        border: 1px solid var(--border-color-base);
        border-bottom: 0;
    }
    .bottomBatch {
        padding: 12px 16px;
        border: 1px solid var(--border-color-base);
        border-top: 0;
    }
    .statusTip{
        margin-left: 160px;
        font-size: 14px;
        color: #000;
        text-align: left;
        margin-bottom: 4px;
    }
    .searchBtn{
        margin-left: 20px;
    }
    .delete{
        color: #ff5757;
    }
    .center{
        text-align: center;
        font-size: 16px;
    }
    .info{
        line-height: 40px;
    }
    .infoKey{
        display: inline-block;
        min-width: 110px;
        font-size: 14px;
        color: #999;
        text-align: right;
    }
    .infoValue{
        display: inline-block;
        font-size: 14px;
        color: #000;
        margin-left: 38px;
    }
    .table {
        :global .el-table {
            border: 1px var(--border-color-base) solid;
        }
    }
    .disable, .disable:hover, .disable:focus {
        color: var(--color-text-secondary);
        cursor: auto;
    }
    :global .errorInfo{
        max-width: 1200px;
    }
</style>
