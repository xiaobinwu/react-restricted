<template>
    <div :class="$style.container">
        <div :class="$style.header">
            <el-form ref="searchForm" :inline="true" :model="searchForm" label-suffix="：">
                <el-form-item :label="$t('goods.goodsList.goodsTitle')">
                    <el-input v-model="searchForm.goodsTitle" :class="$style.input"></el-input>
                </el-form-item>
                <el-form-item label="spu">
                    <el-input v-model="searchForm.goodSpuList" :class="$style.input"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.shopGoodCode')">
                    <el-input :class="$style.input" v-model="searchForm.shopGoodSnList"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.goodsCode')">
                    <el-input :class="$style.input" v-model="searchForm.goodSnList"></el-input>
                </el-form-item>
                <el-form-item :class="$style.btnGroup">
                    <el-button type="primary" @click="search">{{ $t('goods.search') }}</el-button>
                    <router-link :to="{ name: 'goodsAdd' }">
                        <el-button>{{ $t('goods.goodsList.addGoods') }}</el-button>
                    </router-link>
                </el-form-item>
            </el-form>
            <div class="">
                <PaginatedTable
                    v-loading="loading"
                    :data="tableData"
                    :columns="tableColumns"
                    :pagination="pagination"
                    :span-method="objectSpanMethod"
                    :class="$style.table"
                    ref-dom="checkTable"
                    @pagesize-change="changePageSize"
                    @page-change="changePage"
                >
                    <template
                        slot="goodsTitle"
                        slot-scope="scope"
                    >
                        <router-link :to="{ name: 'goodsDetail', query: { product_id: scope.row.spu, review_type: 2}}">
                            {{ scope.row.goodsTitle }}
                        </router-link>
                    </template>
                    <template
                        slot="price"
                        slot-scope="scope"
                    >
                        ${{ scope.row.price }}
                    </template>
                    <template
                        slot="goodsInfo"
                        slot-scope="scope"
                    >
                        <div :class="$style.goodsInfo">
                            <div :class="$style.imageDiv">
                                <img :class="$style.image" :src="scope.row.goodsInfo.thumbUrl"/>
                            </div>
                            <div :class="$style.goodsAttr">
                                <div v-for="(item, index) in scope.row.goodsInfo.attrs" :key="index">
                                    {{ item.name }}: {{ item.value ? item.value.alias || item.value.name : '' }}
                                </div>
                            </div>
                        </div>
                    </template>
                    <template
                        slot="operate"
                        slot-scope="scope"
                    >
                        <router-link :to="{ name: 'GoodsPreview', params: { id: scope.row.sku, type: 2 } }">
                            {{ $t('goods.goodsList.preview') }}
                        </router-link>
                    </template>
                </PaginatedTable>
            </div>
        </div>
    </div>
</template>

<script>
    import PaginatedTable from '../../../components/PaginatedTable.vue';
    import { serviceCheckGoodsList } from '../../../services/goods';

    export default {
        name: 'GoodsCheckTab',
        components: { PaginatedTable },
        props: {
            type: {
                type: Number,
                default() {
                    return null;
                }
            },
            open: {
                type: String,
                default: ''
            }
        },
        data() {
            return {
                searchForm: {
                    goodsTitle: '',
                    goodSpuList: '',
                    shopGoodSnList: '',
                    goodSnList: ''
                },
                loading: false,
                tableData: [],
                rowData: {},
                tableColumns: [
                    {
                        label: this.$t('goods.goodsList.goodsTitle'),
                        prop: 'goodsTitle',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.platformCategory'),
                        prop: 'platformCategory',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: 'spu',
                        prop: 'spu',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.goodsInfo'),
                        prop: 'goodsInfo',
                        showSlot: true,
                        scope: true,
                        width: '200px',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.shopGoodCode'),
                        prop: 'shopGoodCode',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.goodsCode'),
                        prop: 'sku',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.price'),
                        prop: 'price',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.storage'),
                        prop: 'storage',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.operate'),
                        showSlot: true,
                        scope: true,
                        prop: 'operate',
                        align: 'center',
                        'header-align': 'center'
                    },
                ],
                pagination: {
                    pageNo: 1,
                    pageSize: 20,
                    totalCount: 0
                },
                rowIndex: '-1',
                sortDataIndex: [], // 对列表相同spu的排序在一起
                spuIndexArr: [], // 切分表格
            };
        },
        created() {
            this.init();
        },
        methods: {
            async init() {
                const {
                    title, spu, goodSn, shopGoodSn, pageNo, pageSize
                } = this.$route.query;
                this.pagination.pageNo = Number(pageNo) || 1;
                this.pagination.pageSize = Number(pageSize) || 20;
                this.searchForm.goodsTitle = title;
                this.searchForm.goodSpuList = spu;
                this.searchForm.goodSnList = goodSn;
                this.searchForm.shopGoodSnList = shopGoodSn;
                this.loading = true;
                await this.getList();
            },
            search() {
                this.pagination.pageNo = 1;
                this.getList();
                this.turnUrl();
            },
            // tab切换的回调函数
            getDataFirstPage() {
                this.initData();
                this.getList();
                this.turnUrl();
            },
            // 清空搜索数据
            initData() {
                this.pagination.pageNo = 1;
                this.pagination.pageSize = 20;
                this.searchForm.goodsTitle = '';
                this.searchForm.goodSpuList = '';
                this.searchForm.goodSnList = '';
                this.searchForm.shopGoodSnList = '';
            },
            async getList() {
                this.tableData = [];
                this.loading = true;
                const { data, status } = await this.serviceGetList({
                    page: this.pagination.pageNo,
                    pageSize: this.pagination.pageSize,
                    searchForm: this.searchForm
                });
                this.loading = false;
                this.handleList({ data, status });
            },
            async serviceGetList({
                page = 1, pageSize = 20, searchForm
            }) {
                const res = await serviceCheckGoodsList.http({
                    params: {
                        page_index: page,
                        page_size: pageSize,
                        title: this.searchForm.goodsTitle,
                        product_ids: this.searchForm.goodSpuList,
                        seller_skus: this.searchForm.shopGoodSnList,
                        variation_ids: this.searchForm.goodSnList
                    },
                });
                return res;
            },
            handleList({ status, data }) {
                if (status === 0) {
                    data.list.forEach((item, index) => {
                        const obj = {
                            goodsTitle: item.title,
                            platformCategory: item.store_category_path.path,
                            spu: item.product_id,
                            sku: item.variation_id,
                            price: item.present_price,
                            shopGoodCode: item.seller_sku,
                            storage: item.stock_num
                        };
                        obj.goodsInfo = {
                            thumbUrl: item.image_urls[0],
                            attrs: item.sku_attributes
                        };
                        this.tableData.push(obj);
                    });
                    this.sortDataArr();
                    this.getOrderNumber();
                    this.$emit('changeNum', {
                        type: this.type,
                        total: data.total_num
                    });
                    this.pagination.pageNo = data.page_index;
                    this.pagination.totalCount = data.total_num;
                }
            },
            // 对相同sku排在一起整理
            sortDataArr() {
                const OrderObj = {};
                this.sortDataIndex = [];
                this.tableData.forEach((element, index) => {
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    this.sortDataIndex.push(OrderObj[k]);
                }
                const dataArr = [];
                for (let i = 0; i < this.sortDataIndex.length; i += 1) {
                    const element = this.sortDataIndex[i];
                    for (let j = 0; j < element.length; j += 1) {
                        dataArr.push(this.tableData[element[j]]);
                    }
                }
                this.tableData = dataArr;
            },
            // 获取相同的spu的数组
            getOrderNumber() {
                const OrderObj = {};
                this.spuIndexArr = [];
                this.tableData.forEach((element, index) => {
                    element.rowIndex = index;
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    // if (OrderObj[k].length > 1) {
                    this.spuIndexArr.push(OrderObj[k]);
                    // }
                }
            },
            objectSpanMethod({
                row, column, rowIndex, columnIndex
            }) {
                // console.log(rowIndex, columnIndex);
                if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2) {
                    for (let i = 0; i < this.spuIndexArr.length; i += 1) {
                        const element = this.spuIndexArr[i];
                        for (let j = 0; j < element.length; j += 1) {
                            const item = element[j];
                            if (rowIndex === item) {
                                row.group = i;
                                if (j === 0) {
                                    return {
                                        rowspan: element.length,
                                        colspan: 1
                                    };
                                } if (j !== 0) {
                                    return {
                                        rowspan: 0,
                                        colspan: 0
                                    };
                                }
                            }
                        }
                    }
                }
                return {
                    rowspan: 1,
                    colspan: 1
                };
            },
            turnUrl() {
                this.$router.replace({
                    name: 'goodsList',
                    query: {
                        type: this.type,
                        pageSize: this.pagination.pageSize,
                        pageNo: this.pagination.pageNo,
                        title: this.searchForm.goodsTitle,
                        spu: this.searchForm.goodSpuList,
                        goodSn: this.searchForm.goodSnList,
                        shopGoodSn: this.searchForm.shopGoodSnList,
                    }
                });
            },
            // 分页事件
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
                this.getList();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
                this.getList();
            }
        },
    };
</script>

<style module>
    @import 'variable.css';
    .container{
        font-size: 14px;
        color: #000;
    }
    .header{
        margin-bottom: 20px;
    }
    .input {
        width: 150px;
    }
    .header .date{
        width: 140px;
    }
    .goodsInfo{
        position: relative;
        min-height: 50px;
    }
    .imageDiv{
        height: 100%;
        vertical-align: middle;
    }
    .image {
        position: absolute;
        width: 50px;
        height: 50px;
        top: 50%;
        transform: translateY(-50%);
    }
    .goodsAttr{
        display: inline-block;
        margin-left: 60px;
        vertical-align: middle;
    }
    /*.btnGroup{*/
        /*width: 100%;*/
        /*text-align: right;*/
    /*}*/
    .searchBtn{
        margin-left: 20px;
    }
    .delete{
        color: #ff5757;
    }
    .center{
        text-align: center;
        font-size: 16px;
    }
    .table {
        :global .el-table {
            border: 1px var(--border-color-base) solid;
        }
    }
    .table {
        :global .el-table {
            border: 1px var(--border-color-base) solid;
        }
    }
</style>
