<template>
    <div :class="$style.container">
        <!-- 搜索项目 -->
        <div :class="$style.header">
            <el-form ref="searchForm" :inline="true" :model="searchForm" label-suffix="：">
                <el-form-item :label="$t('goods.goodsList.goodsTitle')">
                    <el-select v-model="searchForm.isTitleEmpty" style="width: 120px">
                        <el-option :value="0" label="商品标题"></el-option>
                        <el-option :value="1" label="草稿"></el-option>
                    </el-select>
                    <el-input
                        v-model="searchForm.goodsTitle"
                        :class="$style.input"
                        :disabled="searchForm.isTitleEmpty === 1"
                        placeholder="模糊匹配">
                    </el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.lastUpdateTime')">
                    <el-date-picker
                        v-model="searchForm.statusChangeTimeMin"
                        :class="$style.date"
                        :placeholder="$t('goods.selectDate')"
                        value-format="timestamp"
                        type="date">
                    </el-date-picker>
                    {{ $t('goods.goodsList.zhi') }}
                    <el-date-picker
                        v-model="searchForm.statusChangeTimeMax"
                        :class="$style.date"
                        :placeholder="$t('goods.selectDate')"
                        value-format="timestamp"
                        type="date">
                    </el-date-picker>
                </el-form-item>
                <el-form-item :class="$style.btnGroup">
                    <el-button type="primary" @click="search">{{ $t('goods.search') }}</el-button>
                    <router-link :to="{ name: 'goodsAdd' }">
                        <el-button>{{ $t('goods.goodsList.addGoods') }}</el-button>
                    </router-link>
                </el-form-item>
            </el-form>

            <!-- 表格 -->
            <div class="">
                <PaginatedTable
                    v-loading="loading"
                    ref="waitSubmit"
                    :data="tableData"
                    :columns="tableColumns"
                    :pagination="pagination"
                    :class="$style.table"
                    ref-dom="waitSubmitTable"
                    @pagesize-change="changePageSize"
                    @page-change="changePage"
                    @selection-change="handleSelectionChange">
                    <template slot="goodsTitle" slot-scope="scope">
                        <router-link :to="{ name: 'goodsEditor', query: { product_id: scope.row.spu, review_type: 1 }}">
                            {{ scope.row.goodsTitle || $t('goods.goodsList.saved') }}
                        </router-link>
                    </template>
                    <template slot="operate" slot-scope="scope">
                        <router-link :to="{ name: 'goodsEditor', query: { product_id: scope.row.spu, review_type: 1}}">
                            {{ $t('goods.edit') }}
                        </router-link>
                        <a :class="$style.delete" @click="dialogDeleteGoods(1, scope.row)">{{ $t('goods.delete') }}</a>
                    </template>
                    <div slot="headerBatch" :class="$style.headerBatch">
                        <el-button :disabled="isBatch" size="mini" type="danger" @click="dialogDeleteGoods(2)">
                            {{ $t('goods.delete') }}
                        </el-button>
                    </div>
                    <div slot="bottomBatch" :class="$style.bottomBatch">
                        <el-button :disabled="isBatch" size="mini" type="danger" @click="dialogDeleteGoods(2)">
                            {{ $t('goods.delete') }}
                        </el-button>
                    </div>
                </PaginatedTable>
            </div>
        </div>
    </div>
</template>

<script>
    import PaginatedTable from '../../../components/PaginatedTable.vue';
    import {
        serviceWaitSubmitGoodsList,
        serviceDeleteSavedGoods
    } from '../../../services/goods';

    export default {
        name: 'GoodsWaitSubmitTab',
        components: { PaginatedTable },
        props: {
            type: {
                type: Number,
                default() {
                    return null;
                }
            },
            open: {
                type: String,
                default: ''
            }
        },
        data() {
            return {
                searchForm: {
                    isTitleEmpty: 0,
                    goodsTitle: '',
                    goodSpuList: '',
                    statusChangeTimeMin: '',
                    statusChangeTimeMax: '',
                    shopGoodSnList: '',
                },
                tableData: [],
                rowData: {},
                loading: false,
                tableColumns: [
                    {
                        label: 'spu1',
                        prop: 'spuSelect',
                        type: 'selection',
                        width: '55px',
                        align: 'center',
                        'header-align': 'center',
                    },
                    {
                        label: this.$t('goods.goodsList.goodsTitle'),
                        prop: 'goodsTitle',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center',
                    },
                    {
                        label: this.$t('goods.goodsList.platformCategory'),
                        prop: 'platformCategory',
                        align: 'center',
                        'header-align': 'center',
                    },
                    {
                        label: this.$t('goods.goodsList.lastUpdateTime'),
                        prop: 'statusUpdateTime',
                        align: 'center',
                        'header-align': 'center',
                    },
                    {
                        label: this.$t('goods.operate'),
                        showSlot: true,
                        scope: true,
                        prop: 'operate',
                        align: 'center',
                        'header-align': 'center',
                    },
                ],
                pagination: {
                    pageNo: 1,
                    pageSize: 20,
                    totalCount: 0
                },
                rowIndex: '-1',
                sortDataIndex: [], // 对列表相同spu的排序在一起
                spuIndexArr: [], // 切分表格
                selectRow: [], // 被选择的行的数据
                isBatch: true, // 批量按钮是否可用
                selectOneRow: {}, // 单选行数据
                deleteEventType: 1, // 1代表单选删除， 2代表多选删除
            };
        },
        watch: {
            selectRow() {
                this.isBatch = !(this.selectRow.length > 0);
            }
        },
        created() {
            this.init();
        },
        methods: {
            async init() {
                const {
                    title, startTime, endTime, pageNo, pageSize, isTitleEmpty
                } = this.$route.query;

                this.pagination.pageNo = Number(pageNo) || 1;
                this.pagination.pageSize = Number(pageSize) || 20;
                this.searchForm.goodsTitle = title;
                this.searchForm.statusChangeTimeMin = startTime;
                this.searchForm.statusChangeTimeMax = endTime;
                this.searchForm.isTitleEmpty = Number(isTitleEmpty) || 0;

                this.loading = true;

                this.getList();
            },

            search() {
                this.pagination.pageNo = 1;
                this.getList();
                this.turnUrl();
            },

            // tab切换的回调函数
            getDataFirstPage() {
                this.initData();
                this.getList();
                this.turnUrl();
            },

            // 清空搜索数据
            initData() {
                this.pagination.isTitleEmpty = '';
                this.pagination.pageNo = 1;
                this.pagination.pageSize = 20;
                this.searchForm.goodsTitle = '';
                this.searchForm.statusChangeTimeMin = '';
                this.searchForm.statusChangeTimeMax = '';
            },
            async getList() {
                this.tableData = [];
                this.loading = true;

                const { statusChangeTimeMin, statusChangeTimeMax } = this.searchForm;

                const params = {
                    is_title_empty: this.searchForm.isTitleEmpty,
                    page_index: this.pagination.pageNo,
                    page_size: this.pagination.pageSize,
                    title: this.searchForm.goodsTitle,
                    update_at_left: statusChangeTimeMin ? statusChangeTimeMin / 1000 : '',
                    update_at_right: statusChangeTimeMax ? statusChangeTimeMax / 1000 : '',
                };
                const reply = await serviceWaitSubmitGoodsList.http({ params });
                this.loading = false;
                this.handleList(reply);
            },

            handleList({ status, data }) {
                if (status === 0) {
                    const list = data.list || [];
                    list.forEach((item, index) => {
                        const obj = {
                            goodsTitle: item.title,
                            platformCategory: item.category_path,
                            spu: item.product_id,
                            statusUpdateTime: item.updated_at,
                            selectSku: false
                        };
                        this.tableData.push(obj);
                    });
                    this.getOrderNumber();
                    this.$emit('changeNum', {
                        type: this.type,
                        total: data.total_num
                    });
                    this.pagination.pageNo = data.page_index;
                    this.pagination.totalCount = data.total_num;
                }
            },

            // 对相同sku排在一起整理
            sortDataArr() {
                const OrderObj = {};
                this.sortDataIndex = [];
                this.tableData.forEach((element, index) => {
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    this.sortDataIndex.push(OrderObj[k]);
                }
                const dataArr = [];
                for (let i = 0; i < this.sortDataIndex.length; i += 1) {
                    const element = this.sortDataIndex[i];
                    for (let j = 0; j < element.length; j += 1) {
                        dataArr.push(this.tableData[element[j]]);
                    }
                }
                this.tableData = dataArr;
            },

            // 获取相同的spu的数组
            getOrderNumber() {
                this.spuIndexArr = [];
                const OrderObj = {};
                this.tableData.forEach((element, index) => {
                    element.rowIndex = index;
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    // if (OrderObj[k].length > 1) {
                    this.spuIndexArr.push(OrderObj[k]);
                    // }
                }
            },

            // spu勾选变化
            handleSelectionChange(selection, row) {
                this.selectRow = selection;
            },

            rowEdit(row) {
                this.$router.push({ name: 'brandEdit', params: { id: row.id } });
            },

            // 删除草稿箱
            deleteGoodsSaved(params) {
                return serviceDeleteSavedGoods.http({ data: params });
            },

            // 删除保存的商品
            dialogDeleteGoods(type, row) {
                const data = type === 1
                    ? [row.spu]
                    : this.selectRow.map(item => item.spu);
                const dialogText = type === 1
                    ? this.$t('goods.goodsList.deleteSavedGoods')
                    : this.$t('goods.goodsList.batchDeleteSavedGoods', [data.length]);

                this.$confirm(dialogText, {
                    confirmButtonText: this.$t('goods.confirm'),
                    cancelButtonText: this.$t('goods.cancel'),
                    center: true
                }).then(async () => {
                    const { status, msg } = await this.deleteGoodsSaved({
                        product_ids: [...data]
                    });
                    if (status === 0) {
                        this.$message({ type: 'success', message: this.$t('goods.deleteSuccess') });
                        this.getList();
                    } else {
                        this.$message({ type: 'error', message: msg });
                    }
                });
            },

            turnUrl(data) {
                const queryObj = Object.assign({
                    type: this.type,
                    pageSize: this.pagination.pageSize,
                    pageNo: this.pagination.pageNo,
                    title: this.searchForm.goodsTitle,
                    startTime: this.searchForm.statusChangeTimeMin,
                    endTime: this.searchForm.statusChangeTimeMax,
                }, data);
                this.$router.replace({
                    name: 'goodsList',
                    query: queryObj
                });
            },

            // 分页事件
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
                this.getList();
            },

            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
                this.getList();
            }
        },
    };
</script>

<style module>
    @import 'variable.css';
    .container{
        font-size: 14px;
        color: #000;
    }
    .header{
        margin-bottom: 20px;
    }
    .input {
        width: 150px;
    }
    .header .date{
        width: 140px;
    }
    .goodsInfo{
        position: relative;
        min-height: 50px;
    }
    .imageDiv{
        height: 100%;
        vertical-align: middle;
    }
    .image {
        position: absolute;
        width: 50px;
        height: 50px;
        top: 50%;
        transform: translateY(-50%);
    }
    .goodsAttr{
        display: inline-block;
        margin-left: 60px;
        vertical-align: middle;
    }
    /*.btnGroup{*/
        /*float: right;*/
    /*}*/

    .headerBatch{
        padding: 12px 16px;
        border: 1px solid #ddd;
        border-bottom: 0;
    }
    .bottomBatch{
        padding: 12px 16px;
        border: 1px solid #ddd;
        border-top: 0;
    }
    .statusTip{
        margin-left: 160px;
        font-size: 14px;
        color: #000;
        text-align: left;
        margin-bottom: 4px;
    }
    .searchBtn{
        margin-left: 20px;
    }
    .delete{
        color: #ff5757;
    }
    .center{
        text-align: center;
        font-size: 16px;
    }
    .delete{
        color: #ff5757;
    }
    .table {
        :global .el-table {
            border: 1px var(--border-color-base) solid;
        }
    }
</style>
