<template>
    <div :class="$style.container">
        <div :class="$style.header">
            <el-form ref="searchForm" :inline="true" :model="searchForm" label-suffix="：">
                <el-form-item :label="$t('goods.goodsList.goodsTitle')">
                    <el-input v-model="searchForm.goodsTitle" :class="$style.input"></el-input>
                </el-form-item>
                <el-form-item label="spu">
                    <el-input v-model="searchForm.goodSpuList" :class="$style.input"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.shopGoodCode')">
                    <el-input :class="$style.input" v-model="searchForm.shopGoodSnList"></el-input>
                </el-form-item>
                <el-form-item :label="$t('goods.goodsList.goodsCode')">
                    <el-input :class="$style.input" v-model="searchForm.goodSnList"></el-input>
                </el-form-item>
                <el-form-item :class="$style.btnGroup">
                    <el-button type="primary" @click="search">{{ $t('goods.search') }}</el-button>
                    <router-link :to="{ name: 'goodsAdd' }">
                        <el-button>{{ $t('goods.goodsList.addGoods') }}</el-button>
                    </router-link>
                </el-form-item>
            </el-form>
            <div class="">
                <!--<div :class="$style.batch">-->
                <!--<el-button :disabled="isBatch" size="mini" type="danger" @click="dialogDeleteGoods(2)">-->
                <!--{{ $t('goods.delete') }}-->
                <!--</el-button>-->
                <!--</div>-->
                <PaginatedTable
                    v-loading="loading"
                    ref="disapprove"
                    :data="tableData"
                    :columns="tableColumns"
                    :pagination="pagination"
                    :span-method="objectSpanMethod"
                    :class="$style.table"
                    ref-dom="disapproveTable"
                    @pagesize-change="changePageSize"
                    @page-change="changePage"
                    @select="handleSelectionChange"
                    @select-all="handleAllSelectionChange"
                >
                    <template
                        slot="goodsTitle"
                        slot-scope="scope"
                    >
                        <router-link :to="{ name: 'goodsDetail', query: { product_id: scope.row.spu, review_type: 2 }}">
                            {{ scope.row.goodsTitle }}
                        </router-link>
                    </template>
                    <template
                        slot="platformCategory"
                        slot-scope="scope"
                    >
                        <span>{{ scope.row.platformCategoryPath }}</span>
                    </template>
                    <template
                        slot="selectSku"
                        slot-scope="scope"
                    >
                        <el-checkbox v-model="scope.row.selectSku" @change="(value) => {
                            changeSkuSelect(value, scope.row)
                        }"></el-checkbox>
                    </template>
                    <template
                        slot="goodsInfo"
                        slot-scope="scope"
                    >
                        <div :class="$style.goodsInfo">
                            <div :class="$style.imageDiv">
                                <img :class="$style.image" :src="scope.row.goodsInfo.thumbUrl"/>
                            </div>
                            <div :class="$style.goodsAttr">
                                <div v-for="(item, index) in scope.row.goodsInfo.attrs" :key="index">
                                    {{ item.name }}: {{ item.value ? item.value.alias || item.value.name : '' }}
                                </div>
                            </div>
                        </div>
                    </template>
                    <template
                        slot="price"
                        slot-scope="scope"
                    >
                        <a @click="dialogChangePriceAndStock(scope.row,0)">${{ scope.row.price }} </a>
                    </template>
                    <template
                        slot="storage"
                        slot-scope="scope"
                    >
                        <a @click="dialogChangePriceAndStock(scope.row,1)">{{ scope.row.storage }} </a>
                    </template>
                    <template
                        slot="operate"
                        slot-scope="scope"
                    >
                        <div>
                            <router-link :to="{ name: 'goodsEditor', query: { product_id: scope.row.spu, review_type: 3 }}">
                                {{ $t('goods.edit') }}
                            </router-link>
                        </div>
                        <div>
                            <router-link :to="{ name: 'GoodsPreview', params: { id: scope.row.sku, type: 3 } }">
                                {{ $t('goods.goodsList.preview') }}
                            </router-link>
                        </div>
                        <!--<div>-->
                        <!--<a :class="$style.delete" @click="dialogDeleteGoods(1, scope.row)">{{ $t('goods.delete') }}</a>-->
                        <!--</div>-->
                    </template>
                </PaginatedTable>
                <!--<div :class="$style.batch">-->
                <!--<el-button :disabled="isBatch" size="mini" type="danger" @click="dialogDeleteGoods(2)">-->
                <!--{{ $t('goods.delete') }}-->
                <!--</el-button>-->
                <!--</div>-->
                <!--todo: 把弹出框挪出做组件-->
                <!--设置单个商品价格和库存-->
                <el-dialog
                    :visible.sync="priceDialogVisible"
                    :title="priceAndStorageTitle[priceAndStorageIndex]"
                    width="560px"
                    @close="() => {
                        $refs.priceAndStorageForm.resetFields();
                }">
                    <div>
                        <ul>
                            <li :class="$style.info">
                                <div :class="$style.infoKey">
                                    {{ $t('goods.goodsList.goodsCode') }}
                                </div>
                                <div :class="$style.infoValue">
                                    {{ selectOneRow.sku }}
                                </div>
                            </li>
                            <li :class="$style.info">
                                <div :class="$style.infoKey">
                                    {{ $t('goods.goodsList.shopGoodCode') }}
                                </div>
                                <div :class="$style.infoValue">
                                    {{ selectOneRow.shopGoodCode }}
                                </div>
                            </li>
                            <li :class="$style.info">
                                <div :class="$style.infoKey">
                                    {{ $t('goods.goodsList.specification') }}
                                </div>
                                <div :class="$style.infoValue">
                                    {{ selectOneRow.sku }}
                                </div>
                            </li>
                        </ul>
                        <el-form ref="priceAndStorageForm" :model="priceAndStorageForm" label-width="110px" label-suffix=":">
                            <el-form-item :rules="priceAndStorageIndex===0?priceRules:stockRules"
                                          :label="priceAndStorageIndex===0?$t('goods.goodsList.price'):$t('goods.goodsList.storage')" prop="num">
                                <el-input v-model="priceAndStorageForm.num" style="width: 300px"></el-input>
                            </el-form-item>
                        </el-form>
                    </div>
                    <span slot="footer" :class="$style.center">
                        <el-button @click="priceDialogVisible = false">{{ $t('goods.cancel') }}</el-button>
                        <el-button type="primary" @click="priceAndStockConfirm()">{{ $t('goods.confirm') }}</el-button>
                    </span>
                </el-dialog>
            </div>
        </div>
    </div>
</template>

<script>
    import PaginatedTable from '../../../components/PaginatedTable.vue';
    import {
        serviceDisapproveGoodsList, serviceDeleteDisapproveGoods, serviceEditDisapproveGoodsPrice, serviceEditDisapproveGoodsStock
    } from '../../../services/goods';

    export default {
        name: 'GoodsDisapproveTab',
        components: { PaginatedTable },
        props: {
            type: {
                type: Number,
                default() {
                    return null;
                }
            },
            open: {
                type: String,
                default: ''
            }
        },
        data() {
            const priceValidatePass = (rule, value, callback) => {
                if (value > Number(1000000)) {
                    callback(new Error(this.$t('goods.goodsList.priceNumberErr')));
                } else {
                    callback();
                }
            };
            const stockValidatePass = (rule, value, callback) => {
                if (value > Number(1000000)) {
                    callback(new Error(this.$t('goods.goodsList.stockNumberErr')));
                } else {
                    callback();
                }
            };
            return {
                searchForm: {
                    goodsTitle: '',
                    goodSpuList: '',
                    shopGoodSnList: '',
                    goodSnList: ''
                },
                tableData: [],
                rowData: {},
                tableColumns: [
                    // {
                    //     label: 'spu1',
                    //     prop: 'spuSelect',
                    //     type: 'selection',
                    //     width: '55px',
                    //     align: 'center',
                    //     'header-align': 'center'
                    // },
                    {
                        label: this.$t('goods.goodsList.goodsTitle'),
                        prop: 'goodsTitle',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.platformCategory'),
                        prop: 'platformCategory',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: 'spu',
                        prop: 'spu',
                        align: 'center',
                        'header-align': 'center'
                    },
                    // {
                    //     label: '',
                    //     prop: 'selectSku',
                    //     width: '55px',
                    //     showSlot: true,
                    //     scope: true,
                    //     align: 'center',
                    //     'header-align': 'center'
                    // },
                    {
                        label: this.$t('goods.goodsList.goodsInfo'),
                        prop: 'goodsInfo',
                        showSlot: true,
                        scope: true,
                        width: '200px',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.shopGoodCode'),
                        prop: 'shopGoodCode',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.goodsCode'),
                        prop: 'sku',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.price'),
                        prop: 'price',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.goodsList.storage'),
                        prop: 'storage',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center',
                    },
                    {
                        label: this.$t('goods.goodsList.reason'),
                        prop: 'reason',
                        align: 'center',
                        'header-align': 'center',
                    },
                    {
                        label: this.$t('goods.operate'),
                        showSlot: true,
                        scope: true,
                        prop: 'operate',
                        align: 'center',
                        'header-align': 'center',
                    },
                ],
                pagination: {
                    pageNo: 1,
                    pageSize: 20,
                    totalCount: 0
                },
                loading: false,
                rowIndex: '-1',
                sortDataIndex: [], // 对列表相同spu的排序在一起
                spuIndexArr: [], // 切分表格
                selectRow: [], // 被选择的行的数据
                freightModuleArr: [], // 模板数组
                isBatch: true, // 批量按钮是否可用
                selectStatusType: 2, // 2表示上架，3表示下架
                selectOneRow: {}, // 单选行数据
                priceDialogVisible: false, // 设置单个商品的弹出框
                priceAndStorageIndex: 0, // 0表示修改价格，1表示修改库存数，
                priceAndStorageTitle: [ // 修改价格和库存弹出框标题
                    this.$t('goods.goodsList.changePrice'),
                    this.$t('goods.goodsList.changeStock')
                ],
                priceAndStorageForm: { // 修改价格和库存表单
                    num: 0
                },
                priceRules: [ // 价格校验
                    { required: true, message: this.$t('goods.goodsList.priceNumberErr'), trigger: 'blur' },
                    { pattern: /^[1-9]\d*$|^\d+(\.\d{1,2})$/, message: this.$t('goods.goodsList.priceNumberErr'), trigger: 'blur' },
                    { validator: priceValidatePass, trigger: 'blur' }
                ],
                stockRules: [ // 库存校验
                    { required: true, message: this.$t('goods.goodsList.stockNumberErr'), trigger: 'blur' },
                    { pattern: /^[1-9]\d*$|0$/, message: this.$t('goods.goodsList.stockNumberErr'), trigger: 'blur' },
                    { validator: stockValidatePass, trigger: 'blur' }
                ],
            };
        },
        watch: {
            selectRow() {
                this.isBatch = !(this.selectRow.length > 0);
            }
        },
        created() {
            this.init();
        },
        methods: {
            async init() {
                const {
                    title, spu, goodSn, shopGoodSn, pageNo, pageSize
                } = this.$route.query;
                this.pagination.pageNo = Number(pageNo) || 1;
                this.pagination.pageSize = Number(pageSize) || 20;
                this.searchForm.goodsTitle = title;
                this.searchForm.goodSpuList = spu;
                this.searchForm.goodSnList = goodSn;
                this.searchForm.shopGoodSnList = shopGoodSn;
                this.loading = true;
                await this.getList();
            },
            search() {
                this.pagination.pageNo = 1;
                this.getList();
                this.turnUrl();
            },
            // tab切换的回调函数
            getDataFirstPage() {
                this.initData();
                this.getList();
                this.turnUrl();
            },
            // 清空搜索数据
            initData() {
                this.pagination.pageNo = 1;
                this.pagination.pageSize = 20;
                this.searchForm.goodsTitle = '';
                this.searchForm.goodSpuList = '';
                this.searchForm.goodSnList = '';
                this.searchForm.shopGoodSnList = '';
            },
            async getList() {
                this.tableData = [];
                this.loading = true;
                const { data, status } = await this.serviceGetList({
                    page: this.pagination.pageNo,
                    pageSize: this.pagination.pageSize,
                    searchForm: this.searchForm
                });
                this.loading = false;
                this.handleList({ data, status });
            },
            async serviceGetList({
                page = 1, pageSize = 20, searchForm
            }) {
                const res = await serviceDisapproveGoodsList.http({
                    params: {
                        page_index: page,
                        page_size: pageSize,
                        title: this.searchForm.goodsTitle,
                        product_ids: this.searchForm.goodSpuList,
                        seller_skus: this.searchForm.shopGoodSnList,
                        variation_ids: this.searchForm.goodSnList
                    },
                });
                return res;
            },
            handleList({ status, data }) {
                if (status === 0) {
                    data.list.forEach((item, index) => {
                        const obj = {
                            goodsTitle: item.title,
                            platformCategory: item.store_category_path.path,
                            spu: item.product_id,
                            sku: item.variation_id,
                            virWhCode: item.virWhCode,
                            price: item.present_price,
                            shopGoodCode: item.seller_sku,
                            storage: item.stock_num,
                            selectSku: false,
                            reason: item.review_remark
                        };
                        obj.goodsInfo = {
                            thumbUrl: item.image_urls[0],
                            attrs: item.sku_attributes ? item.sku_attributes : []
                        };
                        this.tableData.push(obj);
                    });
                    this.sortDataArr();
                    this.getOrderNumber();
                    this.$emit('changeNum', {
                        type: this.type,
                        total: data.total_num
                    });
                    this.pagination.pageNo = data.page_index;
                    this.pagination.totalCount = data.total_num;
                }
            },
            // 对相同sku排在一起整理
            sortDataArr() {
                const OrderObj = {};
                this.sortDataIndex = [];
                this.tableData.forEach((element, index) => {
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    this.sortDataIndex.push(OrderObj[k]);
                }
                const dataArr = [];
                for (let i = 0; i < this.sortDataIndex.length; i += 1) {
                    const element = this.sortDataIndex[i];
                    for (let j = 0; j < element.length; j += 1) {
                        dataArr.push(this.tableData[element[j]]);
                    }
                }
                this.tableData = dataArr;
            },
            // 获取相同的spu的数组
            getOrderNumber() {
                const OrderObj = {};
                this.spuIndexArr = [];
                this.tableData.forEach((element, index) => {
                    element.rowIndex = index;
                    if (OrderObj[element.spu]) {
                        OrderObj[element.spu].push(index);
                    } else {
                        OrderObj[element.spu] = [];
                        OrderObj[element.spu].push(index);
                    }
                });

                for (const k in OrderObj) {
                    // if (OrderObj[k].length > 1) {
                    this.spuIndexArr.push(OrderObj[k]);
                    // }
                }
            },
            objectSpanMethod({
                row, column, rowIndex, columnIndex
            }) {
                // console.log(rowIndex, columnIndex);
                if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2) {
                    for (let i = 0; i < this.spuIndexArr.length; i += 1) {
                        const element = this.spuIndexArr[i];
                        for (let j = 0; j < element.length; j += 1) {
                            const item = element[j];
                            if (rowIndex === item) {
                                row.group = i;
                                if (j === 0) {
                                    return {
                                        rowspan: element.length,
                                        colspan: 1
                                    };
                                } if (j !== 0) {
                                    return {
                                        rowspan: 0,
                                        colspan: 0
                                    };
                                }
                            }
                        }
                    }
                }
                return {
                    rowspan: 1,
                    colspan: 1
                };
            },
            // sku勾选变化
            changeSkuSelect(value, row) {
                const item = this.spuIndexArr[row.group];
                if (value) {
                    for (let i = 0; i < item.length; i += 1) {
                        if (this.tableData[item[i]].selectSku === false) {
                            this.$refs.disapprove.$refs.disapproveTable.toggleRowSelection(this.tableData[item[0]], false);
                            this.selectRowData();
                            return;
                        }
                    }
                    this.$refs.disapprove.$refs.disapproveTable.toggleRowSelection(this.tableData[item[0]], true);
                } else {
                    this.$refs.disapprove.$refs.disapproveTable.toggleRowSelection(this.tableData[item[0]], false);
                }
                this.selectRowData();
            },
            // spu勾选变化
            handleSelectionChange(selection, row) {
                const flag = selection.includes(row);
                const element = this.spuIndexArr[row.group];
                if (flag) {
                    for (let i = 0; i < element.length; i += 1) {
                        this.tableData[element[i]].selectSku = true;
                        this.$refs.disapprove.$refs.disapproveTable.toggleRowSelection(this.tableData[element[i]], true);
                    }
                } else {
                    for (let i = 0; i < element.length; i += 1) {
                        this.tableData[element[i]].selectSku = false;
                        this.$refs.disapprove.$refs.disapproveTable.toggleRowSelection(this.tableData[element[i]], false);
                    }
                }
                this.selectRowData();
            },
            // 勾选全选和取消全选的变化
            handleAllSelectionChange(selection) {
                if (selection.length) {
                    for (let i = 0; i < this.tableData.length; i += 1) {
                        this.tableData[i].selectSku = true;
                    }
                } else {
                    for (let i = 0; i < this.tableData.length; i += 1) {
                        this.tableData[i].selectSku = false;
                    }
                }
                this.selectRowData();
            },
            // 检查被选中的数据
            selectRowData() {
                this.selectRow = [];
                this.tableData.forEach((item, index) => {
                    if (item.selectSku) {
                        this.selectRow.push(item);
                    }
                });
            },
            // 改变商品价格和库存弹出框
            dialogChangePriceAndStock(row, index) {
                this.priceDialogVisible = true;
                this.selectOneRow = row;
                this.priceAndStorageIndex = index;
                if (index === 0) {
                    this.priceAndStorageForm.num = row.price;
                } else {
                    this.priceAndStorageForm.num = row.storage;
                }
            },
            // 价格和库存确认按钮
            priceAndStockConfirm() {
                let postData;
                let res;
                this.$refs.priceAndStorageForm.validate(async (valid) => {
                    if (valid) {
                        if (this.priceAndStorageIndex === 0) {
                            postData = {
                                variation_data: [{
                                    variation_id: this.selectOneRow.sku,
                                    present_price: this.priceAndStorageForm.num
                                }]
                            };
                            res = await serviceEditDisapproveGoodsPrice.http({
                                data: postData
                            });
                        } else {
                            postData = {
                                variation_data: [{
                                    variation_id: this.selectOneRow.sku,
                                    stock_num: this.priceAndStorageForm.num
                                }]
                            };
                            res = await serviceEditDisapproveGoodsStock.http({
                                data: postData
                            });
                        }
                        if (res.status === 0) {
                            this.$message({
                                message: this.$t('goods.setSuccess'),
                                type: 'success'
                            });
                            this.getList();
                        } else {
                            this.$message.error(res.msg);
                        }
                        this.priceDialogVisible = false;
                    }
                });
            },

            // 删除商品
            dialogDeleteGoods(index, row) {
                if (index === 1) {
                    this.$confirm(this.$t('goods.goodsList.deleteGoodsTip'), {
                        confirmButtonText: this.$t('goods.confirm'),
                        cancelButtonText: this.$t('goods.cancel'),
                        center: true
                    }).then(async () => {
                        const { status, msg } = await serviceDeleteDisapproveGoods.http({
                            data: {
                                variation_ids: [row.sku]
                            }
                        });
                        if (status === 0) {
                            this.$message({
                                message: this.$t('goods.deleteSuccess'),
                                type: 'success'
                            });
                            this.getList();
                        } else {
                            this.$message.error(msg);
                        }
                    });
                } else if (index === 2) {
                    this.$confirm(this.$t('goods.goodsList.batchDeleteGoods', [this.selectRow.length]), {
                        confirmButtonText: this.$t('goods.confirm'),
                        cancelButtonText: this.$t('goods.cancel'),
                        center: true
                    }).then(async () => {
                        const variationIds = this.selectRow.map(item => (item.sku));
                        const { status, msg } = await serviceDeleteDisapproveGoods.http({
                            data: {
                                variation_ids: variationIds
                            }
                        });
                        if (status === 0) {
                            this.$message({
                                message: this.$t('goods.deleteSuccess'),
                                type: 'success'
                            });
                            this.getList();
                        } else {
                            this.$message.error(msg);
                        }
                    });
                }
            },

            turnUrl() {
                this.$router.replace({
                    name: 'goodsList',
                    query: {
                        type: this.type,
                        pageSize: this.pagination.pageSize,
                        pageNo: this.pagination.pageNo,
                        title: this.searchForm.goodsTitle,
                        spu: this.searchForm.goodSpuList,
                        goodSn: this.searchForm.goodSnList,
                        shopGoodSn: this.searchForm.shopGoodSnList
                    }
                });
            },
            // 分页事件
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
                this.getList();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
                this.getList();
            }
        },
    };
</script>

<style module>
    @import 'variable.css';
    .container{
        font-size: 14px;
        color: #000;
    }
    .header{
        margin-bottom: 20px;
    }
    .input {
        width: 150px;
    }
    .header .date{
        width: 140px;
    }
    .goodsInfo{
        position: relative;
        min-height: 50px;
    }
    .imageDiv{
        height: 100%;
        vertical-align: middle;
    }
    .image {
        position: absolute;
        width: 50px;
        height: 50px;
        top: 50%;
        transform: translateY(-50%);
    }
    .goodsAttr{
        display: inline-block;
        margin-left: 60px;
        vertical-align: middle;
    }
    /*.btnGroup{*/
        /*width: 100%;*/
        /*text-align: right;*/
    /*}*/
    .dialogFreight{
    :global .el-dialog__footer{
        text-align: center;
    }
    }
    .freightTip{
        margin-left: 160px;
        font-size: 14px;
        color: #000;
        text-align: left;
    }
    .freightSelect{
        text-align: left;
    }
    :global .el-dialog__body {
        padding: 0 20px 10px;
    }
    .batch{
        padding: 12px 16px;
        border: 1px solid #ddd;
    }
    .statusTip{
        margin-left: 160px;
        font-size: 14px;
        color: #000;
        text-align: left;
        margin-bottom: 4px;
    }
    .searchBtn{
        margin-left: 20px;
    }
    .delete{
        color: #ff5757;
    }
    .center{
        text-align: center;
        font-size: 16px;
    }
    .info{
        line-height: 40px;
    }
    .infoKey{
        display: inline-block;
        min-width: 110px;
        font-size: 14px;
        color: #999;
        text-align: right;
    }
    .infoValue{
        display: inline-block;
        font-size: 14px;
        color: #000;
        margin-left: 38px;
    }
    .table {
        :global .el-table {
            border: 1px var(--border-color-base) solid;
        }
    }
</style>
