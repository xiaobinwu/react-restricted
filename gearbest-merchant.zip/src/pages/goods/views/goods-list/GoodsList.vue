<template>
    <div :class="$style.container">
        <el-tabs v-model="activeName" type="border-card" @tab-click="handleTapClick">
            <el-tab-pane type="approveChild" name="approveChild">
                <span slot="label">审核通过<span>({{ approveNum }})</span></span>
                <div>
                    <goods-approve-tab
                        ref="approveChild"
                        :type="1"
                        @changeNum="changeNum"
                        @changeOpen="changeOpen">
                    </goods-approve-tab>
                </div>
            </el-tab-pane>
            <el-tab-pane type="checkChild" name="checkChild">
                <span slot="label">待审核<span>({{ checkNum }})</span></span>
                <div>
                    <goods-check-tab
                        ref="checkChild"
                        :type="2"
                        @changeNum="changeNum"
                        @changeOpen="changeOpen">
                    </goods-check-tab>
                </div>
            </el-tab-pane>
            <el-tab-pane type="savedChild" name="savedChild">
                <span slot="label">草稿箱<span>({{ savedNum }})</span></span>
                <div>
                    <goods-wait-submit-tab
                        ref="savedChild"
                        :type="3"
                        @changeNum="changeNum"
                        @changeActiveName="changeActiveName"
                        @changeOpen="changeOpen" >
                    </goods-wait-submit-tab>
                </div>
            </el-tab-pane>
            <el-tab-pane type="disapproveChild" name="disapproveChild">
                <span slot="label">审核不通过<span>({{ disapproveNum }})</span></span>
                <div>
                    <goods-disapprove-tab
                        ref="disapproveChild"
                        :type="4"
                        @changeNum="changeNum"
                        @changeOpen="changeOpen">
                    </goods-disapprove-tab>
                </div>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script>
    import goodsApproveTab from './components/GoodsApproveTab';
    import goodsCheckTab from './components/GoodsCheckTab';
    import goodsWaitSubmitTab from './components/GoodsWaitSubmitTab';
    import goodsDisapproveTab from './components/GoodsDisapproveTab';

    export default {
        name: 'GoodsList',
        components: {
            goodsApproveTab,
            goodsCheckTab,
            goodsWaitSubmitTab,
            goodsDisapproveTab
        },
        data() {
            return {
                approveNum: 0,
                disapproveNum: 0,
                checkNum: 0,
                savedNum: 0,
                activeName: 'approveChild',
            };
        },
        created() {
            this.init();
        },
        methods: {
            handleTapClick(tab) {
                const name = tab.name;
                this.$refs[name].getDataFirstPage();
            },
            init() {
                let { type } = this.$route.query;
                type = Number(type);
                if (type === 1) {
                    this.activeName = 'approveChild';
                } else if (type === 2) {
                    this.activeName = 'checkChild';
                    this.isCheck = true;
                } else if (type === 3) {
                    this.activeName = 'savedChild';
                } else if (type === 4) {
                    this.activeName = 'disapproveChild';
                }
            },
            changeNum(data) {
                if (data.type === 1) {
                    this.approveNum = data.total;
                } else if (data.type === 2) {
                    this.checkNum = data.total;
                } else if (data.type === 3) {
                    this.savedNum = data.total;
                } else if (data.type === 4) {
                    this.disapproveNum = data.total;
                }
            },
            changeActiveName(name) {
                this.activeName = name;
            },
            changeOpen(data) {
                this.open = data;
            }
        }
    };
</script>

<style module>
.container {
    font-size: 14px;
}
</style>
