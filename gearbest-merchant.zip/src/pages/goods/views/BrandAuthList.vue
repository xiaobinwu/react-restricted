<template>
    <div :class="$style.container">
        <el-form :inline="true" :model="searchForm" label-suffix="：">
            <el-form-item :label="$t('goods.brand.name')">
                <el-select v-model="searchForm.brandCode" :placeholder="$t('goods.brand.inputENameSearch')" filterable>
                    <el-option v-for="(item, index) in brandList" :key="index" :label="item.label" :value="item.value">
                        <span :class="$style.optionLeft">{{ item.label }}</span>
                        <span :class="$style.optionRight">{{ item.other }}</span>
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item :label="$t('goods.brand.checkResult')">
                <el-select v-model="searchForm.reviewStatus" :placeholder="$t('goods.brand.select')">
                    <el-option :label="$t('goods.brand.waitACheck')" value="1"></el-option>
                    <el-option :label="$t('goods.brand.successCheck')" value="2"></el-option>
                    <el-option :label="$t('goods.brand.failCheck')" value="3"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="search">{{ $t('goods.search') }}</el-button>
            </el-form-item>
            <el-form-item style="float: right">
                <router-link :to="{ name: 'brandAuthAdd' }">
                    <el-button>{{ $t('goods.brand.brandAuthAdd') }}</el-button>
                </router-link>
            </el-form-item>
        </el-form>
        <paginated-table
            v-loading="loading"
            :data="tableData"
            :columns="tableColumns"
            :pagination="pagination"
            :span-method="objectSpanMethod"
            :border="true"
            @pagesize-change="changePageSize"
            @page-change="changePage"
        >
            <template
                slot="operate"
                slot-scope="scope"
            >
                <router-link v-if="scope.row.checkResult === 3" :to="{ name: 'brandAuthEdit', params: {id: scope.row.id}}">
                    <el-button type="text">{{ $t('goods.edit') }}</el-button>
                </router-link>
                <span v-if="scope.row.checkResult === 1">
                    <a :class="$style.disable" href="javascript:;">{{ $t('goods.edit') }}</a>
                </span>
                <el-button
                    :class="[$style.delete, scope.row.checkResult === 1?$style.disable:'']"
                    type="text"
                    @click="rowDelete(scope.row)"
                >{{ $t('goods.delete') }}</el-button>
            </template>
            <template
                slot="certificate"
                slot-scope="scope"
            >
                <div v-if="scope.row.certificate">
                    <!--<img v-if="jubdgePattern(scope.row.certificate) === 'jpg'" :src="scope.row.certificate" :class="$style.certificate"/>-->
                    <!--<div v-else>-->
                    <!--<img v-if="jubdgePattern(scope.row.certificate) === 'pdf'"
                     :class="$style.certificateIcon" src="@goods/assets/img/pdf.png"/>-->
                    <!--<img v-if="jubdgePattern(scope.row.certificate) === 'doc'"
                     :class="$style.certificateIcon" src="@goods/assets/img/doc.png"/>-->
                    <!--<a :class="$style.fileName" :href="scope.row.certificate">{{ scope.row.fileName }}</a>-->
                    <!--</div>-->
                    <div>
                        <img :class="$style.certificateIcon" src="@goods/assets/img/doc.png"/>
                        <a :class="$style.fileName" :href="scope.row.certificate" :title="scope.row.fileName">{{ scope.row.fileName }}</a>
                    </div>
                </div>
            </template>
        </paginated-table>
        <el-dialog
            :visible.sync="dialogVisible"
            center
            width="560px">
            <div :class="$style.center">{{ $t('goods.brand.deleteAuthTip') }}</div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">{{ $t('goods.cancel') }}</el-button>
                <el-button type="primary" @click="confirm()">{{ $t('goods.confirm') }}</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import { serviceBrandAuthList, serviceBrandAuthDelete, serviceBrandAuthPublicList } from '../services/goods';
    import { dateFormat } from '@/assets/js/utils/date';
    import PaginatedTable from '../components/PaginatedTable.vue';

    export default {
        name: 'BrandAuthList',
        components: { PaginatedTable },
        data() {
            return {
                searchForm: {
                    brandCode: '',
                    reviewStatus: ''
                },
                brandList: [],
                dialogVisible: false,
                rowData: {},
                docImgUrl: 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3365018759,2226705862&fm=27&gp=0.jpg',
                pdfImgUrl: 'https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=967395617,3601302195&fm=27&gp=0.jpg',
                lastId: '',
                tableData: [],
                tableColumns: [
                    {
                        label: this.$t('goods.brand.name'),
                        prop: 'name',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.certificate'),
                        showSlot: true,
                        scope: true,
                        prop: 'certificate',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.fromAndToDate'),
                        prop: 'authDate',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.checkResult'),
                        prop: 'checkResultName',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.validDate'),
                        prop: 'validDate',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.applyDate'),
                        prop: 'applyDate',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.reason'),
                        prop: 'reason',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.operate'),
                        showSlot: true,
                        scope: true,
                        prop: 'operate',
                        align: 'center',
                        'header-align': 'center'
                    }
                ],
                pagination: {
                    pageNo: 1,
                    pageSize: 10,
                    totalCount: 0
                },
                rowIndex: '-1',
                certificateIndexArr: [],
                loading: false
            };
        },
        created() {
            this.init();
        },
        methods: {
            async init() {
                const {
                    reviewStatus, brandCode, pageSize, pageNo
                } = this.$route.query;
                this.pagination.pageNo = Number(pageNo) || 1;
                this.pagination.pageSize = Number(pageSize) || 10;
                this.searchForm.brandCode = brandCode;
                this.searchForm.reviewStatus = reviewStatus;
                this.getPublicBrandList();
                await this.getList();
            },
            async getPublicBrandList() {
                const { status, data, msg } = await serviceBrandAuthPublicList.http({
                    params: {
                        is_all: 1
                    }
                });
                if (status === 0) {
                    this.brandList = data.map(item => ({
                        label: item.name,
                        value: item.brand_code,
                        other: item.brand_owner
                    }));
                } else {
                    this.$message.error(msg);
                }
            },
            async serviceGetList({
                page = 1, pageSize = 10, reviewStatus, brandCode
            }) {
                const res = await serviceBrandAuthList.http({
                    params: {
                        page,
                        brand_code: brandCode,
                        review_status: reviewStatus,
                        page_size: pageSize
                    },
                });
                return res;
            },
            async getList() {
                this.tableData = [];
                this.loading = true;
                const { data, status } = await this.serviceGetList({
                    page: this.pagination.pageNo,
                    pageSize: this.pagination.pageSize,
                    reviewStatus: this.searchForm.reviewStatus,
                    brandCode: this.searchForm.brandCode
                });
                this.loading = false;
                this.handleList({ data, status });
            },
            handleList({ status, data }) {
                console.log(data);
                if (status === 0) {
                    data.list.forEach((item, index) => {
                        if (item.licensingList && item.licensingList.length) {
                            for (let i = 0; i < item.licensingList.length; i += 1) {
                                const obj = {
                                    id: item.id,
                                    name: item.name_en,
                                    certificate: item.licensingList[i].link,
                                    fileName: item.licensingList[i].file_name,
                                    authDate: item.licensingList[i].start_time ? `${dateFormat(item.licensingList[i].start_time, 'yyyy-MM-dd')}
                                           ${this.$t('goods.brand.zhi')}${dateFormat(item.licensingList[i].end_time, 'yyyy-MM-dd')}` : '',
                                    checkResult: item.review_status,
                                    validDate: `${dateFormat(item.start_time, 'yyyy-MM-dd')}
                                            ${this.$t('goods.brand.zhi')}${dateFormat(item.end_time, 'yyyy-MM-dd')}`,
                                    applyDate: dateFormat(item.create_time, 'yyyy-MM-dd hh:mm:ss'),
                                    reason: item.reason
                                };
                                if (item.review_status === 1) {
                                    obj.checkResultName = this.$t('goods.brand.waitACheck');
                                } else if (item.review_status === 2) {
                                    obj.checkResultName = this.$t('goods.brand.pass');
                                } else if (item.review_status === 3) {
                                    obj.checkResultName = this.$t('goods.brand.noPass');
                                }
                                this.tableData.push(obj);
                            }
                        } else {
                            const obj = {
                                id: item.id,
                                name: item.name_en,
                                certificate: '',
                                authDate: '',
                                fileName: '',
                                checkResult: item.review_status,
                                validDate: `${dateFormat(item.start_time, 'yyyy-MM-dd')}
                                        ${this.$t('goods.brand.zhi')}${dateFormat(item.end_time, 'yyyy-MM-dd')}`,
                                applyDate: dateFormat(item.create_time, 'yyyy-MM-dd hh:mm:ss'),
                                reason: item.reason
                            };
                            if (item.review_status === 1) {
                                obj.checkResultName = this.$t('goods.brand.waitACheck');
                            } else if (item.review_status === 2) {
                                obj.checkResultName = this.$t('goods.brand.pass');
                            } else if (item.review_status === 3) {
                                obj.checkResultName = this.$t('goods.brand.noPass');
                            }
                            this.tableData.push(obj);
                        }
                    });
                    this.getOrderNumber();
                    this.pagination.pageNo = Number(data.page_index);
                    this.pagination.totalCount = data.total_num || 0;
                }
            },
            // 获取相同的id的数组
            getOrderNumber() {
                const OrderObj = {};
                this.certificateIndexArr = [];
                this.tableData.forEach((element, index) => {
                    element.rowIndex = index;
                    if (OrderObj[element.id]) {
                        OrderObj[element.id].push(index);
                    } else {
                        OrderObj[element.id] = [];
                        OrderObj[element.id].push(index);
                    }
                });

                for (const k in OrderObj) {
                    if (OrderObj[k].length > 1) {
                        this.certificateIndexArr.push(OrderObj[k]);
                    }
                }
                // console.log(this.certificateIndexArr);
            },
            objectSpanMethod({
                row, column, rowIndex, columnIndex
            }) {
                if (columnIndex !== 1 && columnIndex !== 2) {
                    for (let i = 0; i < this.certificateIndexArr.length; i += 1) {
                        const element = this.certificateIndexArr[i];
                        for (let j = 0; j < element.length; j += 1) {
                            const item = element[j];
                            if (rowIndex === item) {
                                if (j === 0) {
                                    return {
                                        rowspan: element.length,
                                        colspan: 1
                                    };
                                } if (j !== 0) {
                                    return {
                                        rowspan: 0,
                                        colspan: 0
                                    };
                                }
                            }
                        }
                    }
                }
                return {
                    rowspan: 1,
                    colspan: 1
                };
            },
            jubdgePattern(link) {
                const pdf = /.pdf$/i;
                const jpg = /.jpg$|.jpeg$/i;
                if (jpg.test(link)) {
                    return 'jpg';
                }
                if (pdf.test(link)) {
                    return 'pdf';
                }
                return 'doc';
            },
            search() {
                this.getList();
                this.turnUrl();
            },
            turnUrl() {
                this.$router.replace({
                    name: 'brandAuthList',
                    query: {
                        pageSize: this.pagination.pageSize,
                        brandCode: this.searchForm.brandCode,
                        pageNo: this.pagination.pageNo,
                        reviewStatus: this.searchForm.reviewStatus
                    }
                });
            },
            rowDelete(row) {
                if (row.checkResult === 2 || row.checkResult === 3 || row.checkResult === 0) {
                    this.rowData = row;
                    this.dialogVisible = true;
                }
            },
            async confirm() {
                const { status, msg } = await serviceBrandAuthDelete.http({
                    data: {
                        id: this.rowData.id
                    }
                });
                if (status === 0) {
                    this.$message({
                        message: this.$t('goods.deleteSuccess'),
                        type: 'success'
                    });
                } else {
                    this.$message.error(msg);
                }
                this.dialogVisible = false;
                await this.getList();
            },
            // 分页事件
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
                this.getList();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
                this.getList();
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    .container {
        background: #fff;
        font-size: 14px;
        padding: 30px 20px;
    }
    .certificate{
        width: 60px;
        height: 60px;
    }
    .certificateIcon{
        width: 30px;
        height: 40px;
    }
    .disable, .disable:hover, .disable:focus {
        color: var(--color-text-secondary);
        cursor: auto;
    }
    .center{
        text-align: center;
        font-size: 16px;
    }
    .fileName{
        width: 100px;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        display: inline-block;
    }
    .optionLeft {
        float: left;
        padding-right: 10px;
        max-width: 300px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .optionRight{
        float: right;
        padding-left: 10px;
        max-width: 300px;
        color: var(--color-text-secondary );
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: right;
    }
</style>
