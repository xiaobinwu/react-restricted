<template>
    <div class="container">
        <el-form ref="form" :model="model" :rules="rules" label-width="140px" label-position="right">
            <el-form-item
                :label="$t('goods.add.textDesc')"
                style="width: 800px;"
                prop="description_detail">
                <el-input
                    :disabled="isView"
                    :placeholder="$t('goods.add.textDescPlace')"
                    v-model="model.description_detail"
                    :rows="5"
                    max="200"
                    type="textarea">
                </el-input>
            </el-form-item>
            <el-form-item
                :label="$t('goods.add.imgDesc')"
                style="width: 800px"
                prop="image_detail">
                <p :class="$style.imgDescTips">{{ $t('goods.add.imgDescTips') }}</p>
                <div v-if="!isView" :class="$style.upload" @click="handleImageSelect">
                    <i class="icon-close"></i>
                </div>
                <div
                    v-show="model.image_detail.length"
                    :class="$style.imgDesc">
                    <el-scrollbar
                        :class="$style.imgMiniMap"
                        :wrap-class="$style.scrollWrap"
                        tag="ul">
                        <li
                            v-for="(img, index) in model.image_detail"
                            :class="$style.imgMiniItem"
                            :key="index">
                            <img :src="img">
                            <div v-if="!isView" :class="$style.imgSort">
                                <i
                                    v-for="(className, itemIndex)
                                    in getIconClasses(model.image_detail.length, index)"
                                    :key="itemIndex"
                                    :class="className"
                                    @click="handleSort(model.image_detail, index, itemIndex)">
                                </i>
                                <i :class="$style.deleteImg" @click="onDelete(index)"></i>
                            </div>
                        </li>
                    </el-scrollbar>
                    <el-scrollbar
                        :class="$style.imgPreview"
                        :wrap-class="$style.scrollWrap"
                        :view-class="$style.listInner"
                        tag="ul">
                        <li
                            v-for="(img, index) in model.image_detail"
                            :class="$style.imgPreviewItem"
                            :key="index">
                            <img :src="img">
                            <div :class="$style.imgSort">
                                <i
                                    v-for="(className, itemIndex)
                                    in getIconClasses(model.image_detail.length, index)"
                                    :key="itemIndex"
                                    :class="className"
                                    @click="handleSort(model.image_detail, index, itemIndex)">
                                </i>
                                <i :class="$style.deleteImg" @click="onDelete(index)"></i>
                            </div>
                        </li>
                    </el-scrollbar>
                </div>
            </el-form-item>
        </el-form>
        <album-photo-select
            :visible.sync="selectPhotoVisible"
            :type="['jpg']"
            :size="400"
            :width="1000"
            :limit="uploadTotal"
            :data="uploadParams"
            upload-tips="图片小于400KB，支持图片格式（JPG), 图片宽度1000px"
            width-logical="==="
            @save="handleImageSelected">
        </album-photo-select>
    </div>
</template>

<script>
    import { deepCopy } from '@/assets/js/utils/types';
    import { goodsDescForm } from './validator';
    import AlbumPhotoSelect from '@/components/AlbumPhotoSelect';

    export default {
        name: 'GoodsDesc',
        inject: ['goodsEditor'],
        components: {
            AlbumPhotoSelect
        },

        data() {
            return {
                uploadUrl: '/image-manage/image-upload',
                model: {
                    description_detail: '',
                    image_detail: []
                },
                rules: goodsDescForm,
                uploadFileName: 'uploadFile',
                uploadParams: {
                    method: 'goodsDetail'
                },
                selectPhotoVisible: false,
                uploadLimit: 20
            };
        },

        computed: {
            // 销售属性数据 - 编辑商品时
            salesData() {
                return deepCopy(this.goodsEditor.salesData);
            },
            isView() {
                return this.goodsEditor.isView;
            },
            uploadTotal() {
                return this.uploadLimit - this.model.image_detail.length;
            }
        },
        watch: {
            salesData: {
                deep: true,
                immediate: true,
                handler(val) {
                    if (!val) return;
                    this.model.description_detail = this.parseDescText(val.description_detail);
                    this.model.image_detail = this.parserDescImg(val.image_detail);
                }
            }
        },

        methods: {
            // 删除图片
            onDelete(index) {
                this.$delete(this.model.image_detail, index);
            },

            // 获取排序图标的样式 - 向上还是向下
            getIconClasses(total, index) {
                if (total === 1) {
                    return [
                        this.$style.sortUpOff,
                        this.$style.sortDownOff
                    ];
                }
                if (index === 0) {
                    return [
                        this.$style.sortUpOff,
                        this.$style.sortDown
                    ];
                }
                if (total - 1 === index) {
                    return [
                        this.$style.sortUp,
                        this.$style.sortDownOff
                    ];
                }
                return [
                    this.$style.sortUp,
                    this.$style.sortDown
                ];
            },

            // 处理排序
            handleSort(value, index, type) {
                if (type === 0 && index !== 0) {
                    value[index] = value.splice(index - 1, 1, value[index])[0];
                }
                if (type === 1 && index !== value.length - 1) {
                    value[index] = value.splice(index + 1, 1, value[index])[0];
                }
            },

            // 提交数据
            submit() {
                return new Promise((resolve, reject) => {
                    this.$refs.form.validate((valid) => {
                        if (valid) {
                            resolve(this.getData());
                        } else {
                            reject();
                        }
                    });
                });
            },

            // 获取数据
            getData() {
                const data = deepCopy(this.model);
                data.image_detail = this.genDescImgHTML(data.image_detail);
                data.description_detail = this.genDescTextHTMl(data.description_detail);
                return data;
            },

            // 生成描述图片HTML
            genDescImgHTML(imgs) {
                if (!imgs) return '';
                const imgTag = '<p><img style="max-width:100%;height:auto" src="{{links}}"></p>';

                const replace = (str, data) => {
                    Object.keys(data).forEach((key) => {
                        const reg = new RegExp(`{{\\s*?${key}\\s*?}}`);
                        str = str.replace(reg, data[key]);
                    });
                    return str;
                };

                return imgs.map(links => replace(imgTag, { links })).join('');
            },

            // 解析描述图片
            parserDescImg(htmls) {
                if (!htmls) return [];
                const reg = /<img[^>]+src=['"]([^'"]+)['"]+/g;
                const res = [];
                const next = () => reg.exec(htmls);
                let temp = next();

                while (temp != null) {
                    res.push(temp[1]);
                    temp = next();
                }
                return res;
            },

            // 生成描述文字HTML - 替换空格以及换行
            genDescTextHTMl(text) {
                return text.replace(/\n/g, '<br/>').replace(/\s/g, ' ');
            },

            // 解析描述文字HTML
            parseDescText(htmls) {
                return htmls.replace(/<br\/>/g, '\n');
            },

            // 选择图片完成
            handleImageSelected(data) {
                const images = this.model.image_detail;
                // this.$set(images, images.length, data);
                images.splice(images.length, 0, ...data);
                this.$refs.form.validateField(['image_detail']);
            },

            // 选择图片
            handleImageSelect() {
                if (this.model.image_detail.length >= this.uploadLimit) {
                    this.$message.error(this.$t('goods.add.validateUploadImgCount', [this.uploadLimit]));
                } else {
                    this.selectPhotoVisible = true;
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .imgDesc {
        display: flex;
        height: 500px;
        padding: 8px;
        margin-top: 16px;
        background: var(--background-color-base);
        border-radius: var(--border-radius);
    }

    .imgMiniMap {
        width: 100px;
    }

    .imgMiniItem {
        position: relative;
        width: 80px;
        height: 80px;
        background-color: var(--color-white);
    }

    .imgMiniItem:hover [class^="GoodsDesc_imgSort"] {
        visibility: visible;
        opacity: 1;
    }

    .imgMiniItem img {
        width: 80px;
        height: 80px;
        object-fit: cover;
    }

    .scrollWrap {
        min-height: 500px;
        overflow-y: scroll;
        height: 100%;
    }

    .listInner {
        margin-bottom: 10px;
    }

    .imgPreview {
        flex: 1;
        margin-left: 40px;
    }

    .imgPreviewItem {
        position: relative;
        width: 490px;
    }

    .imgPreviewItem:hover [class^="GoodsDesc_imgSort"] {
        visibility: visible;
        opacity: 1;
    }

    .imgPreview img {
        display: block;
        width: 490px;
        height: auto;
    }

    .imgSort {
        display: flex;
        position: absolute;
        align-items: flex-end;
        justify-content: center;
        padding-bottom: 16px;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background-color: rgba(0, 0, 0, .5);
        visibility: hidden;
        opacity: 0;
        transition: opacity var(--animation-transition-time) var(--animation-transition-timing);
    }

    .imgSort i {
        display: inline-block;
        width: 20px;
        height: 20px;
        line-height: 80px;
        background-repeat: no-repeat;
        background-size: 20px;
        cursor: pointer;
    }

    .imgSort i:nth-child(2){
        margin: 0 4px;
    }

    .sortUp {
        background-image: resolve('img/icon-goods-add-sort-up.png');
    }

    .sortUpOff {
        background-image: resolve('img/icon-goods-add-sort-up-disabled.png');
    }

    .sortDown {
        background-image: resolve('img/icon-goods-add-sort-down.png');
    }

    .sortDownOff {
        background-image: resolve('img/icon-goods-add-sort-down-disabled.png');
    }

    .deleteImg {
        background-image: resolve('img/icon-goods-img-del.png');
    }

    .imgDescTips {
        /*position: absolute;*/
        font-size: var(--font-size-base);
    }

    .imgUpload {
        text-align: center;
    }

    .upload {
        position: relative;
        width: 80px;
        height: 80px;
        border: 2px dashed #d9d9d9;
        cursor: pointer;
        overflow: hidden;
        text-align: center;
    }

    .upload [class^="icon-close"] {
        display: inline-block;
        font-size: 28px;
        line-height: 80px;
        text-align: center;
        color: rgba(153,153,153,1);
        transform: rotate(45deg);
    }
</style>
