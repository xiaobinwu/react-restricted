<template>
    <div :class="$style.container">
        <el-form ref="salesAttrsForm" :model="model" :rules="rules" label-position="right" label-width="120px" >
            <el-form-item
                v-for="attr in salesAttrs"
                :key="attr.attribute_id"
                :label="attr.attribute_name"
                :required="attr.required === 1"
                :prop="attr.attribute_id.toString()">
                <table v-if="model[attr.attribute_id]" :class="$style.attrsTable">
                    <thead>
                        <tr>
                            <th style="width: 220px">{{ model[attr.attribute_id].name }}</th>
                            <th v-if="attr.customized_name === 1" style="width: 220px">{{ $t('goods.add.customName') }}</th>
                            <th>{{ $t('goods.add.display') }}</th>
                            <th>{{ $t('goods.add.sort') }}</th>
                            <th>{{ $t('goods.add.operation') }}</th>
                        </tr>
                    </thead>
                    <tbody v-if="model[attr.attribute_id]">
                        <tr v-for="(value, index) in model[attr.attribute_id].value" :key="index">
                            <td>
                                <el-select
                                    v-model="value.id"
                                    :disabled="isView || value.noEdit"
                                    filterable
                                    @clear="onClear(
                                        model[attr.attribute_id].value,
                                        attr.attr_values,
                                        index)"
                                    @change="onSelect(
                                        $event,
                                        model[attr.attribute_id].value,
                                        attr.attr_values,
                                        index)">
                                    <el-option
                                        v-for="option in attr.attr_values"
                                        :key="option.attribute_value_id"
                                        :disabled="getOptionState(
                                            option,
                                            model[attr.attribute_id].value
                                        )"
                                        :label="option.attribute_value_name"
                                        :value="option.attribute_value_id">
                                    </el-option>
                                </el-select>
                            </td>
                            <td v-if="attr.customized_name === 1">
                                <el-input
                                    :disabled="isView || value.noEdit"
                                    :maxlength="50"
                                    :placeholder="$t('goods.add.customNamePlace')"
                                    v-model.trim="value.alias"
                                    @change="dispatchValue">
                                </el-input>
                            </td>
                            <td>
                                {{ value.alias || value.name }}
                            </td>
                            <td>
                                <template v-if="isView">
                                    <i
                                        v-for="(className, classNameIndex)
                                        in getIconClasses(model[attr.attribute_id].value, index)"
                                        :key="classNameIndex"
                                        :class="[$style.sortIcon, className]">
                                    </i>
                                </template>
                                <template v-if="!isView">
                                    <i
                                        v-for="(className, classNameIndex)
                                        in getIconClasses(model[attr.attribute_id].value, index)"
                                        :key="classNameIndex"
                                        :class="[$style.sortIcon, className]"
                                        @click="handleSort(model[attr.attribute_id].value, index, classNameIndex)">
                                    </i>
                                </template>
                            </td>
                            <td>
                                <el-button
                                    :disabled="isView || value.noEdit || model[attr.attribute_id].value.length === 1 || !value.id"
                                    type="danger"
                                    size="mini"
                                    @click="onDelete(model[attr.attribute_id].value, attr.attr_values, index)">{{ $t('base.button.del') }}</el-button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    import { LINKS } from '@/assets/js/constant/reg';
    import { GB_HOST } from '@/assets/js/constant/other';
    import emitter from '@/assets/js/mixins/emitter';
    import { deepCopy, map } from '@/assets/js/utils/types';

    export default {
        name: 'GoodsAttr',
        inject: ['goodsEditor'],
        mixins: [emitter],

        data() {
            return {
                model: {},
                rules: {}
            };
        },

        computed: {
            // 销售属性
            salesAttrs() {
                return this.goodsEditor.salesAttrs || [];
            },
            // 属性 id
            propertyIds() {
                return this.salesAttrs.map(item => item.attribute_id);
            },
            // 属性的数据 - 编辑的商品时
            salesData() {
                return deepCopy(this.goodsEditor.salesData) || [];
            },
            // 是否编辑状态
            isEditor() {
                return this.goodsEditor.isEditor;
            },
            isView() {
                return this.goodsEditor.isView;
            },
            isSaved() {
                return +this.$route.query.review_type === 1;
            }
        },

        watch: {
            salesAttrs: {
                deep: true,
                handler(val) {
                    if (!val) return;
                    this.rules = this.genValidateRules(val);
                    // 新建
                    if (!this.goodsEditor.isEditor) {
                        this.model = this.genAttrsData(val);
                    } else {
                        // 编辑
                        const data = this.getAttrsData(this.salesData.specifications, val);
                        this.model = Object.assign(this.genAttrsData(val), data);
                    }
                }
            }
        },

        created() {
            this.$on('on-sales-attr-delete', ({ sku }) => {
                for (const { id, value } of sku) {
                    const spu = this.model[id];
                    const index = spu.value.findIndex(item => item.id === value.id);
                    // 保留一个空的选项
                    if (spu.value.length > 2) {
                        spu.value.splice(index, 1);
                    } else { // 最后一个只清空数据
                        spu.value.splice(index, 1, this.getAttrTemp());
                    }
                }
                // this.dispatchValue();
            });
        },

        methods: {
            // 验证数据
            submit() {
                return new Promise((resolve, reject) => {
                    this.$refs.salesAttrsForm.validate((valid) => {
                        if (valid) {
                            resolve();
                        } else {
                            reject();
                        }
                    });
                });
            },

            // 清除选择
            onClear(value, values, index) {
                value[index].name = '';
                this.dispatchValue();
            },

            // 选择事件
            onSelect(id, value, values, index) {
                if (!id) return;
                const [selected] = values.filter(item => item.attribute_value_id === id);
                value[index].name = selected.attribute_value_name;
                this.addValue(index, value, values);
                this.dispatchValue();
            },

            // 删除事件
            onDelete(value, values, index) {
                const count = value.length;
                const selectAll = value.filter(item => item.id).length === values.length;
                // 只剩一个不能删除
                if (count > 1) {
                    this.$delete(value, index);
                    // 全选的时候删除，在最后添加空的一行
                    if (selectAll) {
                        this.addValue(value.length - 1, value, values);
                    }
                    this.dispatchValue();
                }
            },

            // 添加新的一行
            addValue(index, value, values) {
                const length = value.length;
                // 最后一行点击 && 选项有剩余
                if (index === length - 1 && index < values.length - 1) {
                    this.$set(value, length, this.getAttrTemp());
                }
            },

            // 派发事件 - 给 <sales-spec/> 组件更新数据
            dispatchValue() {
                this.dispatch('SalesInfo', 'on-sales-spec-add', {
                    attrs: this.getValidSkuData()
                });
            },

            // 处理排序
            handleSort(value, index, type) {
                const lastIndex = index === value.length - 1;
                // 没有值不能移动
                if (!value[index].id) return;

                // 下一条没有值不能下移
                if (!lastIndex && !value[index + 1].id && type === 1) return;

                if (type === 0 && index !== 0) {
                    value[index] = value.splice(index - 1, 1, value[index])[0];
                }

                if (type === 1 && index !== value.length - 1) {
                    value[index] = value.splice(index + 1, 1, value[index])[0];
                }

                this.dispatchValue();
            },

            // 获取有效的SKU数据
            getValidSkuData() {
                const props = this.model;
                const ids = this.propertyIds;
                // 过滤无效的 SKU 属性
                return ids.map(id => deepCopy(props[id])).filter((item) => {
                    item.value = item.value.filter(value => value.id);
                    return !!item.value.length;
                });
            },

            // 获取属性的模板 - 与提交数据结构一致
            getAttrTemp() {
                return {
                    id: '',
                    name: '',
                    alias: ''
                };
            },

            // 获取选项的状态 - 是否能选择下拉组件的某个值
            getOptionState(option, selected) {
                const selectedMap = map(selected, 'id');
                return !!selectedMap[option.attribute_value_id];
            },

            // 获取排序图标的样式 - 向上还是向下
            getIconClasses(values, index) {
                const total = values.length;
                const lastIndex = index === total - 1;

                // 没有值不能移动
                if (!values[index].id) {
                    return [
                        this.$style.sortUpOff,
                        this.$style.sortDownOff
                    ];
                }

                // 非最后一条 && 下一条没有值
                if (!lastIndex && !values[index + 1].id) {
                    if (index === 0) {
                        return [
                            this.$style.sortUpOff,
                            this.$style.sortDownOff
                        ];
                    }
                    return [
                        this.$style.sortUp,
                        this.$style.sortDownOff
                    ];
                }

                // 只有一条
                if (total === 1) {
                    return [
                        this.$style.sortUpOff,
                        this.$style.sortDownOff
                    ];
                }

                // 第一条
                if (index === 0) {
                    return [
                        this.$style.sortUpOff,
                        this.$style.sortDown
                    ];
                }

                // 最后一条
                if (total - 1 === index) {
                    return [
                        this.$style.sortUp,
                        this.$style.sortDownOff
                    ];
                }

                // 其他
                return [
                    this.$style.sortUp,
                    this.$style.sortDown
                ];
            },

            // 生成属性数据 - 新建商品时
            genAttrsData(data) {
                return data.reduce((acc, item) => {
                    const id = item.attribute_id;
                    const temp = this.getAttrTemp();
                    if (this.isEditor && !this.isSaved) {
                        temp.noEdit = true;
                    }
                    acc[id] = {
                        id,
                        name: item.attribute_name,
                        value: [temp]
                    };
                    return acc;
                }, {});
            },

            // 获取属性数据 - 编辑商品时
            getAttrsData(data, attrs) {
                const res = {};
                const attrsMap = map(attrs, 'attribute_id');
                for (const spec of data) {
                    for (const attr of spec.sku_attributes) {
                        const id = attr.id;
                        const value = attr.value;
                        // 编辑时不允许修改已有数据
                        if (this.isEditor && !this.isSaved) {
                            value.noEdit = true;
                        }
                        if (!res[id]) {
                            res[id] = attr;
                            // 在后面添加空的一行
                            res[id].value = [value, this.getAttrTemp()];
                            // 全选了所有值不需要添加新的一行
                            if (res[id].value.length > attrsMap[id].attr_values.length) {
                                res[id].value.pop();
                            }
                        } else {
                            const filterValue = [...res[id].value].filter(item => !!item.id);
                            const valueMap = map(filterValue, 'id');
                            if (!valueMap[value.id]) {
                                res[id].value.pop();
                                res[id].value.push(value);
                                // 全选了所有值不需要添加新的一行
                                if (res[id].value.length < attrsMap[id].attr_values.length) {
                                    res[id].value.push(this.getAttrTemp());
                                }
                            }
                        }
                    }
                }
                return res;
            },

            // 生成表单验证规则 - 提供给 <el-form /> 组件
            genValidateRules(salesAttrs) {
                return salesAttrs.reduce((acc, item) => {
                    const id = item.attribute_id;
                    acc[id] = [{
                        required: item.required === 1,
                        validator: (rules, attribute, callback) => {
                            const validValue = [...attribute.value].filter(attr => attr.id || attr.alias);
                            if (!validValue.length && rules.required) {
                                callback(new Error(this.$t('goods.add.validateSelectAttr', [attribute.name])));
                            }
                            validValue.forEach((value) => {
                                const matched = value.alias.match(LINKS);
                                if (value.alias && matched && !matched.every(url => url.includes(GB_HOST))) {
                                    callback(new Error(this.$t('goods.add.validateDelOtherUrl')));
                                }
                                if (value.alias && !/^[A-Za-z0-9\s]{0,50}$/.test(value.alias)) {
                                    callback(new Error(this.$t('goods.add.validateConstomName')));
                                }
                                if (value.alias && !value.id) {
                                    callback(new Error(this.$t('goods.add.validateSelectAttr', [attribute.name])));
                                }
                            });
                            callback();
                        },
                        trigger: ['blur', 'change']
                    }];
                    return acc;
                }, {});
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        padding: 30px 55px 30px 0;
    }

    .attrsTable {
        width: 100%;
        table-layout: fixed;
        border: 1px solid var(--border-color-lighter);
        border-collapse:collapse;
    }

    .attrsTable thead {
        background-color: #fafafa;
    }

    .attrsTable thead th {
        line-height: 40px;
        color: var(--color-text-primary);
        font-size: var(--font-size-base);
        border-bottom: 1px solid var(--border-color-lighter);
        font-weight: 400;
    }

    .attrsTable tbody td {
        padding: 12px 20px;
        text-align: center;
        border-bottom: 1px solid var(--border-color-lighter);
    }

    .attrsTable tbody tr:nth-child(even) {
        background-color: #fafafa;
    }

    .sortIcon {
        display: inline-block;
        width: 24px;
        height: 24px;
        background-repeat: no-repeat;
        cursor: pointer;
        vertical-align: middle;
    }

    .sortUp {
        background-image: resolve('img/icon-goods-add-sort-up.png');
    }

    .sortUpOff {
        background-image: resolve('img/icon-goods-add-sort-up-disabled.png');
    }

    .sortDown {
        background-image: resolve('img/icon-goods-add-sort-down.png');
    }

    .sortDownOff {
        background-image: resolve('img/icon-goods-add-sort-down-disabled.png');
    }
</style>
