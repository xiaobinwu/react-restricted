// 商品规格表单校验规则
import { LINKS } from '@/assets/js/constant/reg';
import { GB_HOST } from '@/assets/js/constant/other';

export const specFormRules = {
    present_price: [
        {
            type: 'number',
            require: true,
            message: window.$$lang.translate('goods.add.requireGoodsPrice'),
            trigger: 'change'
        },
        {
            type: 'number',
            message: window.$$lang.translate('base.validate.number'),
            trigger: 'change'
        },
        {
            type: 'number',
            min: 0.01,
            max: 1000000,
            message: window.$$lang.translate('base.validate.range', [0.01, 1000000]),
            trigger: 'change'
        },
        {
            validator(rules, value, callback) {
                if (!/^\d+(\.\d{0,2})?$/.test(value)) {
                    callback(new Error(window.$$lang.translate('base.validate.decimalPoint', [2])));
                } else {
                    callback();
                }
            },
            trigger: 'change'
        }
    ],
    stock_num: [
        {
            type: 'number',
            require: true,
            message: window.$$lang.translate('goods.add.requireGoodsStock'),
            trigger: 'change'
        },
        {
            type: 'number',
            message: window.$$lang.translate('base.validate.number'),
            trigger: 'change'
        },
        {
            type: 'integer',
            message: window.$$lang.translate('base.validate.integer'),
            trigger: 'change'
        },
        {
            type: 'number',
            min: 0,
            max: 1000000,
            message: window.$$lang.translate('base.validate.range', [0, 1000000]),
            trigger: 'change'
        }
    ],
    seller_sku: {
        validator(rules, value, callback) {
            const matched = value.match(LINKS);
            if (matched && !matched.every(url => url.includes(GB_HOST))) {
                callback(new Error(window.$$lang.translate('goods.add.validateDelOtherUrl')));
            }
            if (value.length > 15) {
                callback(new Error(window.$$lang.translate('base.validate.length', [15])));
            }
            if (value && !/^[A-Za-z0-9]+?$/.test(value)) {
                callback(new Error(window.$$lang.translate('base.validate.lettersNumbers')));
            }
            callback();
        },
        trigger: 'change'
    },
    image_urls: {
        validator(rules, value, callback) {
            if (!value) {
                callback(new Error(window.$$lang.translate('goods.add.requireGoodsMainImg')));
            }
            callback();
        },
        trigger: 'blur'
    }
};

// 商品视频校验规则
export const goodsVideoForm = {
    video_urls: {
        validator(rules, value, callback) {
            // https://www.youtube.com/watch?v=4mPERVGRqOM
            const reg = /^https?:\/\/www.youtube.com\/watch\?v=.+$/;
            if (value && !reg.test(value)) {
                callback(new Error(window.$$lang.translate('goods.add.validateVideo', ['https://www.youtube.com/watch?v=****'])));
            } else {
                callback();
            }
        },
        trigger: 'blur'
    }
};


// 商品描述表单校验规则
export const goodsDescForm = {
    description_detail: {
        validator(rules, value, callback) {
            const matched = value.match(LINKS);
            if (matched && !matched.every(url => url.includes(GB_HOST))) {
                callback(new Error(window.$$lang.translate('goods.add.validateDelOtherUrl')));
            } else if (value.length > 2000) {
                callback(new Error(window.$$lang.translate('base.validate.length', [2000])));
            } else if (/[\u4E00-\u9FA5]/i.test(value)) {
                callback(new Error(window.$$lang.translate('goods.add.validateDescTextCn')));
            } else {
                callback();
            }
        },
        trigger: 'blur'
    },
    image_detail: {
        required: true,
        validator(rules, value, callback) {
            if (!value.length) {
                callback(new Error(window.$$lang.translate('goods.add.requireImgDesc')));
            } else {
                callback();
            }
        },
        trigger: 'blur'
    }
};


// 商品图片校验
export const goodsImgForm = {
    image_urls: {
        required: true,
        validator(rules, value, callback) {
            if (!value.length) {
                callback(new Error(window.$$lang.translate('goods.add.requireImg')));
            } else {
                callback();
            }
        },
        trigger: 'blur'
    }
};
