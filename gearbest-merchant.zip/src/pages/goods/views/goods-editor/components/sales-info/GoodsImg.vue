<template>
    <div class="container">
        <el-form ref="form" :model="model" :rules="rules" label-width="150px" label-position="right">
            <el-form-item :label="$t('goods.add.goodsImg')" prop="image_urls">
                <div :class="$style.imgTips">
                    {{ $t('goods.add.goodsImgTips') }}
                    <el-popover
                        placement="bottom"
                        width="400"
                        trigger="click">
                        <i slot="reference" class="icon-question"></i>
                        <template>
                            <div :class="$style.goodsImageTips">
                                <p> {{ $t('goods.add.goodsImgPoperTips1') }}</p>
                                <p> {{ $t('goods.add.goodsImgPoperTips2') }}</p>
                                <p> {{ $t('goods.add.goodsImgPoperTips3') }}</p>
                                <p> {{ $t('goods.add.goodsImgPoperTips4') }}</p>
                                <p> {{ $t('goods.add.goodsImgPoperTips5') }}</p>
                            </div>
                        </template>
                    </el-popover>
                </div>
                <div :class="$style.uploadList">
                    <div v-for="(img, index) in model.image_urls" :key="index" :class="$style.uploadListItem">
                        <img :src="img">
                        <div v-if="!isView" :class="$style.uploadDel">
                            <i class="icon-close" @click="onDelete(index)"></i>
                        </div>
                    </div>
                    <div v-if="!isView" :class="$style.upload" @click="handleImageSelect">
                        <i class="icon-close"></i>
                    </div>
                </div>
            </el-form-item>
        </el-form>

        <album-photo-select
            :visible.sync="selectPhotoVisible"
            :type="['jpg']"
            :size="1024"
            :width="800"
            :height="800"
            :radio="[1, 1.3333]"
            :limit="uploadTotal"
            :data="uploadParams"
            width-logical=">="
            height-logical=">="
            upload-tips="图片小于1MB、格式要求（JPG)、比例要求1:1.333"
            @save="handleImageSelected">
        </album-photo-select>
    </div>
</template>

<script>
    import { deepCopy } from '@/assets/js/utils/types';
    import { goodsImgForm } from './validator';

    import AlbumPhotoSelect from '@/components/AlbumPhotoSelect';

    export default {
        name: 'GoodsImg',
        inject: ['goodsEditor'],
        components: {
            AlbumPhotoSelect
        },

        data() {
            return {
                uploadUrl: '/image-manage/image-upload',
                model: {
                    image_urls: []
                },
                rules: goodsImgForm,
                uploadFileName: 'uploadFile',
                uploadParams: {
                    method: 'goodsImage'
                },
                selectPhotoVisible: false,
                uploadLimit: 10
            };
        },

        computed: {
            // 销售属性数据 - 编辑商品时
            salesData() {
                return deepCopy(this.goodsEditor.salesData);
            },
            isView() {
                return this.goodsEditor.isView;
            },
            uploadTotal() {
                return this.uploadLimit - this.model.image_urls.length;
            }
        },

        watch: {
            salesData: {
                deep: true,
                immediate: true,
                handler(val) {
                    if (!val) return;
                    this.model.image_urls = val.image_urls;
                }
            }
        },

        methods: {
            onDelete(index) {
                this.$delete(this.model.image_urls, index);
            },

            // 提交数据
            submit() {
                return new Promise((resolve, reject) => {
                    this.$refs.form.validate((valid) => {
                        if (valid) {
                            resolve(this.getData());
                        } else {
                            reject();
                        }
                    });
                });
            },

            // 获取数据
            getData() {
                return deepCopy(this.model);
            },

            // 选择图片完成
            handleImageSelected(data) {
                const images = this.model.image_urls;
                // this.$set(images, images.length, data);
                images.splice(images.length, 0, ...data);
                this.$refs.form.validateField(['image_urls']);
            },

            // 选择图片
            handleImageSelect() {
                if (this.model.image_urls.length >= this.uploadLimit) {
                    this.$message.error(this.$t('goods.add.validateUploadImgCount', [10]));
                } else {
                    this.selectPhotoVisible = true;
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .uploadContent {
        display: flex;
    }

    .upload {
        position: relative;
        width: 80px;
        height: 80px;
        border: 2px dashed #d9d9d9;
        text-align: center;
        cursor: pointer;
        overflow: hidden;
    }

    .upload [class^="icon-close"] {
        display: inline-block;
        font-size: 28px;
        line-height: 80px;
        text-align: center;
        color: rgba(153,153,153,1);
        transform: rotate(45deg);
    }

    .uploadList {
        display: flex;
        flex-wrap: wrap;
    }

    .uploadListItem {
        position: relative;
        width: 80px;
        height: 80px;
        margin-right: 20px;
        margin-bottom: 20px;
    }

    .uploadList img {
        width: 80px;
        height: 80px;
    }

    .uploadListItem:hover [class^="GoodsImg_uploadDel"] {
        visibility: visible;
        opacity: 1;
    }

    .uploadDel {
        display: flex;
        align-items: center;
        justify-content: center;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.7);
        visibility: hidden;
        opacity: 0;
        transition: opacity var(--animation-transition-time) var(--animation-transition-timing);
    }

    .uploadDel [class^="icon-close"] {
        font-size: 18px;
        color: white;
        cursor: pointer;
    }

    .imgTips {
        /*position: absolute;*/
        font-size: var(--font-size-base);
        line-height: 1;
        margin: 14px 0 20px 0;
    }

    .imgTips [class^="icon-question"] {
        font-size: 24px;
        vertical-align: -3px;
        color: var(--color-text-regular);
        cursor: pointer;
    }

    .goodsImageTips {
        line-height: 1.6;
    }

    .goodsImageTips p {
        padding-bottom: 5px;
    }
</style>
