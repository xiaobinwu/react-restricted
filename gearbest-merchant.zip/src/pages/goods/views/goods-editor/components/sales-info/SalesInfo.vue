<template>
    <div class="container">
        <goods-attribute ref="goodsAttrs"></goods-attribute>
        <goods-spec ref="goodsSpec"></goods-spec>
        <goods-img></goods-img>
        <goods-video></goods-video>
        <goods-desc></goods-desc>
    </div>
</template>

<script>
    import emitter from '@/assets/js/mixins/emitter';
    import GoodsAttribute from './GoodsAttr';
    import GoodsSpec from './GoodsSpec';
    import GoodsVideo from './GoodsVideo';
    import GoodsDesc from './GoodsDesc';
    import GoodsImg from './GoodsImg';

    export default {
        name: 'SalesInfo',
        inject: ['goodsEditor'],
        components: {
            GoodsAttribute,
            GoodsSpec,
            GoodsVideo,
            GoodsDesc,
            GoodsImg
        },
        mixins: [emitter],

        data() {
            return {
                msg: 'fuck'
            };
        },

        created() {
            this.$on('on-sales-attr-delete', (data) => {
                this.broadcast('GoodsAttr', 'on-sales-attr-delete', data);
            });
            this.$on('on-sales-spec-add', (data) => {
                this.broadcast('GoodsSpec', 'on-sales-spec-add', data);
            });
        },

        methods: {
            // 提交校验
            submit() {
                const submitPromise = this.$children.reduce((acc, child) => {
                    if (child.submit) {
                        acc.push(child.submit());
                    }
                    return acc;
                }, []);

                return Promise.all(submitPromise).then(response => this.getData());
            },

            // 保存提交校验
            submitForSave() {
                return Promise.all([
                    this.$refs.goodsAttrs.submit(),
                    this.$refs.goodsSpec.submit()
                ]);
            },

            // 获取子组件的数据
            getData() {
                const data = this.$children.reduce((acc, child) => {
                    if (child.getData) {
                        acc = Object.assign(acc, child.getData());
                    }
                    return acc;
                }, {});

                return {
                    sale_infos: data
                };
            }
        },
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        color: red;
    }
</style>
