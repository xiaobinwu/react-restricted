<template>
    <div :class="$style.container">
        <p :class="$style.title">{{ $t('goods.add.goodsSpec') }}</p>
        <div :class="$style.tableContent">
            <div :class="$style.tableScroll">
                <table :class="$style.specTable">
                    <thead>
                        <tr>
                            <th>
                                <el-checkbox
                                    :disabled="isView"
                                    v-model="selectAll"
                                    @change="onSelectAll"/>
                            </th>
                            <th v-for="(name, index) in tableHeadNames"
                                :key="index">
                                {{ name }}
                            </th>
                            <th><span :class="$style.required">*</span>{{ $t('goods.add.goodsPrice') }}</th>
                            <th><span :class="$style.required">*</span>{{ $t('goods.add.goodsStock') }}</th>
                            <th>{{ $t('goods.add.goodsCode') }}</th>
                            <th><span :class="$style.required">*</span>{{ $t('goods.add.goodsCoverImg') }}
                                <el-popover
                                    placement="bottom-end"
                                    width="400"
                                    trigger="click">
                                    <i slot="reference" class="icon-question"></i>
                                    <template>
                                        <div :class="$style.goodsImageTips">
                                            <p> {{ $t('goods.add.goodsImgPoperTips1') }}</p>
                                            <p> {{ $t('goods.add.goodsImgPoperTips2') }}</p>
                                            <p> {{ $t('goods.add.goodsImgPoperTips3') }}</p>
                                            <p> {{ $t('goods.add.goodsImgPoperTips4') }}</p>
                                            <p> {{ $t('goods.add.goodsImgPoperTips5') }}</p>
                                            <p> {{ $t('goods.add.goodsImgPoperTips6') }}</p>
                                        </div>
                                    </template>
                                </el-popover>
                            </th>
                            <th>{{ $t('goods.add.goodsOperaiton') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(sku, index) in skuModel" :key="index">
                            <td>
                                <el-checkbox
                                    :disabled="isView"
                                    v-model="sku.select">
                                </el-checkbox>
                            </td>
                            <td v-for="(prop, valueIndex) in sku.sku_attributes"
                                :key="valueIndex">
                                {{ prop.value.alias || prop.value.name }}
                            </td>
                            <td>
                                <el-form
                                    ref="skuForm"
                                    :model="sku"
                                    :rules="rules">
                                    <el-form-item prop="present_price">
                                        <el-input
                                            :disabled="isView"
                                            v-model.number="sku.present_price"
                                            type="number"
                                            style="min-width: 120px">
                                            <span slot="prefix" :class="$style.inputPrefix">$</span>
                                        </el-input>
                                    </el-form-item>
                                </el-form>
                            </td>
                            <td>
                                <el-form ref="skuForm" :model="sku" :rules="rules">
                                    <el-form-item prop="stock_num">
                                        <el-input
                                            :disabled="isView"
                                            v-model.number="sku.stock_num"
                                            type="number"
                                            style="min-width: 120px"/>
                                    </el-form-item>
                                </el-form>
                            </td>
                            <td>
                                <el-form
                                    ref="skuForm"
                                    :model="sku"
                                    :rules="rules">
                                    <el-form-item prop="seller_sku">
                                        <el-input
                                            :disabled="isView"
                                            v-model="sku.seller_sku"
                                            style="min-width: 200px"/>
                                    </el-form-item>
                                </el-form>
                            </td>
                            <td>
                                <el-form
                                    ref="skuForm"
                                    :model="sku"
                                    :rules="rules">
                                    <el-form-item prop="image_urls">
                                        <div v-if="!isView && !sku.image_urls" :class="$style.upload" @click="handleImageSelect(index)">
                                            <i class="icon-close"></i>
                                        </div>
                                        <div v-else :class="$style.uploadPreview">
                                            <img :src="sku.image_urls">
                                            <div v-if="!isView" class="delete" @click="onImageDelete(sku)">
                                                <i class="icon-close"></i>
                                            </div>
                                        </div>
                                    </el-form-item>
                                </el-form>
                            </td>
                            <td>
                                <el-button
                                    :disabled="isView || !!sku.variation_id"
                                    type="danger"
                                    size="mini"
                                    @click="onDelete(sku, index)">
                                    {{ $t('base.button.del') }}
                                </el-button>
                            </td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td></td>
                            <td :class="$style.textLeft">
                                <el-input
                                    v-model.number="priceValue"
                                    :clearable="true"
                                    :disabled="isView || !batchable"
                                    :placeholder="$t('goods.add.batchAddPricePlace')"
                                    type="number"
                                    style="width: 150px">
                                    <span slot="prefix" :class="$style.inputPrefix">$</span>
                                </el-input>
                            </td>
                            <td>
                                <el-button
                                    :disabled="isView || !batchable"
                                    type="primary"
                                    size="small"
                                    @click="handleAllPrice(priceValue, 'add')">
                                    {{ $t('goods.add.batchAdd') }}
                                </el-button>
                            </td>
                            <td>
                                <el-button
                                    :disabled="isView || !batchable"
                                    type="danger"
                                    size="small"
                                    @click="handleAllPrice('')">
                                    {{ $t('goods.add.batchClear') }}
                                </el-button>
                            </td>
                            <td v-for="num in colNum - 4" :key="num"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td :class="$style.textLeft">
                                <el-input
                                    v-model.number="stockValue"
                                    :disabled="isView || !batchable"
                                    :placeholder="$t('goods.add.batchAddStockPlace')"
                                    type="number"
                                    style="width: 150px">
                                </el-input>
                            </td>
                            <td>
                                <el-button
                                    :disabled="isView || !batchable"
                                    type="primary"
                                    size="small"
                                    @click="handleAllStock(stockValue, 'add')">
                                    {{ $t('goods.add.batchAdd') }}
                                </el-button>
                            </td>
                            <td>
                                <el-button
                                    :disabled="isView || !batchable"
                                    type="danger"
                                    size="small"
                                    @click="handleAllStock('')">
                                    {{ $t('goods.add.batchClear') }}
                                </el-button>
                            </td>
                            <td v-for="num in (colNum - 4)" :key="num"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td :class="$style.textLeft">
                                <el-button
                                    v-if="!isView && batchable"
                                    type="primary"
                                    size="small"
                                    @click="handleImageSelect(-1)">
                                    {{ $t('goods.add.batchAddCover') }}
                                </el-button>
                                <el-button
                                    v-else
                                    :disabled="isView || !batchable"
                                    type="primary"
                                    size="small"
                                    @click="hasSelected">
                                    {{ $t('goods.add.batchAddCover') }}
                                </el-button>
                            </td>
                            <td>
                                <el-button
                                    :disabled="isView || !batchable"
                                    type="danger"
                                    size="small"
                                    @click="batchDeleteImage('')">
                                    {{ $t('goods.add.batchDelCover') }}
                                </el-button>
                            </td>
                            <td v-for="num in (colNum - 3)" :key="num"></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <div :class="$style.stockTotal">
            <span :class="$style.name">
                {{ $t('goods.add.stockTotal') }}
            </span>
            <div :class="$style.content">
                <el-input :value="totalStockNum" disabled></el-input>
            </div>
        </div>
        <album-photo-select
            :visible.sync="selectPhotoVisible"
            :type="['jpg']"
            :size="1024"
            :width="800"
            :height="800"
            :radio="[1, 1.3333]"
            :limit="1"
            :data="uploadParams"
            upload-tips="图片小于1MB，图片格式（JPG), 图片比例1:1.333"
            width-logical=">="
            height-logical=">="
            @save="handleImageSelected"
            @cancel="handleImageCancel">
        </album-photo-select>
    </div>
</template>

<script>
    import { deepCopy, map } from '@/assets/js/utils/types';
    import emitter from '@/assets/js/mixins/emitter';
    import { specFormRules } from './validator';
    import AlbumPhotoSelect from '@/components/AlbumPhotoSelect';

    export default {
        name: 'GoodsSpec',
        inject: ['goodsEditor'],
        components: {
            AlbumPhotoSelect
        },
        mixins: [emitter],

        data() {
            return {
                skuKeys: new Set(),
                skuMaps: new Map(),
                skuModel: [], // 纯 sku 数据
                spuNames: [], // SKU 的名字
                isIndeterminate: false,
                batchable: false,
                selectAll: false,
                priceValue: '',
                stockValue: '',
                rules: specFormRules,
                uploadUrl: '/image-manage/image-upload',
                uploadFileName: 'uploadFile',
                uploadParams: {
                    method: 'goodsImage'
                },
                selectPhotoVisible: false,
                uploadRow: ''
            };
        },

        computed: {
            // 销售属性
            salesAttrs() {
                return this.goodsEditor.salesAttrs || [];
            },
            // 销售属性数据 - 编辑商品时
            salesData() {
                return deepCopy(this.goodsEditor.salesData);
            },
            // 必选的属性名
            requiredAttrNames() {
                return this.salesAttrs.reduce((acc, item) => {
                    if (item.required === 1) {
                        acc.push(item.attribute_name);
                    }
                    return acc;
                }, []);
            },
            // 表头项
            tableHeadNames() {
                return this.spuNames.length
                    ? this.spuNames
                    : this.requiredAttrNames;
            },
            // 列数
            colNum() {
                return this.tableHeadNames.length + 6;
            },
            // 库存数
            totalStockNum() {
                return this.skuModel.reduce((count, item) => {
                    count += item.stock_num;
                    return count;
                }, 0) || '';
            },
            // 选择的SKU
            selected() {
                return this.skuModel.filter(item => item.select);
            },
            // 预览模式
            isView() {
                return this.goodsEditor.isView;
            }
        },

        watch: {
            salesData: {
                deep: true,
                immediate: true,
                handler(val) {
                    if (!val) return;
                    const {
                        model, keys, maps, names
                    } = this.getSkuData(val);

                    this.skuModel = model;
                    this.skuKeys = keys;
                    this.skuMaps = maps;
                    this.spuNames = names;
                }
            },
            selected(val) {
                this.selectAll = val.length === this.skuModel.length;
                // 可否批量操作
                this.batchable = !!val.length;
            }
        },
        created() {
            this.$on('on-sales-spec-add', ({ attrs }) => {
                this.updateSku(attrs);
            });
        },

        methods: {
            // 选择所有
            onSelectAll(val) {
                this.skuModel.forEach((prop) => {
                    this.$set(prop, 'select', val);
                });
                this.selectAll = val;
            },

            // 删除商品规格
            onDelete(row, index) {
                const deleteSku = [];

                row.sku_attributes.forEach((sku) => {
                    // 当前SKU属性被组合几次
                    const count = this.skuModel.reduce((acc, item) => {
                        const skus = map(item.sku_attributes, 'id');
                        const currSku = skus[sku.id];
                        if (currSku.value.id === sku.value.id) {
                            acc += 1;
                        }
                        return acc;
                    }, 0);

                    // 组合次数小于等于1的属性可以直接删除
                    if (count <= 1) {
                        deleteSku.push(sku);
                    }
                    console.log(sku.value.name, ' - 组合数次 -', count);
                });

                const key = this.genKeyForSku(row);
                this.dispatchValue(deleteSku);
                this.$delete(this.skuModel, index);
                this.skuKeys.delete(key);
                this.skuMaps.delete(key);
            },

            // 批量设置价格
            handleAllPrice(val, type) {
                if (!this.hasSelected()) return;
                if (!val && type === 'add') {
                    this.$message.error(this.$t('goods.add.valdiateInputPrice'));
                }
                this.updateForSelected('present_price', val);
            },

            // 批量设置库存
            handleAllStock(val, type) {
                if (!this.hasSelected()) return;
                if (val === '' && type === 'add') {
                    this.$message.error(this.$t('goods.add.valdiateInputStock'));
                }
                this.updateForSelected('stock_num', val);
            },

            // 删除主图
            onImageDelete(props) {
                this.$set(props, 'image_urls', '');
            },

            // 主图上传成功
            onUploadSuccess(index, props, data) {
                const self = this;
                this.$set(props, 'image_urls', data);
                // 上传图片事件后重新校验
                self.$refs.skuForm[(index + 1) * 4 - 1].validateField('image_urls');
            },

            // 获取数据 - 提交数据
            getData() {
                return {
                    specifications: deepCopy(this.skuModel)
                };
            },

            // 批量上传图片 - 成功回调
            batchUploadSuccess(url) {
                this.updateForSelected('image_urls', url);
                // 批量上传后重新校验
                this.$refs.skuForm.forEach((item, index) => {
                    if (index > 0 && (index + 1) % 4 === 0) {
                        item.validateField('image_urls');
                    }
                });
            },

            // 批量删除图片
            batchDeleteImage() {
                if (!this.hasSelected()) return;
                this.updateForSelected('image_urls');
            },

            // 更新选择的商品规格的值
            updateForSelected(key, val = '') {
                for (const item of this.selected) {
                    this.$set(item, key, val);
                }
            },

            // 批量修改校验
            hasSelected() {
                if (this.selected <= 0) {
                    this.$message.warning(this.$t('goods.add.validateSelectSpec'));
                    return false;
                }
                return true;
            },

            // 派发事件给 <sales-attr/> 组件
            dispatchValue(sku) {
                this.dispatch('SalesInfo', 'on-sales-attr-delete', { sku });
            },

            // 获取 SKU 模板 - 与提交数据结构一致
            getSkuTemp() {
                return {
                    image_urls: '',
                    present_price: '',
                    seller_sku: '',
                    sku_attributes: [],
                    stock_num: '',
                    variation_id: ''
                };
            },

            // 生成 SKU 数据 - 新建
            genSkuData(properties) {
                const model = [];
                const names = new Set();
                const keys = new Set();
                const maps = new Map();

                const generate = (index = 0, current = []) => {
                    const prop = properties[index];
                    const id = prop.id;
                    const name = prop.name;
                    const value = prop.value;

                    names.add(prop.name);

                    for (let i = 0; i < value.length; i += 1) {
                        const props = [...current, {
                            id,
                            name,
                            value: value[i]
                        }];

                        if (index < properties.length - 1) {
                            generate(index + 1, props);
                        } else {
                            const temp = {
                                ...this.getSkuTemp(),
                                sku_attributes: [...props]
                            };
                            const key = this.genKeyForSku(temp);

                            model.push(temp);
                            keys.add(key);
                            maps.set(key, temp);
                        }
                    }
                };

                generate();

                return {
                    model,
                    keys,
                    maps,
                    names: [...names],
                };
            },

            // 获取SKU数据 - 编辑
            getSkuData(prop) {
                const model = deepCopy(prop.specifications);
                const keys = new Set();
                const maps = new Map();
                const names = new Set();

                model.forEach((item) => {
                    const key = this.genKeyForSku(item);
                    keys.add(key);
                    maps.set(key, item);
                    item.sku_attributes.forEach((pro) => {
                        names.add(pro.name);
                    });
                });

                return {
                    model,
                    keys,
                    maps,
                    names: [...names]
                };
            },

            // 更新SKU
            updateSku(props) {
                // // SKU必选项的个数 - 暂时屏蔽
                // const count = props.reduce((acc, item) => {
                //     if (this.requiredAttrNames.includes(item.name)) {
                //         acc += 1;
                //     }
                //     return acc;
                // }, 0);

                // 计算SKU
                // if (count === this.requiredAttrNames.length && props.length) {
                if (props.length) {
                    const {
                        model, names, maps, keys
                    } = this.genSkuData(props);
                    // 第一次生成
                    this.spuNames = names;
                    if (!this.skuMaps.size) {
                        this.skuModel = model;
                        this.skuMaps = maps;
                        this.skuKeys = keys;
                    } else { // 对比数据
                        const newModel = [];
                        const skuKeys = new Set();
                        const skuMaps = new Map();
                        model.forEach((sku) => {
                            const key = this.genKeyForSku(sku);
                            // 当前 skuKeys 里有，就复用之前的数据
                            // 当前 skuKeys 里没有，证明之前删除了
                            if (this.skuKeys.has(key)) {
                                const data = this.skuMaps.get(key);
                                data.sku_attributes = [...sku.sku_attributes];
                                newModel.push(data);
                                skuKeys.add(key);
                                skuMaps.set(key, data);
                            } else {
                                newModel.push(sku);
                                skuKeys.add(key);
                                skuMaps.set(key, sku);
                            }
                        });
                        this.skuKeys = skuKeys;
                        this.skuMaps = skuMaps;
                        this.skuModel = newModel;
                    }
                } else {
                    this.skuModel = [];
                    this.spuNames = [];
                    this.skuMaps = new Map();
                    this.skuKeys = new Set();
                }
            },

            // 为SKU生成唯一的KEY - 以属性id_属性值id组成
            genKeyForSku(prop) {
                return prop.sku_attributes.reduce((acc, item) => {
                    acc.push(`${item.id}_${item.value.id}`);
                    return acc;
                }, []).join('_');
            },

            // 提交表单 - 成功返回数据
            submit() {
                const forms = this.$refs.skuForm || [];
                const formsPromise = forms.reduce((acc, form) => {
                    acc.push(form.validate());
                    return acc;
                }, []);

                return Promise.all(formsPromise).then(response => Promise.resolve(this.getData()));
            },

            // 选择图片完成
            handleImageSelected(data) {
                const index = this.uploadRow;
                const props = this.skuModel[index];
                if (index >= 0) {
                    this.onUploadSuccess(index, props, ...data);
                }
                if (index === -1) {
                    this.batchUploadSuccess(...data);
                }
            },

            // 选择图片
            handleImageSelect(index) {
                this.selectPhotoVisible = true;
                this.uploadRow = index;
            },

            // 取消选择
            handleImageCancel() {
                this.uploadRow = '';
            }
        },
    };
</script>

<style module>
    @import 'variable.css';


    .container {
        width: 870px;
        margin: 0 auto 20px auto;
    }

    .tableContent {
        position: relative;
    }

    .tableScroll {
        width: 100%;
        overflow: auto;
    }

    .title {
        line-height: 40px;
        padding-bottom: 10px;
        color: var(--color-text-primary);
        font-size: var(--font-size-base);
    }

    .title:before{
        content: "*";
        color: #ff5757;
        margin-right: 4px;
    }

    .textLeft {
        text-align: left;
    }

    .required {
        margin-right: 4px;
        color: #ff5757;
    }

    .inputPrefix {
        margin-left: 10px;
        line-height: 40px;
    }

    .goodsImageTips {
        line-height: 1.6;
    }

    .goodsImageTips p {
        padding-bottom: 5px;
    }

    .specTable {
        width: 100%;
        text-align: center;
        border-top: 1px solid var(--border-color-lighter);
        border-bottom: 1px solid var(--border-color-lighter);
        border-left: 0;
        border-right: 0;
        border-spacing: 0;
        border-collapse: collapse;
    }

    .specTable:before,
    .specTable:after {
        position: absolute;
        width: 1px;
        top: 0;
        bottom: 0;
        border-left: 1px solid var(--border-color-lighter);
        content: "";
    }

    .specTable:before {
        left: 0;
    }

    .specTable:after {
        right: 0;
    }

    .specTable:before {
        width: 1px;
        position: absolute;
        right: 0;
        top: 0;
        bottom: 0;
        border-left: 1px solid var(--border-color-lighter);
        content: "";
    }

    .specTable tr {
        border-bottom: 1px solid var(--border-color-lighter);
    }

    .specTable thead {
        background-color: #fafafa;
    }

    .specTable thead th {
        color: var(--color-text-primary);
        font-size: var(--font-size-base);
        line-height: 40px;
        font-weight: 400;
        padding: 0 20px;
        white-space: nowrap;
    }

    .specTable thead th [class~="icon-question"] {
        font-size: 24px;
        vertical-align: -3px;
        color: var(--color-text-primary);
        cursor: pointer;
    }

    .specTable tbody td {
        padding: 20px 16px;
        text-align: center;
        white-space: nowrap;
    }

    .specTable tbody td[rowspan] {
        border-left: 1px solid var(--border-color-lighter);
        border-right: 1px solid var(--border-color-lighter);
    }

    .specTable tbody tr:nth-child(even) {
        background-color: #fafafa;
    }

    .specTable tfoot {
        background-color: #fbfbfb;
    }

    .specTable tfoot tr {
        border-bottom: 1px solid rgba(238,238,238,1);
    }

    .specTable tfoot td {
        padding: 14px 0;
    }

    .specTable [class^="el-form-item"]{
        margin-bottom: 0;
    }

    .upload {
        position: relative;
        width: 80px;
        height: 80px;
        border: 1px dashed #d9d9d9;
        border-radius: 4px;
        cursor: pointer;
        overflow: hidden;
    }

    .upload [class^="icon-close"] {
        display: inline-block;
        font-size: 28px;
        line-height: 80px;
        text-align: center;
        color: rgba(153,153,153,1);
        transform: rotate(45deg);
    }

    .uploadPreview {
        position: relative;
        width: 80px;
        height: 80px;
        border-radius: 4px;
        overflow: hidden;
    }

    .uploadPreview img {
        width: inherit;
        height: inherit;
    }

    .uploadPreview:hover [class~="delete"] {
        display: block;
    }

    .uploadPreview [class~="delete"] {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.7);
    }

    .uploadPreview [class~="icon-close"] {
        color: #fff;
        font-size: 18px;
        line-height: 80px;
        text-align: center;
        cursor: pointer;
    }

    .stockTotal {
        display: flex;
        align-items: center;
        justify-items: center;
        margin-top: 20px;
    }

    .stockTotal .name {
        color: var(--color-text-primary);
        font-size: var(--font-size-base);
    }

    .stockTotal .content {
        width: 300px;
        margin-left: 26px;
    }

     .goodsImageTips {
        line-height: 1.6;
    }

    .goodsImageTips p {
        padding-bottom: 5px;
    }
</style>
