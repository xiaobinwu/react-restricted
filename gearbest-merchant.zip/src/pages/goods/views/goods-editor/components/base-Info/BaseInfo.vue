<template>
    <div :class="$style.container">
        <el-form ref="form" :model="model" :rules="rules" label-position="right" label-width="180px">
            <el-form-item label="语言：" prop="lang">
                <el-select
                    disabled
                    value="en"
                    style="width: 240px">
                    <el-option label="英语" value="en"></el-option>
                </el-select>
                <span :class="$style.tip">
                    当前仅支持维护英文资料
                </span>
            </el-form-item>
            <el-form-item :label="$t('goods.add.goodsTitle')" prop="title">
                <el-input
                    :disabled="isView"
                    :placeholder="$t('goods.add.goodsTitlePlace')"
                    v-model.trim="model.title"
                    max="100"
                    style="width: 700px">
                </el-input>
                <el-popover
                    placement="bottom-end"
                    width="400"
                    trigger="click">
                    <div :class="$style.goodsTitleTips">
                        <template>
                            <p>{{ $t('goods.add.goodsTitleTip1') }}</p>
                            <p>{{ $t('goods.add.goodsTitleTip2') }}</p>
                            <p>{{ $t('goods.add.goodsTitleTip3') }}</p>
                            <p>{{ $t('goods.add.goodsTitleTip4') }}</p>
                        </template>
                    </div>
                    <i slot="reference" class="icon-question"></i>
                </el-popover>
            </el-form-item>
            <el-form-item :label="$t('goods.add.brand')" prop="brand_code">
                <el-select
                    :disabled="isView"
                    :placeholder="$t('goods.add.brandPlace')"
                    v-model="model.brand_code"
                    style="width: 240px">
                    <div :class="$style.brandItem">
                        <el-option
                            v-for="(brand, brandIndex) in brands"
                            :key="brandIndex"
                            :label="brand.name"
                            :value="brand.brand_code">
                        </el-option>
                    </div>
                </el-select>
                <span :class="$style.tip">
                    {{ $t('goods.add.brandTip') }}
                </span>
            </el-form-item>
            <el-form-item :label="$t('goods.add.weight')" prop="package_weight">
                <el-input
                    :disabled="isView"
                    :placeholder="$t('goods.add.weightPlace')"
                    v-model="model.package_weight"
                    style="width: 240px">
                </el-input><span :class="$style.unit">kg</span>
            </el-form-item>
            <el-form-item :label="$t('goods.add.volume')">
                <el-col :span="6">
                    <el-form-item
                        :rules="rules.package_volume"
                        :label="$t('goods.add.volumeLength')"
                        prop="package_length"
                        label-width="60px">
                        <el-input
                            :disabled="isView"
                            v-model="model.package_length"
                            style="width: 100px">
                        </el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item
                        :rules="rules.package_volume"
                        :label="$t('goods.add.volumeWidth')"
                        prop="package_width"
                        label-width="60px">
                        <el-input
                            :disabled="isView"
                            v-model="model.package_width"
                            style="width: 100px">
                        </el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="7">
                    <el-form-item
                        :rules="rules.package_volume"
                        :label="$t('goods.add.volumeHeight')"
                        prop="package_height"
                        label-width="60px">
                        <el-input
                            :disabled="isView"
                            v-model="model.package_height"
                            style="width: 100px">
                        </el-input><span :class="$style.unit">cm</span>
                    </el-form-item>
                </el-col>
                <!--<el-col :span="1">cm</el-col>-->
            </el-form-item>
            <el-form-item :label="$t('goods.add.deliveryTime')" required>
                <el-col :span="3">
                    <el-form-item label-width="0" prop="delivery_day_min">
                        <el-input :disabled="isView" v-model="model.delivery_day_min"/>
                    </el-form-item>
                </el-col>
                <el-col :span="1" :class="$style.line">-</el-col>
                <el-col :span="3">
                    <el-form-item label-width="0" prop="delivery_day_max">
                        <el-input :disabled="isView" v-model="model.delivery_day_max"/>
                    </el-form-item>
                </el-col>
                <el-col :span="1" :class="$style.unit">{{ $t('goods.add.unitDay') }}</el-col>
            </el-form-item>
            <!-- 暂时隐藏2.0再显示 -->
            <!-- <el-form-item :label="$t('goods.add.afterSubmitGoods')：" prop="default_sold_status">
                <el-radio-group
                    v-model.number="model.default_sold_status"
                    :disabled="isView || soldStatusDisabled">
                    <el-radio :label="1">{{ $t('goods.add.upper') }}</el-radio>
                    <el-radio :label="2">{{ $t('goods.add.lower') }}</el-radio>
                </el-radio-group>
            </el-form-item> -->
        </el-form>
    </div>
</template>

<script>
    import { GOODS_EDITOR_BASE_INFO } from '@goods/assets/js/constant/local';
    import { brandList } from '@goods/services/goods';
    import { deepCopy } from '@/assets/js/utils/types';

    import { getRules } from './validator';

    export default {
        name: 'BaseInfo',
        inject: ['goodsEditor'],

        data() {
            return {
                model: {
                    lang: '',
                    title: '',
                    brand_code: '',
                    package_weight: '',
                    package_length: '',
                    package_width: '',
                    package_height: '',
                    delivery_day_min: 1,
                    delivery_day_max: 3,
                    default_sold_status: 2
                },
                rules: getRules(this),
                brands: [],
                soldStatusDisabled: true
            };
        },

        computed: {
            // 编辑商品时
            goodsData() {
                return deepCopy(this.goodsEditor.goodsData);
            },
            deliverMode() {
                return this.goodsEditor.deliverMode;
            },
            isView() {
                return this.goodsEditor.isView;
            }
        },

        watch: {
            'model.package_weight': function callback(newVal, oldVal) {
                if (newVal && Number.isNaN(Number(newVal))) {
                    this.$nextTick(() => {
                        this.$set(this.model, 'package_weight', oldVal);
                    });
                }
            },
            'model.package_length': function callback(newVal, oldVal) {
                if (newVal && Number.isNaN(Number(newVal))) {
                    this.$nextTick(() => {
                        this.$set(this.model, 'package_length', oldVal);
                    });
                }
            },
            'model.package_width': function callback(newVal, oldVal) {
                if (newVal && Number.isNaN(Number(newVal))) {
                    this.$nextTick(() => {
                        this.$set(this.model, 'package_width', oldVal);
                    });
                }
            },
            'model.package_height': function callback(newVal, oldVal) {
                if (newVal && Number.isNaN(Number(newVal))) {
                    this.$nextTick(() => {
                        this.$set(this.model, 'package_height', oldVal);
                    });
                }
            },
            'model.delivery_day_min': function callback(newVal, oldVal) {
                if (newVal && !/^[0-9]+$/.test(newVal)) {
                    this.$nextTick(() => {
                        this.$set(this.model, 'delivery_day_min', oldVal);
                    });
                }
            },
            'model.delivery_day_max': function callback(newVal, oldVal) {
                if (newVal && !/^[0-9]+$/.test(newVal)) {
                    this.$nextTick(() => {
                        this.$set(this.model, 'delivery_day_max', oldVal);
                    });
                }
            },
            goodsData: {
                deep: true,
                immediate: true,
                handler(val) {
                    if (val) {
                        this.model = val.base_infos;
                    }
                }
            },
            deliverMode: {
                deep: true,
                immediate: true,
                handler(val) {
                    if (!val) return;

                    // 平台控制该店铺只开放FBG模式：
                    // 审核通过后商品状态开关-只选中下架状态，且不可修改
                    if (val.isOpenFbgMode && !val.isOpenDirectMode) {
                        this.soldStatusDisabled = true;
                        this.model.default_sold_status = 2;
                    }

                    // 平台控制该店铺开放直发以及FBG模式时，不做限制，可自由配置
                    if (val.isOpenFbgMode && val.isOpenDirectMode) {
                        this.soldStatusDisabled = false;
                    }
                    // 平台控制该店铺只开放直发模式时：
                    // 审核通过后商品状态开关，不做限制，可自由配置
                    if (!val.isOpenFbgMode && val.isOpenDirectMode) {
                        this.soldStatusDisabled = false;
                    }
                    // 都不支持的时
                    if (!val.isOpenFbgMode && !val.isOpenDirectMode) {
                        this.soldStatusDisabled = true;
                        this.model.default_sold_status = 2;
                    }
                }
            }
        },

        created() {
            this.getCacheData();
            this.getBrandList();
        },

        methods: {
            // 获取品牌列表
            async getBrandList() {
                const { data } = await brandList.http();
                data.push({
                    name: this.$t('goods.add.centerBrand'),
                    brand_code: '0'
                });
                this.brands = data;
            },

            // 提交数据
            submit() {
                return new Promise((resolve, reject) => {
                    this.$refs.form.validate((valid) => {
                        if (valid) {
                            resolve(this.getData());
                        } else {
                            reject(new Error('submit fail'));
                        }
                    });
                });
            },

            // 保存草稿校验
            submitForSave() {
                return this.submit();
            },

            // 获取数据
            getData() {
                return {
                    base_infos: {
                        ...deepCopy(this.model)
                    }
                };
            },

            // 获取切换类目缓存的信息
            getCacheData() {
                const cache = window.sessionStorage.getItem(GOODS_EDITOR_BASE_INFO);
                if (cache) {
                    try {
                        const formatCache = JSON.parse(cache);
                        if (formatCache.base_infos) {
                            this.model = formatCache.base_infos;
                            // 用完删除
                            this.delCacheData();
                        }
                    } catch (e) {
                        throw e;
                    }
                }
            },

            // 删除缓存信息
            delCacheData() {
                sessionStorage.removeItem(GOODS_EDITOR_BASE_INFO);
            }
        },
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        padding: 30px 0;
    }

    .goodsTitleTips p {
        padding-bottom: 5px;
        word-break: break-all;
    }

    .goodsTitleTips > p:nth-child(4) {
        padding-bottom: 0;
    }

    .brandItem {
        max-width: 300px;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
    }

    .brandItem [class^="el-select-dropdown__item"] {
        text-overflow: unset;
        white-space: normal;
        overflow: unset;
        word-wrap:break-word;
        height: auto;
        padding: 10px 20px;
        line-height: inherit;
    }

    .tip {
        display: inline-block;
        margin-left: 10px;
        color: var(--color-text-regular);
    }

    .line {
        display: inline-block;
        padding: 0 5px;
        text-align: center;
    }

    .unit {
        padding-left: 10px;
    }

    .container [class^="icon-question"] {
        font-size: 24px;
        cursor: pointer;
    }
</style>
