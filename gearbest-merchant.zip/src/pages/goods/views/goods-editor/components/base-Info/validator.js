// 商品基本信息表单校验
export const getRules = (context) => {
    const self = context;

    return {
        lang: [],
        title: [
            {
                required: true,
                trigger: 'blur',
                message: self.$t('goods.add.reuiredTitle'),
            },
            {
                type: 'string',
                pattern: /^(\s|\w|_|-)*$/,
                trigger: 'blur',
                message: self.$t('base.validate.name'),
            },
            {
                message: self.$t('base.validate.length', [100]),
                max: 100,
                trigger: 'blur'
            }
        ],
        brand_code: {
            required: true,
            message: self.$t('goods.add.requireBrand'),
            trigger: 'change'
        },
        package_weight: {
            required: true,
            validator(rules, value, callback) {
                if (value === '') {
                    callback(new Error(self.$t('goods.add.requireWeight')));
                }
                value = Number.parseFloat(value, 10);
                if (typeof value !== 'number') {
                    callback(new Error(self.$t('base.validate.number')));
                }
                if (value < 0 || value > 10000) {
                    callback(new Error(self.$t('base.validate.range', [0, 10000])));
                }
                if (!/^-?\d+(\.\d{0,4})?$/.test(value)) {
                    callback(new Error(self.$t('base.validate.decimalPoint', [4])));
                }
                callback();
            },
            trigger: 'blur',
        },
        package_volume: {
            required: true,
            validator(rules, value, callback) {
                if (value === '') {
                    callback(new Error(self.$t('goods.add.requiredVolume')));
                }
                value = Number.parseFloat(value, 10);
                if (typeof value !== 'number') {
                    callback(new Error(self.$t('base.validate.number')));
                }
                if (value < 0 || value > 10000) {
                    callback(new Error(self.$t('base.validate.range', [0, 10000])));
                }
                if (!/^\d+(\.\d{0,2})?$/.test(value)) {
                    callback(new Error(self.$t('base.validate.decimalPoint', [2])));
                }
                callback();
            }
        },
        delivery_day_min: {
            required: true,
            validator(rules, value, callback) {
                if (value === '') {
                    callback(new Error(self.$t('goods.add.requireDeliveryTime')));
                }
                value = Number.parseInt(value, 10);
                if (!(Number.isInteger(value) && value > 0)) {
                    callback(new Error(self.$t('base.validate.positiveInteger')));
                }
                if (!(value >= 1 && value <= 29)) {
                    callback(new Error(self.$t('base.validate.range', [1, 30])));
                }
                if (self.model.delivery_day_max) {
                    self.$refs.form.validateField('delivery_day_max');
                }
                callback();
            },
            trigger: 'blur',
        },
        delivery_day_max: {
            require: true,
            validator(rules, value, callback) {
                if (value === '') {
                    callback(new Error(self.$t('goods.add.requireDeliveryTime')));
                }
                value = Number.parseInt(value, 10);
                if (!(Number.isInteger(value) && value > 0)) {
                    callback(new Error(self.$t('base.validate.positiveInteger')));
                }
                if (!(value >= 1 && value <= 30)) {
                    callback(new Error(self.$t('base.validate.range', [1, 30])));
                }
                if (value <= self.model.delivery_day_min) {
                    callback(new Error(self.$t('base.validate.thanInitVal')));
                }
                callback();
            },
            trigger: 'blur'
        },
        default_sold_status: {
            required: true,
            type: 'number',
            message: self.$t('goods.add.requireAfterSubmitGoods'),
            trigger: 'change'
        }
    };
};
