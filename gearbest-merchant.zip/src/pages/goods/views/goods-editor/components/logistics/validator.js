// 运费模板表单校验规则
export const logisticsForm = {
    logistics_template_id: {
        required: true,
        type: 'number',
        message: window.$$lang.translate('goods.add.selectShippingTemp'),
        trigger: 'change'
    }
};
