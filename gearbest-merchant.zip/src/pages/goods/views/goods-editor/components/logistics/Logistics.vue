<template>
    <div :class="$style.container">
        <el-form ref="form" :model="model" :rules="rules" label-width="140px" label-position="right">
            <el-form-item :label="$t('goods.add.shippingTemp')" prop="logistics_template_id">
                <el-select
                    :disabled="isView || !logisticsSelectble"
                    :placeholder="$t('goods.add.selectShippingTemp')"
                    v-model="model.logistics_template_id"
                    :loading="loading">
                    <el-option
                        v-for="item in options"
                        :label="item.name"
                        :value="item.id"
                        :key="item.id">
                    </el-option>
                </el-select>
                <div :class="$style.add">
                    <el-button
                        :disabled="isView || !logisticsSelectble"
                        type="primary"
                        @click="handleAddLogistics">
                        {{ $t('goods.add.createShippingTemp') }}
                    </el-button>
                </div>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    import emitter from '@/assets/js/mixins/emitter';
    import { GOODS_EDITOR_LOGISTICS } from '@goods/assets/js/constant/local';
    import { shippingTemplate } from '@goods/services/logisitics';
    import { deepCopy } from '@/assets/js/utils/types';
    import { logisticsForm } from './validator';


    export default {
        name: 'Logistics',
        inject: ['goodsEditor'],
        mixins: [emitter],

        data() {
            return {
                options: [],
                loading: true,
                model: {
                    logistics_template_id: ''
                },
                rules: logisticsForm,
                logisticsSelectble: true
            };
        },

        computed: {
            // 商品数据 - 编辑时
            goodsData() {
                return this.goodsEditor.goodsData;
            },
            deliverMode() {
                return this.goodsEditor.deliverMode;
            },
            isView() {
                return this.goodsEditor.isView;
            },
            isEditor() {
                return this.goodsEditor.isEditor;
            },
            isSaved() {
                return +this.$route.query.review_type === 1;
            }
        },

        watch: {
            goodsData: {
                deep: true,
                immediate: true,
                handler(val) {
                    if (!val) return;
                    this.model.logistics_template_id = val.logistics_template_id;
                }
            },
            deliverMode: {
                deep: true,
                immediate: true,
                handler(val) {
                    if (!val) return;

                    // 新增默认选择直发运费模板
                    let type = 2;

                    // 编辑的时候重新校验物流模板
                    if (this.isEditor && !this.isSaved) {
                        type = '';
                        this.logisticsSelectble = false;
                    }
                    this.getShippingTemplate({ type });
                }
            }
        },

        created() {
            this.getCacheData();
        },

        methods: {
            // 获取物流运费模板
            async getShippingTemplate(params) {
                const { data, status } = await shippingTemplate.http({ params });
                if (status === 0) {
                    this.options = data;
                    this.loading = false;
                }
            },

            // 新增物流模板
            handleAddLogistics() {
                this.$confirm(this.$t('goods.add.addShippingTempTips'), this.$t('goods.add.createShippingTemp'), {
                    cancelButtonText: this.$t('base.button.notSave'),
                    confirmButtonText: this.$t('base.button.save'),
                    distinguishCancelAndClose: true,
                    callback: (action) => {
                        if (action === 'confirm') {
                            this.dispatch('GoodsEditor', 'on-logistics-add', this.goLogistics);
                        } else if (action === 'cancel') {
                            this.goLogistics();
                        }
                    }
                });
            },

            // 获取物流类型
            getLogisticsType(val) {
                let type = '';

                // 店铺只开放FBG模式：
                if (val.isOpenFbgMode && !val.isOpenDirectMode) {
                    type = 3;
                }

                // 店铺开放直发以及FBG模式时
                if (val.isOpenFbgMode && val.isOpenDirectMode) {
                    type = '';
                }

                // 店铺只开放直发模式时：
                if (!val.isOpenFbgMode && val.isOpenDirectMode) {
                    type = 2;
                }

                return type;
            },

            // 跳转运费模板新增
            goLogistics(href) {
                href = encodeURIComponent(href);
                this.$router.gbReplace(`/logistics/shippingOperate?ref=${href}`);
            },

            // 验证数据
            submit() {
                return new Promise((resolve, reject) => {
                    this.$refs.form.validate((valid) => {
                        if (valid) {
                            resolve(this.getData());
                        } else {
                            reject();
                        }
                    });
                });
            },

            // 获取数据
            getData() {
                return deepCopy(this.model);
            },

            // 获取切换类目缓存的信息
            getCacheData() {
                const cache = window.sessionStorage.getItem(GOODS_EDITOR_LOGISTICS);
                if (cache) {
                    try {
                        const formatCache = JSON.parse(cache);
                        if (formatCache.logistics_template_id) {
                            this.model = formatCache;
                            this.delCacheData();
                        }
                    } catch (e) {
                        throw e;
                    }
                }
            },

            // 删除缓存信息
            delCacheData() {
                sessionStorage.removeItem(GOODS_EDITOR_LOGISTICS);
            }
        },
    };
</script>

<style module>
    .container {
        padding-top: 30px;
    }

    .add {
        display: inline-block;
        margin-left: 20px;
    }
</style>
