<template>
    <div :class="$style.container">
        <div :class="$style.content">
            <div :class="$style.header">
                <i :class="$style.tipsIcon"></i>
                <p :class="$style.tips">
                    {{ $t('goods.add.submitSuccessTips') }}<br>
                    {{ $t('goods.add.saveSuccessSPU') }}{{ params.product_id }}
                </p>
            </div>
            <div :class="$style.operation">
                <el-button type="primary" @click="previewGoods">{{ $t('goods.add.previewGoods') }}</el-button>
                <el-button @click="goGoodsAdd">{{ $t('goods.add.addGoodsAgain') }}</el-button>
                <el-button @click="goGoodsList">{{ $t('goods.add.backGoodsList') }}</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'SubmitSuccess',
        inject: ['reload', 'goodsEditor'],
        computed: {
            params() {
                return this.goodsEditor.params;
            },
            isSaved() {
                return +this.$route.query.review_type === 1;
            }
        },
        methods: {
            previewGoods() {
                if (this.isSaved) {
                    this.$router.replace({
                        name: 'GoodsPreview',
                        params: {
                            id: this.params.variation_ids,
                            type: 2
                        }
                    });
                } else {
                    this.$router.push({
                        name: 'GoodsPreview',
                        params: {
                            id: this.params.variation_ids,
                            type: 2
                        }
                    });
                }
            },
            goGoodsAdd() {
                this.$router.push({
                    name: 'goodsAdd'
                }, this.reload());
            },
            goGoodsList() {
                this.$router.push({
                    name: 'goodsList',
                    query: {
                        type: 2
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        height: 845px;
        display: flex;
        justify-content: center;
    }

    .content {
        padding-top: 100px;
    }

    .header {
        display: flex;
        align-items: center;
    }

    .tipsIcon {
        display: inline-block;
        width: 40px;
        height: 40px;
        background: resolve('img/icon-goods-review.png') no-repeat;
    }

    .tips {
        padding-left: 20px;
        font-size: var(--font-size-base);
        color: var(--color-text-primary);
        line-height: 20px;
    }

    .operation {
        padding-top: 80px;
        text-align: center;
    }

    .operation button:nth-child(2) {
        margin: 0 30px;
    }

</style>
