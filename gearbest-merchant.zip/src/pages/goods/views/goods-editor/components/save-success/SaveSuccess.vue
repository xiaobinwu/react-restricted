<template>
    <div :class="$style.container">
        <div :class="$style.content">
            <div :class="$style.header">
                <i :class="$style.tipsIcon"></i>
                <p :class="$style.tips">
                    {{ $t('goods.add.saveSuccessTips') }}<br>
                    <!--{{ $t('goods.add.saveSuccessSPU') }}{{ params.product_id }}-->
                </p>
            </div>
            <div :class="$style.operation">
                <!-- <el-button type="primary" @click="previewGoods">{{ $t('goods.add.previewGoods') }}</el-button> -->
                <el-button @click="goGoodsEditor">{{ $t('goods.add.editGoodsAgain') }}</el-button>
                <el-button @click="goGoodsAdd">{{ $t('goods.add.addGoodsAgain') }}</el-button>
                <el-button @click="goGoodsList">{{ $t('goods.add.backGoodsList') }}</el-button>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'SaveSuccess',
        inject: ['reload', 'goodsEditor'],
        computed: {
            params() {
                return this.goodsEditor.params;
            }
        },
        methods: {
            previewGoods() {
                this.$router.push({
                    name: 'GoodsPreview',
                    params: {
                        id: this.params.variation_ids,
                        type: 1
                    }
                });
            },
            goGoodsAdd() {
                this.$router.push({
                    name: 'goodsAdd',
                }, this.reload());
            },
            goGoodsEditor() {
                this.$router.push({
                    name: 'goodsEditor',
                    query: {
                        product_id: this.params.product_id,
                        review_type: 1
                    }
                }, this.reload());
            },
            goGoodsList() {
                this.$router.push({
                    name: 'goodsList',
                    query: {
                        type: 3
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        height: 845px;
        display: flex;
        justify-content: center;
    }
    .content {
        padding-top: 100px;
    }
    .header {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .tipsIcon {
        display: inline-block;
        width: 40px;
        height: 40px;
        background: resolve('img/icon-goods-save.png') no-repeat;
    }

    .tips {
        padding-left: 20px;
        font-size: var(--font-size-base);
        color: var(--color-text-primary);
        line-height: 20px;
    }

    .operation {
        padding-top: 80px;
        text-align: center;
    }

    .operation button {
        margin-right: 30px;
    }

    .operation button:last-child {
        margin-right: 0;
    }

</style>
