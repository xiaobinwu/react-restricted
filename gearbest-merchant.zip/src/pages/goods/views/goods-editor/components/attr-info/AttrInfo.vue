<template>
    <div :class="$style.container">
        <el-form
            v-if="model"
            ref="form"
            :class="$style.descrtion"
            :model="model"
            :rules="rules"
            label-position="right"
            label-width="180px">
            <el-col v-for="description in descAttrs" :span="12" :key="description.category_id">
                <el-form-item :label="description.attribute_name" :required="description.required === 1">
                    <el-col :span="!!description.unit_ids.length ? 12 : 17">
                        <!--单选-->
                        <el-form-item
                            v-if="description.attribute_show_type_value === 1"
                            :prop="description.modelKey"
                            style="margin-bottom: 22px" >
                            <el-select
                                :disabled="isView"
                                v-model="model[description.modelKey]">
                                <el-option
                                    v-for="item in description.attr_values"
                                    :key="item.attribute_value_id"
                                    :label="item.attribute_value_name"
                                    :value="item.attribute_value_id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <!--多选-->
                        <el-form-item
                            v-if="description.attribute_show_type_value === 2"
                            :prop="description.modelKey"
                            style="margin-bottom: 22px" >
                            <el-select
                                :disabled="isView"
                                v-model="model[description.modelKey]"
                                multiple>
                                <el-option
                                    v-for="item in description.attr_values"
                                    :key="item.attribute_value_id"
                                    :label="item.attribute_value_name"
                                    :value="item.attribute_value_id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <!--输入框-->
                        <el-form-item
                            v-if="description.attribute_show_type_value === 3"
                            :prop="description.modelKey"
                            style="margin-bottom: 22px" >
                            <el-input
                                :disabled="isView"
                                :value="model[description.modelKey]"
                                @input="handleValue(model, description.modelKey, $event, description)">
                            </el-input>
                        </el-form-item>
                        <!--区间-->
                        <el-form-item
                            v-if="description.attribute_show_type_value === 4"
                            style="margin-bottom: 22px" >
                            <el-col :span="11">
                                <el-form-item :prop="description.modelStartKey">
                                    <el-input
                                        :disabled="isView"
                                        :value="model[description.modelStartKey]"
                                        @input="handleValue(model, description.modelStartKey, $event, description)">
                                    </el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="2">
                                <span :class="$style.line">-</span>
                            </el-col>
                            <el-col :span="11">
                                <el-form-item :prop="description.modelEndKey">
                                    <el-input
                                        :disabled="isView"
                                        :value="model[description.modelEndKey]"
                                        @input="handleValue(model, description.modelEndKey, $event, description)">
                                    </el-input>
                                </el-form-item>
                            </el-col>
                        </el-form-item>
                        <p v-if="description.notices" :class="$style.notices">
                            {{ description.notices.is_rename === 1 ? $t('goods.add.attrNameEdited') : '' }}
                            {{ description.notices.is_reset === 1 ? $t('goods.add.attrNameReset') : '' }}
                            {{ description.notices.is_disable === 1 ? $t('goods.add.attrNameDel') : '' }}
                        </p>
                    </el-col>
                    <el-col v-if="!!description.unit_ids.length" :span="7">
                        <!--单位-->
                        <el-form-item
                            :prop="description.modelUnitKey"
                            style="margin-left: 5px">
                            <el-select
                                :disabled="isView"
                                :placeholder="$t('goods.add.unit')"
                                v-model="model[description.modelUnitKey]">
                                <el-option
                                    v-for="item in description.units"
                                    :key="item.unit_id"
                                    :label="item.unit_name"
                                    :value="item.unit_id">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-form-item>
            </el-col>
        </el-form>
    </div>
</template>

<script>
    import { LINKS } from '@/assets/js/constant/reg';
    import { GB_HOST } from '@/assets/js/constant/other';
    import { deepCopy, map } from '@/assets/js/utils/types';

    export default {
        name: 'AttrInfo',
        inject: ['goodsEditor'],

        data() {
            return {
                model: null,
                rules: {}
            };
        },

        computed: {
            descAttrs() {
                return deepCopy(this.goodsEditor.descAttrs);
            },
            descData() {
                return this.goodsEditor.descData || [];
            },
            isView() {
                return this.goodsEditor.isView;
            }
        },

        watch: {
            descAttrs: {
                deep: true,
                handler(val) {
                    if (!val) return;
                    const { model, rules } = this.genModelAndRules(this.extendDescAttrsForKey(val));
                    this.model = model;
                    this.rules = rules;

                    // 编辑
                    if (this.goodsEditor.isEditor) {
                        this.model = this.getAttrData(
                            this.extendDescAttrsForNotices(val, this.descData),
                            this.descData
                        );
                    }
                }
            }
        },

        methods: {
            // 扩展描述属性对象 - 添加唯一key
            extendDescAttrsForKey(data) {
                return data && data.map((item) => {
                    const keys = this.generateKey(item);
                    item = Object.assign(item, keys);
                    return item;
                });
            },

            // 扩展描述属性对象 - 添加删除信息
            extendDescAttrsForNotices(val, data) {
                const getNotices = () => ({
                    is_disable: 0,
                    is_rename: 0,
                    is_reset: 0
                });

                const attrsMap = map(data, 'id');
                return val && val.map((item) => {
                    if (attrsMap[item.attribute_id]) {
                        item.notices = attrsMap[item.attribute_id].notices;
                    } else {
                        item.notices = getNotices();
                    }
                    return item;
                });
            },

            // 生成表单model和rules
            genModelAndRules(data) {
                const model = {};
                const rules = {};

                const types = {
                    1: 'string',
                    2: 'number'
                };

                const message = {
                    required: this.$t('base.validate.required'),
                    string: this.$t('base.validate.string'),
                    number: this.$t('base.validate.number')
                };

                const trigger = {
                    1: 'visible-change',
                    2: 'visible-change',
                    3: 'blur',
                    4: 'blur'
                };

                const getTypeof = val => typeof val;

                for (const props of data) {
                    const keys = this.generateKey(props);
                    const type = props.attribute_show_type_value;

                    Object.keys(keys).forEach((item) => {
                        const key = keys[item];
                        // 多选控件初始值为数组
                        model[key] = type === 2 ? [] : '';
                        rules[key] = [];
                        rules[key].push({
                            required: props.required === 1,
                            message: message.required,
                            trigger: trigger[type]
                        });
                        rules[key].push({
                            required: props.required === 1,
                            showType: props.attribute_show_type_value,
                            type: types[props.input_type],
                            validator(rule, values, callback) {
                                const showType = rule.showType;
                                // 不需要校验的属性跳过
                                // 单选和多选只校验是否选择了值
                                // 输入框和区间输入框校验输入类型
                                if (showType === 1) {
                                    if (!values && rules.required) {
                                        callback(new Error(message.required));
                                    }
                                } else if (showType === 2) {
                                    if (!values.length && rule.required) {
                                        callback(new Error(message.required));
                                    }
                                } else if (showType === 3) {
                                    if (getTypeof(values) !== rule.type && rule.required) {
                                        callback(new Error(message[rule.type]));
                                    }
                                    const matched = values ? values.toString().match(LINKS) : [];
                                    if (rule.type === 'string'
                                        && values
                                        && matched
                                        && !matched.every(url => url.includes(GB_HOST))
                                        && !rule.required) {
                                            callback(new Error(this.$t('goods.add.validateDelOtherUrl')));
                                        }
                                } else if (showType === 4) {
                                    values.forEach((value) => {
                                        if (rule.required && getTypeof(value) === rule.type) {
                                            callback(new Error(message[rule.type]));
                                        }
                                        const matched = values ? values.toString().match(LINKS) : [];
                                        if (!rule.required
                                            && rule.type === 'string'
                                            && value
                                            && matched
                                            && !matched.every(url => url.includes(GB_HOST))) {
                                                callback(new Error(this.$t('goods.add.validateDelOtherUrl')));
                                            }
                                    });
                                }
                                callback();
                            },
                            trigger: trigger[type]
                        });
                    });
                }
                return { model, rules };
            },

            // 根据表单元素属性生成 model key 用于表单双向绑定
            generateKey(props) {
                const key = {};
                const id = props.attribute_id;
                const unitIds = props.unit_ids;
                const isRange = props.attribute_show_type_value === 4;
                if (!isRange) {
                    key.modelKey = `${id}_value`;
                }
                if (unitIds.length) {
                    key.modelUnitKey = `${id}_unit_value`;
                }
                if (isRange) {
                    key.modelStartKey = `${id}_start_value`;
                    key.modelEndKey = `${id}_end_value`;
                }
                return key;
            },

            // 动态处理 <el-input/> v-model 修饰符
            handleValue(model, key, value, des) {
                let val = '';
                if (des.input_type === 1) { // 字符串
                    val = value;
                } else { // 数字
                    val = Number(value) === parseFloat(value) ? Number(value) : value;
                }
                this.$set(model, key, val);
            },

            // 提交数据
            submit() {
                return new Promise((resolve, reject) => {
                    this.$refs.form.validate((valid) => {
                        if (valid) {
                            resolve(this.getData());
                        } else {
                            reject(new Error('submit fail'));
                        }
                    });
                });
            },

            // 获取属性值模板 - 用于数据提交
            getAttrValueTemp() {
                return {
                    id: '',
                    name: '',
                    alias: '',
                    unit_id: '',
                    unit_name: ''
                };
            },

            // 获取属性模板 - 用于数据提交
            getAttrTemp() {
                return {
                    id: '',
                    name: '',
                    values: []
                };
            },

            // 设置属性数据 - 编辑商品时
            getAttrData(attrs, data) {
                const attrsMap = map(attrs, 'attribute_id');
                const model = {};

                for (const attr of data) {
                    const item = attrsMap[attr.id];
                    const type = item.attribute_show_type_value;
                    const values = attr.values;

                    // 设置单位值
                    if (item.units.length) {
                        model[item.modelUnitKey] = values[0].unit_id;
                    }

                    // 为不同的表单设置不同的属性值
                    if (type === 1) {
                        model[item.modelKey] = values[0].id || '';
                    }
                    // 多选
                    if (type === 2) {
                        model[item.modelKey] = values.reduce((acc, value) => {
                            acc.push(value.id || '');
                            return acc;
                        }, []);
                    }
                    // 输入框
                    if (type === 3) {
                        model[item.modelKey] = values[0].name;
                    }
                    // 范围
                    if (type === 4) {
                        model[item.modelStartKey] = values[0].name;
                        model[item.modelEndKey] = values[1].name;
                    }
                }

                return model;
            },

            // 获取数据
            getData() {
                const data = this.model;
                const res = this.descAttrs.reduce((acc, item) => {
                    const attr = this.getAttrTemp();
                    const type = item.attribute_show_type_value;
                    const optionsMap = map(item.attr_values, 'attribute_value_id');
                    const unitsMap = map(item.units, 'unit_id');

                    // 属性id 属性名字
                    attr.id = item.attribute_id;
                    attr.name = item.attribute_name;

                    // 单位
                    const unitId = data[item.modelUnitKey];
                    const unitName = unitId ? unitsMap[unitId].unit_name : '';

                    // 属性值

                    // 单选
                    if (type === 1 && data[item.modelKey]) {
                        const value = this.getAttrValueTemp();
                        const id = data[item.modelKey];
                        value.id = id || 0;
                        value.name = optionsMap[id] ? optionsMap[id].attribute_value_name : '';
                        value.unit_id = unitId || '';
                        value.unit_name = unitName || '';
                        attr.values = [value];

                        acc.push(attr);
                    }

                    // 多选框
                    if (type === 2 && data[item.modelKey].length) {
                        const values = [];
                        for (const id of data[item.modelKey]) {
                            const temp = this.getAttrValueTemp();
                            temp.id = id || 0;
                            temp.name = optionsMap[id] ? optionsMap[id].attribute_value_name : '';
                            temp.unit_id = unitId || '';
                            temp.unit_name = unitName || '';

                            values.push(temp);
                        }

                        attr.values = [...values];

                        acc.push(attr);
                    }

                    // 输入框
                    if (type === 3 && data[item.modelKey]) {
                        const value = this.getAttrValueTemp();
                        value.id = 0;
                        value.name = data[item.modelKey].toString();
                        value.unit_id = unitId || '';
                        value.unit_name = unitName || '';

                        attr.values = [value];

                        acc.push(attr);
                    }

                    // 区间
                    if (type === 4 && data[item.modelStartKey] && data[item.modelEndKey]) {
                        const startValue = this.getAttrValueTemp();
                        const endValue = this.getAttrValueTemp();
                        startValue.id = 0;
                        startValue.name = data[item.modelStartKey].toString();
                        startValue.unit_id = unitId || '';
                        startValue.unit_name = unitName || '';
                        endValue.id = 0;
                        endValue.name = data[item.modelEndKey].toString();
                        endValue.unit_id = unitId || '';
                        endValue.unit_name = unitName || '';
                        attr.values = [startValue, endValue];

                        acc.push(attr);
                    }

                    return acc;
                }, []);

                return {
                    attr_infos: res
                };
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        background-color: #fff;
        padding: 30px 40px 0 30px;
        @mixin clearfix;
    }

    .container [class^="el-form-item"] {
        margin-bottom: 0;
    }

    .line {
        text-align: center;
    }

    .notices {
        padding-bottom: 20px;
        line-height: 1;
        color: var(--color-error);
    }
</style>
