<template>
    <div class="container">
        <div :class="$style.category">
            <span :class="$style.label">{{ $t('goods.add.publicCategory') }}</span>
            <ul :class="$style.categoryContent">
                <li v-for="(category, index) in categoryPath" :key="index">
                    {{ category }}
                    <i v-if="index !== categoryPath.length - 1" class="icon-arrow-right"></i>
                </li>
                <el-button :disabled="isEditor" type="primary" @click="handleSwitchCategory">{{ $t('goods.add.switchCategory') }}</el-button>
            </ul>
        </div>
        <div :class="$style.category">
            <span :class="$style.label">{{ $t('goods.add.platformCategory') }}</span>
            <ul v-if="!!siteCategoryPath.length" :class="$style.platformCategoryContent">
                <li v-for="(item, index) in siteCategoryPath" :key="index">
                    {{ item }}
                    <i v-if="index !== siteCategoryPath.length - 1" class="icon-arrow-right" ></i>
                </li>
                <span :class="$style.tip">{{ $t('goods.add.platformCategoryTip') }}</span>
            </ul>
        </div>
    </div>
</template>

<script>
    import emitter from '@/assets/js/mixins/emitter';
    import { siteCategoryPath, categoryPath } from '@goods/services/goods';

    export default {
        name: 'CategoryInfo',
        inject: ['goodsEditor', 'reload'],
        mixins: [emitter],
        data() {
            return {
                categoryPath: [],
                siteCategoryPath: []
            };
        },

        computed: {
            params() {
                return this.goodsEditor.params;
            },
            isEditor(val) {
                return this.goodsEditor.isEditor;
            }
        },

        watch: {
            params: {
                deep: true,
                immediate: true,
                handler({ categoryId }) {
                    if (!categoryId) return;
                    // 分类路径
                    this.getCategoryPath({ categoryId });
                    // 网站分类路径
                    this.getSiteCategoryPath({ categoryId });
                }
            }
        },

        methods: {
            // 获取分类路径
            async getCategoryPath(params) {
                const { data, status } = await categoryPath.http({ params });
                if (status === 0) {
                    if (data.path && data.path.length) {
                        this.categoryPath = data.path.split(' > ');
                    }
                }
            },

            // 获取网站分类
            async getSiteCategoryPath(params) {
                const { data, status } = await siteCategoryPath.http({ params });
                if (status === 0) {
                    if (data.path && data.path.length) {
                        this.siteCategoryPath = data.path.split(' > ');
                    }
                }
            },

            // 切换类目
            handleSwitchCategory() {
                this.$confirm(this.$t('goods.add.saveCategoryTip'), this.$t('goods.add.switchCategory'), {
                    cancelButtonText: this.$t('base.button.notSave'),
                    confirmButtonText: this.$t('base.button.save'),
                    distinguishCancelAndClose: true,
                    callback: (action) => {
                        if (action === 'confirm') {
                            this.dispatch('GoodsEditor', 'on-switch-category-enter');
                        } else if (action === 'cancel') {
                            this.dispatch('GoodsEditor', 'on-switch-category-cancel');
                        }
                    }
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .category {
        display: flex;
        align-items: center;
        padding-left: 40px;
        padding-top: 25px;
        font-size: var(--font-size-base);
    }

    .category:last-child {
        padding-bottom: 25px;
    }

    .category .label {
        color: var(--color-text-primary);
        flex-shrink: 0;
    }

    .categoryContent, .platformCategoryContent{
        display: flex;
        flex-wrap: wrap;
        align-items: center;
    }

    .categoryContent li:not(:last-of-type) {
        color: var(--color-text-regular);
    }

    .categoryContent li:last-of-type {
        margin-right: 20px;
    }

    .platformCategoryContent li {
        color: var(--color-text-regular);
    }

    .platformCategoryContent .tip {
        font-size: var(--font-size-base);
    }

    .category [class^="icon-arrow-right"] {
        display: inline-block;
        width: 24px;
        height: 24px;
        line-height: 24px;
        text-align: center;
    }
</style>
