<template>
    <div :class="$style.container">
        <template v-if="isView || !editing">
            <!-- 搜索类目 -->
            <layout-card
                v-if="!categorySelected && !isEditor"
                :name="$t('goods.add.category')"
                :collapsible="searchCategory.collapsible"
                :collapse="searchCategory.collapse"
                @collapse="onCollapsed('searchCategory', !searchCategory.collapse)">
                <category v-model="categoryIds" @completed="onCategorySelected"></category>
            </layout-card>

            <!-- 类目信息 -->
            <layout-card
                v-if="categorySelected"
                :name="$t('goods.add.categoryInfo')">
                <category-info></category-info>
            </layout-card>

            <!-- 基础信息 -->
            <layout-card
                v-if="categorySelected"
                :collapsible="basicInfoCard.collapsible"
                :collapse="basicInfoCard.collapse"
                name="基础信息"
                @collapse="onCollapsed('basicInfoCard', !basicInfoCard.collapse)">
                <baseInfo ref="baseInfo"></baseInfo>
            </layout-card>

            <!-- 属性信息 -->
            <layout-card
                v-if="categorySelected"
                :collapsible="attributeCard.collapsible"
                :collapse="attributeCard.collapse"
                name="属性信息"
                @collapse="onCollapsed('attributeCard', !attributeCard.collapse)">
                <attr-info ref="attrInfo"></attr-info>
            </layout-card>

            <!-- 销售信息 -->
            <layout-card
                v-if="categorySelected"
                :collapsible="salesInfoCard.collapsible"
                :collapse="salesInfoCard.collapse"
                name="销售信息"
                @collapse="onCollapsed('salesInfoCard', !salesInfoCard.collapse)">
                <sales-info ref="salesInfo"></sales-info>
            </layout-card>

            <!-- 物流信息 -->
            <layout-card
                v-if="categorySelected"
                :collapsible="logisticsCard.collapsible"
                :collapse="logisticsCard.collapse"
                name="物流属性"
                @collapse="onCollapsed('logisticsCard', !logisticsCard.collapse)">
                <logistics ref="logistics"></logistics>
            </layout-card>

            <div v-show="categorySelected" :class="$style.submit">
                <el-button v-if="savedVisible" :disabled="isView || !editable" :loading="saving" @click="handleSaveClick">保存草稿</el-button>
                <el-button :disabled="isView || !editable" :loading="submitting" type="primary" @click="handleSubmitClick">提交审核</el-button>
            </div>

        </template>

        <!--提交审核成功-->
        <submit-success v-if="submitted"></submit-success>
        <save-success v-if="saved"></save-success>
    </div>
</template>

<script>
    import { storeDeliverMode } from '@goods/services/logisitics';
    import {
        categoryAttribute, goodsAdd, goodsEdit, goodsInfo
    } from '@goods/services/goods';
    import {
        GOODS_EDITOR_BASE_INFO,
        GOODS_EDITOR_CATEGORY,
        GOODS_EDITOR_LOGISTICS
    } from '@goods/assets/js/constant/local';
    // components
    import Category from '@/components/Category';
    import CategoryInfo from './components/category-info/CategoryInfo';
    import BaseInfo from './components/base-Info/BaseInfo';
    import AttrInfo from './components/attr-info/AttrInfo';
    import SalesInfo from './components/sales-info/SalesInfo';
    import Logistics from './components/logistics/Logistics';
    import SubmitSuccess from './components/submit-success/SubmitSuccess';
    import SaveSuccess from './components/save-success/SaveSuccess';

    export default {
        name: 'GoodsEditor',
        components: {
            Category,
            CategoryInfo,
            BaseInfo,
            AttrInfo,
            SalesInfo,
            Logistics,
            SubmitSuccess,
            SaveSuccess
        },
        props: {
            // 是否编辑
            isEditor: {
                type: Boolean,
                default: false
            },
            // 是否查看
            isView: {
                type: Boolean,
                default: false
            }
        },
        provide() {
            return {
                goodsEditor: this
            };
        },
        inject: ['reload'],

        data() {
            return {
                params: {
                    product_id: '',
                    categoryId: '',
                    review_type: '',
                    variation_ids: ''
                },

                saving: false,
                submitting: false,
                submitted: false,
                saved: false,

                // 搜索分类
                searchCategory: {
                    collapsible: false,
                    collapse: false
                },
                categorySelected: false,
                categoryIds: [],


                // 基本信息
                basicInfoCard: {
                    collapsible: true,
                    collapse: false
                },

                // 属性信息
                attributeCard: {
                    collapsible: true,
                    collapse: false
                },
                descAttrs: null,
                descData: [],

                // 销售信息
                salesInfoCard: {
                    collapsible: true,
                    collapse: false
                },
                salesAttrs: null,
                salesData: null,

                // 物流属性
                logisticsCard: {
                    collapsible: true,
                    collapse: false
                },
                logisticsData: null,

                // 商品数据
                goodsData: null,

                // 发货模式
                deliverMode: null
            };
        },

        computed: {
            // 编辑中
            editing() {
                return this.submitted || this.saved;
            },
            // 可提交
            editable() {
                return +this.params.review_type !== 2;
            },
            // 保存草稿按钮 - 显示否
            savedVisible() {
                // 编辑草稿 || 添加时商品
                return (+this.params.review_type === 1 && this.isEditor && !this.isView) || (!this.isView && !this.isEditor);
            }
        },

        watch: {
            categorySelected(val) {
                this.getCategoryAttrs();
            },
            $route() {
                // 路由刷新的时候重载组件
                this.reload();
            }
        },

        beforeRouteLeave(to, from, next) {
            // 离开当前页面时删除缓存
            window.sessionStorage.removeItem(GOODS_EDITOR_BASE_INFO);
            window.sessionStorage.removeItem(GOODS_EDITOR_LOGISTICS);
            window.sessionStorage.removeItem(GOODS_EDITOR_CATEGORY);
            next();
        },

        created() {
            this.initRequest();

            // This event from <category-info/>
            this.$on('on-switch-category-enter', () => {
                this.cacheBaseAndLogisticsData();
                this.cacheCategoryData();
                // from inject method
                this.reload();
            });

            // This event from <category-info/>
            this.$on('on-switch-category-cancel', () => {
                this.cacheCategoryData();
                // from inject method
                this.reload();
            });

            // This event from <logistics/>
            this.$on('on-logistics-add', (callback) => {
                this.handleSaveClick(callback);
            });

            // 初始化分类
            this.initCategoryByCache();
        },

        methods: {

            // 初始化请求
            initRequest() {
                const isEditor = this.isEditor;

                if (isEditor) {
                    const params = {
                        product_id: this.$route.query.product_id,
                        review_type: this.$route.query.review_type
                    };
                    // 更新 params 对象
                    // this.params = Object.assign({}, this.params, params);
                    this.params.product_id = params.product_id;
                    this.params.review_type = params.review_type;

                    // 商品详情
                    this.getGoodsInfo(params);
                }

                this.getStoreDeliverMode();
            },

            // 处理折叠
            onCollapsed(module, val) {
                Object.assign(this[module], { collapse: val });
            },

            // 分类选择完成
            onCategorySelected(val) {
                this.categorySelected = true;
                // 取最后一个分类ID
                this.params.categoryId = [...val].pop().id;
            },

            // 获取分类属性
            async getCategoryAttrs() {
                const params = {
                    category_id: this.params.categoryId
                };
                const { data, status } = await categoryAttribute.http({ params });

                if (status === 0) {
                    this.descAttrs = data.attr_infos || [];
                    this.salesAttrs = data.sale_attrs || [];
                }
            },

            // 获取商品信息
            async getGoodsInfo(params) {
                const { data, status } = await goodsInfo.http({ params });

                if (status === 0) {
                    // 保存类目ID
                    this.params.categoryId = data.category_id;

                    // 手动设置为选择完毕类目
                    this.categorySelected = true;

                    // 数据赋值
                    this.goodsData = data;
                    this.salesData = data.sale_infos;
                    this.descData = data.attr_infos;
                }
            },

            // 获取发货模式
            async getStoreDeliverMode() {
                const { data, status } = await storeDeliverMode.http();
                if (status === 0) {
                    this.deliverMode = Object.assign({}, data);
                }
            },

            // 根据编辑或者新增调用不同的接口
            goodsAddOrEdit(data) {
                return this.isEditor ? goodsEdit.http({ data }) : goodsAdd.http({ data });
            },

            // 根据 ref 获取模块的数据 - 调用模块的 getData 方法
            getModuleDataByRef(refs) {
                return refs.reduce((acc, ref) => {
                    const item = this.$refs[ref].getData();
                    acc = Object.assign(acc, item);
                    return acc;
                }, {});
            },

            // 根据 ref 验证模块表单 - 调用模块的验证方法
            validateModuleByRef(refs, validate) {
                const submitPromise = refs.reduce((acc, name) => {
                    acc.push(this.$refs[name][validate]());
                    return acc;
                }, []);
                return Promise.all(submitPromise);
            },

            // 缓存基本信息和运费模板信息
            cacheBaseAndLogisticsData() {
                const data = this.getModuleDataByRef(['baseInfo', 'logistics']);

                window.sessionStorage.setItem(
                    GOODS_EDITOR_BASE_INFO,
                    JSON.stringify({
                        base_infos: data.base_infos
                    })
                );

                window.sessionStorage.setItem(
                    GOODS_EDITOR_LOGISTICS,
                    JSON.stringify({
                        logistics_template_id: data.logistics_template_id
                    })
                );
            },

            // 缓存分类信息数据
            cacheCategoryData() {
                window.sessionStorage.setItem(
                    GOODS_EDITOR_CATEGORY,
                    JSON.stringify(this.categoryIds)
                );
            },

            // 编辑时分类组件默认选中上次
            initCategoryByCache() {
                // 删除缓存信息
                const delCacheData = () => {
                    sessionStorage.removeItem(GOODS_EDITOR_CATEGORY);
                };

                const cache = window.sessionStorage.getItem(GOODS_EDITOR_CATEGORY);
                if (cache) {
                    try {
                        const categoryIds = JSON.parse(cache);
                        if (categoryIds && Array.isArray(categoryIds)) {
                            this.categoryIds = categoryIds;
                            delCacheData();
                        }
                    } catch (e) {
                        throw e;
                    }
                }
            },

            // 商品编辑地址
            getGoodsEditorPath(params) {
                const queryString = Object.keys(params).map(item => [item, params[item] || ''].join('=')).join('&');
                return `/goods/editor?${queryString}`;
            },

            // 保存草稿
            async handleSaveClick(callback) {
                if (!this.editable || this.saving) return;

                // 获取哪些模块的数据
                const dataRefs = [
                    'baseInfo',
                    'attrInfo',
                    'salesInfo',
                    'logistics'
                ];

                // 获取模块数据
                const getAllData = () => this.getModuleDataByRef(dataRefs);

                const data = {
                    ...getAllData(),
                    save_type: 2,
                    product_id: this.params.product_id,
                    category_id: this.params.categoryId
                };

                // 按钮显示加载状态
                this.saving = true;

                // 调用接口
                const reply = await this.goodsAddOrEdit(data);

                this.saving = false;

                // 请求成功
                if (reply.status === 0) {
                    this.params.product_id = reply.data.product_id;
                    // 兼容返回参数
                    // reply.data.variation_ids = reply.data.variation_ids || reply.data.variation_id;
                    // this.params.variation_ids = reply.data.variation_ids[0];
                    if (typeof callback === 'function') {
                        callback(this.getGoodsEditorPath({
                            product_id: reply.data.product_id,
                            review_type: 1
                        }));
                    } else {
                        // 根据保存类型显示不同的成功页面
                        this.saved = true;
                    }

                    this.scrollToTop();
                }
            },

            // 提交审核
            handleSubmitClick() {
                if (!this.editable || this.submitting) return;

                // 校验哪些模块
                const submitRefs = [
                    'baseInfo',
                    'attrInfo',
                    'salesInfo',
                    'logistics'
                ];

                // 将 promise all 返回的数据组装成对象
                const composeData = arr => arr && arr.reduce((acc, item) => {
                    acc = Object.assign(acc, item);
                    return acc;
                }, {});

                this.validateModuleByRef(submitRefs, 'submit').then(async (response) => {
                    const data = {
                        ...composeData(response),
                        save_type: 1,
                        product_id: this.params.product_id,
                        category_id: this.params.categoryId
                    };

                    // 按钮显示加载状态
                    this.submitting = true;

                    // 调用接口
                    // this.handleGoodsAddOrEdit(data);
                    const reply = await this.goodsAddOrEdit(data);

                    this.submitting = false;

                    // 请求成功
                    if (reply.status === 0) {
                        this.params.product_id = reply.data.product_id;
                        // 兼容返回参数
                        reply.data.variation_ids = reply.data.variation_ids || reply.data.variation_id;
                        this.params.variation_ids = reply.data.variation_ids[0];
                        // 根据保存类型显示不同的成功页面
                        this.submitted = true;
                        this.scrollToTop();
                    }

                }, response => this.$message.error('请检查表单'));
            },

            // 滚动至顶部
            scrollToTop() {
                document.documentElement.scrollTop = 0;
            }
        }
    };
</script>

<style module>
    .container {
        background-color: #fff;
    }

    .submit {
        display: flex;
        justify-content: center;
        padding: 80px 0 40px 0;
    }

    .submit button:nth-child(2) {
        margin-left: 30px;
    }
</style>
