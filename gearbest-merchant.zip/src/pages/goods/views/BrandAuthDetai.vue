<template>
    <layout-card :name="$t('goods.brand.brandAuth')">
        <div :class="$style.content">
            <el-form ref="authForm" :model="authForm" :rules="rules" label-width="200px" label-suffix=":">
                <el-form-item :label="$t('goods.brand.brand')" prop="brand_code">
                    <el-select
                        v-model="authForm.brand_code"
                        :placeholder="$t('goods.select')"
                        :loading="brandLoading"
                        :remote-method="getBrandList"
                        clearable
                        remote
                        filterable
                        @focus="getBrandList('')"
                        @clear="getBrandList('')">
                        <el-option v-for="(item, index) in brandList" :key="index" :label="item.label" :value="item.value">
                            <span :class="$style.optionLeft">{{ item.label }}</span>
                            <span :class="$style.optionRight">{{ item.other }}</span>
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item :label="$t('goods.brand.brandCertificateType')" prop="licensing_type">
                    <el-select v-model="authForm.licensing_type" :placeholder="$t('goods.brand.select')" @change="changeType">
                        <el-option :value="1" :label="$t('goods.brand.brandCertificate')"></el-option>
                        <el-option :value="2" :label="$t('goods.brand.brandAppectCertificate')"></el-option>
                        <el-option :value="3" :label="$t('goods.brand.brandRegisterCertificate')"></el-option>
                    </el-select>
                    <span :class="$style.authExplain">{{ $t('goods.brandAuth.authExplain') }}</span>
                </el-form-item>
                <el-form-item ref :label="$t('goods.brand.brandCertificateConfirm')">
                    <p :class="$style.detail">{{ $t('goods.brand.uploadDetail') }}
                    <a :href="formatDownloadUrl" class="">{{ $t('goods.brand.downloadFormat') }}</a></p>
                    <div v-for="(item, index) in authForm.licensingList" :key="index" :class="$style.item">
                        <el-form-item :prop="'licensingList.'+index+'.link'"
                                      :rules="[{ required: true, message: $t('goods.brand.fileEmpty'), trigger: 'change' } ]"
                                      label="" style="display: inline-block;vertical-align: bottom;">
                            <el-upload
                                :show-file-list="false"
                                :on-success="(res, file) => {
                                    handleAvatarSuccess(res, file, index);
                                }"
                                :before-upload="beforeAvatarUpload"
                                :action="uploadUrl"
                                :class="[$style.upload, item.link?$style.uploadFile:'']"
                                :with-credentials="true"
                                name="uploadFile"
                                style="display: inline-block"
                            >
                                <div v-if="item.link">
                                    <!--<img v-if="jubdgePattern(item.link) === 'jpg'" :src="item.link" :class="$style.imgUpload">-->
                                    <!--<div v-else-if="jubdgePattern(item.link) === 'pdf'" :class="$style.imgDiv">-->
                                    <!--<img :class="$style.formatImg" src="@goods/assets/img/pdf.png" alt="">-->
                                    <!--<div style="line-height: 20px"><a :class="$style.fileName">{{ item.file_name }}</a></div>-->
                                    <!--</div>-->
                                    <!--<div v-else :class="$style.imgDiv">-->
                                    <!--<img :class="$style.formatImg" src="@goods/assets/img/doc.png" alt="">-->
                                    <!--<div style="line-height: 20px"><a :class="$style.fileName">{{ item.file_name }}</a></div>-->
                                    <!--</div>-->
                                    <div :class="$style.imgDiv">
                                        <img :class="$style.formatImg" src="@goods/assets/img/doc.png" alt="">
                                        <div style="line-height: 20px">
                                            <a :class="$style.fileName" :title="item.file_name">{{ item.file_name }}</a>
                                        </div>
                                    </div>
                                </div>
                                <el-button v-else size="mini">
                                    <span :class="$style.iconUpload" class="el-icon-upload2"></span>
                                    <span :class="$style.uploadText">{{ $t('goods.brand.uploadFile') }}</span>
                                </el-button>
                            </el-upload>
                        </el-form-item>
                        <div :class="$style.time">
                            <span v-if="authForm.licensing_type !== 2" :class="$style.authDate">{{ $t('goods.brand.authDate') }}</span>
                            <div>
                                <el-form-item v-if="authForm.licensing_type !== 2"
                                              :prop="'licensingList.'+index+'.start_time'"
                                              :rules="[{ required: true, message: $t('goods.brand.timeEmtpy'), trigger: 'change' }]"
                                              label="" style="display: inline-block">
                                    <el-date-picker
                                        v-model="item.start_time"
                                        :placeholder="$t('goods.selectDate')"
                                        :picker-options="pickerStartOptions(item)"
                                        type="date">
                                    </el-date-picker>
                                </el-form-item>
                                <span v-if="authForm.licensing_type !== 2">{{ $t('goods.brand.zhi') }}</span>
                                <el-form-item v-if="authForm.licensing_type !== 2"
                                              :prop="'licensingList.'+index+'.end_time'"
                                              :rules="[{ required: true, message: $t('goods.brand.timeEmtpy'), trigger: 'change' }]"
                                              label="" style="display: inline-block">
                                    <el-date-picker
                                        v-model="item.end_time"
                                        :placeholder="$t('goods.selectDate')"
                                        :picker-options="pickerEndOptions(item)"
                                        type="date">
                                    </el-date-picker>
                                </el-form-item>
                                <el-button v-if="authForm.licensingList.length < authLimit"
                                           :class="$style.deleteBtn" size="mini" type="primary"
                                           @click="addAuth(index)">{{ $t('goods.add') }}</el-button>
                                <el-button v-if="authForm.licensingList.length > 1"
                                           :class="$style.deleteBtn" size="mini"
                                           type="danger" @click="deleteAuth(index)">{{ $t('goods.delete') }}</el-button>
                            </div>
                        </div>
                    </div>
                </el-form-item>
                <el-form-item style="margin-top: 50px">
                    <el-button type="primary" @click="submitForm('authForm')">{{ $t('goods.submitCheck') }}</el-button>
                </el-form-item>
            </el-form>
        </div>
    </layout-card>
</template>

<script module>
    import {
        serviceBrandAuthAdd, serviceBrandAuthDetail, serviceBrandAuthEdit, serviceBrandListGet
    } from '../services/goods';

    export default {
        name: 'GoodsList',
        data() {
            return {
                id: null,
                name: '',
                brandLoading: true,
                brandList: [],
                formatIcon: '',
                formatDownloadUrl: 'http://seller.gearbest.net/storage/document/download-format-description.docx',
                authForm: {
                    brand_code: '',
                    licensingList: [
                        {
                            link: '',
                            start_time: '',
                            end_time: '',
                            file_name: ''
                        }
                    ],
                    licensing_type: ''
                },
                rules: {
                    brand_code: [
                        { required: true, message: this.$t('goods.brand.selectBrandEmpty'), trigger: 'change' }
                    ],
                    licensing_type: [
                        { required: true, message: this.$t('goods.brand.brandCertificateTypeEmpty'), trigger: 'change' }
                    ]
                },
                authLimit: 10,
                uploadUrl: '/image-manage/image-upload?method=brandAuth',
                pickerStartOptions(item) {
                    return {
                        disabledDate(time) {
                            if (item.end_time) {
                                return time.getTime() > (new Date(item.end_time).getTime() - 60 * 60 * 24 * 1000);
                            }
                            return false;
                        }
                    };
                },
                pickerEndOptions(item) {
                    return {
                        disabledDate(time) {
                            if (item.start_time) {
                                return time.getTime() < (new Date(item.start_time).getTime() + 60 * 60 * 24 * 1000);
                            }
                            return false;
                        }
                    };
                }
            };
        },
        created() {
            const { name, params, query } = this.$route;
            this.name = name;
            if (name === 'brandAuthEdit' && Object.prototype.hasOwnProperty.call(params, 'id')) {
                this.id = params.id;
                this.getDetail();
            }
            if (query.brandCode) {
                this.authForm.brand_code = query.brandCode;
            }
            // this.getBrandList('', this.authForm.brand_code);
        },
        methods: {
            async getDetail() {
                const { status, data } = await serviceBrandAuthDetail.http({
                    params: {
                        id: this.id
                    }
                });
                if (status === 0) {
                    this.authForm.brand_code = data.brand_code;
                    this.authForm.licensingList = data.licensingList;
                    this.authForm.licensing_type = data.licensing_type;
                    this.authForm.licensingList.forEach((item) => {
                        item.start_time *= 1000;
                        item.end_time *= 1000;
                    });
                    console.log(data.licensingList);
                }
            },
            async getBrandList(name = '', brand_codes = '') {
                const { status, data } = await serviceBrandListGet.http({
                    params: {
                        page_index: 1,
                        page_size: 500,
                        is_all: 1,
                        review_status: 2,
                        name,
                        brand_codes
                    }
                });
                this.brandLoading = false;
                if (status === 0) {
                    this.brandList = data.list.map(item => ({
                        label: item.name_en,
                        value: item.brand_code,
                        other: item.brand_owner
                    }));
                }
            },
            changeType() {
                this.authForm.licensingList = [
                    {
                        link: '',
                        start_time: '',
                        end_time: '',
                        file_name: ''
                    }
                ];
                if (this.authForm.licensing_type === 2) {
                    this.authLimit = 2;
                } else {
                    this.authLimit = 10;
                }
            },
            handleAvatarSuccess(res, file, index) {
                if (res.status === 0) {
                    this.authForm.licensingList[index].file_name = file.name;
                    this.authForm.licensingList[index].link = res.data.url;
                } else {
                    this.$message.error(res.msg);
                }
            },
            beforeAvatarUpload(file) {
                const isLt5M = file.size / 1024 / 1024 < 5;
                const isValidExt = ['application/pdf', 'image/jpe', 'image/jpeg'].includes(file.type);
                if (!isLt5M) {
                    this.$message.error(this.$t('goods.brandAuth.fileFormat'));
                }
                if (!isValidExt) {
                    this.$message.error(this.$t('goods.brandAuth.fileFormat'));
                }
                return isLt5M && isValidExt;
            },
            deleteAuth(index) {
                this.authForm.licensingList.splice(index, 1);
            },
            jubdgePattern(link) {
                const pdf = /.pdf$/i;
                const jpg = /.jpg$|.jpeg$/i;
                if (jpg.test(link)) {
                    return 'jpg';
                }
                if (pdf.test(link)) {
                    return 'pdf';
                }
                return 'doc';
            },
            addAuth(index) {
                this.authForm.licensingList.splice(index + 1, 0, {
                    link: '',
                    start_time: '',
                    end_time: ''
                });
            },
            async addBrandAuth() {
                const postData = {
                    brand_code: this.authForm.brand_code,
                    licensing_type: this.authForm.licensing_type,
                    licensingList: []
                };
                this.authForm.licensingList.forEach((item) => {
                    postData.licensingList.push({
                        end_time: item.end_time ? item.end_time / 1000 : '',
                        start_time: item.start_time ? item.start_time / 1000 : '',
                        link: item.link,
                        file_name: item.file_name
                    });
                });
                const { status, msg } = await serviceBrandAuthAdd.http({
                    data: postData
                });
                if (status === 0) {
                    this.$message({
                        message: this.$t('goods.brand.brandAuthSubmitSuccess'),
                        type: 'success'
                    });
                    this.$router.push({
                        name: 'brandAuthList'
                    });
                } else {
                    this.$message.error(msg);
                }
            },
            async editBrandAuth() {
                const postData = {
                    brand_code: this.authForm.brand_code,
                    licensing_type: this.authForm.licensing_type,
                    licensingList: [],
                    id: this.id
                };
                this.authForm.licensingList.forEach((item) => {
                    postData.licensingList.push({
                        end_time: item.end_time ? item.end_time / 1000 : '',
                        start_time: item.start_time ? item.start_time / 1000 : '',
                        link: item.link,
                        file_name: item.file_name
                    });
                });
                const { status, msg } = await serviceBrandAuthEdit.http({
                    data: postData
                });
                if (status === 0) {
                    this.$message({
                        message: this.$t('goods.brand.brandAuthSubmitSuccess'),
                        type: 'success'
                    });
                    this.$router.push({
                        name: 'brandAuthList'
                    });
                } else {
                    this.$message.error(msg);
                }
            },
            submitForm(formName) {
                this.$refs[formName].validate(async (valid) => {
                    if (valid) {
                        if (this.name === 'brandAuthEdit') {
                            this.editBrandAuth();
                        } else {
                            this.addBrandAuth();
                        }
                    } else {
                        console.log('error submit!!');
                    }
                });
            },
        }
    };
</script>

<style module>
    @import 'variable.css';
    .container {
        color: red;
        font-size: 18px;
    }
    .detail{
        color: #666;
    }
    .time {
        display: inline-block;
        vertical-align: top;
        margin-left: 23px;
    }
    .content{
        padding: 24px;
    }
    .upload {
        vertical-align: middle;
    }
    .uploadFile :global .el-upload--picture-card {
        border: 0;
    }
    .authDate{
        color: #999;
    }
    .item:not(:last-of-type) {
      margin-bottom: 30px;
    }
    .deleteBtn{
        margin-left: 10px;
    }
    .optionLeft {
        float: left;
        padding-right: 10px;
        max-width: 300px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .optionRight{
        float: right;
        padding-left: 10px;
        max-width: 300px;
        color: var(--color-text-secondary );
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: right;
    }
    .fileLink{
        color: var(--color-text-regular);
        display: inline-block;
        width: 80px;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        position: absolute;
        left: 0;
        bottom: 14px;
    }
    .iconUpload{
        color: var(--color-primary);
        font-size: var(--font-size-larger);
        vertical-align: middle;
    }
    .uploadText{
        vertical-align: middle;
        color: var(--color-text-primary);
    }
    .imgUpload{
        width: 70px;
        height: 70px;
        vertical-align: bottom;
    }
    .formatImg{
        width: 40px;
        height: 50px;
    }
    .fileName{
        width: 70px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        display: inline-block;
    }
    .imgDiv{
        height: 50px;
        display: inline-block;
    }
    .authExplain {
        margin-left: 10px;
        color: var(--color-text-regular);
    }
</style>
