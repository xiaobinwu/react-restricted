import Service from '@/assets/js/Service/index';

/**
 * 获取商品发布类目
 */
export const goodsCategory = new Service({
    url: '/goods/category-tree',
    method: 'get',
    loading: true
});

/**
 * 品牌授权列表 - 下拉框使用
 */
export const brandList = new Service({
    url: '/public/goods/query-brand-licensing-list',
    method: 'get',
    showError: true,
    loading: true
});

/**
 * 获取网站分类路径
 */
export const siteCategoryPath = new Service({
    url: '/public/goods/get-site-category-path',
    method: 'get',
    showError: true,
    loading: true
});

/**
 * 获取发布类目路径
 */
export const categoryPath = new Service({
    url: '/public/goods/get-category-path',
    method: 'get',
    showError: true,
    loading: true
});

/*
 * 获取分类绑定属性列表
 */
export const categoryAttribute = new Service({
    url: '/public/goods/get-category-attr-list',
    method: 'get',
    showError: true,
    loading: true
});

/**
 * 新增商品
 */
export const goodsAdd = new Service({
    url: '/goods/goods-add',
    method: 'post',
    showError: true
});

/**
 * 商品编辑
 */
export const goodsEdit = new Service({
    url: '/goods/goods-edit',
    method: 'post',
    showError: true,
    loading: true
});

/**
 * 商品详情
 */
export const goodsInfo = new Service({
    url: '/goods/goods-info',
    method: 'get',
    loading: true
});

// 品牌列表
export const serviceBrandListGet = new Service({
    url: '/goods/brand-list',
    method: 'get',
    isCancel: false,
});

// 删除品牌
export const serviceBrandDelete = new Service({
    url: '/goods/brand-delete',
    loading: true,
    method: 'post',
});

// 添加品牌
export const serviceBrandAdd = new Service({
    url: '/goods/brand-add',
    loading: true,
    method: 'post'
});

// 品牌详情
export const serviceBrandDetail = new Service({
    url: '/goods/brand-info',
    loading: true,
    method: 'get',
});

// 品牌编辑
export const serviceBrandEdit = new Service({
    url: '/goods/brand-edit',
    loading: true,
    method: 'post',
});

// 品牌授权列表
export const serviceBrandAuthList = new Service({
    url: '/goods/brand-licensing-list',
    loading: true,
    method: 'get',
    isCancel: false
});

// 删除品牌授权
export const serviceBrandAuthDelete = new Service({
    url: '/goods/brand-licensing-delete',
    loading: true,
    method: 'post'
});

// 添加品牌授权
export const serviceBrandAuthAdd = new Service({
    url: '/goods/brand-licensing-add',
    loading: true,
    method: 'post',
});

// 编辑品牌授权
export const serviceBrandAuthEdit = new Service({
    url: '/goods/brand-licensing-edit',
    loading: true,
    method: 'post',
});

// 查询品牌授权详情
export const serviceBrandAuthDetail = new Service({
    url: '/goods/brand-licensing-info',
    loading: true,
    method: 'get',
});

export const serviceBrandAuthPublicList = new Service({
    url: '/public/goods/query-brand-licensing-list',
    loading: true,
    method: 'get',
});

// 查询审核通过的商品列表
export const serviceApproveGoodsList = new Service({
    url: '/goods/approved-goods-list',
    loading: true,
    method: 'get',
    isCancel: false,
});

// 获取全部的运费模板
export const serviceGetFreightList = new Service({
    url: '/public/logistics/shipping-template/get-all',
    loading: true,
    method: 'get'
});

// 设置运费模板
export const serviceChangeFreight = new Service({
    url: '/goods/change-goods-freight-template',
    loading: true,
    method: 'post'
});

// 商品上下架
export const serviceUpAndDownGoods = new Service({
    url: '/goods/change-goods-status',
    loading: true,
    method: 'post'
});

// 修改商品价格接口
export const serviceChangePrice = new Service({
    url: '/goods/change-goods-price',
    loading: true,
    method: 'post'
});

// 修改商品库存
export const serviceChangeStorage = new Service({
    url: '/goods/change-goods-stock',
    loading: true,
    method: 'post'
});

// 查询待审核的列表
export const serviceCheckGoodsList = new Service({
    url: '/goods/under-review-goods-list',
    loading: true,
    method: 'get',
    isCancel: false
});

// 待提交列表
export const serviceWaitSubmitGoodsList = new Service({
    url: '/goods/saved-goods-list',
    loading: true,
    method: 'get',
    isCancel: false,
});

// 删除待提交商品
export const serviceDeleteSavedGoods = new Service({
    url: '/goods/delete-saved-goods',
    loading: true,
    method: 'post'
});

// 提交未提交的商品
export const serviceSubmitSavedGoods = new Service({
    url: '/goods/quick-save-goods',
    loading: true,
    method: 'post'
});

// 审核不通过的列表
export const serviceDisapproveGoodsList = new Service({
    url: '/goods/not-approved-goods-list',
    loading: true,
    method: 'get',
    isCancel: false,
});

// 删除审核不通过的商品
export const serviceDeleteDisapproveGoods = new Service({
    url: '/goods/delete-not-approved-goods',
    loading: true,
    method: 'post'
});

// 修改审核不通过的商品的价格
export const serviceEditDisapproveGoodsPrice = new Service({
    url: '/goods/change-not-approved-goods-price',
    loading: true,
    method: 'post'
});

// 修改审核不通过的商品的库存
export const serviceEditDisapproveGoodsStock = new Service({
    url: '/goods/change-not-approved-goods-stock',
    loading: true,
    method: 'post'
});

// 获取所有国家数据
export const serviceGetCountryList = new Service({
    url: '/public/logistics/country/list',
    loading: true,
    method: 'get'
});

// CDP商标注册地
export const serviceGetTrademarks = new Service({
    url: '/public/trademarks',
    loading: true,
    method: 'get'
});

// 获取商品预览信息
export const getGoodsPreviewInfo = new Service({
    url: '/goods/goods-preview-info',
    loading: true,
    method: 'get',
});
