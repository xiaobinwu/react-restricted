import Service from '@/assets/js/Service/index';

/**
 * 获取运费模板
 */
export const shippingTemplate = new Service({
    url: '/public/logistics/shipping-template/get-all',
    method: 'get'
});

/**
 * 店铺支持的发货模式
 */
export const storeDeliverMode = new Service({
    url: '/public/get-store-deliver-mode',
    method: 'get'
});
