/**
 * 本地存储使用的常量-> localStorage sessionStorage
 */

// 商品编辑-基本信息
export const GOODS_EDITOR_BASE_INFO = 'goods-editor-base-info';
export const GOODS_EDITOR_LOGISTICS = 'goods-editor-logistics';
export const GOODS_EDITOR_CATEGORY = 'goods-editor-category';
