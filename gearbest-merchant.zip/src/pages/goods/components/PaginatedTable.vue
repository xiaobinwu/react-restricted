<template>
    <div>
        <slot name="headerBatch"></slot>
        <el-table
            :ref="refDom"
            :data="data"
            v-bind="$attrs"
            border
            v-on="$listeners"
        >
            <template v-for="column in columns">
                <el-table-column
                    v-if="column.type && column.type === 'expand'"
                    v-bind="column"
                    :key="column.type"
                >
                    <template slot-scope="scope">
                        <!-- 将作用域插槽的scope再回传到父组件的slot引用，再以slot-scope插槽暴露出去 -->
                        <slot
                            v-bind="scope"
                            name="expand"
                        />
                    </template>
                </el-table-column>
                <el-table-column
                    v-else-if="column.type && column.type !== 'expand'"
                    v-bind="column"
                    :key="column.type"
                />
                <el-table-column
                    v-else-if="!column.type && column.scope"
                    v-bind="column"
                    :key="column.label"
                >
                    <template slot-scope="scope">
                        <template
                            v-if="column.showHeader"
                            slot="header"
                        >
                            {{ column.label ? column.label : '' }}
                            <slot name="header"/>
                        </template>
                        <slot
                            v-if="column.showSlot"
                            v-bind="scope"
                            :name="column.prop"
                        />
                    </template>
                </el-table-column>
                <el-table-column
                    v-else
                    v-bind="column"
                    :key="column.label"
                />
            </template>
            <template slot="append">
                <slot name="append" />
            </template>
        </el-table>
        <div>
            <slot name="bottomBatch"></slot>
        </div>
        <div>
            <el-pagination
                v-if="isPagination"
                :class="$style.page"
                :current-page="pagination.pageNo"
                :page-sizes="[10, 20, 50]"
                :page-size="pagination.pageSize"
                :total="pagination.totalCount"
                layout="total, sizes, prev, pager, next, jumper"
                @size-change="changePageSize"
                @current-change="changePage"
            />
        </div>
    </div>
</template>

<script>
    export default {
        name: 'PaginatedTable',
        props: {
            data: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            refDom: {
                type: String,
                required: false,
                default() {
                    return 'table';
                }
            },
            columns: {
                type: Array,
                required: true,
                default() {
                    return [];
                }
            },
            pagination: {
                type: Object,
                default() {
                    return null;
                }
            }
        },
        computed: {
            isPagination() {
                return this.isNotEmptyObject(this.pagination);
            }
        },
        methods: {
            changePageSize(value) {
                this.$emit('pagesize-change', value);
            },
            changePage(value) {
                this.$emit('page-change', value);
            },
            isNotEmptyObject(obj) {
                return obj && Object.keys(obj).length > 0;
            }
        }
    };
</script>

<style module>
    .page {
        margin: 20px 0;
        text-align: right;
    }
</style>
