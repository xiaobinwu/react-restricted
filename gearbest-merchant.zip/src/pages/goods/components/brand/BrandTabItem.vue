<template>
    <div>
        <div :class="$style.header" >
            <span :class="$style.name">{{ $t('goods.brand.EName') }}:</span>
            <el-select v-model="brandCode" :placeholder="$t('goods.brand.inputENameSearch')" filterable>
                <el-option v-for="(item, index) in brandList" :key="index" :label="item.label" :value="item.value">
                    <span :class="$style.optionLeft">{{ item.label }}</span>
                    <span :class="$style.optionRight">{{ item.other }}</span>
                </el-option>
            </el-select>
            <el-button :class="$style.searchBtn" type="primary" @click="search">{{ $t('goods.search') }}</el-button>
            <el-button type="default" style="float: right;" @click="addBrand">{{ $t('goods.brand.brandAdd') }}</el-button>
        </div>
        <paginated-table
            v-loading="loading"
            :data="tableData"
            :columns="tableColumns"
            :pagination="pagination"
            :span-method="objectSpanMethod"
            :border="true"
            @pagesize-change="changePageSize"
            @page-change="changePage"
        >
            <template
                v-if="type===2 || type===3"
                slot="operate"
                slot-scope="scope"
            >
                <el-button
                    type="text"
                    @click="rowEdit(scope.row)"
                >{{ $t('goods.edit') }}</el-button>
                <el-button
                    v-if="type===3"
                    :class="$style.delete"
                    type="text"
                    @click="rowDelete(scope.row)"
                >{{ $t('goods.delete') }}</el-button>
            </template>
            <template
                slot="logo"
                slot-scope="scope"
            >
                <img :src="domainName + scope.row.logo" :class="$style.logo"/>
            </template>
            <template
                slot="EName"
                slot-scope="scope"
            >
                <router-link :to="{ name: 'brandDetail', params: {id: scope.row.id},query: {type: scope.row.reviewStatus}}">
                    {{ scope.row.EName }}
                </router-link>
            </template>
        </paginated-table>
        <el-dialog
            :visible.sync="dialogVisible"
            center
            width="560px">
            <div :class="$style.center">{{ $t('goods.brand.deleteTip') }}</div>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">{{ $t('goods.cancel') }}</el-button>
                <el-button type="primary" @click="confirm()">{{ $t('goods.confirm') }}</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import PaginatedTable from '../PaginatedTable.vue';
    import { serviceBrandListGet, serviceBrandDelete } from '../../services/goods';
    import { UPLOAD_LOGO } from '@/assets/js/constant/env.js';

    export default {
        name: 'BrandTabItem',
        components: { PaginatedTable },
        props: {
            type: {
                type: Number,
                default() {
                    return null;
                }
            }
        },
        data() {
            return {
                brandCode: '',
                dialogVisible: false,
                tableData: [],
                rowData: {},
                loading: false,
                tableColumns: [
                    {
                        label: this.$t('goods.brand.EName'),
                        prop: 'EName',
                        showSlot: true,
                        scope: true,
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.logo'),
                        showSlot: true,
                        scope: true,
                        prop: 'logo',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.brandOwner'),
                        prop: 'brandOwner',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.registerAddr'),
                        prop: 'registerAddr',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.brandCode'),
                        prop: 'brandCode',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.classifyNo'),
                        prop: 'classifyNo',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.checkResult'),
                        prop: 'checkResult',
                        align: 'center',
                        'header-align': 'center'
                    },
                    {
                        label: this.$t('goods.brand.submitTime'),
                        prop: 'submitTime',
                        align: 'center',
                        'header-align': 'center'
                    }
                ],
                pagination: {
                    pageNo: 1,
                    pageSize: 10,
                    totalCount: 0
                },
                sortDataIndex: [],
                idIndexArr: [],
                brandList: [],
                domainName: UPLOAD_LOGO,
                checkResult: [this.$t('goods.brand.waitACheck'), this.$t('goods.goodsList.pass'), this.$t('goods.goodsList.noPass')],
                isFirst: true, // 用于进入这个tab获取全部数据
                isNoAccessTab: true, // 用于从未进入过这个tab,
                isGetSelectList: false // 是否获取全部的下拉数据
            };
        },
        created() {
            this.init();
        },
        methods: {
            async init() {
                if (this.type === 3) {
                    this.tableColumns.push(
                        {
                            label: this.$t('goods.brand.reason'),
                            prop: 'reason',
                            align: 'center',
                            'header-align': 'center'
                        }
                    );
                    this.tableColumns.push(
                        {
                            label: this.$t('goods.operate'),
                            showSlot: true,
                            scope: true,
                            prop: 'operate',
                            align: 'center',
                            'header-align': 'center'
                        }
                    );
                }
                const {
                    brandCode, pageSize, pageNo
                } = this.$route.query;
                let { type } = this.$route.query;
                if (!type) {
                    type = 2;
                }
                if (Number(type) === this.type) {
                    this.pagination.pageNo = Number(pageNo) || 1;
                    this.pagination.pageSize = Number(pageSize) || 10;
                    this.brandCode = brandCode;
                    this.isFirst = false;
                    this.isNoAccessTab = false;
                    this.getList();
                    const { data, status } = await this.serviceGetList({
                        page: 1,
                        pageSize: 1000000000,
                        reviewStatus: this.type,
                    });
                    if (status === 0) {
                        this.brandList = data.list.map(item => ({
                            label: item.name_en,
                            value: item.brand_code,
                            other: item.brand_owner
                        }));
                        this.$emit('changeNum', {
                            type: this.type,
                            total: data.total_num
                        });
                    }
                }
                // 用于非当前tab获取数值
                if (this.isFirst) {
                    this.getList();
                }
            },
            search() {
                this.getList();
                this.turnUrl();
            },
            async getList() {
                this.tableData = [];
                this.loading = true;
                const { data, status } = await this.serviceGetList({
                    page: this.pagination.pageNo,
                    pageSize: this.pagination.pageSize,
                    reviewStatus: this.type,
                    brandCode: this.brandCode
                });
                this.loading = false;
                this.handleList({ data, status });
            },
            async serviceGetList({
                page = 1, pageSize = 10, reviewStatus, brandCode
            }) {
                const res = await serviceBrandListGet.http({
                    params: {
                        page_index: page,
                        brand_codes: brandCode,
                        review_status: reviewStatus,
                        page_size: pageSize
                    },
                });
                return res;
            },
            handleList({ status, data }) {
                if (status === 0) {
                    if (this.isNoAccessTab) {
                        this.$emit('changeNum', {
                            type: this.type,
                            total: data.total_num
                        });
                        return;
                    }
                    data.list.forEach((item, index) => {
                        if (item.register_infos && item.register_infos.length) {
                            for (let i = 0; i < item.register_infos.length; i += 1) {
                                const obj = {
                                    id: item.id,
                                    EName: item.name_en,
                                    logo: item.brand_logo,
                                    brandCode: item.register_infos[i].register_no,
                                    brandOwner: item.brand_owner,
                                    registerAddr: item.register_infos[i].register_addr_name,
                                    checkResult: this.checkResult[item.review_status - 1],
                                    reviewStatus: item.review_status,
                                    classifyNo: item.register_infos[i].register_classify_no,
                                    submitTime: item.created_at,
                                    reason: item.review_remark,
                                };
                                this.tableData.push(obj);
                            }
                        } else {
                            const obj = {
                                id: item.id,
                                EName: item.name_en,
                                logo: item.brand_logo,
                                brandCode: '',
                                brandOwner: item.brand_owner,
                                registerAddr: '',
                                checkResult: this.checkResult[item.review_status - 1],
                                reviewStatus: item.review_status,
                                classifyNo: '',
                                submitTime: item.created_at,
                                reason: item.review_remark
                            };
                            this.tableData.push(obj);
                        }
                    });
                    this.pagination.pageNo = data.page_index;
                    this.pagination.totalCount = data.total_num;
                    this.sortDataArr();
                    this.getOrderNumber();
                    if (this.isFirst) {
                        this.$emit('changeNum', {
                            type: this.type,
                            total: data.total_num
                        });
                        this.isFirst = false;
                    }
                }
            },
            async getDataFirstPage() {
                this.brandCode = '';
                this.pagination = {
                    pageNo: 1,
                    pageSize: 10,
                    totalCount: 0
                };
                this.isFirst = true;
                this.isNoAccessTab = false;
                this.getList();
                this.turnUrl();
                if (!this.isGetSelectList) {
                    const { data, status, msg } = await this.serviceGetList({
                        page: 1,
                        pageSize: 1000000000,
                        reviewStatus: this.type,
                    });
                    if (status === 0) {
                        this.isGetSelectList = true;
                        this.brandList = data.list.map(item => ({
                            label: item.name_en,
                            value: item.brand_code,
                            other: item.brand_owner
                        }));
                    } else {
                        this.$message.error(msg);
                    }
                }
            },
            // 对相同id排在一起整理
            sortDataArr() {
                const OrderObj = {};
                this.sortDataIndex = [];
                this.tableData.forEach((element, index) => {
                    if (OrderObj[element.id]) {
                        OrderObj[element.id].push(index);
                    } else {
                        OrderObj[element.id] = [];
                        OrderObj[element.id].push(index);
                    }
                });

                for (const k in OrderObj) {
                    this.sortDataIndex.push(OrderObj[k]);
                }
                const dataArr = [];
                for (let i = 0; i < this.sortDataIndex.length; i += 1) {
                    const element = this.sortDataIndex[i];
                    for (let j = 0; j < element.length; j += 1) {
                        dataArr.push(this.tableData[element[j]]);
                    }
                }
                this.tableData = dataArr;
            },
            // 获取相同的spu的数组
            getOrderNumber() {
                const OrderObj = {};
                this.idIndexArr = [];
                this.tableData.forEach((element, index) => {
                    element.rowIndex = index;
                    if (OrderObj[element.id]) {
                        OrderObj[element.id].push(index);
                    } else {
                        OrderObj[element.id] = [];
                        OrderObj[element.id].push(index);
                    }
                });

                for (const k in OrderObj) {
                    // if (OrderObj[k].length > 1) {
                    this.idIndexArr.push(OrderObj[k]);
                    // }
                }
            },
            objectSpanMethod({
                row, column, rowIndex, columnIndex
            }) {
                if (columnIndex === 0 || columnIndex === 1 || columnIndex === 2 || columnIndex === 6 || columnIndex === 7) {
                    for (let i = 0; i < this.idIndexArr.length; i += 1) {
                        const element = this.idIndexArr[i];
                        for (let j = 0; j < element.length; j += 1) {
                            const item = element[j];
                            if (rowIndex === item) {
                                row.group = i;
                                if (j === 0) {
                                    return {
                                        rowspan: element.length,
                                        colspan: 1
                                    };
                                } if (j !== 0) {
                                    return {
                                        rowspan: 0,
                                        colspan: 0
                                    };
                                }
                            }
                        }
                    }
                }
                return {
                    rowspan: 1,
                    colspan: 1
                };
            },
            rowEdit(row) {
                this.$router.push({ name: 'brandEdit', params: { id: row.id }, query: { type: 3 } });
            },
            rowDelete(row) {
                this.rowData = row;
                this.dialogVisible = true;
            },
            addBrand() {
                this.$router.push({ name: 'brandAdd' });
            },
            async confirm() {
                const { status } = await serviceBrandDelete.http({
                    data: {
                        review_status: this.rowData.reviewStatus,
                        id: this.rowData.id
                    }
                });
                if (status === 0) {
                    this.$message({
                        message: this.$t('goods.deleteSuccess'),
                        type: 'success'
                    });
                } else {
                    this.$message.error(this.$t('goods.deleteFailed'));
                }
                this.dialogVisible = false;
                await this.getList();
            },
            turnUrl() {
                this.$router.replace({
                    name: 'brandList',
                    query: {
                        pageSize: this.pagination.pageSize,
                        brandCode: this.brandCode,
                        pageNo: this.pagination.pageNo,
                        type: this.type
                    }
                });
            },
            // 分页事件
            changePageSize(value) {
                this.pagination.pageSize = value;
                this.turnUrl();
                this.getList();
            },
            changePage(value) {
                this.pagination.pageNo = value;
                this.turnUrl();
                this.getList();
            }
        },
    };
</script>

<style module>
    @import 'variable.css';
    .header{
        margin-bottom: 20px;
    }
    .input {
        width: 300px;
    }
    .name {
        margin-right: 10px;
    }
    .searchBtn{
        margin-left: 20px;
    }
    .delete{
        color: #ff5757;
    }
    .logo {
        width: 56px;
        height: 56px;
    }
    .center{
        text-align: center;
        font-size: 16px;
    }
    .optionLeft {
        float: left;
        padding-right: 10px;
        max-width: 300px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .optionRight{
        float: right;
        padding-left: 10px;
        max-width: 300px;
        color: var(--color-text-secondary );
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: right;
    }
</style>
