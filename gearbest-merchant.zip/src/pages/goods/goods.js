import app from '@/assets/js/app';
import lang from '@/assets/js/lang';
import goodsLang from '@/lang/goods';
import router from './router';


(async () => {
    const langInstance = await lang({ local: goodsLang, moduleName: 'goods' });
    app({ lang: langInstance, router });
})();
