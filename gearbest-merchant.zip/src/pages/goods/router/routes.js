import asyncComponent from '@/assets/js/common/asyncComponent';

export default [
    // 添加商品
    {
        path: '/goods/add',
        name: 'goodsAdd',
        meta: {
            title: 'base.menu.goods.add'
        },
        component: () => asyncComponent(import('@goods/views/goods-editor/GoodsEditor'))
    },
    // 修改商品
    {
        path: 'goods/editor',
        name: 'goodsEditor',
        meta: {
            title: 'goods.edit.title',
            focusMenu: '/goods/list'
        },
        props: {
            isEditor: true
        },
        component: () => asyncComponent(import('@goods/views/goods-editor/GoodsEditor'))
    },
    // 查看商品详情
    {
        path: 'goods/detail',
        name: 'goodsDetail',
        meta: {
            title: 'goods.detail.title',
            focusMenu: '/goods/list'
        },
        props: {
            isEditor: true,
            isView: true
        },
        component: () => asyncComponent(import('@goods/views/goods-editor/GoodsEditor'))
    },
    // 品牌列表页
    {
        path: '/goods/brand',
        name: 'brandList',
        meta: {
            title: 'base.menu.goods.brandList',
        },
        component: () => asyncComponent(import('@goods/views/BrandList'))
    },
    // 品牌添加页
    {
        path: '/goods/brand/add',
        name: 'brandAdd',
        meta: {
            title: 'goods.brand.add',
            focusMenu: '/goods/brand',
        },
        component: () => asyncComponent(import('@goods/views/BrandDetail'))
    },
    // 品牌编辑页
    {
        path: '/goods/brand/:id',
        name: 'brandEdit',
        meta: {
            title: 'goods.brand.edit',
            focusMenu: '/goods/brand',
        },
        component: () => asyncComponent(import('@goods/views/BrandDetail'))
    },
    // 品牌详情页
    {
        path: '/goods/brand-detail/:id',
        name: 'brandDetail',
        meta: {
            title: 'goods.brand.detail',
            requestAuth: true,
            focusMenu: '/goods/brand',
        },
        component: () => asyncComponent(import('@goods/views/BrandDetail'))
    },
    // 品牌授权列表
    {
        path: '/goods/brand-auth',
        name: 'brandAuthList',
        meta: {
            title: 'base.menu.goods.brandAuth',
        },
        component: () => asyncComponent(import('@goods/views/BrandAuthList'))
    },
    // 品牌授权添加
    {
        path: '/goods/brand-auth/add',
        name: 'brandAuthAdd',
        meta: {
            title: 'goods.brandAuth.add',
            focusMenu: '/goods/brand-auth',
        },
        component: () => asyncComponent(import('@goods/views/BrandAuthDetai'))
    },
    // 品牌授权编辑
    {
        path: '/goods/brand-auth/:id',
        name: 'brandAuthEdit',
        meta: {
            title: 'goods.brandAuth.edit',
            focusMenu: '/goods/brand-auth',
        },
        component: () => asyncComponent(import('@goods/views/BrandAuthDetai'))
    },
    // 商品列表
    {
        path: '/goods/list',
        name: 'goodsList',
        meta: {
            title: 'base.menu.goods.list',
        },
        component: () => asyncComponent(import('@goods/views/goods-list/GoodsList'))
    },
    // 商品预览页面
    {
        path: '/goods/preview/:id-:type',
        name: 'GoodsPreview',
        meta: {
            title: 'base.menu.goods.preview',
            focusMenu: '/goods/list',
        },
        component: () => asyncComponent(import('@goods/views/GoodsPreview'))
    }
];
