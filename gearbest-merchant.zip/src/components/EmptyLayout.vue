<template>
    <div :class="$style.app">
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'Layout'
    };
</script>

<style module>
    @import 'utils.css';
    .container {
        width: 100%;
    }
</style>
