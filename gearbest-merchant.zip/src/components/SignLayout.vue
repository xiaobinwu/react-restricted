<template>
    <div :class="$style.app">
        <Layout-header-main :show-menu="showMenu" :show-logout="showLogout" :menu-logo="isMenuLogo" />
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'Layout',
        data() {
            return {
                showMenu: true,
                showLogout: true,
                isMenuLogo: true
            };
        },
        created() {
            if (this.$route.meta.showHeaderMenu !== undefined) {
                this.showMenu = this.$route.meta.showHeaderMenu;
            }
            if (this.$route.meta.showHeaderLogout !== undefined) {
                this.showLogout = this.$route.meta.showHeaderLogout;
            }
        }

    };
</script>

<style module>
    @import 'utils.css';
    .container {
        width: 100%;
    }
    .app {
        background-color: #fff;
    }
</style>
