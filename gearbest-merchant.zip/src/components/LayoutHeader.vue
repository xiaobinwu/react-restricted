<template>
    <header :class="$style.container">
        <Layout-header-main/>
        <layout-header-nav/>
    </header>
</template>

<script>
    export default {
        name: 'LayoutHeader'
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-white);
    }
    .container [class^="LayoutHeaderMain_container--"] {
        border: none;
    }
</style>
