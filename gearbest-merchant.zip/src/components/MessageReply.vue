<template>
    <div :class="$style.container">
        <p :class="$style.title">
            {{ $t('base.MessageReply.sendTo') }}：
            <span :class="$style.titleName">{{ nikeName }}</span>
        </p>
        <div :class="$style.textareaBox">
            <el-input
                v-model="textarea"
                :rows="rows"
                :maxlength="maxlength"
                resize="none"
                type="textarea"
                @focus="isShowGoodsInfo = isShowGoodsInfo === 0 ? 1 : isShowGoodsInfo">
            </el-input>
            <!-- 特殊展示商品信息 -->
            <div
                v-if="extraData && (extraData.groupType === 1 || extraData.groupType === 2)"
                v-show="isShowGoodsInfo === 1"
                :class="$style.textareaTip">
                <img
                    v-if="extraData.groupType == 1"
                    :class="$style.textareaTipImg"
                    :src="extraData.goodsInfo.image"
                    :alt="extraData.goodsInfo.image">
                <div :class="$style.textareaTipCon">
                    <p :class="$style.textareaTipTitle">{{ extraData.title }}</p>
                    <p :class="$style.textareaTipTxt">
                        <span
                            v-if="extraData.groupType == 2"
                            :class="$style.textareaTipTxtBlack">
                            {{ $t('base.MessageReply.orderNumber') }}:&nbsp;
                        </span>
                        <a
                            v-if="extraData.groupType == 1"
                            :href="extraData.goodsInfo.url"
                            target="_blank">
                            {{ extraData.goodsInfo.title }}
                        </a>
                        <a
                            v-else-if="extraData.groupType == 2"
                            :href="extraData.groupValue">
                            {{ extraData.groupValue }}
                        </a>
                    </p>
                </div>
                <i :class="['el-icon-close', $style.textareaTipClose ]" @click="isShowGoodsInfo = 2"></i>
            </div>
        </div>
        <el-row :class="$style.option">
            <el-col :span="2">{{ $t('base.MessageReply.uploadPictures') }}：</el-col>
            <el-col :span="3">
                <el-upload
                    ref="upload"
                    :action="actionUrl"
                    :auto-upload="false"
                    :accept="accept.type"
                    :limit="fileLimit"
                    :on-change="onChange"
                    :on-remove="onRemove"
                    :on-exceed="onExceed"
                    :on-success="onSuccess"
                    :on-error="onError"
                    :data="fileData"
                    :name="name"
                    list-type="picture">
                    <el-button>{{ $t('base.MessageReply.selectFile') }}</el-button>
                </el-upload>
            </el-col>
            <el-col :span="15" :class="$style.empt">
                <span v-show="fileNum <= 0">{{ $t('base.MessageReply.noSelectFiles') }}</span>
            </el-col>
            <el-col :span="4" align="right">
                <el-button type="primary" @click="sendReply">{{ $t('base.MessageReply.send') }}</el-button>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    import { UPLOAD_REVIEW_IMG } from '@/assets/js/constant/env.js';

    export default {
        name: 'MessageReply',
        props: {
            nikeName: { // 对方昵称
                type: [String, Number],
                default: '',
            },
            extraData: { // 特殊展示信息
                type: Object,
                default() { // 格式要求同 MessageLog 组件注释部分
                    return null;
                }
            },
            rows: { // textarea 高度
                type: Number,
                default: 6
            },
            maxlength: { // textarea 最大值
                type: Number,
                default: 500
            },
            fileLimit: { // 选择文件 最大上传个数
                type: Number,
                default: 1
            },
            actionUrl: { // 选择文件 上传地址
                type: String,
                default: UPLOAD_REVIEW_IMG
            },
            name: {
                type: String,
                default: 'files'
            },
            fileData: {
                type: Object,
                default() {
                    return { site: 'gearbest' };
                }
            },
            accept: { // 支持上传文件
                type: Object,
                default() {
                    return {
                        class: 'image',
                        type: '.jpg,.png,.jpeg,.gif'
                    };
                }
            },
            maxFilesize: {
                type: Number,
                default: 10485760 // 10 M
            }
        },
        data() {
            return {
                isShowGoodsInfo: 0, // 是否展示商品信息
                textarea: '', // textarea 输入值
                fileNum: 0, // 当前待上传文件数量
                responseFile: [],
            };
        },
        computed: {
            fileOk() {
                let statusSign = 0;
                this.$refs.upload.uploadFiles.forEach((element) => {
                    if (element.status === 'success') statusSign += 1;
                });
                return statusSign >= this.$refs.upload.uploadFiles.length;
            }
        },
        watch: {
            responseFile: {
                handler() {
                    if (this.fileOk) this.emitReqly();
                },
                deep: true
            }
        },
        methods: {
            onExceed(e) { // 超出文件上传个数'
                const vm = this;
                vm.$message({
                    type: 'error',
                    message: vm.$t('base.MessageReply.overstepLimit')
                });
            },
            onChange(change) {
                const vm = this;
                let sign = 0;
                // 文件类型校验
                const chagneFileType = change.raw.type;
                const classArr = vm.accept.class.split(',');
                if (!sign && !classArr.some(item => chagneFileType.indexOf(item) >= 0)) sign = 1;
                // 文件大小限制
                if (!sign && change.size > vm.maxFilesize) sign = 2;
                if (sign) {
                    vm.$refs.upload.uploadFiles.pop();
                    vm.$message({
                        type: 'error',
                        message: sign === 1 ? vm.$t('base.MessageReply.fileFormatError') : vm.$t('base.MessageReply.overstepFileSize')
                    });
                }
                vm.fileNum = vm.$refs.upload.uploadFiles.length;
            },
            onRemove() {
                const vm = this;
                vm.fileNum = vm.$refs.upload.uploadFiles.length;
            },
            onSuccess(response) {
                this.responseFile.push(response.file);
            },
            onError(error) {
                this.error(error.type);
            },
            sendReply() {
                const vm = this;
                if (vm.$refs.upload.uploadFiles.length) { // 当前是否有选择图片
                    if (vm.fileOk) {
                        vm.emitReqly();
                    } else {
                        vm.$refs.upload.submit();
                    }
                } else if (vm.textarea) {
                    vm.emitReqly(1);
                } else {
                    vm.$message.error('请输入回复内容');
                }
            },
            emitReqly(type) {
                const vm = this;
                const sendData = {
                    isNew: vm.isShowGoodsInfo !== 1,
                    textarea: vm.textarea,
                    extraData: vm.extraData
                };
                if (type !== 1) { // 只发送文本
                    sendData.files = vm.responseFile;
                }
                vm.$emit('sendMSG', sendData, vm.success, vm.error);
            },
            success(msg) {
                this.$message({
                    type: 'success',
                    message: msg
                });
                this.textarea = '';
                this.$refs.upload.clearFiles();
                this.fileNum = 0;
            },
            error(msg) {
                this.$message({
                    type: 'error',
                    message: msg
                });
            },
        }
    };
</script>

<style module>
    .container {
        background: #fff;
        padding: 20px 20px 30px;
    }

    .title {
        margin-bottom: 10px;
        line-height: 30px;
        font-size: 14px;
        font-weight: 500;
        color: #666;
        line-height: 20px;
    }

    .titleName {
        color: #000;
    }

    .textareaBox {
        position: relative;
        margin-bottom: 22px;
    }

    .textareaTip {
        position: absolute;
        left: 1px;
        right: 1px;
        bottom: 1px;
        padding: 10px 20px;
        background:#F4F4F4;
        border-radius:0px 0px 3px 3px;
        font-size: 0;
    }

    .textareaTipImg {
        display: inline-block;
        vertical-align: top;
        width: 40px;
        height: 40px;
        margin-right: 10px;
        background: #D8D8D8;
    }

    .textareaTipCon {
        display: inline-block;
        vertical-align: top;
    }

    .textareaTipTitle,
    .textareaTipTxt {
        line-height: 20px;
        font-size: 14px;
        width: 820px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        color: #666666;
    }

    .textareaTipTxt {
        display: block;
        color: #398EFF;
    }

    .textareaTipTxtBlack {
        color: #000;
    }

    .textareaTipClose {
        position: absolute;
        right: 10px;
        top: 10px;
        font-size: 15px;
        cursor: pointer;
    }

    .empt {
        min-height: 1px;
    }

    .option {
        line-height: 40px;
        font-size: 14px;
        color: #666;
    }
</style>
