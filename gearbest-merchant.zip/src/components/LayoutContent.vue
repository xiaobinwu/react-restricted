<template>
    <main :class="[$style.container, classes]">
        <div v-if="$slots.sidebar" :class="$style.sidebar">
            <slot name="sidebar"></slot>
        </div>
        <section :class="$style.content">
            <slot></slot>
        </section>
    </main>
</template>

<script>
    export default {
        name: 'LayoutContent',
        computed: {
            classes() {
                const classes = [];
                if (this.$slots.sidebar) {
                    classes.push(this.$style.showSidebar);
                }
                return classes;
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        display: flex;
        width: var(--layout-safe-width);
        margin: 0 auto;
        padding-top: 20px;
    }
    .container.showSidebar .content {
        flex: 1;
        width: var(--layout-content-width);
    }
    .sidebar {
        width: var(--layout-side-width);
        min-height: 800px;
        margin-right: var(--layout-gutter-width);
        background-color: #fff;
    }
</style>
