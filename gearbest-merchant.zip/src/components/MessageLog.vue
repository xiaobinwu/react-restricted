<template>
    <div :class="$style.container">
        <el-row :class="$style.top">
            <el-col :span="20">
                <b>{{ $t('base.messageLog.msglog') }}</b>
            </el-col>
            <el-col :span="4" align="right">
                <el-button
                    v-if="showDelete"
                    @click="deletLog">
                    {{ $t('base.messageLog.delete') }}
                </el-button>
            </el-col>
        </el-row>
        <div :class="$style.content">
            <p
                v-if="listData.length <= 0"
                :class="$style.nothingData">{{ $t('base.messageLog.nodata') }}</p>
            <div v-for="(msgItem, msgIndex) in listData" :key="msgIndex">
                <!-- 分组头部展示 -->
                <el-row
                    v-if="showGroup && (msgItem.groupType == 1 || msgItem.groupType == 2) &&
                        (!listData[msgIndex - 1] || msgItem.groupType != listData[msgIndex - 1].groupType ||
                    msgItem.groupValue != listData[msgIndex - 1].groupValue)"
                    :class="$style.row">
                    <el-col :span="3" :class="$style.emp"></el-col>
                    <el-col :span="18">
                        <div :class="$style.groupTop">
                            <div :class="$style.groupConten">
                                <img
                                    v-if="msgItem.groupType == 1"
                                    :class="$style.groupImg"
                                    :src="msgItem.goodsInfo.image"
                                    :alt="msgItem.goodsInfo.image">
                                <div :class="$style.groupInfo">
                                    <p v-if="msgItem.groupType == 1" :class="$style.groupTitle">{{ $t('message.aboutProduct') }}</p>
                                    <p v-if="msgItem.groupType == 2" :class="$style.groupTitle">{{ $t('message.aboutOrder') }}</p>
                                    <p :class="$style.groupTxt">
                                        <span
                                            v-if="msgItem.groupType == 2">
                                            {{ $t('base.messageLog.orderNumber') }}:&nbsp;
                                        </span>
                                        <a
                                            v-if="msgItem.groupType == 1"
                                            :href="msgItem.goodsInfo.url"
                                            target="_blank">
                                            {{ msgItem.goodsInfo.title }}
                                        </a>
                                        <a
                                            v-else-if="msgItem.groupType == 2"
                                            href="javascript:;"
                                            @click="$router.gbPush(`/order/details/${msgItem.groupValue}`)">
                                            {{ msgItem.groupValue }}
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </el-col>
                    <el-col :span="3"></el-col>
                </el-row>
                <!-- 聊天内容 对方 / 自己-->
                <el-row v-if="msgItem.primary == 2" :class="$style.row">
                    <el-col :span="3" :class="$style.logTitle" align="right">
                        <h5 :class="$style.logName" :title="msgItem.nickname" align="left">{{ msgItem.nickname }}</h5>
                        <p :class="$style.logTime" align="left">{{ timeShow(msgItem.time) }}</p>
                    </el-col>
                    <el-col :span="18" :class="$style.logContent" align="left">
                        <div :class="[$style.logContentTxt, $style.buyer]">
                            <span v-if="msgItem.contentType == 1">{{ msgItem.content }}</span>
                            <img v-else-if="msgItem.contentType == 2" :class="$style.logContentImg" :src="msgItem.content" :alt="msgItem.content">
                        </div>
                    </el-col>
                    <el-col :span="3" :class="$style.emp"></el-col>
                </el-row>
                <el-row v-if="msgItem.primary == 1" :class="$style.row">
                    <el-col :span="3" :class="$style.emp"></el-col>
                    <el-col :span="18" :class="$style.logContent" align="right">
                        <div :class="[$style.logContentTxt, $style.seller]">
                            <span v-if="msgItem.contentType == 1">{{ msgItem.content }}</span>
                            <img v-else-if="msgItem.contentType == 2" :class="$style.logContentImg" :src="msgItem.content" :alt="msgItem.content">
                        </div>
                    </el-col>
                    <el-col :span="3" :class="$style.logTitle" align="left">
                        <h5 :class="$style.logName" :title="msgItem.nickname">{{ msgItem.nickname }}</h5>
                        <p :class="$style.logTime">{{ timeShow(msgItem.time) }}</p>
                    </el-col>
                </el-row>
                <!-- 分组底部分割线 -->
                <el-row
                    v-if="listData[msgIndex + 1] &&
                    (msgItem.groupType != listData[msgIndex + 1].groupType || msgItem.groupValue != listData[msgIndex + 1].groupValue)"
                    :class="$style.row">
                    <el-col :span="3" :class="$style.emp"></el-col>
                    <el-col :span="18" :class="$style.groupEnd">
                        <p :class="$style.groupHr"></p>
                        <span :class="$style.groupEndIcon">
                            <i class="el-icon-star-off"></i>
                        </span>
                    </el-col>
                    <el-col :span="3"></el-col>
                </el-row>
            </div>
        </div>
        <el-pagination
            :class="$style.pagination"
            :total="total"
            :current-page="currentPage"
            :page-size="pageSize"
            :page-sizes="pageSizes"
            layout="total, sizes, prev, pager, next, jumper"
            align="right"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange">
        </el-pagination>
    </div>
</template>

<script>
    import { dateFormat } from '@/assets/js/utils/date';

    export default {
        name: 'MessageLog',
        props: {
            listData: { // 消息记录数据
                type: Array,
                default() {
                    return [
                        // {
                        //     time: 0, // 时间
                        //     primary: 1, // 主次关系 1:主 2:客
                        //     nickname: '', // 1(我) 2:(nickname) 其他时 可以为数组 同时配合 primary 字段使用
                        //     contentType: 1, // 消息类型 1:文本; 2:图片
                        //     content: '', // 消息内容 默认展示文本 图片时为图片链接
                        //     title: '', // 标题信息
                        //     groupType: 1, // 聚合类型 1:商品 2:订单 3:店铺
                        //     groupValue: '', // 聚合信息 type = 1(spu) || 2(order number) || 3(shop code)
                        //     goodsInfo: { // 聚合类型为 1 时 存在
                        //         sku: '',
                        //         url: '',
                        //         image: '',
                        //         title: '',
                        //     }
                        // }
                    ];
                }
            },
            showGroup: {
                type: Boolean,
                default: true
            },
            showDelete: {
                type: Boolean,
                default: true
            },
            total: { // 总数条数
                type: [Number, String],
                default: 1
            },
            currentPage: { // 当前页
                type: [Number, String],
                default: 1
            },
            pageSize: { // 每页长度
                type: [Number, String],
                default: 10
            },
            pageSizes: { // 长度切换数组
                type: Array,
                default() {
                    return [10, 20, 30];
                },
            },
        },
        methods: {
            timeShow(timeStamp) {
                return dateFormat(timeStamp);
            },
            deletLog() {
                const vm = this;
                vm.$confirm(vm.$t('base.messageLog.deletTip'), '', {
                    confirmButtonText: vm.$t('base.messageLog.confirm'),
                    cancelButtonText: vm.$t('base.messageLog.cancel'),
                    type: 'warning'
                }).then(() => {
                    vm.$emit('deletLog');
                }).catch(() => {
                    // console.log('已取消');
                });
            },
            handleSizeChange(val) {
                this.emitParent({ pageSize: val });
            },
            handleCurrentChange(val) {
                this.emitParent({ currentPage: val });
            },
            emitParent(change) { // 将参数写入路由
                const vm = this;
                const urlQuery = vm.$route.query || {};
                const queryData = {};
                if (change.pageSize && change.pageSize !== 10) queryData.pageSize = change.pageSize;
                if (change.currentPage && change.currentPage !== 1) queryData.currentPage = change.currentPage;
                // 保持路由中另外一个值
                if (change.pageSize && urlQuery.currentPage) queryData.currentPage = urlQuery.currentPage;
                if (change.currentPage && urlQuery.pageSize) queryData.pageSize = urlQuery.pageSize;
                vm.$emit('setRoute', queryData);
            },
        }
    };
</script>

<style module>
    .container {
        background: #fff;
        padding: 20px 20px 30px;
    }

    .top {
        padding-bottom: 15px;
        border-bottom: 1px solid #DDDDDD;
        line-height: 40px;
        font-size: 18px;
        color: #000;
    }

    .pagination {
        padding-top: 15px;
        border-top: 1px solid #DDDDDD;
    }

    .content {
        padding: 30px;
        min-height: 20px;
    }

    .nothingData {
        text-align: center;
        color: #999;
    }

    /* 聊天内容 */
    .row {
        margin-bottom: 30px;
        font-size: 0;
    }

    .emp {
        height: 20px;
    }

    .logTitle {
        padding: 8px 0;
    }

    .logName {
        height: 20px;
        line-height: 20px;
        font-size: 14px;
        color: #000;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        cursor: pointer;
    }

    .logTime {
        height: 18px;
        line-height: 18px;
        font-size: 12px;
        color: #999;
    }

    .logContent {
        padding: 0 18px;
    }

    .logContentTxt {
        position: relative;
        display: inline-block;
        padding: 8px 24px;
        line-height:24px;
        font-size: 14px;
        border-radius: 4px;
        color: #000;
        text-align: left;
        word-break: break-all;
    }

    .logContentImg {
        max-width: 100%;
        max-height: 140px;
        cursor: pointer;
    }

    .buyer {
        background: #F4F4F4;
    }

    .buyer:before {
        content: '';
        position: absolute;
        left: -10px;
        top: 20px;
        width: 0;
        height: 0;
        border-left: 0;
        border-top: 5px solid  transparent;
        border-bottom: 5px solid transparent;
        border-right: 10px solid #F4F4F4;
    }

    .seller {
        background: #EAF4FE;
    }

    .seller:before {
        content: '';
        position: absolute;
        right: -10px;
        top: 20px;
        width: 0;
        height: 0;
        border-right: 0;
        border-top: 8px solid  transparent;
        border-bottom: 6px solid transparent;
        border-left: 10px solid #EAF4FE;
    }

    /* 底部分隔线 */
    .groupEnd {
        position: relative;
        padding: 5px 0;
    }

    .groupHr {
        border-top: 1px solid #F2F2F2;
    }

    .groupEndIcon {
        position: absolute;
        top: 0;
        left: 50%;
        margin-right: -12.5px;
        width: 25px;
        height: 11px;
        font-size: 12px;
        text-align: center;
        background: #fff;
        color: #ddd;
    }

    /* 头部展示内容 */
    .groupTop {
        padding: 0 150px;
        border-bottom: 1px solid #F2F2F2;
    }

    .groupConten {
        border: 1px solid #F2F2F2;
        border-bottom: 0;
        padding: 4px;
        font-size: 0;
        margin-bottom: -1px;
        background: #fff;
    }

    .groupImg {
        width:40px;
        height:40px;
        margin-right: 10px;
        background:#D8D8D8;
    }

    .groupInfo {
        display: inline-block;
        vertical-align: top;
        max-width: 300px;
        height: 40px;
    }

    .groupTitle {
        height: 20px;
        line-height: 20px;
        font-size: 12px;
        color: #999;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .groupTxt {
        height: 20px;
        line-height: 20px;
        font-size: 12px;
        color: #000;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }
</style>
