<template>
    <div :class="$style.container">
        <el-form label-position="right" label-width="120px">
            <el-form-item :label="label">
                <div :class="$style.content">
                    <category-item
                        v-for="(category, index) in categories"
                        v-model="value[index]"
                        :key="index"
                        :placeholder="$t(placeholder[index])"
                        :categories="category"
                        @select="handleCategory"
                        @update="handleCategoryUpdate">
                    </category-item>
                </div>
                <div :class="$style.selected">
                    <i :class="$style.arrow"></i>
                    <dl>
                        <dt>{{ $t('goods.add.category.selected') }}</dt>
                        <dd v-for="(item, index) in selected" :key="index">
                            {{ item ? item.name : '' }}
                            <i v-show="index !== selected.length - 1" class="icon-arrow-right"></i>
                        </dd>
                    </dl>
                </div>
            </el-form-item>
        </el-form>
        <div :class="$style.operation">
            <el-button :disabled="!completed" type="primary" @click="handleEnter">{{ $t('goods.next') }}</el-button>
        </div>
    </div>
</template>

<script>
    import { goodsCategory } from '@goods/services/goods';
    import CategoryItem from './CategoryItem';

    export default {
        name: 'Category',
        components: {
            CategoryItem
        },

        props: {
            value: {
                type: Array,
                default() {
                    return [];
                }
            },
            label: {
                type: String,
                default() {
                    return this.$t('base.category-search');
                }
            }
        },

        data() {
            return {
                categories: [
                    [],
                    [],
                    [],
                    []
                ],
                placeholder: [
                    'goods.add.category.leve1',
                    'goods.add.category.leve2',
                    'goods.add.category.leve3',
                    'goods.add.category.leve4'
                ],
                selected: [],
                completed: false
            };
        },

        beforeMount() {
            this.getGoodsCategory();
        },

        methods: {
            // 获取分类信息
            async getGoodsCategory() {
                const { data } = await goodsCategory.http();
                if (data && Array.isArray(data)) {
                    this.categories.splice(0, 1, data);
                }
            },

            // 处理分类
            handleCategory(val) {
                const index = val.level - 1;
                const next = val.level;
                const length = this.categories.length;
                const removed = length - next;

                // 下一级类目数据初始化
                if (removed) {
                    this.categories.splice(next, removed, ...Array(removed));
                    this.categories.splice(next, 1, val.children);
                }

                // 更新选择的结果
                this.selected.splice(index, length - index, val);

                this.completed = this.getSelecteState(val);

                // 当前选择的类目
                const ids = this.selected.reduce((acc, item) => {
                    acc.push(item.id);
                    return acc;
                }, []);
                this.$emit('input', ids);
            },

            handleCategoryUpdate(val) {
                const index = val.level - 1;
                const next = val.level;
                if (val.children) {
                    this.categories.splice(next, 1, val.children);
                }
                this.selected.splice(index, 1, val);
                this.completed = this.getSelecteState(val);
            },

            // 当前选择的类目没有子集认为选择完毕
            getSelecteState(category) {
                return category.isReviewed === 1 && category.isleaf === 1;
            },

            // 选择完毕
            handleEnter() {
                if (this.completed) {
                    this.$emit('completed', this.selected);
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        padding-top: 20px;
    }

    .content {
        display: flex;
    }

    .content [class^="CategoryItem_container"] {
        margin-right: 10px;
    }

    .content [class^="CategoryItem_container"]:last-child {
        margin-right: 0;
    }

    .selected {
        position: relative;
        width: 830px;
        margin-top: 20px;
        padding: 12px;
        background:#d3e6ff;
        border-radius: 4px;
        box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.06);
    }

    .selected .arrow {
        position: absolute;
        left: 30px;
        top: -8px;
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 0 8px 8px 8px;
        border-color: transparent transparent #d3e6ff transparent
    }

    .selected dl {
        display: flex;
        align-items: center;
        font-size: var(--font-size-base);
        color: var(--color-text-primary);
        line-height: 1;
    }

    .selected dt {
        white-space: nowrap
    }
    .selected dd {
        position: relative;
        margin-right: 30px;
    }

    .selected dd i {
        position: absolute;
        top: 50%;
        right: -23px;
        transform: translateY(-50%);
    }

    .operation {
        display: flex;
        justify-content: center;
        padding: 50px 0;
    }
</style>
