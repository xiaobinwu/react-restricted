<template>
    <el-dialog :visible="visible" :title="title" width="560px" @close="handleClose('form')">
        <el-form ref="form" :model="form" :rules="rules" label-width="100px">
            <el-form-item
                label="相册名称"
                prop="albumName">
                <el-input v-model.trim="form.albumName" placeholder="请输入相册名称(30字内)"></el-input>
            </el-form-item>
        </el-form>
        <div :class="$style.btnGroup">
            <el-button @click="closeDialog">取消</el-button>
            <el-button :loading="loading" type="primary" @click="handleSaveClick">确定</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import { serviceAlbumCreate, serviceAlbumUpdate } from '@picture/services/picture';

    export default {
        name: 'AlbumCreate',

        props: {
            visible: {
                type: Boolean,
                default: false
            },
            isEditor: {
                type: Boolean,
                default: false
            },
            data: {
                type: Object,
                default() {
                    return {};
                }
            }
        },

        data() {
            return {
                loading: false,
                form: {
                    albumName: ''
                },
                rules: {
                    albumName: [
                        { required: true, message: '相册名字不能为空', trigger: 'blur' },
                        { max: 30, message: '相册名字30字以内', trigger: 'blur' },
                    ]
                }
            };
        },

        computed: {
            title() {
                return this.isEditor ? '修改相册名称' : '创建相册';
            }
        },

        watch: {
            visible(val) {
                if (val) {
                    this.updateAlbumData();
                }
            }
        },

        methods: {
            closeDialog() {
                this.$emit('update:visible', false);
            },

            // 验证相册表单
            validateForm(formName) {
                return new Promise((resolve, reject) => {
                    this.$refs[formName].validate((valid) => {
                        if (valid) {
                            resolve();
                        } else {
                            reject(new Error('submit fail'));
                        }
                    });
                });
            },

            // 新建或更新相册
            albumAddOrUpdate(data) {
                return this.isEditor ? serviceAlbumUpdate.http({ data }) : serviceAlbumCreate.http({ data });
            },

            // 获取提交数据
            getData() {
                if (this.isEditor) {
                    return Object.keys(this.data).reduce((acc, key) => {
                        acc[key] = this.form[key] || this.data[key];
                        return acc;
                    }, {});
                }
                return {
                    albumName: this.form.albumName
                };

            },

            // 处理保存
            async handleAddOrUpdate() {
                this.loading = true;

                const postData = this.getData();
                const { status, data } = await this.albumAddOrUpdate(postData);

                this.loading = false;

                if (status === 0) {
                    this.closeDialog();
                    this.$emit('save', data);
                }
            },

            // 处理保存事件
            async handleSaveClick() {
                if (!this.loading) {
                    await this.validateForm('form');
                    this.handleAddOrUpdate();
                }
            },

            // 表单重置
            resetFields(formName) {
                this.$refs[formName].resetFields();
            },

            // 弹窗关闭回调
            handleClose(form) {
                this.resetFields(form);
                this.closeDialog();
            },

            updateAlbumData() {
                if (this.isEditor) {
                    const hasKey = key => Object.hasOwnProperty.call(this.form, key);
                    Object.keys(this.data).forEach((key) => {
                        if (hasKey(key)) {
                            this.form[key] = this.data[key];
                        }
                    });
                }
            }
        }
    };
</script>

<style module>
    .btnGroup {
        padding-top: 8px;
        font-size: 0;
        text-align: center;
    }

    .btnGroup button:last-of-type {
        margin-left: 20px;
    }
</style>
