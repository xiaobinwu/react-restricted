<template>
    <div :class="$style.container">
        <input :placeholder="placeholder" v-model="inputValue" :class="$style.input" type="text" @input="input">
    </div>
</template>

<script>
    export default {
        name: 'CategoryInput',

        props: {
            value: {
                type: String,
                default: ''
            },
            placeholder: {
                type: String,
                default: ''
            }
        },

        data() {
            return {
                inputValue: this.value
            };
        },

        methods: {
            input(e) {
                this.$emit('input', e.target.value);
            }
        }
    };
</script>

<style module>
    .container {
        padding-bottom: 5px;
    }

    .input {
        width: 100%;
        display: block;
    }
</style>
