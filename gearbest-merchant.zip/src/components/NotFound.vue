<template>
    <div :class="$style.container">
        <div :class="$style.content">
            <span :class="$style.tipIcon"></span>
            <p :class="$style.tipText">{{ $t('base.notFound.tip') }}</p>
            <el-button @click="toHome">{{ $t('base.button.back') }}</el-button>
            <!-- <el-button type="primary">{{ $t('base.button.refresh') }}</el-button> -->
        </div>
    </div>
</template>

<script>
    export default {
        name: 'NotFound',
        methods: {
            toHome() {
                this.$router.push({
                    name: 'indexHome'
                });
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        display: flex;
        align-items: center;
        justify-content: center;
        background:rgba(242,242,242,1);
    }
    .content {
        margin-top: 10%;
        text-align: center;
    }
    .tipIcon {
        display: block;
        width: 283px;
        height: 156px;
        margin: 0 auto;
        background: resolve('img/icon-notfound.png');
    }
    .tipText {
        padding-top: 40px;
        padding-bottom: 88px;
        font-size: 20px;
        color: var(--color-text-primary);
    }
    .content [class~="el-button"]:last-child {
        margin-left: 30px;
    }
</style>
