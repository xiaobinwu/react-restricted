<template>
    <div :class="$style.container">
        <layout-header></layout-header>
        <layout-content>
            <layout-side slot="sidebar"></layout-side>
            <breadcrumb v-show="meta.breadVisible"></breadcrumb>
            <router-view v-if="isRouterAlive"></router-view>
        </layout-content>
        <!-- <layout-footer></layout-footer> -->
    </div>
</template>

<script>
    export default {
        name: 'Layout',
        provide() {
            return {
                reload: this.reload // 向子组件注入刷新页面方法
            };
        },
        data() {
            return {
                meta: {
                    breadVisible: true
                },
                isRouterAlive: true
            };
        },
        watch: {
            $route: {
                immediate: true,
                handler(val) {
                    this.meta = Object.assign(this.meta, val.meta);
                }
            }
        },

        methods: {
            // 刷新当前页面
            reload() {
                this.isRouterAlive = false;
                this.$nextTick(() => {
                    this.isRouterAlive = true;
                });
            }
        }
    };
</script>

<style module>
    @import 'utils.css';

    .container {
        width: 100%;
    }
</style>
