<template>
    <div :class="$style.container">
        <el-cascader
            :props="props"
            :clearable="true"
            :options="categories"
            v-model="selectedOptions"
            expand-trigger="hover"
            @change="handleChange">
        </el-cascader>
    </div>
</template>

<script>
    import { goodsCategory } from '@goods/services/goods';

    export default {
        name: 'CategoryCascader',
        props: {
            categoryId: {
                type: String,
                default() {
                    return '';
                }
            }
        },
        data() {
            return {
                props: {
                    label: 'name',
                    value: 'id',
                },
                selectedOptions: [],
                categories: [],
            };
        },
        created() {
            this.getGoodsCategory();
        },
        methods: {
            // 获取分类信息
            async getGoodsCategory() {
                const { data } = await goodsCategory.http();
                if (data && Array.isArray(data)) {
                    this.categories = data;
                }
            },
            handleChange(val) {
                const categoryIds = val.length ? val.join(',') : '';
                this.$emit('updateCategory', { category_id: categoryIds });
            },
            setValue(val) {
                if (val) {
                    this.selectedOptions = val.split(',').map(item => Number(item));
                } else {
                    this.selectedOptions = [];
                }
                this.$emit('updateCategory', { category_id: val });
            }
        }
    };
</script>

<style module>

</style>
