<template>
    <div :class="$style.container">
        <div :class="$style.content">
            <div :class="$style.brand">
                <a v-if="menuLogo" href="https://www.gearbest.com/"></a>
                <a v-else href="javascript:;" @click="goHome">
                </a>
                <el-select v-model="value" placeholder="请选择语言" value="">
                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
                </el-select>
            </div>
            <ul v-if="showMenu" :class="$style.menu">
                <li v-if="showLogout" :class="[$style.menuList, $style.store]">
                    <a :class="$style.menuColor" href="/">
                        <i class="icon-store"></i>
                        {{ shopInfo.shopName }}
                    </a>
                </li>
                <!-- 店铺状态暂时隐藏 -->
                <!-- <li v-if="showLogout" :class="[$style.menuList, $style.storeStatus]">
                    {{ $t('base.header.shopState') }}：{{ accountStatus }}
                </li> -->
                <li v-if="showLogout" :class="[$style.menuList, $style.storeStatus]">
                    <a :href="gearbestUrl+'/store/'+shopInfo.shopCode+'.html'" :class="$style.menuColor">
                        {{ $t('base.menu.store.enter') }}
                    </a>
                </li>
                <li :class="[$style.menuList, $style.logout, $style.menuColor]">
                    <a href="javascript:;" @click="logout">
                        {{ $t('base.header.signOut') }}
                    </a>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
    import { mapGetters, mapMutations } from 'vuex';
    import { UPDATE_USER } from '@/assets/js/store/mutationTypes';
    import { signLogout } from '@sign/services/login';
    import { GEARBEST_URL } from '@/assets/js/constant/env.js';

    // 店铺状态多语言 key
    const shopStatusKey = [
        'base.header.shopState1',
        'base.header.shopState2',
        'base.header.shopState3',
        'base.header.shopState4',
        'base.header.shopState5'
    ];

    export default {
        name: 'LayoutHeaderMain',
        props: {
            showMenu: {
                type: Boolean,
                default: true
            },
            showLogout: {
                type: Boolean,
                default: true
            },
            menuLogo: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                value: 'zh-cn',
                options: [
                    {
                        value: 'zh-cn',
                        label: '中文简体'
                    }
                ],
                gearbestUrl: GEARBEST_URL,
            };
        },
        computed: {
            ...mapGetters(['userInfo']),
            shopInfo() {
                return this.userInfo.defaultShop || {};
            },
            accountStatus() {
                const status = this.userInfo.accountStatus;
                return this.$t(shopStatusKey[status]);
            }
        },
        methods: {
            ...mapMutations({
                updateUserInfo: UPDATE_USER
            }),
            async logout() {
                await signLogout.http();
                this.updateUserInfo({
                    userInfo: {},
                    isLogin: null,
                });
                this.$router.gbPush('/sign/login');
            },
            goHome() {
                this.$router.gbPush('/index/home');
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        padding: 21px 0;
        background-color: var(--color-white);
        border-bottom: 1px solid var(--border-color-base);
    }
    .content {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: var(--layout-safe-width);
        margin: 0 auto;
    }
    .brand {
        display: flex;
        align-items: center;
    }
    .brand a {
        display: block;
        margin-right: 77px;
        width: 154px;
        height: 25px;
        background-image: resolve('img/layout-header-logo.png');
    }
    .menu {
        display: flex;
        align-items: center;
    }
    .menuList {
        margin-right: 30px;
        color: var(--color-text-primary);
    }
    .menuList:last-child {
        margin-right: 0;
    }
    .menuList.store {
        color: var(--color-primary-darken);
    }
    .menuList.store i {
        font-size: 24px;
        vertical-align: -4px;
        color: inherit;
    }
    .menuList.storeStatus {
        color: var(--color-text-secondary);
    }
    .menuList.logout a:not(:hover) {
       color: inherit;
    }
    .menuColor{
        color: var(--color-text-primary);
    }
</style>
