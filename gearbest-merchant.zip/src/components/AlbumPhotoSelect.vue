<template>
    <div class="container">
        <el-dialog :visible="visible" :custom-class="$style.photoSelect" title="从相册选取图片" width="900px" @close="closeDialog">
            <div :class="$style.content">
                <el-scrollbar
                    :class="$style.sideBox"
                    :wrap-class="$style.scrollWrap"
                    :view-class="$style.sideContent"
                    tag="div">
                    <p :class="$style.sideName">相册</p>
                    <el-button
                        size="small"
                        width="100%"
                        @click="dialogCreateAlbum = !dialogCreateAlbum">
                        创建相册
                    </el-button>
                    <el-button
                        v-for="(album, index) in albumList"
                        :class="$style.albumBtn"
                        :key="index"
                        size="small"
                        type="primary"
                        @click="handleAlbumSelect(album)">
                        {{ album.albumName }}
                    </el-button>
                </el-scrollbar>
                <div :class="$style.main">
                    <div :class="$style.operation">
                        <div :class="$style.search">
                            <el-input v-model="params.fileName"></el-input>
                            <el-button type="primary" @click="getAlbumImages">搜索</el-button>
                        </div>
                        <album-photo-input-file @change="handleChange">
                            <el-button>本地上传</el-button>
                        </album-photo-input-file>
                    </div>
                    <el-scrollbar
                        :class="$style.phostListBox"
                        :wrap-class="$style.photoList"
                        :view-class="$style.photoListView"
                        tag="div">
                        <el-checkbox-group v-model="checkedImages" :max="limit">
                            <div v-for="image in albumImages" :class="$style.photoItem" :key="image.fileCode">
                                <img :class="$style.img" :src="image.filePath | thumb(200,200)">
                                <p :class="$style.imgName">{{ image.fileRealName }}</p>
                                <el-checkbox :disabled="image.disabled" :label="image.filePath">&nbsp;</el-checkbox>
                            </div>
                        </el-checkbox-group>
                    </el-scrollbar>
                    <div :class="$style.pagination">
                        <el-pagination
                            :total="imagesCount"
                            :current-page="params.page"
                            :page-sizes="[10, 20, 30, 50]"
                            :page-size="params.pageSize"
                            layout="total, sizes, prev, pager, next, jumper"
                            @size-change="handleSizeChange"
                            @current-change="handleCurrentChange">
                        </el-pagination>
                    </div>
                </div>
            </div>
            <div :class="$style.btnGroup">
                <el-button @click="closeDialog">取消</el-button>
                <el-button type="primary" @click="handleSave">保存</el-button>
            </div>
        </el-dialog>

        <album-create
            :visible.sync="dialogCreateAlbum"
            @save="handleAlbumCreate">
        </album-create>

        <album-photo-upload
            ref="upload"
            :lock-album="true"
            :album-code="albumCode"
            :visible.sync="dialogAlbumUpload"
            :data="data"
            :upload-tips="uploadTips"
            action="/image-manage/image-upload"
            name="uploadFile"
            @save="handlePhotoUpload">
        </album-photo-upload>
    </div>
</template>

<script>
    import { serviceAlbumList, serviceAlbumImages } from '@picture/services/picture';
    import AlbumCreate from './AlbumCreate';
    import AlbumPhotoInputFile from './album-photo-upload/AlbumPhotoInputFile';
    import AlbumPhotoUpload from './album-photo-upload/AlbumPhotoUpload';

    export default {
        name: 'AlbumPhotoSelect',
        components: {
            AlbumCreate,
            AlbumPhotoInputFile,
            AlbumPhotoUpload
        },

        filters: {
            thumb(val, width, height) {
                if (!val) return '';
                const ext = val.match(/.+\.(.+)$/)[1] || '';
                return `${val}_${width}x${height}.${ext}`;
            }
        },

        props: {
            visible: {
                type: Boolean,
                default: false
            },
            type: {
                type: Array,
                default() {
                    return ['.png', '.jpeg', '.jpg', '.bmp'];
                }
            },
            width: {
                type: Number,
                default: Number.MAX_VALUE
            },
            widthLogical: {
                type: String,
                default: '<='
            },
            heightLogical: {
                type: String,
                default: '<='
            },
            height: {
                type: Number,
                default: Number.MAX_VALUE
            },
            radio: {
                type: Array,
                default() {
                    return [];
                }
            },
            size: {
                type: Number,
                default: Number.MAX_VALUE
            },
            limit: {
                type: Number,
                default: 1
            },
            data: {
                type: Object,
                default() {
                    return {};
                }
            },
            uploadTips: {
                type: String,
                default: ''
            }
        },

        data() {
            return {
                albumList: [],
                albumImages: [],
                imagesCount: 0,
                albumCode: '',
                dialogCreateAlbum: false,
                dialogAlbumUpload: false,
                checkedImages: [],
                params: {
                    page: 1,
                    pageSize: 20,
                    fileName: '',
                }
            };
        },

        computed: {
            composeParams() {
                const { page, pageSize, fileName } = this.$route.query;
                return Object.assign({
                    page,
                    pageSize,
                    fileName,
                    albumCode: this.albumCode
                }, this.params);
            }
        },
        watch: {
            visible(val) {
                if (val) {
                    this.init();
                } else {
                    this.checkedImages = [];
                    this.onCancel();
                }
            },
            albumCode(val) {
                this.getAlbumImages();
            },
        },

        methods: {
            async init() {
                const album = await this.getAlbumList();
                if (album.length) {
                    this.albumCode = album[0].albumCode;
                }
            },

            // pageSize 改变时会触发
            handleSizeChange(pageSize) {
                this.params.pageSize = pageSize;
                this.getAlbumImages();
            },

            // currentPage 改变时会触发
            handleCurrentChange(page) {
                this.params.page = page;
                this.getAlbumImages();
            },

            // 获取相册列表
            async getAlbumList() {
                const { status, data } = await serviceAlbumList.http();
                if (status === 0) {
                    this.albumList = data;
                    return Promise.resolve(data);
                }
                return Promise.reject(data);
            },

            // 获取相册图片
            async getAlbumImages() {
                const params = this.composeParams;
                const { status, data } = await serviceAlbumImages.http({ params });
                if (status === 0) {
                    const photos = data.list || [];
                    this.albumImages = photos.map((item) => {
                        item.disabled = !this.filterValidPhoto(item);
                        return item;
                    });
                    this.imagesCount = data.count;
                }
            },

            // 处理选择相册
            handleAlbumSelect(album) {
                this.albumCode = album.albumCode;
            },

            // 根据 props 传的规则过滤图片
            filterValidPhoto(photo) {
                const size = photo.fileSize / 8 / 1024 <= this.size;
                const width = this.compareNumberBySymbol(photo.fileWidth, this.width, this.widthLogical);
                const height = this.compareNumberBySymbol(photo.fileHeight, this.height, this.heightLogical);
                const type = this.type.includes(photo.fileExt);

                let radio = true;
                if (this.radio.length) {
                    const [start, end] = this.radio;
                    radio = height / width >= start && height / width <= end;
                }
                return size && width && height && type && radio;
            },

            compareNumberBySymbol(n1, n2, symbol) {
                switch (symbol) {
                case '===':
                    return n1 === n2;
                case '>=':
                    return n1 >= n2;
                case '<=':
                    return n1 <= n2;
                case '>':
                    return n1 > n2;
                default:
                    return n1 < n2;
                }
            },

            // 处理文件上传事件
            handleChange(files) {
                this.dialogAlbumUpload = true;
                this.$refs.upload.addFile(files);
            },

            // 选择完成
            handleSave() {
                if (!this.checkedImages.length) {
                    this.$message.error('未选择任何图片');
                } else {
                    this.onSave(this.checkedImages);
                }
            },

            // 关闭弹窗
            closeDialog() {
                this.$emit('update:visible', false);
            },

            // 派发保存事件
            onSave(data) {
                this.$emit('save', data);
                this.closeDialog();
            },

            // 派发取消事件
            onCancel(data) {
                this.$emit('cancel', data);
                this.closeDialog();
            },

            // 创建相册
            handleAlbumCreate(album) {
                this.getAlbumList();
                this.albumCode = album.albumCode;
            },

            // 照片上传完毕保存
            handlePhotoUpload() {
                this.getAlbumImages();
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .content {
    }

    .photoSelect [class~="el-dialog__body"] {
        padding-top: 0;
    }

    .sideBox {
        float: left;
        width: 172px;
        border-radius:4px;
    }

    .sideName {
        font-size: var(--font-size-base);
        color: var(--color-text-primary);
        padding-bottom: 14px;
    }

    .scrollWrap {
        flex-shrink: 0;
        min-width: 140px;
        height: 362px;
        background:rgba(242,242,242,1);
        overflow-y: scroll;
    }

    .sideContent {
        display: flex;
        flex-direction: column;
        padding: 20px 34px 20px 15px;
    }

    .albumBtn {
        width: 124px;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }

    .sideContent [class~="el-button"] {
        margin-left: 0;
        margin-bottom: 20px;
    }

    .main {
        margin-left: 180px;
    }

    .operation {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .search {
        display: flex;
    }

    .phostListBox {
        border: var(--border-base-style);
    }

    .photoListView {
        padding: 20px;
    }
    .pagination {
        text-align: right;
        margin-top: 14px;
    }

    .photoList {
        height: 311px;
        overflow-y: auto;
        @mixin clearfix;
    }

    .photoItem {
        float: left;
        width: 80px;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-right: 30px;
        margin-bottom: 30px;
    }

    .photoItem:nth-of-type(6n) {
        margin-right: 0;
    }

    .photoItem .img {
        width: 80px;
        height: 80px;
    }

    .imgName {
        width: 80px;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        padding: 10px 0 6px 0;
        font-size: 12px;
        text-align: center;
        color: (--color-text-primary);
    }

    .btnGroup {
        margin-top: 30px;
        font-size: 0;
        text-align: center;
    }

    .btnGroup button:last-of-type {
        margin-left: 20px;
    }

</style>
