<template>
    <div :class="$style.container">
        <div v-show="model === 'bread'" :class="$style.bread">
            <span :class="$style.breadTip">{{ $t('base.bread.location') }}：</span>
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>{{ $t('base.nav.home') }}</el-breadcrumb-item>
                <el-breadcrumb-item v-for="item in list" :key="item.path">{{ $t(item.title) }}</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div v-show="model ==='back'" :class="$style.goBack">
            <a @click="goBack">
                <i class="icon-arrow-down"></i>
                {{ $t('base.button.back') }}
            </a>
            <span :class="$style.goBackName">{{ $t(goBackName) }}</span>
        </div>

    </div>
</template>

<script>
    import config from '@/assets/js/menu';
    import { deepCopy } from '@/assets/js/utils/types';

    export default {
        name: 'Breadcrumb',
        data() {
            return {
                pages: '',
                path: '',
                configMap: null,
                list: [],
                focusMenu: '',
                goBackName: '',
                model: 'bread'
            };
        },
        watch: {
            $route: {
                immediate: true,
                handler(val) {
                    const matched = [...val.matched].pop();
                    if (!matched) return;
                    this.$nextTick(() => {
                        this.pages = matched.path.split('/')[1];
                        const { focusMenu, title } = matched.meta;
                        this.focusMenu = focusMenu;
                        this.goBackName = title;
                        this.path = matched.path;
                    });
                }
            },
            pages(val) {
                const pagesConfig = config.find(item => item.module === val);
                if (!pagesConfig) return;
                this.configMap = this.configFlatten([deepCopy(pagesConfig)]);
            },
            path(val) {
                // 路径在菜单配置里面
                // 自动生成面包屑路径
                if (this.configMap && this.configMap[val]) {
                    this.list = this.genBreadcrumb(val);
                    this.model = 'bread';
                }
                // 不在菜单栏配置的路径
                // 配置了 focusMenu 参数
                // 展示返回按钮形式的面包屑
                if (this.configMap && !this.configMap[val] && this.focusMenu) {
                    const menuPath = this.configMap[this.focusMenu];
                    if (!menuPath) {
                        console.warn('Breadcrumb: Route configuration parameters are invalid ', this.focusMenu);
                    } else {
                        this.model = 'back';
                    }
                }
            }
        },
        methods: {
            configFlatten(menu) {
                const values = {};
                let index = 0;

                flattenTree(menu);
                function flattenTree(node, parent) {
                    node.forEach((item) => {
                        index += 1;
                        item.path = item.path || index;
                        item.parent = parent && parent.path;
                        values[item.path] = item;
                        if (item.submenu) flattenTree(item.submenu, item);

                        delete item.submenu;
                    });
                }

                return values;
            },
            genBreadcrumb(pathname) {
                if (!this.configMap[pathname]) return [];

                const res = [];
                let temp = pathname;
                while (temp) {
                    const menu = this.configMap[temp];
                    res.unshift({
                        path: typeof menu.path !== 'number' ? menu.path : null,
                        title: menu.title
                    });
                    temp = menu.parent;
                }

                return res;
            },
            goBack() {
                const { redirectUrl } = this.$route.query;
                if (redirectUrl) {
                    window.location.href = redirectUrl;
                } else {
                    this.$router.back();
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        padding: 20px 0 20px 20px;
        color: var(--color-text-regular);
        font-size: var(--font-size-largest);
        @mixin clearfix;

    }
    .breadTip {
        float: left;
        color: var(--color-black);
    }
    .goBack {
    }
    .goBack [class^="icon"] {
        display: inline-block;
        color: inherit;
        font-size: 18px;
        font-weight: bold;
        transform: rotate(90deg);
    }
    .goBackName {
        display: inline-block;
        margin-left: 10px;
    }
</style>
