<template>
    <div :class="$style.container">
        <category-input v-model="search" :placeholder="placeholder"/>
        <el-scrollbar :class="$style.list" :wrap-class="$style.listWarp" :view-class="$style.listInner" tag="ul">
            <category-option
                v-for="category in searched"
                :key="category.id"
                :on="value === category.id"
                :value="value"
                :option="category"
                :light="!(category.isReviewed === 1 && category.status === 1)"
                @select="handleOptionSelect"
                @update="handleOptionUpdate">
            </category-option>
        </el-scrollbar>
    </div>
</template>

<script>
    import CategoryInput from './CategoryInput';
    import CategoryOption from './CategoryOption';

    export default {
        name: 'CategoryItem',
        components: {
            CategoryInput,
            CategoryOption
        },

        props: {
            categories: {
                type: Array,
                default() {
                    return [];
                }
            },
            placeholder: {
                type: String,
                default: ''
            },
            value: {
                type: [Number, String],
                default: ''
            }
        },

        data() {
            return {
                search: ''
            };
        },

        computed: {
            searched() {
                return this.categories.filter(item => item.name.includes(this.search));
            }
        },

        methods: {
            handleOptionSelect(val) {
                this.$emit('select', val);
            },
            handleOptionUpdate(val) {
                this.$emit('update', val);
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        width: 200px;
        background-color: #fff;
    }

    .container [class~=".el-scrollbar"] {
        border-radius: var(--border-radius);
    }

    .list {
        border: var(--border-base-style);
        border-radius: var(--border-radius);
    }

    .listWarp {
        min-width: 200px;
        height: 250px;
        overflow: scroll;
    }

    .listInner {
        padding: 9px 0;
    }
</style>
