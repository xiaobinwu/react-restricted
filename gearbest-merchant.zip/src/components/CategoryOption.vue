<template>
    <li :class="[$style.item, classes]" @click="handleClick">
        {{ option.name }}
    </li>
</template>

<script>
    export default {
        name: 'CategoryOption',

        props: {
            option: {
                type: Object,
                default() {
                    return {};
                }
            },
            light: {
                type: Boolean,
                default: false
            },
            on: {
                type: Boolean,
                default: false
            },
            value: {
                type: [Number, String],
                default: ''
            }
        },

        computed: {
            classes() {
                const classNames = [];
                if (this.light) {
                    classNames.push(this.$style.light);
                }
                if (this.on) {
                    classNames.push(this.$style.selected);
                }
                return classNames;
            }
        },

        mounted() {
            // 首次渲染的时候 - 传入了之前选择值
            if (this.on
                && this.option.id === this.value
            ) {
                this.$emit('update', this.option);
            }
        },

        methods: {
            // 处理 option 点击
            handleClick() {
                this.$emit('select', this.option);
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .item {
        width: 100%;
        padding: 0 10px;
        height: 20px;
        line-height: 20px;
        color: var(--color-text-primary);
        font-size: var(--font-size-base);
        transition: background var(--animation-transition-time) var(--animation-transition-timing);
        cursor: pointer;
        white-space: nowrap;
    }

    .item:hover {
        color: var(--color-primary-darken);
    }

    .light {
        color: var(--color-text-secondary);
    }

    .selected {
        color: var(--color-primary-darken);
    }
</style>
