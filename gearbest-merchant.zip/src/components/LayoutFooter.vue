<template>
    <footer :class="$style.container">我是底部</footer>
</template>

<script>
    export default {
        name: 'LayoutFooter'
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        text-align: center;
    }
</style>
