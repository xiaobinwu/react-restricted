<template>
    <div :class="$style.steps">
        <div v-for="item in stepsList" :key="item.title" :class="item.className" :style="item.style">{{ item.title }}</div>
    </div>
</template>

<script>
    /**
     * 进度条
     */
    export default {
        name: 'ProgressBar',
        props: {
            active: {
                type: Number,
                default: 0
            },
            steps: {
                type: Array,
                default() {
                    return [];
                }
            }
        },

        computed: {
            stepsList() {
                return this.steps.map((item, index) => ({
                    title: item,
                    className: index === this.active ? this.$style.stepItemActived : this.$style.stepItem,
                    style: {
                        width: `${(100 / this.steps.length).toFixed(4)}%`
                    }
                }));
            },
        }
    };
</script>

<style module>
    @import "variable.css";
    @import 'utils.css';

    .steps {
        height: 30px;
        margin-bottom: 16px;
        @mixin clearfix;
    }

    .stepItem,
    .stepItemActived {
        position: relative;
        float: left;
        height: 30px;
        border-right: 4px solid #fff;
        line-height: 30px;
        font-size: 18px;
        text-align: center;
        background-color: #E9F1FE;
        color: #2774FF;

        &:before,
        &:after {
            content: '';
            position: absolute;
            top: 0;
            right: -10px;
            width: 0;
            height: 0;
            border-width: 15px 0 15px 10px;
            border-style: solid;
            border-color: transparent;
            border-left-color: #E9F1FE;
            z-index: 1;
        }

        &:before {
            right: -14px;
            border-left-color: #fff;
        }

        &:last-of-type {
            border-right: 0;

            &:before,
            &:after {
                display: none;
            }
        }
    }

    .stepItemActived {
        background-color: #61A5FF;
        color: #fff;

        &:after {
            border-left-color: #61A5FF;
        }

        & ~ .stepItem {
            background-color: #eee;
            color: #999;

            &:after {
                border-left-color: #eee;
            }
        }
    }
</style>
