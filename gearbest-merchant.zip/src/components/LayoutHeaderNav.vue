<template>
    <div :class="$style.container">
        <ul :class="$style.list">
            <li :class="[$style.item, $style.on]"><a href="javascript:;" @click="goToIndex">{{ $t('base.nav.home') }}</a></li>
        </ul>
    </div>
</template>

<script>
    export default {
        name: 'LayoutHeaderNav',
        methods: {
            goToIndex() {
                this.$router.gbPush('/index/home');
            }
        }
    };
</script>

<style module>
    @import 'variable.css';

    .container {
        background-color: var(--color-primary);
    }
   .list {
        display: flex;
        width: var(--layout-safe-width);
        margin: 0 auto;
   }
    .item {
        width: 200px;
        margin-right: 20px;
        font-size: var(--font-size-largest);
        color: var(--color-white);
        text-align: center;
        padding: 15px 0;
    }
    .item.on {
        background-color: var(--color-primary-darken);
    }
    .item a {
        color: inherit;
    }
</style>
