<template>
    <el-menu :default-active="active" @select="handleSelect">
        <el-submenu v-for="first in config" :key="first.title" :index="first.title">
            <template slot="title">
                <span :class="$style.title">{{ $t(first.title) }}</span>
            </template>
            <template v-for="second in first.submenu">
                <el-menu-item v-if="!second.submenu" :index="second.path" :key="second.title">{{ $t(second.title) }}</el-menu-item>
                <el-submenu v-else :index="second.title" :key="second.title">
                    <template slot="title">{{ $t(second.title) }}</template>
                    <el-menu-item v-for="third in second.submenu" :index="third.path" :key="third.path">{{ $t(third.title) }}</el-menu-item>
                </el-submenu>
            </template>
        </el-submenu>
    </el-menu>
</template>

<script>
    import { mapGetters } from 'vuex';
    import config from '@/assets/js/menu';

    export default {
        name: 'LayoutSide',
        data() {
            return {
                active: ''
            };
        },
        computed: {
            ...mapGetters(['userInfo']),
            defaultShop() {
                return this.userInfo.defaultShop || '';
            },
            config() {
                // 直发模式的店铺不展示 FBG 模块
                // 临时处理
                const direct = this.defaultShop.deliverModeList || '';
                if (direct.length === 1 && direct[0] === 1) {
                    return config.filter(item => item.module !== 'fbg');
                }
                return config;
            }
        },
        watch: {
            $route: {
                immediate: true,
                handler(val) {
                    const matched = [...val.matched].pop();
                    if (!matched) {
                        this.active = '';
                    } else {
                        const { focusMenu } = matched.meta;
                        this.active = focusMenu || matched.path;
                    }
                }
            }
        },
        methods: {
            // 跳转
            handleSelect(path) {
                this.$router.gbPush(path);
            },
        },

    };
</script>

<style module>
    @import 'variable.css';

    .container {
        height: 1130px;
        background-color: var(--color-white);
        border-radius: 4px;
    }
    .title {
        font-size: var(--font-size-largest);
    }
</style>
