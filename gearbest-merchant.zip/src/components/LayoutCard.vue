<template>
    <div :class="$style.container">
        <div v-if="visibleHead" :class="$style.header" @click="onCollapse">
            <span v-if="name" :class="$style.title">{{ name }}</span>
            <a v-if="more" :class="$style.more" @click="onMore">{{ $t('base.layoutcard.more') }}</a>
            <i v-show="collapsible" :class="['icon-arrow-down', classes]"></i>
        </div>
        <el-collapse-transition>
            <div v-show="!collapse" :class="$style.content">
                <slot></slot>
            </div>
        </el-collapse-transition>
    </div>
</template>

<script>
    /**
     * 布局卡片组件
     * props
     * @param {string}  name              标题
     * @param {boolean} more              更多按钮
     * @param {boolean} collapsible       能否折叠
     * @param {boolean}  collapse         折叠状态
     *
     * events
     * @name more(e)                      触发更多
     * @name collapse(collapse)           触发折叠
     */
    export default {
        name: 'LayoutCard',
        props: {
            name: {
                type: String,
                default: ''
            },
            more: {
                type: Boolean,
                default: false
            },
            collapsible: {
                type: Boolean,
                default: false,
            },
            collapse: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            visibleHead() {
                return this.name || this.more || this.collapsible;
            },
            classes() {
                const classNames = [];
                if (this.collapse) {
                    classNames.push(this.$style.collapsed);
                }
                return classNames;
            }
        },
        methods: {
            onMore(e) {
                this.$emit('more', e);
            },
            onCollapse(e) {
                if (this.collapsible) {
                    this.$emit('collapse', !this.collapsed);
                }
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .container {
        background-color: var(--color-white);
        border-radius: 4px;
    }
    .header {
        padding: 16px 20px 16px 25px;
        background-color: #fafafa;
        @mixin clearfix;
    }
    .title {
        position: relative;
        padding-left: 15px;
        font-size: var(--font-size-largest);
        color: var(--color-text-primary);
    }
    .title:before {
        position: absolute;
        top: 50%;
        left: 0;
        width: 5px;
        height: 16px;
        margin-top: -8px;
        background: var(--color-primary-darken);
        border-radius: 3px;
        content: "";
    }
    .more {
        line-height: 18px;
        float: right;
    }
    .header [class~="icon-arrow-down"] {
        float: right;
        transition: transform var(--animation-transition-time) var(--animation-transition-timing);
    }
    .collapsed {
        transform: rotate(-90deg);
    }
    .content {
        background-color: #fff;
    }
</style>
