<template>
    <div :class="$style.input" @click="handleClick">
        <slot></slot>
        <input ref="input" :accept="accept" type="file" multiple @change="handleChange">
    </div>
</template>

<script>
    /**
     * 只提供基本的文件选择功能
     */
    export default {
        name: 'AlbumPhotoInputFile',
        props: {
            accept: {
                type: String,
                default: 'image/jpg,image/jpeg,image/png,image/gif'
            },
            multiple: {
                type: Boolean,
                default: true
            },
        },
        methods: {
            handleClick() {
                this.$refs.input.value = null;
                this.$refs.input.click();
            },
            handleChange(event) {
                const files = event.target.files || [];
                const accept = this.accept.split(',');
                const filter = [...files].filter(item => accept.includes(item.type));
                if (filter.length) {
                    this.$emit('change', filter);
                }
            }
        }
    };
</script>

<style module>
    .input input {
        display: none;
    }
</style>
