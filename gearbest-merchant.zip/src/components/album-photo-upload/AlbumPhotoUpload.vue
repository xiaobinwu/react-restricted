<template>
    <el-dialog :visible="visible" width="810px" title="上传图片" @close="closeDialog">
        <div class="header">
            <el-form>
                <el-form-item label="将图片保存至：">
                    <el-select v-model="checked" :disabled="lockAlbum">
                        <el-option
                            v-for="(album, index) in albumList"
                            :key="index"
                            :label="album.albumName"
                            :value="album.albumCode">
                        </el-option>
                    </el-select>

                    <span v-if="uploadTips" :class="$style.uploadTips">{{ uploadTips }}</span>
                    <span v-else :class="$style.uploadTips">图片最大不能超过3M，支持图片格式（JPG,JEPG,PNG,BMP,GIF)</span>
                </el-form-item>
            </el-form>
        </div>
        <el-scrollbar
            :class="$style.content"
            :wrap-class="$style.scrollWrap"
            :view-class="$style.listInner"
            tag="div">
            <div v-for="(item, index) in uploadList" :key="index" :class="$style.contentItem">
                <div :class="$style.imgBox">
                    <img :src="item.dataUrl">
                    <div :class="$style.deleteImg" @click="deleteFile(index, item)">
                        <i class="icon-delete"></i>
                    </div>
                </div>
                <p :class="$style.imgName">{{ item.file.name }}</p>
                <div :class="$style.progress">
                    <el-progress :percentage="item.percent" :show-text="false"></el-progress>
                </div>
                <p v-if="!!item.error" :class="$style.error">{{ item.error }}</p>
                <p v-if="!!item.error && item.status === 4" :class="[$style.error, $style.errorCursor]" @click="updateFile(item)">{{ item.error }}</p>
            </div>
        </el-scrollbar>
        <div :class="$style.btnGroup">
            <el-button @click="closeDialog">取消</el-button>
            <el-button type="primary" @click="saveFile">保存</el-button>
        </div>
    </el-dialog>
</template>

<script>
    import { serviceAlbumList, serviceImageMove } from '@picture/services/picture';

    export default {
        name: 'AlbumPhotoUpload',

        props: {
            // 是否显示
            visible: {
                type: Boolean,
                default: false
            },
            // 上传的地址
            action: {
                type: String,
                default: '/image-manage/image-upload'
            },
            // 上传文件字段
            name: {
                type: String,
                default: 'uploadFile'
            },
            // 其他携带的字段
            data: {
                type: Object,
                default() {
                    return {
                        method: 'albumImage'
                    };
                }
            },
            // 图片上传大小
            size: {
                type: Number,
                default: 3 * 1024 * 1024
            },
            // 锁定上传相册
            lockAlbum: {
                type: Boolean,
                default: false
            },
            albumCode: {
                type: String,
                default: ''
            },
            uploadTips: {
                type: String,
                default: ''
            }
        },

        data() {
            return {
                checked: '',
                albumList: [],
                uploadList: []
            };
        },

        watch: {
            visible(val) {
                if (val) {
                    this.init();
                }
            }
        },

        methods: {
            // main
            init() {
                this.getAlbumList();
            },

            // 获取相册列表
            async getAlbumList() {
                const { status, data } = await serviceAlbumList.http();
                if (status === 0) {
                    this.albumList = data;
                    // 默认选择第一个相册
                    if (this.lockAlbum) {
                        this.checked = this.albumCode;
                    } else {
                        this.checked = this.albumList[0].albumCode;
                    }
                }
            },

            // 添加上传文件
            async addFile(files) {
                const data = await this.handleFile(files);
                this.uploadList = data.map((file) => {
                    file.error = file.size > this.size ? '超过3M' : '';
                    file.percent = 0;
                    file.fileCode = '';
                    return file;
                });

                this.uploadFile(this.uploadList);
            },

            // 读取文件信息 - 异步队列
            handleFile(files) {
                const all = files.reduce((acc, file) => {
                    acc.push(this.readFile(file));
                    return acc;
                }, []);
                return Promise.all(all);
            },

            // 文件上传 - 异步队列
            uploadFile(files) {
                const self = this;
                const task = (index, total, quene) => {
                    this.post({
                        data: quene[index],
                        onSuccess(response) {
                            if (response.status === 80011106 || response.status === 80011104) {
                                this.data = Object.assign(this.data, {
                                    error: '格式不符',
                                    status: 3,
                                    percent: 0
                                });
                            } else if (response.status === 0) {
                                this.data = Object.assign(this.data, {
                                    error: '',
                                    status: 2,
                                    percent: 100,
                                    fileCode: response.data.fileCode
                                });
                            } else {
                                this.data = Object.assign(this.data, {
                                    error: '上传错误',
                                    status: 3,
                                    percent: 0
                                });

                                self.$message.error(response.msg);
                                return;
                            }


                            if (index < total - 1) {
                                index += 1;
                                task(index, total, files);
                            }
                        },
                        onProgress(progress) {
                            this.data.status = 1;
                            this.data.percent = progress.percent;
                        },
                        onError(response) {
                            this.data = Object.assign(this.data, {
                                error: '上传失败（点击重试)',
                                status: 4,
                                percent: 0
                            });
                            if (index < total - 1) {
                                index += 1;
                                task(index, total, files);
                            }
                        }
                    });
                };

                task(0, files.length, files);
            },

            // ajax 文件上传
            post(option) {
                const getBody = (xhr) => {
                    const text = xhr.responseText || xhr.response;
                    if (!text) {
                        return text;
                    }

                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        return text;
                    }
                };

                const getError = (action, xhr) => {
                    let msg;
                    if (xhr.response) {
                        msg = `${xhr.response.error || xhr.response}`;
                    } else if (xhr.responseText) {
                        msg = `${xhr.responseText}`;
                    } else {
                        msg = `fail to post ${action} ${xhr.status}`;
                    }

                    const err = new Error(msg);
                    err.status = xhr.status;
                    err.method = 'post';
                    err.url = action;
                    return err;
                };

                const xhr = new XMLHttpRequest();
                const formData = new FormData();

                if (this.data) {
                    Object.keys(this.data).forEach((key) => {
                        formData.append(key, this.data[key]);
                    });
                }
                formData.append(this.name, option.data.file);
                xhr.withCredentials = true;

                xhr.onload = () => {
                    if (xhr.status >= 200 && xhr.status <= 300) {
                        option.onSuccess(getBody(xhr), option.data);
                    } else {
                        option.onError(option.data);
                    }
                };

                xhr.onerror = () => {
                    option.onError(getError(this.action, xhr));
                };

                xhr.upload.onprogress = (e) => {
                    if (e.total > 0) {
                        e.percent = e.loaded / e.total * 100;
                        option.onProgress(e);
                    }
                };

                xhr.open('post', this.action, true);

                xhr.send(formData);
            },

            // 读取文件原信息 - 返回 dataURL
            readFile(file) {
                return new Promise((resolve, reject) => {
                    const fileReader = new FileReader();
                    fileReader.onload = (e) => {
                        resolve({
                            dataUrl: e.target.result,
                            file
                        });
                    };
                    fileReader.onerror = (e) => {
                        reject();
                    };
                    fileReader.readAsDataURL(file);
                });
            },

            // 删除文件
            deleteFile(index, file) {
                // 正在上传
                if (file.status !== 1) {
                    this.uploadList.splice(index, 1);
                } else {
                    this.$message.error('图片正在上传');
                }
            },

            // 是否全部上传完毕
            isAllUpload() {
                const files = this.uploadList;
                return files.filter(file => file.status === 2).length === files.length;
            },

            // 获取默认相册
            getDefaultAlbum() {
                return this.albumList.filter(item => item.albumDefault === '1');
            },

            // 保存图片
            async saveFile() {
                if (!this.uploadList.length) {
                    this.$message.error('暂无文件上传');
                } else if (!this.isAllUpload()) {
                    this.$message.error('有未上传成功的图片');
                } else {
                    const data = {
                        fileCode: [],
                        albumCode: this.checked
                    };
                    this.uploadList.forEach((file) => {
                        data.fileCode.push(file.fileCode);
                    });
                    data.fileCode = data.fileCode.join(',');

                    // 上传到默认相册不需要转移文件
                    const defaultAlbum = this.getDefaultAlbum()[0];
                    if (defaultAlbum.albumCode !== this.checked) {
                        await this.ImageMove(data);
                    }
                    this.$message.success('图片保存成功');

                    this.$emit('save');

                    this.closeDialog();
                }
            },

            async ImageMove(data) {
                const reply = await serviceImageMove.http({ data });
                if (reply.status === 0) {
                    return Promise.resolve();
                }
                return Promise.reject();
            },

            closeDialog() {
                this.$emit('update:visible', false);
                this.uploadList = [];
            }
        }
    };
</script>

<style module>
    @import 'variable.css';
    @import 'utils.css';

    .uploadTips {
        display: inline-block;
        margin-left: 16px;
        font-size: var(--font-size-base);
        color: var(--color-text-regular);
    }

    .content {
        margin-bottom: 30px;
        border-radius: 4px;
        border: var(--border-base-style);
    }

    .btnGroup {
        font-size: 0;
        text-align: center;
    }

    .btnGroup button:last-of-type {
        margin-left: 20px;
    }

    .content {
        /* padding: 20px; */
    }

    .contentItem {
        float: left;
        position: relative;
        width: 80px;
        height: 154px;
        margin-right: 27px;
        margin-bottom: 27px;
    }

    .contentItem:nth-child(7n) {
        margin-right: 0;
    }

    .imgBox {
        position: relative;
        cursor: pointer;
    }

    .imgBox img {
        width: 80px;
        height: 80px;
        object-fit: cover;
    }

    .imgBox:hover > div {
        opacity: 1;
        transition: opacity var(--animation-transition-time) var(--animation-transition-timing);
    }

    .deleteImg {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0, 0, 0, 0.6);
        opacity: 0;
        transition: opacity var(--animation-transition-time) var(--animation-transition-timing);
    }

    .deleteImg i {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 24px;
    }

    .imgName {
        width: inherit;
        line-height: 1;
        padding-top: 14px;
        color: var(--color-text-primary);
        font-size: 12px;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        text-align: center;
    }

    .contentItem .error {
        padding-top: 10px;
        font-size: 12px;
        color: var(--color-error);
        line-height: 1;
        text-align: center;
    }

    .contentItem .errorCursor {
        cursor: pointer;
    }

    .progress {
        padding-top: 12px;
        width: 100%;
    }

    .scrollWrap {
        height: 400px;
        overflow-y: scroll;
    }

    .listInner {
        padding: 20px;
        @mixin clearfix;
    }
</style>
