/**
 * Created by Liu.Jun on 2018/12/18.
 */

/**
 * 参数说明
 * @param url           {string} 《请求地址，必传项》
 * @param method        {string} 《请求方式，默认：'GET'》
 * @param loading       {boolean} 《请求阶段是否显示菊花图，默认：false》
 * @param cache         {boolean} 《是否缓存接口，默认：false》
 * @param isCancel      {boolean} 《如果第二次请求发起在第一次请求结束之前，是否取消第一次请求，默认：false》
 * @param useLocalCache {number} 《本地缓存接口数据，值为缓存的时间（秒），默认：0（不缓存）》
 * @param usePreResult  {boolean} 《多次请求同一个接口，皆返回第一次请求的数据，不会判断参数变更，谨慎使用，默认：false》
 * @param ignoreAuth    {boolean} 《是否忽略接口验证登录状态，默认：false》
 * @param showError     {boolean} 《是否自动弹出接口返回的报错信息，默认：false》
 */

import { Message, Loading } from 'element-ui';
import { http, serviceConfig, Service } from '@gb/http';
import { resetVuexLoginInfo } from './auth';

const isDev = process.env.NODE_ENV === 'development';

// 全局接口拦截器
http.interceptors.push(request => function responseCall(response) {
    const requestErr = 'Request fail !!';
    if (response.ok) {
        const status = response.body ? response.body.status : 0;
        if (!request.ignoreAuth && status === 10070005) {
            /**
             * 用户未登录，强制下线
             * 设置 ignoreAuth: false 可以跳过登录检测
             * 主要用于 /user/get-login-data 接口
             */
            resetVuexLoginInfo();
        } else if (status !== 0 && request.showError) {
            /**
             * 设置 showError: true 可自动弹出接口报错信息
             */
            Message.error(response.body.msg || requestErr);
        }
    } else if (request.showError) {
        Message.error(requestErr);
    }
});

/**
 * loading 配置
 */
serviceConfig.set({
    showLoading() {
        return Loading.service();
    },
    hideLoading(params) {
        // 这里params 为调用showLoading 的返回值
        params.close();
    }
});

export default class GbService extends Service {
    preHttpCall(params) {
        // 兼容post请求参数传递 data -> body
        if (params.data) {
            params.body = params.data;
            delete params.data;
        }

        if (isDev) {
            if (params.mock) {
                params.url = `http://apidoc.gearbest-beta.com/server/index.php?g=Web&c=Mock&o=simple&projectID=70&uri=${params.url}`;
            } else {
                params.url = `/devApi${params.url}`;
            }
        }
    }
}
