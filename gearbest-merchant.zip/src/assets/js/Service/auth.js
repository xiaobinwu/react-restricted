/**
 * Created by Jiazhan Li on 2019/2/18.
 */

import { UPDATE_USER } from '@/assets/js/store/mutationTypes';
import store from '../store';

/**
 * 强制用户下线，重新登录
 */
export const resetVuexLoginInfo = () => {
    // 需要登录
    store.commit(UPDATE_USER, {
        isLogin: null,
        userInfo: {},
        shopFreeze: false,
    });
    window.location.href = '/sign.html#/sign/login';
};
