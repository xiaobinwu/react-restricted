/**
 * 全局通用的一些路由视图
 */

export default [
    {
        name: 'notFound',
        path: '/404',
        meta: {
            title: '404'
        },
        component: () => import('@/components/NotFound')
    },
    {
        path: '*',
        redirect: '404'
    }
];
