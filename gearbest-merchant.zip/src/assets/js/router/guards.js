/**
 * 全局路由守卫
 * Created by Jiazhan Li on 2019/2/14.
 */

import { syncUserState, redirect } from './auth';

/**
 * 全局前置守卫
 * @param router 《路由实例》
 * @returns {Function | *}
 */
export default function guards(router) {
    router.beforeEach(async (to, from, next) => {
        // 新开标签页时，同步用户状态信息
        await syncUserState();

        // 分析用户状态，重定向落地页
        redirect(to, from, next);
    });
}
