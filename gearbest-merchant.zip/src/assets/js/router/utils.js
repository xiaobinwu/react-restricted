import Router from 'vue-router';

/**
 * 路由跨页面 push / replace 方法
 * @param {string|object} location 字符串路径或者一个描述地址的对象，跨页面跳转时必须为合法的字符串路径
 * @param {function} onComplete
 * @param {function} onAbort
 */
Router.prototype.gbPush = function gbPush(location, onComplete, onAbort) {
    const matched = this.resolve(location).route.matched;
    const last = matched[matched.length - 1];

    if (matched.length && last.path !== '/404') {
        this.push(location, onComplete, onAbort);
    } else {
        const crossPage = location.split('/')[1];
        window.location.href = this.gbFullPath(crossPage, location);
    }
};

Router.prototype.gbReplace = function gbReplace(location, onComplete, onAbort) {
    const matched = this.resolve(location).route.matched;
    const last = matched[matched.length - 1];

    if (matched.length && last.path !== '/404') {
        this.replace(location, onComplete, onAbort);
    } else {
        const crossPage = location.split('/')[1];
        window.location.replace(this.gbFullPath(crossPage, location));
    }
};

Router.prototype.gbFullPath = function gbCrossFullPath(page, path) {
    const origin = window.location.origin;
    return `${origin}/${page}.html#${path}`;
};
