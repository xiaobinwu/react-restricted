/**
 * Created by Jiazhan Li on 2019/2/14.
 */

import { getLoginInfo } from '@sign/services/login';
import { UPDATE_USER } from '../store/mutationTypes';
import store from '../store';

/**
 * 新开标签页时，同步用户状态信息
 * 当前用户状态信息通过 sessionStorage 存储，且用户新开标签时无法获取前一个窗口的用户状态信息
 * 所以该情景下通过请求接口的方式获取状态信息，并同步
 */
export async function syncUserState() {
    if (store.state.user.isLogin === null) {
        // 用户通过新开标签页进入页面
        try {
            const { status, data } = await getLoginInfo.http();
            if (status === 0 && data.status === 1) {
                // 用户已登录且已经激活（但也有可能是冻结状态）
                store.commit(UPDATE_USER, {
                    isLogin: true,
                    shopFreeze: data.accountStatus === 4,
                    userInfo: Object.assign({
                        defaultShop: data.shopInfo[0] || {}
                    }, data)
                });
            }
        } catch (error) {
            console.error(error.statusText);
        }
    }
}

/**
 * 分析用户状态，重定向落地页
 * @param to
 * @param from
 * @param nextx
 *
 * 用户已登录
 *     |-- 账户未激活（不存在这种情况）
 *     |-- 账户已封停（不存在这种情况）
 *     |-- 账户正常
 *         |-- 如果店铺状态 == 未入驻、审核中、已拒绝
 *             |-- 如果 to == 商家入驻页，next()
 *             |-- 如果 to != 商家入驻页，跳 user/entry（商家入驻页）
 *         |-- 如果店铺状态 == 已开店、已冻结
 *             |-- 如果 to == 登录、注册页、商家入驻页，跳店铺首页或来源页（登录带ref）
 *             |-- 如果 to != 登录、注册页、商家入驻页，next()
 * 用户未登录
 *     |-- 如果 to == 登录、注册页，next()
 *     |-- 如果 to != 登录、注册页，跳登录页，且带上ref
 */
export function redirect(to, from, next) {
    const { isLogin, userInfo = {} } = store.state.user;
    const privateNext = getPrivateNext(to, from, next); // 返回封装后的 next 函数

    if (isRequireAuth(to.matched)) {
        // 需要验证登录状态的页面
        if (isLogin && userInfo.status === 1) {
            // 用户已登录且账户正常
            if ([0, 1, 2].includes(userInfo.accountStatus)) {
                // 店铺状态 == 未入驻、审核中、已拒绝
                if (to.name === 'userEntry') {
                    privateNext();
                } else {
                    privateNext({ path: '/user/entry' });
                }
            } else if ([3, 4].includes(userInfo.accountStatus)) {
                // 店铺状态 == 已开店、已冻结
                if (['signLogin', 'signRegister', 'userEntry'].includes(to.name)) {
                    if (to.query.ref) {
                        privateNext({ path: decodeURIComponent(to.query.ref) });
                    } else {
                        privateNext({ path: '/index/home' });
                    }
                } else {
                    privateNext();
                }
            }
        } else if (!isLogin) {
            if (['signLogin', 'signRegister'].includes(to.name)) {
                // 登录、注册页
                privateNext();
            } else {
                // 跳转至登录页，且带上ref参数
                privateNext({
                    path: '/sign/login',
                    query: {
                        ref: encodeURIComponent(window.location.href)
                    }
                });
            }
        }
    } else {
        // 无需验证登录状态，可直接进入页面
        privateNext();
    }
}

/**
 * 返回封装后的 next 函数，兼容跨组件的页面跳转
 * @param to
 * @param from
 * @param next
 */
function getPrivateNext(to, from, next) {
    return (param) => {
        if (param === undefined || param.path === undefined) {
            // 允许进入页面
            document.title = window.$$lang.translate(to.meta.title);
            next(param);
        } else {
            const { path, query = {} } = param;
            const { origin, pathname } = window.location;

            if (/^https?/.test(path)) {
                console.log(path);
                window.location.href = path; // 绝对路径
            } else {
                const entryName = (/^\/?([^/]+)/.exec(path) || [])[1] || 'index';
                const entryNameLocal = (/([^/]+)\.html?/.exec(pathname) || [])[1] || 'index';
                if (entryName === entryNameLocal) {
                    next(param); // 跳转路径位于同一组件
                } else {
                    const queryStr = Object.entries(query).map(([key, value]) => `${key}=${value}`).join('&');
                    console.log(`${origin}/${entryName}.html#${path}${queryStr ? `?${queryStr}` : ''}`);
                    window.location.href = `${origin}/${entryName}.html#${path}${queryStr ? `?${queryStr}` : ''}`;
                }
            }
        }
    };
}

/**
 * 判断待进入的页面是否需要登录认证
 * @param matchList 《路由匹配列表》
 * @return {boolean}
 */
function isRequireAuth(matchList = []) {
    let needToAuth = false;
    Array.from(matchList).reverse().some((item) => {
        if (item.meta && item.meta.requireAuth !== undefined) {
            if (item.meta.requireAuth === true) needToAuth = true;
            return true;
        }
        return false;
    });
    return needToAuth;
}
