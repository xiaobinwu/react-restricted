import Vue from 'vue';
import Router from 'vue-router';
import routes from './routes';
import guards from './guards';
import './utils';

Vue.use(Router);

/**
 * 路由入口
 * {object} options VueRouter Options
 */
export default (options) => {
    const router = new Router({
        ...options,
        mode: 'hash',
        routes: [...options.routes, ...routes], // 合并当前页面的路由和通用路由视图
        scrollBehavior() {
            return { x: 0, y: 0 };
        }
    });
    guards(router); // 路由守卫
    return router;
};
