/**
 * Created by Liu.Jun on 2019/1/3.
 */

export const UPDATE_USER = 'UPDATE_USER_MUTATION';
