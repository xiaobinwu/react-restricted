/**
 * Created by Liu.Jun on 2019/1/3.
 */

import * as types from '../mutationTypes';

const state = {
    userInfo: {},
    isLogin: null, // null 未登录过  true 已登录  false 过期
    shopFreeze: false,
};

const mutations = {
    [types.UPDATE_USER](moduleState, { userInfo, isLogin }) {
        moduleState.userInfo = userInfo;
        moduleState.isLogin = isLogin;
    }
};

const getters = {
    userInfo: moduleState => moduleState.userInfo
};

const actions = {
    // 干点啥啊

};

export default {
    state,
    getters,
    mutations,
    actions,
};
