/**
 * Created by Guo.Xiu on 2019/1/10.
 */

const state = {

};

const mutations = {
};

export default {
    state,
    mutations,
};
