/**
 * Created by Liu.Jun on 2019/1/3.
 */

const state = {
};

const mutations = {
};

export default {
    state,
    mutations,
};
