/**
 * Created by Liu.Jun on 2019/1/3.
 */

import Vue from 'vue';
import Vuex from 'vuex';
import vuexStorage from '@/assets/js/plugins/vuex-storage';
import { UPDATE_USER } from './mutationTypes';

import modules from './modules';

Vue.use(Vuex);

export default new Vuex.Store({
    modules,
    plugins: [vuexStorage({
        predicate: [UPDATE_USER],
        storeModule: ['user']
    })],
    strict: process.env.NODE_ENV !== 'production'
});
