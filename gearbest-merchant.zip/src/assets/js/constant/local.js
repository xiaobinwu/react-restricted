/**
 * 本地存储使用的常量-> localStorage sessionStorage
 */

// 语言类型
export const LANG_TYPE = 'lang-type';
