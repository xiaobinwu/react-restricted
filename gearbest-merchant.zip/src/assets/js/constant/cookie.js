/**
 * cookie 使用的常量
 */
