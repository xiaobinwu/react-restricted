/**
 * 全局通用的常量
 */

// 域名
export const DOMAIN = 'http://www.example.com';

// 站点支持的语言类型
export const LANG_TYPES = ['zh-cn'];

// 图片上传地址
export const UPLOAD_URL = '/image-manage/image-upload';

// GB 主机名
export const GB_HOST = 'gearbest.net';
