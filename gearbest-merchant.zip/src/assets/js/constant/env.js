
/**
* 项目环境常量 - 由 config/env.const 根据根目录 env.const.js 生成
*/
export const CDN_IMG = '/';
export const UPLOAD_LOGO = 'http://pdm.hqygou.com';
export const UPLOAD_REVIEW_IMG = 'http://uploads.review.com.a.php5.egomsl.com/review/upload';
export const GEARBEST_URL = 'https://www.gearbest.net';
