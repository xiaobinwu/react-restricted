/**
* 通用的正则
*/

// 域名 - 匹配下列规则
// http://www.baidu.com.com
// http://www.baidu.com.com:8080
// http://baidu.com
// http://baidu.com:8080
// www.baidu.com
// www.baidu.com:8080
// www.baidu.net
// www.baidu.cn
// baidu.cn
// baidu.cn:9090
export const LINKS = /((https?:\/\/([\w|\-_]+\.)+[\w]+(:\d+)?)|(www\.([\w|\-_]+\.)+[\w|\-_]+(:\d+)?)|(([\w|\-_]+\.)+(cn|com|net)(:\d+)?))/gi;
