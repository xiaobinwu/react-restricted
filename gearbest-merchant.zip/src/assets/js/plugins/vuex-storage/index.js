/**
 * Created by Liu.Jun on 2019/1/3.
 */

// session Storage 强制新标签会丢失，暂不处理
// sessionStorage chrome下只会在第一次打开标签下同步数据，及时使用复制标签，后续的变更都是独立的不同标签不会在同步数据

import syncStorage from './utils/syncStorage';

const DEFAULT_KEY = 'vuex-storage-key';

// 检测是否可运行
function checkCanRun() {
    //
    if (typeof window === 'undefined' || !window.localStorage) {
        console.error(
            'localStorage 异常',
        );
        return false;
    }

    // ios 隐私模式等 localStorage无法使用
    try {
        window.localStorage.setItem('vuex-storage-test', 'test');
        window.localStorage.removeItem('vuex-storage-test');
    } catch (e) {
        console.error(
            'localStorage无法使用',
        );
        return false;
    }

    return true;
}

class Storage {
    constructor({
        store,
        key,
        storageObj,
        storeModule
    } = {}) {
        this.store = store;
        this.key = key;
        this.storageObj = storageObj;
        this.storeModule = [].concat(storeModule);

        this.initStore();
    }

    getStorageData() {
        const { storageObj, key } = this;
        try {
            return storageObj.getItem(key) ? JSON.parse(storageObj.getItem(key)) || {} : {};
        } catch (e) {
            console.error('获取本地storage json解析异常，强制替换为空对象');
            return {};
        }
    }

    initStore() {
        const { store } = this;
        const curData = this.getStorageData();

        // 通过mutation 恢复数据，只存储最后一次commit记录，可能导致数据丢失，全量存储会导致记录信息过大，调整通过配置 module 直接做state缓存
        Object.entries(curData).forEach(([stateModuleKey, stateVal]) => {
            if (this.storeModule.includes(stateModuleKey)) {
                store.replaceState({
                    [stateModuleKey]: stateVal
                });
            }
        });

        // Object.entries(curData).forEach(([mutationType, mutationPayload]) => {
        //     if (shouldSave(mutationType)) {
        //         store.commit(mutationType, mutationPayload);
        //     }
        // });
    }

    addStorage(state) {
        const { storageObj, key } = this;
        const saveState = this.storeModule.reduce((preVal, curVal) => {
            if (state[curVal]) {
                Object.assign(preVal, {
                    [curVal]: state[curVal]
                });
            }
            return preVal;
        }, {});

        storageObj.setItem(key, JSON.stringify(saveState));

        // const curData = this.getStorageData();
        // storageObj.setItem(key, JSON.stringify({
        //     ...curData,
        //     ...newData
        // }));
    }

    clearStorage() {
        const { storageObj, key } = this;
        storageObj.removeItem(key);
    }

    getStorage() {
        const { storageObj, key } = this;
        return storageObj.getItem(key);
    }
}

/**
 *
 * @param 可选 | predicate 数组['mutationKey1', 'mutationKey2'] | function 回掉函数return bool，缓存时机，目前只起到强化性能的作用 | 默认不过滤
 * @param stroageKey 本地存储 key名
 * @param stroageType 1 -- localStorage， 2 -- sessionStorage
 * @param storeModule String|Array 实际上直接获取state的key名，不会考虑支持多级，可以通过按模块或者rootState区分key名
 * @param syncKeyPrefix String 数据localstorage 变更key前缀，通过key来同步 sessionStorage
 * @returns {Function}
 */

export default ({
    predicate, stroageKey, storeModule, stroageType = 2, syncKeyPrefix = 'gbsSync'
} = {}) => (store) => {
    if (!checkCanRun()) return;

    const key = stroageKey || DEFAULT_KEY;
    const storageObj = stroageType === 2 ? window.sessionStorage : window.localStorage;

    const shouldSave = typeof predicate === 'function'
        ? predicate
        : predicate ? mutation => predicate.includes(mutation.type) : () => true;

    const storageInstance = new Storage({
        store,
        key,
        storageObj,
        storeModule
    });


    // 同步 sessionStorage，不同步state
    const emitSyncEvent = syncStorage({
        storageObj,
        key,
        syncKeyPrefix
    });

    // 同步本地存储
    store.subscribe((mutation, state) => {
        if (shouldSave(mutation)) {
            storageInstance.addStorage(state);
            const storage = storageInstance.getStorage();
            if (emitSyncEvent) {
                emitSyncEvent(storage);
            }
        }
    });
};
