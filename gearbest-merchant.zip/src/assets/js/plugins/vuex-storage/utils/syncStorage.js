/**
 * Created by Liu.Jun on 2019/1/26.
 */

export default function ({
    storageObj,
    key,
    syncKeyPrefix
} = {}) {
    const emitKey = `${syncKeyPrefix}-${key}`;

    if (storageObj === sessionStorage) {
        window.addEventListener('storage', (event) => {
            if (event.key === emitKey && event.newValue) {
                const curStorage = sessionStorage.getItem(key);
                if (event.newValue !== curStorage) {
                    sessionStorage.setItem(key, event.newValue);
                }
            }
        });

        return function emitSync(storageData) {
            localStorage.setItem(emitKey, storageData);
            localStorage.removeItem(emitKey);
        };
    }

    return null;
}
