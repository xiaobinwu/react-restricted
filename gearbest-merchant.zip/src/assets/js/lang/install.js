/* eslint-disable */
export function install(Vue) {
    Vue.mixin({
        beforeCreate() {
            if (this.$options && this.$options.lang) {
                this._langRoot = this;
                this._lang = this.$options.lang;
            } else {
                this._langRoot = (this.$parent && this.$parent._langRoot) || this;
            }
        }
    });

    Object.defineProperty(Vue.prototype, '$lang', {
        get() { return this._langRoot._lang; }
    });

    Vue.prototype.$t = function(key, values = []) {
        const lang = this.$lang;
        return lang.translate(key, values);
    }
}
