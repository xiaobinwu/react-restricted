import Lang from './Lang';
import baseLang from '@/lang/base';
import { getRemoteLang } from '@/assets/js/common/services';

/**
 * 多语言初始化
 * @param local 模块本地语言包
 * @param moduleName 模块名（用于获取远程对应语言包）
 * @returns {Promise<Lang>}
 */
export default ({ local, moduleName }) => new Promise(async (resolve, reject) => {
    const lang = new Lang({
        type: 'zh-cn',
        lang: {
            ...baseLang,
            ...local
        }
    });


    const cached = Lang.getCacheLangType();

    // 获取远程语言包
    if (Lang.validateLangType(cached) && cached !== lang.type) {
        lang.type = cached;
        try {
            const { data } = await getRemoteLang.http({
                mock: true,
                params: {
                    type: cached,
                    module: moduleName
                }
            });

            lang.lang = data;
            resolve(lang);

        } catch (e) {
            reject(e);
        }
    } else {
        resolve(lang);
    }
});
