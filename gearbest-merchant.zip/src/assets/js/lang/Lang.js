import { install } from './install';
import { LANG_TYPE } from '@/assets/js/constant/local';
import { LANG_TYPES } from '@/assets/js/constant/other';

export default class Lang {
    static LANG_TYPE_CACHE_KEY = LANG_TYPE;

    static LANG_TYPES = LANG_TYPES;

    /**
     * 构造函数
     * @param type 默认显示的语言
     * @param lang 本地语言包
     */
    constructor({ type, lang }) {
        this.type = type;
        this.lang = lang;
    }

    /**
     * 获取缓存语言类型
     * @returns {string}
     */
    static getCacheLangType() {
        return window.localStorage.getItem(Lang.LANG_TYPE_CACHE_KEY);
    }

    /**
     * 设置缓存语言类型
     * @param val
     */
    static setCacheLangType(val) {
        try {
            window.localStorage.setItem(Lang.LANG_TYPE_CACHE_KEY, val);
        } catch (e) {
            throw e;
        }
    }

    /**
     * 是否是有效的语言类型
     * 防止客户端篡改无效的语言类型
     * @param val
     * @returns {boolean}
     */
    static validateLangType(val) {
        return !!~Lang.LANG_TYPES.indexOf(val);
    }

    /**
     * 格式化占位符
     * @param {string} lang
     * @param {array} values
     * @returns {string}
     * @private
     */
    langFormat(lang, values = []) {
        let str = lang;
        values.forEach((item, index) => {
            str = str.replace(`:#$${index + 1}#`, item);
        });
        return str;
    }

    /**
     * 根据 key 获取对应语言
     * @param {string} key
     * @param {array} values
     * @returns {string}
     * @public
     */
    translate(key, values = []) {
        const lang = this.lang;
        const val = lang && lang[key];

        if (!val) return key;

        return this.langFormat(lang[key], values);
    }
}

Lang.install = install;
