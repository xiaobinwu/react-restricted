/**
 * 节流阀函数（当多次执行待封装的函数时，为了节约性能，函数将在一次间隔时间内最多执行一次）
 * @param  [Function] func 待封装的函数
 * @param  [Number] wait 间隔时间
 * @param  [Boolean] immediate 如果为 true，函数会在一开始执行一次
 * @return [Function] 返回封装后的函数
 * @author lijiazhan
 */
export default function debounce(func, wait, immediate) {
    let timeout;
    let args;
    let context;
    let timestamp;
    let result;

    function later() {
        const last = new Date() - timestamp;

        if (last < wait && last >= 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            if (!immediate) {
                result = func.apply(context, args);
                args = null;
                context = args;
            }
        }
    }

    return (...params) => {
        context = this;
        args = params;
        timestamp = new Date();
        const callNow = immediate && !timeout;
        if (!timeout) timeout = setTimeout(later, wait);
        if (callNow) {
            result = func.apply(context, args);
            args = null;
            context = args;
        }
        return result;
    };
}
