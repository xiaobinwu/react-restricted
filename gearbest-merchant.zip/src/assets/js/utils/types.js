
/**
 * 工具函数 - 类型转换/类型判断
 */


/**
 * 是否为对象
 * @param {*} val
 */
const toString = Object.prototype.toString;
export const isObject = val => toString.call(val) === '[object Object]';

/**
 * 是否为空对象
 * @param {*} val
 */
export const isNotEmptyObject = obj => obj && Object.keys(obj).length > 0;

/**
 * 深拷贝 - 合法的 JSON 对象
 * @param {Object} obj
 */
export const deepCopy = (obj) => {
    try {
        if (obj) {
            return JSON.parse(JSON.stringify(obj));
        }
        return obj;
    } catch (e) {
        throw e;
    }
};

/**
 * 以 key 将对象数组数转为 map 结构
 * @param arr
 * @param key
 */
export const map = (arr = [], key) => arr.reduce((acc, item) => {
    if (item[key]) {
        acc[item[key]] = item;
    }
    return acc;
}, {});
