/**
 * Created by Jiazhan Li on 2018/12/29.
 */

/**
 * 时间戳格式化
 * @param  {Date|Number} date 要格式化的日期对象或者时间戳（注意：时间戳单位为秒）
 * @param  {String} format 进行格式化的模式字符串，默认为：'yyyy-MM-dd hh:mm:ss'
 * @return {String}
 * @demo
 *     dateFormat(new Date());                              // => 2006-01-02 08:09:04
 *     dateFormat(1234567891);                              // => 2006-01-02 08:09:04
 *     dateFormat(1234567891, 'yyyy-MM-dd hh:mm:ss');       // => 2006-01-02 08:09:04
 *     dateFormat(new Date(), 'yyyy-M-d h:m:s');            // => 2006-1-2 8:9:4
 *     dateFormat(new Date(), 'MMM dd, yyyy hh:mm:ss');     // => Jan 02, 2006 08:09:04
 *     dateFormat(new Date(), 'MMMM d, yyyy');              // => January 2, 2006
 *     dateFormat(new Date(), 'MMM dd, yyyy hh:mm:ss TT');  // => Mar 15, 2018 18:15:58 AM
 *
 * 你还可以提前设置一些默认值，比如：dateFormat.format 和 dateFormat.months
 */
export function dateFormat(date, format) {
    if (!date) return '';

    const $date = date instanceof Date ? date : new Date(date * 1000);
    const $format = format || 'yyyy/MM/dd hh:mm';
    const $months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
    ];
    const map = {
        y: $date.getFullYear(),
        M: $date.getMonth() + 1,
        d: $date.getDate(),
        h: $date.getHours(),
        m: $date.getMinutes(),
        s: $date.getSeconds(),
        T: $date.getHours() < 13 ? 'AM' : 'PM'
    };

    return $format.replace(/(([yMdhmsT])(\2)*)/g, (all, t1, t2) => {
        const v = map[t2];
        if (t2 === 'y') return `${v}`.substr(4 - t1.length);
        if (t2 === 'M' && t1.length > 2) return $months[v - 1].substr(0, t1.length);
        return t1.length > 1 ? `0${v}`.substr(-2) : v;
    });
}

/**
 * 返回一个加工过的时间格式化工具（可以少些点代码）
 * @param format
 * @return {function(*=): String}
 */
export function dateFormatter(format) {
    return date => dateFormat(date, format);
}
