/**
 * 解析 url
 * @param url
 */
export function parse(url) {
    const a = document.createElement('a');
    a.href = url;

    const search = (str) => {
        if (!str) return {};

        const ret = {};
        str = str.slice(1).split('&');
        for (let i = 0, arr; i < str.length; i += 1) {
            arr = str[i].split('=');
            const key = arr[0]; const
                value = arr[1];
            if (/\[\]$/.test(key)) {
                ret[key] = ret[key] || [];
                ret[key].push(value);
            } else {
                ret[key] = value;
            }
        }
        return ret;
    };

    return {
        protocol: a.protocol,
        host: a.host,
        hostname: a.hostname,
        pathname: a.pathname,
        search: search(a.search),
        hash: a.hash,
        origin: a.origin
    };
}

/**
 * JS模拟触发A标签打开新页面
 * @param url
 */
export function openNewPage(url) {
    const a = document.createElement('a');
    a.style.display = 'none';
    a.target = '_blank';
    a.href = url;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}
