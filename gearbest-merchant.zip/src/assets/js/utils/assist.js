import { CDN_IMG } from '@/assets/js/constant/env';

/**
 * 根据 File 对象获取图片宽高信息
 * @param file
 */
export const getImgInfo = file => new Promise((resolve, reject) => {
    const render = new FileReader();

    render.onload = (e) => {
        const data = e.target.result;
        const img = new Image();

        img.onload = () => {
            resolve({
                width: img.width,
                height: img.height,
                type: data.match(/^data:(.+)?;.+/)[1],
                size: e.total / 1024 // kb
            });
        };

        img.error = () => {
            reject(new Error('getImgInfo fail'));
        };

        img.src = data;
    };

    render.onerror = (e) => {
        reject(new Error('getImgInfo fail'));
    };
    render.readAsDataURL(file);
});

/**
 * 自动补充cdn前缀
 * 所有需要放到static的文件必须放到 /static/file 文件夹下
 * 使用时直接传入/static/file/下的文件名, 如: getAssistPath('filename');
 */
export const getAssistPath = filename => `${CDN_IMG}/static/file/${filename}`;


/**
 * 往剪切板添加内容
 * @param value
 * @returns {boolean}
 */
export const clipboard = (value) => {
    if (document.execCommand) {
        const input = document.createElement('input');
        document.body.appendChild(input);
        input.setAttribute('value', value);
        input.select();

        document.execCommand('copy');
        document.body.removeChild(input);

        return true;
    }
    return false;
};

/**
 * 预先加载图片
 * @param {String} src
 * @returns {Promise}
 */
export const preloadImage = src => new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
        resolve(image);
    };
    image.onerror = () => {
        reject(image);
    };
    image.src = src;
});
