import Cookies from 'js-cookie';
import { DOMAIN } from '../constant/other';


Cookies.defaults = {
    path: '/',
    domain: DOMAIN,
    expires: 365
};

export default Cookies;
