import goods from './goods';
import logistics from './logistics';
import promotion from './promotion';
import store from './store';
import message from './message';
import order from './order';
import fbg from './fbg';
import picture from './picture';
import capital from './capital';

export default [
    goods,
    order,
    promotion,
    logistics,
    fbg,
    store,
    message,
    picture,
    capital,
];
