export default {
    title: 'base.menu.fbg.name',
    module: 'fbg',
    submenu: [
        {
            title: 'base.menu.fbg.material.goods',
            path: '/fbg/material'
        },
        {
            title: 'base.menu.fbg.arrival',
            path: '/fbg/arrival',
        },
        {
            title: 'base.menu.fbg.stock',
            path: '/fbg/goodsStock'
        },
        {
            title: 'base.menu.fbg.order',
            path: '/fbg/orders'
        },
    ]
};
