export default {
    title: 'base.menu.logistics.name',
    module: 'logistics',
    submenu: [
        {
            title: 'base.menu.logistics.addressManager',
            submenu: [
                {
                    title: 'base.menu.logistics.returnAddress',
                    path: '/logistics/returnAddressList'
                }
            ]
        },
        {
            title: 'base.menu.logistics.shippingList',
            path: '/logistics/shippingList'
        }
    ]
};
