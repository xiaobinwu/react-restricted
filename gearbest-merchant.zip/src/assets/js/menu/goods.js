export default {
    title: 'base.menu.goods.name',
    module: 'goods',
    submenu: [
        {
            title: 'base.menu.goods.add',
            path: '/goods/add'
        },
        {
            title: 'base.menu.goods.list',
            path: '/goods/list'
        },
        {
            title: 'base.menu.goods.brand',
            submenu: [
                {
                    title: 'base.menu.goods.brandAuth',
                    path: '/goods/brand-auth'
                },
                {
                    title: 'base.menu.goods.brandList',
                    path: '/goods/brand'
                }
            ]
        },
    ]
};
