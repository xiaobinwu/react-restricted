export default {
    title: 'base.menu.store.name',
    module: 'store',
    submenu: [
        {
            title: 'base.menu.store.decorate',
            path: '/store/decorate'
        },
    ]
};
