export default {
    title: 'base.menu.picture.name',
    module: 'picture',
    submenu: [
        {
            title: 'base.menu.picture.album',
            path: '/picture/album'
        }
    ]
};
