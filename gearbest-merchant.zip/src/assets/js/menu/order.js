export default {
    title: 'base.order.title',
    module: 'order',
    submenu: [
        {
            title: 'base.order.list',
            path: '/order/lists'
        },
        {
            title: 'base.order.aftersale',
            path: '/order/aftersale'
        },
        {
            title: '判责列表',
            path: '/order/accountability'
        }
    ]
};
