/**
 * Created by Jiazhan Li on 2019/2/19.
 */

export default {
    title: 'capital.menu.title',
    module: 'capital',
    submenu: [
        // 放款查询
        {
            title: 'capital.menu.loanQuery',
            path: '/capital/loan-query'
        },

        // 订单资金查询
        {
            title: 'capital.menu.orderCapitalQuery',
            path: '/capital/order-capital-query'
        },

        // 结算账单
        {
            title: 'capital.menu.bill',
            path: '/capital/bill-list'
        },

        // 结算账户
        {
            title: 'capital.menu.settlementAccount',
            path: '/capital/settlement-account'
        },

        // 服务资金查询
        {
            title: 'capital.menu.serviceCapitalQuery',
            path: '/capital/service-capital-query'
        },

        // 仓储账单
        {
            title: 'capital.menu.warehouseBill',
            path: '/capital/warehouse-bill-list'
        },

        // 服务账户
        {
            title: 'capital.menu.serviceAccount',
            path: '/capital/service-account'
        },
    ]
};
