export default {
    title: 'base.menu.message.name',
    module: 'message',
    submenu: [
        {
            title: 'base.menu.message.leave',
            path: '/message/leave'
        },
        {
            title: 'base.menu.message.arbitrate',
            path: '/message/arbitrate'
        },
        {
            title: 'base.menu.message.reminder',
            path: '/message/reminder'
        }
    ]
};
