export default {
    title: 'base.nav.home',
    module: 'index',
};
