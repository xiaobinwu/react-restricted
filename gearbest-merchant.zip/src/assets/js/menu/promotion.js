/**
 * Created by Jiazhan Li on 2018/12/27.
 */

export default {
    title: 'base.menu.promotion.name',
    module: 'promotion',
    submenu: [
        {
            title: 'base.menu.promotion.storeActivity',
            path: '/promotion/store-activity'
        }
    ]
};
