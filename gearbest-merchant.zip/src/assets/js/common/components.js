// 按需引入
import {
    Alert,
    Button,
    Checkbox,
    CheckboxGroup,
    Col,
    Dialog,
    Form,
    FormItem,
    Input,
    InputNumber,
    Loading,
    Menu,
    MenuItem,
    MenuItemGroup,
    Message,
    MessageBox,
    Option,
    Popover,
    Radio,
    RadioGroup,
    Row,
    Scrollbar,
    Step,
    Steps,
    Select,
    Submenu,
    TabPane,
    Tabs,
    Tag,
    breadcrumb,
    breadcrumbItem,
    Progress
} from 'element-ui';

import CollapseTransition from 'element-ui/lib/transitions/collapse-transition';
// 其他的组件样式 label-plugin-component 会自动引入
import '@gb/merchant-theme/lib/date-picker.css';
import '@gb/merchant-theme/lib/table.css';
import '@gb/merchant-theme/lib/table-column.css';
import '@gb/merchant-theme/lib/upload.css';
import '@gb/merchant-theme/lib/pagination.css';
import '@gb/merchant-theme/lib/cascader.css';

const components = [
    Alert,
    Button,
    Checkbox,
    CheckboxGroup,
    Col,
    Dialog,
    Form,
    FormItem,
    Input,
    InputNumber,
    Menu,
    MenuItem,
    MenuItemGroup,
    Message,
    MessageBox,
    Option,
    Popover,
    Radio,
    RadioGroup,
    Row,
    Scrollbar,
    Step,
    Steps,
    Select,
    Submenu,
    TabPane,
    Tabs,
    Tag,
    breadcrumb,
    breadcrumbItem,
    CollapseTransition,
    Progress
];

const ElDatePicker = () => import('element-ui/lib/date-picker');
const ElTable = () => import('element-ui/lib/table');
const ElTableColumn = () => import('element-ui/lib/table-column');
const ElUpload = () => import('element-ui/lib/upload');
const ElPagination = () => import('element-ui/lib/pagination');
const ElCascader = () => import('element-ui/lib/cascader');


export default {
    install(Vue) {
        Vue.use(Loading.directive);
        components.forEach((component) => {
            Vue.component(component.name, component);
        });

        // 异步注册比较大的组件
        Vue.component('ElDatePicker', ElDatePicker);
        Vue.component('ElTable', ElTable);
        Vue.component('ElTableColumn', ElTableColumn);
        Vue.component('ElUpload', ElUpload);
        Vue.component('ElPagination', ElPagination);
        Vue.component('ElCascader', ElCascader);

        Vue.prototype.$loading = Loading.service;
        Vue.prototype.$alert = MessageBox.alert;
        Vue.prototype.$confirm = MessageBox.confirm;
        Vue.prototype.$message = Message;
        Vue.prototype.$prompt = MessageBox.prompt;
    }
};
