/**
 * 公共 service
 */

import Service from '../Service';

/**
 * 获取语言包
 * @type {GbService}
 */
export const getRemoteLang = new Service({
    url: '/user/add',
    loading: true,
    method: 'get'
});

/**
 * 图片删除
 */
export const deleteImage = new Service({
    url: '/image-manage/delete-image',
    method: 'post',
    mock: true
});
