<template>
    <div v-loading="true"
         :class="$style.loading"
         element-loading-background="rgba(0, 0, 0, 0)">
    </div>
</template>
<style module>
    .loading {
        position: absolute;
        width: 100%;
        /*height: calc(100vh - 168px);*/
        height: calc(100vh - 200px);
        background-color: transparent;
    }
</style>
