<template>
    <div :class="$style.error">
        <h1>Oops Error...</h1>
    </div>
</template>

<style module>
    .error {
        width: 100%;
        text-align: center;
        padding: 100px 0 0;
        position: absolute;
    }
</style>
