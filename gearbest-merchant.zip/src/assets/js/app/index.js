import Vue from 'vue';
import App from './App';
// 垫片
import '@gb/polyfill';

// 样式
import '@/assets/styles/reset.css';
import '@/assets/styles/iconfont.css';

// 全局通用组件
import components from '@/assets/js/common/components';
import Layout from '@/components/Layout';
import LayoutHeader from '@/components/LayoutHeader';
import LayoutHeaderMain from '@/components/LayoutHeaderMain';
import LayoutHeaderNav from '@/components/LayoutHeaderNav';
import LayoutFooter from '@/components/LayoutFooter';
import LayoutContent from '@/components/LayoutContent';
import LayoutCard from '@/components/LayoutCard';
import Breadcrumb from '@/components/Breadcrumb';
import LayoutSide from '@/components/LayoutSide';

// 多语言
import Lang from '@/assets/js/lang/Lang';

// store
import store from '@/assets/js/store';

Vue.component(Layout.name, Layout);
Vue.component(LayoutHeader.name, LayoutHeader);
Vue.component(LayoutFooter.name, LayoutFooter);
Vue.component(LayoutContent.name, LayoutContent);
Vue.component(LayoutCard.name, LayoutCard);
Vue.component(LayoutHeaderMain.name, LayoutHeaderMain);
Vue.component(LayoutHeaderNav.name, LayoutHeaderNav);
Vue.component(Breadcrumb.name, Breadcrumb);
Vue.component(LayoutSide.name, LayoutSide);

Vue.use(components);
Vue.use(Lang);


// 全局变量 xx
const setGlobaleLang = (langInstance) => {
    if (langInstance instanceof Lang) {
        window.$$lang = langInstance;
    }
};

/**
 * 应用入口
 * @param {Object} options - VueOptions
 */
export default (options) => {
    // 设置全局多语言方法
    setGlobaleLang(options.lang);

    setGlobaleLang();
    new Vue({
        el: '#app',
        store,
        render: h => h(App),
        ...options
    });
};
