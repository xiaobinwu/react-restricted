/**
 * 图片管理模块的多语言 key
 */

export default {

};
