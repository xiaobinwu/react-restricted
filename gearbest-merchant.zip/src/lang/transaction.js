/**
 * 安全密码多语言 key
 */

export default {
    'transaction.menu.editPassword': '设置安全密码',
    'transaction.menu.safeEmail': '发送邮件',
    'transaction.pw': '输入密码',
    'transaction.pw.again': '再次输入密码',
    'transaction.captcha.code': '输入验证码',
    'transaction.hasaccount': '已有账号',
    'transaction.login': '立即登录',
    'transaction.validate.email.empty': '请输入您的电子邮箱地址',
    'transaction.validate.email.maxlength': '电子邮箱地址不能超过50个字符',
    'transaction.validate.email.notlegal': '请输入正确邮箱',
    'transaction.validate.email.exist': '该电子邮件地址已占用',
    'transaction.validate.pw.empty': '密码不能为空',
    'transaction.validate.pw.tooeasy': '密码比较简单，有被盗的危险，数字、字符、字母至少包含其中两种。',
    'transaction.validate.pw.errlength': '密码长度仅限 6 至 16 个字符。',
    'transaction.pw.again.empty': '请再次输入密码',
    'transaction.pw.again.notpass': '密码不一致',
    'transaction.captcha.code.empty': '请输入验证码',
    'transaction.reset.password': '设置安全密码',
    'transaction.reset.new.pw': '新密码',
    'transaction.reset.password.submit': '提交',
    'transaction.reset.password.success': '设置密码成功',
    'transaction.go.capital': '前往资金账户查看',
    'transaction.result.expired': '验证链接已失效',
    'transaction.active.email.sent': '验证邮件已送达 <span class="emailAddress">:#$1#</span>',
    'transaction.active.expire.tip': '请登录邮箱，点击链接，链接在10分钟内有效',
    'transaction.active.toemail': '前往邮箱查看',
    'transaction.active.noemail': '没收到邮件？',
    'transaction.active.sent.again': '再次发送',
    'transaction.active.sent.success': '验证邮件发送成功',

};
