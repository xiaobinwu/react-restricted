/**
 * 店铺多语言 key
 */

export default {
    'store.tabs.custom': '店铺自定义banner',
    'store.tabs.default': '店铺默认banner',
    'store.platform.pc': 'PC端',
    'store.platform.mobile': '移动端',
    'store.upload.browse': '浏览',
    'store.upload.pcTips': '仅支持JPG、GIF格式的图片，图片尺寸必须是1920px * 350px，图片需小于500kb',
    'store.upload.mTips': '仅支持JPG、GIF格式的图片，图片尺寸必须是750px * 300px，图片需小于500kb',
    'store.submit.tips': '注: 点击确定后商城端30分钟左右生效',
    'store.upload.sure': '确定',
    'store.upload.typeError': '仅支持JPG、GIF格式的图片',
    'store.upload.sizeError': '图片必须小于500kb',
    'store.upload.pcAttrError': '图片尺寸必须是 1920px * 350px',
    'store.upload.mAttrError': '图片尺寸必须是 750px * 300px',

    'store.default.template.one': '模板一',
    'store.default.template.seccond': '模板二',
    'store.default.firstLine': '第一行文案',
    'store.default.seccondLine': '第二行文案',
};
