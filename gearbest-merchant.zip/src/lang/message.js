/**
 * 消息管理多语言 key
 */

export default {
    // 消息管理 - 公共
    'message.all': '所有',
    'message.time': '时间',
    'message.search': '搜索',
    'message.confirm': '确定',
    'message.cancel': '取消',
    'message.me': '我',
    'message.system': '系统',
    // 状态
    'message.handleState': '处理状态',
    'message.completed': '已完成',
    'message.replyState': '回复状态',
    'message.replyOk': '已回复',
    'message.replyNo': '未回复',
    // 时间插件
    'message.startTime': '开始日期',
    'message.endTime': '结束日期',
    'message.timeTo': '至',
    // 列表表头
    'message.messageContent': '消息内容',
    'message.orderNumber': '订单号',
    'message.payTime': '付款时间',
    'message.remindTime': '催单时间',
    'message.comeFrom': '来自于',
    // 按钮
    'message.batchReply': '批量回复',
    'message.batchDeletion': '批量删除',
    // 弹窗提示语
    'message.deletTip': '确认删除此消息？',
    'message.enterContent': '请输入留言内容',
    'message.deletErrorTip': '仲裁中消息不允许删除',
    // 其他
    'message.aboutProduct': '关于这个产品',
    'message.aboutOrder': '关于这个订单',

    // 仲裁通知 - 详情
    'message.arbitratedetail.afterSalesDigest': '售后摘要',
    'message.arbitratedetail.orderNumber': '订单编号',
    'message.arbitratedetail.commodityNumber': '商品编号',
    'message.arbitratedetail.ticketNumber': '服务单号',
    'message.arbitratedetail.logisticsMode': '物流方式',
    'message.arbitratedetail.logisticsNumber': '物流单号',
    'message.arbitratedetail.processingState': '处理状态',
    'message.arbitratedetail.serviceType': '服务类型',

    // 催单
    'message.reminder.fromMessage': '来自 :#$1# 的消息',
};
