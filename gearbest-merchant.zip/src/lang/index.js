/**
 * 店铺首页多语言 key
 */

export default {
    'index.tips.welcome': '欢迎使用卖家端后台系统',
    'index.shop.frozen': '店铺冻结中，暂无法正常运营',
    'index.confirm': '确认',
};
