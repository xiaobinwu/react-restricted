/**
 * 通用的多语言 key
 */

export default {
    /**
     * 验证相关
     */
    'base.validate.required': '不能为空',
    'base.validate.length': '限:#$1#字符内',
    'base.validate.number': '限输入数字',
    'base.validate.string': '限输入字符',
    'base.validate.name': '请输入英文字符、数字、连字符或下划线',
    'base.validate.lettersNumbers': '限输入字符和数字',
    'base.validate.range': '可输入范围：:#$1#-:#$2#',
    'base.validate.decimalPoint': '精确到小数点后:#$1#位',
    'base.validate.positiveInteger': '请输入正整数',
    'base.validate.integer': '请输入整数',
    'base.validate.thanInitVal': '应大于初始值',
    'base.validate.imgSize': '图片最大不超过:#$1#',
    'base.validate.imgType': '仅允许上传:#$1#格式图片',

    /**
     * 组件 - Button
     */
    'base.button.back': '返回',
    'base.button.refresh': '刷新',
    'base.button.save': '保存',
    'base.button.notSave': '不保存',
    'base.button.del': '删除',

    /**
     * 组件 - LayoutHeaderMain
     */
    'base.header.shopState': '店铺状态',
    'base.header.shopState1': '未入驻',
    'base.header.shopState2': '未审核',
    'base.header.shopState3': '已拒绝',
    'base.header.shopState4': '已开店',
    'base.header.shopState5': '已封停',
    'base.header.signOut': '退出系统',

    /**
     * 组件 - LayoutHeaderNav
     */
    'base.nav.home': '首页',

    /**
     * 组件 - Breadcurmb
     */
    'base.bread.location': '当前位置',

    /**
     * 组件 - layout-card
     */
    'base.layoutcard.more': '更多',

    /**
     * 组件 - LayoutSide
     */
    'base.menu.index.name': '首页',

    //
    'base.menu.index.shopNotices': '店铺公告',
    'base.menu.index.shopNoticesDetail': '店铺公告详情',
    'base.menu.index.tutorialDetail': '新手教学详情',

    // 商品模块
    'base.menu.goods.name': '商品管理',
    'base.menu.goods.list': '商品列表',
    'base.menu.goods.add': '添加商品',
    'base.menu.goods.brand': '品牌管理',
    'base.menu.goods.brandAuth': '品牌授权列表',
    'base.menu.goods.brandList': '品牌添加列表',
    'base.menu.goods.preview': '商品预览',

    // 物流模块
    'base.menu.logistics.name': '物流管理',
    'base.menu.logistics.addressManager': '地址管理',
    'base.menu.logistics.returnAddress': '退货地址',
    'base.menu.logistics.shippingList': '运费模板',

    // FBG 管理
    'base.menu.fbg.name': 'FBG管理',
    'base.menu.fbg.arrival': '入仓管理',
    'base.menu.fbg.arrival.apply': '入退仓申请',
    'base.menu.fbg.arrival.goods': '入仓商品管理',
    'base.menu.fbg.material.goods': '商品物料管理',
    'base.menu.fbg.stock': 'FBG库存',
    'base.menu.fbg.order': 'FBG订单',

    // 营销管理
    'base.menu.promotion.name': '营销管理',
    'base.menu.promotion.storeActivity': '店铺活动',
    'base.menu.store.name': '店铺管理',
    'base.menu.store.decorate': '店铺banner',
    'base.menu.store.enter': '进入我的店铺',
    'base.menu.promotion.addCoupon': '添加优惠券',
    'base.menu.promotion.addActivity': '创建满立减',
    'base.menu.promotion.viewDetail': '查看详情',
    'base.menu.promotion.viewReport': '查看报告',

    // 资金账户管理
    'capital.menu.title': '资金账户管理',
    'capital.menu.loanQuery': '放款查询',
    'capital.menu.orderCapitalQuery': '订单资金查询',
    'capital.menu.bill': '结算账单',
    'capital.menu.billDetail': '结算账单详情',
    'capital.menu.settlementAccount': '结算账户',
    'capital.menu.capitalReport': '资金明细',
    'capital.menu.serviceCapitalQuery': '服务资金查询',
    'capital.menu.warehouseBill': '仓储账单',
    'capital.menu.warehouseBillDetail': '仓储账单详情',
    'capital.menu.serviceAccount': '服务账户',
    'capital.menu.serviceAccountDetail': '服务账户充值',
    'capital.menu.receivingAccount': '收款账户',
    'capital.menu.withdrawal': '提现',

    // 消息管理
    'base.menu.message.name': '消息管理',
    'base.menu.message.leave': '我的留言',
    'base.menu.message.leavedetail': '消息详情',
    'base.menu.message.arbitrate': '仲裁通知',
    'base.menu.message.arbitratedetail': '仲裁详情',
    'base.menu.message.reminder': '催单通知',

    // 消息管理
    'base.order.title': '订单管理',
    'base.order.list': '订单列表',
    'base.order.details': '订单详情',
    'base.order.deliveryRegistered': '发货登记',
    'base.order.aftersale': '售后处理',
    'base.order.aftersaledetail': '售后详情',

    // 图片管理
    'base.menu.picture.name': '图片管理',
    'base.menu.picture.album': '相册列表',
    'base.menu.picture.albumPhoto': '相册图片',

    // 组件 - 消息记录 MessageLog
    'base.messageLog.msglog': '消息记录',
    'base.messageLog.delete': '删除',
    'base.messageLog.orderNumber': 'Order number',
    'base.messageLog.confirm': '确定',
    'base.messageLog.cancel': '取消',
    'base.messageLog.deletTip': '确认删除此消息？',
    'base.messageLog.nodata': '暂无数据',

    // 组件 - 消息回复 MessageReply
    'base.MessageReply.sendTo': 'Send to',
    'base.MessageReply.orderNumber': 'Order number',
    'base.MessageReply.uploadPictures': '上传图片',
    'base.MessageReply.selectFile': '选择文件',
    'base.MessageReply.noSelectFiles': '未选择任何文件',
    'base.MessageReply.send': '发送',
    'base.MessageReply.overstepLimit': '超出个数限制',
    'base.MessageReply.overstepFileSize': '图片大小最大支持10M',
    'base.MessageReply.fileFormatError': '图片格式错误，支持格式JPG, JPEG, GIF, PNG, BMP。',

    // 组件 - 图片管理
    'base.menu.album.name': '图片管理',
    'base.menu.album.list': '相册详情',

    /**
     * 组件 - NotFound
     */
    'base.notFound.tip': '你好！页面丢失，请检测网络连接或访问地址是否正常，稍后重试。',

    /**
     * 组件 Category
     */
    'base.category-search': '搜索组件'
};
