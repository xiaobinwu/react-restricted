/**
 * 资金账户管理多语言
 * Created by Jiazhan Li on 2019/2/19.
 */

export default {
    'capital.account.collection': '收款账号',
    'capital.account.dollar': '美金账户银行卡',
    'capital.account.payoneer': 'Payoneer(派安盈)账户',
    'capital.account.warning': '您的账户必须要和入驻公司主体一致',
    'capital.collection.validate.errlength': '请输入100个字符以内的信息',

    'capital.bankaccount.no': 'Bank Account No.（银行账号）：',
    'capital.bankaccount.validate.empty': '请输入银行账号',
    'capital.bankaccount.validate.errlength': '请输入100个字符以内的信息',

    'capital.beneficiary.name': 'Beneficiary Name（银行户名）：',
    'capital.beneficiary.validate.empty': '请输入银行户名',

    'capital.bank.name': 'Bank Name（银行名称）：',
    'capital.bankname.validate.empty': '请输入银行名称',

    'capital.bank.swiftcode': 'Swift Code（银行电汇代码）：',
    'capital.swiftcode.validate.empty': '请输入银行电汇代码',

    'capital.bank.address': 'Bank Address（银行地址）：',
    'capital.collectionaddress.prompt': '请输入英文地址',
    'capital.collectionaddress.validate.empty': '请输入英文地址',
    'capital.collectionaddress.validate.errlength': '请输入200个字符以内的信息',

    'capital.bank.postalcode': 'ZIP / Postal Code（邮编)：',
    'capital.postalcode.validate.empty': '请输入邮编',
    'capital.postalcode.validate.errlength': '请输入30字符以内的信息',

    'capital.business.address': 'Business Address（注册地址）：',

    'capital.contact.prompt.phone': '手机号',
    'capital.notify.mobileno': 'Notify Mobile No（联系手机号码）：',
    'capital.notifymobile.validate.empty': '请输入联系手机号码',
    'capital.notifymobile.validate.errlength': '请输入30字符以内的信息',

    'capital.account.scan': 'Beneficiary Account Scan（银行卡账户扫描件）：',
    'capital.account.scan.clickDownload': '点击下载',
    'capital.accountscan.title': '填写信息并加盖公章后上传此扫描件',
    'capital.accountscan.condition': '图片文件大小1MB以内，支持JPG、PNG、GIF、PDF文件格式，最多可上传3张',
    'capital.accountscan.validate.empty': '请上传银行卡账户扫描件',
    'capital.accountscan.validate.errsize': '图片大小不符合！图片大小请保持在1M以内',
    'capital.accountscan.validate.errformat': '图片格式错误！图片支持JPG、PNG、GIF、PDF文件格式',

    'capital.payoneer.go.register': '点击去注册',
    'capital.payoneer.account': 'Payoneer(派安盈)账户：',
    'capital.payoneer.account.title': '如无Payoneer账户可在派安盈官网自己注册',
    'capital.payoneeraccount.validate.empty': '提示请输入payoneer派安盈账户',
    'capital.payoneeraccount.validate.errlength': '请输入50字符以内的信息',

    'capital.payoneer.collectionname': '收款人名称：',
    'capital.payoneer.collectionname.title': '需要注册公司名称一致',
    'capital.collectionname.validate.empty': '提示请输入收款人名称',
    'capital.collectionname.validate.errlength': '请输入50字符以内的信息',

    'capital.payoneer.scan': 'Payoneer账户收款主体截图：',
    'capital.payoneerscan.title': 'Payoneer账户收款主体截图',
    'capital.payoneerscan.condition': '图片文件大小1MB以内，支持JPG、PNG、GIF、PDF文件格式，最多可上传3张',
    'capital.payoneerscan.validate.empty': '请上传Payoneer账户收款主体截图',
    'capital.payoneerscan.validate.errsize': '图片大小不符合！图片大小请保持在1M以内',
    'capital.payoneerscan.validate.errformat': '图片格式错误！图片支持JPG、PNG、GIF、PDF文件格式',
    'capital.payoneer.place.en': '请用英文填写',
    'capital.payoneer.place.number': '支持输入数字',
    'capital.payoneer.place.ennumber': '支持输入英文和数字',
    'capital.payoneer.place.prohibitcn': '请输入Payoneer账号名',
    'capital.payoneer.place.bankno': '请输入银行账号',
    'capital.payoneer.place.bankcode': '请输入银行电汇代码',
    'capital.please.choose': '请选择',
    'capital.please.choose.en': 'Select',
    'capital.account.submitaudit': '提交审核',
    'capital.cancel': '取消',
};
