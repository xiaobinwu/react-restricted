# GB 商家开放平台
##

## 如何运行

### 切换 npm 源
由于项目内依赖了内部的 npm 包，所需先切换 npm 源，具体方法如下：

```bash
npm i nrm -g // 安装 nrm
nrm add fenpm http://fenpm.hqygou.com // 添加内部源
nrm use fenpm // 切换至内部源
```


### 本地开发
``` bash
npm run start
```

### 测试环境构建
``` bash
npm run build
```

### 线上环境构建
``` bash
npm run prod
```

## 本地接口联调
复制 `.env` 文件为 `.env.js`, 将 target 修改为你联调的目标地址
``` js
module.exports = {
    proxyTable: {
        '/devApi': {
            target: `http://10.33.6.164`,
            pathRewrite: { '^/devApi': '' },
            changeOrigin: true,
            secure: false,
        },
    }
};
```

## 文档相关
### 设计稿
1. [蓝狐邀请链接](https://lanhuapp.com/url/3EzlY)
2. [蓝狐地址](https://lanhuapp.com/web/#/item/board?pid=4598be80-1c7f-441e-945c-17dab6b61112)

### 需求原型
1. [卖家首页](https://s7y8nj.axshare.com/)
2. [店铺管理](https://s7y8nj.axshare.com/)
3. [商品管理](https://qvc1zk.axshare.com)
4. [会员模块](https://121clh.axshare.com)
5. [商家入驻](https://121clh.axshare.com)
6. [账号管理](https://2sshha.axshare.com)
7. [营销管理](https://fafihy.axshare.com)
8. [消息管理](https://svc0lr.axshare.com)
9. [订单管理](https://rrhmw2.axshare.com)
10. [物流管理](https://rup8i3.axshare.com)
11. [FBG管理](https://ilxy8t.axshare.com/#g=1)
12. 周边


