/**
 * 多页入口配置
 */

const path = require('path');
const fs = require('fs');

const pagesBasePath = path.resolve(__dirname, '../src/pages/'); // 入口

// 获取 pages 一级目录
exports.getPagesDir = () => fs.readdirSync(pagesBasePath);

// 获取有效的入口模块名
exports.getPagesName = () => {
    const entry = this.getPagesEntry();
    return Object.keys(entry);
};

// 获取 webpack entry
// 默认只获取同目录名.js 文件
exports.getPagesEntry = () => this.getPagesDir().reduce((acc, item) => {
    const fullPath = path.posix.join(pagesBasePath, item, `${item}.js`);

    // 简单判断包含当前目录（goods|promition）
    if (process.env.npm_config_dir) {
        if (fs.existsSync(fullPath) && process.env.npm_config_dir.includes(item)) {
            if (fs.existsSync(fullPath)) {
                acc[item] = fullPath;
            }
        }
    } else if (fs.existsSync(fullPath)) {
        acc[item] = fullPath;
    }
    return acc;
}, {});