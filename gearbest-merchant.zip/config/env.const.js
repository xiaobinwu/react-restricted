const path = require('path');
const render = require('json-templater/string');
const fs = require('fs');
const endOfLine = require('os').EOL;

const env = process.env.npm_lifecycle_script.split(' ').find(argv => argv.includes('--env'));
const constEnv = env ? env.split('=')[1] : 'dev';
const config = require('../env.const')[constEnv];

console.log('[生成', constEnv, '环境常量文件]');

const OUTPUT_PATH = path.join(__dirname, '../src/assets/js/constant/env.js');
const MAIN_TEMPLATE = `
/**
* 项目环境常量 - 由 config/env.const 根据根目录 env.const.js 生成
*/
{{constant}}
`;
const EXPORT_TEMPLATE = "export const {{name}} = '{{value}}';";

const constantTemplate = [];

Object.keys(config).forEach(name => {
    constantTemplate.push(
        render(EXPORT_TEMPLATE, {
            name,
            value: config[name]
        })
    );
});

fs.writeFileSync(
    OUTPUT_PATH,
    render(MAIN_TEMPLATE, {
        constant: constantTemplate.join(endOfLine)
    })
);

console.log('[生成环境常量文件完成]');
