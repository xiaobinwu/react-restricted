/**
 * 公共模块配置
 */

const webpack = require('webpack');
const path = require('path');
const pages = require('./pages');
// const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

const resolve = _path => path.resolve(__dirname, '../', _path);

const chunks = {
    // 偶尔会变但是又通用的模块
    common: [
        resolve('src/assets/js/common/components.js')
    ],
    // 稳定不变的模块
    lib: [
        'vue',
        'vue-router',
        'vuex',
        '@gb/polyfill',
        '@gb/http'
    ]
};

// 生成 chunks name
exports.getChunksName = () => Object.keys(chunks).filter(item => !!chunks[item].length);

// 生成 chunks 入口
exports.getChunksEntry = (name) => {
    if (name) return chunks[name];
    // 过滤掉为空的 chunks 配置
    return this.getChunksName().reduce((acc, item) => {
        acc[item] = chunks[item];
        return acc;
    }, {});
};

// 提取公共模块
exports.generateCommonsChunk = () => {
    const names = this.getChunksName();

    return [
        // 分析打包依赖
        // new BundleAnalyzerPlugin(),
        // 从所有 pages 里抽离公共代码
        new webpack.optimize.CommonsChunkPlugin({
            name: 'vendor',
            minChunks: 2,
            chunks: pages.getPagesName()
        }),
        // 抽离手动指定的 commons chunks
        new webpack.optimize.CommonsChunkPlugin({
            names: [...names, 'runtime'],
            minChunks: Infinity
        }),
        // 抽离异步代码
        new webpack.optimize.CommonsChunkPlugin({
            name: 'app',
            async: 'children-chunks',
            children: true,
            minChunks: 1
        })
    ];
};
