/**
 * css module 控制
 */

// https://github.com/webpack-contrib/css-loader
module.exports = {
    localIndentName: '[name]_[local]--[hash:base64:5]',
    camelCase: true
};