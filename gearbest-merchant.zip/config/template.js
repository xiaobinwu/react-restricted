const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const pages = require('./pages');
const chunks = require('./chunks');

const outputs = process.env.npm_lifecycle_script.split(' ').find(argv => argv.includes('--outputdir'));
const outputdir = outputs ? outputs.split('=')[1] : '/';

// 生成 HTML 入口文件
exports.generateTemplates = (options) => {
    const entry = pages.getPagesName();
    const chunksName = chunks.getChunksName();

    return entry.map((name) => {
        // const filename = process.env.NODE_ENV === 'production' ? path.resolve(__dirname, `..${outputdir}/${name}/index.html`) : `${name}/index.html`;
        const filename = process.env.NODE_ENV === 'production' ? path.resolve(__dirname, `..${outputdir}/${name}.html`) : `${name}.html`;

        // https://github.com/ampedandwired/html-webpack-plugin
        return new HtmlWebpackPlugin({
            template: 'index.html',
            chunks: [...chunksName, 'vendor', 'runtime', name],
            chunksSortMode: 'dependency',
            inject: true,
            filename,
            ...options
        });
    });
};
