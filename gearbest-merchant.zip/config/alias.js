/**
 * 项目 assets 目录 alias 别名配置
 */

const path = require('path');
const pages = require('./pages');

const resolve = _path => path.resolve(__dirname, '../', _path);


// 页面 alias
// eg: @goods => src/pages/goods
exports.getPagesAlias = () => {
    return pages.getPagesDir().reduce((acc, item) => {
        const prefix = `@${item}`;
        acc[prefix] = resolve(`src/pages/${item}`);
        return acc;
    }, {});
};
