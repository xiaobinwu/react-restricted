// Template version: 1.3.1
// see http://vuejs-templates.github.io/webpack for documentation.

const path = require('path');
const { existsSync } = require('fs');

let envJson = {
    proxyTable: {},
};

if (existsSync(path.join(__dirname, '../.env.js'))) {
    envJson = require('../.env.js');
} else {
    console.log('[仅开发环境]: 丢失 .env.js文件\n');
}

const env = process.env.npm_lifecycle_script.split(' ').find(argv => argv.includes('--env'));
const constEnv = env ? env.split('=')[1] : 'dev';

const envConfig = require('../env.const');
const CND_IMG = envConfig[constEnv].CDN_IMG;

// 默认 proxyTable 其它通过 .env.js 配置，在开发过程中直接和对接后端人员对接
const defaultProxy = {
    '/devApi': {
        target: 'https://seller.gearbest.net', // 需要配置 host 10.40.2.132
        pathRewrite: { '^/devApi': '' },
        changeOrigin: true,
        secure: false
    },
    '/captcha': {
        target: 'https://seller.gearbest.net',
        changeOrigin: true,
        secure: false
    },
    '/image-manage/image-upload': {
        target: 'https://seller.gearbest.net',
        changeOrigin: true,
        secure: false
    },
    '/image-manage/logo-upload': {
        target: 'https://seller.gearbest.net',
        changeOrigin: true,
        secure: false
    },
    '/order/accountability/attachment/upload': {
        target: 'https://seller.gearbest.net',
        changeOrigin: true,
        secure: false
    },
    '/imagemanage/anonymous-upload': {
        target: 'https://seller.gearbest.net',
        changeOrigin: true,
        secure: false
    },
};

// 调整 cookie 域名
function setSameOriginCookie(proxyParams, host) {
    Object.entries(proxyParams).forEach(([key, value]) => {
        value.onProxyRes = (proxyRes) => {
            const cookies = proxyRes.headers['set-cookie'];
            // 修改cookie Domain
            if (cookies) {
                const newCookie = cookies.map(cookie => cookie.replace(/domain=.*;/i, `domain=${host};`));
                // 修改cookie path
                proxyRes.headers['set-cookie'] = newCookie;
            }
        };
    });

    return proxyParams;
}

// host
const host = 'localhost';

// build or prod?
const outputs = process.env.npm_lifecycle_script.split(' ').find(argv => argv.includes('--outputdir'));
const outputdir = outputs ? outputs.split('=')[1] : '/';

module.exports = {
    // 开发环境
    dev: {
        // Paths
        assetsSubDirectory: 'static',
        assetsPublicPath: CND_IMG,
        proxyTable: {
            ...setSameOriginCookie(defaultProxy, host),
            ...setSameOriginCookie(envJson.proxyTable, host)
        },

        // Various Dev Server settings
        host, // can be overwritten by process.env.HOST
        port: 8080, // can be overwritten by process.env.PORT, if port is in use, a free one will be determined
        autoOpenBrowser: true,
        errorOverlay: true,
        notifyOnErrors: true,
        poll: false, // https://webpack.js.org/configuration/dev-server/#devserver-watchoptions-

        // Use Eslint Loader?
        // If true, your code will be linted during bundling and
        // linting errors and warnings will be shown in the console.
        useEslint: true,
        // If true, eslint errors and warnings will also be shown in the error overlay
        // in the browser.
        showEslintErrorsInOverlay: false,

        /**
         * Source Maps
         */

        // https://webpack.js.org/configuration/devtool/#development
        devtool: 'cheap-module-eval-source-map',

        // If you have problems debugging vue-files in devtools,
        // set this to false - it *may* help
        // https://vue-loader.vuejs.org/en/options.html#cachebusting
        cacheBusting: true,

        cssSourceMap: true
    },

    // 生产环境
    build: {
        // Template for index.html
        // index: path.resolve(__dirname, '../dist/index.html'),

        // Paths
        assetsRoot: path.resolve(__dirname, `..${outputdir}`), // ../public/dist or ../public/prod
        assetsSubDirectory: 'static',
        assetsPublicPath: CND_IMG,

        /**
         * Source Maps
         */

        productionSourceMap: false,
        // https://webpack.js.org/configuration/devtool/#production
        devtool: '#source-map',

        // Gzip off by default as many popular static hosts such as
        // Surge or Netlify already gzip all static assets for you.
        // Before setting to `true`, make sure to:
        // npm install --save-dev compression-webpack-plugin
        productionGzip: false,
        productionGzipExtensions: ['js', 'css'],

        // Run the build command with an extra argument to
        // View the bundle analyzer report after build finishes:
        // `npm run build --report`
        // Set to `true` or `false` to always turn it on or off
        bundleAnalyzerReport: process.env.npm_config_report
    }
};
