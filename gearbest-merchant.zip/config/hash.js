/**
 * 静态文件 hash 控制
 */

const hash = {
    status: true,
    fileHash: true,
    dateHash: false, 
    length: 5
};

const dateNow = Date.now();

exports.getFileName = (name, ext, hashType) => {
    // 未开启 hash 版本
    if (!hash.status) {
        return `${name}.${ext}`;
    }

    if (hash.fileHash) {
        return `${name}.[${hashType}:${hash.length}].${ext}`;
    }

    if (hash.dateHash) {
        return `${name}.${dateNow}.${ext}`;
    }
};