import $ from 'jquery';
import './test.css';
import '../select.js';

$('.js-select').select({
    skin: 'select-custom', // 添加自定义 class 属性
    maxHeight: 300, // 下拉列表的最大高度，默认为300px
    searchable: true, // 是否可搜索，默认为 false
});

$('fieldset').on('click', 'a', (e) => {
    const opera = $(e.currentTarget).data('opera');

    if (opera === 'getValue') {
        console.log($('.js-select').select('getValue'));
    } else if (opera === 'setValue') {
        $('.js-select').select('setValue', 2);
    } else if (opera === 'getText') {
        console.log($('.js-select').select('getText'));
    } else if (opera === 'disable') {
        $('.js-select').select('disable');
    } else if (opera === 'enable') {
        $('.js-select').select('enable');
    } else if (opera === 'update') {
        $('.js-select').append('<option value="100">这是新添加的数据</option>');
        $('.js-select').select('update');
    }
});
