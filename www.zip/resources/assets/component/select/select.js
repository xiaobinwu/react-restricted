/*
 * name: select（下拉列表）
 * author: zaki
 * date: 2017/11/29
 *
 ******************************** 《简介》 ********************************

    1. 组件依赖 "jquery.js" 插件。
    2. 组件依赖 "dropdown.js" 组件。

 ******************************** 《html》 ********************************
    <!-- exp1 -->
    <select class="selector">
        <option value="1">one</option>
        <option value="2">two</option>
        <option value="3">three</option>
    </select>

    <!-- exp2 -->
    <select class="selector" data-skin="custom-class">
        <option value="1">one</option>
        <option value="2">two</option>
        <option value="3" selected>three</option>
    </select>

 ******************************** 《调用方式》 ********************************

    demo1: $('.selector').select();               // 普通初始化 (参数取默认值)
    demo2: $('.selector').select('disable');      // 设置不可用
    demo3: $('.selector').select('enable');       // 设置可用
    demo5: $('.selector').select('update');       // 更新数据
    demo6: $('.selector').select('getValue');     // 获取选中的值
    demo7: $('.selector').select('getText');      // 获取选中的文本
    demo8: $('.selector').select('setValue', 1);  // 设置某值选中

    demo9: 初始化带参数
    $('.selector').select({
        skin: 'select-custom',      // 添加自定义 class 属性
        maxHeight: 300,             // 下拉列表的最大高度，默认为300px
        searchable: true,           // 是否可搜索，默认为 false
        vagueSearch: false,         // 是否启用模糊搜索
    });

 */
import 'component/dropdown/dropdown.js';
import $ from 'jquery';
import render from './select.art';
import './select.css';

/**
 * 节流阀函数（当多次执行待封装的函数时，为了节约性能，函数将在一次间隔时间内最多执行一次）
 * @param  [Function] func 待封装的函数
 * @param  [Number] wait 间隔时间
 * @param  [Boolean] immediate 如果为 true，函数会在一开始执行一次
 * @return [Function] 返回封装后的函数
 * @author lijiazhan
 */
function debounce(func, wait, immediate) {
    let timeout;
    let args;
    let context;
    let timestamp;
    let result;

    function later() {
        const last = new Date() - timestamp;

        if (last < wait && last >= 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            if (!immediate) {
                result = func.apply(context, args);
                args = null;
                context = args;
            }
        }
    }

    return (...params) => {
        context = this;
        args = params;
        timestamp = new Date();
        const callNow = immediate && !timeout;
        if (!timeout) timeout = setTimeout(later, wait);
        if (callNow) {
            result = func.apply(context, args);
            args = null;
            context = args;
        }
        return result;
    };
}

const SELECTCACHE = {}; // 缓存字典

window.SELECTCACHE = SELECTCACHE;

const SELECT = {
    /**
     * 初始化组件
     */
    init($select, params) {
        const $self = $select;

        $self.hide(); // 隐藏原select元素

        // 生成模型容器
        const $model = $(render({ tempType: 'basic' }));
        $self.before($model);
        $self.model = $model;

        // 生成 KEY，并添加到缓存变量
        const KEY = `SELECT${Math.floor(Math.random() * 10000000)}`;
        $self.KEY = KEY;
        $self.data('key', KEY);
        SELECTCACHE[KEY] = $self;

        // 激活下拉菜单组件
        const $dropdown = $model.children('.select_inner');
        $self.dropdown = $dropdown;
        $dropdown.dropdown({
            onOpen: () => {
                if ($self.config.searchable) {
                    $model.find('.select_input').val('');
                    $model.find('.select_option').removeClass('hide');
                }

                if (typeof $self.config.onDropdownOpen === 'function') {
                    $self.config.onDropdownOpen();
                }
            },
            onClose() {
                if (typeof $self.config.onDropdownClose === 'function') {
                    $self.config.onDropdownClose();
                }
            }
        });

        // 定义组件事件
        $model.on('click', '.select_option', function() { // eslint-disable-line
            const $this = $(this);

            if ($this.hasClass('disabled')) return false; // 对 disabled 的选项点击无效

            const $title = $model.find('.select_title');
            const index = $this.data('index');
            $self.find('option').eq(index).prop('selected', true); // 操作原DOM元素

            // 标记选项
            if (!$model.curOption) {
                $model.curOption = $model.find('.select_option.selected');
            }
            $model.curOption.removeClass('selected');
            $model.curOption = $this.addClass('selected');

            $title.text($this.text());
            $dropdown.dropdown('close');
            $self.trigger('change');
        });

        // 过滤选项
        $model.on('input', '.select_input', debounce((e) => {
            const key = $(e.target).val().toLowerCase();
            if ($self.config.searchable) {
                if ($self.config.searchable === true) {
                    // 搜索全部
                    SELECT.setFilterOptions($model.find('.select_option'), key, $self.config.vagueSearch);
                } else {
                    const curGroupArr = [].concat($self.config.searchable);

                    // 默认搜索不包含分组数据
                    SELECT.setFilterOptions($model.find('.select_scrollInner>.select_option'), key, $self.config.vagueSearch);

                    // 分组搜索
                    $model.find('.select_optgroup').each((index, element) => {
                        // 配置从1开始，包含搜索的分组
                        if (curGroupArr.indexOf(index + 1) > -1) {
                            $(element)[
                                SELECT.setFilterOptions($(element).find('.select_option'), key, $self.config.vagueSearch) ? 'addClass' : 'removeClass'
                            ]('hide');
                        } else {
                            $(element)[!key ? 'removeClass' : 'addClass']('hide');
                        }
                    });
                }
            }
        }, 100));

        // 组件的 DOM 节点被移除时释放内存
        $self.on('DOMNodeRemovedFromDocument', () => {
            $self.Select('clean');
        });

        $self.Select = (args) => {
            if (typeof args[0] !== 'string') return $self;
            if (args[0] === 'getValue') {
                return $self.val();
            } else if (args[0] === 'getText') {
                return $self.find('option').eq($self[0].selectedIndex).text();
            } else if (args[0] === 'update') {
                SELECT.update($self, params);
            } else if (args[0] === 'disable') {
                SELECT.setDisable($self);
            } else if (args[0] === 'enable') {
                SELECT.setEnable($self);
            } else if (args[0] === 'clean') {
                delete SELECTCACHE[$self.KEY];
                $dropdown.dropdown('clean');
            } else if (args[0] === 'setValue' && args[1] !== undefined) {
                $self.val(args[1]);
                SELECT.update($self, params);
            }
            return $self;
        };

        SELECT.update($self, params);

        return $self.Select(params);
    },

    /**
     * 设置filter元素状态
     * @param elements [jquery]
     * @param key [String] 搜索词
     * @returns {boolean}
     */
    setFilterOptions(elements, key, vagueSearch) {
        let removeCount = 0;
        elements.each((i, elem) => {
            const $this = $(elem);
            if ((vagueSearch ? $this.data('text').indexOf(key) >= 0 : $this.is(`[data-text^=${key}]`)) || !key) {
                $this.removeClass('hide');
            } else {
                $this.addClass('hide');
                removeCount += 1;
            }
        });

        return removeCount === elements.length;
    },

    /**
     * 设置不可用
     */
    setDisable($select) {
        $select.prop('disabled', true);
        $select.dropdown.dropdown('disable');
    },


    /**
     * 设置可用
     */
    setEnable($select) {
        $select.prop('disabled', false);
        $select.dropdown.dropdown('enable');
    },


    /**
     * 更新组件
     */
    update($select, params) {
        const $self = $select;
        const $model = $self.model;

        // 组件默认配置
        $self.config = $self.config || {
            skin: '', // 自定义class
            maxHeight: 300, // 菜单最大高度
            searchable: false, // 是否可搜索
            vagueSearch: false, // 是否模糊搜索
            onDropdownOpen: $.noop, // 开启下拉列表
        };

        const { config } = $self;

        if (typeof params[0] === 'object') {
            Object.assign(config, params[0]); // 扩展组件配置
        }

        // 渲染菜单列表项
        let optionIndex = -1;
        let optgroupIndex = -1;
        const getOptionHtml = options => options.map((opt) => {
            const $opt = $(opt);
            if (opt.nodeName.toLowerCase() === 'optgroup') {
                optgroupIndex += 1;
                return `<div class="select_optgroup select_optgroup-${optgroupIndex}">${getOptionHtml([...$opt.children()])}</div>`;
            } else if (opt.nodeName.toLowerCase() === 'option') {
                const selected = $opt.is(':selected') ? 'selected' : '';
                const disabled = $opt.is(':disabled') ? 'disabled' : '';
                optionIndex += 1;
                return `<div class="select_option ${selected} ${disabled}" 
                    data-index="${optionIndex}" 
                    data-value="${$opt.attr('value')}" 
                    data-text="${$opt.text().toLowerCase().trim()}">${$opt.text()}</div>`;
            }
            return '';
        }).join('');

        $model.find('.select_menu').html(render({
            tempType: 'menu',
            searchable: config.searchable,
            content: getOptionHtml([...$self.children()]),
        }));

        // 设置最大高度
        $model.find('.select_scrollWrap').css('max-height', config.maxHeight);

        $model.find('.select_title').html($self.find('option').filter(':selected').text());
        // 添加自定义class
        const skin = $self.data('skin');
        if (skin) $model.addClass(skin);
        if (config.skin) $model.addClass(config.skin);

        $model.curOption = null; // 重置该值

        return $self;
    },
};


/**
 * 定义插件
 * @param  {Object} params 组件参数
 */
$.fn.select = function(...params) { // eslint-disable-line
    if (this.length === 0) return this;

    // 支持批量操作
    if (this.length > 1) {
        this.each(function() { // eslint-disable-line
            $(this).select(...params);
        });
        return this;
    }

    const $self = this; // select 元素（本尊）

    // 判断组件是否被初始化过
    const key = $self.KEY || $self.data('key');
    if (key in SELECTCACHE) {
        if (typeof params[0] === 'object') {
            return SELECT.update(SELECTCACHE[key], params);
        } else if (typeof params[0] === 'string') {
            return SELECTCACHE[key].Select(params);
        }
        return $self;
    }

    return SELECT.init($self, params);
};
