import '../radio.css';
import Radio from '../radio.js';

console.log(new Radio());

