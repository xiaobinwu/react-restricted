import './radio.css';

class Radio {
    constructor(dom) {
        this.dom = dom;
    }
}
export default Radio;
