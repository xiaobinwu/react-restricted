import Vue from 'vue';
import { trans } from 'js/core/translate.js';
import { getCurrency, } from 'js/core/currency';
import {
    currencyCeil,
    onePrice,
    getTotal,
} from 'paycart/currencyRule.js';
import tinyLazy from './tinyLazy';
import App from './tinyCart.vue';

import './tinyCart.css';

Vue.use(tinyLazy);

Vue.prototype.$trans = trans;

Vue.prototype.$bus = new Vue();

Vue.prototype.remainderRule = {
    currencyCeil,
    onePrice,
    getTotal,
};

Vue.prototype.currencyCeil = Vue.prototype.remainderRule.currencyCeil;

// 向上取整
Vue.filter('currencyCeil', (...arg) => Vue.prototype.remainderRule.currencyCeil.apply(null, [...arg]));

// 单个价格(arg[2] == 0 时向下取整， 默认向上取整)
Vue.filter('$remainder_one', (...arg) => {
    const round = arg[2] === undefined ? 2 : +arg[2];
    return Vue.prototype.remainderRule.onePrice.call(null, arg[1], round);
});

// 价格求和
Vue.filter('$remainder_sum', (...arg) => Vue.prototype.remainderRule.getTotal.call(null, arg[1]));

const vueTinyCart = async () => {
    const currency = await getCurrency();
    return new Vue({
        data: {
            currency,
            cartPath: $('#cartPath').val(),
            currenySign: currency.currencyCode
        },
        render: h => h(App),
    }).$mount('#js-tinyCartBox');
};

export default vueTinyCart;
