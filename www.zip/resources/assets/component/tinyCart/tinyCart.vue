<template lang="pug">
    .tinycart
        .tinycart_head
            i.icon-close(@click="closeTinyCart")
            a.view_my_bag(:href="cartPath", target="_special") {{ $trans('base.view_my_bag') }}

        //- loading
        .headCart_dataLoading.panel-loading(v-show="empty === -1")

        //- 购物车为空
        .tinyEmpty(v-show="empty === 1")
            p {{ $trans('base.cart_empty') }}
            p.nologin(v-if="!isLogin", v-html="$trans('base.cart_nologin', [`${DOMAIN_LOGIN}/m-users-a-register.htm?type=1`, `${DOMAIN_LOGIN}/m-users-a-sign.htm?type=1`])")

        .tinycart_body(v-show="empty === 0")
            //- 满额免邮信息
            .freeShipRule
                .freeShipTip(v-if="freeShipRule.feeShippingDiff !== undefined", v-html="freeShipRule.feeShippingDiff === 0 ? $trans('base.free_ship_y') : $trans('base.free_ship_n', [freeShipRule.feeShippingDiff || 0, currencyCeil(currency, freeShipRule.feeShippingDiff || 0), freeShipRule.logisticsName || ''])")
                .freeShipTip(v-else, v-html="$trans('base.free_ship_empty')")
                .freeShipBar
                    p.freeShipTrail(:style="{width:`${freeShipRule.feeShippingDiff !== undefined ? 100 - (freeShipRule.feeShippingDiff / freeShipRule.freePrice || 0) * 100 : 0}%`}")
            //- 列表信息
            .tinycart_list(ref="scrollbar")
                .ss-wrapper
                    .ss-content(v-tinylazy-contain="{ 'selector': 'tiny_img', 'scrollItem' : 'tiny_groups', 'maxheight': 390 }")
                        tinygroup(v-for="(goods, index) in goodsList", :key="goods.itemId", :goods="goods", :activityList="activityList")

            .tinycart_checkout
                .grand_total {{ $trans('base.grand_total') }}
                    span.grand_price {{ currency | $remainder_sum({ prices: selectedTotal.amount, discounts: selectedTotal.discount }) }}
                a.checkout_btn(href="javascript:;", @click="checkout('cc')") {{ $trans('base.cart_checkout') }}
</template>

<script>
    import layer from 'layer';
    import {
        serviceCartSelect,
        serviceCartSaveActs,
    } from 'js/service/paycart';
    import { isLogin } from 'js/core/user';
    import { serviceSampleCart } from 'js/service/common';
    import { closeTinyCart } from 'js/core/goods/cart.js';
    import SimpleScrollbar from 'lib/simple-scrollbar/simple-scrollbar.js';
    import tinygroup from './components/tinygroup.vue';

    const { DOMAIN_LOGIN, DOMAIN_ORDER } = window.GLOBAL;

    export default {
        data() {
            return {
                empty: -1, // 0: 购物车不为空 1: 购物车为空
                goodsList: [],
                isLogin: false,
                cartPath: this.$root.cartPath,
                DOMAIN_LOGIN,
                DOMAIN_ORDER,
                selectedTotal: {
                    floorPrice: {}, // 减免字段
                    discount: [], // 减免金额
                    amount: [], // 勾选商品单价数组
                },
                total: { // 价格总计
                    goodsAmount: 0,
                    settleAmount: 0,
                    discountAmount: 0,
                },
                freeShipRule: {},
                activityList: {},
                lastLength: 0,
            };
        },
        components: {
            tinygroup,
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        async created() {
            this.$bus.$on('updatelist', () => {
                this.getCartList();
            });
            this.$bus.$on('selectGoods', ({ checked, itemId }) => {
                this.goodSelect(checked, itemId);
            });

            // 判断用户是否登录
            this.isLogin = await isLogin();

            // 默认请求购物车列表
            this.getCartList('init');

        },
        methods: {
            async getCartList() {
                const vm = this;
                let listLength = 0;

                const { status, data } = await serviceSampleCart.http();

                if (status === 0) {
                    const selectedDiscount = [];
                    const { goodsList, freeShipRule, activityList } = data;

                    if (activityList && activityList.length) {
                        activityList.forEach((act) => {
                            vm.activityList[act.activityId] = act;
                        });
                    }

                    if (goodsList && goodsList.length) {
                        listLength = goodsList.length;

                        vm.selectedTotal = {
                            floorPrice: {},
                            discount: [], // 减免金额
                            amount: [], // 勾选商品单价数组
                        };

                        vm.goodsList = goodsList;

                        // 免邮减免优惠
                        vm.freeShipRule = freeShipRule;

                        vm.goodsList.forEach((goods) => {

                            // 配件
                            const { accessoryList } = goods;
                            if (accessoryList.length) {
                                listLength += accessoryList.length;
                            }

                            if (goods.isSelected) {

                                // 定金膨胀优惠金额
                                if (goods.skuAdvanceDetail) {
                                    vm.selectedTotal.amount.push({
                                        price: goods.skuAdvanceDetail.advanceAmount,
                                        Qty: goods.qty
                                    });

                                    if (goods.qty > goods.buyLimit) {
                                        layer.msg(vm.$trans('cart.canot_add_number', [goods.buyLimit]));
                                    }
                                } else {
                                    // 价格计算
                                    goods.priceList.forEach((item) => {
                                        vm.selectedTotal.amount.push({
                                            price: item.price,
                                            Qty: item.qty
                                        });
                                        if (item.activityDeductAmount > 0) {
                                            selectedDiscount.push(item.activityDeductAmount);
                                        }
                                    });
                                }

                                // 配件
                                if (accessoryList.length) {
                                    accessoryList.forEach((access) => {
                                        if (access.isSelected) {
                                            // 定金膨胀优惠金额
                                            if (access.skuAdvanceDetail) {
                                                vm.selectedTotal.amount.push({
                                                    price: access.skuAdvanceDetail.advanceAmount,
                                                    Qty: access.qty
                                                });

                                                if (access.qty > access.buyLimit) {
                                                    layer.msg(vm.$trans('cart.canot_add_number', [goods.buyLimit]));
                                                }
                                            } else {
                                                // 价格计算
                                                access.priceList.forEach((item) => {
                                                    vm.selectedTotal.amount.push({
                                                        price: item.price,
                                                        Qty: item.qty
                                                    });
                                                    if (item.activityDeductAmount > 0) {
                                                        selectedDiscount.push(item.activityDeductAmount);
                                                    }
                                                });
                                            }
                                        }
                                    });
                                }
                            }
                        });

                        // 取 pricelist中， 单个商品的活动优惠金额相加后进行多币种换算向下取整
                        vm.selectedTotal.discount.push(...selectedDiscount);

                        vm.$nextTick(() => {
                            const simpleScrollbar = SimpleScrollbar.initEl(vm.$refs.scrollbar);

                            if (listLength <= 3) {
                                // 隐藏滚动条
                                simpleScrollbar.hide();
                            } else if (vm.lastLength <= 3 && listLength > 3) {
                                // 重置滚动条高度
                                simpleScrollbar.reset();
                            }
                            vm.lastLength = listLength;
                        });

                        vm.empty = 0;
                    } else {
                        vm.empty = 1;
                    }
                } else {
                    vm.empty = 1;
                }

                // 更新购物车数量
                $('.js-cartNum').text(listLength);
            },
            closeTinyCart() {
                closeTinyCart();
            },
            // 勾选
            async goodSelect(checked, itemId) {
                let isMainSelect = 1;

                this.goodsList.forEach((goods) => {
                    if (goods.itemId === itemId) {
                        goods.isSelected = checked;
                    }

                    if (goods.accessoryList.length) {
                        goods.accessoryList.forEach((access) => {
                            if (access.itemId === itemId) {
                                if (checked && !goods.isSelected) {
                                    isMainSelect = 0;
                                } else {
                                    access.isSelected = checked;
                                }
                            }
                        });
                    }
                });
                if (!isMainSelect) {
                    layer.msg(this.$trans('cart.check_main_first'));
                    return;
                }
                const { status, msg } = await serviceCartSelect.http({
                    data: {
                        isSelected: checked,
                        itemId,
                    },
                });

                // update list
                this.getCartList();

                if (status !== 0) {
                    layer.msg(msg);
                }
            },
            // checkout_btn
            async checkout() {
                const vm = this;
                let itemList = [];
                // 定金膨胀
                let skuAdvanceDetail = false;

                vm.goodsList.forEach((goods) => {
                    if (goods.isSelected) {
                        if (goods.skuAdvanceDetail) {
                            skuAdvanceDetail = true;
                        }
                        itemList.push({
                            itemId: goods.itemId,
                            activityId: goods.activityId
                        });

                        const { accessoryList } = goods;

                        if (accessoryList.length) {
                            accessoryList.forEach((access) => {
                                if (access.isSelected) {
                                    itemList.push({
                                        itemId: access.itemId,
                                        activityId: access.activityId
                                    });
                                }
                            });
                        }
                    }
                });

                if (itemList.length === 0) {
                    return layer.msg(vm.$trans('cart.check_one_least'));
                }

                itemList = [];

                vm.goodsList.forEach((goods) => {
                    if (goods.isSelected && goods.activityId > 0 && vm.activityList[goods.activityId].joined) {
                        if (goods.skuAdvanceDetail) {
                            skuAdvanceDetail = true;
                        }
                        itemList.push({
                            itemId: goods.itemId,
                            activityId: goods.activityId
                        });

                        const { accessoryList } = goods;

                        if (accessoryList.length) {
                            accessoryList.forEach((access) => {
                                if (access.isSelected) {
                                    itemList.push({
                                        itemId: access.itemId,
                                        activityId: access.activityId
                                    });
                                }
                            });
                        }
                    }
                });

                layer.load();
                // 提交商品列表
                const res = await serviceCartSaveActs.http({
                    data: {
                        itemList
                    }
                });

                if (res.status === 0) {
                    const doc = document;
                    const formEl = doc.createElement('form');
                    const isDeposit = skuAdvanceDetail ? '?isDeposit=1' : '';
                    formEl.method = 'post';
                    formEl.action = `${GLOBAL.DOMAIN_ORDER}/checkout/index${isDeposit}`;
                    doc.body.appendChild(formEl);
                    formEl.submit();
                } else {
                    layer.closeAll('loading');

                    layer.msg(
                        res.msg, { time: 1500, },
                        () => {
                            setTimeout(() => window.location.reload(), 1000);
                        }
                    );
                }

                return false;
            },
        }
    };
</script>
