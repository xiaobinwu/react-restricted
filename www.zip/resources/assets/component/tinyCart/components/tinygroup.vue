<template lang="pug">
.tiny_groups
    .tiny_item
        checkbox(v-if="goods.allowBuy && goods.stockNum > 0 && goods.goodType != 2 && goods.goodType != 21", :checked="goods.isSelected", :itemId="goods.itemId", :goodsType="goods.goodsType")
        a.tiny_goods.icon-loading(:href="goods.linkUrl", target="_special")
            img.tiny_img(src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", :data-id="goods.itemId", :data-img="goods.goodImg")
            .cart_imgText(v-if="goods.goodType === 1") {{ $trans('cart.act_tag_accessory') }}
            .cart_imgText(v-if="goods.goodType === 2 || goods.goodType === 21") {{ $trans('cart.act_tag_gift') }}
            .cart_imgText(v-if="goods.goodType === 3") {{ $trans('cart.act_tag_addon') }}

        .cart_info
            a.cart_link(:href="goods.linkUrl", target="_special") {{goods.goodTitle}}
            i.icon-close(v-if="goods.goodType != 21", @click="deleteGoods(goods.itemId)")

            p.cart_attrBox(v-for="(row, rowIndex) in goods.attr", :key="rowIndex")
                span.cart_attr {{row.name | capitalize}}:
                |  {{row.value}}

            changeStock(:goods="goods", :parentData="parentData", :activity="goods.activityId ? activityList[goods.activityId] : {}")
            p.cart_price {{currency | $remainder_one(goods.price)}}

    tinygroup(v-if="goods.accessoryList && goods.accessoryList.length > 0", v-for="(parts, partsIndex) in goods.accessoryList", :key="goods.itemId", :goods="parts", :parentData="goods")
</template>

<script>

    import { serviceCartDelete, } from 'js/service/paycart';
    import checkbox from 'paycart/component/cart-v2/checkbox.vue';
    import changeStock from './change_stock';

    export default {
        name: 'tinygroup',
        data() {
            return {

            };
        },
        props: {
            goods: Object,
            parentData: Object,
            activityList: Object,
        },
        components: {
            changeStock,
            checkbox,
        },
        computed: {
            currency() {
                return this.$root.currenySign;
            }
        },
        filters: {
            capitalize(value) {
                if (!value) return '';
                value = value.toString();
                return value.charAt(0).toUpperCase() + value.slice(1);
            }
        },
        methods: {
            // 删除
            async deleteGoods(itemId) {
                const { status } = await serviceCartDelete.http({
                    data: {
                        itemId,
                    }
                });

                if (status === 0) {
                    // update list
                    this.$bus.$emit('updatelist');
                }
            },
        }
    };
</script>

<style>
@import './tinygroup.css';
</style>
