<template lang="pug">
    .tiny_changestock(:class="{'disabled': !goods.allowBuy || goods.stockNum <= 1 || goods.goodType === 2 || goods.goodType === 21 || goods.goodType === 3}")
        i.icon-reduce.tiny_changebtn(@click="reduceNum", :class="{ 'disabled': inputVal <= 1 }")
        input.tiny_stockNum(type="text", v-model.number.trim.lazy="inputVal", @focus="getOrig", @blur="change_stock('blur')", @keyup="onenter($event)", :disabled="goods.stockNum <= 1")
        i.icon-add.tiny_changebtn(@click="addNum", :class="{ 'disabled': inputVal >= goods.stockNum || (goods.skuAdvanceDetail && goods.skuAdvanceDetail.advanceAmount && (inputVal >= goods.buyLimit)) || (parentData && inputVal >= parentData.qty) }")
</template>

<script>

    import layer from 'layer';
    import { serviceCartUpdate } from 'js/service/paycart';

    export default {
        data() {
            return {
                lastStock: '', // 存储上次输入的数值
                inputRules: /^\+?[1-9][0-9]*$/, // 正整数正则表达式
                inputVal: this.goods.stockNum <= 0 ? 0 : this.goods.qty,
            };
        },
        props: {
            goods: Object,
            parentData: Object,
            activity: Object,
        },
        watch: {
            goods: {
                handler() {
                    if (this.goods.stockNum <= 0) {
                        this.inputVal = 0;
                    } else if (this.goods.stockNum >= this.goods.qty) {
                        this.inputVal = this.goods.qty;
                    } else {
                        this.inputVal = this.goods.stockNum;
                    }
                },
                deep: true
            },
        },
        methods: {
            testValue(value) {
                if (this.inputRules.test(value || this.inputVal)) {
                    return value || this.inputVal;
                }
                this.inputVal = 1;
                return 1;
            },
            addNum() {
                const vm = this;
                vm.lastStock = vm.inputVal;
                if (vm.parentData && vm.inputVal >= vm.parentData.qty) {
                    vm.inputVal = vm.parentData.qty;
                    return;
                }

                if (vm.testValue()) {
                    this.inputVal += 1;
                    if (vm.inputVal > vm.goods.stockNum) {
                        vm.inputVal = vm.goods.stockNum;
                    }
                    // 定金膨胀
                    if (vm.goods.skuAdvanceDetail && vm.goods.skuAdvanceDetail.advanceAmount) {
                        if (vm.goods.buyLimit > 0 && vm.inputVal > vm.goods.buyLimit) {
                            layer.msg(vm.$trans('cart.canot_add_number', [vm.goods.buyLimit]));
                            vm.inputVal -= 1;
                        }
                    }
                    vm.change_stock();
                }
            },
            reduceNum() {
                const vm = this;
                vm.lastStock = vm.inputVal;
                if (this.goods.stockNum <= 0) {
                    this.inputVal = 0;
                    return;
                }

                if (vm.testValue() && vm.testValue() > 1) {
                    vm.inputVal -= 1;
                    vm.change_stock();
                }
            },
            getOrig() {
                this.lastStock = this.inputVal;
            },
            onenter(ev) {
                if (+ev.keyCode === 13) {
                    ev.currentTarget.blur();
                }
            },
            change_stock(blur) {
                const vm = this;
                // 定金膨胀
                if (vm.goods.skuAdvanceDetail && vm.goods.skuAdvanceDetail.advanceAmount) {
                    if (vm.goods.buyLimit > 0 && vm.inputVal > vm.goods.buyLimit) {
                        layer.msg(vm.$trans('cart.canot_add_number', [vm.goods.buyLimit]));

                        if (blur) {
                            if (vm.goods.buyLimit < vm.goods.stockNum) {
                                vm.inputVal = vm.goods.buyLimit;
                            } else {
                                vm.inputVal = vm.goods.stockNum;
                            }
                        } else {
                            return;
                        }
                    }
                }
                // 库存不足直接拒绝
                if (vm.goods.stockNum <= 0) {
                    vm.inputVal = 0;
                    return;
                }
                // 配件数量不能超过主件数量 && 不能超过单次购买数量
                if (vm.parentData && vm.inputVal >= vm.parentData.qty) {
                    vm.inputVal = vm.parentData.qty;
                }
                // 不允许编辑 || 手输的数字没变化时直接拒绝
                if (+vm.inputVal === +vm.lastStock) return;

                // 正则匹配输入的值是否合法
                if (!vm.inputRules.test(vm.inputVal)) {
                    vm.inputVal = 1;
                    if (+vm.inputVal === +vm.lastStock) return;
                }
                // 输入的值大于库存 || 单次购买数量时时立即修正
                if (vm.inputVal > vm.goods.stockNum) {
                    vm.inputVal = vm.goods.stockNum;
                    layer.msg(vm.$trans('cart.no_more_than', [vm.inputVal]));
                }

                // 针对购物车商品 M元N件 进行库存判断
                /* if (
                    vm.goods.isSelected &&
                    +vm.activity.activity.activityType === 6 &&
                    vm.goods.remainderCount !== 0 &&
                    vm.inputVal > vm.goods.remainderCount
                ) {
                    layer.msg(vm.$trans('cart.notice_out_of_active_stock', [vm.goods.remainderCount]));
                    return;
                } */

                // 更新父级的价格显示
                vm.changestockEvent();

            },
            // 更改商品数量
            async changestockEvent(data) {
                const vm = this;
                const { status, msg } = await serviceCartUpdate.http({
                    data: {
                        itemId: vm.goods.itemId,
                        qty: vm.inputVal,
                    }
                });

                if (status === 0) {
                    vm.$bus.$emit('updatelist');
                } else {
                    layer.msg(msg);
                }
            },
        }
    };
</script>
