import { throttle } from 'js/utils/index.js';

export default (Vue, opts = {}) => {
    const config = Object.assign({
        retry: false,
        preload: 100,
        throttleWait: 300,
        selector: 'tiny_img',
        preClass: 'load_err',
        loading: 'icon-loading',
        scrollItem: 'tiny_groups',
        container: '',
        maxheight: '',
        domList: []
    }, opts);

    const loadEnd = (el) => {
        const parent = el.parentNode;
        if (parent.classList.contains(config.loading)) {
            parent.classList.remove(config.loading);
        }
    };

    const canShow = (scrollItem) => {
        const el = scrollItem.getElementsByClassName(config.selector)[0];
        const imgsrc = el.getAttribute('data-img');
        // 图片距离顶部的距离
        const elTop = scrollItem.getBoundingClientRect().top;
        // 容器距离顶部的距离
        const viewTop = config.container.getBoundingClientRect().top;
        // 可视区高度
        const viewHeight = +config.maxheight || config.container.offsetHeight;

        if (elTop <= viewTop + viewHeight) {
            const image = new Image();
            image.src = imgsrc;
            image.onload = () => {
                el.src = imgsrc;
                el.classList.remove(config.preClass);
                loadEnd(el);
            };
            image.onerror = () => {
                el.src = config.error;
                el.classList.add(config.preClass);
                loadEnd(el);
            };
        }
    };

    const throttleFn = throttle(() => {
        config.domList.forEach((dom) => {
            canShow(dom);
        });
    }, config.throttleWait);

    const addEventListener = (el, binding) => {
        config.container = el;
        if (el.children) {
            const scrollItem = binding.value ? binding.value.scrollItem : config.scrollItem;
            config.maxheight = binding.value ? binding.value.maxheight : config.maxheight;

            config.domList = [...el.getElementsByClassName(scrollItem)];

            // 初始化执行
            throttleFn();
            // 添加事件监听
            config.container.addEventListener('scroll', throttleFn, false);
        }
    };

    Vue.directive('tinylazy-contain', {
        // inserted: addEventListener,
        componentUpdated: addEventListener,
    });
};
