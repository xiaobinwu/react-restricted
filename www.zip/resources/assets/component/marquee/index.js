/*
 * name: marquee（跑马灯组件）
 * author: Jiazhan Li
 * date: 2018/05/28
 */

import TWEEN from 'js/lib/Tween';
import './style.css';

const TRANSFORM = ['transform', 'webkitTransform', 'MozTransform', 'msTransform', 'OTransform'];
const ANIMATION = ['animation', 'webkitAnimation', 'MozAnimation', 'msAnimation', 'OAnimation'];
const bodyStyle = document.body.style;
const transform = TRANSFORM.find(item => bodyStyle[item] !== undefined);
const animation = ANIMATION.find(item => bodyStyle[item] !== undefined);

/**
 * TWEEN更新驱动函数
 */
function animate() {
    if (TWEEN.update()) {
        requestAnimationFrame(animate);
    }
}

/**
 * 单个跑马灯
 * @param {Element}  element     元素
 * @param {Number}   speed       移动一个像素的毫秒值（默认16）
 * @param {Boolean}  css3        css3驱动动画
 * @param {String}   direction   轮播方向（默认向上）：up, left
 */
class SingleMarquee {
    constructor({
        element = null,
        speed = 16,
        css3 = true,
        direction = 'up',
    } = {}) {
        const [child] = element.children;
        this.child = child;
        this.element = element;
        this.speed = speed;
        this.isOverflow = false; // 内容是否溢出容器
        this.css3 = css3;
        this.direction = direction;

        if (!this.child) return;

        if (this.direction === 'up') {
            this.parentSize = this.element.clientHeight;
            this.childSize = this.child.offsetHeight;
            this.animationName = 'marqueeV';
        } else if (this.direction === 'left') {
            this.parentSize = this.element.clientWidth;
            this.childSize = this.child.offsetWidth;
            this.animationName = 'marqueeH';
        }

        if (this.parentSize < this.childSize) {
            this.isOverflow = true;
            this.child.innerHTML = this.child.innerHTML.repeat(2);
            this.duration = (this.childSize * this.speed) / 1000;

            if (animation && this.css3) {
                this.child.style[animation] = `${this.animationName} ${this.duration}s linear infinite`;
            } else {
                this.createTween();
                animate();
            }
        }
    }

    /**
     * 创建动画
     */
    createTween(distance = 0) {
        const duration = (this.duration * (this.childSize - distance)) / this.childSize;

        this.tween = new TWEEN.Tween({ x: distance })
            .to({ x: this.childSize }, duration * 1000)
            .onUpdate((pos) => {
                if (this.direction === 'up') {
                    this.child.style[transform] = `translate(0, ${-pos.x}px)`;
                } else if (this.direction === 'left') {
                    this.child.style[transform] = `translate(${-pos.x}px, 0)`;
                }
            })
            .onComplete(() => {
                if (distance > 0) this.createTween();
            });

        if (distance === 0) this.tween.repeat(Infinity);
        this.tween.start();
    }

    /**
     * 开始动画
     */
    start() {
        if (this.isOverflow) {
            if (animation && this.css3) {
                this.child.style[`${animation}PlayState`] = 'running';
            } else {
                this.createTween(this.tween._object.x); // eslint-disable-line
                animate();
            }
        }
        return this;
    }

    /**
     * 停止动画
     */
    stop() {
        if (this.isOverflow) {
            if (animation && this.css3) {
                this.child.style[`${animation}PlayState`] = 'paused';
            } else {
                this.tween.stop();
            }
        }
        return this;
    }
}

/**
 * Marquee类
 * @param {String}  selector    元素选择器
 * @param {Number}  speed       移动一个像素的毫秒值（默认16）
 * @param {Boolean} css3        css3驱动动画
 * @param {String}  direction   轮播方向（默认向上）：up, left
 */
export default class Marquee {
    constructor({
        selector = null,
        speed = 16,
        css3 = true,
        direction = 'up',
    } = {}) {
        try {
            this.elements = document.querySelectorAll(selector);
        } catch (e) {
            this.elements = [];
        }

        this.list = [];

        [...this.elements].forEach((element) => {
            this.list.push(new SingleMarquee({
                element,
                speed,
                css3,
                direction,
            }));
        });
    }

    start() {
        return this.list.map(item => item.start());
    }

    stop() {
        return this.list.map(item => item.stop());
    }
}
