import $ from 'jquery';
import 'component/select/select.js';
import '../combobox.js';

const demoData = [{
    code: 0,
    name: '全部',
}, {
    code: 1,
    name: '选项1',
}, {
    code: 2,
    name: '选项2',
}];

$('.js-select').combobox({
    data: demoData,
    value: 'code',
    text: 'name',
    default: 2,
    onChange(target) {
        console.log(`当前选中了：${target.val()}`);
    },
    onComplete(target) {
        target.select();
    },
});
