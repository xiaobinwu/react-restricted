/*
 * name: combobox（数据填充组件，为下拉列表填充数据）
 * author: zaki
 * date: 2017/12/25
 *
 ******************************** 《简介》 ********************************

    1. 组件依赖 "jquery.js" 插件。
    2. 组件依赖 "select.js" 组件。

 ******************************** 《html》 ********************************
    <!-- exp1 -->
    <select class="selector"></select>

 ******************************** 《调用方式》 ********************************

    demo1:
    $('.selector').combobox({
        data: [], // 异步请求的数据（数组）
        value: 'code', // 存放 option 元素值的属性名
        text: 'name', // 存放 option 元素文本的属性名
        default: '', // 默认值（如不传递，取第一个值）
        placeholder: 'please select a value', // 提示语
        onChange: null,
        onComplete: null,
    });

 */

$.fn.combobox = function combobox(params) {
    if (this.length === 0) return this;

    // 支持批量操作
    if (this.length > 1) {
        this.each((index, elem) => {
            $(elem).combobox(params);
        });
        return this;
    }

    const $self = this;

    const config = {
        data: [],
        value: 'code',
        text: 'name',
        default: '',
        placeholder: undefined,
        onChange: $.noop,
        onComplete: $.noop,
    };

    if (typeof params === 'object') {
        Object.assign(config, params); // 扩展组件配置
    }

    const getOptions = options => options.map((opt) => {
        if (!opt) return '';
        else if (Array.isArray(opt)) return opt.length > 0 ? `<optgroup>${getOptions(opt)}</optgroup>` : '';
        const optValue = String(opt[config.value]);
        const isChecked = optValue === String(config.default) || optValue === $self[0].dataset.value ? 'selected' : '';
        return `<option value="${optValue}" ${isChecked}>${opt[config.text]}</option>`;
    }).join('');

    const html = typeof config.placeholder === 'string' ? `<option value="">${config.placeholder}</option>` : '';
    $self.html(html + getOptions(config.data));

    if (!$self.hasClass('initialized')) {
        $self.on('change', () => {
            config.onChange($self);
        });
        $self.addClass('initialized');
    }

    config.onComplete($self);
    return this;
};
