import '../item.css';
import Item from '../item.js';

console.log(new Item());

