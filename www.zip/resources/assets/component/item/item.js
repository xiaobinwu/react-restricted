import 'css/bootstrap';
import './item.css';

class Item {
    constructor(dom) {
        this.dom = dom;
    }
}
export default Item;
