/**
 * 鼠标进入/离开元素，控制某个元素显示/隐藏。适用场景：控制子元素显示隐藏 | 不相关多个元素显示隐藏
 * @param enterElement    鼠标进入元素
 * @param displayElement  需要显示元素
 * @param isChild         enterElement 和 displayElement是否是父子关系
 * @param outIsHide       enterElement鼠标移出，displayElement是否继续显示。如果为false则默认点击body隐藏
 * @param scrollHide       元素是否滚动隐藏
 * @param onChange        显示/隐藏状态触发回调函数
 */
function mouseDisplay({
    enterElement = '.js_dropBullet',
    displayElement = '.js_dropContent',
    isChild = true,
    outIsHide = true,
    scrollHide = false,
    onChange = (enterEle, status) => {},
}) {
    const $enterEle = $(enterElement);
    const $displayEle = $(displayElement);
    let scrollLock = false;
    $enterEle.mouseenter((ele) => {
        if (isChild) {
            $(ele.currentTarget).find(displayElement).show();
        } else {
            $displayEle.show();
        }
        scrollLock = false;
        onChange($(ele.currentTarget), 'show');
    });
    if (outIsHide) {
        $enterEle.mouseleave((ele) => {
            if (isChild) {
                $(ele.currentTarget).find(displayElement).hide();
            } else {
                $displayEle.hide();
            }
            onChange($(ele.currentTarget), 'hide');
        });
    } else {
        $enterEle.click(e => e.stopPropagation());
        $('body').click(() => {
            if (isChild) {
                $enterEle.find($displayEle).hide();
            } else {
                $displayEle.hide();
            }
            onChange($enterEle, 'hide');
        });
        if (scrollHide) {
            $(window).scroll((e) => {
                if (scrollLock && isChild) return;
                scrollLock = true;
                $enterEle.find($displayEle).hide();
                onChange($enterEle, 'hide');
            });
        }
    }
}

export default mouseDisplay;

