import '../toggle.css';
import Toggle from '../toggle.js';

console.log(new Toggle());

