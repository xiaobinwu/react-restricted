import './toggle.css';

class Toggle {
    constructor(dom) {
        this.dom = dom;
    }
}
export default Toggle;
