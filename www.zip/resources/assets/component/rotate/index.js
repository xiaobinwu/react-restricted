/*
 * name: rotate（旋转动画）
 * author: zaki
 * date: 2018/05/24
 */

import TWEEN from 'js/lib/Tween';

const TRANSITION = ['transition', 'webkitTransition', 'MozTransition', 'msTransition', 'OTransition'];
const TRANSFORM = ['transform', 'webkitTransform', 'MozTransform', 'msTransform', 'OTransform'];
const bodyStyle = document.body.style;
const transition = TRANSITION.find(item => bodyStyle[item] !== undefined);
const transform = TRANSFORM.find(item => bodyStyle[item] !== undefined);

/**
 * Rotate类
 * @param {Element}  element        // 欲旋转元素
 * @param {Number}   angle          // 最初的角度
 * @param {Number}   animateTo      // 最终角度
 * @param {Number}   duration       // 动画过渡时间
 * @param {Function} onEnd          // 旋转结束后的回调函数
 */
export default class Rotate {
    constructor(params) {
        this.params = Object.assign({
            element: null,
            angle: 0,
            animateTo: 0,
            duration: 0,
            onEnd: () => {},
        }, params);

        this.element = this.params.element;
        this.angle = this.params.angle;
        this.isReady = true;

        if (this.params.animateTo > 0) {
            this.run(this.params);
        }
    }

    /**
     * 旋转驱动函数
     * @param animateTo         // 最终角度
     * @param duration          // 动画过渡时间
     * @param onEnd             // 旋转结束后的回调函数
     */
    run({
        animateTo = this.params.animateTo,
        duration = this.params.duration,
        onEnd = this.params.onEnd,
    } = {}) {
        if (!this.isReady) return;
        this.isReady = false;

        if (transition) {
            // 支持css3动画
            this.element.style[transition] = `${transform} ${duration / 1000}s ease-in-out`;
            this.element.style[transform] = `rotate(${animateTo}deg)`;
            setTimeout(() => {
                this.isReady = true;
                this.element.style[transition] = 'none';
                this.element.style[transform] = `rotate(${animateTo % 360}deg)`;
                onEnd();
            }, duration);
        } else {
            new TWEEN.Tween({ angle: this.angle })
                .to({ angle: animateTo }, duration)
                .easing(TWEEN.Easing.Quadratic.InOut)
                .onUpdate((obj) => {
                    this.element.style[transform] = `rotate(${obj.angle}deg)`;
                })
                .onComplete(() => {
                    this.isReady = true;
                    this.angle = animateTo % 360;
                    this.element.style[transform] = `rotate(${this.angle}deg)`;
                    onEnd();
                })
                .start();
            animate();
        }
    }
}

/**
 * 用于驱动更新操作
 */
function animate() {
    if (TWEEN.update()) {
        requestAnimationFrame(animate);
    }
}
