import $ from 'jquery';
import './test.css';
import '../dropdown.js';

// 组件初始化
$('.js-dropdown').dropdown({
    onOpen() {
        console.log('open');
    },
    onClose() {
        console.log('close');
    },
});

// 控制组件
$('fieldset').on('click', 'a', (e) => {
    const opera = $(e.currentTarget).data('opera');

    if (opera === 'open') {
        $('.js-dropdown').dropdown('open');
    } else if (opera === 'close') {
        $('.js-dropdown').dropdown('close');
    } else if (opera === 'toggle') {
        $('.js-dropdown').dropdown('toggle');
    } else if (opera === 'disable') {
        $('.js-dropdown').dropdown('disable');
    } else if (opera === 'enable') {
        $('.js-dropdown').dropdown('enable');
    }
});

// 必须阻止控制按钮针对 "mousedown" 的事件冒泡
// 因为点击组件外部（即出发 document 的 mousedown 事件）会默认关闭组件
$('fieldset').on('mousedown', 'a', (e) => {
    e.stopPropagation();
});
