/*
 * name: dropdown（下拉组件）
 * author: zaki
 * date: 2017/06/16
 *
 ******************************** 《简介》 ********************************

    1. 组件依赖 "jquery.js" 插件。
    2. 组件支持批量操作
    3. 内部有缓存机制，不用担心性能问题
    4. 建议在控制下拉菜单显示或隐藏的时候尽量不要用切换 display:none 的方式，这样做会导致：
       // css3过渡属性将失效；
       // 这种模式下如果需要对菜单里面的内容计算宽高度将失效。
       // 建议采用(opacity:0 + visibility:hidden)的组合模式

 ******************************** 《html》 ********************************

    <div id="demo">
        <div class="dropdown_toggle">头部</div>
        <div class="dropdown_menu">内容</div>
    </div>

 ******************************** 《调用方式》 ********************************

    demo1: $('#demo').dropdown();               // 普通初始化 (参数取默认值)
    demo2: $('#demo').dropdown('open');         // 打开菜单 (class="open"，你需对这个类型进行样式控制)
    demo3: $('#demo').dropdown('close');        // 隐藏菜单
    demo4: $('#demo').dropdown('toggle');       // 反复切换菜单
    demo5: $('#demo').dropdown('disable');      // 设置不可用 (class="disabled"，你需对这个类型进行样式控制)
    demo6: $('#demo').dropdown('enable');       // 设置可用
    demo7: $('#demo').dropdown('clean');        // 清理缓存（用于删除组件dom元素的时候）

    demo8: 初始化带参数
    $('#demo').dropdown({
        mode: 0,                    // 0: 鼠标点击控制显示隐藏（默认值）； 1: 鼠标移入移出控制显示隐藏
        onOpen: function() {}       // 菜单打开时执行回调
        onClose: function() {}      // 菜单隐藏时执行回调
    });

 */

import './dropdown.css';

const DROPCACHE = {}; // 缓存字典
const dropTask = {}; // 任务队列：用于点击组件外部关闭组件

window.DROPCACHE = DROPCACHE; // 将缓存字典暴露给window对象，方便调试

$.fn.dropdown = function dropdown(params) {
    if (this.length === 0) return this;

    // 支持批量操作
    if (this.length > 1) {
        this.each((index, elem) => {
            $(elem).dropdown(params);
        });
        return this;
    }

    const $self = this;

    let isOpen; // 组件是否打开
    let isDisable; // 组件是否禁用状态

    // 判断组件是否被初始化过
    const key = $self.KEY || $self.data('key');
    if (key in DROPCACHE) {
        return DROPCACHE[key].Dropdown(params);
    }

    /* 代码能走到这里说明组件还未进行过初始化 */
    const $toggle = $self.children('.dropdown_toggle');

    // 生成 KEY，并添加到缓存变量
    const KEY = `DROPDOWN${Math.floor(Math.random() * 10000000)}`;
    $self.KEY = KEY;
    $self.data('key', KEY).addClass(KEY);
    DROPCACHE[KEY] = $self;

    // 默认配置
    const config = {
        mode: 0, // 组件模式
        onOpen: $.noop,
        onClose: $.noop,
    };

    // 内部方法集合
    const methods = {
        init() {
            isOpen = $self.hasClass('dropdown-open');
            isDisable = $self.hasClass('disabled');

            if (typeof params === 'object') {
                $.extend(config, params);
            }

            if (config.mode === 0) {
                // 鼠标点击控制组件缩放
                $toggle.on('mousedown', (e) => {
                    e.preventDefault();
                }).on('click', () => {
                    methods[isOpen ? 'closeMenu' : 'openMenu']();
                });
            } else {
                // 鼠标移入移出控制组件缩放
                $toggle.on('mouseenter', methods.openMenu);
                $self.on('mouseleave', methods.closeMenu);
            }

            // 组件的 DOM 节点被移除时释放内存
            $self.on('DOMNodeRemovedFromDocument', () => {
                $self.Dropdown('clean');
            });

            $self.Dropdown(params);
        },

        // 弹出菜单
        openMenu() {
            if (!isDisable && isOpen === false) {
                isOpen = true;
                $self.addClass('dropdown-open');
                dropTask[KEY] = $self; // 添加关闭任务
                config.onOpen($self);
            }
        },

        // 关闭菜单
        closeMenu() {
            if (!isDisable && isOpen === true) {
                isOpen = false;
                $self.removeClass('dropdown-open');
                delete dropTask[KEY];
                config.onClose($self);
            }
        },
    };

    // 组件行为
    $self.Dropdown = (opera) => {
        if (typeof opera !== 'string') {
            return $self;
        } else if (opera === 'open') {
            methods.openMenu();
        } else if (opera === 'close') {
            methods.closeMenu();
        } else if (opera === 'disable') {
            methods.closeMenu(); // 设置为不可用的时候关闭菜单
            isDisable = true;
            $self.addClass('disabled');
        } else if (opera === 'enable') {
            isDisable = false;
            $self.removeClass('disabled');
        } else if (opera === 'toggle') {
            methods[isOpen ? 'closeMenu' : 'openMenu']();
        } else if (opera === 'clean') {
            delete DROPCACHE[$self.data('key')];
        }
        return $self;
    };

    // 最后让我们初始化它
    methods.init();
    return this;
};

// 当点击组件外部时关闭组件菜单
$(document).on('mousedown', (e) => {
    for (let key in dropTask) { // eslint-disable-line
        if ($(e.target).closest(`.${key}`).length === 0) {
            dropTask[key].dropdown('close');
        }
    }
});
