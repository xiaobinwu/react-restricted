/*
 * name: loader（列表加载器）
 * author: zaki
 * date: 2018/02/09
 */

export default class Loader {
    constructor(params) {
        this.config = Object.assign({
            viewMore: null,
            auto: false,
            bufferArea: 500,
            data: $.noop,
            loadStart: $.noop,
            loadSuccess: $.noop
        }, params);

        this.loadStatus = 'ready';
        this.data = null;
        this.$viewMore = $(this.config.viewMore);
        this.update();

        if (this.$viewMore.length > 0) {
            this.$viewMore = this.$viewMore.eq(0);

            if (this.config.auto) {
                const $win = $(window);
                const screenHeight = $win.height();

                $win.on('scroll', () => {
                    const scrollTop = $win.scrollTop();
                    if (this.vmTop - scrollTop - screenHeight < this.config.bufferArea) {
                        this.load();
                    }
                });
            } else {
                this.$viewMore.on('tap', () => {
                    this.load();
                });
            }
        }
    }

    async load() {
        if (this.loadStatus === 'ready') {
            this.loadStatus = 'loading';
            this.config.loadStart();

            if (this.$viewMore.length > 0) {
                this.$viewMore.addClass('loading');
            }

            // 华丽的分割线--------------------
            this.data = await this.config.data();
            this.loadStatus = 'ready';
            this.config.loadSuccess(this.data);
            this.update();

            if (this.$viewMore.length > 0) {
                this.$viewMore.removeClass('loading');
            }
        }
    }

    update() {
        if (this.$viewMore.length > 0) {
            this.vmTop = this.$viewMore.offset().top;
        }
    }

    reset() {
        this.loadStatus = 'ready';
    }

    end() {
        this.loadStatus = 'end';
    }
}
