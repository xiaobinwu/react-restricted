/**
 * 场景：你是否有需要通过JS来控制页面变换，你是否为了性能需要CSS3来控制变化，是否需要通过原始的定位来控制页面元素变换。TransitionMove 甚至可以用于高级滑动插件的底层基础变换
 * constructor 初始化参数：
 *      ele: 需要移动的元素
 *      type: 移动的类型   ['translateX','translateY','rotate','top','right','bottom','left',]
 * 实例run参数：
 *      distance: 移动的距离，使用者需要自己带上单位
 *      timing：过渡的时间，使用者需要自己带上单位
 *      onEnd：本次过渡结束触发的回调
 */

import TWEEN from 'js/lib/Tween';

const isTrans = 'transition' in document.body.style;

function setupAnimation(runtime) {
    TWEEN.update(runtime);
    requestAnimationFrame(setupAnimation);
}

export default class MoveTransform {
    constructor({
        ele = null,
        type = 'translateX',
    }) {
        this.prevDist = 0;
        this.ele = ele;
        this.type = type;
    }

    run({
        distance = 0,
        timing = 0,
        onEnd = () => {},
    }) {
        this.distance = distance;
        this.onEnd = onEnd;
        this.timing = timing;
        const pools = [
            'translateX',
            'translateY',
            'rotate',
            'top',
            'right',
            'bottom',
            'left',
        ];
        let currentIndex = 0;
        const isIncludeType = pools.some((value, index) => {
            if (value === this.type) {
                currentIndex = index;
                return true;
            }
            return false;
        });
        if (isIncludeType) {
            this.analyze(currentIndex, this.type);
        } else {
            throw new Error('type parameter type error');
        }
    }

    analyze(index, prop) {
        if (this.timing) {
            this.animation(index, prop);
        } else {
            this.mutation(index, prop, this.distance);
        }
    }

    animation(index, prop) {
        const self = this;
        if (isTrans) {
            this.ele.style.transition = `all ${this.timing}`;
            setTimeout(() => {
                this.mutation(index, prop, this.distance);
            }, 15);
            if (!this.firstLock) {
                this.firstLock = true;
                this.ele.addEventListener('transitionend', self.onEnd, false);
            }
        } else {
            const disNum = parseFloat(this.distance);
            new TWEEN.Tween({ move: this.prevDist })
                .to({ move: disNum })
                .easing(TWEEN.Easing.Quadratic.Out)
                .onUpdate((obj) => {
                    let unitIcon = 'px';
                    if (prop === 'rotate') unitIcon = 'deg';
                    this.mutation(index, prop, `${obj.move}${unitIcon}`);
                })
                .start()
                .onComplete(() => {
                    this.onEnd();
                    TWEEN.removeAll();
                });
            requestAnimationFrame(setupAnimation);
            this.prevDist = disNum;
        }
    }

    mutation(index, prop, distance) {
        if (index > 2) {
            this.ele.style[prop] = distance;
        } else {
            this.polyfillTransform(this.ele, `${prop}(${distance})`);
        }
    }

    polyfillTransform(ele, val) {
        ele.style.transform = val;
        ele.style.webkitTransform = val;
        ele.style.mozTransform = val;
        ele.style.msTransform = val;
    }
}
