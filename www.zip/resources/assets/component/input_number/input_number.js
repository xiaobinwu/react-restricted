/*
 * name: input_number
 * author: luochongfei
 * date: 2017-12-06
 *
 ******************************** 《简介》 ********************************

    1. 组件无依赖（自身样式除外）
    2. IE8+
    3. 在html属性设置属性
    4. 在对象实例设置回调

 ******************************** 《html》 ********************************
    <!-- exp1 -->
    <span class="compInputNumber" id="js-yourElementId">
        <span class="compInputNumber_reduce">-</span>
        <span class="compInputNumber_inputWrap">
            <input type="text" value="1" step="1" min="1" max="50" class="compInputNumber_input">
        </span>
        <span class="compInputNumber_plus">+</span>
    </span>

    <!-- exp2 可对input设置禁用-->
    <span class="compInputNumber" id="js-yourElementId">
        <span class="compInputNumber_reduce">-</span>
        <span class="compInputNumber_inputWrap">
            <input type="text" value="1" step="1" min="1" max="50" class="compInputNumber_input" disabled>
        </span>
        <span class="compInputNumber_plus">+</span>
    </span>

 ******************************** 《调用方式》 ********************************

    demo1: new InputNumber('js-productCount');  // 普通初始化 (参数取行内属性或默认)
    demo2:
        new InputNumber('js-productCount', {
            // input值有变化时
            onChange(val) {
                console.log('有变化：', val);
            },
            // input值到最大时
            onMax(val) {
                console.log('最大了：', val);
            },
            // input值到最小时
            onMin(val) {
                console.log('最小了：', val);
            },
        });

 ******************************** 《input可配置属性》 ********************************
    data-min:           最小值
    data-max:           最大值
    data-step:          加减量
    data-hold-down:     是否开启长按（当要监听事件时不建议开启此项）
    disabled:           存在则禁用整个控件，反之启用整个控件

 ******************************** 《对象实例回调事件》 ********************************
    onChange(value):        input值有变化时
    onMax(value):           input值到最大时
    onMin(value):           input值到最小时

 ******************************** 《对象实例设定事件》 ********************************
    setDisable(Boolean):     设置是否禁用控件
    setMax(value):           设置最大值
    setMin(value):           设置最小值
 */

import './input_number.css';

class InputNumber {
    constructor(id, options) {
        if (typeof id === 'undefined') {
            return;
        }
        this.oParent = document.getElementById(id);
        if (!this.oParent) {
            return;
        }
        this.opt = options || {};
        this.dom();
        this.eleConfig();
        this.bindEvent();
    }
    dom() {
        this.oBtnPlus = this.oParent.querySelector('.compInputNumber_plus');
        this.oBtnReduce = this.oParent.querySelector('.compInputNumber_reduce');
        this.oInput = this.oParent.querySelector('.compInputNumber_input');
    }
    eleConfig() {
        function replaceNum(val, newVal) {
            return (!val || Number.isNaN(val)) ? newVal : val;
        }
        this.min = replaceNum(parseInt(this.oInput.getAttribute('min'), 10), 1);
        this.max = replaceNum(parseInt(this.oInput.getAttribute('max'), 10), 100);
        this.step = replaceNum(parseInt(this.oInput.getAttribute('step'), 10), 1);
        this.holdDown = this.oInput.getAttribute('hold-down') || false;
        this.disabled = this.oInput.disabled;
        this.setDisable(this.disabled);
    }
    bindEvent() {
        // 加 按下
        this.oBtnPlus.addEventListener('mousedown', () => {
            if (this.disabled) {
                return;
            }
            this.plus();
            this.hold(this.plus);
        }, false);
        // 加 抬起
        this.oBtnPlus.addEventListener('mouseup', () => {
            this.clearTimer();
        });

        // 减 按下
        this.oBtnReduce.addEventListener('mousedown', () => {
            if (this.disabled) {
                return;
            }
            this.reduce();
            this.hold(this.reduce);
        }, false);
        // 减 抬起
        this.oBtnReduce.addEventListener('mouseup', () => {
            this.clearTimer();
        });

        // 监测数量变化
        this.oInput.addEventListener('input', () => this.onChange(), false);
        // 兼容ie9
        this.oInput.addEventListener('propertychange', () => this.onChange(), false);
    }
    // 加
    plus() {
        const iptVal = parseInt(this.oInput.value, 10);
        this.oInput.value = iptVal + this.step;
        this.onChange();
    }
    // 减
    reduce() {
        const iptVal = parseInt(this.oInput.value, 10);
        this.oInput.value = iptVal - this.step;
        this.onChange();
    }
    // 值变化时
    onChange() {
        let iptVal = parseInt(this.oInput.value, 10);

        // 非数字时
        if (Number.isNaN(iptVal)) {
            this.oInput.value = this.min;
        }

        // 大于等于最大值时
        if (iptVal >= this.max) {
            this.oInput.value = this.max;
            this.onMax();
            this.oBtnPlus.setAttribute('disabled', 'disabled');
        } else {
            this.oBtnPlus.removeAttribute('disabled');
        }

        // 小于等于最小值时
        if (iptVal <= this.min) {
            this.oInput.value = this.min;
            this.onMin();
            this.oBtnReduce.setAttribute('disabled', 'disabled');
        } else {
            this.oBtnReduce.removeAttribute('disabled');
        }

        iptVal = this.oInput.value;

        // 自定义回调
        if (this.opt.onChange) {
            this.opt.onChange.call(null, iptVal);
        }
    }
    // 最小时
    onMin() {
        if (this.opt.onMin) {
            this.opt.onMin.call(null, this.oInput.value);
        }
    }
    // 最大时
    onMax() {
        if (this.opt.onMax) {
            this.opt.onMax.call(null, this.oInput.value);
        }
    }
    // 设置是否禁用
    setDisable(isDisable) {
        const dis = isDisable;
        this.oInput.disabled = dis;
        this.disabled = dis;
        if (dis) {
            this.oBtnPlus.setAttribute('disabled', '');
            this.oBtnReduce.setAttribute('disabled', '');
        } else {
            this.oBtnPlus.removeAttribute('disabled');
            this.oBtnReduce.removeAttribute('disabled');
        }
    }
    // 设置最小值
    setMin(value) {
        let val = typeof value === 'number' ? value : 1;
        if (Number.isNaN(val)) {
            val = 1;
        }
        this.min = val;
        this.oInput.setAttribute('data-min', val);
        this.onChange();
    }
    // 设置最大值
    setMax(value) {
        let val = typeof value === 'number' ? value : 100;
        if (Number.isNaN(val)) {
            val = 100;
        }
        this.max = val;
        this.oInput.setAttribute('data-max', val);
        this.onChange();
    }
    // 设置值
    setVal(value) {
        this.oInput.value = value || 1;
        this.onChange();
    }
    // 获取值
    getVal() {
        return this.oInput.value;
    }
    // 按住
    hold(fn) {
        if (!this.holdDown) {
            return;
        }
        this.plusTimer1 = setTimeout(() => {
            this.plusTimer2 = setInterval(() => {
                fn.call(this);
            }, 70);
        }, 600);
    }
    // 清除按住定时器
    clearTimer() {
        clearInterval(this.plusTimer1);
        clearInterval(this.plusTimer2);
    }
}
export default InputNumber;
