import '../goods_attr.css';

// 数据
import props from '../data/props.js';
import props2 from '../data/props2.js';
import props3 from '../data/props3.js';

// 核心脚本
import GoodsAttr from '../goods_attr.js';

const goodsAttr1 = new GoodsAttr({
    jqWrap: $('#wrap1'),
    goodsList: props.goods_list,
    multiplyAttrName: 'product_number',
    success(product) {
        $('#img').find('img').attr('src', product.goods_img);
        $('#title').html(product.goods_title);
        $('#price').html(product.price * 7.87738);
    },
});
goodsAttr1.init();


const goodsAttr2 = new GoodsAttr({
    jqWrap: $('#wrap2'),
    goodsList: props2.goods_list,
    multiplyAttrName: 'product_number',
    success(product) {
        console.info(product);
        document.querySelector('#iframe2').src = product.goods_img;
    },
});
goodsAttr2.init();


const goodsAttr3 = new GoodsAttr({
    jqWrap: $('#wrap3'),
    goodsList: props3.goods_list,
    multiplyAttrName: 'product_number',
    success(product) {
        console.info(product);
        document.querySelector('#img3').src = product.goods_img;
    },
});
goodsAttr3.init();
