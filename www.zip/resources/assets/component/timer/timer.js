/*
 * name: timer（倒计时组件）
 * author: zaki
 * date: 2018/01/08
 */

class Timer {
    // 构造方法
    constructor(jqSelector, params) {
        const self = this;

        this.task = {}; // 任务列表

        setTimeout(() => {
            this.add(jqSelector, params);
        }, 0);

        function done() {
            for (const t in self.task) { // eslint-disable-line
                self.task[t].beat();
            }
        }

        done();
        this.clock = setInterval(done, 1000);
    }

    // 添加器
    add(jqSelector, config) {
        const self = this;
        const $selector = $(jqSelector);

        if (!jqSelector || $selector.length === 0) return self;

        // 配置参数
        const params = Object.assign({
            format: '{dd}:{hh}:{mm}:{ss}', // 格式化
            interval: 0, // 倒计时秒数
            charWrap: false, // 是否使用<i>标签包裹单个数字
            onStart: $.noop, // 计时开始前回调函数
            onEnd: $.noop, // 计时结束后回调函数
            onChange(target, output) { // 每次秒表跳动执行的回调函数
                $(target).html(output);
            },
        }, config);

        // 内部批量操作
        if ($selector.length > 1) {
            $selector.each((i, elem) => {
                self.add(elem, params);
            });
            return self;
        }

        // 生成秒数（保证 interval 始终大于等于0）
        let interval = 0;
        if (typeof params.interval === 'function') {
            interval = params.interval($selector);
            interval = interval > 0 ? Math.floor(interval) : 0;
        } else if (typeof params.interval === 'string') {
            const timestamp = $selector.data(params.interval);
            const now = Math.floor((new Date()) / 1000);
            interval = timestamp && timestamp - now > 0 ? timestamp - now : 0;
        } else if (typeof params.interval === 'number' && params.interval >= 0) {
            interval = Math.floor(params.interval);
        }

        // 生成随机任务id
        const taskId = Math.floor(Math.random() * 1000000000);

        // 触发 onStart 事件
        params.onStart($selector, Timer.format(interval, params));

        // 节拍函数
        function beat() {
            const output = Timer.format(interval, params);

            params.onChange($selector, output);
            if (interval === 0) {
                delete self.task[taskId];
                params.onEnd($selector, output);
            } else {
                interval -= 1;
            }
        }

        self.task[taskId] = { beat };
        beat();

        return self;
    }

    // 清空任务列表缓存
    clean() {
        this.task = {};
    }

    // 更新列表
    update(jqSelector, config) {
        this.clean();
        this.add(jqSelector, config);
    }

    destroy() {
        this.clean();
        clearInterval(this.clock);
    }

    // 类方法：时间格式化
    static format(interval, params) {
        const second = interval;
        const minute = Math.floor(second / 60);
        const hour = Math.floor(minute / 60);
        const day = Math.floor(hour / 24);
        const map = {
            d: day,
            h: hour % 24,
            m: minute % 60,
            s: Math.floor(second % 60),
        };

        const format = typeof params.format === 'function' ? params.format(interval) : params.format;
        const result = format.replace(/{(([dhms])+)}/g, (all, t1, t2) => {
            const v = map[t2];
            return t1.length > 1 ? `0${v}`.substr(-2) : v;
        });

        if (params.charWrap) {
            return result.replace(/(\d)/g, '<i>$1</i>');
        }

        return result;
    }
}

export default Timer;
