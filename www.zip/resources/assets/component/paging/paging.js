/*
 * name: paging（异步分页组件）
 * author: zaki
 * date: 2017/12/04
 *
 ******************************** 《简介》 ********************************

    1. 组件依赖 "jquery.js" 插件。
    2. 组件支持批量操作

 ******************************** 《html》 ********************************

    <div id="paging"></div>

 ******************************** 《调用方式》 ********************************

    $('#paging').paging({
        current: 1, // 当前页数
        total: 100, // 总页数

        // 跳页后执行的回调函数
        onChange: function(pageNum) {
            // turnToPage(pageNum);
        }
    });

 */

import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';
import render from './paging.art';
import './paging.css';

runtime.trans = trans;

$.fn.paging = function (params) { // eslint-disable-line

    if (this.length === 0) return this;
    // 支持批量操作
    if (this.length > 1) {
        // eslint-disable-next-line
        this.each(function() {
            $(this).paging(params);
        });
        return this;
    }

    const self = this;

    const config = $.extend({
        current: 1, // 当前页码
        total: 0, // 总页数
        onChange: $.noop, // 跳页后执行的回调函数
    }, params);

    // 总页数不超过一页时隐藏组件
    if (!config.total || config.total <= 1) {
        return self.hide();
    }
    self.show();

    // 渲染模板
    self.html(render(config));

    const $input = self.find('.gbPaging_input');

    // 自定义跳转
    function customGoToPage() {
        let pageNum = parseInt($input.val(), 10);
        if (!pageNum) {
            pageNum = 1;
        } else if (pageNum > config.total) {
            pageNum = config.total;
        }
        config.onChange(pageNum);
    }

    // eslint-disable-next-line
    self.find('a').on('click', function() {
        const $this = $(this);
        const goto = $this.data('goto');

        if (goto === 'prev') {
            if (!$this.hasClass('disabled')) {
                config.onChange(config.current - 1);
            }
        } else if (goto === 'next') {
            if (!$this.hasClass('disabled')) {
                config.onChange(config.current + 1);
            }
        } else if (goto === 'custom') {
            customGoToPage();
        } else if (!$this.hasClass('actived')) {
            config.onChange(parseInt(goto, 10));
        }
    });

    // eslint-disable-next-line
    $input.on('keydown', function(e) {
        if (e.keyCode === 13) {
            customGoToPage();
        }
    });

    return this;
};
