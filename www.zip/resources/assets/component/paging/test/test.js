import $ from 'jquery';
import 'component/paging/paging.js';

// 假设这是一个获取列表数据的方法
function getDataList(pageNum) {
    // 通常在这里会发送请求获取异步数据
    console.log(`在这里我获取到了第${pageNum}页的数据`);

    $('#paging').paging({
        current: pageNum, // 当前页数
        total: 20, // 总页数
        onChange(num) { // 点击跳页执行的回调函数
            getDataList(num);
        },
    });
}

// 跳转到第一页
getDataList(2);
