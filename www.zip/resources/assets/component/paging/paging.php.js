/*
 * name: paging.php（php分页组件）
 * author: zaki
 * date: 2017/12/04
 */

import './paging.css';
