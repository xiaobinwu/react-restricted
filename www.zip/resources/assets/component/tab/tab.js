import './tab.css';

class Tab {
    constructor(dom) {
        this.dom = dom;
    }
}
export default Tab;
