import '../tab.css';
import Tab from '../tab.js';

console.log(new Tab());
