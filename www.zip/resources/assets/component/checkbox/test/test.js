import '../checkbox.css';
import Checkbox from '../checkbox.js';

console.log(new Checkbox());

