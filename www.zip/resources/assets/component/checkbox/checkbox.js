import './checkbox.css';

class Checkbox {
    constructor(dom) {
        this.dom = dom;
    }
}
export default Checkbox;
