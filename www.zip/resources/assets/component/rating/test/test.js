import './test.css';
import '../rating.css';
import Rating from '../rating.js';

new Rating();

[...document.querySelectorAll('input')].forEach((elem) => {
    elem.addEventListener('change', (e) => {
        console.log(e.target.value);
    }, false);
});
