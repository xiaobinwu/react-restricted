/*
 * name: rating（评星组件）
 * author: Jiazhan Li
 * date: 2018/07/19
 */

import './rating.css';

/**
 * @param selector  可接受：选择器字符串、DOMElement、NodeList、jQuery对象
 */
class Rating {
    constructor(selector = '.js-rating') {
        try {
            if (selector.nodeType === 1) this.elements = [selector];
            else if (typeof selector === 'string') this.elements = document.querySelectorAll(selector);
            else if (selector.length > 0) this.elements = selector;
            else this.elements = [];

            [...this.elements].forEach((item) => {
                if (item && item.nodeType === 1) {
                    new Single(item);
                }
            });
        } catch (e) {
            console.error('评星组件加载失败！！');
        }
    }
}

/**
 * 针对单个实例的实现
 * @param element   DOMElement对象
 */
class Single {
    constructor(element) {
        // rating-initialized 是组件已经被初始化的标志类名
        if (!element.classList.contains('rating-initialized')) {
            element.classList.add('rating-initialized');
            this.element = element;
            this.editable = element.nodeName.toLowerCase() === 'input';
            this.shapeClass = 'rating_full';
            this.value = Number(element.value || element.dataset.value) || 0;
            this.value = this.value >= 0 && this.value <= 5 ? this.value : 0;
            this.init();
        }
    }

    // 事件触发器（change）
    static triggerChange = (() => {
        if (document.fireEvent) return dom => dom.fireEvent('onchange');
        const event = document.createEvent('HTMLEvents');
        event.initEvent('change', false, true);
        return dom => dom.dispatchEvent(event);
    })();

    init() {
        this.element.style.display = 'none';
        const model = this.getElementOfModel();
        this.element.parentNode.insertBefore(model, this.element.nextSibling);

        if (this.editable) {
            let activeItem = model.querySelector(`.${this.shapeClass}`);
            const firstItem = model.querySelector('.rating_before');
            const { shapeClass, element } = this;
            const disabled = element.classList.contains('disabled');

            model.classList.add('rating_model-input');
            if (disabled) {
                model.classList.add('rating_model-disabled');
            } else {
                model.classList.add('rating_model-enabled');
            }

            model.addEventListener('click', (e) => {
                if (!disabled) {
                    const isActived = e.target.classList.contains(shapeClass);
                    activeItem.classList.remove(shapeClass);
                    activeItem = isActived ? firstItem : e.target;
                    activeItem.classList.add(shapeClass);
                    element.value = activeItem.dataset.index;
                    Single.triggerChange(element);
                }
            }, false);
        }
    }

    getElementOfModel() {
        const dom = document.createElement('span');
        dom.classList.add('rating_model');
        dom.innerHTML = this.getHtmlOfModel();
        return dom;
    }

    getHtmlOfModel() {
        const decimal = this.value % 1;
        let index = Math.floor(this.value);

        if (!this.editable) {
            if (decimal >= 0.25) index += 1;
            if (decimal >= 0.25 && decimal < 0.75) this.shapeClass = 'rating_half';
        }

        let html = `<i class="rating_before ${index === 0 ? this.shapeClass : ''}" data-index="0"></i>`;
        for (let i = 1; i <= 5; i += 1) {
            html += `<i class="rating_star ${index === i ? this.shapeClass : ''}" data-index="${i}"></i>`;
        }

        return html;
    }
}

export default Rating;
