import 'js/bootstrap';
import $ from 'jquery';
import { serviceCollectStatus } from 'js/service/common';

/**
 * 商品-异步获取收藏数|是否收藏
 * @param {String}
 */
const asyncGetcollectControl = {
    initApp() {
        this.collectControl();
    },
    async collectControl() {
        const dataCode = [];
        const itemWrap = $('.js-isCollect');
        const likeCtrl = $('.gbGoodsItem_ctrl');
        if (typeof itemWrap !== typeof undefined && itemWrap !== false) {
            itemWrap.each((index, item) => {
                const tahtSef = $(item);
                dataCode.push(tahtSef.data('collect-code'));
            });
            try {
                // 两次调用...
                // debugger;
                if (dataCode && dataCode.length > 0) {
                    const res = await serviceCollectStatus.http({
                        errorPop: false,
                        isCancel: false,
                        params: {
                            goodsSnlist: dataCode.join(','),
                        },
                    });
                    if (+res.status === 0) {
                        if (res.data && res.data.length > 0) {
                            res.data.forEach((item, index) => {
                                const resIndex = res.data[index];
                                const renderItem = likeCtrl.find(`a[data-collect-id="${res.data[index].goodSn}"]`);
                                let collectNum = res.data[index].skuNum;
                                if (collectNum < 1) {
                                    collectNum = 0;
                                } else if (collectNum > 1000) {
                                    collectNum = '999+';
                                }
                                renderItem.attr({
                                    'data-favid': `${resIndex.id}`,
                                    'data-vircode': `${resIndex.virCode}`,
                                }).find('.js-likeCount').text(`(${collectNum})`);
                                if (resIndex.fav === true) {
                                    if (!renderItem.hasClass('collected')) {
                                        renderItem.addClass('collected');
                                    }
                                }
                            });
                        }
                    }
                }
            } catch (error) {
                console.log(error);
                // throw new Error(error);
            }
        }
    },
};

export default asyncGetcollectControl;
