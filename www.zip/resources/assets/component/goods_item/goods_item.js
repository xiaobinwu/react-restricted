/*
 * name: goodsItem（全站商品列表页橱窗）
 * author: duanmin
 * date: 2017/12/26
 */
import 'js/bootstrap';
import $ from 'jquery';
import PubSub from 'pubsub-js';
import layer from 'layer';
import Rating from 'component/rating/rating.js';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import { serviceDealsAddlikes, serviceDealsDeletelikes } from 'js/service/promotion';
import { serviceCollectAdd, serviceCollectRemove, serviceGoodlistCollectRemove } from 'js/service/common';
import render from './goods_item.art';
import brandUpRender from './brandup_item.art';
import './goods_item.css';

runtime.trans = trans;

// 商品橱窗分类样式
runtime.skins = [
    'gbGoodsItem-index', // 0-首页推荐版块
    'gbGoodsItem-user', // 1-用户中心收藏页
    'gbGoodsItem-search', // 2-分类页/搜索页
    'gbGoodsItem-searchCloth', // 3-服装分类页
    'gbGoodsItem-deals', // 4-Deals频道页
    'gbGoodsItem-zone', // 5-0.99 Zone版块页
    'gbGoodsItem-clear', // 6-Clearance清仓页
    'gbGoodsItem-newArrival', // 7-new_arrival NEW频道页
];
runtime.GLOBAL = window.GLOBAL; // 国家渠道

const GoodsItem = {
    /**
     * 初始化（调用入口）
     * @param  {Object} options.container 父容器
     * @param  {Number} options.type      类型
     * @param  {Array}  options.list      列表数据
     * @param  {Boolean} options.append   数据添加类型
     */
    init({
        container = $(document),
        type = 0,
        list = [],
        append = false,
        ...alias
    } = {}) {
        // 模板渲染（用于异步获取）
        if (list && list.length > 0) {
            let viewRender = render;
            if ([4, 5, 7].indexOf(type) >= 0) {
                viewRender = brandUpRender;
            }
            container[append ? 'append' : 'html'](viewRender({
                type,
                list,
                ...alias,
            }));

            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: container[0]
            });
        }

        // 星星评分
        new Rating();

        // 异步更新商品收藏状态
        // asyncGetcollectControl.initApp();

        // 定义事件
        if (container.closest('.goodsItem-initialized').length === 0) {
            container.addClass('goodsItem-initialized');
            container.on('click', '.js-opera', (e) => {
                e.preventDefault();
                const $this = $(e.currentTarget);
                const opera = $this.data('opera');

                if (opera === 'addToCart') GoodsItem.addToCart($this); // 添加购物车
                else if (opera === 'addlikes') GoodsItem.addlikes($this); // 添加点赞
                else if (opera === 'deletelikes') GoodsItem.deletelikes($this); // 取消点赞
                else if (opera === 'collect') GoodsItem.collect($this); // 添加收藏
                else if (opera === 'videoShow') GoodsItem.videoShow($this); // 播放视频
                else if (opera === 'cancelCollect') GoodsItem.cancelCollect($this); // 取消收藏
                else if (opera === 'deleteCollect') GoodsItem.deleteCollect($this); // 删除收藏
                else if (opera === 'toggleCollect') GoodsItem.toggleCollect($this); // 切换收藏
                else if (opera === 'likesControl') GoodsItem.likesControl($this); // 切换点赞
            });
        }
    },

    /**
     * 添加购物车
     * @param {Object} $btn 操作按钮
     */
    addToCart($btn) {
        const goodsSku = $btn.data('sku');
        const goodsQty = $btn.data('num');
        const goodsWid = $btn.data('wid');
        const goodsImg = $btn.data('img');

        PubSub.publish('sysAddToCart', {
            goods: {
                goodsSn: goodsSku,
                qty: goodsQty,
                warehouseCode: goodsWid,
            },
            cartAni: {
                imgSrc: goodsImg,
                origin: $btn,
            },
        });
    },

    /**
     * 播放视频
     * @param {Object} $btn 操作按钮
     */
    videoShow($btn) {
        const video = $btn.data('video');
        const videoList = video ? video.split(',') : [];
        const len = videoList.length;

        if (len === 1) {
            GoodsItem.cateSwalBoxControl(videoList[0]);
        } else if (len > 1) {
            const randomIndex = Math.floor(Math.random() * len);
            GoodsItem.cateSwalBoxControl(videoList[randomIndex]);
        } else {
            layer.msg('There is no video.');
        }
    },

    /**
     * 播放视频弹框
     * @param {Object} $btn 操作按钮
     */
    async cateSwalBoxControl(extendVideoCode) {
        const showVideoTemp = await import('./show_video.art');
        layer.open({
            content: showVideoTemp({ videoCode: extendVideoCode }),
            area: ['auto', 'auto'],
            btn: false,
            closeBtn: 1,
        });
    },

    /**
     * 添加点赞
     * @param {Object} $btn 操作按钮
     */
    async addlikes($btn) {
        const likeCode = $btn.data('deals-id');
        const $likesCount = $btn.find('.js-likesCount');
        const likeStrNum = Number($likesCount.text().replace(/[()]/g, ''));

        const res = await serviceDealsAddlikes.http({
            errorPop: false,
            params: {
                deals_id: likeCode,
            },
        });
        if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        } else if (+res.status === 0) {
            if (!$btn.hasClass('on')) {
                $btn.addClass('on');
                $likesCount.text(`(${likeStrNum + 1})`);
            }
        }
    },


    /**
     * 取消点赞
     * @param {Object} $btn 操作按钮
     */
    async deletelikes($btn) {
        const likeCode = $btn.data('deals-id');
        const $likesCount = $btn.find('.js-likesCount');
        const likeStrNum = Number($likesCount.text().replace(/[()]/g, ''));

        const res = await serviceDealsDeletelikes.http({
            errorPop: false,
            params: {
                deals_id: likeCode,
            },
        });
        if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        } else if (+res.status === 0) {
            if ($btn.hasClass('on')) {
                $btn.removeClass('on');
                if (likeStrNum > 0) {
                    $likesCount.text(`(${likeStrNum - 1})`);
                }
            }
        }
    },


    /**
     * 切换点赞
     * @param {Object} $btn 操作按钮
     */
    likesControl($btn) {
        if ($btn.hasClass('on')) {
            GoodsItem.deletelikes($btn);
        } else {
            GoodsItem.addlikes($btn);
        }
    },


    /**
     * 添加收藏
     * @param {Object} $btn 操作按钮
     */
    async collect($btn) {
        const $likeCount = $btn.find('.js-likeCount');
        const dataSn = $btn.data('sku');
        const dataWid = $btn.data('wid');
        const $collectNum = $('.js-collectNum');
        const collectStrNum = Number($collectNum.text());
        const viewStrNum = Number($likeCount.text().replace(/[()]/g, ''));

        const data = await serviceCollectAdd.http({
            errorPop: false,
            data: {
                goods: [`${dataSn}_${dataWid}`],
            },
        });

        if (+data.status === 0) {
            const $likeIcon = $btn.find('.gbGoodsItem_likeIcon');
            if (!$likeIcon.hasClass('sp-collected')) {
                $likeIcon.addClass('sp-collected');
                $likeIcon.addClass('animation');
                $btn.find('.js-collectionNum').show().addClass('add-animation').html('+1')
                    .hide(300);
                if (!Number.isFinite(viewStrNum)) {
                    $likeCount.text('999+');
                } else {
                    $likeCount.text(`${viewStrNum + 1}`);
                }
                $collectNum.text(`${collectStrNum + 1}`);
            }
        } else if (data.data && data.data.redirectUrl) {
            window.location.href = data.data.redirectUrl;
        } else {
            layer.msg(data.msg);
        }
    },

    /**
     * 取消收藏
     * @param {Object} $btn 操作按钮
     */
    async cancelCollect($btn) {
        const $likeCount = $btn.find('.js-likeCount');
        const dataSn = $btn.data('sku').toString();
        const virCodex = $btn.data('vircode').toString();
        const $collectNum = $('.js-collectNum');
        const collectStrNum = Number($collectNum.text());
        const viewStrNum = Number($likeCount.text().replace(/[()]/g, ''));

        const data = await serviceGoodlistCollectRemove.http({
            errorPop: false,
            data: {
                goodSn: dataSn,
                virCode: virCodex,
            },
        });

        if (+data.status === 0) {
            const $likeIcon = $btn.find('.gbGoodsItem_likeIcon');
            if (!$btn.hasClass('cancelCollect')) {
                $likeIcon.removeClass('sp-collected');
                $likeIcon.addClass('animation');
                $btn.find('.js-collectionNum').show().addClass('add-animation').html('-1')
                    .hide(300);
                if (!Number.isFinite(viewStrNum)) {
                    $likeCount.text('999+');
                } else {
                    $likeCount.text(`${viewStrNum - 1}`);
                }
                if (collectStrNum > 0) {
                    $collectNum.text(`${collectStrNum - 1}`);
                }
            }
        } else if (data.data && data.data.redirectUrl) {
            window.location.href = data.data.redirectUrl;
        } else {
            layer.msg(data.msg);
        }
    },

    /**
     * 切换收藏
     * @param {Object} $btn 操作按钮
     */
    toggleCollect($btn) {
        const $likeIcon = $btn.find('.gbGoodsItem_likeIcon');
        if ($likeIcon.hasClass('sp-collected')) {
            GoodsItem.cancelCollect($btn);
        } else {
            GoodsItem.collect($btn);
        }
    },

    /**
     * 删除收藏
     * @param {Object} $btn 操作按钮
     */
    async deleteCollect($btn) {
        const $collectNum = $('.js-collectNum');
        const collectStrNum = Number($collectNum.text());
        const data = await serviceCollectRemove.http({
            errorPop: false,
            loading: true,
            data: {
                favId: [`${$btn.data('favid')}`],
            },
        });

        if (+data.status === 0) {
            if (collectStrNum > 0) {
                $collectNum.text(`${collectStrNum - 1}`);
            }
            $btn.closest('.gbGoodsItem').remove();
        } else if (data.data && data.data.redirectUrl) {
            window.location.href = data.data.redirectUrl;
        } else {
            layer.msg(data.msg);
        }
    },
};

export default GoodsItem;
