/*
 * name: Searcher（搜索器）
 * author: Jiazhan Li
 * date: 2018/06/04
 *
 ******************************** 《html》 ********************************

    <input type="text" id="js-selector">

 ******************************** 《调用方式》 ********************************

    new Searcher({
        selector: '.js-searcher',       // 选择器
        skin: 'custom-skin',            // 自定义样式
        keyOfName: 'countryName',       // 属性名-选项文本
        keyOfCode: 'countryCode',       // 属性名-选项值
        minLength: 5,                   // 满足最小长度才发起搜索

        // 接口对象（Promise实例）
        async service(key) {
            const res = await serviceGetData.http({
                params: {
                    key,
                }
            });
            return res.data;
        },

        // 选中值时触发的回调函数
        onChange(data, target) {
            console.log(data);
        }
    });

 */

import { throttle } from 'js/utils/index.js';
import 'component/dropdown/dropdown';
import './style.css';

/**
 * Single类（单个元素操作）
 * @param {Element}  element        // 元素
 * @param {String}   skin           // 自定义样式
 * @param {String}   keyOfName      // 属性名-选项文本
 * @param {String}   keyOfCode      // 属性名-选项值
 * @param {Number}   minLength      // 满足最小长度才发起搜索
 * @param {String}   preventDefault // 阻止组件默认行为
 * @param {Service}  service        // 接口对象（Promise实例）
 * @param {Function} onChange       // 选中值时触发的回调函数
 */
class Single {
    constructor({
        element = null,
        skin = '',
        keyOfName = 'name',
        keyOfCode = 'code',
        minLength = 0,
        preventDefault = false,
        service = () => {},
        onChange = () => {},
    } = {}) {
        this.element = element;
        this.skin = skin;
        this.name = keyOfName;
        this.code = keyOfCode;
        this.minLength = minLength;
        this.preventDefault = preventDefault;
        this.service = service;
        this.onChange = onChange;
        this.createModel();
        this.bindEvent();
    }

    /**
     * 创建搜索列表元素
     */
    createModel() {
        this.$content = document.createElement('div');
        this.$content.className = 'searcher_content';
        this.$menu = document.createElement('div');
        this.$menu.className = 'searcher_menu';
        this.$model = document.createElement('div');
        this.$model.className = `searcher ${this.skin}`;
        this.$menu.appendChild(this.$content);
        this.$model.appendChild(this.$menu);
        this.element.parentNode.insertBefore(this.$model, this.element.nextSibling);

        // 初始化下拉组件
        this.dropdown = $(this.$model).dropdown();

        // 防止点击输入框导致关闭菜单
        this.element.classList.add(this.$model.className.split(' ').find(item => /^DROPDOWN/.test(item)));
    }

    /**
     * 事件绑定
     */
    bindEvent() {
        this.isArrowToRequest = true; // 是否允许再次发起请求
        this.isChangeBeforeResponse = false; // 请求未响应期间是否改变过输入框中的值

        /**
         * 搜索请求
         * @return {Promise<void>}
         */
        this.search = async () => {
            if (this.isArrowToRequest) {
                this.isArrowToRequest = false;
                try {
                    if (this.element.value.length >= this.minLength) {
                        this.data = await this.service(this.element.value);
                    } else {
                        this.data = [];
                    }
                } catch (e) {
                    this.data = [];
                }

                this.isArrowToRequest = true;

                if (this.data.length > 0) {
                    this.$content.innerHTML = this.data.map((item, index) => {
                        const code = item[this.code];
                        const name = item[this.name];
                        return `<div class="searcher_item" data-code="${code}" data-index="${index}">${name}</div>`;
                    }).join('');
                    this.dropdown.dropdown('open');
                } else {
                    this.dropdown.dropdown('close');
                }

                if (this.isChangeBeforeResponse) {
                    this.isChangeBeforeResponse = false;
                    this.search();
                }
            } else {
                this.isChangeBeforeResponse = true;
            }
        };

        // 搜索请求
        this.element.addEventListener('input', throttle(this.search, 200));

        // 点击选中值
        this.$model.addEventListener('click', (e) => {
            if (e.target.className === 'searcher_item') {
                if (!this.preventDefault) this.element.value = $(e.target).text();
                this.onChange(this.data[e.target.dataset.index], this.element);
                this.dropdown.dropdown('close');
            }
        });
    }
}

/**
 * Searcher类（用来处理多个实例）
 * @param {String}   selector       // 元素选择器
 * @param {String}   skin           // 自定义样式
 * @param {String}   keyOfName      // 属性名-选项文本
 * @param {String}   keyOfCode      // 属性名-选项值
 * @param {Number}   minLength      // 满足最小长度才发起搜索
 * @param {String}   preventDefault // 阻止组件默认行为
 * @param {Promise}  service        // 接口对象（Promise实例）
 * @param {Function} onChange       // 选中值时触发的回调函数
 */
export default class Searcher {
    constructor({
        selector = '',
        skin = '',
        keyOfName = 'name',
        keyOfCode = 'code',
        minLength = 0,
        preventDefault = false,
        service = () => {},
        onChange = () => {},
    } = {}) {
        this.list = [];
        this.elements = getElements(selector);
        this.elements.forEach((element) => {
            this.list.push(new Single({
                element,
                skin,
                keyOfName,
                keyOfCode,
                minLength,
                preventDefault,
                service,
                onChange,
            }));
        });
    }
}

/**
 * 返回元素列表（支持选择器字符串、Element对象、NodeList对象、数组等）
 * @param selector
 * @return {Array}
 */
function getElements(selector) {
    let elements = [];
    try {
        if (typeof selector === 'string') {
            elements = document.querySelectorAll(selector);
        } else if (selector.nodeType === 1) {
            elements = [selector];
        } else if (selector.length > 0) {
            elements = [...selector].filter(item => item.nodeType === 1);
        } else {
            elements = [];
        }
    } catch (e) {
        elements = [];
    }
    return [...elements];
}
