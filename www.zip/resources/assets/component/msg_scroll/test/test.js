import '../msg_scroll.css';
import MsgScroll from '../msg_scroll.js';

new MsgScroll('.js-msgScroll', {
    interval: 2000,
});
