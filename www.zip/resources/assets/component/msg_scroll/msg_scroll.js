import './msg_scroll.css';

class MsgScroll {
    constructor(jqSelector, options = {}) {
        this.$wrap = $(jqSelector);

        if (this.$wrap.length) {
            this.options = Object.assign({
                // 滚动间隔
                interval: 2000,
                // 鼠标移入是否暂停
                hoverStop: true,
            }, options);

            this.$wrap.get(0).innerHTML += this.$wrap.get(0).innerHTML;

            this.start();
            this.bindEvent();
        }
    }

    bindEvent() {
        const self = this;
        if (this.options.hoverStop) {
            this.$wrap.hover(() => {
                self.stop();
            }, () => {
                self.start();
            });
        }
    }

    start() {
        const { $wrap, options } = this;
        const wrapHeight = $wrap.outerHeight();
        const childLength = $wrap.children().length;

        function scroll() {
            const scrollDis = `+=${wrapHeight}`;
            $wrap.stop().animate({
                scrollTop: scrollDis,
            }, () => {
                if ($wrap.scrollTop() >= wrapHeight * (childLength / 2)) {
                    $wrap.scrollTop(0);
                }
            });
        }
        clearInterval(this.timer);
        this.timer = setInterval(scroll, options.interval);
    }

    stop() {
        clearInterval(this.timer);
    }
}

export default MsgScroll;

