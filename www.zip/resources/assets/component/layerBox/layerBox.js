import loadingGif from 'common/img/loading.gif';
import './layerBox.css';

/**
 * [loading 加载种，整个页面覆盖蒙层]
 */
function loading() {
    const DIV = document.createElement('DIV');
    const IMG = new Image();
    DIV.className = 'layerBox_loading';
    IMG.src = loadingGif;
    DIV.appendChild(IMG);
    document.body.appendChild(DIV);
    return DIV;
}

/**
 * [close 删除弹框Element]
 * @param  {[type]} node [需要删除的元素]
 */
function close(node) {
    node.parentNode.removeChild(node);
}

/**
 * [msg 消息提示，3秒定时器关闭]
 * @param  {[type]} content [提示内容]
 */
function msg(content) {
    const DIV = document.createElement('DIV');
    DIV.className = 'layerBox_msg scalebox';
    const TEXT = document.createTextNode(content);
    DIV.appendChild(TEXT);
    document.body.appendChild(DIV);
    const width = parseFloat(window.getComputedStyle(DIV, null).getPropertyValue('width'));
    DIV.style.marginLeft = `-${width / 2}px`;
    setTimeout(() => {
        close(DIV);
    }, 3000);
}

export {
    loading,
    close,
    msg,
};
