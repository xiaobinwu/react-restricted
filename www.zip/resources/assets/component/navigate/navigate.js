/**
 * 导航组件
 * @author  lijiazhan (lijiazhan@globalegrow.com)
 * @date    2018/01/19
 */

export default class Navigate {
    constructor(selector, params) {
        this.nav = $(selector); // 容器
        this.cursor = this.nav.find('.cursor'); // 光标
        this.items = this.nav.find('.case'); // 子项
        this.activeCase = this.items.filter('.on'); // 上一次聚焦的子项

        // 配置
        this.config = Object.assign({
            default: null, // 默认选中的位置
            onChange: $.noop // 选中元素后的回调
        }, params);

        // 定义选中事件
        this.nav.on('click', '.case', (e) => {
            this.currentCase = $(e.currentTarget);
            if (!this.currentCase.hasClass('on')) {
                this.onClick();
            }
        });

        // 默认跳转
        if (typeof this.config.default === 'number') {
            this.goto(this.config.default);
        }
    }

    // 每次跳转都会执行的函数
    // 这里涉及光标位置的计算，以及调用回调函数
    onClick() {
        const $case = this.currentCase;
        this.caseLeft = $case.position().left;
        this.caseWidth = $case.width();

        if (this.activeCase.length) this.activeCase.removeClass('on');
        this.activeCase = $case.addClass('on');
        this.config.onChange($case);
        this.cursor.css({
            left: this.caseLeft,
            width: this.caseWidth
        });
    }

    // 主动触发跳转到指定位置
    goto(index) {
        this.items.eq(index).trigger('click');
    }
}
