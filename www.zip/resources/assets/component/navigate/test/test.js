import Navigate from '../navigate';

// 下面这个是滚动版
// import Navigate from '../navigate.scroll';

// 调用方式1：
// 默认选中第一个导航，且带回调函数
new Navigate('.selector', {
	default: 0,
	onChange($case) {
		// to do something...
	}
});

// 调用方式2：
// 假如你想通过程序去跳转到某个导航
const nav = new Navigate('.selector', {
	default: 0,
	onChange($case) {
		// to do something...
	}
});

nav.goto(2); // 跳到第三个导航
