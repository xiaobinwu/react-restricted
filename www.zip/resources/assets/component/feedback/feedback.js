/* eslint-disable max-len */
import $ from 'jquery';
import layer from 'layer';
import { serviceFeedBack } from 'js/service/common';
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';
import PubSub from 'pubsub-js';
import { getUserStatus } from 'js/core/user.js';
import 'js/utils/validation.config.js';
import './feedback.css';

const { SUPPORT_URL } = window.GLOBAL || {};

runtime.trans = trans;
class FeedBack {
    static Files = [];
    static Sku = '';
    static msgEmail = '';
    static bindEvent() {
        // 避免反复执行
        if (window.$feedbackInit) {
            return;
        }
        window.$feedbackInit = true;

        getUserStatus({
            toLogin: 0
        }).then((userInfo) => {
            if (userInfo.user) {
                FeedBack.msgEmail = userInfo.user.email;
            }
        });

        // 点击入口弹窗
        $('body').on('click', '.js_feedback', () => {
            FeedBack.feedbackShow();
        });
        // 添加
        $('body').on('click', '.js_fileAdd', () => {
            const uploadDom = `
                <div class="reportShow_upload">
                    <span class="reportShow_selectFile reportShow_float reportShow_border-radius">${trans('base.select_file')}
                        <input type="file" value="${trans('base.select_file')}" class="reportShow_selectFileInput reportShow_float reportShow_border-radius"/>
                    </span>
                    <input type="text" class="reportShow_showText reportShow_float reportShow_border-radius"
                        readonly="readonly" placeholder="${trans('base.no_file')}" />
                    <span class="reportShow_addFile js_fileReduce reportShow_float reportShow_border-radius"><i class="icon-reduce"></i></span>
                </div>`;
            const uploadLength = $('.reportShow_upload').length;
            if (uploadLength <= 2) {
                $('.reportShow_fileRight').append(uploadDom);
            }
            if (uploadLength >= 2) {
                $('.js_fileAdd').hide();
            }
        });
        // 删除
        $('body').on('click', '.js_fileReduce', function remove() {
            const $this = $(this);
            $this.parent().remove();
            const uploadLength = $('.reportShow_upload').length;
            if (uploadLength <= 2) {
                $('.js_fileAdd').show();
            }
        });
    }
    static async feedbackShow() {
        const { pageType } = window.TrackData && window.TrackData.common ? window.TrackData.common : '';
        let tmp;
        if (pageType !== 'goods') {
            const feedbackTemp = await import('./common/show_fb.art');
            tmp = feedbackTemp({
                SUPPORT_URL
            });
        } else {
            const feedbackTemp = await import('./common/show_fbGood.art');
            const goodsData = JSON.parse(window.sessionStorage.getItem('gb_goodsInfo'));
            tmp = feedbackTemp({
                SUPPORT_URL,
                defaultEmail: FeedBack.msgEmail,
                ...goodsData
            });
            FeedBack.Sku = goodsData.goodsSn;
        }
        layer.open({
            type: 1, // 弹窗
            content: tmp,
            area: ['660px', 'auto'],
            closeBtn: 1,
            skin: 'feedback',
            end() {
                FeedBack.Files = [];
            },
            success(layero) {
                const form = $(layero[0]).find('form').get(0);
                FeedBack.validate(form);
                PubSub.publish('sysUpdateCurrency', {
                    context: layero[0],
                });
            },
        });
        FeedBack.judge();
    }
    // 上传文件
    static judge() {
        $('.reportShow_fileRight').on('change', 'input[type="file"]', function upload() {
            const $this = $(this);
            const filePath = $this.val();
            const arr = filePath.split('\\');
            const num = arr.length - 1;
            const fileName = arr[num];
            $this.parents('.reportShow_upload').find('.reportShow_showText').val(fileName);
        });
    }

    static async upload(form) {
        const files = [];
        const fileDoms = document.querySelectorAll('.reportShow_selectFileInput');
        const WebUploader = await import('webuploader');
        [...fileDoms].forEach((item) => {
            if (item.files.length) {
                const wuFile = new WebUploader.File(new WebUploader.Lib.File(WebUploader.guid('rt_'), item.files[0]));
                files.push(wuFile);
            }
        });
        if (files.length) {
            const uploader = new WebUploader.Uploader({
                extensions: 'gif,jpg,jpeg,bmp,png',
                mimeTypes: 'image/*',
                fileVal: 'files',
                formData: {
                    site: window.GLOBAL.SITE_FLAG,
                },
                server: `${window.GLOBAL.DOMAIN_UPLOAD}/review/upload?tos3=1`,
            });
            uploader.on('uploadSuccess', (file, res) => {
                FeedBack.Files.push(res.file);
                if (uploader.getStats().progressNum === 0) {
                    FeedBack.submitForm(form);
                }
            });
            uploader.addFiles(files);
            uploader.upload();
        } else {
            FeedBack.submitForm(form);
        }
    }
    static async submitForm(form) {
        const formdata = new FormData(form);
        let pageType = window.TrackData && window.TrackData.common ? window.TrackData.common.pageType : '';
        if (pageType === 'goods') {
            formdata.append('sku', FeedBack.Sku || '');
            pageType = 'goodsDetail';
        }
        formdata.append('platform', 1);
        formdata.append('pipeline', window.GLOBAL.PIPELINE);
        formdata.append('lang', window.GLOBAL.LANG);
        formdata.append('source_url', window.location.href);
        formdata.append('source_type', pageType);
        if (FeedBack.Files.length) {
            formdata.append('file', FeedBack.Files.join(','));
        }
        const res = await serviceFeedBack.http({
            data: formdata,
        });
        if (res.msg) {
            layer.msg(res.msg, () => {
                if (res.status === 0) {
                    layer.closeAll('page');
                }
            });
        }
    }
    static validate(formDom) {
        const $form = $(formDom);
        $form.validate({
            rules: {
                email: {
                    email: true,
                },
                content: {
                    required: true,
                },
            }
        });
        $form.on('submit', (e) => {
            e.preventDefault();
            if ($form.valid()) {
                const $btn = $form.find('button');
                $btn.addClass('loading');
                FeedBack.upload($form[0]);
            }
        });
    }
}

export default FeedBack;
