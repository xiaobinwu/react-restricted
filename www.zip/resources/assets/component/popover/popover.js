// import $ from 'jquery';
import Popper from './utils/popper';
import './popover.css';

/**
 *  dom 触发元素： jquery选择器/dom对象/jquery 对象 ， 必填
 *  title：默认标题
 *  placement 提示位置暂时只支持 bottom
 *  placement: top/top-start/top-end/bottom/bottom-start/bottom-end/left/left-start/left-end/right/right-start/right-end
 *
 *  content 内容不能为空 字符串/jquery选择器/dom对象/jquery 对象
 *  width: 宽度
 */

// 调整 兼容ie9
// https://github.com/ElemeFE/element/blob/89509b5fe37499a2f902280bc3a5fcf16913327d/src/utils/popper.js

class Popover {
    constructor(dom, options) {
        this.dom = dom;
        this.options = Object.assign({
            placement: 'bottom',
            title: 'title title title title title ',
            content: 'content hhahaha ',
            width: '200',
            trigger: 'hover',
        }, options);

        this.mounted();
    }

    mounted() {
        this.popper = new Popper(document.getElementById('js-popover'), {
            content: 'test content',
        }, {
            placement: 'bottom-start',
        });
    }
}
export default Popover;

