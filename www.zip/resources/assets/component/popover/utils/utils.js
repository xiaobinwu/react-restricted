/**
 * Created by Liu.Jun on 2018/2/24.
 */

let curId = 0;
export default function generateId() {
    // return Math.floor(Math.random() * 10000);
    curId += 1;
    return curId;
}
