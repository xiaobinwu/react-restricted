import '../popover.css';
import Popover from '../popover.js';

console.log(new Popover());
