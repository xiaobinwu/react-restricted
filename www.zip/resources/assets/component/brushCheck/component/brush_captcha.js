/**
 * 普通的验证码方式
 */
import layer from 'layer';
import temp from '../template/temp.art';

export default (resolve) => {
    const layerIndex = layer.open({
        type: 1,
        content: temp({
            imgUrl: `/captcha/default?${Math.random()}`
        }),
        shadeClose: false, // 开启遮罩关闭
    });
    const $brushVerify = $('#js-brushVerify');
    const $verifyImg = $('#js-verifyImg');
    const $protectBrushBtn = $('#js-protectBrushBtn');
    // 刷新验证码
    const refreshVerify = function refreshVerify() {
        $brushVerify.val('');
        $verifyImg.attr('src', `/captcha/default?${Math.random()}`);
    };

    // 触发验证码刷新
    $verifyImg.on('click', () => {
        refreshVerify();
    });
    $protectBrushBtn.on('click', () => {
        resolve({
            captchaType: 'captcha',
            gbcaptcha: $brushVerify.val()
        });
        layer.close(layerIndex);
    });
};
