/**
 * Created by Liu.Jun on 2018/9/7.
 */

import 'js/utils/testFlag.js'; // 测试环境标志
import Thirdparty from 'js/core/thirdparty';
import asyncScript from 'js/utils/asyncScript.js';
import preload from 'js/core/preload/preload.js'; // 页面预加载
import updateMessageCount from 'js/core/updateMessageCount.js'; // 获取站内信数量
import performance from 'js/core/performance'; // 前端性能日志上报
import 'js/core/liveChatConfig.js'; // live chat 售前客服入口
import { initFirebase } from 'js/core/firebase/main.js'; // firebase fcm
// import { runServerWork } from 'js/sw/runSw.js'; // server work

export default () => {
    // AFF 系统的推广链接的cookie记录
    new Thirdparty();

    // 三方 异步script
    ['//js.affasi.com/affasi_web.min.js', window.GLOBAL.LOGSSS_URL].map(item => asyncScript({
        url: item
    }));

    // serverWork
    // runServerWork();

    // load 后 1s 预加载
    setTimeout(() => {
        preload(window.nextCommon);
    }, 1000);
    // firebase
    initFirebase();
    // 全站站内信消息
    try {
        if (window.TrackData.common.pageType !== 'login' && window.TrackData.common.pageType !== 'cart') {
            updateMessageCount(document.querySelectorAll('.js-messageCountHeader'), document.querySelectorAll('.js-messageCount_all'));
        }
    } catch (e) {
        // nothing...
    }

    // 前端性能上报
    performance();
};
