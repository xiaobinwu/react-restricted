import Track from 'js/track/track';

const NEWARRIVA_CONFIG = {
    // 大banner
    '.js-trackNewArrivalBanner': {
        module: 'A_1',
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            return {
                mdlc: `md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1,
            };
        },
    },

    // 大banner下方3个广告位
    '.js-trackBannerItem': {
        module: 'A_@',
        start: 2,
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            return {
                mdlc: `md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1
            };
        },
    },

    // 新品版块
    '.js-trackNewProdItem': {
        module: 'B_1',
        explore: 'self',
        click: '.newArrivalProdLink',
        pageModule: 'mr',
        itemType: 'goods',
        recordOrigin: 1,
        exploreRoot: '.js-siteNewArrivalSlick',
        exploreFirstShow: 4,
        customUbcta({ module, target }) {
            return {
                mrlc: `mr_${module}`,
                type: 'mr',
                rank: +$(target).attr('data-true-index') + 1,
            };
        },
    },

    // 定金膨胀版块广告位
    '.js-trackOrderBanner': {
        module: 'C_1',
        explore: 'self',
        click: '.preOrderProdBannerImg',
        pageModule: 'md',
        itemType: 'banner',
        recordOrigin: 1,
        exploreRoot: '.js-sitePreOrderSlick',
        exploreFirstShow: 1,
        customUbcta({ module, target }) {
            return {
                mrlc: `md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1,
            };
        },
    },

    // 定金膨胀版块推荐位
    '.js-trackOrderProdItem': {
        module: 'C_1',
        explore: 'self',
        click: ['.preOrderProd_thumb', '.preOrderProd_title', '.preOrderProd_payDeposit'],
        pageModule: 'mr',
        itemType: 'goods',
        recordOrigin: 1,
        exploreRoot: '.js-sitePreOrderSlick',
        exploreFirstShow: 4,
        customUbcta({ module, target }) {
            return {
                mrlc: `mr_${module}`,
                type: 'mr',
                rank: +$(target).attr('data-true-index') + 1,
            };
        },
    },

    // 首发banner版块
    '.js-trackPreviousProdBanner': {
        module: 'D_1',
        explore: 'self',
        click: ['.previousProdBannerImage'],
        pageModule: 'md',
        itemType: 'banner',
        recordOrigin: 1,
        exploreRoot: '.js-sitePreviousBannerSlick',
        exploreFirstShow: 5,
        customUbcta({ module, target }) {
            return {
                mrlc: `md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1,
            };
        },
    },

    // 商品位曝光
    '.js-trackGoodsItem': {
        module: 'E_1',
        explore: 'self',
        itemType: 'goodsItem',
        click: ['.gbGoodsItem_thumb', '.gbGoodsItem_title'],
        exploreRoot: 'root',
        pageModule: 'mr',
        async: true,
        observer: '.js-trackNewCollectionProdList',
        customUbcta({ module, target }) {
            return {
                mrlc: `mr_${module}`,
                rank: +$(target).attr('data-true-index') + 1,
                type: 'mr',
            };
        },
    },

    // 加入购物车
    '.js-trackAddCart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        },
    },

    // 加入收藏
    '.js-trackCollect': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'addToCollect',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },

    // 视频播放
    '.js-trackVideoShow': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'videoShow',
        customData: {
            x: 'video',
        },
    },
};

class NewArrivaTrack extends Track {
    // 页面曝光
    explorePageData() {
        const trackC = $('input[name=track-infor]').attr('data-track-inofo').split('_');
        const p = `${trackC[1]}_${trackC[2]}`;
        const filter = {
            view: trackC[0],
            sort: trackC[1],
            page: trackC[2],
        };

        const data = {
            p, filter
        };

        return data;
    }

    customExploreTrackCallback({ target, configData }) {
        const { itemType } = configData || {};
        const trackC = $('input[name=track-infor]').attr('data-track-inofo').split('_');
        if (itemType === 'goodsItem') {
            return {
                filter: {
                    view: trackC[0],
                    sort: trackC[1],
                    page: trackC[2],
                }
            };
        }
        return {};
    }
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};
        // 加入购物车|加入收藏|视频播放
        if (itemType === 'addToCart' || itemType === 'addToCollect' || itemType === 'videoShow' || itemType === 'goodsItem') {
            const trackI = $(dom).parents('li').data('true-index');
            const trackP = $(dom).parents('li').data('trackcode').split('_');
            const trackC = $('input[name=track-infor]').attr('data-track-inofo').split('_');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: +trackI + 1,
                },
                filter: {
                    view: trackC[0],
                    sort: trackC[1],
                    page: trackC[2] ? trackC[2] : '1',
                },
            };
        }

        return { ...data, ...configData.customData };
    }
}

const newArrivaTrack = new NewArrivaTrack({
    config: NEWARRIVA_CONFIG,
    page: 'arrival',
    noReleaseConnection: true, // 因底部推荐有持续加载，无需释放突变监听
});

export default () => {
    newArrivaTrack.run();
};
