import Track from 'js/track/track';
import GoodsInfo from 'js/core/goods/GoodsInfo.js'; // 商品业务逻辑
import { getUrlQuery } from 'js/utils/index.js';
import RecordToGoods from 'js/core/goods/recordToGoods.js'; // 记录进入商详来源
import Cookies from 'js/utils/cookie';
import { STORAGE_SOURCE_ORIGIN } from 'common/js/variables';

const linkParameters = getUrlQuery();
// 商详来源记录,仅当属性切换时，是记录上一级来源，不记录同商品不同属性之间的来源
const { referrer, isChangeAttr } = RecordToGoods.get();
const preLink = (isChangeAttr === true) ? referrer : document.referrer;

RecordToGoods.set('isChangeAttr', false);
RecordToGoods.set('referrer', preLink);

// 如果有实际来源，则让所有曝光和点击记录原始来源
if (preLink) {
    window.TrackData.common.pl = preLink;
}

const GOODSINFO = GoodsInfo.get();
const GOODS_CONFIG = {
    // 加车
    '.js-trackBtnAddCart': {
        itemType: 'addToCart',
        click: 'self',
        customData: {},
        reportOrigin: 1,
        reportBTS: 1,
    },

    // paypal快捷支付
    '.js-trackBtnPaypal': {
        itemType: 'paypal',
        click: 'self',
        customData: {},
        reportOrigin: 1,
        reportBTS: 1,
    },

    // 加收藏
    '.js-trackBtnGoodsCollect': {
        itemType: 'addToCollect',
        click: 'self',
        customData: {},
        reportOrigin: 1, // 上报来源
        reportBTS: 1, // 上报bts
    },

    // 组合买(配件)
    '.js-btnBindBuy': {
        itemType: 'buyTogether',
        click: 'self',
        customData: {},
        reportOrigin: 1,
        reportBTS: 1,
    },

    // 直接购买
    '.js-trackBtnBuyNow': {
        itemType: 'buyNow',
        click: 'self',
        customData: {},
        reportOrigin: 1,
        reportBTS: 1,
    },

    // 推荐位1
    '.js-trackRecom1': {
        module: 'A_1',
        itemType: 'goods',
        click: 'self',
        exploreRoot: '.goodsRecommend',
        explore: 'self',
        pageModule: 'mr',
        async: true, // 异步加载的数据的设置
        observer: '.js-trackRecomList1',
        exploreFirstShow: 8,
        recordOrigin: 1,
        recordBTS: 1,
    },

    // 推荐位2(其他用户也买)
    '.js-trackRecom2': {
        module: 'A_2',
        itemType: 'goods',
        click: 'self',
        exploreRoot: '.goodsAlsoBought',
        explore: 'self',
        pageModule: 'mr',
        async: true, // 异步加载的数据的设置
        observer: '.js-trackRecomList2',
        exploreFirstShow: 8,
        recordOrigin: 1,
        recordBTS: 1,
    },

    // 推荐位3(猜你喜欢)
    '.js-trackRecom3': {
        module: 'A_3',
        itemType: 'goods',
        click: 'self',
        exploreRoot: '.goodsGuessLike',
        explore: 'self',
        pageModule: 'mr',
        async: true, // 异步加载的数据的设置
        observer: '.js-trackRecomList3',
        exploreFirstShow: 8,
        recordOrigin: 1,
        recordBTS: 1,
    },

    // 推荐位4(赞助推荐)
    '.js-trackRecom4': {
        module: 'A_4',
        itemType: 'goods',
        click: 'self',
        exploreRoot: '.goodsSponsored',
        explore: 'self',
        pageModule: 'mr',
        async: true, // 异步加载的数据的设置
        observer: '.js-trackRecomList4',
        exploreFirstShow: 8,
        recordOrigin: 1,
        recordBTS: 1,
    },

    // 分享-facebook
    '.js-trackBtnShareFB': {
        itemType: 'share',
        shareType: 'fb',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 分享-twitter
    '.js-trackBtnShareTT': {
        itemType: 'share',
        shareType: 'twitter',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 分享-vk
    '.js-trackBtnShareVK': {
        itemType: 'share',
        shareType: 'vk',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 分享-pinterest
    '.js-trackBtnSharePT': {
        itemType: 'share',
        shareType: 'pinterest',
        click: 'self',
        customData: {},
        reportOrigin: 1,
    },

    // 评论-top
    '.js-trackReviewTop': {
        itemType: 'reviewTop',
        click: 'self',
        customData: {},
        recordOrigin: 1,
    },

    // 评论-suspension
    '.js-trackReviewSuspension': {
        itemType: 'reviewSuspension',
        click: 'self',
        customData: {},
        recordOrigin: 1,
    },

    // 仓库，保存页面来源
    '.js-btnWarehouseCheck': {
        itemType: 'recordOriginCustom',
        click: 'self',
    },
    // 商品属性，保存页面来源
    '.js-attrItem': {
        itemType: 'recordOriginCustom',
        click: 'self',
    },
    // 浏览历史记录
    '.goodsViewed_item': {
        click: 'self',
        explore: 'self',
        exploreRoot: 'root',
        module: 'B_1',
        async: true,
        observer: '.js-goodsViewHistory',
        itemType: 'goodsViewed',
    },
    // 语言切换
    '.js-changeMultiLang': {
        click: 'self',
        customData: {
            x: ' Languagechange'
        }
    }

};


class GoodsTrack extends Track {
    // 商详整页曝光
    explorePageData() {
        const priceData = window.goodsPriceData || {};
        const priceIE = priceData.price || '';
        const skuInfo = {
            sku: GOODSINFO.goodsSn,
            pam: 1,
            pc: GOODSINFO.categoryId,
            k: GOODSINFO.warehouseCode,
            price: priceIE,
        };
        const data = {
            ksku: GOODSINFO.goodsSn,
            skuInfo,
            p: `p${GOODSINFO.webGoodsSn}`,
            plf: 'pc',
        };
        if (linkParameters.url_source) {
            data.ubcta = {
                pc: linkParameters.url_source
            };
        }
        // 支持中心 跨域埋点
        // Cookies.set(Track.TRACK_ORIGIN, { ubcta: { fmd: 'mp' } }, { path: '.gearbest.net' });
        const TRACK_ORIGIN = Cookies.getJSON(Track.TRACK_ORIGIN);
        if (TRACK_ORIGIN) {
            setTimeout(() => {
                Cookies.remove(Track.TRACK_ORIGIN, { path: '/' });
            });
            super.setStorageSourceOrigin(TRACK_ORIGIN.ubcta);
        }

        super.mergeBTS();
        return data;
    }

    customExploreTrackCallback({
        target,
        configData
    }) {
        const { itemType, module } = configData;
        const {
            versionid, bucketid, planid, plancode, policy, trackModule
        } = target.dataset;
        const obj = {};
        if (versionid && bucketid && planid) {
            obj.bts = {
                versionid,
                bucketid,
                planid,
                plancode,
                policy,
                mrlc: trackModule
            };
        }
        if (itemType === 'goodsViewed') {
            let pageS = 'c';
            try {
                pageS = window.TrackData.common.b;
            } catch (e) {
                //
            }
            obj.ubcta = {
                name: 'Your Recently Viewed Items',
                type: 'mr',
                mrlc: `${pageS}_mr_${module}`,
                sku: target.dataset.trackKey.split('_')[0],
                rank: Number(target.dataset.index) + 1
            };
        }

        return obj;
    }

    // 点击处理（组装所需数据）
    customClickTrackCallback(config) {
        const { keyTarget, dom, module } = config;
        const { itemType, shareType } = config.configData || {};
        const num = $('#js-goodsIntroQTY').find('[name=qty]').val();

        // 埋点商品状态 0:正常  1:清仓    2:呆滞    3:滞销
        const zt = 0;
        let data = {};
        const typeCfg = {
            goods() {
                const {
                    versionid = '', bucketid = '', planid = '', plancode = '', policy = ''
                } = keyTarget.dataset;
                data.bts = {
                    versionid,
                    bucketid,
                    planid,
                    plancode,
                    policy
                };
            },
            // 加车
            addToCart: () => {
                data = {
                    skuinfo: {
                        sku: GOODSINFO.goodsSn,
                        pam: num,
                        pc: GOODSINFO.categoryId,
                        k: GOODSINFO.warehouseCode,
                        zt,
                    },
                    pm: 'mb',
                    x: 'ADT',
                    ksku: GOODSINFO.goodsSn,
                    ubcta: {
                        k: GOODSINFO.warehouseCode,
                    },
                };
                if (linkParameters.url_source) {
                    data.ubcta.pc = linkParameters.url_source;
                }
            },

            // 加收藏
            addToCollect: () => {
                data = {
                    pm: 'mb',
                    skuinfo: {
                        sku: GOODSINFO.goodsSn,
                        pam: 1,
                        pc: GOODSINFO.categoryId,
                        k: GOODSINFO.warehouseCode,
                        zt,
                    },
                    ubcta: {
                        k: GOODSINFO.warehouseCode,
                    },
                    x: 'ADF',
                };
            },

            // 组合买(配件)
            buyTogether: () => {
                // 商详页勾选的配件（含主件）
                const selectedGoods = window.GOODS_TOGETHERDATA || [];
                const result = [];
                if (selectedGoods.length) {
                    selectedGoods.forEach((item) => {
                        result.push({
                            sku: item.goodsSn,
                            pam: 1,
                            pc: item.categoryId,
                            k: item.warehouseCode,
                            zt: 0,
                        });
                    });
                }
                data = {
                    skuinfo: result,
                    pm: 'mbt',
                    x: 'BTS',
                    ubcta: {
                        k: GOODSINFO.warehouseCode,
                    },
                };
                if (linkParameters.url_source) {
                    data.ubcta.pc = linkParameters.url_source;
                }
            },

            // 直接购买
            buyNow: () => {
                data = {
                    skuinfo: {
                        sku: GOODSINFO.goodsSn,
                        pam: 1,
                        pc: GOODSINFO.categoryId,
                        k: GOODSINFO.warehouseCode,
                        zt,
                    },
                    pm: 'mb',
                    x: 'BDR',
                    ubcta: {
                        k: GOODSINFO.warehouseCode,
                    },
                    ksku: GOODSINFO.goodsSn,
                };
                if (linkParameters.url_source) {
                    data.ubcta.pc = linkParameters.url_source;
                }
            },

            // 分享
            share: () => {
                data = {
                    skuinfo: {
                        sku: GOODSINFO.goodsSn,
                        pc: GOODSINFO.categoryId,
                        k: GOODSINFO.warehouseCode,
                    },
                    pm: 'mb',
                    x: 'share',
                    ubcta: {
                        channel: '', // 分享类型
                        p: '' // 来自活动页面，要记录活动ID
                    },
                    ksku: GOODSINFO.goodsSn,
                };
                if (typeof shareType !== 'undefined') {
                    data.ubcta.channel = shareType;
                }
            },

            // 顶部评论
            reviewTop: () => {
                data = {
                    x: 'Reviews_top_click',
                };
            },

            // 悬浮评论
            reviewSuspension: () => {
                data = {
                    x: 'Reviews_suspension_click',
                };
            },

            // paypal快捷支付
            paypal() {
                data = {
                    skuinfo: {
                        sku: GOODSINFO.goodsSn,
                        pam: num,
                        pc: GOODSINFO.categoryId,
                        k: GOODSINFO.warehouseCode,
                        zt,
                    },
                    x: 'CWP',
                    ksku: GOODSINFO.goodsSn,
                    ubcta: {
                        k: GOODSINFO.warehouseCode,
                    },
                };
            },
        };
        if (typeof typeCfg[itemType] === 'function') {
            typeCfg[itemType]();
        }
        if (itemType === 'recordOriginCustom') {
            try {
                // 点击商品仓库+属性，保存页面来源
                const $dom = $(dom);
                if (!($dom.hasClass('goodsIntro_warehouseActive') || $dom.hasClass('disabled'))) {
                    const currentOrigin = super.getRecordOrigin();
                    if (Object.keys(currentOrigin).length) {
                        window.sessionStorage.setItem(STORAGE_SOURCE_ORIGIN, JSON.stringify(currentOrigin));
                    }
                    const { bts } = super.getBTS();
                    if (bts) super.saveBTS(bts);
                }
            } catch (e) {
                //
            }
        } else if (itemType === 'goodsViewed') {
            // 历史记录
            let pageS = 'c';
            try {
                pageS = window.TrackData.common.b;
            } catch (e) {
                //
            }
            data.ubcta = {
                name: 'Your Recently Viewed Items',
                type: 'mr',
                mrlc: `${pageS}_mr_${module}`,
                sku: dom.dataset.trackKey.split('_')[0],
                rank: Number(dom.dataset.index) + 1
            };
            super.setOriginStorage(data.ubcta);
        }
        return { ...data };
    }
}

const goodsTrack = new GoodsTrack({ config: GOODS_CONFIG, page: 'goods' });

export default () => {
    goodsTrack.run();
};
