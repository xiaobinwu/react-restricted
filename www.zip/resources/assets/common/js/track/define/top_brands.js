import Track from 'js/track/track';

const BRANDS = {
    common: {
        '.js-trackGoodsItem': {
            explore: 'self',
            pageModule: 'mp',
            exploreRoot: 'root',
        },

        '.cateMainWarp_exploreThumb': {
            click: 'self',
            pageModule: 'mp',
        },

        '.cateMainWarp_exploreTitle': {
            click: 'self',
            pageModule: 'mp',
        },

        '.js-exploreCollection': {
            click: 'self',
            pageModule: 'mb',
        },

        '.gbGoodsItem_cart': {
            click: 'self',
            pageModule: 'mb',
        },
    },
};

export default class BrandsTrack extends Track {
    constructor({
        type = 'common', // 子页面名称
        page = false, // 是否曝光页面
        extendData = {} // 公共数据
    }) {
        super({
            config: BRANDS[type],
            page,
            extendData
        });
    }

    customClickTrackCallback(data) {
        const {
            // dom,
            classKey,
            // configData,
            // module,
            targetData
        } = data;

        if (classKey === '.gbGoodsItem_cart') {
            // 加入购物车
            return {
                x: 'ADT',
                ksku: targetData.sku,
                ubcta: { fmd: 'mp' }
            };
        } else if (classKey === '.gbGoodsItem_like') {
            // 加入收藏夹
            return {
                x: 'ADF',
                ubcta: { fmd: 'mp' }
            };
        }
        return {};
    }
}
