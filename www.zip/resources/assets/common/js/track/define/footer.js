import Track from 'js/track/track';

class FooterTrack extends Track {
    customClickTrackCallback({
        dom,
        classKey,
        configData,
        module,
        targetData
    }) {
        const { itemType } = configData;
        const data = {};

        if (itemType === 'recomSearch') {
            data.sckw = dom.textContent;
            data.sl = $(dom).index(classKey);
        }

        return data;
    }
}

const FOOTER = {
    // 底部热搜词
    '.js-trackItemHotKey': {
        itemType: 'recomSearch',
        click: 'self',
        crossPage: 'search',
        recordOrigin: 2,
        customData: {
            sk: 'T',
            x: 'search',
        },
    }
};

const footerTrack = new FooterTrack({
    config: FOOTER,
    context: '.js-siteFooterWrap'
});

export default () => {
    footerTrack.run();
};
