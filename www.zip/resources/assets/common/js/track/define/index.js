/**
 * 首页埋点（品牌升级后）
 * 2019-01-23 11:09:37
 */
import Track from 'js/track/track';

const INDEX = {
    // 大banner
    '.indexBanner-item': {
        module: 'A_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'bannerB',
        exploreRoot: '.js-slickIndexBanner',
        exploreFirstShow: 1,
        customUbcta({ module, target }) {
            return {
                mdlc: `a_md_${module}`,
                name: 'Top_Banner_B',
                type: 'md',
                rank: +$(target).attr('data-banner-index') + 1
            };
        }
    },

    // 大banner下方4个广告位
    '.indexActs_item': {
        module: 'A_@',
        start: 2,
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'bannerS',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            return {
                mdlc: `a_md_${module}`,
                name: 'Top_Banner_S',
                rank: 1,
                type: 'md',
            };
        }
    },

    // collections推荐项
    '.js-trackBannerCollections': {
        module: 'B_@',
        start: 1,
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        click: 'self',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            const moduleName = $('.indexCollections').find('.indexTitle_label').text();
            return {
                mdlc: `a_md_${module}`,
                name: moduleName || 'COLLECTIONS',
                rank: 1,
                type: 'md',
            };
        }
    },

    // deals主广告位
    '.js-trackDealsMain': {
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            const groupName = $(target).parents('.indexDeals_item').attr('data-name');
            const moduleName = $('.indexDeals').find('.indexTitle_label').text();
            return {
                mdlc: `a_md_${module}`,
                name: moduleName || 'SUPPERDEALS',
                type: 'md',
                rank: 1,
                // deals有多组数据，上报当前所处类型名称
                parm: groupName
            };
        }
    },

    // deals商品列表
    '.js-gItemTrackDeals': {
        module: 'C_1',
        explore: 'self',
        pageModule: 'mr',
        itemType: 'goods',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            const groupName = $(target).parents('.indexDeals_item').attr('data-name');
            const moduleName = $('.indexDeals').find('.indexTitle_label').text();
            return {
                mrlc: `a_mr_${module}`,
                name: moduleName || 'SUPPERDEALS',
                type: 'mr',
                rank: +$(target).attr('data-true-index') + 1,
                parm: groupName
            };
        }
    },


    // 新品首位广告
    '.js-trackBannerNew': {
        module: 'D_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            const truePageIndex = $(target).parents('.indexNew_item').attr('data-true-index');
            const moduleName = $('.indexNew').find('.indexTitle_label').text();
            return {
                mdlc: `a_md_${module}`,
                name: moduleName || 'NEW',
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1,
                // 新品有多组数据，上报当前所处组号(页号)
                parm: +truePageIndex + 1
            };
        }
    },

    // 新品商品列表
    '.js-gItemTrackNew': {
        module: 'D_1',
        explore: 'self',
        pageModule: 'mr',
        itemType: 'goods',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            const truePageIndex = $(target).parents('.indexNew_item').attr('data-true-index');
            const moduleName = $('.indexNew').find('.indexTitle_label').text();
            return {
                mrlc: `a_mr_${module}`,
                name: moduleName || 'NEW',
                type: 'mr',
                rank: +$(target).attr('data-true-index') + 1,
                parm: +truePageIndex + 1
            };
        }
    },

    // 品牌
    '.js-trackItemBrands': {
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            const truePageIndex = $(target).parents('.indexBrands_groupItem').attr('data-true-index');
            const moduleName = $('.indexBrands').find('.indexTitle_label').text();
            return {
                mdlc: `a_md_${module}`,
                name: moduleName || 'BRANDS',
                type: 'md',
                rank: 1,
                // 品牌有多组数据，上报当前所处组号(页号)
                parm: +truePageIndex + 1
            };
        }
    },

    // 分类
    '.js-indexTrackCateItem': {
        module: 'F_@',
        start: 1,
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'banner',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            const moduleName = $(target).parents('.indexCates').find('.indexTitle_label').text();
            return {
                mdlc: `a_md_${module}`,
                name: moduleName || 'CATEGORIES',
                rank: 1,
                type: 'md',
            };
        }
    },

    // 底部推荐位
    '.js-trackRecomItem': {
        module: 'G_1',
        explore: 'self',
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mr',
        async: true,
        targetBTS: true,
        observer: '.js-trackPanelIndexRecom',
        customUbcta({ module, target }) {
            const moduleName = $('#js-panelIndexRecomed').find('.indexTitle_label').text();
            return {
                mrlc: `a_mr_${module}`,
                name: moduleName || 'RECOMMENDEDFORYOU',
                rank: +$(target).attr('data-true-index') + 1,
                type: 'mr',
            };
        }
    },

    // 所有商品推荐位点击处理
    '.gbItem': {
        click: ['.gbItem_img', '.gbItem_title'],
        pageModule: 'mr',
        itemType: 'goods',
        recordBTS: 1,
        targetBTS: true,
        customUbcta({ module, target }) {
            const nameConfig = {
                C_1: $('.indexDeals').find('.indexTitle_label').text() || 'SUPPERDEALS',
                D_1: $('.indexNew').find('.indexTitle_label').text() || 'NEW',
                G_1: $('#js-panelIndexRecomed').find('.indexTitle_label').text() || 'RECOMMENDEDFORYOU'
            };

            const data = {
                mrlc: `a_mr_${module}`,
                name: nameConfig[module],
                type: 'mr',
            };

            // deals
            if (module === 'C_1') {
                data.parm = $(target).parents('.indexDeals_item').attr('data-name');
            }

            // 新品
            if (module === 'D_1') {
                data.parm = +$(target).parents('.indexNew_item').attr('data-true-index') + 1;
            }

            return data;
        }
    },

    // 大背景图 或 hoverBanner
    '.js-trackIndexBg': {
        module: 'A_X',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        exploreRoot: 'root',
        customUbcta({ module }) {
            return {
                mdlc: `a_md_${module}`,
                name: 'Top_Banner_H',
                type: 'md',
            };
        }
    }
};

class IndexTrack extends Track {
    customClickTrackCallback(config) {
        const { keyTarget } = config;
        const { itemType } = config.configData || {};
        const moduleName = $(keyTarget).parent().attr('data-module-name');

        if (itemType === 'goods' && moduleName) {
            const module = $(keyTarget).attr('data-track-module');
            const index = $(keyTarget).attr('data-true-index');
            const sku = $(keyTarget).attr('data-track-key').split('_')[0];

            super.setOriginStorage({
                mrlc: `a_mr_${module}`,
                rank: +index + 1,
                sku,
                name: moduleName,
                type: 'mr'
            });
        }
    }
}

const indexTrack = new IndexTrack({
    config: INDEX,
    page: 'index',
    noReleaseConnection: true, // 因底部推荐有持续加载，无需释放突变监听
});

export default () => {
    indexTrack.run();
};
