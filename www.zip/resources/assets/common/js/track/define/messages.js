import Track from 'js/track/track';

const messageConfig = {
    '.js-messageTrack': {
        click: 'self',
        explore: 'self',
        recordOrigin: 1,
        customData: {
            x: 'MESSAGE',
        }
    },
};

class MSTrack extends Track {
    customClickTrackCallback({ dom, configData }) {
        const data = {
            s: 'e013',
            b: 'e',
        };
        const mesName = dom.dataset.title;
        const mesSource = dom.dataset.source;
        data.ubcta = {
            name: mesName,
            type: mesSource,
        };
        return { ...data, ...configData.customData };
    }
    explorePageData() {
        return {
            s: 'e013',
            b: 'e'
        };
    }
}

const messageTrack = new MSTrack({
    config: messageConfig,
    page: true,
});

export default () => {
    messageTrack.run();
};
