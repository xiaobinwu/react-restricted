import Track from 'js/track/track';

const NewFlashSale = {
    '.js-goodsItemAsync': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.goodsItem_buy'],
        exploreRoot: 'root',
        pageModule: 'mp',
        async: true, // 异步加载的数据的设置
        observer: '.js-goodsListAsync',
    },
    '.js-goodsItem': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.goodsItem_buy'],
        exploreRoot: 'root',
        pageModule: 'mp'
    },
};

class NewFlashSaleTrack extends Track {
}

const newFlashSaleTrack = new NewFlashSaleTrack({
    config: NewFlashSale,
    page: true,
});
export default () => {
    newFlashSaleTrack.run();
};
