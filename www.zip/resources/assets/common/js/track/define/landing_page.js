import Track from 'js/track/track';

const config = {
    '.subjectGoodItem': {
        explore: 'self',
        click: ['.js-link'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.showProd': {
        explore: 'self',
        click: ['.js-link'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.js-addCart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mb',
        reportOrigin: 1,
    }
};

[...document.querySelectorAll('[data-track-key]')].forEach((item) => {
    const { trackKey, catid } = item.dataset;
    window.TrackData[trackKey] = {
        pc: catid,
        k: trackKey.split('_')[1],
    };
});

class LandingTrack extends Track {
    customClickTrackCallback({
        dom,
        classKey,
        configData,
    }) {
        try {
            const keyTarget = dom.closest('[data-track-key]');
            const [sku, wid] = keyTarget.dataset.trackKey.split('_');
            const catId = keyTarget.dataset.catid;

            if (classKey === '.js-addCart') {
                // 加入购物车
                return {
                    x: 'ADT',
                    ksku: sku,
                    ubcta: { fmd: 'mr_A_1' },
                    skuinfo: {
                        sku,
                        pam: '1',
                        pc: catId,
                        k: wid,
                        zt: '0',
                    }
                };
            } else if (classKey === '.js-link') {
                return {
                    ubcta: { rank: $(keyTarget).hasClass('subjectGoodItem') ? $(keyTarget).index() + 1 : 1 },
                };
            }
            return {};
        } catch (e) {
            return {};
        }
    }
}

const landingTrack = new LandingTrack({
    config,
    page: true,
});

export default () => {
    landingTrack.run();
};
