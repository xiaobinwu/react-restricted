import Track from 'js/track/track';

const USER = {
    common: {
        '.goodsItem_item': {
            explore: 'self',
            pageModule: 'mr',
            exploreRoot: 'root',
            async: true,
            observer: '#youLike'
        },

        '.goodsItem_thumb': {
            click: 'self',
            pageModule: 'mr',
            async: true,
            recordOrigin: 1,
            observer: '#youLike'
        },

        '.goodsItem_title': {
            click: 'self',
            pageModule: 'mr',
            async: true,
            recordOrigin: 1,
            observer: '#youLike'
        },
    },

    // 商品收藏页
    goodsFavor: {
        '.gbGoodsItem-user': {
            explore: 'self',
            pageModule: 'mp',
            exploreRoot: 'root',
            async: true,
            observer: '.goodsList'
        },

        '.gbGoodsItem_thumb': {
            click: 'self',
            pageModule: 'mp',
            async: true,
            recordOrigin: 1,
            observer: '.goodsList'
        },

        '.gbGoodsItem_title': {
            click: 'self',
            pageModule: 'mp',
            async: true,
            recordOrigin: 1,
            observer: '.goodsList'
        },

        '.gbGoodsItem_cart-favor': {
            click: 'self',
            pageModule: 'mb',
            async: true,
            reportOrigin: 1,
            observer: '.goodsList',
        },
    },

    // 我的订单
    order: {
        '.btn-continueToPay': {
            click: 'self',
            async: true,
            observer: '.orderList_list',
        },
        '.orderItem_baseInfo': {
            click: ['.orderItem_title', '.orderItem_thumb'],
            itemType: 'orderLink'
        }
    },

    // 会员中心
    center: {
        '.vip_acList': {
            module: 'A_@',
            start: 1,
            click: 'self',
            explore: 'self',
            pageModule: 'md',
            async: true,
            recordOrigin: 1,
            exploreRoot: 'root',
            observer: '.vipList',
        },
    },

    rule: {
        '.ruleList_inBtnText': {
            click: 'self',
            recordOrigin: 1,
        }
    }

};

export default class UserTrack extends Track {
    constructor({
        type = 'goodsFavor', // 子页面名称
        page = false, // 是否曝光页面
        extendData = {} // 公共数据
    }) {
        super({
            config: USER[type],
            page,
            extendData
        });
    }

    customClickTrackCallback(data) {
        const {
            dom,
            classKey,
            configData,
            // module,
            targetData
        } = data;
        const { itemType } = configData;
        if (classKey === '.gbGoodsItem_cart-favor') {
            // 加入购物车
            return {
                x: 'ADT',
                ksku: targetData.sku,
                ubcta: { fmd: 'mp' }
            };
        } else if (classKey === '.btn-continueToPay') {
            return {
                x: 'CTP',
                skuinfo: (window.trackDataForOrder || {})[dom.dataset.track],
            };
        } else if (classKey === '.vip_acList') {
            const key = dom.dataset.index;
            return {
                x: `A_${key}`,
                ubcta: {
                    mdlc: `A_${key}`,
                    mdID: dom.dataset.trackKey,
                },
            };
        } else if (classKey === '.ruleList_inBtnText') {
            return {
                x: 'RULE_CLICK',
                ubcta: { name: 'shopping' }
            };
        } else if (itemType === 'orderLink') {
            const $orderItem = $(dom).closest('.orderItem_baseInfo');
            return {
                ubcta: {
                    type: 'mp',
                    sku: $orderItem.data('goodssn'),
                    tab: $('.navigate').find('.case.on').html()
                }
            };
        }
        return {};
    }
}
