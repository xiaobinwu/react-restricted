import Track from 'js/track/track';

const RULES = {
    '.operation_favor': { // 单个收藏
        click: 'self',
        pageModule: 'mr',
        itemType: 'favor',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },
    '.batch_favor': { // 批量收藏
        click: 'self',
        pageModule: 'mr',
        itemType: 'batchFavor',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },
    /*
    '.cart_img': { // 点击商品图片
        module: 'custom',
        type: ['click'],
        pageModule: 'mr',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    },
    '.cart_link': { // 点击商品标题
        module: 'custom',
        type: ['click'],
        pageModule: 'mr',
        itemType: 'goodslink',
        customData: {
            x: 'sku',
        },
    }, */
    '.cart_payBtn': { // 快捷支付
        click: 'self',
        pageModule: 'mr',
        itemType: 'checkout',
        customData: {
            x: 'CWP',
        },
    },
    '.proceed_checkout': { // 点击下单
        click: 'self',
        pageModule: 'mr',
        itemType: 'checkout',
        customData: {
            x: 'checkout',
        },
    },
    '.gbGoodsItem_grItem': { // 底部推荐位曝光
        module: 'A_1',
        click: 'self',
        explore: 'self',
        recordOrigin: 1,
        itemType: 'goodsRecom',
        exploreRoot: '.goodsRecommend_slickCon',
        pageModule: 'mr',
        async: true, // 异步加载的数据的设置
        observer: '.goodsRecommend_slickItem',
        exploreFirstShow: 6,
    },
    '.cart_item_list': {
        click: ['.cart_img', '.cart_link'],
        itemType: 'cartItem',
    }
};

class Paycart extends Track {
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        const data = {};
        // 批量收藏
        if (itemType === 'batchFavor' || itemType === 'checkout') {
            const skuinfo = [];
            const trackData = window.TrackData.TrackDataList;
            for (const datakey in trackData) {
                const item = trackData[datakey];
                if (item.isSelected) {
                    const skudata = {
                        sku: item.sku,
                        pc: item.pc,
                        k: item.k,
                    };
                    // 点击 生成订单按钮
                    if (itemType === 'checkout') {
                        skudata.pam = item.pam;
                    }
                    skuinfo.push(skudata);
                }
            }

            data.skuinfo = skuinfo;
        } else if (itemType === 'favor') {
            // 单个收藏
            const dataset = dom.dataset.customtrack.split('_');
            data.skuinfo = [{
                sku: dataset[0],
                pc: dataset[1],
                k: dataset[2],
            }];
        } else if (itemType === 'goodslink') {
            // 点击商品图片或者标题
            const dataset = dom.closest('.cart_item_list').dataset.customtrack.split('_');
            data.skuinfo = [{
                sku: dataset[0],
                pc: dataset[1],
                k: dataset[2],
                pam: dataset[3],
            }];
        } else if (itemType === 'goodsRecom') {
            const { dataset } = dom;
            data.ubcta = [];
            data.ubcta.push({
                mrlc: RULES['.gbGoodsItem_grItem'].module,
                sku: dataset.trackKey.split('_')[0],
                rank: dataset.index,
            });
        } else if (itemType === 'cartItem') {
            data.x = $(dom).closest('.cart_item_list').data('goodssn');
        }

        return { ...data, ...configData.customData };
    }
    // 页面曝光数据：
    explorePageData() {
        const trackData = window.TrackData.TrackDataList;
        const data = {};
        data.skuinfo = [];
        for (const item in trackData) {
            const itemData = trackData[item];
            data.skuinfo.push({
                sku: itemData.sku,
                pam: itemData.pam,
                pc: itemData.pc,
                k: itemData.k,
            });
        }
        return data;
    }
}

class CheckoutTrack extends Track {
    // 页面曝光数据：
    explorePageData() {
        const data = {
            glb_bts: window.TrackData.btsPlan || ''
        };
        return data;
    }
}

export {
    Paycart,
    RULES,

    CheckoutTrack
};
