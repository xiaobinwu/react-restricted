import Track from 'js/track/track';

const CLEARANCE_CONFIG = {
    // 点击商品位曝光
    '.js-trackGoodsItem': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'trackPlain',
        recordOrigin: 1,
        customData: {
            x: 'sku',
        },
    },

    // 商品位曝光
    '.trackGoodsItem': {
        explore: 'self',
        pageModule: 'mp',
        itemType: 'list',
        exploreRoot: 'root',
    },

    // 加入购物车
    '.js-trackAddCart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        }
    },

    // 加入收藏
    '.js-exploreCollection': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'addToCollect',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },

    // coupon 选择
    '.js-trackCoupon': {
        click: 'self',
        itemType: 'coupon',
        customData: {
            x: 'COUPON_SELECT',
        }
    }

};


const { orderByCode, pageSize, pageNo } = window.userTrackData;

const filter = {
    view: pageSize,
    sort: orderByCode,
    page: pageNo,
};

class ClearanceTrack extends Track {
    // 页面曝光
    explorePageData() {
        return { filter };
    }

    // 同步/异步 商品位曝光
    customExploreTrackCallback() {
        return { filter };
    }

    // 自定义点击
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};
        // 加入购物车|加入收藏
        if (itemType === 'addToCart' || itemType === 'addToCollect') {
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter
            };
        } else if (itemType === 'trackPlain') {
            // 清仓页列表商品位点击曝光
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter
            };
        } else if (itemType === 'coupon') {
            // 筛选coupon下的sku商品的点击曝光
            const name = encodeURIComponent(dom.dataset.name);
            const modelnum = dom.dataset.code;
            data = {
                ubcta: {
                    name,
                    modelnum
                }
            };
        }
        return { ...data, ...configData.customData };
    }
}

const clearanceTrack = new ClearanceTrack({
    config: CLEARANCE_CONFIG,
    page: 'clearances',
});

export default () => {
    clearanceTrack.run();
};
