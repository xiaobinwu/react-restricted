import Track from 'js/track/track';

const FlashSale = {

    '.flashSale_a_item': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.flashSale_a_item_link': {
        click: 'self',
        pageModule: 'mp',
    },
    '.flashSale_a_buy_link': {
        click: 'self',
        pageModule: 'mp',
    },

    '.flashSale_b_item': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.flashSale_b_item_link': {
        click: 'self',
        pageModule: 'mp',
    },
    '.flashSale_b_buy_link': {
        click: 'self',
        pageModule: 'mp',
    },

    '.flashSale_c_item': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.flashSale_c_item_link': {
        click: 'self',
        pageModule: 'mp',
    },
    '.flashSale_c_buy_link': {
        click: 'self',
        pageModule: 'mp',
    },

    '.flashSale_d_item': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.flashSale_d_item_link': {
        click: 'self',
        pageModule: 'mp',
    },
    '.flashSale_d_buy_link': {
        click: 'self',
        pageModule: 'mp',
    },

    '.flashSale_e_item': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.flashSale_e_item_link': {
        click: 'self',
        pageModule: 'mp',
    }
};

class FlashSaleTrack extends Track {
}

const flashSaleTrack = new FlashSaleTrack({
    config: FlashSale,
    page: true,
});
export default () => {
    flashSaleTrack.run();
};
