import Track from 'js/track/track';

const SEO = {
    // sku曝光和点击
    '.seoSkuContainer': {
        click: ['.seoSkuContainer_img', '.seoSkuContainer_a'],
        explore: 'self',
        pageModule: 'mr',
        exploreRoot: 'root',
        itemType: 'seoSkuCustom',
    },
    // 推荐词点击
    '.seoRecommendWord': {
        click: 'self',
        itemType: 'seoRecommend',
    },
    // 视频点击
    '.seoVideo': {
        click: 'self',
        itemType: 'seoVideo',
    },
    // 图片点击
    '.js-imgItemReviews': {
        click: 'self',
        itemType: 'seoImg',
    },
    // view more点击
    '.seoProViewMore': {
        click: 'self',
        itemType: 'seoViewMore',
    }
};

const keyWord = $('.seoKeyword').text();

class SeoTrack extends Track {
    customExploreTrackCallback({
        target,
        configData
    }) {
        const trackData = window.TrackData || { common: {} };
        const { itemType } = configData;
        const $target = $(target);
        const ubcta = [];
        $.each($target, (i, item) => {
            const $item = $(item);
            const dataset = $item.data();
            const $buryingGoods = $item.closest('.js-buryingGoods');
            const pit = $buryingGoods.data('pit');
            const title = $buryingGoods.find('.seoTitle').text();
            ubcta.push({
                tt: keyWord,
                name: title,
                type: 'mr',
                mrlc: `${trackData.common.s}_mr_${pit}`,
                sku: dataset.sku,
                rank: dataset.rank
            });
        });
        if (itemType === 'seoSkuCustom') {
            return {
                ubcta
            };
        }
        return {};
    }
    customClickTrackCallback({ dom, configData }) {
        const trackData = window.TrackData || {};
        const { itemType } = configData;
        const $dom = $(dom);
        // sku
        if (itemType === 'seoSkuCustom') {
            const $seoSkuContainer = $dom.closest('.seoSkuContainer');
            const dataset = $seoSkuContainer.data();
            const $buryingGoods = $dom.closest('.js-buryingGoods');
            const pit = $buryingGoods.data('pit');
            const title = $buryingGoods.find('.seoTitle').text();
            const ubcta = {
                tt: keyWord,
                name: title,
                type: 'mr',
                mrlc: `${trackData.common.s}_mr_${pit}`,
                sku: dataset.sku,
                rank: dataset.rank
            };
            // 组合购买、PP支付、加购点击、立即购买
            super.setOriginStorage(ubcta);
            return {
                x: 'sku',
                skuinfo: {
                    sku: dataset.sku,
                    pam: 0,
                    pc: '12215',
                    k: '1433363'
                },
                ubcta
            };
        }
        // 推荐词
        if (itemType === 'seoRecommend') {
            return {
                x: 'Search_RecommendWrod',
                ubcta: {
                    tt: keyWord,
                    title: $dom.text()
                }
            };
        }
        // 视频
        if (itemType === 'seoVideo') {
            const $buryingGoods = $dom.closest('.js-buryingGoods');
            const title = $buryingGoods.find('.seoTitle').text();
            return {
                x: 'Search_VideoClick',
                ubcta: {
                    tt: keyWord,
                    rank: $dom.data('rank'),
                    title,
                    videourl: $dom.data('video')
                }
            };
        }
        // 图片
        if (itemType === 'seoImg') {
            const $buryingGoods = $dom.closest('.js-buryingGoods');
            const title = $buryingGoods.find('.seoTitle').text();
            return {
                x: 'Search_ImageClick',
                ubcta: {
                    tt: keyWord,
                    rank: $dom.data('rank'),
                    title
                }
            };
        }
        // view more
        if (itemType === 'seoViewMore') {
            return {
                x: 'Search_Viewmore',
                ubcta: {
                    tt: keyWord
                }
            };
        }
        return {};
    }
}

const seoTrack = new SeoTrack({
    config: SEO,
    page: 'seo',
});
export default () => {
    seoTrack.run();
};
