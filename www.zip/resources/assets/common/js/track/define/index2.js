/**
 * st首页埋点
 * 2019-01-23 11:09:37
 */
import Track from 'js/track/track';

const INDEX2 = {
    // 大banner
    '.indexBanner-item': {
        module: 'A_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        itemType: 'bannerB',
        exploreRoot: '.js-slickIndexBanner',
        exploreFirstShow: 1,
        observer: '.js-slickIndexBanner',
        async: false,
        customUbcta({ module, target }) {
            return {
                mdlc: `a_md_${module}`,
                name: 'Top_Banner_B',
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1
            };
        }
    },
    '.js-styleTwoBanner': {
        module: 'C_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            return {
                mdlc: `a_md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1
            };
        }
    },
    '.js-styleThreeBanner': {
        module: 'B_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            return {
                mdlc: `a_md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1
            };
        }
    },
    '.js-styleOnePlusTwoBanner': {
        module: 'D_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            return {
                mdlc: `a_md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1
            };
        }
    },
    '.js-styleOnePlusThreeBanner': {
        module: 'E_1',
        click: 'self',
        explore: 'self',
        pageModule: 'md',
        exploreRoot: 'root',
        customUbcta({ module, target }) {
            return {
                mdlc: `a_md_${module}`,
                type: 'md',
                rank: +$(target).attr('data-true-index') + 1
            };
        }
    }
};

class IndexTrack2 extends Track {
    customClickTrackCallback(config) {
    }
}

const indexTrack2 = new IndexTrack2({
    config: INDEX2,
    page: 'index2',
});

export default () => {
    indexTrack2.run();
};
