import Track from 'js/track/track';

const Googlesubject = {
    '.subjectGoodItem_app_exclusive': {
        explore: 'self',
        click: ['.goodInfoLink', '.buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.subjectGoodItem_increase_purchase': {
        explore: 'self',
        click: ['.goodInfoLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp',
    },
    '.tyingItem': {
        explore: 'self',
        click: ['.tyingGoodLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp',
    },
    '.multipleTimeItem': {
        explore: 'self',
        click: ['.js-imgLink', 'js-titleLink', '.buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp',
    },
    '.multipleGoodItem': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp',
    },
    '.normalGoodItem': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.promotionGoodItem': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.rushPurchaseGoodItem': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.subjectGoodItem_single_product': {
        explore: 'self',
        click: ['.goodInfoLink', '.goodOperate_buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.subjectGoodItem_double': {
        explore: 'self',
        click: ['.goodInfoLink', '.goodOperate_buyLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
    '.tyingMianItem': {
        explore: 'self',
        click: ['.tyingGoodLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp',
        recordOrigin: 1
    },
    '.track-goodsItem': {
        explore: 'self',
        click: ['.track-goodsLink', '.toCart'],
        itemType: 'goods',
        exploreRoot: 'root',
        pageModule: 'mp'
    },
};

class GoogleSubjectTrack extends Track {
    explorePageData() {
        return {
            pageModule: $('.js-siteLayout').data('id')
        };
    }
}

const googleSubjectTrack = new GoogleSubjectTrack({
    config: Googlesubject,
    page: true,
});
export default () => {
    googleSubjectTrack.run();
};
