import Track from 'js/track/track';

const ZONEDEALS_CONFIG = {
    // 点击商品位曝光
    '.gbGoodsItem-deals': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'trackPlain',
        recordOrigin: 1,
        customData: {
            x: 'sku',
        },
    },

    // 商品位曝光
    '.gbGoodsItem': {
        explore: 'sefl',
        pageModule: 'mp',
        itemType: 'list',
        click: ['.gbGoodsItem_thumb'],
        async: true,
        exploreRoot: 'root',
        recordOrigin: 1,
        observer: '.js-cateDealsList',
    },

    // 加入购物车
    '.gbGoodsItem_cart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        },
    },

    // 加入收藏
    '.gbGoodsItem_like': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'addToCollect',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },
};

function getFilterParams() {
    const trackO = $('.js-cateOrderBy').val();
    const trackW = $('p[data-nextpage]').data('nextpage');

    return {
        view: '30',
        sort: trackO,
        page: trackW - 1,
    };
}

class ZoneDealsTrack extends Track {
    // 每日折扣整页曝光
    explorePageData() {
        const dataCate = [];
        const itemTracX = $('.gbGoodsItem');
        const trackW = $('p[data-nextpage]').data('nextpage');
        if (itemTracX && itemTracX.length > 0) {
            itemTracX.each((index, item) => {
                const tahtSef = $(item);
                dataCate.push(tahtSef.data('cat-id'));
            });
        }
        const minApply = Math.min.apply(null, dataCate);
        const p = `${minApply}-${trackW}`;

        const filter = getFilterParams();
        return { p, filter };
    }

    // 同步/异步 商品位曝光
    customExploreTrackCallback() {
        const filter = getFilterParams();
        return { filter };
    }

    // 点击
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};

        const trackI = dom.dataset.index;
        const trackP = (dom.dataset.trackcode || '').split('_');
        const filter = getFilterParams();

        // 加入购物车|加入收藏
        if (itemType === 'addToCart' || itemType === 'addToCollect') {
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter
            };
        } else if (itemType === 'trackPlain') {
            // 每日折扣列表商品位点击曝光
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter
            };
        } else if (itemType === 'list') {
            data = { filter };
        }

        return { ...data, ...configData.customData };
    }
}

const zoneDealsTrack = new ZoneDealsTrack({
    config: ZONEDEALS_CONFIG,
    noReleaseConnection: true,
    page: true,
});

export default () => {
    zoneDealsTrack.run();
};
