import Track from 'js/track/track';

const DEALS_CONFIG = {
    // 点击商品位曝光
    '.gbGoodsItem-deals': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'trackPlain',
        recordOrigin: 1,
        customData: {
            x: 'sku',
        },
    },

    // 商品位曝光
    '.js-gbGoodsItem': {
        explore: 'self',
        pageModule: 'mp',
        itemType: 'list',
        exploreRoot: 'root',
    },

    // 加入购物车
    '.gbGoodsItem_cart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        },
    },
};

const { orderByCode, pageSize, pageNo } = window.userTrackData;
const filter = {
    view: pageSize,
    sort: orderByCode,
    page: pageNo,
};

class DealsTrack extends Track {
    // 页面曝光
    explorePageData() {
        return { filter };
    }

    // 同步/异步 商品位曝光
    customExploreTrackCallback() {
        return { filter };
    }

    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};
        // 加入购物车
        if (itemType === 'addToCart') {
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter
            };
        } else if (itemType === 'trackPlain') {
            // Deals列表商品位点击曝光
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter
            };
        }

        return { ...data, ...configData.customData };
    }
}

const dealsTrack = new DealsTrack({
    config: DEALS_CONFIG,
    page: true,
});

export default () => {
    dealsTrack.run();
};
