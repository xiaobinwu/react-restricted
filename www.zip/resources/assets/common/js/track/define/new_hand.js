import Track from 'js/track/track';

class NewHandTrack extends Track {
}

const newHandTrack = new NewHandTrack({
    page: true,
});
export default () => {
    newHandTrack.run();
};
