import Track from 'js/track/track';

const EXPLORE_CONFIG = {
    // 点击商品位曝光
    '.js-trackGoodsItem': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'trackPlain',
        customData: {
            x: 'sku',
        },
    },

    // 商品位曝光
    '.trackGoodsItem': {
        explore: 'sefl',
        pageModule: 'mp',
        itemType: 'list',
        click: ['.cateMainWarp_exploreThumb'],
        async: true,
        exploreRoot: 'root',
        observer: '.js-exploreBox',
    },

    // 加入购物车
    '.js-exploreAddCart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        },
    },

    // 加入收藏
    '.js-exploreCollection': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'addToCollect',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },
};

class ExploreTrack extends Track {
    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};
        // 加入购物车|加入收藏
        if (itemType === 'addToCart' || itemType === 'addToCollect') {
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackO = $('input[name=track-url]').val();
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter: {
                    view: '36',
                    sort: trackO,
                    page: '1',
                },
            };
        } else if (itemType === 'trackPlain') {
            // Explore列表商品位点击曝光
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackO = $('input[name=track-url]').val();
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter: {
                    view: '36',
                    sort: trackO,
                    page: '1',
                },
            };
        }

        return { ...data, ...configData.customData };
    }
}

const exploreTrack = new ExploreTrack({
    config: EXPLORE_CONFIG,
    page: true,
});

export default () => {
    exploreTrack.run();
};
