import Track from 'js/track/track';

const NewFlashSaleCategory = {
    '.js-goodsItemAsync': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.goodsItem_buy'],
        exploreRoot: 'root',
        pageModule: 'mp',
        async: true, // 异步加载的数据的设置
        observer: '.js-goodsList',
    },
    '.js-goodsItemSync': {
        explore: 'self',
        click: ['.js-imgLink', '.js-titleLink', '.goodsItem_buy'],
        exploreRoot: 'root',
        pageModule: 'mp'
    },
};

class NewFlashSaleCategoryTrack extends Track {
}

const newFlashSaleCategoryTrack = new NewFlashSaleCategoryTrack({
    config: NewFlashSaleCategory,
    page: true,
});
export default () => {
    newFlashSaleCategoryTrack.run();
};
