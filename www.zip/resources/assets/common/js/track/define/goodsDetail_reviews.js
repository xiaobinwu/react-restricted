import Track from 'js/track/track';

const config = {
    // 初次进入评论时
    '.goodsReviews_basicInfo': {
        itemType: 'reviews',
        exploreRoot: 'root',
        explore: 'self',
    },
    // 点击评论翻页时
    '.js-trackReviewsItem': {
        itemType: 'reviews',
        exploreRoot: '.js-trackReviewsPage',
        explore: 'self',
        async: true,
        observer: '.js-trackReviewsWrap',
    },
};

class ReviewsTrack extends Track {
    customExploreTrackCallback({ target, configData }) {
        const { itemType } = configData || {};
        if (itemType === 'reviews') {
            const trackPage = $('#js-reviewPaging').find('.actived').data('goto') || '1';
            return {
                ubcta: {
                    type: 'review',
                },
                filter: {
                    page: trackPage.toString(),
                }
            };
        }
        return {};
    }
}

const reviewsTrack = new ReviewsTrack({
    config,
    context: 'goodsReviews',
});
setTimeout(() => {
    reviewsTrack.mutationSize += 1;
}, 0);
$('body').click(() => {
    reviewsTrack.mutationSize += 1;
});

export default () => {
    reviewsTrack.run();
};
