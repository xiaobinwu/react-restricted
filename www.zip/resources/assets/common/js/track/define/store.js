import Track from 'js/track/track';

const {
    storeId, pageNo, orderByCode, pageSize
} = window.userTrackData;
const storeConfig = {
    '.js-trackSearchGoodsItem': {
        click: ['.gbGoodsItem_title', '.gbGoodsItem_thumb'],
        explore: 'self',
        exploreRoot: 'root',
        pageModule: 'mp',
        itemType: 'goodsItem',
        recordOrigin: 1
    },
    '.js-gbGoodsItemAsync': {
        click: ['.gbGoodsItem_title', '.gbGoodsItem_thumb'],
        explore: 'self',
        exploreRoot: 'root',
        pageModule: 'mp',
        itemType: 'goodsItem',
        async: true, // 异步加载的数据的设置
        observer: '.js-storeMaxBox',
        recordOrigin: 1
    },
};

class StoreTrack extends Track {
    // 店铺整页曝光
    explorePageData() {
        const data = {
            si: storeId,
            filter: {
                view: pageSize,
                sort: orderByCode,
                page: pageNo
            }
        };
        return data;
    }
    customExploreTrackCallback({
        target,
        configData
    }) {
        const { itemType } = configData;
        const {
            trackKey
        } = target.dataset;
        let obj = {};
        if (itemType === 'goodsItem') {
            let pageIndex = 0;
            if ($(target).closest('.js-storelistBox').length) {
                const index = $(target).index('.js-storelistBox .gbGoodsItem');
                pageIndex = parseInt(index / pageSize, 10) + 1;
                obj = {
                    ubcta: {
                        sku: trackKey.split('_')[0],
                        rank: index + 1
                    },
                    filter: {
                        view: pageSize,
                        sort: orderByCode,
                        page: pageIndex
                    }
                };
            }
            if ($(target).closest('.js-storeMaxBox').length) {
                const index = $(target).index('.js-storeMaxBox .gbGoodsItem');
                pageIndex = parseInt(index / pageSize, 10) + 1;
                obj = {
                    ubcta: {
                        sku: trackKey.split('_')[0],
                        rank: index + 1
                    },
                    filter: {
                        view: pageSize,
                        sort: orderByCode,
                        page: pageIndex
                    }
                };
            }
        }
        return obj;
    }

    customUserOriginData({ data, tmpSearchOriginData, keyTarget }) {
        const { rank, store } = data.ubcta;
        return {
            rank,
            store
        };
    }
    customClickTrackCallback({ dom, configData, module }) {
        const { itemType } = configData;
        let index = 0;
        let pageIndex = 1;
        if (itemType === 'goodsItem') {
            const $dom = $(dom);
            if ($dom.closest('.js-storelistBox').length) {
                index = $dom.closest('.gbGoodsItem').index('.js-storelistBox .gbGoodsItem');
            }
            if ($dom.closest('.js-storeMaxBox').length) {
                index = $dom.closest('.gbGoodsItem').index('.js-storeMaxBox .gbGoodsItem');
                pageIndex = parseInt(index / pageSize, 10) + 1;
            }
            return {
                ubcta: {
                    store: storeId,
                    rank: index + 1
                },
                filter: {
                    view: pageSize,
                    sort: orderByCode,
                    page: pageIndex
                }
            };
        }
        return {};
    }
}

const storeTrack = new StoreTrack({
    config: storeConfig,
    page: true,
});
export default () => {
    storeTrack.run();
};
