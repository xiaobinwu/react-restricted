import Track from 'js/track/track';

const SEARCH_RESUTS_CONFIG = {

    // 分类|普通列表页点击商品位曝光
    '.js-trackSearchGoodsItem': {
        // click: 'self',
        click: ['.gbGoodsItem_thumbx', '.gbGoodsItem_titlex'],
        pageModule: 'mp',
        itemType: 'trackPlain',
        recordOrigin: 1,
        mergeOrigin: 1,
        customData: {
            x: 'sku',
        },
    },

    // 搜索列表|分类列表商品位曝光
    '.js-gbGoodsItem': {
        explore: 'self',
        pageModule: 'mp',
        itemType: 'list',
        exploreRoot: 'root',
        crossPage: 'search',
    },

    // 普通分类列表页加入购物车
    '.js-trackAddCart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        },
    },

    // 搜索纠错页加入购物车
    '.js-trackSearchAddCart': {
        click: 'self',
        itemType: 'addSearchToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        customData: {
            x: 'ADT',
        },
    },

    // 加入收藏
    '.js-trackCollect': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'addToCollect',
        reportOrigin: 1,
        customData: {
            x: 'ADF',
        },
    },

    // 搜索纠错页加入收藏
    '.js-trackSearchCollect': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'addSearchToCollect',
        customData: {
            x: 'ADF',
        },
    },

    // 视频播放(注：只针对于分类|新品列表页!!!)
    '.js-trackVideoShow': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'videoShow',
        customData: {
            x: 'video',
        },
    },
};

class SearchResultsTrack extends Track {
    // 搜索删词纠错页整页曝光
    explorePageData() {}

    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};
        // 普通分类列表页加入购物车|加入收藏|视频播放
        if (itemType === 'addToCart' || itemType === 'addToCollect' || itemType === 'videoShow') {
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackT = $('input[name=track-keyword-total]').data('track-keyword-total');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter: {
                    view: trackT,
                    sort: '',
                    page: 1,
                },
            };
        } else if (itemType === 'addSearchToCart' || itemType === 'addSearchToCollect') {
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackW = $('input[name=track-word]').data('key-word');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                    sckw: trackW,
                },
                filter: {
                    view: 11,
                    sort: '',
                    page: 1,
                },
            };
        } else if (itemType === 'trackPlain') {
            // 普通分类列表页商品位包含图片或标题点击曝光
            const configDom = $(dom).closest('.js-trackSearchGoodsItem')[0];
            const trackI = configDom.dataset.index;
            const trackP = configDom.dataset.trackcode.split('_');
            // const trackT = $('input[name=track-keyword-total]').data('track-keyword-total');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter: {
                    view: 11,
                    sort: '',
                    page: 1,
                },
            };
        }

        return { ...data, ...configData.customData };
    }
}

const searchResultsTrack = new SearchResultsTrack({
    config: SEARCH_RESUTS_CONFIG,
    page: true,
});

export default () => {
    searchResultsTrack.run();
};
