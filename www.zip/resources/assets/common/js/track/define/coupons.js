import Track from 'js/track/track';

const COUPON_CONFIG = {};


class CouponTrack extends Track {
    explorePageData() {}
}

const couponTrack = new CouponTrack({
    config: COUPON_CONFIG,
    page: true,
});

export default () => {
    couponTrack.run();
};
