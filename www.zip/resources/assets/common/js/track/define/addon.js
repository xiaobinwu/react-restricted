import Track from 'js/track/track';

const Addon = {
    '.gbGoodsItem_gift': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root'
    },
    '.gbGoodsItem_goodlist': {
        explore: 'self',
        pageModule: 'mp',
        exploreRoot: 'root',
        observe: '#addonGoods',
        async: true,
    },
    '.js-gbGoodsGift_thumb_link': {
        click: 'self',
        pageModule: 'mp',
        observe: '#addonGoods',
        async: true,
    },
    '.js-gbGoodsGift_title_link': {
        click: 'self',
        pageModule: 'mp',
        observe: '#addonGoods',
        async: true,
    },
    '.js-gbGoodsList_thumb_link': {
        click: 'self',
        pageModule: 'mp',
        observe: '#addonGoods',
        async: true,
    },
    '.js-gbGoodsList_title_link': {
        click: 'self',
        pageModule: 'mp',
        observe: '#addonGoods',
        async: true,
    }
};

class AddonTrack extends Track {}

const addonTrack = new AddonTrack({
    noReleaseConnection: true,
    config: Addon,
    page: true
});
export default () => {
    addonTrack.run();
};
