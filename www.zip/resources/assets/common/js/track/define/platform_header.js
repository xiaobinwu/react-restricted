/**
 * 大数据坑位(页面模块)对应定义文件, 点击，曝光class定义
 *
 *  配置的示例
 *  'selector' : {
 *      itemType: '', string 类型，通用的有 banner，goods， 其他的值是每个页面自己定义的用于判断执行不同的操作
 *      click: selector | [selector,...] | 'self' 表示需要在那个元素上设置点击事件，或者self本身
 *      explore: 'self' 表示要在那个元素上面曝光
 * ************************************ 针对坑位的特殊处理
 *      当itemType 的值为banner或goods时
 *      module 就有 （大写字母_数字）这种形式的值，大写字母我们表示父级，数字表示子级
 *      例如 A_1,不过这是最终的值。 在配置的时候有4种情况，
 *      情况一: 直接时最终的值 A_1
 *      情况二： @_1   @是一个占位符
 *      情况三： A_@   @是一个占位符
 *      情况四： @_@   @是一个占位符
 *      module: '', string , 坑位标识，只有推荐位、广告位才有
 *
 *      start: 1, number  这是值是针对的是子级是个占位符的情况，值是子级叠加的基值
 *
 *      parent: {  这是属性就是针对父级是占位符的情况
            query: '.indexLayer', 父级的选择器
            start: 'C', 父级开始叠加的基值
        },
 * *********************************
 *      reportOrigin: 1,     上报来源数据（点击加购，加收，直接购买，组合购买按钮）需要配置
 *      recordOrigin: 1,        记录来源页面 （1=> 来源于页面 , 2 => 来源于搜索）
 *      mergeOrigin: 1,         合并来源，比如当前mp需要合并上一次通过搜索来的数据
 *
 *      crossPage: '', string 值为页面类型，用在一些需要跨页面获取数据来曝光的操作，比如搜索
 *      async: true | false， boolean 设置需要埋点的部分是不是异步加载的
 *      observer: '', string 针对于异步加载的内容的最近同步加载的父元素选择器，用来检测dom的变化
 *      customData: {}, object 对于自定义 itemType的类型需要传的自定义数据
 *      pageModule: '' string 埋点位置在页面的 md 广告位，mr 推荐位， mp 推荐位，具体的值，看文档里面的定义
 *      exploreRoot: '' string [root | selector ] 曝光埋点中，基于哪个容器来曝光，root表示基于窗口，是一种默认的曝光模式，  selector 是父元素的选择器，基本是是用在幻灯片的插件中，滑动
 *      成功后的曝光
 *      exploreFirstShow: 1,  这个值主要是针对，exploreRoot 不为 root 的时候。轮播图的时候，默认显示前面几个，前面的几个就是默认的基于root（窗口）的曝光。
 * }
 */

import Track from 'js/track/track';
import $ from 'jquery';

const HEADER = {
    '.siteSearch_hotLink': {
        itemType: 'hotSearch',
        click: 'self',
        crossPage: 'search',
        async: true,
        observer: '.siteSearch_candidate',
        recordOrigin: 2,
        customData: {
            sk: 'T',
            x: 'search',
        },
    },
    '.siteSearch_historyLink': {
        itemType: 'historySearch',
        click: 'self',
        crossPage: 'search',
        async: true,
        observer: '.siteSearch_candidate',
        recordOrigin: 2,
        customData: {
            sk: 'H',
            x: 'search',
        },
    },
    '.siteSearch_suggestLink': {
        itemType: 'suggestSearch',
        click: 'self',
        crossPage: 'search',
        async: true,
        observer: '.siteSearch_candidate',
        recordOrigin: 2,
        customData: {
            sk: 'L',
            x: 'search',
        },
    },
    '.siteSearch_btn': {
        itemType: 'submitSearch',
        type: ['click'],
        click: 'self',
        crossPage: 'search',
        recordOrigin: 2,
        customData: {
            x: 'search',
        },
    },
    '.js-centerEntrance': {
        itemType: 'userLink',
        click: 'self',
        recordOrigin: 1,
        customData: {
            x: 'VIPCENTER_CLICK',
        },
    },
};

const TOPBANNER = {
    '.siteBanner_link': {
        module: 'A_0',
        click: '.siteBanner_img',
        explore: 'self',
        pageModule: 'md',
        exploreRoot: 'root',
    },
};
class HeaderTrack extends Track {
    customCrossPageData() {
        let searchAt = (window.TrackData && window.TrackData.search && window.TrackData.search.at) || 0;
        if (!searchAt) {
            const cateCountElement = document.querySelector('.cateMain_count');
            // if (!cateCountElement) {
            //     cateCountElement = document.querySelector('.cateMain_lineCont');
            // }

            if (cateCountElement) {
                const numMatch = cateCountElement.innerHTML.match(/\d+/g);
                searchAt = numMatch && numMatch[0];
            }

        }
        const ubcta = {
            glb_ubcta: {
                at: searchAt || 0
            }
        };
        return ubcta;
    }
    getFixOriginData(pageType) { // 跨页面数据需要在跳转后再次修正，比如 搜索纠错词数据，跨页面数据和记录加车源使用
        if (pageType === 'search') {
            const sckwVal = $('.js-inputKeyWords').data('key-word');
            if (sckwVal) {
                return {
                    sckw: sckwVal.split(' in')[0] // 直接搜索需要搜索纠正去修复
                };
            }
        }
        return null;
    }
    customClickTrackCallback({
        dom,
        classKey,
        configData,
        module,
        targetData
    }) {
        const { itemType } = configData;
        let data = {};
        const sc = $('.js-cateSearch').data('cate-id') || $('.js-cateSearch').text();
        if (itemType === 'link') {
            data = { ubcta: { dcn: dom.dataset.trackCustom } };
        }
        if (itemType === 'hotSearch') {
            data.sckw = dom.textContent;
            data.sc = sc;
            data.sl = $(dom).index(classKey) + 1;
        }
        if (itemType === 'historySearch') {
            data.sckw = dom.textContent;
            data.sc = sc;
            data.sl = $(dom).index(classKey) + 1;
        }
        if (itemType === 'recomSearch') {
            data.sckw = dom.textContent;
            data.sc = sc;
            data.sl = $(dom).index(classKey);
        }
        if (itemType === 'suggestSearch') {
            data.sckw = dom.textContent;
            data.siws = $('.siteSearch_input').val();
            data.sc = sc;
            data.sl = $(dom).index(classKey) + 1;
        }
        if (itemType === 'submitSearch') {
            data.siws = $('.siteSearch_input').val();
            data.sc = sc;
            data.sckw = data.siws; // 直接搜索需要搜索纠正去修复
        }
        if (itemType === 'userLink') {
            data = { ubcta: { name: 'vipcenter enter' } };
        }
        return data;
    }
}

// document.onkeydown = (e) => {
//     if (e.keyCode === 13 && document.activeElement.className.indexOf('siteSearch_input') !== -1) {
//         document.querySelector('.siteSearch_btn').click();
//     }
// };

const headerTrack = new HeaderTrack({ config: HEADER, context: '.siteHeader' });
const topBannerTrack = new Track({ config: TOPBANNER, context: '.siteBanner' });

export default () => {
    headerTrack.run();
    topBannerTrack.run();
};
