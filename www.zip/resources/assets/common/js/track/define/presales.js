import Track from 'js/track/track';

const PRESALE_CONFIG = {
    // 预售页列表点击商品位曝光
    '.js-trackGoodsItem': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'trackPlain',
        recordOrigin: 1,
        customData: {
            x: 'sku',
        },
    },

    // 预售页列表商品位曝光
    '.js-gbGoodsItem': {
        explore: 'sefl',
        pageModule: 'mp',
        itemType: 'list',
        recordOrigin: 1,
        exploreRoot: 'root',
    },
};

class PresaleTrack extends Track {
    // 预售页曝光
    explorePageData() {
        const dataCat = [];
        const itemModel = $('.js-cateArrivalBox li');
        const trackV = $('input[name=track-infor]').data('track-cat');
        const trackX = $('input[name=track-infor]').data('track-page');
        if (typeof itemModel !== typeof undefined && itemModel !== false) {
            itemModel.each((index, item) => {
                const tahtSef = $(item);
                dataCat.push(tahtSef.data('cat-id'));
            });
        }
        const trackD = dataCat[0];
        const p = `${trackV}` ? `${trackV}-${trackX}` : `${trackD}-${trackX}`;
        return { p };
    }

    customClickTrackCallback({ dom, configData }) {
        const { itemType } = configData;
        let data = {};
        if (itemType === 'trackPlain') {
            // 预售页列表商品位图片或标题点击曝光
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackC = $('input[name=track-infor]').data('track-inofo').split('_');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                },
                filter: {
                    view: trackC[0],
                    page: trackC[1] ? trackC[1] : 1,
                },
            };
        }

        return { ...data, ...configData.customData };
    }
}

const presaleTrack = new PresaleTrack({
    config: PRESALE_CONFIG,
    page: true,
});

export default () => {
    presaleTrack.run();
};
