import Track from 'js/track/track';
import $ from 'jquery';
import { STORAGE_BTS_CATEENTRY, STORAGE_BTS_SEARCHENTRY } from 'js/variables';
import { isCategoryPage, isSearchPage } from 'js/core/searchCateABtest.js';

// bts分流结果
const btsTrackBtsPolicy = $('#js-hdTrackBtsPolicy').val() || '';

// 默认bts数据
let btsDefault = {};
let storageKey = '';

// 分类页 || 分类+搜索页
if (isCategoryPage()) {
    storageKey = STORAGE_BTS_CATEENTRY;
    btsDefault.plancode = 'category';
}

// 搜索页
if (isSearchPage()) {
    storageKey = STORAGE_BTS_SEARCHENTRY;
    btsDefault.plancode = 'keyword';
}

// 从本地存储取出bts信息
let storageBts;
try {
    storageBts = JSON.parse(window.sessionStorage.getItem(storageKey)) || {};
} catch (error) {
    storageBts = {};
}

// 防止本地bts落空了
btsDefault = Object.assign(btsDefault, storageBts);

// 以副本上的policy为准
btsDefault.policy = btsTrackBtsPolicy;

// 当副本上的policy 和 本地存储中bts不等时
// 为防止后台统计数据干扰，剔除 除plancode和policy以外的值
if (btsDefault.policy !== storageBts.policy) {
    delete btsDefault.versionid;
    delete btsDefault.bucketid;
    delete btsDefault.planid;
}


const trackC = $('input[name=track-infor]').data('track-inofo').split('_');

// 分类页非recommend排序不需要上报bts
if (isCategoryPage() && trackC[1] !== 'recommend') {
    btsDefault = false;
}

// 分类页国家站不需要上报bts
if (isCategoryPage() && window.GLOBAL.PIPELINE !== 'GB') {
    btsDefault = false;
}

// 如果policy为空
if (btsDefault.policy === '') {
    btsDefault = false;
}

let pageS = 'b01';
try {
    pageS = window.TrackData.common.s;
} catch (e) {
    //
}

const SEARCHLIST_CONFIG = {
    // 商品分类页焦点图埋点曝光
    '.cateMain_slickItem-track': {
        module: 'A_1',
        click: 'self',
        explore: 'sefl',
        pageModule: 'md',
        itemType: 'list',
        exploreRoot: '.cateMain_trackBanner',
        exploreFirstShow: 1,
    },

    // 商品分类广告位埋点曝光
    '.cateMain_trackItem': {
        module: 'A_@',
        start: 2,
        click: 'self',
        explore: 'sefl',
        pageModule: 'md',
        itemType: 'list',
        exploreRoot: 'root',
    },

    // 搜索页点击商品位曝光
    '.js-trackSearchGoodsItem': {
        // click: 'self',
        click: ['.gbGoodsItem_thumbx', '.gbGoodsItem_titlex'],
        pageModule: 'mp',
        itemType: 'trackSearch',
        recordOrigin: 1,
        reportBTS: 1,
        recordBTS: btsDefault,
        mergeOrigin: 1,
        customData: {}
    },

    // 分类|普通列表页点击商品位曝光
    '.js-trackGoodsItem': {
        click: 'self',
        pageModule: 'mp',
        recordOrigin: 1,
        mergeOrigin: 1,
        itemType: 'trackPlain',
        reportBTS: 1,
        recordBTS: btsDefault,
        customData: {}
    },

    // 搜索列表|分类列表商品位曝光
    '.js-gbGoodsItem': {
        explore: 'self',
        pageModule: 'mp',
        itemType: 'list',
        exploreRoot: 'root',
        crossPage: 'search',
    },

    // 普通分类列表页加入购物车
    '.js-trackAddCart': {
        click: 'self',
        itemType: 'addToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        reportBTS: 1,
        customData: {
            x: 'ADT',
        },
    },

    // 搜索结果页加入购物车(PS：仅限搜索结果页：sckw)
    '.js-trackSearchAddCart': {
        click: 'self',
        itemType: 'addSearchToCart',
        pageModule: 'mp',
        reportOrigin: 1,
        reportBTS: 1,
        customData: {
            x: 'ADT',
        },
    },

    // 加入收藏
    '.js-trackCollect': {
        click: 'self',
        pageModule: 'mp',
        reportOrigin: 1,
        itemType: 'addToCollect',
        reportBTS: 1,
        customData: {
            x: 'ADF',
        },
    },

    // 搜索结果页加入收藏(PS：仅限搜索结果页：sckw)
    '.js-trackSearchCollect': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'addSearchToCollect',
        reportBTS: 1,
        customData: {
            x: 'ADF',
        },
    },

    // 视频播放(注：只针对于分类|新品列表页!!!)
    '.js-trackVideoShow': {
        click: 'self',
        pageModule: 'mp',
        itemType: 'videoShow',
        reportBTS: 1,
        customData: {
            x: 'video',
        },
    },

    // 搜索强制纠错词
    '.js-trackSearchCorrectX': {
        click: 'self',
        recordOrigin: 2,
        itemType: 'searchCorrectX',
        customData: {},
    },

    // 历史记录
    '.goodsViewed_item': {
        click: 'self',
        explore: 'self',
        exploreRoot: 'root',
        module: 'A_2',
        async: true,
        observer: '.js-goodsViewHistory',
        itemType: 'goodsViewed',
    },
    // new arrival
    '.recItemSlick': {
        module: 'A_1',
        click: 'self',
        explore: 'self',
        exploreRoot: '.js-recItemSlick',
        exploreFirstShow: 8,
        async: true,
        observer: '.js-recItemSlick',
        itemType: 'recItemSlickType',
    },
};

class SearchTrack extends Track {
    assignRecordOrigin() {
        const { sk, sckw, sc } = super.getRecordOrigin();
        return { sk, sckw, sc };
    }
    // 列表页整页曝光
    explorePageData() {
        const trackW = $('input[name=track-word]').data('key-word');
        const trackV = $('input[name=track-infor]').data('track-plan');
        const trackT = $.trim($('input[name=track-infor]').data('track-type'));
        const trackY = (trackT === 'search') ? `s-${trackW}` : `${trackV}`;
        const p = `${trackY}`;
        const filter = {
            view: trackC[0],
            sort: trackC[1],
            page: trackC[2],
        };

        const data = {
            p, filter, ...this.assignRecordOrigin()
        };

        // bts有数据时才上报
        if (btsDefault) {
            super.saveBTS(btsDefault);
            super.mergeBTS();

            data.bts = btsDefault;
        }

        return data;
    }

    customExploreTrackCallback({ target, configData }) {
        let data = {};
        const { itemType } = configData;
        let { module } = configData;
        if (itemType === 'goodsViewed') {
            if (!$('.js-recItemSlick').length) module = 'A_1';
            data.ubcta = {
                name: 'Your Recently Viewed Items',
                type: 'mr',
                mrlc: `${pageS}_mr_${module}`,
                sku: target.dataset.trackKey.split('_')[0],
                rank: Number(target.dataset.index) + 1
            };
            data.filter = {
                view: trackC[0],
                sort: trackC[1],
                page: trackC[2],
            };
        } else if (itemType === 'recItemSlickType') {
            data.ubcta = {
                name: 'New Arrival',
                type: 'mr',
                mrlc: `${pageS}_mr_${module}`,
                sku: target.dataset.trackKey.split('_')[0],
                rank: Number(target.dataset.trueIndex) + 1
            };
            data.filter = {
                view: trackC[0],
                sort: trackC[1],
                page: trackC[2],
            };
        } else {
            data = { ...super.getBTS(), ...this.assignRecordOrigin() };
        }
        return data;
    }
    async customExploreTrackBeforeCallback({ target, configData }) {
        const { itemType } = configData;
        const data = {};
        if (itemType === 'list') {
            data.filter = {
                view: trackC[0],
                sort: trackC[1],
                page: trackC[2],
            };
        }
        return data;
    }
    customClickTrackCallback({ dom, configData, module }) {
        const { itemType } = configData;
        let data = {};
        const trackSK = super.getRecordOrigin().sk || '';
        // 普通分类列表页加入购物车|加入收藏|视频播放
        if (itemType === 'addToCart' || itemType === 'addToCollect' || itemType === 'videoShow') {
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    fmd: 'mp',
                    rank: trackI,
                },
                filter: {
                    view: trackC[0],
                    sort: trackC[1],
                    page: trackC[2],
                },
            };
        } else if (itemType === 'addSearchToCart' || itemType === 'addSearchToCollect') {
            // 搜索列表页加购物车|加入收藏
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackW = $('input[name=track-word]').data('key-word');

            data = {
                skuinfo: {
                    sku: trackP[0],
                    pam: 1,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    rank: trackI,
                    sckw: trackW,
                },
                filter: {
                    view: trackC[0],
                    sort: trackC[1],
                    page: trackC[2],
                },
            };
        } else if (itemType === 'trackPlain') {
            // 普通分类列表页商品位包含图片或标题点击曝光
            const trackI = dom.dataset.index;
            const trackP = dom.dataset.trackcode.split('_');
            const trackT = $('.js-siteSearch_input');
            const trackW = $.trim($('.siteSearch_input').val());

            data = {
                x: 'sku',
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                filter: {
                    view: trackC[0],
                    sort: trackC[1],
                    page: trackC[2],
                }
            };

            if (trackT) {
                const ubcta = {
                    x: 'sku',
                    sk: trackSK,
                    rank: trackI
                };
                if (trackW && trackW.length > 0) {
                    ubcta.sckw = trackW || '';
                }
                data.ubcta = ubcta;
            }
            const dataS = {
                x: 'sku',
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                filter: {
                    view: trackC[0],
                    sort: trackC[1],
                    page: trackC[2],
                },
            };
            Object.assign(data, dataS);
        } else if (itemType === 'trackSearch') {
            // 搜索列表商品位包含图片或标题点击曝光
            const configDom = $(dom).closest('.js-trackSearchGoodsItem')[0];
            const trackI = configDom.dataset.index;
            const trackP = configDom.dataset.trackcode.split('_');
            const trackW = $('input[name=track-word]').data('key-word') || $(dom).closest('.js_seachResultList').data('errorCorrectName');

            data = {
                x: 'sku',
                skuinfo: {
                    sku: trackP[0],
                    pam: 0,
                    pc: trackP[1],
                    k: trackP[2],
                },
                ubcta: {
                    sk: trackSK,
                    rank: trackI,
                    sckw: trackW,
                },
                filter: {
                    view: trackC[0],
                    sort: trackC[1],
                    page: trackC[2],
                },
            };
        } else if (itemType === 'searchCorrectX') {
            data = {
                x: 'CORRECT_BEFORE',
            };
        } else if (itemType === 'goodsViewed') {
            if (!$('.js-recItemSlick').length) module = 'A_1';
            data.ubcta = {
                name: 'Your Recently Viewed Items',
                type: 'mr',
                mrlc: `${pageS}_mr_${module}`,
                sku: dom.dataset.trackKey.split('_')[0],
                rank: Number(dom.dataset.index) + 1
            };
            data.filter = {
                view: trackC[0],
                sort: trackC[1],
                page: trackC[2],
            };
            super.setOriginStorage({ sort: data.filter.sort, ...data.ubcta });
        } else if (itemType === 'recItemSlickType') {
            data.ubcta = {
                name: 'New Arrival',
                type: 'mr',
                mrlc: `${pageS}_mr_${module}`,
                sku: dom.dataset.trackKey.split('_')[0],
                rank: Number(dom.dataset.trueIndex) + 1
            };
            data.filter = {
                view: trackC[0],
                sort: trackC[1],
                page: trackC[2],
            };
            super.setOriginStorage({ sort: data.filter.sort, ...data.ubcta });
        }

        return { ...data, ...configData.customData };
    }
}

const searchTrack = new SearchTrack({
    config: SEARCHLIST_CONFIG,
    page: true,
});

export default () => {
    searchTrack.run();
};
