import 'intersection-observer';
import 'mutationobserver-shim';
import PubSub from 'pubsub-js';
import Cookies from 'js/utils/cookie';
import { getUrlQuery, getType } from 'js/utils/index.js';
import { STORAGE_SOURCE_BTS, STORAGE_SOURCE_ORIGIN } from 'common/js/variables';
import { getUserId } from 'js/core/user/getUserId.js';
import sortFilter from './plugins/sortFilter';

// IE11以下性能极差，调整定时器频率
IntersectionObserver.prototype.POLL_INTERVAL = 300;
MutationObserver._period = 600; //eslint-disable-line

function isString(s) {
    return String(s) === s;
}

const COOKIE_UID = 'guid';
const STORAGE_DPF = 'GB_STORAGE_AFF_DPF';
const urlQueryParams = getUrlQuery();

// 简单订阅发布
const Hooks = {
    events: {
        // onSendData: []
    },
    emit(eventName, payload) {
        if (Array.isArray(Hooks.events[eventName])) {
            Hooks.events[eventName].forEach((fn) => {
                fn(payload);
            });
        }
    },
    on(eventName, callFn) {
        Hooks.events[eventName] = Hooks.events[eventName] || [];
        Hooks.events[eventName].push(callFn);
    }
};

window.Hooks = Hooks;

function preSet(target) {
    if (!window.gtla) {
        window.gtla = [];
    }
    // Session ID Data anomaly!!!
    const cookies = Cookies.get();
    const sId = getUserId();
    const uId = cookies[COOKIE_UID];

    let { D_P_f: dpf } = urlQueryParams;
    if (!dpf) {
        dpf = window.localStorage.getItem(STORAGE_DPF);
    } else {
        // 更新 dpf
        window.localStorage.setItem(STORAGE_DPF, dpf);
    }
    target.GTLA = window.gtla;
    target.DATA_TRACK = window.TrackData || {};
    target.DATA_TRACK_COMMON = target.DATA_TRACK.common || {};

    if (sId) {
        // 用户唯一标识
        target.DATA_TRACK_COMMON.oi = sId;
    }

    if (uId) {
        // 登陆id
        target.DATA_TRACK_COMMON.u = uId;
    }

    if (dpf) {
        // aff
        target.DATA_TRACK_COMMON.D_P_f = dpf;
    }
}

function getBTSParamsByDom(dom) {
    if (dom) {
        const {
            versionid,
            bucketid,
            planid,
            plancode,
            policy,
            lableid
        } = dom.dataset;
        if (versionid) {
            return {
                versionid,
                bucketid,
                planid,
                plancode,
                policy,
                lableid
            };
        }
    }
    return {};
}

class EXPLORE_QUEUE_ITEM {
    constructor(target, common) {
        this.ubcta = []; // 常规 ubcta list
        this.bts = []; // 大数据 bts list 要特殊处理
        this.common = common;
        this.target = target;
        this.triggerHandler = null;
    }
    add({
        ubcta,
        bts,
        filter,
        ...otherArgs
    }) {
        if (ubcta && JSON.stringify(this.ubcta).indexOf(JSON.stringify(ubcta)) < 0) this.ubcta.push(ubcta);
        if (bts && JSON.stringify(this.bts).indexOf(JSON.stringify(bts)) < 0) this.bts.push(bts);

        if (this.triggerHandler) {
            clearTimeout(this.triggerHandler);
        }
        this.triggerHandler = setTimeout(() => {

            // mdlc mplc mrlc ，bts要求帮他们拆开数据，因为他们不会做 😊 .....
            const curPm = `${this.common.pm}lc`;
            const tempData = Object.create(null);

            this.ubcta.forEach((itemUbcta) => {
                let curBts;
                if (this.bts.some((itemBts) => {
                    const reBool = (itemUbcta[curPm] === itemBts[curPm]);
                    if (reBool) {
                        curBts = itemBts;
                    }
                    return reBool;
                })) {
                    // 按 pm 拆分bts 对应ubcta 数据
                    const curModule = itemUbcta[curPm]; // A_1 A_2 ....

                    tempData[curModule] = tempData[curModule] || Object.create(null);
                    tempData[curModule].ubcta = (tempData[curModule].ubcta || []).concat(itemUbcta);
                    tempData[curModule].bts = curBts;
                } else {
                    // 没有bts信息 直接合并数据
                    tempData[0] = tempData[0] || Object.create(null);
                    tempData[0].ubcta = (tempData[0].ubcta || []).concat(itemUbcta);
                }
            });

            Object.entries(tempData).forEach(([key, value]) => {
                const tempSend = Object.create(null);

                tempSend.ubcta = value.ubcta;
                if (value.bts && !$.isEmptyObject(value.bts)) {
                    tempSend.bts = value.bts;
                }
                if (filter) {
                    tempSend.filter = filter;
                }
                Object.assign(tempSend, otherArgs);
                this.target.sendData({ type: 'explore', data: { ...this.common, ...tempSend } });
            });
            this.ubcta = [];
            this.bts = [];
        }, this.target.EXPLORE_TIME_THRESHOLD);
    }
}

@preSet
class Track {
    static EXPLORE_RATIO = 0.6
    static EXPLORE_TIME_THRESHOLD = 3000
    static TRACK_CROSS_PAGE = 'TRACK_CROSS_PAGE'
    static TRACK_ORIGIN = 'TRACK_ORIGIN'
    static TRACK_URL_BTS = 'TRACK_URL_BTS'
    static TRACK_URL_SOURCE_ORIGIN = 'TRACK_URL_SOURCE_ORIGIN'
    static TRACK_URL_REFERRER = 'TRACK_URL_REFERRER'
    static OPTIONS = {
        root: null,
        rootMargin: '0px',
        threshold: Track.EXPLORE_RATIO,
    }

    static extendData = {} // 用来存放扩展参数
    static startTime = 0 // 初始时间

    static url = window.location.href


    // slick元素列表获取真正下标
    constructor({
        config = {},
        page = '',
        dataTrueIndex = 'data-true-index', // clone元素列表获取真正下标属性
        context = '#siteWrap',
        noReleaseConnection = false, // 突变完成 是否释放突变监听  默认释放
        extendData = {} // 扩展参数
    }) {
        this.config = config;
        this.dataTrueIndex = dataTrueIndex;
        this.page = page;
        this.OBSERVER = [];
        this.context = context;
        this.noReleaseConnection = noReleaseConnection;
        this.ROOT_OBSERVER = null;
        this.CLICK_CONFIG = {};
        this.EXPLORE_ASYNC = {};
        this.EXPLORE_SYNC = {};
        this.EXPLORE_QUEUE = {};
        this.MUTATION = new MutationObserver(this.mutationCallback.bind(this));
        this.mutationSize = 0;

        Track.extendData = extendData;
        Track.startTime = new Date();
    }

    observerCallback(entries, observer) {
        const self = this;
        if (entries.length) {
            entries.forEach((item) => {
                if (item.intersectionRatio >= observer.thresholds[0]) {
                    self.exploreTrackCallback(item.target);
                    observer.unobserve(item.target);
                }
            });
        } else {
            observer.disconnect();
        }
    }
    customExploreTrackCallback() {
        return {};
    }
    // 曝光前期追加数据，支持异步等待
    async customExploreTrackBeforeCallback() {
        return {};
    }
    async exploreTrackCallback(target) {
        if (target.dataset.trackKey) {
            const key = target.dataset.trackKey.split('_')[0];
            const { configData } = this.findConfigKeyData(target.classList);
            const beforeParams = await this.customExploreTrackBeforeCallback({ target, configData });
            const pm = configData.pageModule;
            const module = target.dataset.trackModule;
            const ubcta = {};
            if (!this.EXPLORE_QUEUE[pm]) {
                this.EXPLORE_QUEUE[pm] = new EXPLORE_QUEUE_ITEM(Track, { pm, ...beforeParams }); //eslint-disable-line
            }
            if (pm === 'md') {
                ubcta.mdlc = target.dataset.trackModule;
                ubcta.mdID = key;
                if (target.dataset.lableid) {
                    ubcta.pdl = target.dataset.lableid;
                }
            }
            if (pm === 'mr') {
                ubcta.mrlc = target.dataset.trackModule;
                ubcta.sku = key;
                if (target.dataset.lableid) {
                    ubcta.pdl = target.dataset.lableid;
                }
            }
            if (pm === 'mp') {
                ubcta.sku = key;
                if (target.dataset.lableid) {
                    ubcta.pdl = target.dataset.lableid;
                }
            }
            if (urlQueryParams.url_source) {
                ubcta.pc = urlQueryParams.url_source;
            }

            // 用户自定义数据
            if (typeof configData.customUbcta === 'function') {
                Object.assign(ubcta, configData.customUbcta({ module, target }));
            }

            // BTS暴露点坑位
            let btsData;
            if (configData.targetBTS) {
                const curBtsData = getBTSParamsByDom(target);
                const lcMap = ['mrlc', 'mdlc', 'mplc'];
                const lcObj = {};
                lcMap.some((lcItem) => {
                    if (ubcta[lcItem]) {
                        lcObj[lcItem] = ubcta[lcItem];
                        return true;
                    }
                    return false;
                });

                // btsData 数据合并
                if (curBtsData.versionid) {
                    btsData = {
                        bts: {
                            ...curBtsData,
                            ...lcObj,
                        }
                    };
                }
            }

            // push
            this.EXPLORE_QUEUE[pm].add({
                ubcta,
                ...(btsData || {}),
                ...this.customExploreTrackCallback({
                    target,
                    configData
                })
            });
        }
    }
    static sendData({ type = 'click', data }) {
        // 扩展公共参数，重置时间
        Object.assign(data, Track.extendData, {
            w: new Date() - Track.startTime || '0'
        });

        const trackData = { trackType: type === 'click' ? 'trackEvent' : 'trackBrowser' };
        const pushData = { ...Track.DATA_TRACK.common, ...trackData, ...data };

        // 上报数据删掉多余字段
        delete pushData.pageType;
        Hooks.emit('onSendData', {
            data: pushData
        });
        Track.GTLA.push(pushData);
    }
    static crossPageSaveData({ data, toPage }) {
        const cross = JSON.parse(window.localStorage.getItem(Track.TRACK_CROSS_PAGE) || '{}');
        cross[toPage] = { ...Track.DATA_TRACK.common, ...data, trackType: 'trackEvent' };
        window.localStorage.setItem(Track.TRACK_CROSS_PAGE, JSON.stringify(cross));
    }

    customCrossPageData() { // 不同页面自行针对各自的跨页面传输埋点传数据
        return {};
    }
    getFixOriginData(pageType) { // 针对类似搜索页面需要搜索纠错的情况
    }
    crossPageSendData() {
        const cross = JSON.parse(window.localStorage.getItem(Track.TRACK_CROSS_PAGE) || '{}');
        const { pageType } = Track.DATA_TRACK_COMMON;
        const crossData = cross[pageType];
        if (crossData) {
            Track.sendData({ data: { ...crossData, ...this.customCrossPageData(crossData) } });
        }
        window.localStorage.removeItem(Track.TRACK_CROSS_PAGE);
    }
    /**
     * 用于把url对应的数据保存到session中
     * @param key 保存在session中的key
     * @param obj 需要保存的对象
     */
    setStorageUrl(key, obj) {
        const urlSource = {
            ...JSON.parse(window.sessionStorage.getItem(key) || '{}'),
            ...{ [Track.url]: obj }
        };
        window.sessionStorage.setItem(key, JSON.stringify(urlSource));
    }
    run() {
        setTimeout(() => {
            if (Object.keys(this.config).length) {
                this.splitDataConfig(); // 将自定义配置以click 和 曝光 两类拆分
                this.parsePageModule(); // 给有module的配置填充 data-track-module
                this.clickTrack(); // 点击曝光处理
                this.exploreTrack();
                this.mutationTrack();
                this.mergeRecordOrigin(); // 保存url和页面来源对应
                this.crossPageSendData();
            }
            this.mergeReferrer(); // 保存url和页面大类、小类对应
            this.explorePage();
        }, 0);
    }
    /**
     * @static
     * @param {any} [{ type = ['page'|'goods'|'banner'] }={}]
     * @memberof Track
     */
    exploreTrack(dataConfig = this.EXPLORE_SYNC) {
        if (!Object.keys(dataConfig).length) return;
        if (!this.ROOT_OBSERVER) {
            this.ROOT_OBSERVER = new IntersectionObserver(this.observerCallback.bind(this), Track.OPTIONS);
        }
        this.OBSERVER.push(this.ROOT_OBSERVER);
        Object.entries(dataConfig).forEach(([key, value]) => {
            if (value.exploreRoot !== 'root') {
                $(value.exploreRoot).each((i, item) => {
                    const observer = new IntersectionObserver(this.observerCallback.bind(this), { ...Track.OPTIONS, root: item, threshold: 0.9 });
                    this.OBSERVER.push(observer);
                    $(item).find(key).each((idx, exploreItem) => {
                        if (idx < value.exploreFirstShow) this.ROOT_OBSERVER.observe(exploreItem);
                        else observer.observe(exploreItem);
                    });
                });
            } else {
                $(key).each((i, item) => {
                    this.ROOT_OBSERVER.observe(item);
                });
            }
        });
    }
    /**
     * 额外的页面曝光数据， ksku/skuinfo:(记录产品编码，ksku适用于商详页；skuinfo适用于购物车页和个人中心-我的收藏页)
     * pagemodule:(适用于专题页)
     * p: （适用于活动页ID） 需要在子类中取覆写
     */

    explorePageData() {
        return {};
    }
    explorePage() { // 页面曝光
        if (this.page) {
            Track.sendData({ data: { ...Track.DATA_TRACK.common, ...this.explorePageData() }, type: 'explore' });
        }
    }
    clickTrack() {
        if (Object.keys(this.CLICK_CONFIG).length) {
            this.bindFunctionScope = this.clickTrackCallback.bind(this);
            try {
                const dom = document.querySelector(this.context);
                dom.addEventListener('click', this.bindFunctionScope);
            } catch (error) {
                // error
            }
        }
    }
    findConfigKeyData(classList) {
        const dataConfig = { ...this.EXPLORE_ASYNC, ...this.EXPLORE_SYNC };
        const keys = Object.keys(dataConfig);
        const classA = Array.from(classList);
        const [classKey] = keys.filter(item => classA.includes(item.substr(1)));
        const configData = dataConfig[classKey];
        return { configData, classKey };
    }

    // 点击上报bts
    getBTS(configData) {
        const urlBTS = JSON.parse(window.sessionStorage.getItem(Track.TRACK_URL_BTS) || '{}');
        return Object.keys(urlBTS).length ? { bts: urlBTS[Track.url] } : {};
    }

    // 保存当前url的bts
    saveBTS(reportBTS, dom) {
        let bts = {};
        if (reportBTS === 1) {
            const dataset = dom.dataset;
            const {
                versionid, bucketid, planid, plancode, policy
            } = dataset;
            bts = {
                versionid,
                bucketid,
                planid,
                plancode,
                policy,
            };
        } else if (getType(reportBTS) === 'Object') {
            bts = reportBTS;
        }
        if (Object.keys(bts).length) window.sessionStorage.setItem(STORAGE_SOURCE_BTS, JSON.stringify(bts));
    }
    // 跳转到另一个页面才能知道url，把url和bts对应并保存
    mergeBTS({
        isDelete = true
    } = {}) {
        const bts = window.sessionStorage.getItem(STORAGE_SOURCE_BTS);
        if (bts) {
            let tempBTS = bts;
            try {
                tempBTS = JSON.parse(tempBTS);
            } catch (error) {
                console.log('track.js:mergeBTS:', error);
            }
            this.setStorageUrl(Track.TRACK_URL_BTS, tempBTS);
            if (isDelete) {
                window.sessionStorage.removeItem(STORAGE_SOURCE_BTS);
            }
        }
    }
    // 保存document.referrer 和对应的页面大小类
    mergeReferrer() {
        if (!this.notFirst && window.TrackData && window.TrackData.common) {
            this.notFirst = true;
            const { b, s } = window.TrackData.common;
            this.setStorageUrl(Track.TRACK_URL_REFERRER, {
                b,
                s
            });
        }

    }
    setOriginStorage(obj) {
        window.sessionStorage.setItem(STORAGE_SOURCE_ORIGIN, JSON.stringify(obj));
    }
    customUserOriginData({ data, tmpSearchOriginData, keyTarget }) {
        return {};
    }
    // 保存当前页面来源
    saveRecordOrigin(recordOrigin, mergeOrigin, data, pm, module, keyTarget) {
        let tmpSearchOriginData = recordOrigin === 2 ?
            {
                fmd: 'mp',
                sk: data.sk || '',
                sc: data.sc || '',
                sckw: data.sckw || '',
            } :
            {
                fmd: pm === 'mp' ? 'mp' : (module ? `${pm}_${module}` : ''),
            };
        if (data.filter && data.filter.sort) tmpSearchOriginData.sort = data.filter.sort; // 针对搜索分类页排序
        if (mergeOrigin) {
            tmpSearchOriginData = { ...this.getRecordOrigin(), ...tmpSearchOriginData };
        }
        this.setOriginStorage({
            ...tmpSearchOriginData,
            ...this.customUserOriginData({
                data,
                tmpSearchOriginData,
                keyTarget
            })
        });
    }
    setStorageSourceOrigin(source) { // 记录页面来源工具类
        this.setStorageUrl(Track.TRACK_URL_SOURCE_ORIGIN, source);
    }
    //  跳转到另一个页面才能知道url，把url和recordOrigin对应并保存
    mergeRecordOrigin() {
        const recordOrigin = window.sessionStorage.getItem(STORAGE_SOURCE_ORIGIN);
        if (recordOrigin) {
            const formatRecordOrigin = JSON.parse(recordOrigin);
            const { pageType } = Track.DATA_TRACK_COMMON;
            const fixsckw = this.getFixOriginData(pageType);
            if (fixsckw && formatRecordOrigin.sckw) { // 纠错词纠正
                Object.assign(formatRecordOrigin, fixsckw);
            }
            this.setStorageSourceOrigin(formatRecordOrigin);
            window.sessionStorage.removeItem(STORAGE_SOURCE_ORIGIN);
        }
    }
    // 获取页面来源
    getRecordOrigin(url = Track.url) {
        const urlSourceOrigin = JSON.parse(window.sessionStorage.getItem(Track.TRACK_URL_SOURCE_ORIGIN) || '{}');
        return urlSourceOrigin[url] || {};
    }

    // 不同页面的自定义点击事件的处理
    customClickTrackCallback() {
        return {};
    }

    clickTrackCallback(e) {
        const target = e.target || e.srcElement;
        const { classKey, dom } = this.searchTarget(target);

        if (classKey) { // 配置的类名key
            const configData = this.CLICK_CONFIG[classKey];
            const pm = configData.pageModule; // md mr mp
            let data = {};
            let targetData = null;
            let module = null; // A_1 A_2

            if (pm) {
                data.pm = pm;
            }
            const keyTarget = dom.closest('[data-track-key]');
            if (keyTarget) {
                const keyWh = keyTarget.dataset.trackKey;
                const key = keyWh.split('_')[0];
                module = keyTarget.dataset.trackModule;

                targetData = Track.DATA_TRACK[keyWh];
                data.x = key;
                if (module) {
                    // mr从slick元素列表获取真正下标，md自定义参数获取下标
                    const $indexDom = $(dom).closest(`[${this.dataTrueIndex}]`);
                    const curDataTrueIndex = $indexDom.attr(this.dataTrueIndex);
                    const configCustomUbcta = (typeof configData.customUbcta === 'function') ? configData.customUbcta : $.noop;
                    let rankIndex;
                    if ($indexDom.length > 0 && typeof curDataTrueIndex !== 'undefined') {
                        rankIndex = +curDataTrueIndex + 1;
                    } else {
                        rankIndex = $(dom).index(classKey) + 1;
                    }
                    if (pm === 'md') {
                        data.ubcta = {
                            mdlc: module,
                            mdID: key,
                            rank: rankIndex,
                            ...configCustomUbcta({ module, target: keyTarget })
                        };
                        data.x = module;
                    } else if (pm === 'mr') {
                        data.ubcta = {
                            mrlc: module,
                            rank: rankIndex,
                            sku: key,
                            ...configCustomUbcta({ module, target: keyTarget })
                        };
                        data.x = 'sku';
                    }
                } else {
                    /* eslint-disable no-lonely-if */
                    if (pm === 'mp') { // 没有设置坑位的商品列表类
                        data.ubcta = { rank: $(dom).index(classKey) + 1 };
                        // 还有个filter 属性  在搜索结果ubcta还有sckw 字段
                    }
                }
                const lableid = keyTarget.dataset.lableid;

                if (lableid) {
                    data.ubcta.pdl = lableid;
                }

                if (urlQueryParams.url_source) {
                    data.ubcta.pc = urlQueryParams.url_source;
                }

                if (keyWh.includes('_') && pm !== 'md') {
                    data.skuinfo = {
                        sku: key,
                        pam: 1,
                        pc: targetData ? targetData.pc : '',
                        k: targetData ? targetData.k : ''
                    };
                }
            } else {
                Object.assign(data, configData.customData);
            }


            const {
                recordOrigin, reportOrigin, mergeOrigin, recordBTS, reportBTS, targetBTS,
            } = configData;

            // targetBTS BTS 上报点，允许后面用户自定义方法覆盖；
            if (targetBTS) {
                const btsData = getBTSParamsByDom(keyTarget);

                // btsData 数据合并
                if (btsData.versionid) {
                    Object.assign(data, {
                        bts: btsData
                    });
                }
            }

            // 合并用户自定义数据
            data = {
                ...data,
                ...this.customClickTrackCallback({
                    keyTarget,
                    dom,
                    classKey,
                    configData,
                    module,
                    targetData
                })
            };

            // 记录来源
            if (recordOrigin === 2 || (recordOrigin === 1 && pm)) {
                this.saveRecordOrigin(recordOrigin, mergeOrigin, data, pm, module, keyTarget);
            }

            // 上报来源
            if (reportOrigin) {
                data.ubcta = { ...data.ubcta, ...this.getRecordOrigin() };
            }

            // 上报bts
            if (reportBTS) {
                data = { ...data, ...this.getBTS() };
            }
            // 记录bts
            if (recordBTS) {
                this.saveBTS(recordBTS, dom);
            }

            if (configData.crossPage) {
                Track.crossPageSaveData({ data, toPage: configData.crossPage });
            } else {
                Track.sendData({ type: 'click', data });
            }
        }
    }
    mutationCallback(mutations) {
        // ie 11 target 存在重複
        const mutationItems = new Set();
        mutations.forEach(m => mutationItems.add(m.target));

        this.mutationSize -= mutationItems.size;

        if (this.mutationSize <= 0 && !this.noReleaseConnection) {
            console.warn('大数据异步数据加载完毕 mutation disconnect');
            this.MUTATION.disconnect();
        }

        mutationItems.forEach((item) => {
            const classA = Array.from(item.classList);
            const entries = Object.entries(this.EXPLORE_ASYNC);
            const exploreConfig = {};
            const tmpArray = entries.filter(el => classA.includes(el[1].observer.substr(1)));
            if (tmpArray.length) {
                tmpArray.forEach(([key, value]) => {
                    exploreConfig[key] = value;
                });
                this.parsePageModule(exploreConfig);
                if (Object.keys(exploreConfig).length) {
                    this.exploreTrack(exploreConfig);
                    setTimeout(() => {
                        PubSub.publish('asyncExplore', {
                            selector: tmpArray[0][0],
                            observeElement: item
                        });
                    }, 0);

                    // 释放 observer

                }
            }
        });
    }
    mutationTrack(dataConfig = this.EXPLORE_ASYNC) {
        const mutateClass = new Set();
        Object.values(dataConfig).forEach((value) => {
            mutateClass.add(value.observer);
        });

        // 記錄長度 方便釋放

        mutateClass.forEach((item) => {
            try {
                const queryObserveDom = [...document.querySelectorAll(item)];
                this.mutationSize += queryObserveDom.length;
                queryObserveDom.forEach((domItem) => {
                    this.MUTATION.observe(domItem, { childList: true });
                });
            } catch (e) {
                // nothing
                this.mutationSize -= 1;
            }
        });
    }
    searchTarget(target) {
        let el = target;
        const res = { classKey: null, dom: null };
        do {
            let r = Object.keys(this.CLICK_CONFIG).filter(item => Array.from(el.classList).includes(item.substr(1))); // eslint-disable-line
            [res.classKey] = r;
            res.dom = el;
            el = el.parentElement;
        } while (!res.classKey && el !== null);
        return res;
    }
    static verify() {
        return !!Track.DATA_TRACK;
    }
    splitDataConfig() {
        Object.entries(this.config).forEach(([key, value]) => {
            if (value.click) {
                if (value.click instanceof Array) {
                    value.click.forEach((item) => {
                        if (item === 'self') {
                            this.CLICK_CONFIG[key] = value;
                        } else {
                            this.CLICK_CONFIG[item] = value;
                        }
                    });
                }
                if (isString(value.click)) {
                    if (value.click === 'self') {
                        this.CLICK_CONFIG[key] = value;
                    } else {
                        this.CLICK_CONFIG[value.click] = value;
                    }
                }
            }
            if (value.explore) {
                if (value.async) {
                    this.EXPLORE_ASYNC[key] = value;
                } else {
                    this.EXPLORE_SYNC[key] = value;
                }
                if (value.append) {
                    this.EXPLORE_ASYNC[key] = value;
                }
            }
        });
    }
    parsePageModule(dataConfig = this.EXPLORE_SYNC) {
        const keys = Object.keys(dataConfig);
        keys.forEach((key) => {
            const item = dataConfig[key];
            if (item.module) {
                if (!item.start && !item.parent) {
                    $(key).each((i, el) => {
                        $(el).attr('data-track-module', item.module);
                    });
                }
                if (!item.start && item.parent) {
                    $(key).each((i, el) => {
                        const $parent = $(el).parents(item.parent.query);
                        const str = Track.getModuleLevel(item.parent, item.parent.query, $parent);
                        $(el).attr('data-track-module', item.module.replace('@', String.fromCharCode(str)));
                    });
                }
                if (item.start && !item.parent) {
                    $(key).each((i, el) => {
                        const num = Track.getModuleLevel(item, key, el);
                        $(el).attr('data-track-module', item.module.replace('@', num));
                    });
                }
                if (item.start && item.parent) {
                    $(key).each((i, el) => {
                        const $parent = $(el).parents(item.parent.query);
                        const num = Track.getModuleLevel(item, key, el, $parent);
                        const str = Track.getModuleLevel(item.parent, item.parent.query, $parent);
                        $(el).attr('data-track-module', `${String.fromCharCode(str)}_${num}`);
                    });
                }
            }
        });
    }
    static getModuleLevel(item, key, el, $parent) {
        let { start } = item;
        if (isString(start)) {
            start = start.codePointAt();
        }
        if ($parent) {
            return $parent.find(key).index(el) + start;
        }
        return $(el).index(key) + start;
    }
    destroy() {
        this.OBSERVER.forEach((item) => {
            item.disconnect();
        });
        this.EXPLORE_QUEUE = {};
        this.MUTATION.disconnect();
        document.querySelector(this.context).removeEventListener('click', this.bindFunctionScope);
    }

    static use(pluginFn) {
        pluginFn(Hooks, Track);
    }
}

Track.use(sortFilter);

export default Track;
