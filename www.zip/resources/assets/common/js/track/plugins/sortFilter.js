/**
 * Created by Liu Jun on 2019/4/18
 */

// 大数据sort 字段sort 统一转换
const replaceConfig = [
    {
        origin: '"sort":"low2high"',
        target: '"sort":"price-low-to-high"'
    },
    {
        origin: '"sort":"high2low"',
        target: '"sort":"price-high-to-low"'
    },
    {
        origin: '"sort":"relevance"',
        target: '"sort":"best_match"'
    },
];

export default (hooks) => {
    hooks.on('onSendData', ({ data }) => {
        for (const d in data) {
            if (data[d]) {
                let pushDataStr = JSON.stringify(data[d]);
                replaceConfig.forEach((item) => {
                    pushDataStr = pushDataStr.replace(new RegExp(item.origin, 'g'), item.target);
                });

                data[d] = JSON.parse(pushDataStr);
            }
        }
    });
};
