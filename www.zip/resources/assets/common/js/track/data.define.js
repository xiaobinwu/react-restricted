const BIGDATA = {
    common: {
        oi: '', // session id
        u: '', // user id
        pl: '', // document.refferrer
        d: '10002', // 站点表示
        b: '', // 页面大类
        s: '', // 页面小类
        p: '', // 页面编码
        dc: '201', // 国家站标识
        lkid: '', // linkid
        pageType: '', // ['index', 'goods', 'list', 'cart', 'user', 'login']
        pagemodule: '', // 适用与专题页
    },
    search: {
        at: '', // 搜索结果商品数量(只在搜索结果页里面)
    },
    'sku/id': { // 对于商品而言这个id就是sku，对于banner 而言，这个是banner的id
        k: '', // 仓库信息
        pc: '', // 分类id
        pam: 1, // 商品数量
    },
};

export default BIGDATA;
