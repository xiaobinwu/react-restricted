/**
 * 采用事件发布机制，此文件是一些系统事件
 */

import PubSub from 'pubsub-js';

import { updateCurrency } from 'js/core/currency';
import { initLazyload, updateLazyload } from 'js/utils/lazyload.js';
import { updateUpgradeSimpleCart, addToCart } from 'js/core/goods/cart.js';
import { updateHeaderUserInfo } from 'js/core/user.js';


/**
 * 系统订阅的事件
 */
PubSub.subscribe('sysUpdateCurrency', (msg, data) => {
    updateCurrency(data);
});

PubSub.subscribe('sysUpdateUserInfo', () => {
    updateHeaderUserInfo();
});

PubSub.subscribe('sysUpdateSampleCart', (msg, data) => {
    updateUpgradeSimpleCart(data);
});

PubSub.subscribe('sysAddToCart', (msg, data) => {
    addToCart(data);
});

PubSub.subscribe('sysInitLazyload', (msg, data) => {
    initLazyload(data);
});

PubSub.subscribe('sysUpdateLazyload', (msg, data) => {
    updateLazyload(data);
});
