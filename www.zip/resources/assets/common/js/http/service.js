/**
 * 全局异步数据接口获取
 */

import http from './index';

// 获取每个请求唯一的key
function getLocalCacheKey(params) {
    try {
        const a = document.createElement('a');
        a.setAttribute('href', params.url);
        const queryStr = Object.entries({
            ...params.params,
            ...String(params.data) === params.data ? {
                pdata: params.data
            } : params.data
        }).map(([key, value]) => `${key}_${value}`).join('_');
        return `${a.pathname}_${queryStr}`.replace(/[^a-z | A-Z | \d]/g, '_');
    } catch (e) {
        return false;
    }
}

export default class Service {
    constructor(params) {
        this.params = Object.assign({
            method: 'jsonp',
            loading: true, // 请求过程中是否显示菊花图
            isCancel: true, // 如果第二次请求发起在第一次请求结束之前，取消第一次请求
            errorPop: true, // 是否弹出默认错误信息
            cache: false, // JSONP callback 固定，固定请求地址命中 cdn
            useLocalCache: 0, // 通过本地缓存cache 接口数据，0 不缓存，单位 （s） 3 * 24 * 60 * 60
            usePreResult: false, // 多次请求同一个接口，皆返回第一次请求的数据，不会判断参数变更，谨慎使用
            isLogin: false, // 设置为true时，接口只能在用户登录后才能登录，否则自动调到登录页面
        }, params);
    }

    async http(params) {
        // 等待前置条件完成（目前仅用在添加购物车接口）
        try {
            if (this.params.additional) params = await this.params.additional(params);
        } catch (e) {
            // nothing
        }

        const curParams = Object.assign({}, this.params, params);

        // 多次请求同一个接口，皆返回第一次请求的数据
        if (curParams.usePreResult && this.$preResult) return this.$preResult;

        // 如果第二次请求发起在第一次请求结束之前，取消第一次请求
        if (curParams.isCancel) {
            this.cancel();
        }

        this.cancelToken = http.CancelToken.source(curParams.method);

        // 判断是否本地存储
        let localCacheName;
        if (curParams.useLocalCache > 0) {
            localCacheName = getLocalCacheKey(curParams);
            if (localCacheName) {
                // 正常获取key名
                try {
                    const cacheData = JSON.parse(window.sessionStorage.getItem(localCacheName));
                    const { lastCacheTime, result } = cacheData;

                    if (lastCacheTime + curParams.useLocalCache >= Math.round((+new Date()) / 1000)) {
                        return result;
                    }
                } catch (e) {
                    // nothing
                }
            }
        }

        // cache 前一次的promise 对象
        this.$preResult = http(({
            cancelToken: this.cancelToken.token,
            ...curParams,
        })).then((result) => {
            // 接口报错不缓存
            if (result.status === 0 && curParams.useLocalCache > 0) {
                setTimeout(() => {
                    // 设置缓存和缓存时的时间
                    try {
                        window.sessionStorage.setItem(localCacheName, JSON.stringify({
                            result,
                            lastCacheTime: Math.round((+new Date()) / 1000)
                        }));
                    } catch (e) {
                        // nothing
                    }
                }, 0);
            }

            return result;
        });

        return this.$preResult;
    }

    cancel() {
        if (this.cancelToken) {
            this.cancelToken.cancel();
        }
    }
}
