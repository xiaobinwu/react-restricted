import axios from 'axios';

import gAxios from './gAxios';
import jsonp from './jsonp';

function http(options) {
    const curFetch = String(options.method).toLocaleLowerCase() === 'jsonp' ? jsonp : gAxios;
    return curFetch(options);
}

// jsonp 兼容 axios 取消操作
http.CancelToken = {
    source(type) {
        if (type === 'jsonp') {
            return jsonp.CancelToken.source();
        }
        return axios.CancelToken.source();
    },
};

export default http;
