/**
 * Created by Liu.Jun on 2018/4/5.
 */

// axios jsonp 公用

import layer from 'layer';

let loading = null; // loading层
let loadingSock = 0; // 用来控制loading层行为的一把锁

export function push(config) {
    if (config && config.loading) {
        if (loadingSock === 0) {
            loading = layer.loading(); // 打开loading层
        }
        loadingSock += 1; // 计数器加1
    }
}

export function pop(config) {
    if (config && config.loading) {
        loadingSock -= 1; // 计数器减1
        if (loadingSock === 0) {
            layer.close(loading); // 关闭loading层
        }
    }
}

export function errPop(res) {
    // int
    try {
        res.data.status = +res.data.code === 200 ? 0 : +res.data.status;
    } catch (e) {
        // nothing
    }

    if (res.data.status !== 0 && res.config.errorPop) {
        // 统一错误处理`
        layer.msg(res.data.msg);
        const { errorCall } = res.config; // 凯子需要保留 错误信息回调
        if (errorCall) {
            errorCall(res);
        }
    }
}

export function redirectUrl(res) {
    if (res.config.isLogin && res.data.data && res.data.data.redirectUrl) {
        res.config.errorPop = false;
        res.config.loading = false;
        window.location.href = res.data.data.redirectUrl;
    }
}
