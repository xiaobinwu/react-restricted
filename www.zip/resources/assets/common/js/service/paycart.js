import Service from '../http/service';

const {
    DOMAIN_CART,
    DOMAIN_ORDER,
    DOMAIN_MAIN,
} = GLOBAL;

/* 购物车相关页面接口 */
// 购物车列表
export const serviceCartList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/list?${+new Date()}`,
    errorPop: false,
    loading: false,
});

// 变更商品选中状态
export const serviceCartSelect = new Service({
    method: 'POST',
    url: '/cart/select',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
    loading: false,
});

// 变更商品参与活动
export const serviceCartChange = new Service({
    method: 'POST',
    url: '/cart/change',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
    loading: false,
});

// 删除商品
export const serviceCartDelete = new Service({
    method: 'POST',
    url: '/cart/delete',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
});

// 更改商品数量
export const serviceCartUpdate = new Service({
    method: 'POST',
    url: '/cart/update',
    headers: { 'Content-Type': 'application/json' },
    loading: false,
});

// 获取活动赠品/加价购商品
export const serviceCartGift = new Service({
    method: 'jsonp',
    url: '/cart/gift',
    loading: false,
    errorPop: false,
});

// 获取同款商品属性
export const serviceCartSameGoods = new Service({
    method: 'jsonp',
    url: '/cart/same',
    errorPop: false,
    loading: false,
});

// 替换商品属性
export const serviceCartReplace = new Service({
    method: 'POST',
    url: '/cart/replace',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
    loading: false,
});

// 保存商品活动信息
export const serviceCartSaveActs = new Service({
    method: 'POST',
    url: '/cart/save',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
    loading: false,
});

// 请求快捷支付
export const serviceCartSendQuickPay = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/payment/express-checkout`,
    headers: { 'Content-Type': 'application/json' },
    loading: false,
});

// 快捷支付获取支付方式
export const serviceCartGetQuickPayMode = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/payment/express-channel`,
    loading: false,
});

// 底部推荐商品位
export const serviceCartRecommend = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/recommend`,
    loading: false,
});

// 查询分类名称路径
export const serviceGetCategoryInfo = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/category`,
    errorPop: false,
    loading: false,
});

// 不通邮检测
export const serviceShipCheck = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/ship-check`,
    errorPop: false,
    loading: false,
});

// 加载店铺优惠券
export const serviceCartCoupon = new Service({
    method: 'POST',
    url: `${DOMAIN_CART}/cart/coupon`,
    errorPop: false,
    loading: false,
});

/* 支付流程相关页面 --- 订单确认页 */
// 订单确认页页面数据
export const serviceCheckoutPageData = new Service({
    method: 'POST',
    url: '/checkout/list',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
    loading: false,
});

// 支付折扣
export const serviceCartPayrelate = new Service({
    method: 'jsonp',
    url: `${DOMAIN_CART}/cart/pay-relate`,
    errorPop: false,
    loading: false,
});

// 订单确认页用户可用优惠券列表
export const serviceCheckoutGetCounponList = new Service({
    method: 'POST',
    url: '/checkout/coupon',
    headers: { 'Content-Type': 'application/json' },
    loading: false,
});

// 订单确认页创建订单
export const serviceCheckoutCreateOrder = new Service({
    method: 'POST',
    url: '/order/create',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
    loading: false,
});

// 选择物流方式查询税费
export const serviceCheckoutQueryTax = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/tax`,
    loading: true,
});

// 快捷支付确认支付
export const serviceCheckoutQuickPayCreate = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/payment/express-pay`,
    loading: true,
});

// 订单确认页普通支付请求跳转支付平台连接
export const serviceCheckoutGoToPay = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/payment/go-pay`,
    loading: true,
});

export const serviceCartAddressEdit = new Service({
    method: 'POST',
    url: '/checkout/address/save',
    headers: { 'Content-Type': 'application/json' },
    errorPop: true,
    loading: true,
});

export const serviceGetPayChannels = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/pay-channels`,
    errorPop: true,
    loading: false,
});

export const serviceGetPayRelate = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/pay-relate`,
});

export const serviceInsuranceType = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/insurance-type `,
});

export const serviceGetShopList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/store/shop-list`,
});

export const serviceGetBtsInfo = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/checkout/bts`,
});

export const serviceSendCodSMS = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/send-cod-sms`,
});

export const serviceCheckCodSMS = new Service({
    method: 'POST',
    url: `${DOMAIN_ORDER}/checkout/check-cod-sms`,
});

/* 支付流程相关页面 --- 支付结果页 */
// 后置礼包兑换抽奖次数
export const servicePaymetResultsGiftNum = new Service({
    method: 'POST',
    url: '/activity/gift/exchange-num',
    headers: { 'Content-Type': 'application/json' },
    errorPop: false,
    loading: false,
});

// 后置礼包兑换抽奖
export const servicePaymetResultsGift = new Service({
    method: 'POST',
    url: '/activity/gift/raffle',
    headers: { 'Content-Type': 'application/json' },
    loading: false,
});

/* 支付流程相关页面 --- 地址编辑页 */
// 获取用户地址信息
export const serviceCartAddressGetAddress = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/checkout/address/list`,
    loading: false,
});

// 地址编辑页请求快捷支付地址信息
export const serviceGetQuickPayAddress = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/payment/user-paypal-info`,
    loading: true,
});

/**
 * 支付流程相关页面 --- 快捷购物版支付结果页
 * 替换游客邮箱
 *
 */
export const servicePaymetResultsVisitorReplace = new Service({
    method: 'POST',
    url: '/replace-visitor-email',
    loading: true,
    errorPop: false,
});

/**
 * 换未激活用户邮箱
 */
export const servicePaymetResultsReplaceEmail = new Service({
    method: 'POST',
    url: '/replace-user-email',
    loading: true,
    errorPop: false,
});
