/**
 * @Desc: 商详相关数据接口
 * @Author: luochongfei
 * @Date: 2018-03-28 10:29:18
 */

import Service from '../http/service';

const { DOMAIN_MAIN } = window.GLOBAL || {};

/**
 * 批发查询
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=29820515
 */
export const serviceWholesaleInquiry = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/goods/wholesale-inquiry`,
});

/**
 * 买即赠列表
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=30476602
 */
export const serviceGoodsGift = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/goods/get-gift`,
});

/**
 * 到货通知订阅
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=30474960
 */
export const serviceArrivalNotice = new Service({
    method: 'POST',
    url: '/goods/add-user-subscribe',
});

/**
 * 营销价格及营销信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=29822315
 * 废弃：已合并至serviceGoodsMultiInfo
 */
// export const serviceGoodsPrice = new Service({
//     loading: false,
//     method: 'jsonp',
//     url: `${DOMAIN_MAIN}/goods/get-price`,
// });

/**
 * 商品库存
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=29822323
 * 废弃：已合并至serviceGoodsMultiInfo
 */
// export const serviceGoodsStock = new Service({
//     method: 'jsonp',
//     loading: false,
//     url: `${DOMAIN_MAIN}/goods/get-stock`,
// });

/**
 * 物流配送信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31786536
 */
// export const serviceGoodsShipping = new Service({
//     method: 'jsonp',
//     loading: false,
//     cache: true,
//     url: `${DOMAIN_MAIN}/goods/get-shipping`,
// });

/**
 * 物流可配送国家列表
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=55280002
 */
export const serviceGoodsShippingCountry = new Service({
    method: 'jsonp',
    loading: false,
    cache: true,
    url: `${DOMAIN_MAIN}/goods/shipping-country`,
});

/**
 * FAQ列表
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=32544427
 */
export const serviceGoodsFaqInquiry = new Service({
    method: 'jsonp',
    cache: true,
    url: `${DOMAIN_MAIN}/goods/faq/inquiry`,
});

/**
 * FAQ问题添加
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=32544027
 */
export const serviceGoodsFaqAdd = new Service({
    method: 'POST',
    url: '/goods/faq/sms-submit',
});

/**
 * 仓库状态列表
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=33161861
 */
export const serviceGoodsWarehouseStatus = new Service({
    method: 'jsonp',
    loading: false,
    url: `${DOMAIN_MAIN}/goods/warehouse-goods-status`,
});

/**
 * 分期付款列表信息
 * 废弃：已合并至serviceGoodsMultiInfo
 */
// export const serviceGoodsInstallmentInfo = new Service({
//     method: 'jsonp',
//     loading: false,
//     url: `${DOMAIN_MAIN}/goods/instalment-info`,
// });

/**
 * 店铺收藏状态
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=37719442
 */
export const serviceGoodsStoreCollectStatus = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/store/has-collect`,
    loading: false,
});

/**
 * 商品收藏信息+状态
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=38503331
 */
// export const serviceGoodsUserCollectStatus = new Service({
//     method: 'jsonp',
//     url: `${DOMAIN_MAIN}/goods/user-fav`,
//     loading: false,
// });

/**
 * 商品评论列表
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=29823290
 */
export const serviceReviewList = new Service({
    method: 'jsonp',
    cache: true,
    url: `${DOMAIN_MAIN}/review/get-list`,
});

/**
 * 商品评论点赞
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=29823351
 */
export const serviceReviewHelpful = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/review/helpful`,
});

//  商品点击率url获取
export const serviceGoodsClickUrl = new Service({
    method: 'jsonp',
    loading: false,
    url: `${DOMAIN_MAIN}/goods/get-click-url`,
});

/**
 * 商详推荐位数据
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=38505799
 */
export class ServiceGoodsRecommend extends Service {
    constructor() {
        super({
            method: 'jsonp',
            url: `${DOMAIN_MAIN}/goods/recommend`,
            loading: false,
        });
    }
}

/**
 * 商详合并接口： [get-price, get-stock, installment_info, goodsStatus]
 * 2018-04-26 16:44:41
 * @param good_sn,warehouse_code,shop_code,is_virtual,categoryId
 */
export const serviceGoodsMultiInfo = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/goods/goods-multi`,
    loading: false,
    cache: true,
});

/**
 * 商详合并接口： [goods-collect, shop-collect]
 */
export const serviceGoodsCollect = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/goods/user-collect`,
    loading: false,
});

/**
 * 提交商品评论
 */
export const serviceReviewCreate = new Service({
    method: 'POST',
    url: '/review/create',
});

/**
 * coupon和promotion信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=56525457
 * 2018-06-20 10:43:47 新增
 */
export const serviceGoodsPromotion = new Service({
    cache: true,
    url: `${DOMAIN_MAIN}/goods/promotion`,
});

/**
 * 异步获取精选商品
 */
export const serviceGetConcentrateGoods = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/new-arrival/concentrate-goods`,
    errorPop: true,
    cache: false,
    loading: true,
});

/**
 * 异步获取可发仓列表及当前仓物流信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=62030666
 */
export const serviceGetWareListAndShipping = new Service({
    url: `${DOMAIN_MAIN}/goods/goods-shipping`,
    errorPop: false,
    cache: true,
    loading: false,
});


/**
 * 异步获取可发仓列表及当前仓物流信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=62030666
 */
export const serviceGetBindBuy = new Service({
    url: `${DOMAIN_MAIN}/goods/goods-parts`,
    method: 'jsonp',
    errorPop: false,
    loading: false,
    cache: true,
});


/**
 * 切换语言查询多语言信息
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=96339779
 */
export const serviceSwitchInfo = new Service({
    url: `${DOMAIN_MAIN}/goods/goods-switch-info`,
    errorPop: false,
    loading: false,
    cache: true,
});

/**
 * seo着陆页New Sales获取
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=96339779
 */
export const serviceGetSeoNewSales = new Service({
    method: 'jsonp',
    errorPop: true,
    cache: false,
    loading: true
});
