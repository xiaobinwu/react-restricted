import Service from '../http/service';

const { DOMAIN_MAIN } = window.GLOBAL;

// 获取hoto 列表数据
export const serviceGetHowtoData = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/blog/how_to`,
});

//  blog 文章点赞
export const serviceArticleLike = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/blog/article/like`,
});
