import Service from '../http/service';

const {
    DOMAIN_USER,
    DOMAIN_MAIN,
    DOMAIN_ORDER,
    BIGDATA_URL
} = window.GLOBAL;

// 点击message us跳转链接
export const serviceGetMessenger = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/get-messenger-link`,
    isLogin: true,
});

// 编辑用户基本信息
export const serviceEditUserInfo = new Service({
    method: 'post',
    url: '/user/edit-profile',
    isLogin: true,
    errorPop: false,
});

// 更新用户头像
export const serviceUpdateAvatar = new Service({
    method: 'post',
    isLogin: true,
    url: '/user/update-icon',
});

// 成长值加成
export const serviceAddGrowup = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/member-growup-scene`,
    isLogin: true,
});

// 修改用户密码
export const serviceChangePwd = new Service({
    method: 'post',
    url: '/user/change-password',
    isLogin: true,
    errorPop: false,
});

// 获取地址本列表
export const serviceGetAddressList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/address-book`,
    isLogin: true,
});

// 设置默认地址
export const serviceSetDefaultAddress = new Service({
    method: 'post',
    url: '/user/set-default-addr',
    isLogin: true,
});

// 删除地址
export const serviceDeleteAddress = new Service({
    method: 'post',
    url: '/user/delete-address',
    isLogin: true,
});

// 添加地址
export const serviceAddAddress = new Service({
    method: 'post',
    url: '/user/add-address',
});

// 修改地址
export const serviceEditAddress = new Service({
    method: 'post',
    url: '/user/edit-address',
});

// 获取国家列表
export const serviceGetCountry = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/get-country`,
    loading: false,
    cache: true,
    usePreResult: true,
});

// 获取省列表
export const serviceGetProvince = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/user/get-province`,
    loading: false
});

// 获取城市列表
export const serviceGetCity = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/user/get-city`,
    loading: false,
    cache: true,
});

// 获取用户积分信息
export const serviceUserPoint = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/query-user-points-info`,
});

// 获取用户积分列表
export const servicePointList = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/query-points-detail`,
});

// 获取会员中心信息
export const serviceMemberCenter = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/member-center`,
});

// 获取会员中心规则页信息
export const serviceMemberRule = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/member-rule`,
});

// 会员礼包
export const serviceMemberReceiveGift = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/member-receive-gift`,
});

// 我的coupon
export const serviceCouponList = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/coupon/index`,
});

// 我的收藏（商品）
export const serviceCollection = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/collection`,
});

// 批量删除收藏商品
export const serviceDeleteCollection = new Service({
    method: 'post',
    isLogin: true,
    url: '/user/collection/delete',
});

// 我的收藏（店铺）
export const serviceStoreList = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/store`,
});

// 批量收藏/取消店铺
export const serviceStoreCollect = new Service({
    method: 'post',
    isLogin: true,
    url: '/user/store-collect',
});

// 订单--列表
export const serviceOrderList = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_ORDER}/order/list`,
});

// 订单--取消原因列表
export const serviceOrderReason = new Service({
    method: 'jsonp',
    url: `${DOMAIN_ORDER}/order/reason`,
});

// 订单--取消/退款
export const serviceOrderCancel = new Service({
    method: 'post',
    isLogin: true,
    url: '/order/cancel',
});

// 订单--催单
export const serviceOrderExpedite = new Service({
    method: 'post',
    isLogin: true,
    url: '/order/expedite',
});

// 订单--确认收货
export const serviceOrderConfirm = new Service({
    method: 'post',
    isLogin: true,
    url: '/order/confirm',
});

// 订单--详情
export const serviceOrderDetail = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_ORDER}/order/detail`,
});

// 订单--发票状态
export const serviceOrderInvoice = new Service({
    method: 'jsonp',
    isLogin: true,
    isCancel: false,
    url: `${DOMAIN_ORDER}/order/invoice-status`,
});

// 订单--包裹物流
export const serviceOrderPackage = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_ORDER}/order/package`,
});

// 订单--获取RMA信息
export const serviceToRma = new Service({
    method: 'post',
    isLogin: true,
    url: '/order/rma'
});

// 订单--去信通知
export const serviceLetterFlag = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/payment/send-letter-flag`,
});

// 自定义地址校验接口
export const serviceGetAddressRule = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/get-address-rule`,
});

// 通过zipcode 获取巴西国家洲等信息
export const serviceGetBrazilCode = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/get-brazil-code`,
});

/* 电子钱包相关接口 */
// 余额
export const serviceWalletBalance = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/payment/wallet/balance`,
    errorPop: true,
    loading: true,
});

// 流水明细 -- loding按需取用
export const serviceWalletList = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_USER}/payment/wallet/list`,
});

// 发送重置邮件
export const serviceWalletSendEmail = new Service({
    method: 'POST',
    isLogin: true,
    url: '/payment/wallet/send-email',
    loading: true,
});

// 重置密码
export const serviceWalletPasswordSave = new Service({
    method: 'POST',
    isLogin: true,
    url: '/payment/wallet/password-save',
    errorPop: false,
    loading: true,
});

// 验证token
export const serviceWalletVerificationToken = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/payment/wallet/reset-password`,
    errorPop: false,
    loading: true,
});

// 更改密码
export const serviceWalletChangePassword = new Service({
    method: 'POST',
    url: '/payment/wallet/change-password',
    errorPop: false,
    loading: true,
});

// 地址编辑页获取obs配置校验规则 --- 订单地址编辑页需要多次请求后面再进行调整
export class serviceCheckoutAddressGetRules extends Service {
    constructor() {
        super({
            method: 'jsonp',
            url: `${DOMAIN_USER}/get-address-rule`,
            loading: false,
        });
    }
}

// 会员-提交订单评论
export const serviceUserReviewAdd = new Service({
    method: 'POST',
    isLogin: true,
    url: '/user/order/review/create',
});

// 会员-提交商品评论
export const serviceUserReviewGoodsAdd = new Service({
    method: 'POST',
    isLogin: true,
    url: '/user/goods/review/create',
});

// 会员-评论详情
export const serviceUserReviewDetail = new Service({
    method: 'jsonp',
    isLogin: true,
    url: `${DOMAIN_MAIN}/user/order/review/detail`,
});

// 会员-评论列表
export const serviceUserReviewList = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/user/order/review`,
    isLogin: true,
});

// 会员-获取推荐商品
export const serviceGetRecomment = new Service({
    method: 'POST',
    errorPop: false,
    loading: false,
    url: BIGDATA_URL,
    Headers: {
        'Content-type': 'application/x-www-form-urlencoded'
    },
    transformRequest(bodyData, headers) {
        // https://github.com/axios/axios/issues/382
        const tempHeaders = headers;
        delete tempHeaders.common['X-CSRF-TOKEN'];
        delete tempHeaders.common['X-Requested-With'];
        return bodyData;
    }
});

// GC银行--收款账号信息（BankTransfer）
export const serviceGetBankTransferInfo = new Service({
    url: `${DOMAIN_ORDER}/payment/bank-transfer-account`,
});

// multibanco支付第三方付款凭证信息
export const serviceGetMultibanco = new Service({
    url: `${DOMAIN_ORDER}/payment/multibanco-info`,
});
// 谷歌地址智能提醒
export const serviceUserGoogleAddress = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/user/address-auto-complete`,
});
export const serviceUserGoogleDetails = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/user/address-geo-coding`,
});

/* 站内信相关接口 */
// 获取消息列表
export const serviceMessageList = new Service({
    url: `${DOMAIN_USER}/message/list`,
    isLogin: true,
});

// 获取用户未读消息总数
export const serviceMessageCount = new Service({
    url: `${DOMAIN_USER}/message/unread-count`,
    errorPop: false,
    loading: false,
});

// 获取各个消息源的未读消息总数
export const serviceMessageSourceCount = new Service({
    url: `${DOMAIN_USER}/message/source-unread-count`,
    isLogin: true,
});

// 批量标记消息为已读状态
export const serviceMessageBatchMarkRead = new Service({
    method: 'POST',
    url: `${DOMAIN_USER}/message/batch-mark-read`,
    isLogin: true,
});

// 消息详情页面
export const serviceMessageInfo = new Service({
    url: `${DOMAIN_USER}/message/info`,
    isLogin: true,
});

// 删除消息
export const serviceMessageDelete = new Service({
    method: 'POST',
    url: '/message/delete-message',
    isLogin: true,
});

// 留言列表
export const serviceMessageLeaveList = new Service({
    url: 'user/messages',
    isLogin: true,
});

// 留言详情
export const serviceMessageLeaveDetail = new Service({
    url: 'user/messages/detail',
    isLogin: true,
});

// 留言删除
export const serviceMessageLeaveDelete = new Service({
    method: 'POST',
    url: 'user/messages/delete',
    isLogin: true,
});

// 回复留言
export const serviceReplyMessageLeave = new Service({
    method: 'POST',
    url: 'user/messages/reply',
    isCancel: false,
});

// 留言
export const serviceMessageLeave = new Service({
    method: 'POST',
    url: 'user/messages/add',
    isLogin: true,
    isCancel: false,
});

// 仲裁留言列表
export const serviceArbitrationList = new Service({
    url: 'user/arbitration/messages',
    isLogin: true,
});

// 仲裁留言详情
export const serviceArbitrationDetail = new Service({
    url: 'user/arbitration/messages/detail',
    isLogin: true,
});

// 仲裁留言删除
export const serviceArbitrationDelete = new Service({
    method: 'POST',
    url: 'user/arbitration/messages/delete',
    isLogin: true,
});

// 仲裁留言回复
export const serviceArbitrationReply = new Service({
    method: 'POST',
    url: 'user/arbitration/messages/reply',
    isLogin: true,
});

// 生成发票
export const serviceCreateInvoice = new Service({
    method: 'POST',
    url: '/order/create-invoice',
    isLogin: true,
});

// 预约提醒
export const serviceReservation = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/reservation/list`,
    isLogin: true,
});

// 获取预约删除消息
export const serviceReservationDelete = new Service({
    method: 'POST',
    url: '/reservation/delete',
    isLogin: true,
});

// 获取预约总数
export const serviceReservationTotal = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/reservation/total`,
    isLogin: true,
});

// 判断地址手机号码的有效性
export const serviceIsAvailablePhone = new Service({
    url: `${DOMAIN_USER}/user/address/is-available-phone`,
});
