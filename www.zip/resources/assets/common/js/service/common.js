import XDStorage from 'js/utils/XDStorage';
import { XD_STORAGE_SERVICEINFO } from 'js/variables';
import Service from '../http/service';

const {
    DOMAIN_MAIN, DOMAIN_USER, DOMAIN_CART, ASYNC_PRICE, CART_THEME_TYPE
} = GLOBAL;
const remoteStorage = new XDStorage();
const curCDN = window.GLOBAL.CDN_CUR;

// 获取实时价格接口（此处原先接口url由GLOBAL吐出）
export const serviceAsyncPrice = new Service({ // eslint-disable-line
    method: 'POST',
    url: ASYNC_PRICE,
    loading: false,
    errorPop: false,
    withCredentials: false,
    headers: {},
});

// 网站头部购物车接口  st 站接口 /cart/simple-new
export const serviceSampleCart = new Service({
    method: 'jsonp',
    loading: false,
    url: `${DOMAIN_CART}/cart/simple${CART_THEME_TYPE === 2 ? '-new' : ''}`,
});

export const serviceGetCouponItem = new Service({
    method: 'POST',
    isCancel: false,
    url: '/user/coupon/receive',
});

// 网站头部获取用户状态
export const serviceUserStatus = new Service({
    method: 'jsonp',
    loading: false,
    url: `${DOMAIN_USER}/check/info`,
});

// 公用底部邮件订阅接口
export const serviceSubscribe = new Service({ // eslint-disable-line
    method: 'POST',
    url: '/subscribe',
});

// 网站热搜和关联词接口
export const serviceSearch = new Service({
    method: 'jsonp',
    loading: false,
    cache: true,
    url: `${DOMAIN_MAIN}/get-keyword`,
});

// 意见反馈
export const serviceFeedBack = new Service({
    method: 'post',
    url: '/feedback',
});

// 搜索页意见反馈
export const serviceSearchFeedBack = new Service({
    method: 'post',
    url: '/search/feedback',
    errorPop: false,
});

// 首页历史记录和推荐位接口
export const serviceIndexHistory = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    cache: true,
    url: `${DOMAIN_MAIN}/user/recent/viewed`,
});

// 全站公用添加收藏
export const serviceCollectAdd = new Service({
    method: 'POST',
    url: '/user/collection/add',
    errorPop: false,
    loading: false,
});

// 全站加入购物车
export const serviceAddToCart = new Service({
    method: 'POST',
    url: '/cart/add',
    headers: { 'Content-Type': 'application/json' },
    additional(params) {
        return new Promise((resolve, reject) => {
            remoteStorage.getValue(XD_STORAGE_SERVICEINFO, (key, value) => {
                if (value) {
                    let goodsData = params.data.goods;
                    if (typeof params.data.goods === 'string') goodsData = JSON.parse(params.data.goods);
                    if (Array.isArray(goodsData)) {
                        goodsData.forEach((goodsItem, goodsIndex) => {
                            if (value.serviceSkuArr.some(item => +item === +goodsItem.goodsSn)) {
                                goodsItem.serviceId = value.serviceId;
                            }
                        });
                    } else if (value.serviceSkuArr.some(item => +item === +goodsData.goodsSn)) {
                        goodsData.serviceId = value.serviceId;
                    }
                    params.data.goods = JSON.stringify(goodsData);
                }
                resolve(params);
            });
        });
    }
});

// 针对于个人中心删除收藏
export const serviceCollectRemove = new Service({
    method: 'POST',
    url: '/user/collection/delete',
    errorPop: false,
    loading: false,
});

// 针对于全站商品列表删除收藏
export const serviceGoodlistCollectRemove = new Service({
    method: 'POST',
    url: '/user/collection/delete-fav-goods',
    errorPop: false,
    loading: false,
});

/**
 * 针对于全站异步获取收藏状态
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=38503331
 */
export const serviceCollectStatus = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/goods/user-fav`,
    errorPop: false,
    loading: false,
});

/**
 * 针对于地址编辑获取国家列表
 *
 */
export class serviceGetCountry extends Service {
    constructor() {
        super({
            method: 'jsonp',
            url: `${DOMAIN_MAIN}/get-country`,
            loading: false,
            cache: true,
        });
    }
}

/**
 * 针对于地址编辑获取省份列表
 *
 */
export class serviceGetProvince extends Service {
    constructor() {
        super({
            method: 'jsonp',
            url: '/user/get-province',
            loading: false,
            cache: true,
        });
    }
}

/**
 * 针对于地址编辑根据zipcode获取巴西等国家信息
 *
 */
export const serviceGetBrazilCode = new Service({
    method: 'jsonp',
    url: `${DOMAIN_USER}/get-brazil-code`,
    errorPop: false,
    loading: true,
});

/*
 * 更新领券已领取状态（用于解决CDN缓存）
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=30474848
 */
export const serviceCouponUpdateInfo = new Service({
    loading: false,
    method: 'jsonp',
    url: `${DOMAIN_USER}/coupon/info`,
});

/**
 * 一键购
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=29822942
 */
export const serviceCartEasyBuy = new Service({
    method: 'POST',
    url: '/cart/buy',
    errorPop: false,
    loading: true,
});

/**
 * 店铺收藏
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=29822942
 */
export const serviceStoreCollect = new Service({
    method: 'POST',
    url: '/user/store-collect',
});

// 视频列表
export const serviceVideoList = new Service({
    method: 'jsonp',
    cache: true,
    url: `${DOMAIN_MAIN}/get-cat-video`,
});

// 视频详情
export const serviceVideoDetail = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/get-video-detail`,
});

// 视频点赞
export const serviceVideoLike = new Service({
    method: 'POST',
    url: '/video/like',
});

// 收藏
export const serviceVideoFavAdd = new Service({
    method: 'POST',
    url: '/goods/add-fav',
});

// 错误搜集
export const serviceReportError = new Service({
    method: 'POST',
    url: '/error/report',
    loading: false,
    errorPop: false,
});

// 获取默认国家和币种
export const serviceCurrencyInfo = new Service({
    method: 'jsonp',
    loading: false,
    cache: true,
    url: `${DOMAIN_MAIN}/currency/info`,
});

// 获取当前cdn国家代码
export const serviceCurrentCountry = new Service({
    method: 'jsonp',
    loading: false,
    cache: true,
    usePreResult: true,
    url: `${curCDN}/current_country`,
});

// 根据IP请求广告位
export const serviceIPBanner = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    cache: true,
    url: `${DOMAIN_MAIN}/async/region/banner`,
});

// 广告落地页请求更多数据
export const serviceLandingPage = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    url: `${DOMAIN_MAIN}/ads-landing-page/picked-goods`,
});

// 搜索框暗文推荐
export const serviceGetDark = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    cache: true,
    url: `${DOMAIN_MAIN}/get-dark`,
});

// 首页定金膨胀弹框
export const serviceDepositRemind = new Service({
    method: 'jsonp',
    loading: false,
    errorPop: false,
    url: `${DOMAIN_MAIN}/get-deposit-remind`,
});

// bts abTest 分流
export const serviceBtsABtest = new Service({
    method: 'post',
    loading: false,
    errorPop: false,
    // url: 'http://35.175.15.99:9086/gateway/shunt', // 测试环境
    url: 'https://api-bts.logsss.com/gateway/shunt', // 正式环境
});

// GB前端性能数据上报接口
export const servicePerformance = new Service({
    method: 'POST',
    loading: false,
    errorPop: false,
    isCancel: false,
    withCredentials: false,
    url: 'https://cloudmonitor.glosop.com/',
    headers: {
        'Content-Type': 'application/json',
        'x-akamai-receipt': 'GB-PERFORMANCE'
    },
    transformRequest(bodyData, headers) {
        // https://github.com/axios/axios/issues/382
        const tempHeaders = headers;
        delete tempHeaders.common['X-CSRF-TOKEN'];
        delete tempHeaders.common['X-Requested-With'];
        return bodyData;
    },
});
