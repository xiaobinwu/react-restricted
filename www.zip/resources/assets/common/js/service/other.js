/**
 * Created by Liu.Jun on 2018/4/24.
 */

// 对外系统的 ，比如大数据
import { getCdnCountryCode } from 'js/core/currency.js';
import { getUserId } from 'js/core/user/getUserId.js';
import Service from '../http/service';

/**
 * 大数据推荐位相关, 所有推荐数据处理都在这个文件里
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=35196617
 */
const FUN = 'gb-recommend-service';
const pipelinecode = window.GLOBAL.PIPELINE;
const lang = window.GLOBAL.LANG;
const isGlobale = (pipelinecode === 'GB');
const defaultSku = '99999999999';
const sid = getUserId();

function getGoodsUrl(url) {
    const { DOMAIN_GOODS_IMAGE } = window.GLOBAL;
    if (url.indexOf('http') === 0) {
        return url;
    }
    return `${DOMAIN_GOODS_IMAGE}/${url}`;
}

function transformData(res) {
    const { DOMAIN_MAIN, DOMAIN_USER } = window.GLOBAL;
    if (res instanceof Array) {
        res.forEach((item) => {
            item.avgRate = item.avgrate;
            item.displayPrice = item.displayprice;
            item.favoriteCount = item.favoritecount;
            item.goodsImage = getGoodsUrl(item.imgurl);
            item.goodImg = item.goodsImage;
            item.goodsNum = item.goodsnum;
            item.goodSn = item.good_sn;
            item.goodsSn = item.good_sn;
            item.goodsTitle = item.goodstitle;
            item.goodTitle = item.goodstitle;
            item.goodsUrl = `${DOMAIN_MAIN}${item.url_title}?wid=${item.warecode}`;
            item.linkUrl = item.goodsUrl;
            item.gridUrl = getGoodsUrl(item.gridurl);
            item.reviewCount = item.reviewcount;
            item.reviewLink = `${DOMAIN_USER}/index#/review/list`;
            item.shopPrice = item.shopprice;
            item.thumbExtendUrl = getGoodsUrl(item.thumbextendurl);
            item.thumbUrl = getGoodsUrl(item.thumburl);
            item.warehouseCode = item.warecode;
            item.wareCode = item.warecode;
            item.webGoodSn = item.webgoodsn;
        });
    }
    return res;
}

function qs(obj) {
    const reData = JSON.parse(JSON.stringify(obj));
    if (reData.params) {
        reData.params = JSON.stringify(reData.params);
    }
    return Object.entries(reData).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`).join('&');
}

async function mergeData(data) {
    const cdnCountry = await getCdnCountryCode();
    const options = {
        params: {
            lang,
            pipelinecode,
            cookie: sid,

            platform: 'PC',
            regioncode: cdnCountry
        },
        recommendType: '1010101',
        fun: FUN,
    };
    if (data && data.params) {
        data.params = Object.assign(options.params, data.params);
    }

    return Object.assign(options, data);
}

function reDataFn(data) {
    return recommendHttp.http({
        data: qs(data),
    }).then((res) => {
        if (res.status === 1) {
            res.status = 0;
            res.data = transformData(res.result);
            delete res.result;
        } else {
            res.status = -1;
        }
        return res;
    });
}

export const recommendHttp = new Service({
    method: 'POST',
    errorPop: false,
    isCancel: false,
    loading: false,
    Headers: {
        'Content-type': 'application/x-www-form-urlencoded'
    },
    url: window.GLOBAL.BIGDATA_URL,
    transformRequest(bodyData, headers) {
        // https://github.com/axios/axios/issues/382
        const tempHeaders = headers;
        delete tempHeaders.common['X-CSRF-TOKEN'];
        delete tempHeaders.common['X-Requested-With'];
        return bodyData;
    }
});


// 首页推荐位
// 全球站： 首页推荐
// 国家站：商详的第一个推荐位
export async function getIndexRecommend(args) {
    const data = await mergeData(args);
    if (isGlobale) {
        data.recommendType = 1010101;
    } else {
        data.params.storeid = '';
        data.recommendType = 1020101;
    }
    data.params.sku = data.params.sku || defaultSku;

    return new Promise(async (resolve, reject) => {
        // 大数据
        const recommendData = recommendHttp.http({
            data: qs(data)
        });

        try {
            const { status, result } = await recommendData;
            const returnData = {};
            if (status === 1) {
                returnData.status = 0;
                returnData.data = {
                    related: transformData(result),
                };
            } else {
                returnData.status = -1;
            }
            resolve(returnData);
        } catch (e) {
            reject();
        }
    });
}

export async function getGoodsRecommend(args) {
    const data = await mergeData({
        params: {
            sku: args && args.params ? args.params.goodSn : defaultSku,
            categoryid: args && args.params && args.params.categoryid
        }
    });

    const type = args && args.params ? +args.params.type : 1;
    const typeCfg = {
        1: 1020101,
        2: 1020201,
        3: 1020301,
        4: 1020102,
    };
    data.recommendType = typeCfg[type];

    // // 非全球站 后两个接口返回空
    // if (!isGlobale) {
    //     if (type !== 1) {
    //         return Promise.reject();
    //     }
    // }

    return reDataFn(data);
}

// you also like 推荐位
export async function getULike(args) {
    const data = await mergeData({
        params: {
            ...args.params
        },
        recommendType: args.recommendType
    });

    return reDataFn(data);
}

// 首页获取推荐商品-无限加载
export async function getIndexRecommendInfinite(config) {
    const curDefaultParams = {
        pageindex: 0,
        pagesize: 30,
        ortherparams: {}
    };

    const options = await mergeData({
        params: {
            ...curDefaultParams,
            ...config
        },
        recommendType: 1010103
    });

    return reDataFn(options);
}
