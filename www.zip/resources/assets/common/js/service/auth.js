/**
 * @Desc: 登录注册权限验证相关接口
 * @Author: luochongfei
 * @Date: 2018-03-28 11:11:44
 */

import Service from '../http/service';

const { DOMAIN_LOGIN } = window.GLOBAL || {};

/**
 * 登录
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=30477770
 */
export const serviceLogin = new Service({
    method: 'POST',
    errorPop: false,
    url: '/user/login',
});

/**
 * 第三方登录
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31785468
 */
export const serviceUserSocial = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/user/social',
});

/**
 * 注册时检查账号是否已存在
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31788386
 */
export const serviceCheckEmailExist = new Service({
    method: 'jsonp',
    errorPop: false,
    loading: true,
    url: `${DOMAIN_LOGIN}/check-email-exist`,
});

/**
 * 注册
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=30477364
 */
export const serviceRegister = new Service({
    method: 'POST',
    errorPop: false,
    loading: true,
    url: '/user/register',
});

/**
 * 发送激活邮件
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31098068
 */
export const serviceActivationEmail = new Service({
    method: 'POST',
    loading: true,
    url: '/user/register/send-activation-email',
});

/**
 * 发送忘记密码邮件
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=34705222
 */
export const serviceConfirmIdentity = new Service({
    method: 'POST',
    loading: true,
    url: '/user/confirm-identity',
});

/**
 * 重置密码（无需旧密码）
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=34705274
 */
export const serviceResetPassword = new Service({
    method: 'POST',
    loading: true,
    url: '/user/reset-password',
});

/**
 * 第三账号手动绑定
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=38505792
 */
export const servicebindSocial = new Service({
    method: 'post',
    url: '/user/bind-social',
    errorPop: false,
    loading: true,
});

/**
 * 第三方登录， 获取联登地址(修改)
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31785468
 */
export const serviceSocialLoginUrl = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/login-url',
});

/**
 * 执行第三方登录(修改)
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31785468
 */
export const serviceSocialLogin = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/login',
});

/**
 * 绑定第三方(修改)
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31785468
 */
export const serviceSocialBind = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/bind',
});

/**
 * 检查第三方是否已经绑定(修改)
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=31785468
 */
export const serviceSocialCheck = new Service({
    method: 'post',
    loading: true,
    errorPop: false,
    url: '/social/check',
});

/**
 * 检查第三方是否已经绑定(修改)
 *
 */
export const serviceSocialTypeList = new Service({
    method: 'get',
    loading: false,
    errorPop: false,
    url: '/social/type-list',
});

/**
 * 获取是否欧盟
 *
 */
export const servicePassportInit = new Service({
    method: 'get',
    loading: true,
    errorPop: false,
    url: '/passport/init',
});

/**
 * 设置 fcm token
 */
export const serviceSetToken = new Service({
    method: 'POST',
    loading: false,
    errorPop: false,
    url: '/user/push-fcm',
});
