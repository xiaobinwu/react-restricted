import Service from '../http/service';

const { DOMAIN_MAIN } = GLOBAL;

// ***********营销页面公共接口 (GMT+8 2018-03-26 16:30:20)************
// Deals频道添加点赞接口
export const serviceDealsAddlikes = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/deals/add-likes`,
    errorPop: false,
    loading: true,
});

// Deals频道取消点赞接口
export const serviceDealsDeletelikes = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/deals/delete-likes`,
    errorPop: false,
    loading: true,
});

// Deals频是否点赞过接口
export const serviceDealsUserlikes = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/deals/get-user-likes-lists`,
    errorPop: false,
    loading: true,
});

// Explore-频道数据接口
export const serviceExploreData = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/explore/explore-data`,
    errorPop: false,
    cache: true,
    loading: true,
});

// Zone Deals 0.99-频道数据接口
export const serviceZoneData = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/zone-deals-list`,
    cache: true,
    errorPop: false,
    loading: true,
});

// 分享送积分
export const serviceShareGetScore = new Service({
    method: 'POST',
    url: '/activity/special/share-point',
});

// 品牌页hot product
export const serviceBrandHot = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/top-brands/brand/ajax-hot-sale`,
});

// 凑单购物车加车判断
export const serviceAddonJudge = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/compose-good/cart-activity-info`,
});

// 凑单页数据
export const serviceAddonCompose = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/compose-good/load-page`,
    cache: true,
});

// 新手是否领取了coupon礼包
export const serviceNewUserIsGetCoupon = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/activity/new-shopping-guide/is-got-coupon`,
    useLocalCache: 60 * 5
});

// 订单抽奖
export const serviceOrderLottery = new Service({
    url: `${DOMAIN_MAIN}/activity/lottery/raffle`,
    method: 'post',
});

// 获取用户中奖列表
export const serviceGetPrizeList = new Service({
    method: 'jsonp',
    url: '/activity/get-lottery-prize-list',
    cache: true,
});

// 预约提醒
export const servicePromotionRemind = new Service({
    method: 'post',
    url: `${DOMAIN_MAIN}/activity/special/reservation`
});

// 新手导购配券商品列表根据用户返回
export function serviceUserCouponGoods() {
    return new Service({
        url: `${DOMAIN_MAIN}/activity/new-shopping-guide/user-data`,
    });
}

// 获取中奖奖品
export const serviceRedRainRaffle = new Service({
    url: `${DOMAIN_MAIN}/activity/lottery/red-rain-raffle`,
    method: 'post',
    errorPop: false,
    loading: false,
});

// 检查是否已玩过
export const serviceRedRainHasPlay = new Service({
    url: `${DOMAIN_MAIN}/activity/lottery/red-rain-check`,
    method: 'post',
    errorPop: false,
    loading: false,
});

// 整好点秒杀页面分类页获取商品
export const serviceFlashSaleGoods = new Service({
    method: 'get',
    errorPop: true,
    loading: false,
    cache: true,
});

// 品牌升级new-频道数据接口
export const serviceGetNewProducts = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/get-new-products/`,
    cache: true,
    errorPop: false,
    loading: true,
});

// 整点秒杀页面场次获取商品
export const serviceFlashSaleSceneGoods = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/get-scene-goods`,
    errorPop: true,
    loading: true,
    cache: true,
});
