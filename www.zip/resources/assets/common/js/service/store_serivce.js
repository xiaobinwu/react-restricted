import Service from '../http/service';

const { DOMAIN_MAIN } = GLOBAL;

// 店铺首页数据接口
export const serviceStoreCollect = new Service({
    method: 'POST',
    url: '/user/store-collect',
    errorPop: false,
    loading: false,
});

// 店铺首页数据接口
export const serviceStoreData = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/store/list`,
    errorPop: false,
    loading: true,
});

// 店铺首页版块数据接口(Window Data Interface)
export const serviceStoreBlockData = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/store/windows-goods`,
    errorPop: false,
    loading: true,
});

// 店铺首页活动商品数据接口
export const serviceStoreActiveData = new Service({
    method: 'jsonp',
    url: `${DOMAIN_MAIN}/store/get-activity-goods`,
    errorPop: false,
    loading: true,
});
