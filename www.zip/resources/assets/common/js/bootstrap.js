import 'gbpolyfill';
import 'js/polyfill';
import 'jquery';
import 'js/event/event.dom';
import 'js/event/event.sys';
import 'mutationobserver-shim';

import Cookies from 'js/utils/cookie';
import { getUrlQuery } from 'js/utils/index';
import PubSub from 'pubsub-js';
import asyncPricePromise from 'js/core/goods/asyncPricePromise.js';
import { installment } from 'js/core/goods/installment.js';
import { COOKIE_LANG, COOKIE_PIPELINE } from 'js/variables';

// 全站基础css + 字体
import 'css/bootstrap.css';
import 'common/icon/syncGlobal/iconfont.css';

// lib css 导入, 避免产生多余css 文件（polyfill_lib.css）
import 'lib/simple-scrollbar/simple-scrollbar.css';
import 'lib/layer/theme/default/layer.css';
import 'lib/layer/custom.css';

const { PIPELINE } = window.GLOBAL;

// 判断渠道是否变更
const cookies = Cookies.get();

const oldPipeline = cookies[COOKIE_PIPELINE];
window.GLOBAL.FE_PIPELINE_IS_CHANGE = (oldPipeline !== undefined) && (oldPipeline !== PIPELINE);

// 获取默认和设置默认的语言和国家渠道
Cookies.set(COOKIE_LANG, GLOBAL.LANG);
Cookies.set(COOKIE_PIPELINE, GLOBAL.PIPELINE);

// 为防止丢失linkid，提前写cookie
setTimeout(() => {
    const { lkid, vip } = getUrlQuery();
    const linkid = vip || lkid;
    if (linkid) {
        Cookies.set('linkid', linkid, {
            domain: window.GLOBAL.DOMAIN_COOKIE,
            expires: 30
        });
    }
}, 0);

// 图片懒加载
PubSub.publish('sysInitLazyload');

/**
 * 在获取实时价格之后
 * 执行巴西墨西哥分期付款脚本
 */
asyncPricePromise.then(() => {
    installment();
});

PubSub.subscribe('nativeReady', () => {
    // 错误反馈
    $('.js_feedback').mouseenter(async () => {
        const FeedBack = (await import('component/feedback/feedback.js')).default;
        FeedBack.bindEvent();
    });
});

PubSub.subscribe('nativeLoad', async () => {
    const { default: asyncBootstrap } = await import('./asyncBootstrap.js');
    asyncBootstrap();
});
