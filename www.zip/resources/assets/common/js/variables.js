/**
 * 全局公共JS变量
 */

const COOKIE_LANG = 'gb_lang';
const COOKIE_PIPELINE = 'gb_pipeline';
const COOKIE_CURRENCY_CODE = 'gb_currencyCode';
const COOKIE_COUNTRY_CODE = 'gb_countryCode';
const COOKIE_UID = 'guid';
const COOKIE_CDN_COUNTRYCODE = 'cdn_countryCode';
const COOKIE_USERINFO = 'gb_userinfo';
const COOKIE_IS_VIEW = 'gb_isView';
const COOKIE_HAVE_OLD_USER = 'gb_haveOldUser'; // 前端使用，跨域传递值
const COOKIE_IS_NEW_USER = 'gb_isNewUser'; // 前端使用，跨域传递值
const COOKIE_CATEGORY_AB = 'gb_categoryAB'; // 前端使用，分类abtest副本标识
const COOKIE_SEARCH_AB = 'gb_searchAB'; // 前端使用，搜索abtest副本标识
const COOKIE_TEST_COOKIE_ID = 'gb_testCookieId'; // 前端使用，测试环境没有AKMANID，前端自己生成使用，仅测试环境
const COOKIE_FCM = 'gb_fcm'; // 前端使用，fcm request状态 (core/firebse/main.js)
const COOKIE_FCM_TOKEN = 'gb_fcmtoken'; // 前端使用，当前fcm token
const COOKIE_FCM_PIPELINE = 'gb_fcmPipeLine'; // 前端使用，判断国家站是否有push过token

const STORAGE_LOGIN = 'gb_isLogin';
const STORAGE_REGOODS = 'gb_reGoods';
const STORAGE_APPAREL = 'gb_apparel';
const STORAGE_FIRST_VIEW = 'gb_firstView';
const STORAGE_SEARCH_HISTORY = 'gb_searchHistory';
const STORAGE_GOODS_VIEW_HISTORY = 'gb_goodsViewHistory';
const STORAGE_DEALS_NODE_ITEM = 'gb_dealsNodeItem';
const STORAGE_EXPLORE_NODE_DATA_ID = 'gb_exploreNodeDataId';
const STORAGE_EXPLORE_NODE = 'gb_exploreNode';
const STORAGE_ZONE_CATE_NAV = 'gb_zoneCateNav';
const STORAGE_ZONE_DEALS_NODE = 'gb_zoneDealsNode';
const STORAGE_SAVE_EO = 'gb_saveEo';
const STORAGE_SITE_BANNER_CLOSE = 'gb_siteBannerClose';
const STORAGE_REVIEW_NICK_NAME = 'gb_reviewNickName';
const STORAGE_INDEX_TOP_BANNER_ID = 'gb_indexTopBannerId';
const STORAGE_COOKIE_POLICY = 'gb_cookiePolicy';
const STORAGE_RECORD_TO_GOODS = 'gb_recordToGoods';
const STORAGE_VIP_CENTER = 'gb_vipCenter';
const STORAGE_GIFT_TYPE = 'gb_giftType';
const STORAGE_SOURCE_BTS = 'gb_sourceBTS';
const STORAGE_GOODS_REDIRECT_LINK = 'gb_goodsRedirectLink';
const STORAGE_NAV_SEARCH = 'gb_navSearch';
const STORAGE_SOURCE_ORIGIN = 'gb_sourceOrigin';

const XD_STORAGE_ORIGIN = window.GLOBAL.DOMAIN_MAIN; // 跨域storage储存域名
const XD_STORAGE_PATH = '/cross-storage.html'; // 跨域storage储存地址
const XD_STORAGE_SERVICEINFO = 'serviceInfo';
const STORAGE_GOOGLE_TRANSLATE = 'gb_googleTranslate';
const STORAGE_MESSAGE_INFO = 'messageInfo'; // 站内信信息
const STORAGE_BTS_CATEENTRY = 'gb_btsCateEntry'; // 分类页入口abtest bts
const STORAGE_BTS_SEARCHENTRY = 'gb_btsSearchEntry'; // 搜索页入口abtest bts

export {
    COOKIE_LANG,
    COOKIE_PIPELINE,
    COOKIE_CURRENCY_CODE,
    COOKIE_COUNTRY_CODE,
    COOKIE_UID,
    COOKIE_CDN_COUNTRYCODE,
    COOKIE_USERINFO,
    COOKIE_IS_VIEW,
    COOKIE_HAVE_OLD_USER,
    COOKIE_IS_NEW_USER,
    COOKIE_CATEGORY_AB,
    COOKIE_SEARCH_AB,
    COOKIE_TEST_COOKIE_ID,
    COOKIE_FCM,
    COOKIE_FCM_TOKEN,
    COOKIE_FCM_PIPELINE,

    STORAGE_FIRST_VIEW,
    STORAGE_APPAREL,
    STORAGE_REGOODS,
    STORAGE_LOGIN,
    STORAGE_SEARCH_HISTORY,
    STORAGE_GOODS_VIEW_HISTORY,
    STORAGE_DEALS_NODE_ITEM,
    STORAGE_EXPLORE_NODE_DATA_ID,
    STORAGE_EXPLORE_NODE,
    STORAGE_ZONE_CATE_NAV,
    STORAGE_ZONE_DEALS_NODE,
    STORAGE_SAVE_EO,
    STORAGE_SITE_BANNER_CLOSE,
    STORAGE_REVIEW_NICK_NAME,
    STORAGE_INDEX_TOP_BANNER_ID,
    STORAGE_RECORD_TO_GOODS,
    STORAGE_VIP_CENTER,
    STORAGE_GIFT_TYPE,
    STORAGE_SOURCE_BTS,
    STORAGE_GOODS_REDIRECT_LINK,
    STORAGE_NAV_SEARCH,
    STORAGE_SOURCE_ORIGIN,

    XD_STORAGE_ORIGIN,
    XD_STORAGE_PATH,
    XD_STORAGE_SERVICEINFO,
    STORAGE_GOOGLE_TRANSLATE,
    STORAGE_COOKIE_POLICY,
    STORAGE_MESSAGE_INFO,
    STORAGE_BTS_CATEENTRY,
    STORAGE_BTS_SEARCHENTRY,
};
