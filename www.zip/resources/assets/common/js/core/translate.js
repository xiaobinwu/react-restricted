/**
 * Created by Liu.Jun on 2018/2/26.
 */

// 翻译未提供前可以直接使用本地lang 方便开发 不用反复提取key

let langs;

const hasOwn = Object.prototype.hasOwnProperty;

/**
 * 合并开发文件到 全局 LANGUAGE
 * @returns {*}
 */
export default function initLangs() {
    if (langs) return langs;

    const LANG = window.LANGUAGE;

    if (process.env.LANG_ENV === 'dev') {
        langs = require('../tempLang/index').default;  // eslint-disable-line
        for (const langModule in LANG) {
            if (hasOwn.call(LANG, langModule)) {
                LANG[langModule] = Object.assign({}, langs[langModule], LANG[langModule]);
            }
        }
    }
    // 合并活动页 特殊语言文件
    if (window.promotionLang) Object.assign(LANG.promotion, window.promotionLang);

    langs = LANG || langs;

    // 不能直接引用 window.LANGUAGE
    window.LANGUAGE = null;

    return langs;
}

/**
 *
 * @param format
 * @param params
 * @returns {*}
 */
export function langFormat(format, params = []) {
    let str = format;
    params.forEach((item, index) => {
        str = str.replace(`:#$${index + 1}#`, item);
    });
    return str;
}


/**
 *
 * @param moduleKey
 * @param params
 * @returns {*}
 */
export function trans(moduleKey, params) {
    const curLangs = initLangs();
    const [moduleName, key] = moduleKey.split('.');
    let str = curLangs[moduleName] && curLangs[moduleName][key];
    if (str) {
        if (params) {
            str = langFormat(str, params);
        }
        return str;
    }

    // 上报数据
    // setTimeout(() => {
    //     const img = new Image();
    //     const statParams = {
    //         page: window.location.href,
    //         module: moduleName,
    //         platform: 'pc',
    //         lang: window.GLOBAL.LANG,
    //         key,
    //     };
    //     const urlParams = Object.entries(statParams).map(([pKey, pValue]) => `${pKey}=${encodeURIComponent(pValue)}`).join('&');
    //     img.src = `//qatool.gearbest.net/Api/getMultilingualInfo/?${urlParams}`;
    // });
    return moduleKey;
}
