/**
 * Created by Liu.Jun on 2018/9/5.
 */

/**
 * 获取静态文件路径
 * @param url
 * @returns {string}
 */

function staticAsset(url) {
    const domainStatic = window.GLOBAL && window.GLOBAL.DOMAIN_STATIC ? window.GLOBAL.DOMAIN_STATIC : '';
    return `${domainStatic}${url}`;
}

export default staticAsset;
