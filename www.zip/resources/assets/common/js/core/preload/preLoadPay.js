/**
 * Created by Liu.Jun on 2018/11/12.
 * 预加载支付平台
 */

import PubSub from 'pubsub-js';
import preload from 'js/core/preload/preload.js';
import Service from 'js/http/service';

const locationOrigin = window.location.host.includes(window.GLOBAL.TOP_DOMAIN) ?
    window.GLOBAL.DOMAIN_CASHIER : window.GLOBAL.DOMAIN_CASHIER_TEST;
const exclude = 'm.';

function loadPayScript() {
    setTimeout(async () => {
        const serviceUserStatus = new Service({
            url: `${locationOrigin}/filelist.js`,
            errorPop: false,
            loading: false,
            cache: true,
            jsonpCallback: '_getPayManifest'
        });

        const res = await serviceUserStatus.http({
            params: {
                _: +new Date()
            }
        });

        if (res && Array.isArray(res)) {
            const preList = res.filter(item => !item.includes(exclude)).map(item => `${locationOrigin}${item}`);
            preload(preList);
        }
    }, 1000);
}


export default () => {
    // load 后预加载
    PubSub.subscribe('nativeLoad', () => {
        loadPayScript();
    });

    // 手动 load
    if (document.readyState === 'complete') loadPayScript();
};
