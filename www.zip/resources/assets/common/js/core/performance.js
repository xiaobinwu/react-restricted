/**
 * 前端性能上报（应用层）
 * Created by Jiazhan Li on 2018/11/26.
 */
import { getCdnCountryCode } from 'js/core/currency.js';
import { servicePerformance } from 'js/service/common';
import Performance from './gb-performance.js';

const {
    PIPELINE,
    LANG,
} = window.GLOBAL || {};

const {
    on = true,
    rate = 0.001, // 100%抽样，测试用
} = window.PERFORMANCE || {};

export default async () => {
    const cdnCountryCode = await getCdnCountryCode();

    // 前端性能上报脚本初始化
    Performance.init({
        // 修改配置项（后台控制）
        config: {
            on,
            rate,
            interval: 0, // 只上报调用那一刻的数据
            size: 0, // 不限制大小
            rules: [{
                name(str) {
                    if (process.env.PACK_ENV === 'prod') {
                        // 针对线上或者预发布环境：页面文档、请求接口、静态资源（js，css）
                        return /^[^?]*?\.gearbest\./.test(str) || /css\.gbtcdn\.com\/imagecache.+\.(js|css)/.test(str);
                    }
                    // 针对测试环境（排除图片，字体）
                    return /^[^?]*?\.gearbest\./.test(str) && !/.*\.(jpg|jpeg|png|gif|svg|ico|woff2?|eot|ttf|otf)/.test(str);
                }
            }],
            service(data) {
                try {
                    servicePerformance.http({
                        data: JSON.stringify(data),
                    });
                } catch (e) {
                    // 这样比较稳！
                }
            },
        },

        // 扩展上报数据
        data: {
            platform: 'pc',
            pipeline: PIPELINE,
            country: cdnCountryCode,
            lang: LANG,
            other: '',
        },
    });
};
