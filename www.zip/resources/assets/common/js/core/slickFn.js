import 'slick-carousel';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { lazySuccess, lazyError } from 'js/utils/lazyload.js';

/**
 *  slick 插件增加一个懒加载图片的loading 和 事件监听机制
 * @param {
 *  container: 选择器，
 *  ... option， slick插件的默认参数，
 *  }
 *  <img data-lazy="">  data-lazy 为懒加载的图片地址
 *  还需要在 img 的父元素的class加上icon-loading，且为第一个class名称
 */

function slickRemoveLoading(slider, source) {
    [...slider].forEach((item) => {
        const img = item.querySelectorAll('img');
        if (img.length) {
            [...img].forEach((el) => {
                if (el && (el.src === source || el.dataset.lazy === source)) {
                    lazySuccess(el);
                }
            });
        }
    });
}
function slickFn({
    container, // 容器
    ...options
}) {
    const $slickList = $(container).children();
    $slickList.each((index, value) => {
        $(value).attr('data-true-index', index);
    });

    const deOptions = {
        lazyLoad: $slickList.length > 2 ? 'ondemand' : 'progressive',
        draggable: false,
    };
    return $(container).slick({
        ...deOptions,
        ...options,
    }).on('lazyLoaded', (e, slick, curImg, imgSource) => {
        slickRemoveLoading(slick.$slideTrack[0].childNodes, imgSource);
    }).on('lazyLoadError', (el, slick, curImg, curImgSource) => {
        lazyError(curImg[0]);
    });
}

export { slickFn };
