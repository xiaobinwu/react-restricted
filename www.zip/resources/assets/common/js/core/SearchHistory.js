/**
 * Created by Liu.Jun on 2018/9/4.
 */

import { STORAGE_SEARCH_HISTORY } from 'js/variables';


const MAX_SEARCH_HISTORY_LENGTH = 5;

/**
 * 搜索记录的类
 */
class SearchHistory {
    static get() {
        return JSON.parse(window.localStorage.getItem(STORAGE_SEARCH_HISTORY) || '[]');
    }
    static set(val) {
        const newVal = SearchHistory.filter(val);
        const data = SearchHistory.get();
        const len = data.length;
        if (len > 0) {
            const first = data[0];
            if (val.toLowerCase() !== first.toLowerCase()) {
                if (len === MAX_SEARCH_HISTORY_LENGTH) {
                    data.pop();
                }
                data.unshift(newVal);
            }
        } else {
            data.unshift(newVal);
        }
        window.localStorage.setItem(STORAGE_SEARCH_HISTORY, JSON.stringify(data));
    }
    static remove(val) {
        const data = SearchHistory.get();
        const index = data.indexOf(val);
        data.splice(index, 1);
        window.localStorage.setItem(STORAGE_SEARCH_HISTORY, JSON.stringify(data));
        return data.length;
    }
    static removeAll() {
        window.localStorage.removeItem(STORAGE_SEARCH_HISTORY);
    }
    static filter(val) {
        return val.replace(/<[^>]+>/g, '');
    }
}

export default SearchHistory;
