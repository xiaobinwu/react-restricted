/**
 *  用户业务逻辑相关的方法
 */
import $ from 'jquery';
import Base64 from 'base-64';
import { STORAGE_LOGIN, COOKIE_USERINFO } from 'js/variables';
import { serviceUserStatus } from 'js/service/common.js';
import Cookies from 'js/utils/cookie';

let userInfo;

const { DOMAIN_LOGIN } = GLOBAL;

/* 获取用户登录状态/自动处理跳转到登录页（状态会被缓存）
 * @param update   强制重新请求(默认关闭)
 * @param toLogin  是否自动登录(默认开启)
*/

function cleverestPromise(promise) {
    let oncePromise;
    return async (...args) => {
        if (!oncePromise) {
            oncePromise = promise.apply(this, args);
        }
        return oncePromise;
    };
}
async function getServiceStatus() {
    await serviceUserStatus.http();
}
const changePipeline = cleverestPromise(getServiceStatus);

async function getUserStatus({ update = 0, toLogin = 1 } = {}) {

    // window.GLOBAL.FE_PIPELINE_IS_CHANGE 变量 切勿放到上面解构
    if (window.GLOBAL.FE_PIPELINE_IS_CHANGE) { // 切换了渠道，重新让服务端写用户信息cookie
        await changePipeline();
    }

    if (undefined === userInfo || update) {
        const userInfoCookie = Cookies.get(COOKIE_USERINFO);

        let errorFlag;
        if (userInfoCookie) {
            try {
                const data = JSON.parse(Base64.decode(decodeURIComponent(userInfoCookie)));
                if (data) {
                    userInfo = data;
                } else {
                    errorFlag = 1;
                }
            } catch (error) {
                errorFlag = 1;
            }
        } else {
            errorFlag = 1;
        }
        if (errorFlag) {
            return {};
        }
    }
    if (toLogin && !userInfo.isLogin) {
        window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm`;
        return false;
    }
    return userInfo;
}

function setUpgradeUserInfo(data) {
    // 购物车数量
    const cartCount = 'cartCount' in data ? data.cartCount : 0;
    $('.js-cartNum').text(cartCount);
    // if (+cartCount < 1) {
    //     $('#js-labelHeadCart').removeClass('hoverShow');
    // }

    // 收藏数量

    const $collectNum = $('.js-collectNum');

    let collectNum = data.collect;

    if (+$collectNum.data('type') === 2) {
        if (collectNum && +collectNum > 99) {
            collectNum = '99+';
        }
    }

    $collectNum.text(collectNum || '0');

    if (Number(data.ticketCount) > 0) {
        $('.js-siteHeader-ticketNum').show().text(`(${data.ticketCount})`);
        $('.js-unread-tickets').show().text(data.ticketCount);
    }

    if (data && data.isLogin) {
        const account = data.user.userName || data.user.email;
        $('.js-labelUserName').text(`${account}`);
        $('#js-panelUserInfo').attr('data-login', 1);
    }
}

async function updateHeaderUserInfo() {
    const data = await getUserStatus({ update: 1, toLogin: 0 });
    if (!data.user) {
        return;
    }
    window.sessionStorage.setItem(STORAGE_LOGIN, `${data.user.userName || data.user.email}`);
    setUpgradeUserInfo(data);
}


/**
 * 判断是否登录
 * return true || false
 */
async function isLogin() {
    const userData = await getUserStatus({
        toLogin: 0
    });
    return userData.isLogin || false;
}

export {
    getUserStatus,
    updateHeaderUserInfo,
    isLogin,
};
