/**
 * 播放视频弹窗
 * @param {*视频码} videoUri 支持多个以逗号分隔
 */
import layer from 'layer';

function videoPlay(videoUri, config) {
    let video = videoUri.trim().split(',');
    if (video.length > 1) {
        video = parseInt(Math.random() * video.length, 10);
    } else {
        video = video['0'];
    }

    const cfg = config || {};

    if (cfg.inline === true && cfg.ele && cfg.ele.length) {
        cfg.ele.html(`
            <iframe src="https://www.youtube.com/embed/${video}?autoplay=1" frameborder="0" width="854" height="480"></iframe>
        `);
    } else {
        layer.open({
            content: `
                <iframe src="https://www.youtube.com/embed/${video}?autoplay=0" frameborder="0" width="100%" height="440"></iframe>`,
            area: '894px',
            closeBtn: true,
            btn: false,
        });
    }


    return {};
}

export default videoPlay;
