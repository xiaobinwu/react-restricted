import { getTimezone } from 'js/utils/index.js';
import { serviceMessageCount } from 'js/service/user';
import { getUserStatus } from 'js/core/user.js';
import Cookies from 'js/utils/cookie';
import { COOKIE_USERINFO } from 'js/variables';
import Base64 from 'base-64';
import RecordMessageInfo from 'js/core/RecordMessageInfo.js'; // 记录站内信总数

let promise = null;
export default async (headElem, usueElem) => {
    const userStatus = await getUserStatus({ update: 1, toLogin: 0 });
    if (userStatus.isLogin) {
        let expireTime = null;
        try {
            const userInfoCookie = Cookies.get(COOKIE_USERINFO);
            const userInfoData = JSON.parse(Base64.decode(decodeURIComponent(userInfoCookie)));
            expireTime = userInfoData.siteMessageTimeInterval > 0 ? userInfoData.siteMessageTimeInterval : 60;
        } catch (err) {
            expireTime = 60; // 当取不到Cookies时，设localStorage失效时间为默认1分钟
        }
        if (!promise) {
            promise = new Promise(async (resolve) => {
                const nowTime = Number(new Date());
                const { messageQty, messageTime } = await RecordMessageInfo.get();
                if (messageTime && nowTime - messageTime < 1000 * expireTime) {
                    resolve(messageQty || 0);
                } else {
                    const { status, data } = await serviceMessageCount.http({ params: { time_zone_id: getTimezone() } });
                    if (status === 0) {
                        RecordMessageInfo.set(data.num || 0);
                        resolve(data.num || 0);
                    }
                }
            });
        }

        const count = await promise;
        [...headElem].forEach((item) => {
            item.innerHTML = count > 99 ? '99+' : count;
            item.style.visibility = count > 0 ? 'visible' : 'hidden';
        });
        [...usueElem].forEach((item) => {
            item.innerHTML = count > 99 ? '(99+)' : `(${count})`;
            item.style.display = count > 0 ? 'inline-block' : 'none';
        });
    }
};
