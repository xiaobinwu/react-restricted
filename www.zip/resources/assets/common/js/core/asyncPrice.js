/**
 * 异步价格
 * Created by li Jiazhan on 2018/5/9
 */

import { serviceAsyncPrice } from 'js/service/common';
import { updateCurrency } from 'js/core/currency';

/**
 * 用来判断异步价格脚本是否执行完毕
 * @type {boolean}
 */
let isEnd = false;

/**
 * 执行入口
 * @param context       容器（DomElement）
 * @param selector      选择器
 * @param elements      DOM元素列表（NoteList）
 * @param callback      回调函数，参数为 1、target(列表项) 2、price(实际价格)
 * @returns {Promise<*>}
 */
async function asyncPrice({
    context = document,
    selector = '.js-asyncPrice',
    elements = [],
    callback = () => {},
} = {}) {
    const availableElem = []; // 有效元素
    const queryData = []; // 请求参数集合
    const result = [];

    isEnd = false;

    // 以传入的元素列表优先级最高
    if (elements && elements.nodeType === 1) {
        elements = [elements];
    } else if (!elements || !elements.length || elements[0].nodeType !== 1) {
        elements = context.querySelectorAll(selector);
    }

    // 过滤无效元素
    [...elements].forEach((item) => {
        const param = item.dataset.asyncPrice;
        if (/\d+#\w+/.test(param)) {
            availableElem.push(item);
            queryData.push(param);
        }
    });

    if (availableElem.length > 0) {
        try {
            const res = await serviceAsyncPrice.http({
                errorPop: false,
                headers: {
                    'Content-Type': 'application/json'
                },
                transformRequest(bodyData, headers) {
                    // https://github.com/axios/axios/issues/382
                    const tempHeaders = headers;
                    delete tempHeaders.common['X-CSRF-TOKEN'];
                    delete tempHeaders.common['X-Requested-With'];
                    return bodyData;
                },
                data: JSON.stringify({
                    domain: GLOBAL.PIPELINE,
                    accessToken: GLOBAL.ACCESS_TOKEN,
                    version: GLOBAL.ESVERSION,
                    language: GLOBAL.LANG,
                    filters: [{
                        field: 'skuId',
                        values: queryData,
                    }],
                }),
            });

            availableElem.forEach((item, index) => {
                const itemData = res.data[index];
                const { displayPrice } = itemData;

                // 合并抛出数据
                result.push(Object.assign({
                    el: item
                }, itemData));

                if (displayPrice) {
                    item.dataset.currency = displayPrice;
                    callback(item, displayPrice);
                }
            });
        } catch (e) {
            console.error('asyncPrice get fail!');
        }
    }

    isEnd = true;
    updateCurrency();

    // 清除价格加载样式
    [...context.querySelectorAll('.price-loading')].forEach((item) => {
        item.classList.remove('price-loading');
    });

    // 导出元素对应的价格列表数组
    return result;
}

/**
 * 等待异步价格执行完毕后才执行，如果在这之前执行，无效！
 * 主要是为了解决异步加载模块二次渲染币种的问题
 * @param callback
 */
function awaitAsyncPrice(callback) {
    if (isEnd) callback();
}

export {
    asyncPrice,
    awaitAsyncPrice,
};
