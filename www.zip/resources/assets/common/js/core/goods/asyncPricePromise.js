import { asyncPrice } from 'js/core/asyncPrice';

export default asyncPrice();
