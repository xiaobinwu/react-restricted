/**
 * 获取商详基本信息(每次进入商详页面会更新，只能取不能设置)
 * goodsSn: "商品SKU",
 * warehouseCode: "商品仓库码",
 * isVirtual: "是否虚拟仓",
 * shopPrice: "销售价",
 * thumb: "缩略图",
 * shopCode: "店铺码"
 */

export default class GoodsInfo {
    constructor() {
        this.goodsInfo = GoodsInfo.get();
    }
    static get() {
        try {
            const data = window.sessionStorage.getItem('gb_goodsInfo');
            return JSON.parse(data);
        } catch (error) {
            return {};
        }
    }
}

