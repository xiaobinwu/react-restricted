import {
    serviceCollectAdd,
    serviceGoodlistCollectRemove,
    // serviceCollectStatus
} from 'js/service/common.js';

class GoodsCollect {

    /**
     * 单个商品添加收藏
     * @param goodsSn 商品sku
     * @param warehouseCode 商品仓库码
     * @param $effectEl 收藏成功后受影响的Jquery元素
     * @param effectCls 收藏成功后要增加的className
     * @param success 收藏成功
     */
    static async add({
        goodsSn = null,
        warehouseCode = null,
        $effectEl = null,
        effectCls = 'active',
        success = $.noop
    }) {

        if (!goodsSn || !warehouseCode) {
            return false;
        }

        const res = await serviceCollectAdd.http({
            errorPop: false,
            isLogin: true,
            data: {
                goods: [`${goodsSn}_${warehouseCode}`],
            },
        });

        if (+res.status === 0) {
            success();

            if ($effectEl && !$effectEl.hasClass(effectCls)) {
                $effectEl.addClass(effectCls);
            }
        }

        return res;
    }


    /**
     * 单个商品取消收藏
     * @param goodsSn 商品sku
     * @param warehouseCode 商品仓库码
     * @param $effectEl 取消收藏后受影响的Jquery元素
     * @param effectCls 取消收藏后要删除的className
     * @param success 取消收藏成功
     */
    static async delete({
        goodsSn = null,
        warehouseCode = null,
        $effectEl = null,
        effectCls = 'active',
        success = $.noop
    }) {

        if (!goodsSn || !warehouseCode) {
            return false;
        }

        const res = await serviceGoodlistCollectRemove.http({
            isLogin: true,
            data: {
                goodSn: goodsSn,
                virCode: warehouseCode,
            },
        });

        if (+res.status === 0) {
            success();

            if ($effectEl && $effectEl.hasClass(effectCls)) {
                $effectEl.removeClass(effectCls);
            }
        }

        return res;
    }

    static status() {

    }
}

export default GoodsCollect;
