/**
 * 执行巴西墨西哥分期付款脚本
 */
function installment() {
    $('.js-installValue').each((index, elem) => {
        const $elem = $(elem);
        const $parent = $elem.closest('.js_seachResultList');
        const data = $elem.attr('data-value');
        const array = data ? JSON.parse(data) : [];
        if (Array.isArray(array) && $parent.length > 0) {
            array.forEach((item) => {
                const $target = $parent.find(`li[data-installment-id="${item.installmentId}"]`);
                $target.find('.js-stagingFree').html(computedAmount(+$target.find('.js-asyncPrice')[0].dataset.currency, item));
            });
        }
    });

    // 内部函数
    function computedAmount(curPrice, data) {
        let result = null;
        data.installments.some((item) => {
            if (item.rate === 0 && item.installments > 1) {
                item.amount = curPrice / item.installments;
                if (item.amount > data.minAmount) {
                    result = item;
                    return true;
                }
            }
            return false;
        });
        return result ?
            `<p class="gbGoodsItem_stagingTag">
                ${result.installments} x 
                <span class="js-currency" data-currency="${result.amount}">${result.amount}</span>
            </p>
            <p class="gbGoodsItem_freeLabel">
                <span class="gbGoodsItem_freeTag">interest-free</span>
            </p>` : '';
    }
}

export { installment };
