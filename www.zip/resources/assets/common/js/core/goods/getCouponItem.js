/**
 * Created by Liu.Jun on 2018/9/5.
 */

import { serviceGetCouponItem } from 'js/service/common';
import { trans } from 'js/core/translate.js';
import layer from 'layer';
import brushCheck from 'component/brushCheck/brushCheck.js';

const getCouponItem = ({
    templateCode, // 优惠券code
    couponResource = 7, // 优惠券渠道
    successTip = true, // 成功提示语
    errorPop = true, // 失败是否提示
    tologin = true, // 是否需要登录
    loading = false, // 是否显示loading
    isCancel = false, // 是否需要取消上次的请求
    defaultState = true, // 默认状态为true正常执行公共then,如false则执行自定义then
}) => serviceGetCouponItem.http({
    data: {
        templateCode,
        couponResource,
    },
    loading,
    isCancel,
    errorPop,
}).then(async ({ status, msg, data }) => {
    if (tologin && data.redirectUrl) {
        const originUrl = window.location.href;
        window.location.href = `${data.redirectUrl}&ref=${originUrl}`;
        return false;
    }
    if (status === 40373285) {
        const checkContent = await brushCheck({
            action: data.action,
            siteKey: data.siteKey,
            recaptchaVersion: data.recaptchaVersion
        });
        const res = await serviceGetCouponItem.http({
            data: {
                templateCode,
                couponResource,
                gbcaptcha: checkContent.gbcaptcha,
                captchaType: checkContent.captchaType,
                recaptchaVersion: checkContent.recaptchaVersion,
            },
            loading,
            isCancel,
            errorPop,
        });
        if (defaultState) {
            if (res.status === 0) {
                if (successTip) {
                    layer.msg(trans('cart.got_your_coupon'));
                }
            } else {
                layer.msg(res.msg);
            }
        }
        return res;
    }
    if (defaultState) {
        if (status === 0) {
            if (successTip) {
                layer.msg(trans('cart.got_your_coupon'));
            }
        } else {
            layer.msg(msg);
        }
    }
    return { status, msg, data };
});

export default getCouponItem;
