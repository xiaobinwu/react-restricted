/**
 * StateStore 用于管理数据集合。主要用于当pool的所有参数都设置了值后，触发callback回调
 */
class StateStore {
    map = Object.create(null);
    once = true;
    instance = null;
    init({
        pool = [],
        callback = null,
        once = true,
    } = {}) {
        pool.forEach((value) => {
            this.map[value] = null;
        });
        this.once = once;
        this.callback = callback;
    }
    set(key, value = key) {
        if (key in this.map) {
            this.map[key] = value;
            this.judge();
        }
    }
    get(key) {
        return this.map[key];
    }
    judge() {
        if (Object.values(this.map).every(value => (value !== null))) this.triggle();
    }
    triggle() {
        if (this.once && !this.instance) {
            this.instance = this.callback;
            this.callback(this.map);
        } else {
            this.callback(this.map);
        }
    }
}

export default StateStore;
