/**
 *  商品业务逻辑相关的方法
 */
import SimpleScrollbar from 'lib/simple-scrollbar/simple-scrollbar.js';
import 'lib/simple-scrollbar/simple-scrollbar.css';
import {
    serviceSampleCart,
    serviceAddToCart,
} from 'js/service/common';
import { serviceCartDelete } from 'js/service/paycart';
import runtime from 'art-template/lib/runtime';
import PubSub from 'pubsub-js';
import { updateCurrency } from 'js/core/currency';
import $ from 'jquery';

const { CART_THEME_TYPE } = window.GLOBAL;
const tinyCartWrap = $('#js-tinyCartWrap');
const HeadCartList = $('#js-panelHeadCartList');
let vueTinyCart;

runtime.GLOBAL = window.GLOBAL;

async function updateSampleCart(cb) {
    const [res, temp] = await Promise.all([serviceSampleCart.http(), import('common/temp/sample_cart.art')]);
    if (res.status === 0 && res.data.goodsList) {
        $('.js-cartNum').text(res.data.totalCount);
        $('.js-headerCart').html(temp({ ...res.data }));
        updateCurrency({
            context: $('.js-headerCart')[0]
        });
        if ($('.js-headerCartScroll').length) {
            const headerCart = document.querySelector('.js-headerCart');
            const dispalyStatus = window.getComputedStyle(headerCart).display;
            if (dispalyStatus !== 'block') headerCart.style.display = 'block';
            SimpleScrollbar.initEl(document.querySelector('.js-headerCartScroll'));
            if (dispalyStatus !== 'block') headerCart.style.display = dispalyStatus;
        }
    }
    if (cb) {
        cb();
    }
    /**
     * that cart contain scrollbar in the site header
     */
}

/**
 * 品牌升级小购物车面板
 * @param {*是否使用缓存数据} useCacheData 默认true
 */

async function updateUpgradeSimpleCart(callback) {

    if (HeadCartList.length === 0 && tinyCartWrap.length === 0) return;

    if (CART_THEME_TYPE === 2) {
        if (!vueTinyCart) {
            // 初始化
            const temp = await import('component/tinyCart/tinyCart.js');
            vueTinyCart = await temp.default();
        } else if (vueTinyCart.$children.length) {
            // 更新购物车数据
            vueTinyCart.$children[0].getCartList();
        }
    } else {
        // 获取购物车列表数据
        const res = await serviceSampleCart.http();
        // 异步加载购物车样式及模板
        const { default: simpleTemp } = await import('modules/common/simple_cart/simple_cart.js');

        if (res.status === 0 && res.data && res.data.goodsList) {

            // 更新购物车数量
            $('.js-cartNum').text(res.data.totalCount);

            // 填充购物车数据
            HeadCartList.html(simpleTemp({ ...res.data }));

            // 美化滚动条
            if ($('.js-headCartScroll').length) {
                SimpleScrollbar.initEl(document.querySelector('.js-headCartScroll'));
            }

        } else {
            // 购物车数据获取失败
        }
    }

    // 更新货币
    PubSub.publish('sysUpdateCurrency', {
        context: $('#js-labelHeadCart')[0]
    });

    if (callback) callback();
}

/**
 * 添加到购物车
 * @param data(支持传一个data对象，表示只添加一个商品) [{
 *  goodsSn         string      Y   商品SKU
 *  qty             string      Y   商品数量
 *  warehouseCode   string      Y   仓库代码
 *  ===========================================
 *  goodsType       int         N   商品类型    0：正常  1：配件  2：赠品  3：加价购 4：买即赠赠品
 *  activityId      int         N   活动Id 不传默认为0
 *  mainGoodsSn     string      N   主商品SKU （配件商品传） 默认 空
 *  ciphertext      string      N   邮箱加密价 默认空
 *  source          int         N   来源  0-详情 1-列表
 *  }]
 *
 *  @param cartAni(飞入购物车动画配置) {
 *  imgSrc: '',     string      Y   飞入过程中小图片src
 *  origin: '',     jquery      Y   飞出起点 $元素
 *  target: '',     jquery      N   飞入目标元素 $元素,默认顶部的购物车
 *  }
 */
async function addToCart({
    goods,
    cartAni = {},
} = {}) {
    // 购物车动画
    async function cartAnimation(options) {
        const imgsrc = options.imgSrc;
        const $origin = options.origin;
        const $target = options.target || $('#js-labelHeadCart');
        const originOffset = $origin.offset();
        const targetOffset = $target.offset();
        const flyer = $(`<img style="z-index:1000; width:40px; height:40px; border-radius:50%;" src="${imgsrc}"/>`);

        if (!flyer.fly) {
            await import('common/js/lib/jquery.fly.min');
        }

        flyer.fly({
            start: {
                left: originOffset.left,
                top: originOffset.top - $(window).scrollTop(),
            },
            end: {
                left: targetOffset.left,
                top: targetOffset.top - $(window).scrollTop(),
                width: 20,
                height: 20,
            },
            speed: 2,
            vertex_Rtop: 20, // 运动轨迹最高点top值，默认20
            onEnd() {
                flyer.hide();
            },
        });
    }

    // 购物车请求
    if (serviceAddToCart.cancel) {
        serviceAddToCart.cancel();
    }
    const res = await serviceAddToCart.http({
        method: 'POST',
        data: {
            goods: JSON.stringify(goods),
        },
    });
    if (res.status === 0) {
        PubSub.publish('sysUpdateSampleCart');
        if (cartAni.imgSrc && cartAni.origin) {
            cartAnimation(cartAni);
        }
    } else {
        PubSub.publish('sysAddToCartFail', res);
    }
    PubSub.publish('sysAddToCartAlways', res);
}

/**
 * 从购物车中删除一项或多项
 * @param itemIds Array 需要删除的商品项
 */
async function deleteFromCart({ itemIds = [], success, faild = null }) {
    if (itemIds.length) {
        const res = await serviceCartDelete.http({
            data: {
                itemId: itemIds.join(',')
            },
            loading: false,
        });

        if (res.status === 0) {
            if (typeof success === 'function') success();
        } else if (typeof faild === 'function') {
            faild();
        }
    }
}

function closeTinyCart() {
    const tinyCartBtn = $('#js-tinyCartBtn');
    tinyCartBtn.attr('visible', 0);
    tinyCartWrap.removeClass('visible');
    setTimeout(() => {
        tinyCartWrap.hide();
    }, 100);
}

export {
    updateSampleCart,
    updateUpgradeSimpleCart,
    addToCart,
    deleteFromCart,
    closeTinyCart,
};
