/**
 * Created by Liu.Jun on 2018/9/4.
 */

import { STORAGE_GOODS_VIEW_HISTORY } from 'js/variables';

/**
 * 用户浏览商品历史记录
 */
class GoodsViewHistory {
    // 获取历史记录 Array
    static get() {
        return JSON.parse(window.localStorage.getItem(STORAGE_GOODS_VIEW_HISTORY) || '[]');
    }
    // 设置历史记录 JSON
    static set(val) {
        let isInIndex = 0;
        const data = GoodsViewHistory.get();

        // 判断是否浏览过
        const isIn = data.some((item, index) => { // eslint-disable-line
            isInIndex = index;
            return val.sku === item.sku;
        });

        // 浏览过要清除，下一步将作为新值插入到起始
        if (isIn) {
            data.splice(isInIndex, 1);
        }

        // 在起始插入新值
        data.unshift(val);

        // 仅显示最近10条
        if (data.length > 10) {
            data.length = 10;
        }

        window.localStorage.setItem(STORAGE_GOODS_VIEW_HISTORY, JSON.stringify(data));
    }
    // 移动所有历史记录
    static remove() {
        window.localStorage.removeItem(STORAGE_GOODS_VIEW_HISTORY);
    }
}

export default GoodsViewHistory;
