/**
 * 记录进入商详标识(referrer,isChangeAttr)
 * 2018-10-08 15:03:23
 */
import { STORAGE_RECORD_TO_GOODS } from 'js/variables';

class RecordToGoods {
    static get() {
        return JSON.parse(window.sessionStorage.getItem(STORAGE_RECORD_TO_GOODS)) || {};
    }

    // 可传一个对象
    static set(key, val) {
        const data = this.get();
        data[key] = val;

        window.sessionStorage.setItem(STORAGE_RECORD_TO_GOODS, JSON.stringify(data));
    }
}

export default RecordToGoods;
