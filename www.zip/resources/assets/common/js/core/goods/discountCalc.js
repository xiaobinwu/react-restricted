/**
 * 前端统一折扣标计算方式
 * luochongfei
 * 2018-12-25 17:14:19
 */
import { add, divide } from 'js/core/currency';

// 获取折扣
function getDiscount(displayPrice = 0, shopPrice = 0) {
    return Math.round(divide(add(shopPrice, -displayPrice), shopPrice) * 100);
}

// 获取折扣标 带百分号
function getDiscountStr(displayPrice, shopPrice) {
    const discount = getDiscount(displayPrice, shopPrice);
    const htmlstrArr = [`<strong class="gbGoodsItem_per">${discount}</strong>`, '%'];

    // 土耳其站百分比前置
    if (window.GLOBAL.LANG === 'tr') {
        htmlstrArr.reverse();
    }

    return htmlstrArr.join('');
}

export {
    getDiscount,
    getDiscountStr
};
