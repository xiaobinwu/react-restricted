// fcm 配置
export const configDev = {
    config: {
        apiKey: 'AIzaSyCjCpDX-GR-o0LMnE2ajWQ0czcedZofCP0',
        authDomain: 'gearbest-web-test.firebaseapp.com',
        databaseURL: 'https://gearbest-web-test.firebaseio.com',
        projectId: 'gearbest-web-test',
        storageBucket: 'gearbest-web-test.appspot.com',
        messagingSenderId: '526451598855'
    },
    key: 'BEiGMeE2BJvDCqbniwq-p_GE_OJhOKIjRPXeT2zjR7RawtaucyDug1OqwT5FYEh2TBqbeEMSqsqRoQBSscQJuEI',

};

export const configProd = {
    config: {
        apiKey: 'AIzaSyB5GQSzurxILwQZhuSypdb-L3U_HBRJUFc',
        authDomain: 'gearbest-web-prod.firebaseapp.com',
        databaseURL: 'https://gearbest-web-prod.firebaseio.com',
        projectId: 'gearbest-web-prod',
        storageBucket: 'gearbest-web-prod.appspot.com',
        messagingSenderId: '49948730698'
    },
    key: 'BEHd_CmhOJ9x_wK36SxY1YpjP1VMst8AFoI1jogQLWdanpenjaJ28h8fxHMK5zRIGUgp7VO3SWZPWtRbnDcBaoc',
};
