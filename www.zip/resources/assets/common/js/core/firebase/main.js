// firebase
import { serviceSetToken } from 'js/service/auth.js';
import { COOKIE_FCM, COOKIE_FCM_TOKEN, COOKIE_FCM_PIPELINE } from 'common/js/variables.js';
import Cookies from 'js/utils/cookie.js';
import { configDev, configProd } from './config.js';

const { PIPELINE } = GLOBAL;
const ENV = window.location.href.indexOf('.com') > -1 ? 'prod' : 'dev';

export const loadScript = (url) => {
    const doc = document;
    const scriptElement = doc.createElement('script');
    doc.body.appendChild(scriptElement);
    const promise = new Promise((resolve) => {
        scriptElement.addEventListener('load', () => {
            resolve();
        });
    });
    scriptElement.src = url;
    return promise;
};

// 取浏览器信息
const getBrowser = () => {
    const explorer = window.navigator.userAgent;
    if (explorer.indexOf('MSIE') >= 0) {
        return 'ie';
    } else if (explorer.indexOf('Firefox') >= 0) {
        return 'Firefox';
    } else if (explorer.indexOf('Chrome') >= 0) {
        return 'Chrome';
    } else if (explorer.indexOf('Opera') >= 0) {
        return 'Opera';
    } else if (explorer.indexOf('Safari') >= 0) {
        return 'Safari';
    }
    return explorer;
};

/**
 * token fcm token power-2(messaging/permission-blocked) power-0(messaging/permission-default)
 * power 0未授权, 1允许, 2禁止
 * http://wiki.hqygou.com:8090/pages/viewpage.action?pageId=129368449
 */
const sendTokenToServer = async (token) => {
    let power;
    let oldToken = Cookies.get(COOKIE_FCM_TOKEN);
    if (!token) { // 国家站
        power = +Cookies.get(COOKIE_FCM);
        if (power === 1) {
            token = oldToken;
        } else if (power === 2) {
            token = oldToken || 'messaging/permission-blocked';
        } else {
            token = 'messaging/permission-default';
        }
    } else {
        power = getPower(token);
    }
    if (power === 1) { // 允许
        if (!oldToken) {
            oldToken = token;
        }
    } else if (power === 2) { // 禁止
        if (oldToken) { // 曾今允许过，保存了cookie
            token = oldToken;
        } else {
            oldToken = token; // 禁止时没有前置操作，均置为mess...
        }
    }

    const params = {
        fcmtoken: token,
        power,
        old_fcmtoken: oldToken,
        page_name: window.location.href,
        language: GLOBAL.LANG,
        browser: getBrowser(),
    };
    Cookies.set(COOKIE_FCM, power, {
        expires: 1 / 3,
    });
    let pipeLineList = Cookies.get(COOKIE_FCM_PIPELINE);
    pipeLineList = pipeLineList ? pipeLineList.split(',') : [];
    if (!pipeLineList.includes(PIPELINE)) {
        pipeLineList.push(PIPELINE);
        Cookies.set(COOKIE_FCM_PIPELINE, pipeLineList.toString(), {
            expires: 1 / 3,
        });
    }
    if (token.indexOf('messaging') < 0) {
        Cookies.set(COOKIE_FCM_TOKEN, token, {
            expires: 1 / 3,
        });
    }
    await serviceSetToken.http({
        data: params
    });
};

// 根据token获取power(详见sendTokenToServer)
const getPower = (token) => {
    if (token.indexOf('default') > -1) {
        return 0;
    } else if (token.indexOf('blocked') > -1) {
        return 2;
    }
    return 1;
};

// 获取配置
const getBase = () => {
    const base = ENV === 'prod' ? configProd : configDev;
    return base;
};

// 是否已弹过窗
const checkStatus = () => !!Cookies.get(COOKIE_FCM);

// 检查当前国家站是否订阅过
const checkPipeline = () => {
    let pipeList = Cookies.get(COOKIE_FCM_PIPELINE);
    if (pipeList) {
        pipeList = pipeList.split(',');
        return pipeList.includes(PIPELINE);
    }
    return false;
};

export const initFirebase = async (isPush) => {
    if (!('serviceWorker' in navigator && 'PushManager' in window)) {
        return;
    }
    await loadScript('https://www.gstatic.com/firebasejs/5.5.1/firebase-app.js');
    await loadScript('https://www.gstatic.com/firebasejs/5.5.1/firebase-messaging.js');
    const { firebase } = window;
    const base = getBase();
    const { config, key } = base;
    firebase.initializeApp(config);
    const messaging = firebase.messaging();
    messaging.usePublicVapidKey(key);
    if (!checkStatus()) { // cookie 无记录时
        try {
            await messaging.requestPermission();
            const token = await messaging.getToken();
            await sendTokenToServer(token);
        } catch (e) {
            await sendTokenToServer(e.code);
        }
    } else if (isPush || !checkPipeline()) { // 有cookie时判断国家站或isPush为true推送
        try {
            const token = await messaging.getToken();
            await sendTokenToServer(token);
        } catch (e) {
            await sendTokenToServer(e.code);
        }
    }
    messaging.onTokenRefresh(() => {
        messaging.getToken().then((refreshedToken) => {
            sendTokenToServer(refreshedToken);
        });
    });

};
