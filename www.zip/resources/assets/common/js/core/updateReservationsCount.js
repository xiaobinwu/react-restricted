import { serviceReservationTotal } from 'js/service/user';
import { getUserStatus } from 'js/core/user.js';

let promise = null;

export default async (usueElem) => {
    const userStatus = await getUserStatus({ update: 1, toLogin: 0 });

    if (userStatus.isLogin) {
        if (!promise) {
            promise = new Promise(async (resolve) => {
                const nowTime = Number(new Date());
                const { reservationsQty, reservationsTime } = JSON.parse(window.localStorage.getItem('reservationsInfo')) || {};

                if (reservationsTime && nowTime - reservationsTime < 1000 * 60) {
                    resolve(reservationsQty || 0);
                } else {
                    const { status, data } = await serviceReservationTotal.http();
                    if (status === 0) {
                        resolve(data.total || 0);
                        window.localStorage.setItem('reservationsInfo', JSON.stringify({
                            reservationsQty: data.total || 0,
                            reservationsTime: nowTime
                        }));
                    }
                }
            });
        }

        const count = await promise;
        [...usueElem].forEach((item) => {
            item.innerHTML = count > 99 ? '(99+)' : `(${count})`;
            item.style.display = count > 0 ? 'inline-block' : 'none';
        });
    }
};
