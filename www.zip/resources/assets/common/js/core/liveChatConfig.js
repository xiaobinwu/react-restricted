/**
 *  live Chat 入口配置
 */

// 商品业务逻辑
import GoodsInfo from 'js/core/goods/GoodsInfo.js';

// url pathname
const urlPathName = window.location.pathname || '';

// 可变配置
const eachConfig = {
    // 分类页
    category() {
        const cateConfig = ['11992', '11293', '12127'];
        let flag = false;
        const cateMatch = urlPathName.match(/c_([^/]*)/);
        const cateId = cateMatch.length > 1 ? cateMatch[1].toString() : 0;
        if (cateId !== 0 && cateConfig.includes(cateId)) {
            flag = true;
        }
        return flag;
    },

    // 搜索结果页
    search() {
        const cateConfig = ['11293', '12127'];
        let flag = false;
        const $cateIncludeItem = $('.js-limtColumnBox').find('li');
        $cateIncludeItem.each((index, item) => {
            const cateId = $(item).data('cateid') ? $(item).data('cateid').toString() : 0;
            if (cateId !== 0 && cateConfig.includes(cateId)) {
                flag = true;
            }
        });
        return flag;
    },

    // 商详页
    goodsDetail() {
        let flag = false;
        const GOODSINFO = GoodsInfo.get();

        // 分类匹配
        const cateConfig = ['11293', '12127'];
        const cateId = GOODSINFO.categoryId;
        if (cateConfig.includes(cateId)) {
            flag = true;
        }

        // 品牌匹配
        const brandsConfig = ['Alfawise'];
        if (brandsConfig.includes(GOODSINFO.brandCode)) {
            flag = true;
        }

        return flag;
    },

    // 品牌详情页
    activityNewBrand() {
        const brandConfig = ['vernee', 'umidigi'];
        let flag = false;
        const brandMatch = urlPathName.match(/brand\/([^/]*)\.html/);
        const brandName = brandMatch.length > 1 ? brandMatch[1].toString() : 0;
        if (brandName !== 0 && brandConfig.includes(brandName)) {
            flag = true;
        }
        return flag;
    }
};

// 搜索分类页同搜索页
eachConfig.searchCategory = eachConfig.category;
eachConfig.categoryList = eachConfig.category;


// 具体逻辑处理
const $preSaleChat = $('#js-panelPreSaleChat');
const liveChat = {
    init() {
        const pageType = $preSaleChat.data('ptype');
        if (typeof pageType !== 'undefined' && typeof eachConfig[pageType] === 'function') {
            const needShow = eachConfig[pageType]();
            if (needShow) {
                $preSaleChat.addClass('show');
                this.bineEvent();
            }
        }
    },

    bineEvent() {
        $preSaleChat.on('click', () => {
            $('.liveChatBtnHidden .LPMlabel').trigger('click');
        });
    }
};

liveChat.init();
