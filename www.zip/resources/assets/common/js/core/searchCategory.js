/*
* 搜索分类页的工具函数
* */
import { getSelector } from 'js/utils/similarjQ';

function getTrackInforEle() {
    const eleInforInput = getSelector('.js-track-infor');
    return eleInforInput ? eleInforInput.dataset.trackType : null;
}
/**
 * 判断是否是搜索结果页。input.js-track-infor获取类型最准确。
 * @returns {boolean}
 */
export function isSearchPage() {
    const infor = getTrackInforEle();
    return infor && infor.includes('search');
}

/**
 * 判断是否是分类页。input.js-track-infor获取类型最准确。
 * @returns {boolean}
 */
export function isCategoryPage(urlPath = window.location.pathname) {
    const infor = getTrackInforEle();
    return infor && infor.includes('category');
}

