/**
 * 国家、币种相关函数集合
 * Created by li Jiazhan on 2018/4/24
 */

import { getUrlQuery } from 'js/utils/index.js';
import smartPromise from 'js/utils/smartPromise.js';
import { serviceCurrencyInfo, serviceCurrentCountry } from 'js/service/common';
import {
    COOKIE_CURRENCY_CODE,
    COOKIE_COUNTRY_CODE,
    COOKIE_CDN_COUNTRYCODE,
    COOKIE_PIPELINE,
} from 'js/variables';

import Cookies from 'js/utils/cookie';

const US = 'US';
const USD = 'USD';

/**
 * 国家字典
 */
let COUNTRY_DICT = null;

/**
 * 返回国家索引字典
 * 注意：这个接口只有在用户已登录的情况才能请求成功
 * @returns {Promise}
 */
async function getCountryDict() {
    if (!COUNTRY_DICT) {
        COUNTRY_DICT = {};
        try {
            [...document.querySelector('.js-countrySelect').options].forEach((item) => {
                if (item.value) {
                    COUNTRY_DICT[item.value] = {
                        countryCode: item.value,
                        countryName: item.dataset.countryName || item.innerHTML,
                    };
                }
            });
        } catch (e) {
            console.log('获取国家列表失败');
        }
    }
    return COUNTRY_DICT;
}

/**
 * 储存当前国家信息
 */
const COUNTRY = {};

/**
 * 异步接口获取cdnCountryCode，后端写cookie
 * @returns {Promise}
 */
async function ajaxGetCdnCountryCode() {
    try { await serviceCurrentCountry.http(); } catch (e) { /* nothing */ }
    return Cookies.get()[COOKIE_CDN_COUNTRYCODE] || US;
}

/**
 * 返回当前cdn定位国家代码
 * @param useCookie 是否使用cookie，默认是
 * @returns {Promise}
 */
const getCdnCountryCode = smartPromise(async (useCookie = true) => {
    const cookieCountryCode = Cookies.get()[COOKIE_CDN_COUNTRYCODE];

    // 如果需要使用cookie
    if (useCookie && cookieCountryCode) {
        return cookieCountryCode;
    }

    // 直接从接口获取
    const cdnCountryCode = await ajaxGetCdnCountryCode();

    return cdnCountryCode;
});

/**
 * 返回当前国家代码，国家代码优先取本地cookie，其次CDN cookie，否则默认 "US"
 * @returns {Promise}
 */
const getCountryCode = smartPromise(async () => {
    if (COUNTRY.countryCode) return COUNTRY.countryCode;
    const cookies = Cookies.get();
    let countryCode = cookies[COOKIE_COUNTRY_CODE];

    if (!countryCode) {
        countryCode = getCdnCountryCode();
    }
    return countryCode;
});

/**
 * 返回国家信息, 参数为空则返回当前国家信息
 * @param countryCode 国家代码
 * @returns {Promise}
 */
const getCountry = smartPromise(async (countryCode) => {
    if (countryCode) {
        return (await getCountryDict())[countryCode] || {};
    } else if (COUNTRY.countryCode) {
        return COUNTRY;
    }
    if (!COUNTRY_DICT) getCountryDict(); // 提前并发请求
    countryCode = await getCountryCode();
    return setCountry(countryCode);
});

/**
 * 设置国家信息
 * @param countryCode 国家代码
 * @returns {Promise}
 */
async function setCountry(countryCode) {
    if (countryCode && countryCode !== COUNTRY.countryCode) {
        const { countryName } = (await getCountryDict())[countryCode] || {};
        if (countryName) {
            COUNTRY.countryCode = countryCode;
            COUNTRY.countryName = countryName;
            Cookies.set(COOKIE_COUNTRY_CODE, countryCode);
        }
    }
    return COUNTRY;
}

/**
 * 币种字典
 */
let CURRENCY_DICT = null;

/**
 * 返回币种索引字典
 * 针对部分国家币种符号需要添加空格（为了视觉好看）
 * @returns {Object}
 */
function getCurrencyDict() {
    if (!CURRENCY_DICT) {
        const specials = {};
        ['RUB', 'TRY', 'JPY', 'SAR', 'CLP', 'CZK', 'AED', 'BGN', 'HRK', 'KRW', 'MAD', 'RON', 'ILS', 'UAH'].forEach((item) => {
            specials[item] = 1;
        });

        CURRENCY_DICT = {};
        (window.EXCHANGERATE || []).forEach((item) => {
            if (specials[item.currencyCode] === 1) {
                item.currencySign = item.currencyPosition ? ` ${item.currencySign}` : `${item.currencySign} `;
            }
            CURRENCY_DICT[item.currencyCode] = item;
        });
    }
    return CURRENCY_DICT;
}

/**
 * 储存当前币种信息
 */
const CURRENCY = {};

/**
 * 返回币种信息, 参数为空则返回当前币种信息
 * @param  {String} currencyCode 币种代码
 * @return {Promise}
 */
const getCurrency = smartPromise(async (currencyCode) => {
    if (currencyCode) {
        return getCurrencyDict()[currencyCode] || {};
    } else if (CURRENCY.currencyCode) {
        return CURRENCY;
    }
    const cookies = Cookies.get();
    // 币种代码优先取URL参数，其次取cookie值，
    // 如果还没有，就只能调异步接口获取了，但是这种情况几乎不可能出现
    currencyCode = getUrlQuery().currency || cookies[COOKIE_CURRENCY_CODE];
    if (!currencyCode) {
        const countryCode = await getCountryCode();
        currencyCode = await getCurrencyCodeByCountry(countryCode);
    }
    return setCurrency(getCurrencyDict()[currencyCode] ? currencyCode : USD);
});

/**
 * 根据国家码返回对应币种信息, 参数为必传
 * @param  {String} countryCode 币种代码
 * @return {Promise}
 */
const getCurrencyCodeByCountry = smartPromise(async (countryCode) => {
    try {
        const cookies = Cookies.get();
        const { data } = await serviceCurrencyInfo.http({
            params: {
                pipeline: cookies[COOKIE_PIPELINE],
                country: countryCode,
            }
        });
        return data.currency || USD;
    } catch (e) {
        return USD;
    }
});

/**
 * 设置币种信息，并记录cookie
 * @param {String} currencyCode 币种代码
 * @return {Promise}
 */
async function setCurrency(currencyCode) {
    if (currencyCode && currencyCode !== CURRENCY.currencyCode) {
        const result = getCurrencyDict()[currencyCode] || {};
        if (result.currencyCode) {
            // 这么写而不是直接赋值是为了能返回同一个引用（CURRENCY）
            Object.assign(CURRENCY, result);
            Cookies.set(COOKIE_CURRENCY_CODE, currencyCode);
        }
        return CURRENCY;
    }
    return getCurrency(currencyCode);
}

/**
 * 小数点移位，相当于乘以10的n次幂
 * @return {Number}
 * @example exp10(19.99, 1) => 199.9
 * @example exp10(19.99, 3) => 19990
 * @example exp10(19.99, -3) => 0.01999
 */
function exp10(number, n) {
    number = Number(number) || 0;
    n = Number(n) || 0;
    if (!number) return 0;
    let abs = String(Math.abs(number));
    const decimal = abs.split('.')[1];
    if (decimal) {
        n -= decimal.length;
        abs = abs.replace('.', '');
    }
    if (n >= 0) {
        abs += '0'.repeat(n);
    } else if (n <= -abs.length) {
        abs = `0.${'0'.repeat(-abs.length - n) + abs}`;
    } else {
        abs = `${abs.slice(0, n)}.${abs.slice(n)}`;
    }
    return Number(`${number < 0 ? '-' : ''}${abs}`);
}

/**
 * 浮点数加法，支持多个数相加
 * @param numbers
 * @return {Number}
 */
function add(...numbers) {
    let maxDigit = 0;
    const arr = (Array.isArray(numbers[0]) ? numbers[0] : numbers).map((num) => {
        let numStr = String(Number(num) || 0);
        const decimal = numStr.split('.')[1];
        let digit = 0;
        if (decimal) {
            digit = decimal.length;
            maxDigit = Math.max(maxDigit, digit);
            numStr = numStr.replace('.', '');
        }
        return { numStr, digit };
    });
    const sum = arr.reduce((pre, item) => {
        if (!item) return pre;
        return pre + exp10(item.numStr, maxDigit - item.digit);
    }, 0);
    return exp10(sum, -maxDigit);
}

/**
 * 浮点数减法
 * @param a 被减数
 * @param b 减数
 * @return {Number}
 */
function sub(a, b) {
    return add(a, -b);
}

/**
 * 浮点数乘法，支持多个数相乘
 * @param numbers
 * @return {Number}
 */
function multiply(...numbers) {
    let digit = 0;
    const total = (Array.isArray(numbers[0]) ? numbers[0] : numbers).reduce((pre, num) => {
        if (!num) return 0;
        let numStr = String(Number(num) || 0);
        const decimal = numStr.split('.')[1];
        if (decimal) {
            digit += decimal.length;
            numStr = numStr.replace('.', '');
        }
        return pre * numStr;
    }, 1);
    return exp10(total, -digit);
}

/**
 * 浮点数除法
 * @param a 被除数
 * @param b 除数
 * @return {Number}
 */
function divide(a, b) {
    a = Number(a) || 0;
    b = Number(b) || 1;
    const [A, B] = [a, b].map((num) => {
        const decimal = String(num).split('.')[1];
        return {
            value: num,
            digit: decimal ? decimal.length : 0
        };
    });
    const maxDigit = Math.max(A.digit, B.digit);
    return exp10(A.value, maxDigit) / exp10(B.value, maxDigit);
}

/**
 * 优化原生toFixed函数
 * @param number    数字
 * @param n         小数点后保留位数
 * @param round     取整方式：0-向下取整、1-四舍五入、2-向上取整
 * @return {String}
 */
function toFixed(number = 0, n = 0, round = 2) {
    n = n > 0 ? n : 0;
    if (!number) {
        return `0.${'0'.repeat(n)}`;
    }
    const ROUND = ['floor', 'round', 'ceil'];
    number = exp10(number, n);
    number = Math[ROUND[round]](number);
    number = String(number);

    if (n - number.length >= 0) {
        number = `0.${'0'.repeat(n - number.length) + number}`;
    } else if (n > 0) {
        number = `${number.slice(0, -n)}.${number.slice(-n)}`;
    }
    return number;
}

/**
 * 格式化价格输出
 * @param {Number}  price         价格（默认美元）
 * @param {Number}  rate          汇率
 * @param {Number}  exponent      小数点后保留位数
 * @param {String}  sign          币种符号
 * @param {Number}  position      币种符号相对价格数值的前后关系（0表示符号在前，1在后）
 * @param {Boolean} wrap          是否用标签分别包裹（<i>币种符号</i><span>整数</span><sub>小数</sub>）：0-否、1-是
 * @param {Number}  round         取整方式：0-向下取整、1-四舍五入、2-向上取整
 * @return {String}
 */
function output({
    price = 0,
    rate = 1,
    exponent = 2,
    sign = '$',
    position = 0,
    wrap = 0,
    round = 2,
} = {}) {
    price = multiply(price, rate);
    price = toFixed(price, exponent, round);
    if (String(wrap) === '1') {
        sign = `<i>${sign}</i>`;
        const dotPos = price.indexOf('.');
        if (dotPos >= 0) {
            price = `<span>${price.slice(0, dotPos)}</span><sub>${price.slice(dotPos)}</sub>`;
        } else {
            price = `<span>${price}</span>`;
        }
    }
    return position ? price + sign : sign + price;
}

/**
 * 渲染价格元素
 * @param {Element}  context        容器
 * @param {String}   selector       选择器
 * @param {NoteList} elements       DOM元素列表
 * @param {String}   currencyCode   币种代码
 * @param {Boolean}  wrap           是否用标签分别包裹：币种符号、整数部分、小数部分
 * @param {Number}   round          取整方式：0-向下取整、1-四舍五入、2-向上取整
 */
async function updateCurrency({
    context = document,
    selector = '.js-currency',
    elements = [],
    currencyCode = '',
    wrap = 0,
    round = 2,
} = {}) {
    const currency = await setCurrency(currencyCode);
    if (elements && elements.nodeType === 1) {
        elements = [elements];
    } else if (!elements || !elements.length || elements[0].nodeType !== 1) {
        elements = context.querySelectorAll(selector);
    }

    [...elements].forEach((item) => {
        const { dataset } = item;
        dataset.wrap = dataset.wrap || wrap;
        dataset.round = dataset.round || round;
        item.innerHTML = output({
            price: dataset.currency || 0,
            rate: currency.currencyRate,
            exponent: currency.exponent,
            sign: currency.currencySign,
            position: currency.currencyPosition,
            wrap: dataset.wrap,
            round: dataset.round,
        });
    });
}

/**
 * 输出换算后币种数值
 * @param price     美元币值
 * @param round     取整方式：0-向下取整、1-四舍五入、2-向上取整
 */
function transform({
    price = 0,
    round = 2,
} = {}) {
    price = multiply(price, CURRENCY.currencyRate);
    price = toFixed(price, CURRENCY.exponent, round);
    return price;
}

/**
 * 不转换，只添加货币符号
 * @param price     当前币值
 * @param round     取整方式：0-向下取整、1-四舍五入、2-向上取整
 */
function addSymbol(price, round = 2) {
    const sign = CURRENCY.currencySign;
    price = toFixed(price, CURRENCY.exponent, round);
    return CURRENCY.currencyPosition ? price + sign : sign + price;
}

/**
 * 输出换算后币种字符串（带币种符号）
 * @param params 参数格式同 transform
 */
function transformSymbol(params) {
    return addSymbol(transform(params));
}


export {
    getCdnCountryCode, // 返回当前cdn定位国家代码
    getCountryCode, // 返回当前国家代码（Promise）
    getCountry, // 返回国家信息（Promise）
    setCountry, // 设置国家信息（Promise）
    getCurrency, // 返回币种信息（Promise）
    setCurrency, // 设置币种信息（Promise）
    exp10, // 小数点移位
    add, // 浮点数加法
    sub, // 浮点数减法
    multiply, // 浮点数乘法
    divide, // 浮点数除法
    toFixed, // 优化原生toFixed函数
    output, // 格式化价格输出
    updateCurrency, // 渲染价格元素（Promise）
    transform, // 输出换算后币种数值
    addSymbol, // 不转换，只添加货币符号
    transformSymbol, // 输出换算后币种字符串（带币种符号）
    getCurrencyCodeByCountry, // 根据国家查询币种信息
};
