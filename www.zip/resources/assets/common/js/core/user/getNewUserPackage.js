/*
   2018/10/24 by yanrenqian
   这个文件用于处理和输出新用户是否领过新手礼包以及判断老用户是否曾经在这个浏览器登陆过这个系统。
   有两种人不可以领新手礼包： 1.一种是老用户 2.是领过新手礼包的新用户
 */

import Cookies from 'js/utils/cookie';
import { COOKIE_HAVE_OLD_USER, COOKIE_IS_NEW_USER } from 'js/variables';

// 领过新手礼包的用户是否登陆过这个系统
export function getHaveOldUser() {
    return Cookies.get(COOKIE_HAVE_OLD_USER);
}

export function setHaveOldUser(value) {
    if (value) {
        Cookies.set(COOKIE_HAVE_OLD_USER, value);
    }
}

// 判断这个人是否是领过新手礼包或者是否老用户
export function getIsNewUser(value) {
    Cookies.get(COOKIE_IS_NEW_USER);
}

export function setIsNewUser(value) {
    if (value) {
        Cookies.set(COOKIE_IS_NEW_USER, value);
    }
}
