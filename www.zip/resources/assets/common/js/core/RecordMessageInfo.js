/**
 * 站内信本地存储数量
 * 2018-11-28
 */
import { STORAGE_MESSAGE_INFO } from 'js/variables';

class RecordMessageInfo {
    static get() {
        try {
            return JSON.parse(window.localStorage.getItem(STORAGE_MESSAGE_INFO)) || {};
        } catch (err) {
            return {};
        }
    }

    // 可传一个对象
    static set(val) {
        const data = JSON.stringify({ messageQty: val, messageTime: new Date().getTime() });
        window.localStorage.setItem(STORAGE_MESSAGE_INFO, data);
    }
}

export default RecordMessageInfo;
