/**
 * 搜索&分类入口ABtest
 * luochongfei
 * 2018-11-22 14:43:16
 */

import PubSub from 'pubsub-js';
import Cookies from 'js-cookie';
import { serviceBtsABtest } from 'js/service/common.js';
import { getUserId } from 'js/core/user/getUserId.js';
import {
    STORAGE_BTS_CATEENTRY,
    STORAGE_BTS_SEARCHENTRY,
    COOKIE_CATEGORY_AB,
    COOKIE_SEARCH_AB
} from 'js/variables';

// 配置项
const CONFIG = {
    // AB分流超时时间（单位:毫秒）
    abShuntTimeout: 1500,

    // AB分流数据本地存在时间（单位：秒）
    abShuntLocalTime: 60 * 60,

    // AB分流cookie过期时间（单位：天）
    cookieExpires: 1 / 24,

    // 分类页AB测试开关
    cateAbTestSwitch: +$('#js-hdCateAbTestSwitch').val() || 0,

    // 搜索页AB测试开关
    searchAbTestSwitch: +$('#js-hdSearchAbTestSwitch').val() || 0,

    // 分类页实验码
    plancodeForCate: 'category',

    // 搜索页实验码
    plancodeForSearch: 'keyword'
};

// 是否分类页、搜索页。 只是用于bts，其他需求慎用
const $pageTypeBts = $('.js-track-pageType_bts');
function isCategoryPage(href = window.location.href) {
    let isCate = false;
    if ($pageTypeBts.length > 0) isCate = $pageTypeBts.val() === 'category';
    return isCate;
}

// 是否搜索页
function isSearchPage(href = window.location.href) {
    let isSearch = false;
    if ($pageTypeBts.length > 0) isSearch = $pageTypeBts.val() === 'search';
    return isSearch;
}


const searchCateABTest = {
    init() {
        this.bindEvent();
    },

    bindEvent() {
        // // 捕获全站的a链接
        // $(document).on('click', 'a', (e) => {
        //     const href = $(e.currentTarget).attr('href');
        //     this.shuntHandle(href, e);
        // });


        // 主动先缓存数据
        PubSub.subscribe('nativeLoad', () => {
            searchCateABTest.shuntHandle('category');
            searchCateABTest.shuntHandle('search');
        });
    },

    /**
     * 分流处理
     * @param {链接} href
     * @param {触发事件对象} e
     */
    shuntHandle(pageType = 'category') {
        const self = this;
        const isCate = pageType === 'category';
        const isSearch = pageType === 'search';

        let switchTag;
        let plancode;
        let storageKey;
        let cookieKey;

        // 分类页
        if (isCate) {
            switchTag = CONFIG.cateAbTestSwitch;
            plancode = CONFIG.plancodeForCate;
            storageKey = STORAGE_BTS_CATEENTRY;
            cookieKey = COOKIE_CATEGORY_AB;
        }

        // 搜索页
        if (isSearch) {
            switchTag = CONFIG.searchAbTestSwitch;
            plancode = CONFIG.plancodeForSearch;
            storageKey = STORAGE_BTS_SEARCHENTRY;
            cookieKey = COOKIE_SEARCH_AB;
        }

        // 开启状态
        if (switchTag) {
            if (!Cookies.get(cookieKey)) { // cookie不存在
                recordData().catch((e) => {
                    console.log(e);
                });
            }
        } else { // 关闭状态

            // 清除本地存储bts数据
            window.sessionStorage.removeItem(storageKey);
            // 清除AB cookie
            Cookies.remove(cookieKey);
        }

        // 记录传递数据
        async function recordData() {
            // 等待AB分流数据
            const res = await self.getABData(plancode);

            if (res && res.policy) {
                // 分流结果存储，以备在分类及搜索页埋点上报使用
                window.sessionStorage.setItem(
                    storageKey,
                    JSON.stringify(res)
                );

                // 设置cookie，给分类及搜索页作cdn副本标识
                Cookies.set(cookieKey, res.policy, { expires: CONFIG.cookieExpires });
            }
        }
    },

    /**
     * ab分流
     * @param {试验码} plancode
     */
    async getABData(plancode) {
        const res = await serviceBtsABtest.http({
            data: JSON.stringify({
                appkey: window.GLOBAL.SITE_CODE,
                cookie: getUserId(),
                plancode,
                params: {},
            }),
            isCancel: false,
            timeout: CONFIG.abShuntTimeout,
            useLocalCache: CONFIG.abShuntLocalTime,
            headers: {
                'Content-Type': 'application/json'
            },
        });

        if (res && res.result) {
            return res.result;
        }

        throw new Error('bts data error !!');
    }
};


export {
    isCategoryPage,
    isSearchPage,
    searchCateABTest
};
