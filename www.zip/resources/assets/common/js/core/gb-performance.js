/**
 * 前端性能上报（基础服务）
 * 注：一般来说你只需要单例操作，不要new! 不要new! 不要new!
 * Created by Jiazhan Li on 2018/12/03.
 */

export default class Performance {
    /**
     * 对外初始化方法（单例模型）
     */
    static init(param) {
        if (!Performance.instance) {
            Performance.instance = new Performance(param);
        }
        return Performance.instance;
    }

    constructor(param = {}) {
        // 配置
        this.config = Object.assign({
            on: false, // 开关，默认关闭
            rate: 0.001, // 全站统一抽样数据比例（默认千分之一）
            size: 0, // 单次上报数据大小（默认不限制，当你使用GET方式上报时，这个值一般不能太大，比如设置 2048 = 2K）
            interval: 0, // 定时监听的毫秒数，如果该值大于零，将在页面打开的整个生命周期持续监听新的资源数据，不然只会执行一次上报操作
            rules: [], // 数据筛选规则列表（必填项，否则所有资源均不会通过筛选）
            service(data) { console.log(data); }, // 每次上报的数据，谁知道你想通过什么方式传给服务器，所以自己搞定吧
        }, param.config);

        // 任务队列
        this.TASK = [];

        // 待上报数据（公共部分）
        this.commonData = Object.assign({
            type: 1, // 1-全站统一抽样数据；2-自定义上报数据
        }, param.data, {
            id: Performance.guid(), // 全局唯一标识符（放在这里的目的是防止外部参数覆盖）
        });

        if (this.config.on && Math.random() < this.config.rate) {
            // 执行第一次数据上报
            this.checkEntries();

            // 如果你配置 interval 这个参数，将会定时监听 this.TASK 任务队列里面的值，一旦发现符合条件的资源将会持续上报
            if (this.config.interval > 0) {
                setInterval(() => {
                    this.checkEntries();
                }, this.config.interval);
            }
        }
    }

    /**
     * 检索资源加载列表（window.performance.getEntries()）是否产生新数据，
     * 如果有，将会对多出来的这部分新数据进行筛选，满足条件的资源添加进任务队列，等待上报
     */
    checkEntries() {
        this.entryIndex = this.entryIndex || 0; // 记录当前待检索的资源索引
        const entries = window.performance.getEntries().slice(this.entryIndex);

        // 如果有新资源的话
        if (entries.length > 0) {
            this.entryIndex += entries.length; // 更新记录当前索引
            entries.forEach((entry) => {
                // 过滤无用资源，如 paint 资源
                if (['navigation', 'resource'].indexOf(entry.entryType) >= 0) {
                    this.addEntryTask(entry);
                }
            });
            this.pack();
        }
    }

    /**
     * 针对单个资源，如果资源满足筛选条件，则将其性能数据添加到任务队列
     */
    addEntryTask(entry) {
        // 将小数精度精确到2位
        const fix = (num = 0) => (+(+num.toFixed(2)));

        // 首个资源（页面资源）的性能参数
        this.navigationTiming = this.navigationTiming || window.performance.getEntries()[0] || {};

        // 首屏渲染时间
        this.firstPaint = this.firstPaint || window.performance.getEntries().find(item => item.name === 'first-paint').startTime || 0;

        // 过滤资源，其中 rules 需在调用的时候传入筛选规则，作为公用组件，我根本不知道你想筛选哪些资源
        // 你可以传入函数、字符串或数字、数组、正则表达式
        const isMatch = this.config.rules.some(someRule => Object.entries(someRule).every(([key, value]) => {
            if (typeof value === 'function') return value(entry[key]);
            else if (['string', 'number'].indexOf(typeof value) >= 0) return entry[key] === value;
            else if (value.length > 0) return value.some(item => entry[key] === item);
            else if (value.test) return value.test(entry[key]);
            return false;
        }));

        if (isMatch) {
            // 如果满足筛选条件的话，我们需要上报以下内容，这些都是资源加载时的一些性能数据，
            // 时间精度我们控制到保留小数点后两位，减少上报数据大小
            this.TASK.push(Object.assign({
                url: entry.name,
                refer: entry.entryType === 'navigation' ? document.referrer : this.navigationTiming.name,
                initiatorType: entry.initiatorType,
                actionType: this.navigationTiming.type || '',
                domContentLoadedEventEnd: fix(this.navigationTiming.domContentLoadedEventEnd),
                loadEventEnd: fix(this.navigationTiming.loadEventEnd),
                firstPaint: fix(this.firstPaint),
                startTime: fix(entry.startTime),
                fetchStart: fix(entry.fetchStart),
                domainLookupStart: fix(entry.domainLookupStart),
                domainLookupEnd: fix(entry.domainLookupEnd),
                connectStart: fix(entry.connectStart),
                secureConnectionStart: fix(entry.secureConnectionStart),
                connectEnd: fix(entry.connectEnd),
                requestStart: fix(entry.requestStart),
                responseStart: fix(entry.responseStart),
                responseEnd: fix(entry.responseEnd),
            }, (() => {
                // this.commonData 中的值不一定是字符串或者数字类型，我们允许他是个回调函数，
                // 当使用者传入一个对象时，我们还需要把它转成一个JSON字符串
                const data = {};
                Object.entries(this.commonData).forEach(([key, value]) => {
                    if (typeof value === 'function') data[key] = value(entry);
                    else if (typeof value === 'object') data[key] = JSON.stringify(value);
                    else data[key] = value;
                });
                return data;
            })()));
        }
    }

    /**
     * 将当前任务队列中的数据批量打包为合适大小的包，数据将以包为单位上传，可以减少上报请求数
     * 每次打包后将任务队列清空
     */
    pack() {
        if (this.TASK && this.TASK.length > 0) {
            const packages = [];
            if (this.config.size) {
                let totalSize = this.config.size; // 初始值设为这个值可以简化代码流程
                this.TASK.forEach((t) => {
                    const unitSize = JSON.stringify(t).length;
                    if (totalSize + unitSize < this.config.size) {
                        totalSize += unitSize;
                        packages[packages.length - 1].push(t);
                    } else {
                        totalSize = unitSize;
                        packages.push([t]);
                    }
                });
            } else {
                packages.push([]);
                this.TASK.forEach((t) => {
                    packages[0].push(t);
                });
            }

            this.TASK = []; // 清空任务队列

            // 以包为单位上传
            packages.forEach((item) => {
                this.send(item);
            });
        }
    }

    /**
     * 上报数据，直接请求上报接口，支持批量操作
     * @param data 待上报数据
     */
    send(data) {
        if (data) {
            // 如果是单个上报对象，将其转为数组格式，确保服务器接收到的永远是一个数组，方便服务器做拆分操作
            if (typeof data === 'object' && !data.length) data = [data];
            this.config.service(data); // 交给回调函数去上传到服务器
        }
    }

    /**
     * 生成全局唯一标识符（UUID）
     * 由当前时间戳加12位十六进制随机数组成
     */
    static guid() {
        const S4 = () => (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        return `${+new Date()}-${S4() + S4() + S4()}`;
    }
}
