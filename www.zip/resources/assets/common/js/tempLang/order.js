/* eslint-disable */

export default {
    /* 以下内容引用于结算流程 --- 订单确认页 */
    // 页面标题
    shipping_information: 'Shipping Information',
    // 顶部地址
    name: 'Name',
    address_line_one: 'Address Line 1',
    address: 'Address',
    zip_postal_code: 'ZIP / Postal Code',
    phone_number: 'Phone Number',
    mail_address: 'E-mail Address',
    edit_shipping_address: 'Edit Shipping Address',
    edit: 'Edit',
    // 订单列表
    split_order_notice: 'Note：We have split the order for you because of different warehouse',
    table_price: 'Selected Items',
    table_num: 'Unit Price',
    table_total: 'Quantity',
    table_oper: 'Subtotal',
    goods_color: 'color',
    goods_size: 'size',
    goods_flash_sale: 'flash sale',
    goods_email_only: 'email only',
    goods_presale: 'presale',
    goods_arrival_notice: 'arrival notice',
    goods_redeem: 'redeem',
    goods_accessory: 'accessory',
    goods_gift: 'Gift',
    changes_in_stock: 'Changes in stock',
    price_disclaimer: 'Price Disclaimer',
    price_tip: 'Prices may fluctuate due to page caches, updates or sales ending; the most up-to-date price takes priority.',
    second_address_tip: 'Please include your Passport information for your selected Shipping Method (to facilitata clearance of goods)',
    place_middle_name: 'Consignee Middle Name',
    place_passport_serial: 'Consignee Passport Serial',
    place_passport_number: 'Consignee passport Number',
    place_passport_issue_date: 'Passport Issue date',
    place_issued_by: 'Issued by',
    place_tax_id: 'Tax ID',
    middle_name: 'Middle Name',
    passport_serial: 'Passport Serial',
    passport_number: 'Passport Number',
    passport_issue_date: 'Passport issue date',
    passport_issue_tip: 'Your date is incorrect.',
    issued_by: 'Issued by',
    tax_id: 'Tax Number',
    save: 'Save',
    total: 'Total',
    goods_weight: 'Weight',
    shipping_options: 'Shipping Options',
    insurance: 'Insurance',
    notice_shipping_title: 'What\'s The Total Delivery Time?',
    notice_shipping_content: `
        Total Delivery Time = Processing Time + Packing Time + Shiping Time. </br>
        Note: To get a safe delivery,we recommend to buy insurance to guarantees your shipment.
        INthe event of verified shipping damage/loss, Gearbest will resend an identical parcel free of charge.
    `,
    remote_fee: 'Already included in the remote fee',
    business_days: 'business days',
    no_tracking_number: 'No tracking number',
    shipping_method: 'Shipping Method',
    total_ost: 'Total Cost',
    place_your_order: 'Place Your Order',
    place_order: 'Place Order',
    have_discount: 'Have discount',
    dropping: 'Dropshipping',
    item_sub_total: 'Item Sub-total',
    gb_points_disscount: 'GB Points Disscount',
    coupon: 'Coupon',
    shipping_cost: 'Shipping Cost',
    promotion: 'Promotion',
    payment_discount: 'Payment discount',
    cod_cost: 'cod Cost',
    cod_discount: 'cod Discount',
    cod_shipping_limit_tip: 'Sorry, you already have 2 unfinished COD order. Please place the order after the package is received and paid',
    tax_price: 'GST',
    grand_total: 'Grand Total',
    guide_insurance: 'Note: For safer delivery, please buy the tracking & insurance fee. In cases of verified shipping loss/damage GB will resend for free.',
    total_giveintegral: 'Earn <em>:#$1#</em> GB points',
    // 优惠方式
    choose_points: 'GB Points',
    use_points: 'Use GB Points',
    want_to_use: 'I want to use',
    use_points_discount: 'Save More: You can use up to :#$1# GB Points( Worth :#$2# ) from your account for a further discount.',
    discount_tip: 'Every order you palce with us is completely safe and secure!',
    apply: 'Apply',
    use_coupon: 'Use Coupon',
    type_coupon_code: 'Type coupon code',
    for_select_items_only: 'For Select Items Only',
    expried: 'Expried',
    input_code_to_use_it: 'Input code to use it',
    available_oupon: 'Available Coupon',
    no_available_coupons: 'No Available Coupons',
    no_use_coupon: 'Don’t want to use coupon',
    coupon_invalid: 'Voucher null and void',
    subtotal_over: 'Subtotal over',
    only_on_unit: 'ONLY for 1st Unit',
    fixed_price: 'Fixed price',
    subototal_over: 'Subototal over',
    coupon_off_over: 'off over',
    coupon_unit_s: 'unit(s)',
    coupon_off: 'off',
    coupon_after: 'after coupon',
    goods_clearance: 'Clearance',

    // 弹窗按钮
    to_pay_page: 'To Pay Page ',
    submit: 'Submit',
    cancel: 'cancel',
    to_edit_address: 'To Edit Address',
    success: 'Success',
    error: 'Error',
    choice_paymode: 'Choice of payment method',
    back_shoping_cart: 'Back Shoping Cart',
    back_to_cart: 'Back to cart',
    pleace_include: '请填写以下内容',
    // 结算页地址校验弹窗提示
    check_edit_address: 'Edit Address',
    check_edit_tips: 'Your shipping address does not meet the shipping company\'s requirements',
    check_edit_btn: 'Edit the address',
    check_edit_to_address: 'The address details are incorrect. Please update the information. ',
    // 物流关税提示
    logistics_tariff_tip: 'The price offered by DHL does not include customs duties. Please cooperate with the customs if so requested. Thanks',
    // 满额免邮提示
    logistics_freeship: 'Get More <em>:#$1#</em> To Enjoy <em>FREE SHIPPING</em> <span>(Notice: ONLY For Apparel Bags & Shoes Watches & Jewelry Items)</span>',
    logistics_freeship_tip: 'Free postal activities do not include remote fees and duties',
    // 前置支付方式
    pay_channels_title: 'Payment Method(s)',
    pay_channels_tip: 'No payment method is available due to legal restrictions, regulations and channels.',
    // 针对巴西特殊收费提示
    special_fee_brazil: `
        Notice: Dear Customer, we inform you that since August 28 of this year,
        the Correios do Brasil has been charging a fee of 15 reais on all international orders.
    `,
    // 定金膨胀
    depoist_goods_choose: 'to save',
    depoist_goods: 'Deposit',
    depoist_no_discount: 'Note: Points and Coupons  cannot be applied to deposit-to-presale items;<br/> Final Payment includes shipping costs, insurance and taxes.',
    depoist_clause_tip: 'You cannot purchase until you agree and acknowledge that your desposit is non-refundable.',
    depoist_clause_text: 'I agree and acknowledge that my desposit is non-refundable.',
    depoist_rules: `
        <h6>Rules</h6>
        <ul>
            <li>Payments will be split into two: initial deposit and final payment.</li>
            <li>
                For even bigger savings, GearBest applies a “deposit expansion”;
                this is a FREE bonus that increases your deposit. The exact amount
                of this increase depends on the specific product.
            </li>
            <li>The remaining balance must be paid within the specified deadline. </li>
            <li>
                Failure to pay the balance before the deadline will see the original
                deposit retained and the order cancelled.
            </li>
            <li>
                For the final payment of the balance, points and coupons cannot
                be used. However, different payment methods can be used and/or
                offline payment are welcome.
            </li>
            <li>
                GearBest reserves the right to amend the guidelines for this
                payment scheme. If you have any questions, please contact our
                Support Staff. (https://support.gearbest.com/)
            </li>
            <li>
                Final Price is the actual amount paid for the item, which equals
                deposit and final payment.
            </li>
            <li>
                (Worked example). Price: $100 ($5 deposit saves $10). The final
                payment: $85=100-10-5. So the final Price: $90=85+5 (Note: this
                applies to item cost only and excludes any tax fee, shopping fee
                and insurance fee.)
            </li>
        </ul>
    `,
    // 定金膨胀明细面板
    depoist_stage: 'Stage',
    depoist_title: 'Deposit',
    depoist_final_payment: 'Final Payment',
    depoist_count_down: 'The booking ends in :#$1# days :#$2#',
    depoist_balance_due: 'Balance Due',
    depoist_discount: 'Discount',
    depoist_actual_payment: 'Actual payment',
    // 结拦截生单弹窗
    depoist_created_alert_tip: 'Please register first before purchasing products that enjoy "deposit expansion".',
    depoist_created_alert_to_register: 'Register now',
    depoist_created_alert_later: 'Later',
    // cod 货到付款
    cod_online_payment_title: 'Online Payment',
    cod_online_payment_note: 'Wire Transfer, Gredit or debit card, paytm, Google Pay, Credit or debit Card.',
    cod_cash_on_delivery: 'Cash on Delivery',
    cod_cash_on_delivery_note: 'There is an additional fee (US$10.00) for this service.',
    cod_cash_on_delivery_tip: 'Payment upon Receipt is a payment method offer for our  customers in UAE, Saudi Arabia. To be eligible for Payment upon Receipt, the Total Price payable (price after discounts) must be between 50 and 400 USD.',
    // 短信验证弹窗
    cod_sms_alert_title: 'Determine',
    cod_sms_alert_top: 'Upon receiving the package,  please pay :#$1# in Cash. Payment must be made in full with cash. We will send an SMS containing the code, please check your phone.',
    cod_sms_alert_send_btn: 'Send SMS',
    cod_sms_alert_note: 'If you do not receive an SMS message, please contact our Customer Serveive Staff.',
    cod_sms_alert_check_btn: 'Check Out',
    cod_sms_alert_bottom: 'In the event of receipt failure, please check the address details and mobile  numberyou entered.',
    cod_sms_alert_err_empty: '验证码不可以为空',
    cod_sms_alert_input_place: 'Validation Code',

    // --- only PC start ---
    promotion_code: 'Promotion Code',
    how_to_use_points: `
        <p>How to Use Points?</p>
        1. 50 Points = $1.00</br>
        2. You can use points for discount if you have at least 50 points.</br>
        3. The discount (from the Points) cannot exceed 30% of the item sub-total cost. (Note: Selected promos may have a different cap.)</br>
        4. Coupons cannot be used together with Points to reduce prices.</br>
        5. Taking cash from “My GB Wallet” costs 1X Points value. For example: $5 will cost 5 Points.</br>
    `,
    // --- only PC end ---

    /* 以下内容引用于结算流程 --- 支付结果页 */
    // --- 支付状态标题
    payment_successful: 'Payment Successful!',
    payment_pending: '正在支付',
    payment_failed: 'Payment Failed!',
    payment_refund: '退款',

    // --- 订单信息
    payment_paid: 'Paid',
    payment_need_to_pay: 'Need to Pay',
    payment_order_no: 'Order No',
    payment_failed_tip: 'System is busy, please try again later.',
    payment_successful_title: 'We Appreciate Your Shopping! Your order has been paid successfully.',
    payment_successful_info1: 'Please remember your order number',
    payment_successful_info2: 'The payment amount is',
    payment_successful_tip: `
        For your safety, we contact you to confirm your order details. If you do, please reply us as soon as possible for a faster shipment. Thanks!
    `,

    // --- 按钮
    payment_check_my_order: 'Check my Order',
    payment_contact_us: 'Contact Us',
    payment_check_bank: 'Check bank details',
    payment_bank_btn: 'Check :#$1# details',
    payment_print: 'Print',
    payment_info: 'Info',
    payment_try_again: 'Try Again',
    payment_message_us: 'Message Us',
    payment_continue_to_payment: 'Continue to payment',

    // --- 线下支付提示语
    payment_line_tip_title: 'Order will be expired within',
    payment_line_tip_text: 'days.Please pay as soon as possible.',
    payment_line_tip_content: `
        Normally payment takes 3-4 days to confirm, please be patient.Any problems regarding your payment, you are welcome to contact us directly
    `,
    payment_line_bankinfo_title: 'Shroff Account number',
    payment_offline_agt_tip: 'Please print your Voucher and pay it at corresponding store within 3 days. Any problems regarding your payment, you are welcom to contact us directly.',
    payment_offline_zl_tip: 'Please print your Voucher and pay it at Servipag store within 3 days. Any problems regarding your payment, you are welcom to contact us directly.',
    payment_offline_in_tip: 'Please kindly check your payment code in your email sending by Payment company and follow the instruction to pay your order.',

    // --- only PC start ---
    payment_offline_tip: '<em>Note:</em> simply contact us at support center. We will help you to complete the payment process.'
    + '</br>Thank you for your purchase.',

    payment_offline_bo_title1: 'Muito obrigado por fazer compras conosco!',
    payment_offline_bo_title2: 'Seu pedido <em>:#$1#</em> já foi recebido!',
    payment_offline_bo_urltxt: 'Imprima o :#$1# Bancario',
    payment_offline_bo_conten: 'Pagá-lo em qualquer banco,'
    + ' loja de loteria ou em seu banco de Internet , você tem 3 dias para completar o seu pagamento.',
    payment_offline_bo_note: 'Note',
    payment_offline_bo_notetxt: 'Seu estado do pedido irá tornar para '
    + '" em processamento" dentro de 1-2 dias úteis depois de verifica o seu pagamento.'
    + ' Talvez alguns pedidos devem exigir o tempo adicional para verificar. Por favor, tenha paciência conosco e seja paciente.',
    payment_offline_bo_tip: 'Dicas: Se você quer saber o estado dos pedidos ou tem algumas problemas, encontre-nos em Messenger.',
    payment_offline_bo_btn: 'Volta para a minha conta',

    payment_offline_gc_conten: 'You can pay Bank Transfers via one of the following methods with the above provided Bank Transfer information:</br>'
    + '1. Online banking</br>'
    + '2. Phone banking(also known as tele-banking)</br>'
    + '3. Mailing a payment form to the bank</br>'
    + 'Visiting the bank and completing payment form in person</br>'
    + 'Please notice that it may require 3-5 days for payments to be confirmed'
    + 'customers who have made payments in your bank,'
    + ' please kindly wait 3-5 days or send us the bank receipt through tickets for payment confirmation.',
    payment_offline_gc_banktip: 'For the purpose of fast matching your payment,'
    + 'please make sure that the payment reference number is submitted to your bank correctly',
    payment_offline_mu_conten: 'Simply contact us at Support Center. We will help you to complete the payment process.</br>'
    + 'Thank you for your purchase.',

    // 普通线下支付标题
    payment_offline_title: 'We Appreciate Your Shopping!',
    // 线上支付新增分享提示
    payment_success_share_tip: 'SHARE NOW:Tell Friends about your COOL GearBest Gear + WIN a Prize',
    payment_failed_help: 'Need help ? ( <a href=":#$1#"><em>Payment FAQ</em></a> / <a href="javascript:;" onclick="$(\'.liveChatBtnHidden .LPMlabel\').trigger(\'click\');"><em>Start Online Chat</em></a> )',
    // --- only PC end ---

    // --- 公共提示文案
    payment_to_messenger: 'Go to messenger',
    payment_click_to_mes: 'Click to track shipping at anytime.',
    payment_click_to_mes_tip: 'Tips: Click Messenger, Get a chance to WIN a phone, and track shipping at anytime.',
    payment_cancelled_tip: 'Sorry, your order was canceled when payment was made. If payment is successful, our Customer Support Team will process your refund using the same payment method.',
    payment_company_days: 'days',
    payment_coupon_tip: 'Order payment successful, a special offer will be given after you confirm order receipt.',

    // 后置礼包
    payment_special_notes: 'Special Notes',
    payment_enter: 'Enter',
    payment_my_coupon: 'My coupon',
    payment_to_view: 'page to view your coupon',

    /* 以下内容引用于快捷购物流程 --- 新支付结果页 */
    // 支付信息
    quickbuy_payinfo_title: 'We Appreciate Your Shopping! Your order has been paid successfully.',
    quickbuy_payinfo_content: 'Please remember your order number: <b>:#$1#.</b> The payment amount is: <b class="org">:#$2#</b>',
    quickbuy_payinfo_copy: 'Copy',
    quickbuy_payinfo_copy_tip: 'Click to save the order number, this is required when contacting our customer support.',
    quickbuy_payinfo_copy_success: 'copy success',
    // 设置账户
    quickbuy_config_title: 'Confirm registration information',
    quickbuy_config_err_tip: 'Kindly know that this email has been registered, please try another new email address.',
    quickbuy_config_email: 'Email',
    quickbuy_config_change: 'change',
    quickbuy_config_tips: 'Tips',
    quickbuy_config_tip_txt: 'To better understand your order details and improve your shopping experience, please improve your personal information',
    quickbuy_config_save: 'Save',
    quickbuy_config_clause: 'I agree to Gearbest <a href=":#$1#/about/terms-and-conditions.html" target="_blank">Terms and Conditions</a> and <a href=":#$2#/about/privacy-policy.html" target="_blank">Privacy Policies</a>',
    quickbuy_config_clause_eu: 'I confirm all information provided is my own; I understand and agree it will be used as per the GearBest <a href=":#$1#/about/privacy-policy.html" target="_blank">Privacy Policy</a>; I can withdraw my prior consent at any time',
    // 校验提示语
    quickbuy_config_clause_error: "To complete the registration, you must agree to gearbest's website Terms and Conditions.",
    quickbuy_config_clause_eu_error: 'To complete registration, you must provide your consent to the above.',
    quickbuy_config_email_reg: 'The email must be a valid email address.',
    quickbuy_config_email_require: 'Please enter a valid email address',
    quickbuy_config_psd_reg: 'Must be at least 8 characters; please use at least 2 types (letters, numbers, or special characters)',
    quickbuy_config_psd_require: 'Please enter password',
    quickbuy_config_psd2_reg: 'Please enter the same value again.',
    quickbuy_config_psd2_require: 'Repeat your password',
    quickbuy_config_email_title: 'E-mail address',
    quickbuy_config_psd_title: 'Enter a password',
    quickbuy_config_psd2_title: 'Comfirm password',
    // 账户设置成功
    quickbuy_finish_title: 'Please activate your account!',
    quickbuy_finish_section: 'our account is awaiting activation. We wiil resend the activation email to help you complete your registration.',
    quickbuy_finish_email_address: 'Email address',
    quickbuy_finish_btn_resend: 'Resend Verification Email',
    quickbuy_finish_btn_change: 'Change Email Address',
    quickbuy_finish_count_down: '剩余倒计时： :#$1#',
    // 弹窗内容
    quickbuy_alert_title: 'Please verify with your original registered password',
    quickbuy_alert_oldpwd_title: 'password',
    quickbuy_alert_oldpwd_require: 'Please enter password',
    quickbuy_alert_oldpwd_err: 'Please input the correct password.',
    quickbuy_alert_newemail_title: 'New Email',
    quickbuy_alert_newemail_require: 'Please enter a valid email address',
    quickbuy_alert_newemail_reg: 'The email must be a valid email address.',
    quickbuy_alert_newemail_err: 'This email address has already been registered.',
    // 支付进入弹窗提示
    quickbuy_alert_enter_title: 'Help us to help you',
    quickbuy_alert_enter_conten: `
        Please be sure to provide accurate registration information.
        This helps us to deal quickly and efficiently with order changes,
        returns, lost packages, and other unexpected events.
        This also allows you to contact our helpful customer service team with your order information.
    `,

    // add by lijiazhan
    edit_address: 'Edit',
    order_all: 'All',
    order_unpaid: 'Unpaid',
    order_notshipped: 'Not shipped',
    order_partly_shipped: 'Partly shipped',
    order_shipped_out: 'Shipped out',
    order_delivered: 'Delivered',
    order_review: 'Review',
    order_refunded: 'Refunded',
    product_name_or_number: 'Product name / number',
    description: 'Description',
    unit_price: 'Unit Price',
    status: 'Status',
    order_list_subtotal: 'Subtotal',
    operation: 'Operation',
    you_have_no_order_yet: 'You have no order yet',
    go_shopping: 'Go Shopping',
    order_canceledz_payment_not_received_notice: 'Note: Order canceled,payment not received withined :#$1#',
    order_no: 'Order No',
    order_will_be_canceled_notice: 'Order will be canceled within :#$1# ,please submit payment as soon as possible.',
    button_order_detail: 'Detail',
    qty: 'Qty',
    price_type_accessory: 'Accessory',
    price_type_gift: 'Gift',
    price_type_add_on_item: 'Add-on item',
    price_type_email_only: 'Email Only',
    price_type_flash_sale: 'Flash Sale',
    status_wait_for_payment: 'Wait for payment',
    status_partialpay: 'Partial pay',
    status_paid: 'Paid',
    paid_notice: 'Paid：Your order ships soon , Thank you so much for your patience.',
    status_packed: 'Packed',
    packed_notice: 'Your order ships soon ,Thank you so much for your patience.',
    status_shipped_out: 'Shipped out',
    status_delivered: 'Delivered',
    delivered_notice: 'Delivered:Write a quick review now & get 5GB points',
    status_refunding: 'Refunding',
    status_refunded: 'Refunded',
    status_cancelled: 'Cancelled',
    status_deleted: 'Deleted',
    status_pending: 'Pending',
    status_partly_shipped: 'Partly shipped',
    status_apply_for_refund: 'Apply for refund',
    status_reviewed: 'Reviewed',
    button_continue_to_pay: 'Continue to pay',
    button_cancel: 'Cancel',
    button_contact_us: 'Contact us',
    button_send_message: 'Send/View Message',
    button_dispatch_faster: 'Dispatch Faster',
    button_confirm_receipt: 'Confirm Receipt',
    button_review: 'Review',
    button_continue_shopping: 'Continue Shopping',
    button_boleto_bancario: 'Check boleto voucher',
    button_oxxo: 'Check OXXO voucher',
    button_pago_efectivo: 'Check Pago Efectivo voucher',
    button_bank_transfer: 'Bank Transfer',
    dispatch_faster_notice: '1. We process your order faster; it will leave our warehouse faster. 2. We will not change shipping method, shipping speed is outside our control.',
    button_tracking: 'Track your shipment',
    button_rma: 'After-Sales Application',
    are_you_sure_cancel_your_order: 'Are You Sure Cancel Your Order?',
    choose_order_cancel_reason: 'Please Choose the Reason Why You Cancel Your Order',
    refund_desc: 'Your goods are about to be issued. We suggest you wait a moment.',
    button_wait: 'Wait',
    reconfirm_receipt: 'Do you confirm receipt?',
    dispatch_faster_success: 'Success！ We will process your order as soon as possible.',
    dispatch_faster_failed_notice: 'Your "Dispatch Faster" request has failed due to server error. For any queries, please contact our <a class="link" href=":#$1#" target="_blank">Support Center</a>.',
    progress_bar_order_submitted: 'Order Submitted',
    progress_bar_payment_received: 'Payment Received',
    progress_bar_packed: 'Packed',
    progress_bar_split_delivery: 'Split Delivery',
    progress_bar_product_dispatch: 'Product Dispatch',
    progress_bar_apply_for_refund: 'Apply For Refund',
    progress_bar_refunding: 'Refunding',
    progress_bar_refunded: 'Refunded',
    progress_bar_order_cancelled: 'Order Cancelled',
    order_detail_consignee_name: 'Consignee name',
    order_detail_contact_telephone: 'Contact telephone',
    order_detail_receipt_address: 'Receipt address',
    e_mail: 'E-mail',
    city: 'City',
    state_county_province: 'State/County/Province',
    zip: 'Zip',
    order_date: 'Order date',
    payment: 'Payment',
    invoice: 'Invoice',
    deliveries: 'Deliveries',
    swiftcode: 'SWIFTCODE',
    special_id: 'Special ID',
    your_chosen_payment_method_notice: '<p class="offlineBill_text">Your chosen payment method is: <em>:#$1#</em>. The payment amount is: <strong>:#$2#</strong>.</p><p class="offlineBill_text">Simply contact us at <a href=":#$3#">Support Center</a>, We will help you to complete the payment process.</p><p class="offlineBill_text">Thank you for your purchase.</p>',
    please_pay_within: 'Please pay within',
    shipping_methods: 'Shipping Methods',
    favorites_no_store_1: `You currently don't have any favorites.`,
    favorites_no_store_2: 'Add stores to your favorites by clicking <i class="icon-collection"></i> on the stores page!',
    track_order_number: 'Track order :#$1#',
    shippment_number: 'Shippment Number',
    tracking_number: 'Tracking Number',
    transfer_number: 'Transfer Number',
    by_update: 'By Update',
    download_invoice: 'Download Invoice',
    issue_invoice: 'Issue an invoice',
    tips_expired_invoice: `Cuz it's over 30 valid days to issue invoice,please contact customer service to apply.`,
    trcking_message: 'Trcking message',
    get_point: 'Get Point :#$1#',
    bank_info_note: 'For the purpose of fast matching your payment ,please make sure that the payment reference number is submitted to your bank correctly.',
    bank_info_desc: `You can pay Bank Transfers via one of the following methods with the above provided Bank Transfer information:
                    <br>1. Online banking
                    <br>2. Phone banking (also known as tele-banking)
                    <br>3. Mailing a payment form to the bank
                    <br>4. Visiting the bank and completing payment form in person
                    <br>
                    <br>Please notice that it may require 3-5 days for payments to be confirmed ,customers who have made payments in your bank ,please kindly wait 3-5 days or send us the bank receipt through tickets for payment confirmation.`,
    payment_reference: 'Payment Reference',
    swift_code: 'SWIFTCODE',
    iban: 'IBAN',
    bank_name: 'Bank Name',
    bank_account: 'Bank Account',
    account_holder: 'Account Holder',
    blz: 'BLZ',
    a_reference: 'A reference',
    an_entity: 'An entity number',
    payable_amount_val: 'Payable amount value',
    expiry_date: 'Due date/Expiry date',
    multibanco_tips: 'Please pay your order within :#$1# days.',
    pending_tip: 'There is a little delay for payment status confirmation, please come back to check your order status a few minutes later.',
    please_select_a_aeason: 'Please Select a Reason',
    order_return_coupon: 'You will have a new coupon',
    order_detail_return_coupon: 'Order is successful, you have a new coupon, will be automatically presented after the order is signed.',
    payment_local_btn: 'Check :#$1# Voucher',
    country_specific_bank_key: 'Country specific bank key(s)',
    tracking_web: 'Tracking Web',
    button_issue: 'Issue',
    invoice_title: 'Invoice title',
    personal: 'Personal',
    company: 'Company',
    billing_adress: 'Billing adress',
    use_shipping_address: 'Use shipping address',
    use_another: 'Use another',
    receiveName_required_msg: 'Please insert invoice title',
    tips_error_invoice: `Billing failed, please try again.`,
    generating: 'Generating',
    tips_generating: 'Invoice generation is expected to be generated within 2 hours. Please download later.',

    // 定金膨胀相关文案
    note_cancel_deposit: '<em>Note:</em>The order was cancelled due to non-payment of deposit.',
    note_cancel_final_payment: '<em>Note:</em>The order was cancelled due to non-payment of remaining balance.',
    deposit: 'Deposit',
    final_payment: 'Final Payment',
    deposit_save: 'Deposit :#$1# to save :#$2#',
    the_period_for_final_payment: 'The period for final payment: :#$1#',
    button_pay_deposit: 'Pay a deposit',
    button_pay_final_payment: 'Pay final payment',
    not_allow_to_pay_final_payment: 'Sorry, the final payment is not ready yet.',
    stage: 'Stage :#$1#',
    not_yet_paid: 'Not yet paid',
    completed: 'Completed',
    goods_final_amount: 'Balance Due',
    totalswell_discount: 'Discount',

    // Wire Transfer支付方式
    wire_transfer_acc_name: 'Account name',
    wire_transfer_acc_nameval: 'YOUSONGTONG E-COMMERCE (HONGKONG) LIMITED',
    wire_transfer_acc_number: 'Account number',
    wire_transfer_acc_numberval: 'OSA90000323435100',
    wire_transfer_bank_name: 'Bank name',
    wire_transfer_bank_nameval: 'BANK OF COMMUNICATIONS CO.,LTD OFFSHORE BANKING UNIT',
    wire_transfer_acc_add: 'Account address',
    wire_transfer_acc_addval: 'NO 188,YINCHENG ZHONG ROAD,SHANGHAI,CHINA',
    wire_transfer_swift_code: 'SWIFT Code',
    wire_transfer_swift_codeval: 'COMMCN3XOBU',
    wire_transfer_conten_tip: `Once paid, please contact our <a href=":#$1#">Support Center</a> with the order number,
                            the bank receipt and amount you sent.`,

    // cod 付款方式
    cod_payment_method_tip: 'Your chosen payment method is',
    cod_payment_notice: 'Simply contact us at support center. We will help you to complete the payment process. Thank you for your purchase.',
    cpd_return_tips: 'Or you can return to <a class="org" href=":#$1#">Home</a> or <a class="org" href=":#$2#">My Account</a>',
    cod_discount: 'cod discount is',

    // 新增第三方订单按钮

    seller_refund: 'Request a Refund',
    contact_seller: 'Contact Seller',
    choose_refund_reason: 'Please Choose Reason.',
    store: 'Store',
    contact_the_seller: 'Contact the seller',
    order_ended: 'ended'
};
