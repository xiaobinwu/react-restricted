/**
 * Created by Liu.Jun on 2018/2/27.
 */

export default {
    max_per_order: 'Max per order',
    sold_out: 'Sold out',
    one_pc: '1PC',
    more_pcs: ':#$1#PCS',

    jan_date: 'JAN :#$1#',
    feb_date: 'FEB :#$1#',
    mar_date: 'MAR :#$1#',
    apr_date: 'APR :#$1#',
    may_date: 'MAY :#$1#',
    jun_date: 'JUN :#$1#',
    jul_date: 'JUL :#$1#',
    aug_date: 'AUG :#$1#',
    sep_date: 'SEP :#$1#',
    oct_date: 'OCT :#$1#',
    nov_date: 'NOV :#$1#',
    dec_date: 'DEC :#$1#',

    promo_begins_in: 'Promo begins in:',
    promo_ends_in: 'Promo ends in:',
    days_h_m_s: '<b>:#$1#</b> days <b>:#$3#::#$2#::#$4#</b>',

    i_got_it: 'I Got It',

    error_report: 'Error Report',
    make_gearbest_better: 'Make Gearbest even better and WIN.',
    report_error_tip1: `If you find an error on this product page, let us know below. We'll check 
    the information within 2 working days.The most helpful comments will receive some awesome rewards.`,
    report_error_tip2: `For queries relating to orders, shipping and other pre-sale or after-sales issues,
     please submit a ticket on our <a href=":#$1#" target=":#$2#" class="goodsPop_reportTipLink">support page</a> instead.`,
    type_of_error: 'Type of Error',
    email: 'Email',
    details: 'Details',

    color: 'Color',
    size: 'Size',

    between_business_days: ':#$1# business days',

    recv_coupon_tip: 'Please check it in your GB account - <a href=":#$1#" target=":#$2#">My Coupon</a>',
    no_more_shipping_method: 'No more shipping method',
    cost_to_country_via_name: ':#$1# to :#$2# Via :#$3#',
    choose_another_country: 'Choose another country',
    payment_discount: 'Payment Discount',
    cant_use_paypal_tip: 'Sorry, the item amount has exceeded the limit and cannot be paid using Paypal',
    flash_sale: 'FLASH SALE',
    email_only: 'Email Only',
    deposit_countdown: 'Deposit Countdown',
    promo: 'Promo',

    brands_title: 'Brands',
    brands_all: 'All Brands',
    brands_popular: 'Popular',
    brands_sort: 'Sort By:',
    brands_sort_hot: 'hot',
    brands_sort_new: 'new',
    brands_sort_trending: 'trending',
    brands_sort_price: 'price',

    flashsale_beginsin: 'Flash sale begins in',
};
