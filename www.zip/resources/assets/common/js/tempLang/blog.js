export default {
    google_share_text: 'GearBest: Online Shopping - Best Gear at Best Prices',
    no_more_products: 'No More Products!',
};
