
export default {
    collected: 'Collected',
    add_to_favorites: 'Add to Favorites',
    coupon_expired_tip: 'Coupons have expired!',
    no_cate_product_tip: 'There is no product under this category!',
    store_product_tip: 'Sorry, currently no products are available for this promotion!',
    no_more_product_tip: 'No more products',
    opera_tips: 'You click too fast, please try again later!',
    discount_off: 'OFF',
    copy_successed: 'Coupon successfully copied!',
    end_time: 'Ends in',
    start_time: 'Starts in',
    view_less: 'view less',
    view_more: 'view more',
    coupon_received_dec: 'My Coupon',
    coupon_received_dec1: 'Please check it in your GB Account',
    coupon_received_tip: 'Coupon Received!'
};
