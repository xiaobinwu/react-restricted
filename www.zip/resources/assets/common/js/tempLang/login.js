export default {
    validate_email_use: 'The email is already in use',
    validate_fb_email: 'Your facebook account doesn\'t have email,Please set a email first',
    auth_fail: 'Auth fail',

    link_email_tips_unregistered: 'An activation email has been sent to you. Please follow the prompts to activate your customer account.',
    link_email_resend: 'Resent successfully. Please check your email box to activate your account. After ' +
                                ':#$1# seconds,<br> you can resend it again.',
    // new
    link_email_tips_registered: 'The email address has been registered, please log in',
    link_email_defeated: 'The email address has is already in use; please use another.',

    // 第三方登陆button 按钮
    link_email: 'Link to email account now',
    resend_activation_email: 'Resend Activation Email',
    change_email: 'Change E-mail',
    button_sign_in: 'Sign In',
    link_email_succeed: 'Successfully linked',
    to_complete_the_registration_eu: 'To complete registration, you must provide your consent to the above.',

    // 访客模式 相关
    visitor_purchase_btn: 'Continue as a guest',
    visitor_faq_btn: 'Fast Shopping FAQ',
    visitor_faq_rules: `
        1. If you shop as a guest, you can skip the normal login process and start purchasing goods immediately.<br/>
        2. For the best possible shopping experience and to ensure your order is processed correctly, 
        please add your registration details following a successful purchase. 
        This gives you free access to our class-leading after-sales support and many additional benefits.<br/>
        3. Please add your order information to the new account after registering on the order completion page, 
        or via the link included in the order confirmation email.<br/>
        4. Once you complete your purchase, please keep your order information in a safe place to track the order progress/status.<br/>
        5. We will keep a record for up to three days for you; if more than three days have elapsed, 
        you will need to re-enter the address details.<br/>
        6. Please note: when you exit guest mode, you may lose your shopping cart record!<br/>
        7. Whenever you make a purchase, we will send the order information to your inbox. 
        You can contact Customer Support with your order information for an order status update.
    `,
    visitor_customer_service: 'Customer Service',
};
