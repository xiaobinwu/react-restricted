export default {
    google_share_text: 'GearBest: Online Shopping - Best Gear at Best Prices',
    promo_ends_in: 'Promo Ends In:',
    promo_start_in: 'Promo Start In',
    ends_in: 'Ends In:',
    begins_in: 'begins In:',
};
