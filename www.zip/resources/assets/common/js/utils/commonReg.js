/**
 * Created by Liu.Jun on 2018/2/23.
 */

// 密码 不会 或运算所以手动分开 哈哈哈哈哈哈
// export const regPassword = /(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[~`@#$%^&*\-_=+|\\?/()<>[\]{}",.;'!]).{8,30}/;

export const regPasswordArr = [
    /(?=.*[0-9])(?=.*[a-zA-Z]).{8,30}/,
    /(?=.*[0-9])(?=.*[~`@#$%^&*\-_=+|\\?/()<>[\]{}",.;'!]).{8,30}/,
    /(?=.*[a-zA-Z])(?=.*[~`@#$%^&*\-_=+|\\?/()<>[\]{}",.;'!]).{8,30}/,
];

export function testPassword(str) {
    const matchStr = String(str);
    return regPasswordArr.some(item => item.test(matchStr));
}

// 电话号码
export const regPhone = /^[+\-()\d]+$/;
