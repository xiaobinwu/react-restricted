/**
 * Created by Liu.Jun on 2018/9/7.
 */
import Cookies from 'js/utils/cookie';

// 判断预发布图标显示
const stagKey = 'staging';

if (Cookies.get(stagKey)) {
    try {
        // 预发布
        const tipBtn = $('<span/>').css({
            padding: '5px',
            position: 'fixed',
            left: '0px',
            top: '0px',
            color: 'rgb(255, 255, 255)',
            background: 'rgb(255, 0, 0)',
            fontSize: '12px',
            zIndex: '2147483647',
            borderRadius: '15px'
        });
        tipBtn.html('预发布');
        tipBtn.appendTo('body');
    } catch (e) {
        // no
    }
}
