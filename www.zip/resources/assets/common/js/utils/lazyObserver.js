/**
 * Created by Liu.Jun on 2018/4/11.
 */

import 'intersection-observer';

// 合并相同 root， 相同 root 取第一次配置
// const observers = new Map();

// function getIntersectionObserver({
//     root, rootMargin, threshold
// }) {
//     let intersectionObserver;
//
//     if (undefined === observers.get(root)) {
//         intersectionObserver = new IntersectionObserver((entries, observer) => {
//             debugger;
//         }, {
//             root,
//             rootMargin,
//             threshold,
//         });
//     }
//     return intersectionObserver;
// }

/**
 * @param root          intersection api
 * @param rootMargin    intersection api
 * @param threshold     intersection api
 * @param once          只触发一次
 * @param callBack([dom])      触发回掉
 * @param observeDom   监听的元素 Element 、NodeList
 */
export default function ({
    root = null,
    rootMargin = '0px',
    threshold = 0.5,
    once = true,
    callBack = null,
    observeDom,
} = {}) {
    let triggerTarget = new Set();

    let intersectionObserver = new IntersectionObserver((entries, observer) => {
        if (entries.length <= 0) {
            observer.disconnect();
            triggerTarget = null;
            intersectionObserver = null;
            console.warn('intersectionObserver disconnect');
        }
        entries.forEach((item) => {
            if (item.intersectionRatio > observer.thresholds[0]) {
                if (once) {
                    // 可在回掉中手动 unobserve
                    if (!triggerTarget.has(item.target)) {
                        setTimeout(() => {
                            callBack(item.target, observer);
                        });
                    }
                    observer.unobserve(item.target);
                    triggerTarget.add(item.target);
                    if (triggerTarget.size === (observeDom.length || 1)) {
                        // 全部触发释放
                        observer.disconnect();
                        triggerTarget = null;
                        intersectionObserver = null;
                        console.warn('懒加载 intersectionObserver disconnect');
                    }
                } else if (callBack) {
                    setTimeout(() => {
                        callBack(item.target, observer);
                    });
                }
            }
        });
    }, {
        root,
        rootMargin,
        threshold,
    });

    if (observeDom) {
        // start observing
        if (observeDom instanceof Element) {
            // Element
            intersectionObserver.observe(observeDom);
        } else {
            // NodeList
            [...observeDom].forEach(dom => intersectionObserver.observe(dom));
        }
    } else {
        console.error('observeDom不能为空');
    }
    return intersectionObserver;
}
