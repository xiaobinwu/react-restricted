/**
 * Created by Liu.Jun on 2018/3/31.
 */

// 统一处理 避免反复设置域名配置
import Cookies from 'js-cookie';

const { DOMAIN_COOKIE } = window.GLOBAL;

Cookies.defaults = {
    path: '/',
    domain: DOMAIN_COOKIE,
    expires: 365
};

export default Cookies;
