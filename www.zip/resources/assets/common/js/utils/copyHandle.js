/**
 * 复制粘贴板
 * Created by Jiazhan Li on 2018/08/02.
 */

import layer from 'layer';
import Clipboard from 'clipboard';
import { trans } from 'js/core/translate.js';

export default (target) => {
    new Clipboard(target, {
        text(elem) {
            return elem.dataset.code;
        },
    }).on('success', () => {
        layer.msg(`${trans('promotion.copy_succeed')}!`);
    });
};
