/**
 * jquery validation 插件配置与其对应的表单行为
 *
 * @author  lijiazhan (lijiazhan@globalegrow.com)
 * @date    2017/12/22
 * @since   2017/12/22
 */

import 'jquery-validation';
import { testPassword, regPhone } from 'js/utils/commonReg';


// 重写表单验证错误提示文案
const transformLangConf = {
    ep: 'es',
    'ep-mx': 'es',
    po: 'pt',
    'pt-br': 'pt-BR',
    'pt-pt': 'pt-PT'
};

const lang = transformLangConf[GLOBAL.LANG] || GLOBAL.LANG;

import(`jquery-validation/dist/localization/messages_${lang}.js`).then(() => {
    console.warn(`设置当前语言${lang}`);
}).catch((e) => {
    // 找不到语言，默认英语
    console.warn(`找不到当前语言：${lang}`);
});

Object.assign($.validator.messages, {
    required: 'This field is required.',
    email: 'Please enter a valid email address.',
});


/**
 * 重写验证的表单交互行为
 */
$.validator.setDefaults({
    success: $.noop,
    onkeyup: false,
    onsubmit: false,
    ignore: '.ignore', // 对添加类型为 .ignore 的表单输入项跳过验证

    /**
     * 每次表单验证都会执行该方法
     * @param  {Object} error   一个包含错误信息的 jquery 对象
     * @param  {Object} elem    待验证的表单项
     */
    errorPlacement(error, elem) {
        const $elem = $(elem);
        const formOrigiClass = 'form_original';
        const $tempGroup = $elem.closest('.form_group');
        const $formGroup = $tempGroup.length > 0 ? $tempGroup : $elem.closest('.js-formGroup');
        let $msg = $formGroup.find('.form_msg');

        if (error.is(':empty')) { // 验证成功
            $formGroup.removeClass('error');
            if ($msg.length > 0) {
                if ($msg.hasClass('form_msg-error')) {
                    $msg.html('').hide();
                } else if ($msg.data('original')) {
                    $msg.html($msg.data('original')); // 还原文本信息
                    $msg.addClass(formOrigiClass);
                }
            }
        } else { // 验证失败，显示错误信息
            $formGroup.addClass('error');
            if ($msg.length === 0) {
                $msg = $('<p class="form_msg form_msg-error"></p>');
                if ($formGroup.hasClass('js-formGroup')) {
                    $formGroup.append($msg);
                } else {
                    $elem.closest('.form_data').append($msg);
                }
            }

            if ($msg.hasClass('form_msg-error')) {
                $msg.show();
            } else if (!$msg.data('original')) {
                $msg.data('original', $msg.html()); // 储存原文本信息
            }

            $msg.html(error.html());
        }
    },
});


/** ****************************************
 * 新增验证规则
 *
 ***************************************** */

/**
 * 验证是否是手机号码，只允许输入数字, +, -, ()
 * phone: true
 */
$.validator.addMethod('phone', (value, element, params) => {
    if (params === false || value === '') return true;
    return regPhone.test(value);
}, 'Please only use: numbers, +, -, or ()');

/**
 * 密码类型
 * vldPassword: true 避开重名 input type
 */
$.validator.addMethod('vldPassword', (value, element, params) => {
    if (params === false || value === '') return true;
    return testPassword(value);
}, 'Must be at least 8 characters; please use at least 2 types (letters, numbers, or special characters).');

/**
 * 不等于（新密码跟旧密码必须不同）
 * unequal: '#oldPassword'
 */
$.validator.addMethod('unequal', (value, element, params) => {
    if (params === false || value === '') return true;
    const $target = $(params);
    return $target.length > 0 ? $target.val() !== value : false;
}, 'The new password is the same as the old one.');

/**
 * 等于（新密码和确认密码必须一致）
 * equal: '#newPassword'
 */
$.validator.addMethod('equal', (value, element, params) => {
    if (params === false || value === '') return true;
    const $target = $(params);
    return $target.length > 0 ? $target.val() === value : false;
}, 'Enter the same password as above');

/**
 * 验证正则表达式（用于自定义地址验证）
 * regex: '^123456$'
 */
$.validator.addMethod('regex', (value, element, params) => {
    if (params === false || value === '') return true;
    return new RegExp(params).test(value);
}, '');
