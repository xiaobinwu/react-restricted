/**
 * 异步函数排重过滤器
 * @param promiseFun    // 异步函数（返回值为promise对象）
 * @return 过滤后的promiseFun方法
 */
export default function smartPromise(promiseFun) {
    let promise = null;
    let promiseStatus = 'pending';
    return (params) => {
        if (!promise || promiseStatus !== 'pending') {
            promise = promiseFun(params);
        }
        if (promise.then) {
            promise.then(() => {
                promiseStatus = 'fulfilled';
            }, () => {
                promiseStatus = 'rejected';
            });
        } else {
            promiseStatus = 'fulfilled';
        }
        return promise;
    };
}
