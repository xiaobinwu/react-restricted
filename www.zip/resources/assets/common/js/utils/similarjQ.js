/*
* 模仿jQuery.js功能,所有兼容性兼容大于等于IE9
* */

/**
 * 选择单个
 * @param select [String] css选择器
 * @param root [HTMLELement] 父级元素
 * @returns {Element | null} 返回选择的节点
 */
export function getSelector(select = '', root = document) {
    return root.querySelector(select);
}

/**
 * 选择多个
 * @param select [String] css选择器
 * @param root [HTMLELement] 父级元素
 * @returns [Array]<HTMLELement> 返回所有选择节点
 */
export function getSelectorAll(select = '', root = document) {
    return [...root.querySelectorAll(select)];
}
