import {
    XD_STORAGE_ORIGIN,
    XD_STORAGE_PATH
} from 'js/variables';

export default class XDStorage {
    constructor(origin = XD_STORAGE_ORIGIN, path = XD_STORAGE_PATH) {
        this.origin = origin;
        this.path = path;
        this.$iframe = null;
        this.$iframeReady = false;
        this.$queue = [];
        this.$requests = {};
        this.$id = 0;
    }

    op = {
        WRITE: 'W',
        READ: 'R',
        DEL: 'D',
        CLEAR: 'X',
    }

    // public interface methods
    init() {
        const that = this;

        if (!this.$iframe) {
            if (window.postMessage && window.JSON && window.localStorage) {
                this.$iframe = document.createElement('iframe');
                this.$iframe.style.cssText = 'position:absolute;width:1px;height:1px;left:-9999px;';
                document.body.appendChild(this.$iframe);

                if (window.addEventListener) {
                    this.$iframe.addEventListener('load', () => {
                        that.$iframeLoaded();
                    }, false);
                    window.addEventListener('message', (event) => {
                        that.$handleMessage(event);
                    }, false);
                } else if (this.$iframe.attachEvent) {
                    this.$iframe.attachEvent('onload', () => {
                        that.$iframeLoaded();
                    }, false);
                    window.attachEvent('onmessage', (event) => {
                        that.$handleMessage(event);
                    });
                }
            } else {
                throw new Error('Unsupported browser.');
            }
        }
        this.$iframe.src = this.origin + this.path;
    }

    getValue(key, callback) {
        this.$toSend({
            key
        }, callback);
    }

    setValue(key, value, callback, expires = 30) {
        this.$toSend({
            key,
            op: this.op.WRITE,
            value,
            expires
        }, callback);
    }

    delValue(key, callback) {
        this.$toSend({
            key,
            op: this.op.DEL
        }, callback);
    }

    clearValue(callback) {
        this.$toSend({
            op: this.op.CLEAR
        }, callback);
    }

    // private methods
    $toSend(params, callback) {
        const data = {
            request: {
                key: params.key,
                id: this.$id += 1,
                op: params.op,
                value: params.value,
                expires: params.expires
            },
            callback
        };
        if (this.$iframeReady) {
            this.$sendRequest(data);
        } else {
            this.$queue.push(data);
        }
        if (!this.$iframe) {
            this.init();
        }
    }

    $sendRequest(data) {
        this.$requests[data.request.id] = data;
        this.$iframe.contentWindow.postMessage(JSON.stringify(data.request), this.origin);
    }

    $iframeLoaded() {
        this.$iframeReady = true;
        if (this.$queue.length) {
            for (let i = 0, len = this.$queue.length; i < len; i += 1) {
                this.$sendRequest(this.$queue[i]);
            }
            this.$queue = [];
        }
    }

    $handleMessage(event) {
        if (event.origin === this.origin) {
            const data = JSON.parse(event.data);
            if (this.$requests[data.id].callback) this.$requests[data.id].callback(data.key, data.value);
            delete this.$requests[data.id];
        }
    }
}
