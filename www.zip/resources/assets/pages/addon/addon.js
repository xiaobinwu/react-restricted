import 'js/bootstrap';
import $ from 'jquery';
import PubSub from 'pubsub-js';

import {
    serviceAddonJudge,
    serviceAddonCompose,
} from 'js/service/promotion';
import { updateCurrency } from 'js/core/currency';
import { trans } from 'js/core/translate.js';
import layer from 'js/lib/layer/layer';
// 大数据埋点
import addonTrack from 'js/track/define/addon.js';
// 收藏
import GoodsItem from 'component/goods_item/goods_item.js';
import { initLazyload } from 'js/utils/lazyload.js';
import runtime from 'art-template/lib/runtime';
import 'component/paging/paging.js';
import tempaddon from './addon.art';
import './addon.css';

addonTrack();

// 分页请求参数
const pagingParams = {
    order: '', // 排序
    catId: '', // 分类ID
    curPage: 1, // 当前页码
    pageSize: 45, // 每页记录数
    totalCount: 1, // 总页数
};
const activityId = $('#composeGoods').val();

// 获取凑单数据
const getData = async () => {
    const addonGoods = $('#addonGoods');
    const params = {
        activityId,
        catId: pagingParams.catId,
        page: pagingParams.curPage,
        pageSize: pagingParams.pageSize,
        order: pagingParams.order,
    };

    runtime.trans = trans;

    const {
        status,
        data: {
            goodsList,
            aggData,
            order,
            curPage,
            pageSize,
            curOrder,
            totalCount,
            totalPage,
        }
    } = await serviceAddonCompose.http({
        params
    });

    if (status === 0) {
        Object.assign(pagingParams, {
            curPage,
            pageSize,
            totalCount,
            totalPage,
        });

        if (aggData.catId) {
            aggData.$length = Object.keys(aggData.catId).length;
        }

        addonGoods.html(tempaddon({
            aggData,
            curPage,
            pageSize,
            order,
            curOrder,
            curCatId: pagingParams.catId,
            totalCount,
            goodsList,
            activityId,
            totalPage,
        }));

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: addonGoods[0],
        });

        // 翻页
        $('.js-paging').paging({
            current: pagingParams.curPage,
            total: Math.ceil(pagingParams.totalCount / pagingParams.pageSize),
            onChange: (num) => {
                pagingParams.curPage = num;
                $(window).scrollTop($('#addonGoods').offset().top);
                getData();
            },
        });

        // 橱窗位公用类
        GoodsItem.init({
            container: $('.js_seachResultList')
        });

        initLazyload();

        $('.addonHeader').removeClass('gb-hide');

        // 点击分类
        $('#js_showAllCat').on('click', () => {
            $('.js-cateMainWarp_catNav').toggleClass('all');
            $('.js-clearCateMenu').toggleClass('down');
        });

        $('.js-cates').on('click', (e) => {
            const $this = $(e.currentTarget);
            const catid = $this.parent().hasClass('on') ? '' : $this.attr('data-catid');
            pagingParams.catId = catid || '';
            pagingParams.curPage = 1;
            getData();
        });
        $('.js-sort').on('click', (e) => {
            const $this = $(e.currentTarget);
            let sort = $this.attr('data-sort');
            if (pagingParams.order === 'high2low' && sort === 'high2low') {
                sort = 'low2high';
            } else if (pagingParams.order === 'low2high' && sort === 'low2high') {
                sort = 'high2low';
            }
            pagingParams.order = sort;
            pagingParams.curPage = 1;
            getData();
        });
        $('.js-pageSize').on('click', (e) => {
            const $this = $(e.currentTarget);
            const $pageSize = +$this.html();
            pagingParams.curPage = 1;
            pagingParams.pageSize = $pageSize;
            $(window).scrollTop($('#addonGoods').offset().top);
            getData();
        });

    }
};

// ???为啥要用activityType作为区分商品，activityType不应该是全局都有的？？,我改成了isGift作为变量
PubSub.subscribe('nativeReady', () => {
    // 添加到购物车
    const $addonWrap = $('#composeGoods');
    const actId = $addonWrap.val();
    const activityType = $addonWrap.attr('data-activitytype');
    $(document).on('click', '.js-addToCart', async (e) => {
        const $this = $(e.currentTarget);
        const goodSku = $this.attr('data-sku');
        const $img = $this.attr('data-img');
        const warehouseStr = $this.attr('data-warehouseCode');
        const singlecount = parseInt($this.attr('data-singlecount'), 10);
        const qtyNum = singlecount > 1 ? singlecount : 1;
        const goodstype = $this.attr('data-goodstype');
        this.isGift = $this.attr('data-isgift');
        // 换购、赠品加车前的校验
        if (this.isGift === '1' && activityType && (+activityType === 2 || +activityType === 4)) {
            /* 加车之前的判断 */
            const { status, data } = await serviceAddonJudge.http({
                params: {
                    activityId: actId
                }
            });
            if (+status !== 0) { return; }
            const maxGiftCount = $this.closest('.productWrap').attr('data-maxgiftcount');
            const meetAmount = $this.attr('data-meetamount');
            if (!(data.isJoined && (+maxGiftCount > data.actJoinedNumber) && !data.actJoinedSkuList.includes(goodSku) && (+data.actMergeAmount >= meetAmount))) { //eslint-disable-line
                layer.msg(trans('cart.addon_addcart_tip'));
                return;
            }
        }
        /* 添加到购物车 */
        PubSub.publish('sysAddToCart', {
            method: 'post',
            goods: {
                goodsSn: goodSku,
                warehouseCode: warehouseStr,
                qty: qtyNum,
                activityId: actId,
                goodsType: goodstype,
            },
            // 无cartAni.imgSrc,cartAni.origin 参数则没有飞入动画
            cartAni: {
                imgSrc: $img,
                origin: $this,
            },
        });
    });

    // 加车成功订阅
    PubSub.subscribe('sysUpdateSampleCart', async () => {
        if (this.isGift === '0') {
            const { status, data } = await serviceAddonJudge.http({
                params: {
                    activityId: actId
                }
            });
            if (+status !== 0) { return; }

            const $activityAmount = $('.js-activityAmount');
            $activityAmount.attr('data-currency', data.actMergeAmount || 0);
            const $actMergeActualAmount = $('.js-actMergeActualAmount');
            const $myDiscounted = $('.addonRuls_my_discounted');
            $actMergeActualAmount.attr('data-currency', data.actMergeActualAmount || 0);
            if (data.activityDeductAmount > 0) {
                $myDiscounted.removeClass('my-hide');
            }
            updateCurrency({
                elements: $actMergeActualAmount[0] ? [$activityAmount[0], $actMergeActualAmount[0]] : [$activityAmount[0]]
            });
        }
    });
    // 播放视频
    async function cateSwalBoxControl(extendVideoCode) {
        const showVideoTemp = await import('../category/component/item/show_video.art');
        layer.open({
            type: 1,
            area: ['900px', '500px'],
            closeBtn: 1,
            anim: 5,
            content: showVideoTemp({ videoCode: extendVideoCode }), // 这里content是一个普通的String
        });
    }

    $(document).on('click', '.gbGoodsItem_video', (e) => {
        const $this = $(e.currentTarget);
        const playParam = $this.attr('data-urlpram');
        const paramArray = playParam.split(',');
        const len = paramArray.length;
        if (len === 1) {
            cateSwalBoxControl(paramArray[0]);
        } else if (len >= 2) {
            const randomIndex = Math.floor(Math.random() * len);
            cateSwalBoxControl(paramArray[randomIndex]);
        }
    });

    // 查看更多
    $(document).on('click', '.js-viewMore', (e) => {
        const $this = $(e.currentTarget);
        const $gbGoodsMoreItem = $this.closest('.cateMain_listModel').find('.gbGoodsMoreItem');
        const icon = '<i class="icon icon-arrow-down1"></i>';
        if ($this.hasClass('isExpend')) {
            $gbGoodsMoreItem.fadeOut(300).css('display', 'none');
            $this.removeClass('isExpend').html(`${trans('cart.view_more')}${icon}`);
            $this.parent().removeClass('isExpend');
        } else {
            $gbGoodsMoreItem.fadeIn().css('display', 'inline-block');
            $this.addClass('isExpend').html(`${trans('cart.view_less')}${icon}`);
            $this.parent().addClass('isExpend');
        }
    });

    getData();

});

export {};
