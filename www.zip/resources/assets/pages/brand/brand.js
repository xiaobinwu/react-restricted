import 'js/bootstrap';
import PubSub from 'pubsub-js';
import Rating from 'component/rating/rating';
import SimpleScrollbar from 'lib/simple-scrollbar/simple-scrollbar.js';
import GoodsItem from 'component/goods_item/goods_item.js';
import BrandsTrack from 'js/track/define/top_brands';
import { slickFn } from 'js/core/slickFn.js';
import { serviceBrandHot } from 'js/service/promotion';
import Timer from 'component/timer/timer.js';
import { trans } from 'js/core/translate.js';
import $ from 'jquery';
import layer from 'layer';
/* ——————闪购 start—————— */
import { serviceCartEasyBuy } from 'js/service/common.js';
import { postLocation } from 'js/utils/index.js';
/* ——————闪购 end——————— */

import './brand.css';

const BRAND_NAME = $('.js-brandName').val();

new Rating();
SimpleScrollbar.initEl(document.querySelector('.js-sayingContain'));

const $contation = $('.js-brandSwitchContent');
let curPage = 0; // 1页 (0 - 10), 2(10 -50), 3(50-100)
const pageSize = 50;

// 判断显示状态
function shrinkContent() {
    if ($contation.find('.gbGoodsItem').length > 0) {
        $contation.append($(`
            <span class="bransSwitch_more js-moreLess">
                ${trans('goods.view_more')}
                <i class="icon-arrow-down1 bransSwitch_moreIcon"></i>
            </span>`));
    }
}
shrinkContent();

// hotsales view more 按钮
$contation.on('click', '.js-moreLess', (e) => {
    const $this = $(e.currentTarget);
    curPage += 1;
    if (curPage === 1) {
        // 显示隐藏的 40 条
        const $item = $('.js-brandSwitchContent .gbGoodsItem:nth-of-type(n+11)');
        $contation.removeClass('brandSec_switchCon-hideMore');
        if ($item.length < 40) {
            // no more
            $this.removeClass('more').remove();
        }
    } else {
        asyncAppendGoods(true);
    }
});

// 顶部轮播
slickFn({
    container: '.js-brandSlick',
    dots: true,
    lazyLoad: 'ondemand',
    prevArrow: $('.brandSlick_navItem').eq(0),
    nextArrow: $('.brandSlick_navItem').eq(1),
});


async function asyncAppendGoods(append = false) {
    const curCateId = document.querySelector('.brandSwitch_item.active').dataset.cateId;
    const { status, data } = await serviceBrandHot.http({
        params: {
            brand: BRAND_NAME,
            cat_id: curCateId,
            page: curPage,
            pageSize
        },
    });

    if (status === 0) {
        GoodsItem.init({
            container: $('.js-brandSwitchContent .brandSec_content'),
            type: 2,
            list: data.goodsList,
            append
        });
        if (data.goodsList.length < pageSize) {
            $('.js-moreLess').remove();
        }
        // PubSub.publish('sysUpdateCurrency', {
        //     context: document.querySelector('.js-brandSwitchContent')
        // });
    }

    return data;
}

// 分类切换
$('.js-brandSwitch').on('click', '.brandSwitch_item', async (e) => {
    const $this = $(e.currentTarget);
    if (!$this.hasClass('active')) {
        $this.addClass('active').siblings('li').removeClass('active');
        curPage = 1;
        $contation.find('.brandSec_content').empty();
        asyncAppendGoods().then(() => {
            $contation.removeClass('brandSec_switchCon-hideMore');
        });
    }
});

// 顶部导航栏 定位
$('.js-brandSecSwitch').on('click', 'li', (e) => {
    const index = $(e.target).index();
    $('html,body').animate({
        scrollTop: $('.brandSec').eq(index).offset().top,
    }, 1000);
});

// info more
$('.js-infoMore').on('click', (e) => {
    const $this = $(e.target);
    const $p = $this.prev('.brandInfo_content');
    $p.removeClass('brandInfo_content-less');
    SimpleScrollbar.initEl(document.querySelector('.brandInfo_content'));
    $this.hide();
});

// 顶部固定
PubSub.subscribe('nativeScroll', () => {
    const $siteHeader = $('.js-brandHeader');
    const headerRect = $siteHeader.get(0).getBoundingClientRect();
    const $headerContent = $siteHeader.find('.brandHeader_content');
    if (headerRect.bottom < 0) {
        $headerContent.addClass('brandHeader_content-fixed');
    } else {
        $headerContent.removeClass('brandHeader_content-fixed');
    }
});

// hot sale 加入购物车
$contation.on('click', '.gbGoodsItem_cart.js-opera', (e) => {
    const $this = $(e.currentTarget);
    PubSub.publish('sysAddToCart', {
        goods: {
            goodsSn: $this.data('sku'),
            qty: 1,
            warehouseCode: $this.data('wid')
        },
        cartAni: {
            imgSrc: $this.data('img'),
            origin: $this,
        }
    });
});

// 播放视频
async function cateSwalBoxControl(extendVideoCode) {
    const showVideoTemp = await import('../../component/goods_item/show_video.art');
    layer.open({
        content: showVideoTemp({ videoCode: extendVideoCode }),
        area: ['auto', 'auto'],
        btn: false,
        anim: 5,
        closeBtn: 1,
    });
}
$contation.on('click', '.gbGoodsItem_video.js-opera', (e) => {
    cateSwalBoxControl($(e.currentTarget).data('video'));
});

$contation.on('click', '.gbGoodsItem_like.js-opera', (e) => {
    const likeEle = $(e.currentTarget);
    if (likeEle.hasClass('collected')) {
        GoodsItem.cancelCollect(likeEle);
    } else {
        GoodsItem.collect(likeEle);
    }
});


/* ——————————闪购———————— */
// 多时段、多商品倒计时
const timer = new Timer();
timer.add('.js-goodRushDown', {
    format: `${trans('base.ends_in')} {dd}:{hh}:{mm}:{ss}`,
    interval: 'end',
});

// 加入购物车
$('.js-flashAddCart').click((e) => {
    const $this = $(e.currentTarget);
    if ($this.hasClass('limit-sold-gray')) return;
    PubSub.publish('sysAddToCart', {
        goods: {
            goodsSn: $this.data('sku'),
            qty: 1,
            warehouseCode: $this.data('wid')
        },
        cartAni: {
            imgSrc: $this.data('img'),
            origin: $this
        }
    });
});

// flash shale
if ($('.gbFlashsaleItem').length > 10) {
    $('.js-flashsale-list').addClass('flashsale-wrap-maxheight')
        .append($(`
            <span class="bransSwitch_more js-flashsale-moreLess">
                ${trans('goods.view_more')}
                <i class="icon-arrow-down1 bransSwitch_moreIcon"></i>
            </span>`));
}
let viewStatus = 0;
$('.js-flashsale-list').parent().on('click', '.js-flashsale-moreLess', () => {
    if (!viewStatus) {
        $('.js-flashsale-list').removeClass('flashsale-wrap-maxheight');
        $('.js-flashsale-moreLess').html(`${trans('goods.view_less')} <i class="icon-arrow-up bransSwitch_moreIcon"></i>`);
    } else {
        $('.js-flashsale-list').addClass('flashsale-wrap-maxheight');
        $('.js-flashsale-moreLess').html(`${trans('goods.view_more')} <i class="icon-arrow-down1 bransSwitch_moreIcon"></i>`);
        document.documentElement.scrollTop = $('.brandSec_content').offset().top;
    }
    viewStatus = !viewStatus ? 1 : 0;
});

// buy now
async function buyNow(that) {
    const msgEle = that.next();
    const { DOMAIN_ORDER = '/' } = window.GLOBAL;
    const URI_CHECKOUT = `${DOMAIN_ORDER}/checkout/index`; // 订单页面链接
    const SELECTEDGOODS = {
        warehouseCode: msgEle.data('wid'),
        goodsSn: msgEle.data('sku'),
        qty: 1,
    };
    const res = await serviceCartEasyBuy.http({
        loading: true,
        data: {
            goods: [SELECTEDGOODS],
        },
    });
    if (+res.status === 0) {
        postLocation(URI_CHECKOUT, {
            isQuickBuy: 1,
        });
    } else {
        layer.msg(res.msg);
    }
}

$('.js-flashsale-list').on('click', '.js-buyNow', (e) => {
    e.preventDefault();
    buyNow($(e.target));
});


// 翻译静态字符
// $('.js-trans-flashsale').each(function (index, value) {
//     $(this).text(trans($(value).text()));
// });


// 初始化埋点配置
function initTrack() {
    const $goodsItem = $('.gbGoodsItem');
    $goodsItem.each((index, elem) => {
        const $elem = $(elem);
        const info = $elem.data('trackcode').split('_');
        const key = `${info[0]}_${info[2]}`;
        try {
            window.TrackData[key] = {
                k: info[2],
                pc: info[1],
                sku: info[0],
                pam: 1
            };
        } catch (e) {
            // 大数据没返回数据
        }
    });

    (new BrandsTrack({
        page: true,
    })).run();
}

initTrack();
