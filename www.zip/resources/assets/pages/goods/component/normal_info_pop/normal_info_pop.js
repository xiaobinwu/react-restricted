/**
 * 商详页简介区普通消息弹窗
 * @priceDisclaimer 价格免责声明
 * @priceProtection 价格保护
 * @taxInfo 税费说明
 */

import layer from 'layer';
import './normal_info_pop.css';

// 价格保护弹窗上链接->支持中心
const URI_SUPPORT_CENTER = window.GLOBAL.SUPPORT_URL;

// 弹窗基础配置
function layerOpen(temp, options) {
    const defaults = {
        content: temp({
            URI_SUPPORT_CENTER,
        }),
        area: '400px',
        btn: false,
        shadeClose: false,
        skin: 'goodsPop_normalInfo'
    };
    Object.assign(defaults, options);
    layer.open(defaults);
}

// 价格免责声明 - priceDisclaimer
async function priceDisclaimer() {
    const html = await import('./price_disclaimer.art');
    layerOpen(html);
}

// 价格保护 - priceProtection
async function priceProtection() {
    const html = await import('./price_protection.art');
    layerOpen(html);
}

//  税费说明 - taxInfo
async function taxInfo() {
    const html = await import('./tax_info.art');
    layerOpen(html);
}

// 错误上报
async function errorReport() {
    const FeedBack = (await import('component/feedback/feedback.js')).default;
    FeedBack.bindEvent();
    FeedBack.feedbackShow();
}

// 按钮触发弹窗
$(document).on('click', '[data-popbtn]', function () { // eslint-disable-line
    const type = $(this).data('popbtn');
    const which = {
        priceDisclaimer,
        priceProtection,
        taxInfo,
        errorReport,
    };
    if (typeof which[type] === 'function') {
        which[type]();
    }
});
