/** 商品促销（营销）价状态展示 */

import PubSub from 'pubsub-js';
import GoodsInfo from 'js/core/goods/GoodsInfo.js';
import Timer from 'component/timer/timer';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import './goods_promo_price.css';


/**
 * 指定商品状态才可显示营销价面板
 * 2    上架
 * 4    到货通知（只因设计问题）
 */
// 去除到货通知显示营销价面板
const SHOWPRICE_STATUS = [2, 4];
/**
 * 营销价格类型 (以下~开头表示有营销价格模板适配)
 * 1    ~邮件专享价
 * 2    ~预售价
 * 7    ~限时限量价
 * 8    ~普通促销
 * 11   ~整点秒杀
 * 28   ~定金膨胀
 */
const PRICE_TYPE_CONFIG = {
    '-2': { // 到货通知
        name: trans('goods.arrival_notice'),
        normalShow: false, // 不显示商品普通价格
    },
    1: { // 邮件专享价
        name: trans('goods.email_only'),
        normalShow: true, // 需要显示商品普通价格
    },
    2: { // 预售价
        name: trans('goods.presale_price'),
        normalShow: true,
    },
    7: { // 限时限量价
        name: trans('goods.flash_sale'),
        normalShow: true,
    },
    11: { // 整点秒杀
        name: trans('goods.super_deals'),
        normalShow: true,
    },
    28: { // 定金膨胀
        name: trans('goods.deposit_detail_imgtitle'),
        normalShow: false,
    },
};
// 商品信息
const GOODSINFO = GoodsInfo.get();


runtime.specialDate = (time) => {
    const date = new Date(time * 1000);
    const yy = date.getFullYear();
    const MM = date.getMonth() + 1;
    const dd = date.getDate();
    const hh = date.getHours() > 9 ? date.getHours() : `0${date.getHours()}`;
    const mm = date.getMinutes() > 9 ? date.getMinutes() : `0${date.getMinutes()}`;
    const spTime = `${yy}.${MM}.${dd} ${hh}:${mm}`;
    return spTime;
};

// 商品普通价格面板
const $panelPrice = $('#js-panelIntroNormalPrice');

// 定金膨胀规则显示
const $panelPromoPrice = $('#js-goodsPromoPrice');

class GoodsPromoPrice {
    constructor() {
        // 是否显示营销价醒目条（默认：显示）
        this.showPromoBar = true;
        this.resPrice = {};
    }

    init() {
        const self = this;

        self.bindEvent();

        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            const { price = {}, goodsStatus, stock } = resData;

            self.resPrice = price;
            self.stock = self.setStock(stock);
            self.goodsStatus = goodsStatus;

            // 到货通知
            if (/^4$/.test(goodsStatus)) {
                self.checkArrivalNotice();
            }

            // 定金膨胀
            if (/^28$/.test(price.labelId)) {
                if (!price.isCanShowDep) {
                    // 不符合定金膨胀条件修正为普通价
                    price.labelId = -1;
                } else {
                    // 定金膨胀时间节点字段修正
                    self.resPrice.startTime = this.resPrice.advanceStartTime;
                    self.resPrice.endTime = this.resPrice.advanceEndTime;
                }
            }

            // 整点秒杀渲染前数据处理
            if (/^11$/.test(price.labelId)) {
                self.handleWholePointSpike();
            }

            // 普通价
            if (/^-1$/.test(price.labelId)) {
                self.showPromoBar = false;
            }

            // 当前商品状态要在上述定义的商品状态 并且 lableId在上述定义的价格类型才展示营销面板
            if (SHOWPRICE_STATUS.includes(+goodsStatus) && price.labelId in PRICE_TYPE_CONFIG) {
                self.renderTemp();
            }

            // 非营销价时要显示正常实时价
            $('.js-panelIntroPrice').attr('data-currency', price.price).removeClass('price-loading');

        });
    }

    bindEvent() {
        // 定金膨胀
        $panelPromoPrice.on('mouseover', '.js-depositRule', (e) => {
            const $this = $(e.currentTarget);
            $this.addClass('show');
        }).on('mouseout', '.js-depositRule', (e) => {
            const $this = $(e.currentTarget);
            $this.removeClass('show');
        });
    }

    // 让到货通知状态转化为 营销状态： -2
    checkArrivalNotice() {
        this.resPrice.labelId = -2;

        const arrivalMsg = window.arrvialNoticeMsg || {};

        // 到货通知信息
        this.noticeSubmitMsg = arrivalMsg.msg || '';

        // 是否显示普通价面板
        PRICE_TYPE_CONFIG['-2'].normalShow = typeof arrivalMsg.isShowPrice === 'undefined' ? 0 : arrivalMsg.isShowPrice;

        // 实际内容是到货通知结束时间
        this.resPrice.endTime = Math.ceil(arrivalMsg.arrivalTime || (new Date().getTime() / 1000));

        // 未给出到货通知状态开始时间，让开始时间小于当前时间即可
        this.resPrice.startTime = Math.ceil(((new Date().getTime()) - 5000) / 1000 || '');
    }

    // 整点秒杀状态 数据处理
    handleWholePointSpike() {
        const priceData = this.resPrice;
        const now = new Date() / 1000;

        if (now < priceData.startTime) { // 整点秒杀预告
            this.showPromoBar = false;
        } else if (now > priceData.startTime && now < priceData.endTime) { // 整点秒杀中

        } else { // 整点秒杀结束
            this.labelId = -1;
        }
    }

    // 模板渲染输出
    async renderTemp() {
        const self = this;
        const temp = await import('./goods_promo_price.art');
        const renderData = self.packageData();

        // 普通价显示
        self.normalPrice();

        // 渲染营销价面板
        $panelPromoPrice.html(temp(renderData)).addClass('show');

        // 开启倒计时
        self.countdown();

        // 更新货币
        PubSub.publish('sysUpdateCurrency');
    }

    // 倒计时
    countdown() {
        const labelId = this.resPrice.labelId;
        const $countdownWrap = $('.goodsIntro_pricePromo');
        const $countdown = $('.goodsPromoPrice_time');

        if (/^(1|2|7|11|28)$/.test(labelId)) {

            // 倒计时格式处理
            const formatHandle = (labelText) => {
                let format = `${labelText} ${trans('goods.days_h_m_s', ['{dd}', '{hh}', '{mm}', '{ss}'])}`;

                /**
                 * 整点秒杀
                 * 大于24h, days hh:mm:ss
                 * 小于24h, hh:mm:ss
                 */
                if (/^(11)$/.test(labelId)) {
                    format = (interval) => {
                        if (interval <= 60 * 60 * 24) {
                            return [labelText, '<b>{hh}:{mm}:{ss}</b>'].join(' ');
                        }
                        return [labelText, trans('goods.days_h_m_s', ['{dd}', '{hh}', '{mm}', '{ss}'])].join(' ');
                    };
                }
                return format;
            };

            const timer = new Timer($countdown, {
                format: formatHandle(),
                interval: 'start',
                onStart() {
                    $countdownWrap.show();
                },
                onEnd() {
                    // 倒计时前缀
                    let preLabelText = /^(28)$/.test(labelId) ? trans('goods.deposit_countdown') : ''; // 定金膨胀
                    preLabelText = /^(11)$/.test(labelId) ? trans('goods.flashsale_endsin') : ''; // 整点秒杀

                    timer.add($countdown, {
                        format: formatHandle(preLabelText),
                        interval: 'end',
                        onEnd() {
                            $countdownWrap.hide();
                        }
                    });
                }
            });
        }

    }

    // 设置商品库存
    setStock(stockData) {
        let stock = 0;
        const num = [];

        Object.entries(stockData).forEach((item) => {
            num.push(item[1]);
        });
        stock = Math.min.apply(null, num);
        return stock;
    }

    // 处理常规价格区
    normalPrice() {
        const self = this;
        const show = PRICE_TYPE_CONFIG[self.resPrice.labelId].normalShow;
        if (show) {
            $panelPrice.show();
        } else {
            $panelPrice.hide();
        }
    }

    // 组装数据
    packageData() {
        const self = this;
        const price = self.resPrice || {};
        const pkData = {
            goodsStatus: self.goodsStatus,
            loginUrl: window.GLOBAL.loginUrl,
            isShowAppPrice: GOODSINFO.isShowAppPrice,
            labelId: price.labelId,
            name: self.saleName(),
            price: price.price,
            shopPrice: GOODSINFO.shopPrice,
            discount: self.discount(),
            startTime: price.startTime || 0,
            endTime: price.endTime || 0,
            surplus: self.surplus(),
            preSaleProgress: self.preSaleProgress(),
            preSaleDesc: self.preSaleDesc(),
            showPromoBar: self.showPromoBar,
            flashSalePrice: price.flashSalePrice,
        };

        // 定金膨胀专属字段
        if (+price.labelId === 28) {
            Object.assign(pkData, {
                pricePage: price.pricePage,
                priceFact: price.priceFact,
                advanceAmount: price.advanceAmount,
                deductionAmount: price.deductionAmount,
                swellDiscontAmount: price.swellDiscontAmount,
                finalAmount: price.finalAmount,
                advanceStartTime: price.advanceStartTime,
                advanceEndTime: price.advanceEndTime,
                finalStartTime: price.finalStartTime,
                finalEndTime: price.finalEndTime
            });
        }
        return pkData;
    }

    // 促销类型
    saleName() {
        try {
            return PRICE_TYPE_CONFIG[this.resPrice.labelId].name || '';
        } catch (error) {
            return '';
        }
    }

    // 折扣计算
    discount() {
        try {
            const originPrice = GOODSINFO.shopPrice;
            return Math.round(((originPrice - this.resPrice.price) / originPrice) * 100);
        } catch (error) {
            return 0;
        }
    }

    /**
     * 剩余量计算
     * return {
     *  count: '剩余数量',
     *  percent: '剩余百分比'
     * }
     */
    surplus() {
        try {
            const price = this.resPrice || {};
            const result = {};

            // 可售出数量未设置，表示为不限出售数量，则隐藏剩余量进度条
            if (!String(price.saleQty).length) {
                result.count = -1;
                result.percent = -1;
            } else if (+this.stock <= 0) { // 库存小于等于0时，限量条进度100% 剩余为0
                result.count = 0;
                result.percent = 100;
            } else {
                // 总数量（可售数量+虚拟售出数量）
                const allCount = (+price.saleQty) + (+price.virtualSaleQty);

                // 共已售出量(用户已购买 + 虚拟售出数量)
                let saledCount = (+price.count) + (+price.virtualSaleQty);

                // 防止计算溢出
                if (saledCount > allCount) {
                    saledCount = allCount;
                }

                // 限时限量剩余量(总数量-共已售出量)
                result.count = allCount - saledCount;

                // 防止计算出错
                if (allCount < 1) {
                    result.percent = 0;
                } else {
                    // 显示剩余量进度条 ((共已售出/共可售出) *100)
                    result.percent = (saledCount / allCount) * 100;
                }
            }

            return result;
        } catch (error) {
            return {
                count: -1,
                percent: -1,
            };
        }
    }

    /**
     * 预售进度计算
     */
    preSaleProgress() {
        try {
            const nowTime = new Date().getTime();
            const startTime = this.resPrice.startTime * 1000;
            const endTime = this.resPrice.endTime * 1000;

            let progressPercent = ((nowTime - startTime) / (endTime - startTime)) * 100;

            if (progressPercent > 100) {
                progressPercent = 100;
            }
            return progressPercent;
        } catch (error) {
            return 0;
        }
    }

    /* 预售描述 */
    preSaleDesc() {
        const self = this;
        const { labelId } = this.resPrice || { labelId: -1 };

        const descCfg = {
            '-2': () => self.noticeSubmitMsg,
            2() {
                const preSaleCount = self.preSaleCount();
                return preSaleCount > -1 ? `${preSaleCount} ${trans('goods.pre_orders')}` : '';
            },
            7() {
                const surplus = self.surplus();
                return surplus.count > -1 ? trans('goods.pieces_left', [surplus.count]) : '';
            },
            11() {
                const surplus = self.surplus();
                return surplus.count > -1 ? trans('goods.number_of_pcs_left', [surplus.count]) : '';
            },

        };
        descCfg[28] = descCfg[2];

        return typeof descCfg[labelId] === 'function' ? descCfg[labelId]() : '';
    }

    /**
     * 预售数量
     */
    preSaleCount() {
        try {
            const price = this.resPrice || {};

            // 预售数量（虚拟售出+起批量）
            return (+price.count) + (+price.virtualSaleQty);
        } catch (error) {
            return 0;
        }
    }
}

export default GoodsPromoPrice;
