import layer from 'layer';
import { getUrlQuery, getObjectMin } from 'js/utils/index.js';
import { STORAGE_GOODS_REDIRECT_LINK } from 'common/js/variables';
import { trans } from 'js/core/translate.js';

import './linkRedirect.css';

class LinkRedirect {
    dataStore = {
        shipping: 0,
        resData: null
    };
    set({
        shipping = 0,
        resData = null
    }) {
        if (shipping) this.dataStore.shipping = shipping;
        if (resData) this.dataStore.resData = resData;
        if (this.dataStore.shipping && this.dataStore.resData) {
            this.init(this.dataStore.resData);
        }
    }
    init(resData) {
        const { stock, goodsStatus } = resData;
        const canStock = getObjectMin(stock);
        this.linkMap = {};
        const isRedirect = window.sessionStorage.getItem(STORAGE_GOODS_REDIRECT_LINK);
        if (isRedirect) {
            window.sessionStorage.removeItem(STORAGE_GOODS_REDIRECT_LINK);
        } else if (!(goodsStatus === 2 && canStock > 0) && this.isPromote()) {
            this.filter();
        }
    }

    isPromote() {
        this.query = getUrlQuery(this.path);
        return this.query.vip || this.query.lkid;
    }

    filter() {
        const $attrLine = $('.js-goodsIntroAttr');
        const len = $attrLine.length;
        let colorWrap = []; // nodeList
        let sizeWrap = []; // nodeList
        const oddColor = []; // 颜色所有奇数
        const oddSize = []; // 尺寸所有奇数
        const checkIndex = [0, 0]; // 选中的下标
        if (len > 0) colorWrap = [...$attrLine.eq(0).find('.js-attrItem')];
        if (len > 1) sizeWrap = [...$attrLine.eq(1).find('.js-attrItem')];
        colorWrap.forEach((value, index) => {
            oddColor.push(value.dataset.prime);
            if (value.className.indexOf('line1') > 0) {
                checkIndex[0] = index;
            }
        });
        sizeWrap.forEach((value, index) => {
            oddSize.push(value.dataset.prime);
            if (value.className.indexOf('line1') > 0) {
                checkIndex[1] = index;
            }
        });
        const urlResult = this.redirect(checkIndex, oddColor, oddSize);
        if (urlResult) this.layerHref(urlResult);
    }

    getPrimeLink() {
        window.goodsLink.forEach((value) => {
            this.linkMap[value.prime] = value;
        });
    }

    redirect(checkIndex, oddColor, oddSize) {
        if (oddColor.length > 1) {
            this.getPrimeLink();
            for (let m = checkIndex[1], n = 0, sizeLen = oddSize.length; (n < sizeLen || n === 0); n += 1) {
                let sizeIndex = 0;
                if (sizeLen) sizeIndex = (m + n) % sizeLen;

                for (let i = checkIndex[0], j = 1, colorLen = oddColor.length; j < colorLen; j += 1) {
                    const colorIndex = (i + j) % colorLen;
                    const url = this.getLink(oddColor[colorIndex], sizeLen ? oddSize[sizeIndex] : 1);
                    if (url) {
                        return url;
                    }
                }
            }
        }
        return $('.cGoodsCrumb_itemLink:last').attr('href');
    }

    getLink(colorNum, sizeNum) {
        const linkVal = this.linkMap[colorNum * sizeNum];
        return linkVal.canBuy === 1 ? linkVal.url : '';
    }

    layerHref(urlResult) {
        window.sessionStorage.setItem(STORAGE_GOODS_REDIRECT_LINK, 1);
        const str = `<div class="redirectBox">
            <div class="redirectBox_title">${trans('goods.product_sold_out')}</div>
            <div class="redirectBox_content">${trans('goods.redirect_recommened', [3])}</div>
        </div>`;
        layer.open({
            type: 1,
            content: str,
            closeBtn: 0,
            area: ['480px', '130px'],
            time: 3000,
            offset: ['300px'],
            success() {
                let stNum = 3;
                function redirectST() {
                    setTimeout(() => {
                        stNum -= 1;
                        $('.redirectBox_content-time').html(stNum);
                        if (stNum !== 0) redirectST();
                    }, 1000);
                }
                redirectST();
            },
            end() {
                window.location.href = urlResult;
            }
        });
    }
}

export default new LinkRedirect();
