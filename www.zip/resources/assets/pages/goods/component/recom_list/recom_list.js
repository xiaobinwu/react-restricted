import { getGoodsRecommend } from 'js/service/other';

import GoodsInfo from 'js/core/goods/GoodsInfo.js';
import { slickFn } from 'js/core/slickFn.js';
import Pubsub from 'pubsub-js';
import temp from './recom_list.art';

// 商品信息
const GOODSINFO = GoodsInfo.get();
// 自适应个数配置
// const RESPONSIVE = {
//     1050: 4, // 浏览器宽度1050以下，推荐位可视区显示3个橱窗，以下类似
//     1250: 5,
//     1450: 6,
//     1650: 7,
//     1850: 8,
//     2050: 9,
//     2250: 10,
//     2450: 11,
//     2650: 12,
// };
const RESPONSIVE = {
    1251: 5, // 浏览器宽度1050以下，推荐位可视区显示3个橱窗，以下类似
    1581: 6,
};


function preSet(target) {
    Pubsub.subscribe('asyncExplore', (msg, { observeElement }) => {
        target.slick($(observeElement).find('.goodsRecom_list'));
    });
}

@preSet
class RecomList {
    constructor($container) {
        this.$container = $container;
        this.recType = this.$container.data('rectype');
        this.$slickBox = this.$container.find('.js-trackRecomList');
    }

    init() {
        if (this.$container.length) {
            this.renderData();
        }
    }

    show() {
        this.$container.addClass('show');
    }

    // 获取数据
    async getData(type = 1) {
        try {
            const res = await getGoodsRecommend({
                params: {
                    goodSn: GOODSINFO.goodsSn,
                    shopCode: GOODSINFO.shopCode,
                    categoryid: GOODSINFO.categoryId,
                    type
                }
            });
            if (+res.status === 0) {
                return res;
            }
            return [];
        } catch (error) {
            return [];
        }
    }

    // 渲染数据
    async renderData() {
        const self = this;
        const { recType, $slickBox } = self;

        // 待获取数据
        self.getData(recType).then((res) => {
            if (res.data.length) {
                // 填充数据到面板
                $slickBox.html(temp({
                    versionid: res.versionid,
                    bucketid: res.bucketid,
                    planid: res.planid,
                    plancode: res.plancode,
                    policy: res.policy,
                    list: res.data,
                    recType,
                }));

                // 更新货币
                Pubsub.publish('sysUpdateCurrency', {
                    context: $slickBox[0]
                });

                // 显示面板
                self.show();
            }
        }).catch((e) => {
            // e
        });
    }

    // 滑动效果（外部可直接调用）
    static slick($slickPanel, slickConfig = {}, responsive = RESPONSIVE) {
        const responsCfg = RecomList.generateRespConfig(responsive);
        const $slickWrap = $slickPanel.closest('.goodsRecom_wrap');

        const slConfig = {
            container: $slickPanel,
            variableWidth: false,
            infinite: false,
            prevArrow: $slickWrap.find('.js-btnSlickPrev'),
            nextArrow: $slickWrap.find('.js-btnSlickNext'),
            slidesToShow: 8,
            slidesToScroll: 8
        };

        Object.assign(slConfig, slickConfig);

        slConfig.responsive = responsCfg;

        slickFn(slConfig);
    }

    // 生成自适应配置（外部可直接调用）
    static generateRespConfig(config) {
        if (typeof config !== 'undefined') {
            const result = [];
            for (const c in config) {
                result.push({
                    breakpoint: c,
                    settings: {
                        slidesToShow: config[c],
                        slidesToScroll: config[c],
                    }
                });
            }
            return result;
        }
        return [];
    }
}

export default RecomList;
