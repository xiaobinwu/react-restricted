import { serviceSwitchInfo } from 'js/service/goods.js';

import './switchInfo.css';

class SwitchInfo {
    init(goodsSn) {
        this.$changeMultiLang = $('.js-changeMultiLang');
        if (this.$changeMultiLang.length === 0) return;
        this.goodsSn = goodsSn;
        this.boolStatus = false;
        this.$title = $('.goodsIntro_title');
        this.$titleProp = $('.goodsIntro_title-prop');
        this.$summary = $('.goodsIntro_summary');
        this.$describe = $('.js-goodsDescribe');
        this.$changeLang = $('.js-changeMultiLang').find('.changeMultiLang_text');
        this.$reloadIcon = $('.changeReloadIcon');
        this.nextRotate = 0;
        this.english = this.$changeLang.data('english');
        this.multiLang = this.$changeLang.data('multiLang');
        this.bindEvent();
    }

    bindEvent() {
        let multiLangLock = false;
        let englishLang = {}; // 接口返回的信息
        const changeBaseInfo = {}; // 原来的信息
        const self = this;
        this.$changeMultiLang.click(async (e) => {
            if (!multiLangLock) {
                multiLangLock = true;
                const data = await self.getLangInfo();
                if (data) {
                    englishLang = data;
                    const propArr = englishLang.goodAttrRespList.map(value => value.attrValue);
                    englishLang.goodTitleProp = propArr.join(' ');
                }
                changeBaseInfo.goodTitle = this.$title.html();
                changeBaseInfo.goodTitleProp = this.$titleProp.html();
                changeBaseInfo.subTitle = this.$summary.html();
                changeBaseInfo.webStyle = this.$describe.html();
            }
            if (englishLang.goodTitle) {
                self.boolStatus = !self.boolStatus;
                self.toggleChangeLang(self.boolStatus ? englishLang : changeBaseInfo);
            }
        });
    }

    async getLangInfo() {
        const { status, data } = await serviceSwitchInfo.http({
            params: {
                goodSn: this.goodsSn,
            },
        });
        let result = false;
        if (status === 0) result = data;
        return result;
    }

    toggleChangeLang({
        goodTitle,
        goodTitleProp,
        subTitle,
        webStyle,
    } = {}) {
        this.$title.html(goodTitle);
        this.$titleProp.html(goodTitleProp);
        this.$summary.html(subTitle);
        this.$describe.html(webStyle);

        this.nextRotate += 180;
        this.$reloadIcon.css('transform', `rotate(${this.nextRotate}deg)`);


        this.$changeLang.html(this.boolStatus ? this.multiLang : this.english);
    }
}

export default new SwitchInfo();
