
import temp from './buy_btn_status.art';

const buyBtnStatus = {
    init({
        // 商品可购状态 - 必填
        status,
        // 库存
        stock = 0,
        // 按钮放置区域
        $btnWrap = $('.js-buyBtnWrap'),
    }) {
        if (typeof status === 'undefined') {
            return;
        }

        const btnHtml = temp({
            status,
            stock,
        });

        $btnWrap.html(btnHtml);
    }
};

export default buyBtnStatus;
