/* #errorReport 商品信息纠错# */

import layer from 'layer';
import { trans } from 'js/core/translate.js';
import '../../module/pop.css';
import './report_error.css';

const URI_SUPPORT_CENTER = window.GLOBAL.SUPPORT_URL;

// 弹窗方法
async function asyncPop() {
    const html = await import('./report_error.art');
    layer.open({
        title: trans('goods.error_report'),
        content: html({
            URI_SUPPORT_CENTER,
        }),
        area: '560px',
        closeBtn: 1,
        btn: false,
        move: false,
        shadeClose: false,
        skin: 'goodsPop goodsPop_report',
    });
}

// 按钮触发弹窗
$(document).on('click', '[data-popbtn="reportError"]', function () { // eslint-disable-line
    asyncPop();
});
