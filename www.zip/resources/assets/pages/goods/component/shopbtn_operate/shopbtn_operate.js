import PubSub from 'pubsub-js';
import layer from 'layer';
import { postLocation } from 'js/utils/index.js';
import GoodsInfo from 'js/core/goods/GoodsInfo.js';
import { serviceCartEasyBuy } from 'js/service/common.js';
import { multiply } from 'js/core/currency';
import { isBfCountry } from 'js/core/bfCountry';
import { serviceCartSendQuickPay } from 'js/service/paycart.js';
import { trans } from 'js/core/translate.js';
import temp from './shopbtn_operate.art';
import './shopbtn_operate.css';

let $btnGoodsAddCart; // 按钮 - 加购物车
let $btnGoodsBuyNow; // 按钮 - 一键购
let $btnGoodsArrivalNotice; // 按钮 - 到货通知
let $btnGoodsBuyNowPaypal; // 按钮 - paypal一键购
const { DOMAIN_ORDER } = window.GLOBAL || {};
const URI_CHECKOUT = `${DOMAIN_ORDER}/checkout/index`; // 订单页面链接
const GOODSINFO = GoodsInfo.get();


export default {

    async init({
        // 商品可购状态 - 必填
        status,
        // 库存
        stock = 0,
        // 营销状态
        labelId = -1,
        // 按钮放置区域
        $btnWrap = $('.js-buyBtnWrap'),
        // 定金膨胀预付定金
        advanceAmount,
        isCanShowDep,
    }) {
        if (typeof status === 'undefined') {
            return;
        }
        const hidePaypal = GOODSINFO.ppExpressInfo.hide;
        // 判断是否网采决定禁用操作
        const disable = await this.isBfProduct();

        // 渲染加购、一键购等按钮
        $btnWrap.html(temp({
            status,
            stock,
            disable,
            labelId,
            advanceAmount,
            isCanShowDep,
            hidePaypal,
        }));

        if (+labelId === 28 && isCanShowDep) {
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $btnWrap[0],
            });
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $btnWrap[1],
            });
        }
        // pp支付可用状态需要用到营销状态
        this.labelId = labelId;
        this.isCanShowDep = isCanShowDep;

        // 动态加载按钮后暂存选择器
        $btnGoodsAddCart = $('.js-btnGoodsAddCart');
        $btnGoodsBuyNow = $('.js-btnGoodsBuyNow');
        $btnGoodsArrivalNotice = $('.js-btnGoodsArrivalNotice');
        $btnGoodsBuyNowPaypal = $('.js-btnGoodsBuyWithPaypal');

        // 切换paypal按钮显示
        this.switchPaypalBtn();

        this.bindEvent();
    },

    // 是否网采商品且当前是否需禁用显示网采的国家
    async isBfProduct() {
        return await isBfCountry() && +GOODSINFO.recommendedLevel === 14;
    },

    bindEvent() {
        const self = this;


        // 加购完成清除loading
        PubSub.subscribe('sysAddToCartAlways', () => {
            $btnGoodsAddCart.removeClass('loading');
        });

        // 订阅购买按钮可用状态切换
        PubSub.subscribe('goods.disableShopBtn', () => {
            self.disableShopBtn();
        });

        // 订阅购买按钮可用状态切换
        PubSub.subscribe('goods.enableShopBtn', () => {
            self.disableShopBtn(false);
        });

        // 数量变更时影响支付按钮可用状态
        PubSub.subscribe('goods.numberChange', () => {
            self.switchPaypalBtn('numberChange');
        });

        // 触发一键购
        $(document).on('click', '.js-btnGoodsBuyNow', (e) => {
            if (!$(e.currentTarget).hasClass('disabled')) {
                self.buyNow();
            }
        });

        // 触发加入购物车
        $(document).on('click', '.js-btnGoodsAddCart', (e) => {
            if (!$(e.currentTarget).hasClass('disabled')) {
                self.addToCart();
            }
        });

        // paypal购买
        $(document).on('click', '.js-btnGoodsBuyWithPaypal', (e) => {
            if (!$(e.currentTarget).hasClass('disabled')) {
                self.buyWithPaypal();
            }
        });

        // 到货通知按钮
        if ($btnGoodsArrivalNotice.length) {
            // arrivalNotice 弹层功能 异步载入
            (async function asyncArrivalNotice() {
                const { arrivalNotice } = await import('../arrival_notice/arrival_notice.js');
                // 按钮触发弹窗
                $btnGoodsArrivalNotice.on('click', () => {
                    arrivalNotice.showPop();
                });
            }());
        }
    },


    // 一键购买
    async buyNow(callback) {
        const self = this;
        const res = await serviceCartEasyBuy.http({
            loading: true,
            data: {
                goods: [window.SELECTEDGOODS],
            },
        });
        if (+res.status === 0) {
            const postData = {
                isQuickBuy: 1,
            };
            // 定金膨胀如果是可预订状态，传参数isDeposit给后台隐藏登录页面的访客购物入口
            if (+self.labelId === 28 && +self.isCanShowDep) {
                Object.assign(postData, {
                    isDeposit: 1,
                });
            }
            if (typeof callback === 'function') {
                callback(res);
            } else {
                postLocation(URI_CHECKOUT, postData);
            }
        } else {
            layer.msg(res.msg);
        }
    },

    // 加入购物车
    addToCart() {
        if ($btnGoodsAddCart.hasClass('loading')) {
            return;
        }
        $btnGoodsAddCart.addClass('loading');
        if ($('#js-navGoods').hasClass('goodsNav-fixed')) {
            PubSub.publish('sysAddToCart', {
                goods: window.SELECTEDGOODS,
                cartAni: {
                    imgSrc: GOODSINFO.thumb,
                    origin: $('.goodsNav-btnWrap .js-btnGoodsAddCart'),
                    target: $('.siteAside .siteAside_cart'),
                },
            });
        } else {
            PubSub.publish('sysAddToCart', {
                goods: window.SELECTEDGOODS,
                cartAni: {
                    imgSrc: GOODSINFO.thumb,
                    origin: $btnGoodsAddCart,
                },
            });
        }
    },

    // 使用paypal快捷支付
    buyWithPaypal() {
        if (GOODSINFO.ppExpressInfo && GOODSINFO.ppExpressInfo.channelCode) {
            this.buyNow(async (res) => {
                try {
                    const quickPayData = await serviceCartSendQuickPay.http({
                        loading: true,
                        params: {
                            channelCode: GOODSINFO.ppExpressInfo.channelCode
                        },
                    });

                    const { redirectUrl } = quickPayData.data;
                    if (redirectUrl) {
                        window.location.href = redirectUrl;
                    } else {
                        layer.msg(trans('user.data_error'));
                    }
                } catch (e) {
                    console.log('ERROR:shopbtn_operate=>buyWithPaypal', e);
                }
            });
        }
    },

    // 切换paypal支付按钮显示
    switchPaypalBtn(type) {
        if (GOODSINFO.ppExpressInfo) {
            const { addPrice, qty } = window.SELECTEDGOODS;
            const totalPrice = multiply(addPrice, qty);
            let btnNeedHide = false;
            const disable = $btnGoodsBuyNowPaypal.attr('data-disable') === 'true' ? 1 : 0; // 当前选项是否有物流

            // 商品单价大于paypal最大可支付价，则不可用paypay支付按钮
            if (addPrice > GOODSINFO.ppExpressInfo.ppMax) {
                btnNeedHide = true;
            }

            // 营销状态不可用情况 7:限时限量 28 定金膨胀
            if (/^(7|28)$/.test(this.labelId)) {
                btnNeedHide = true;
            }

            if (btnNeedHide) { // 隐藏paypal按钮
                $btnGoodsBuyNowPaypal.hide();
            } else if (totalPrice < GOODSINFO.ppExpressInfo.ppMin || totalPrice > GOODSINFO.ppExpressInfo.ppMax) {
                // 选择数量后结算总价小于最小支付价  或 大于最大支付价，置灰paypal支付按钮
                $btnGoodsBuyNowPaypal.addClass('disabled');

                // 数量变化且总结算金额大于最大可支付价
                if (type === 'numberChange' && totalPrice > GOODSINFO.ppExpressInfo.ppMax && !disable) {
                    layer.msg(trans('goods.cant_use_paypal_tip'));
                }
            } else if (!disable) { // 其他情况移除禁用,但没物流时不能移除禁用
                $btnGoodsBuyNowPaypal.removeClass('disabled');
            }
        }
    },

    // 购买相关按钮是否可用
    disableShopBtn(disable = true) {
        const flag = disable ? 'addClass' : 'removeClass';
        $btnGoodsAddCart[flag]('disabled');
        $btnGoodsBuyNow[flag]('disabled');
        $btnGoodsArrivalNotice[flag]('disabled');
        $btnGoodsBuyNowPaypal[flag]('disabled');
    }
};
