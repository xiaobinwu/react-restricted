
import { dateFormat } from 'js/utils/index.js';
import PubSub from 'pubsub-js';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import GoodsInfo from 'js/core/goods/GoodsInfo.js';

import { isLogin } from 'js/core/user.js';
import { serviceCouponUpdateInfo } from 'js/service/common.js';
import { serviceGoodsPromotion, serviceGoodsGift } from 'js/service/goods.js';
import { trans } from 'js/core/translate.js';

import layer from 'layer';
import tempCoupon from './coupon.art';
import tempPromotion from './promotion.art';
import './pop_gift.css';

const GOODSINFO = GoodsInfo.get();
const $couponWrap = $('#js-goodsCoupon');
const $promotionWrap = $('#js-goodsPromotion');

export const promotionCoupon = {
    async init(freeData) {
        // 获取满额免邮数据(shipping.js)
        this.freeShippingData = freeData;
        // 渲染
        this.render();
    },

    // 绑定事件
    bindEvent() {
        const self = this;
        return {
            // 优惠券
            coupon() {
                // 转换过期时间
                $couponWrap.on('mouseover', '.js-itemCoupon', (e) => {
                    const $this = $(e.currentTarget);
                    const $panel = $this.find('.js-couponEndTime');
                    const time = $panel.text();
                    self.couponTimeFormat(time, $panel);
                });

                // 查看更多
                $couponWrap.on('click', '.js-btnToggleCoupon', (e) => {
                    $(e.currentTarget).parent().toggleClass('is-show');
                });

                // 领取
                $couponWrap.on('click', '.js-itemCoupon', (e) => {
                    const $this = $(e.currentTarget);
                    const code = $this.attr('data-code');
                    const useLink = $this.attr('data-useLink');

                    self.getCoupon(code, useLink).then(() => {
                        // 变更领取状态
                        self.getCouponReceivedStatus({
                            $list: $this,
                        });
                    });
                });
            },

            // 活动
            promotion() {
                // 查看更多
                $promotionWrap.on('click', '.js-btnTogglePromo', () => {
                    $promotionWrap.toggleClass('is-show');
                });

                // 查看单条详情
                $promotionWrap.on('click', '.js-lkbtnViewPromo', (e) => {
                    const $this = $(e.currentTarget);
                    if (+$this.data('ispromo') === 0) {
                        e.preventDefault();
                        const activityId = $this.data('activityid');
                        self.giftPop(activityId);
                    } else {
                        $this.attr('href', $this.data('href'));
                    }
                });
            }
        };
    },

    // 渲染到页面
    async render() {
        const self = this;
        try {
            const { coupon, activity, discountInfo } = await this.getData();

            // 优惠券
            if (coupon && coupon.length) {
                const couponHtml = tempCoupon({
                    coupon,
                });
                $couponWrap.html(couponHtml);

                // 更新货币
                PubSub.publish('sysUpdateCurrency', {
                    context: $couponWrap[0]
                });

                self.couponRecStatus();
                self.bindEvent().coupon();
            }

            // 活动信息
            if ((activity && activity.length) || (discountInfo && discountInfo.length) || self.freeShippingData.logisticsName) {

                // 如果有优惠券信息
                if (discountInfo && discountInfo.length) {
                    discountInfo.forEach((item, index) => {
                        activity.push({
                            activity_TYPE: 'discount',
                            rule: item
                        });
                    });
                }
                if (self.freeShippingData.logisticsName) {
                    activity.push(self.freeShippingData);
                }

                const activityHtml = tempPromotion({
                    activity
                });
                $promotionWrap.html(activityHtml);

                // 更新货币
                PubSub.publish('sysUpdateCurrency', {
                    context: $promotionWrap[0]
                });

                self.bindEvent().promotion();
            } else {
                $promotionWrap.html('');
            }

        } catch (error) {
            // error
        }
    },

    // 获取数据
    getData() {
        return new Promise(async (resolve, reject) => {
            try {
                const { status, data } = await serviceGoodsPromotion.http({
                    errorPop: false,
                    loading: false,
                    params: {
                        shopCode: GOODSINFO.shopCode,
                        goodSn: GOODSINFO.goodsSn,
                        virCode: GOODSINFO.warehouseCode,
                        categoryId: GOODSINFO.categoryId,
                        brandCode: GOODSINFO.brandCode
                    },
                });
                if (+status === 0) {
                    resolve(data);
                }
            } catch (error) {
                reject(error);
            }
        });
    },

    // 领优惠券(券码)
    getCoupon(code, useLink) {
        return new Promise((resolve, reject) => {
            getCouponItem({
                templateCode: code,
                errorPop: false,
                defaultState: false
            }).then(({ status, msg, data }) => {
                if (status === 0) {
                    layer.open({
                        type: 1,
                        closeBtn: 1,
                        area: ['400px', '220px'],
                        content: `<div class="couponPopover"><p class="p1">${trans('goods.coupon_received')}</p>
                            <p>${trans('goods.recv_coupon_tip', [data.myCouponLink, '_self'])}</p>
                            ${useLink ? `<p class="use-link"><a href="${useLink}">${trans('cart.use_coupon')}</a></p>` : ''}</div>`,
                    });
                    // 领取成功
                    resolve();
                } else if (data && data.redirectUrl) {
                    window.location.href = data.redirectUrl;
                } else if (msg) {
                    layer.msg(msg);
                    // 可能刚才还高亮有，这会就没了，也要变更状态
                    resolve();
                } else {
                    // 没有领到
                    reject();
                }
            });
        });
    },

    // 优惠券领取状态
    async couponRecStatus() {
        const login = await isLogin();
        const $itemCoupon = $couponWrap.find('.js-itemCoupon');

        if (login && $itemCoupon.length) {
            await this.getCouponReceivedStatus({
                $list: $itemCoupon,
            });
        }
    },

    // 获取商品收藏状态
    async getCouponReceivedStatus({ $list }) {
        const sendDataArr = [];

        $list.each((index, ele) => {
            const $this = $(ele);
            const code = $this.attr('data-code');
            sendDataArr.push(code);
        });

        const res = await serviceCouponUpdateInfo.http({
            loading: false,
            params: {
                templateCode: sendDataArr.join(',')
            }
        });

        const resultData = res.data;
        $list.each((index, ele) => {
            const $this = $(ele);
            const code = $this.attr('data-code');

            if (resultData[code] && resultData[code].length > 0) {
                $this.addClass('is-used');
            } else {
                $this.removeClass('is-used');
            }
        });
    },

    // 优惠券倒计时格式化
    couponTimeFormat(time, $panel) {
        if (!$panel.data('is-trans') && /\d+/.test(time)) {
            const endTimeStr = dateFormat(time, 'dd/MM/yyyy');
            $panel.text(endTimeStr);
            $panel.data('is-trans', true);
        }
    },

    // 礼品弹窗
    async giftPop(activityId) {
        try {
            const temp = await import('./pop_gift.art');
            const res = await serviceGoodsGift.http({
                params: {
                    activityId,
                    warehouseCode: GOODSINFO.warehouseCode,
                },
            });
            if (+res.status === 0) {
                layer.open({
                    title: trans('order.goods_gift'),
                    content: temp({
                        list: res.data,
                    }),
                    area: '400px',
                    closeBtn: 1,
                    btn: false,
                    move: false,
                    shadeClose: false,
                });
            }
        } catch (error) {
            // error
        }
    }
};
