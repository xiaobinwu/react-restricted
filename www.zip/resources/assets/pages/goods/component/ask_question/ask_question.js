import layer from 'layer';
import { serviceGoodsFaqAdd } from 'js/service/goods.js';
import GoodsInfo from 'js/core/goods/GoodsInfo.js';
import { trans } from 'js/core/translate.js';
import 'component/select/select.js';
import 'js/utils/validation.config.js';
import './ask_question.css';
import temp from './ask_question.art';

const GOODSINFO = GoodsInfo.get();
const { PIPELINE } = window.GLOBAL;

const askQuestion = {
    init() {
        this.bindEvent();
    },

    bindEvent() {
        const self = this;

        // 按钮触发弹窗
        $(document).on('click', '[data-popbtn="askQuestion"]', () => {
            self.showPop();
        });
    },

    // 打开弹窗
    showPop() {
        const self = this;
        layer.open({
            title: trans('goods.ask_a_question'),
            content: temp({
                sku: GOODSINFO.goodsSn,
                goods_title: GOODSINFO.title,
                url: window.location.origin + window.location.pathname,
                pipe_line: PIPELINE,
            }),
            area: '560px',
            closeBtn: 1,
            btn: false,
            move: false,
            shadeClose: false,
            skin: 'goodsPop goodsPop_askQuestion',
            success() {
                const $form = $('#js-formFAQAdd');

                // 表单验证
                self.formValid($form);

                // 表单事件
                self.bindEventEach($form);
            },
        });
    },

    // 绑定事件（每次弹窗打开）
    bindEventEach($form) {
        const self = this;

        // 下拉菜单初始化
        $('#js-selPopQuestionTopic').select();

        // 语言下拉菜单
        $('#js-selPopQuestionLanguage').select();

        // 提交
        $form.off('submit').on('submit', (e) => {
            e.preventDefault();
            const $this = $(e.currentTarget);
            if ($this.valid()) {
                $this.find('input:submit').addClass('loading');
                self.submitQuestion($this).then(() => {
                    $form.find('input:submit').removeClass('loading');
                });
            }
        });

        // 绑定好事件后允许按钮提交
        $form.find('input:submit').removeClass('disabled');
    },

    // 表单验证
    formValid($form) {
        // 验证
        $form.validate({
            ignore: ':hidden:not(select)',
            rules: {
                nickname: {
                    required: true,
                },
                email: {
                    required: true,
                    email: true,
                },
                type: {
                    required: true,
                    number: true,
                },
                lang: {
                    required: true,
                },
                content: {
                    required: true,
                    maxlength: 3000,
                },
            },
        });
    },

    // 提交表单
    async submitQuestion($form) {
        try {
            const sdata = $form.serialize();
            const res = await serviceGoodsFaqAdd.http({
                data: sdata,
            });

            if (+res.status === 0 && res.msg) {
                layer.msg(res.msg);
            }

        } catch (error) {
            // error
        }
    }
};
askQuestion.init();
