import $ from 'jquery';
import { serviceGoodsFaqInquiry } from 'js/service/goods.js';
import 'component/paging/paging.js';

// 当前分类标识
let tabIndex = 0;

const pageSize = 10;
const sku = $('#js-hdGoodsSn').val();
const $panelPage = $('.js-faqPaging');
const $panelFilter = $('#js-faqFilter');
const $panelCustomerFAQ = $('#js-panelCustomerFAQ');

/**
 * 创建分页
 * @param {*当前页} currentPage
 * @param {*分页总数} totalPage
 */
function paging(currentPage, totalPage) {
    $panelPage.eq(tabIndex).paging({
        current: currentPage,
        total: totalPage,
        onChange(num) { // 跳页后执行的回调函数
            // 回到头部
            $(window).scrollTop($panelFilter.offset().top - 52);
            // 再次渲染分页
            reviewRender({// eslint-disable-line
                page: num,
            });
        },
    });
}

/**
 * FAQ渲染并分页
 * @param {*分页请求配置} options
 *  sku         商品SKU
 *  page        当前页数，默认：2
 *  page_size   每页数据大小，默认：10
 *  type        类型，
 *      0：全部
 *      1：产品信息 Product information
 *      2：库存状态 Stock Status
 *      4：支付 Payment
 *      5：运输 About Shipping
 *      6：其他 Others
 */
async function reviewRender(options) {
    const temp = await import('./faq.art');
    const defaults = {
        sku,
        page: 1,
        page_size: pageSize,
        type: $('.js-itemFaqFilter.active').data('type'),
    };
    const params = Object.assign(defaults, options);
    if (serviceGoodsFaqInquiry.cancel) {
        serviceGoodsFaqInquiry.cancel();
    }
    const res = await serviceGoodsFaqInquiry.http({
        params,
    });
    $panelCustomerFAQ.find('.js-itemPanelCustomerFAQ').eq(tabIndex).html(temp(res.data));
    paging(params.page, Math.ceil(res.data.total / params.page_size));

    $(window).scrollTop($panelFilter.offset().top - 5);
}

// tab - 分类切换
$panelFilter.find('.js-itemFaqFilter').on('click', function () { // eslint-disable-line
    const $this = $(this);
    const index = $this.index();
    const currentTypeTotal = $this.data('total');

    // 标识切换到当前分类
    tabIndex = index;

    // 当前分类tab高亮
    $this.addClass('active').siblings().removeClass('active');

    // 隐藏其他分类内容 显示当前分类内容
    $panelCustomerFAQ.find('.js-itemPanelCustomerFAQ').hide().eq(index).fadeIn();

    // 仅显示当前分类的分页
    $panelPage.hide().eq(tabIndex).show();

    // 为当前分类创建分页
    if (!$panelPage.eq(tabIndex).find('.gbPaging').length) {
        paging(1, Math.ceil(currentTypeTotal / pageSize));
    }
}).eq(0).trigger('click');
