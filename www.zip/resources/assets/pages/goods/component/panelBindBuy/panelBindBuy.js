import PubSub from 'pubsub-js';
import { serviceGetBindBuy } from 'js/service/goods.js';
import temp from './panelBindBuy.art';

const panelBindBuy = $('#js-panelBindBuy');

async function init(GOODSINFO, call) {
    const { status, data } = await serviceGetBindBuy.http({
        params: {
            goodSn: GOODSINFO.goodsSn,
            virCode: GOODSINFO.warehouseCode,
            categoryId: GOODSINFO.categoryId,
            recommendLevel: GOODSINFO.recommendLevel,
        },
    });

    if (status === 0) {
        const $thumb = panelBindBuy.attr('data-thumb');
        const $shopPrice = panelBindBuy.attr('data-currency');
        const title = panelBindBuy.attr('title');

        if (data.length) {
            panelBindBuy.removeClass('gb-hide').html(temp({
                $partsInfo: data,
                $shopPrice,
                $thumb,
                title,
            }));

            if (call) {
                call();
                PubSub.publish('sysInitLazyload');
            }
        }

    }

}

export default init;
