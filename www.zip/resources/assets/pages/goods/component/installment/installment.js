import Pubsub from 'pubsub-js';
import SimpleScrollbar from 'lib/simple-scrollbar/simple-scrollbar.js';
import { add, divide, multiply } from 'js/core/currency';
import temp from './installment.art';
import './installment.css';

const $wrapInstallment = $('#js-panelInstallment');
const $boxInstallment = $('#js-boxInstallMent');
const $panelFreeTimes = $('.js-installFreeTimes');

export class Installment {
    constructor() {
        this.bindEvent();
    }

    bindEvent() {
        const self = this;

        // 选择某项分期
        $(document).on('click', '.js-itemInstallment', (e) => {
            const $this = $(e.currentTarget);
            const installments = $this.attr('data-installments');

            // 设置选中的分期
            self.selectedInstallment = installments;

            // 显示选中的分期信息
            self.showSelected();

            // 关闭选项面板
            self.$eleSelect.dropdown('close');
        });

    }

    // 显示分期面板
    show() {
        $wrapInstallment.addClass('show');
    }

    // 筛选数据
    filterData(num = 1) {
        const self = this;
        const data = self.installmentData || {};
        const { price } = self;
        const result = [];
        if (data.installments instanceof Array && data.installments.length) {
            data.installments.forEach((item) => {
                // 分期总价
                const totalPrice = add(multiply(price, num), multiply(price, num, divide(item.rate, 100)));
                // 分期总价
                const perPrice = divide(totalPrice, item.installments);

                // 总金额限制    每期金额限制  分期数限制
                if (
                    totalPrice >= data.min && totalPrice <= data.max &&
                    perPrice >= data.minAmount &&
                    item.installments > 1
                ) {
                    result.push({
                        rate: item.rate,
                        installments: item.installments,
                        perPrice,
                        totalPrice,
                    });
                }
            });
        }

        self.resultList = result.reverse();
    }

    // 填充选项面板
    async renderSel() {
        const self = this;
        if (self.resultList instanceof Array && self.resultList.length) {

            // 填充列表
            $boxInstallment.html(temp({
                list: self.resultList,
            }));

            // 选项面板可切换
            self.$eleSelect = $boxInstallment.find('.select_inner');
            self.$eleSelect.dropdown();

            // 更新倾向
            Pubsub.publish('sysUpdateCurrency', {
                context: $boxInstallment[0],
            });

            // 变更免息数量
            $panelFreeTimes.text(self.getFreeTimes());

            // 漂亮的滚动条啊
            SimpleScrollbar.initEl(document.querySelector('#js-boxInstallMent .js-menuInstall'));

            // 显示分期面板
            self.show();
        }
    }

    // 从分期列表中提取指定期数的数据(期数)
    filterSelectedData(installment) {
        const list = this.resultList;
        let result = {};
        list.forEach((item, index) => {
            if (+item.installments === +installment) {
                result = item;
            }
        });
        return result;
    }

    // 在select bar上显示选中的内容
    async showSelected() {
        const self = this;

        // 确定已选择分期
        if (this.selectedInstallment > 0) {
            const selectedData = self.filterSelectedData(self.selectedInstallment);

            // 使用子模板
            const tempConfig = Object.assign({
                ART_TYPE: 'selected',
            }, selectedData);

            // 填充选择内容
            $boxInstallment.find('.select_title').html(temp(tempConfig));

            // 切换免息标识
            Installment.changeFreeTag(selectedData.rate);

            // 更新货币
            Pubsub.publish('sysUpdateCurrency', {
                context: $boxInstallment[0],
            });
        }
    }

    // 免息期数数量
    getFreeTimes() {
        const list = this.resultList;
        let count = 0;
        list.forEach((item, index) => {
            if (+item.rate === 0) {
                count += 1;
            }
        });
        return count;
    }

    // 变更无息标识状态
    static changeFreeTag(rate) {
        $boxInstallment.parents('.goodsIntro_attrBox').attr('data-free', +rate === 0);
    }
}
