import $ from 'jquery';
import layer from 'layer';
import Cookies from 'js/utils/cookie';
import Pubsub from 'pubsub-js';
import Rating from 'component/rating/rating.js';
import reviewsTrack from 'js/track/define/goodsDetail_reviews.js';
import { serviceReviewList, serviceReviewHelpful } from 'js/service/goods.js';
import { serviceCurrentCountry } from 'js/service/common';
import { isLogin } from 'js/core/user.js';
import 'component/paging/paging.js';

// 大数据埋点
reviewsTrack();
const pageSize = 10;
const reviewCount = $('#js-hdReviewCount').val();
const $panelPage = $('#js-reviewPaging');
const $panelReivew = $('#js-reviewWrap');
const $panelFilter = $('#js-reviewFilter');
const $panelSort = $('#js-currentSort');
const $panelRate = $('#js-reviewRate');
const sku = $('#js-hdGoodsSn').val();
// 去评论页面链接特殊处理（香港，大陆区）
const URI_WRITEVIEW = '/review/create';
const { DOMAIN_MAIN, PIPELINE } = window.GLOBAL || {};
const canSpecReviewCountry = ['HK', 'CN'];

/**
 * 仅创建分页
 * @param {*当前页} currentPage
 * @param {*分页总数} totalPage
 */
function paging(currentPage, totalPage) {
    $panelPage.paging({
        current: currentPage,
        total: totalPage,
        onChange(num) { // 跳页后执行的回调函数
            // 回到头部
            $(window).scrollTop($panelFilter.offset().top - 50);
            // 再次渲染分页
            reviewRender({// eslint-disable-line
                page: num,
                rate: $panelRate.data('rate') || 0
            });
        },
    });
}

/**
 * 评论渲染并分页
 * @param {*分页请求配置} options
 *  sku         商品SKU
 *  page        当前页数，默认：2
 *  page_size   每页数据大小，默认：10
 *  sort        排序，hot，helpful，recent
 *  type        类型，0：全部，1：带图，2：纯文字，3：视频
 */
async function reviewRender(options) {
    const temp = await import('./review.art');
    const defaults = {
        sku,
        page: 1,
        page_size: pageSize,
        sort: $panelSort.data('sort'),
        type: $('.js-btnReviewType.active').data('type'),
    };
    const params = $.extend(defaults, options);
    if (serviceReviewList.cancel) {
        serviceReviewList.cancel();
    }
    const res = await serviceReviewList.http({
        params,
    });
    $panelReivew.html(temp({
        list: res.data,
    }));

    // 评星初始化
    new Rating();
    paging(defaults.page, Math.ceil(res.data.review_count / defaults.page_size));

    $(window).scrollTop($panelFilter.offset().top - 5);
}

/**
 * 评论 点赞|倒彩
 * @param {*评论对应id} reviewId
 * @param {*评价评论类型 0:无用 1:有用} type
 */
async function helpful(reviewId, type, $btn) { // eslint-disable-line
    const res = await serviceReviewHelpful.http({
        errorPop: false,
        method: 'POST',
        data: {
            review_id: reviewId,
            type,
        },
    });
    if (+res.status === 0) {
        const $countPlace = $btn.find('.js-helpCount');
        const text = $countPlace.text();
        if (/\d/.test(text)) {
            $countPlace.text(parseInt(text, 10) + 1);
        }
    } else {
        layer.msg(res.msg);
    }
}

// 因第一页是同步输出，仅生成分页，对应第1页同步数据
paging(1, Math.ceil(reviewCount / pageSize));

// 触发 点赞|倒彩
$panelReivew.on('click', '.js-btnReviewHelp', function () { // eslint-disable-line
    const $this = $(this);
    const type = $this.data('help');
    const reviewId = $this.parents('li').data('review-id');
    helpful(reviewId, type, $this);
});

// 评论类型选择
$panelFilter.on('click', '.js-btnReviewType', function () { // eslint-disable-line
    $(this).addClass('active').siblings('.js-btnReviewType').removeClass('active');
    $panelRate.find('.js-rateNum').removeClass('ffColor');
    $panelRate.data('rate', 0);
    reviewRender();
});

// 评论星级筛选
$panelRate.on('click', '.js-rateNum', function () { // eslint-disable-line
    $(this).addClass('ffColor').siblings().removeClass('ffColor');
    const rateNum = $(this).data('rate');
    $panelRate.data('rate', rateNum);
    $($panelFilter.find('.js-btnReviewType')[0]).addClass('active').siblings('.js-btnReviewType').removeClass('active');
    reviewRender({
        type: 0,
        rate: rateNum
    });
});

// 评论排序选择
$panelFilter.on('click', '.js-itemSort', function () { // eslint-disable-line
    const sortText = $(this).text();
    const sort = $(this).data('sort');
    $panelSort.html(sortText).data('sort', sort);
    $panelRate.find('.js-rateNum').removeClass('ffColor');
    $panelRate.data('rate', 0);
    reviewRender();
});

// 订阅评论渲染事件，外部可发布
Pubsub.subscribe('goods.reviewsRender', (msg, config) => {
    reviewRender(config);
});

// 评论链接特殊处理
$(document).on('click', '.js-linkToWriteView', async (e) => {
    e.preventDefault();
    const $this = $(e.currentTarget);
    const reviewSku = $this.data('sku');
    const reviewWcode = $this.data('wcode');
    const userIsLogin = await isLogin();

    let url = $this.attr('href');
    let reviewCountry = Cookies.get('cdn_countryCode');

    if (!reviewCountry) {
        // 以下请求并不是一个正规的jsonp请求，但我们的目的只是为了加载它记录cookie值
        try { await serviceCurrentCountry.http(); } catch (err) { /* nothing */ }
        reviewCountry = Cookies.get('cdn_countryCode');
    }

    if (userIsLogin && canSpecReviewCountry.includes(reviewCountry) && PIPELINE === 'GB') {
        url = `${DOMAIN_MAIN}${URI_WRITEVIEW}?sku=${reviewSku}&wcode=${reviewWcode}`;
    }

    window.location.href = url;
});
