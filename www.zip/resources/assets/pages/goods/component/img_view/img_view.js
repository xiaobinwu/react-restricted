import layer from 'layer';
import { slickFn } from 'js/core/slickFn.js';
import './img_view.css';

// 图片预览
async function imgView(listData, defaultIndex) {
    if (!listData.length) {
        return;
    }
    let index = 0;
    if (typeof defaultIndex !== 'undefined') {
        index = defaultIndex;
    }
    const temp = await import('./img_view.art');
    layer.open({
        content: temp({
            list: listData,
            curIndex: index,
        }),
        area: '845px',
        closeBtn: 1,
        btn: false,
        move: false,
        shadeClose: false,
    });

    const $slick = $('#js-slickImgView');
    const slickObj = slickFn({
        container: $slick,
        infinite: false,
        lazyLoad: 'ondemand',
        prevArrow: $slick.prev('.js-btnViewImg'),
        nextArrow: $slick.next('.js-btnViewImg'),
        initialSlide: index,
    }).on('afterChange', (e, slick) => {
        $('.js-itemThumbImgView').removeClass('active').eq(slick.currentSlide).addClass('active');
    });

    // 点击缩略图
    $('.js-itemThumbImgView').off('click').on('click', function () {// eslint-disable-line
        slickObj.slick('slickGoTo', $(this).index());
    });
}

export default imgView;
