import layer from 'layer';
import PubSub from 'pubsub-js';
import { trans } from 'js/core/translate.js';
import { serviceGoodsWarehouseStatus } from 'js/service/goods.js';
import { replaceUrlVal } from 'js/utils/index.js';
import GoodsInfo from 'js/core/goods/GoodsInfo.js';
import linkRedirect from '../linkRedirect/linkRedirect';
import '../shipping/shipping.css';
import './warehouse_status.css';

const GOODSINFO = GoodsInfo.get();
const goodSn = GOODSINFO.goodsSn;
const shopCode = GOODSINFO.shopCode;
const currentWarehouseCode = GOODSINFO.warehouseCode;

function popSuccess() {
    PubSub.publish('sysUpdateCurrency', {
        context: document.querySelector('#js-tbodyWarehouseList'),
    });
    $('#js-tbodyWarehouseList').off('click').on('click', '.js-itemWarehouseStatus', function () { // eslint-disable-line
        if ($(this).find('.goodsIntro_warehouseItem').hasClass('active')) {
            layer.closeAll();
            return false;
        }
        const wid = $(this).data('code');
        window.location.href = replaceUrlVal('wid', wid);
    });
}

async function showWarehousePop() {
    const html = await import('./warehouse_status.art');
    const res = await serviceGoodsWarehouseStatus.http({
        errorPop: false,
        params: {
            good_sn: goodSn,
            shop_code: shopCode,
        },
    });
    if (+res.status === 0 && res.data) {
        layer.open({
            skin: 'customBtn',
            title: trans('goods.choose_another_warehouse'),
            content: html({
                list: res.data,
                currentWarehouseCode,
            }),
            area: '560px',
            closeBtn: 1,
            btn: false,
            move: false,
            shadeClose: false,
            success() {
                popSuccess();
            },
        });
    } else {
        linkRedirect.set({
            shipping: 1
        });
    }
}

export default showWarehousePop;
