/* #shipping 运费弹窗# */
import layer from 'layer';
import PubSub from 'pubsub-js';
import { trans } from 'js/core/translate.js';
import { getObjectMin } from 'js/utils/index.js';
import InputNumber from 'component/input_number/input_number.js';
import { serviceGoodsShippingCountry, serviceGetWareListAndShipping } from 'js/service/goods.js';
import GoodsInfo from 'js/core/goods/GoodsInfo.js';
import { getCountry, setCountry } from 'js/core/currency';
import 'component/combobox/combobox';

// 购买按钮状态
import shopBtnOperate from '../shopbtn_operate/shopbtn_operate.js';
// 推广链接301跳转
import linkRedirect from '../linkRedirect/linkRedirect';

import tempWarehouseList from './warehouse_list.art';
import './shipping.css';

const GOODSINFO = GoodsInfo.get();
const $btnShowShipping = $('#js-btnShippingPop'); // 开启运输弹窗

class Shipping {
    constructor({
        goodsImage = {}
    }) {
        this.goodsImage = goodsImage;

        // 获取数据必传字段
        this.num = 1;
        this.priceMd5 = '';
        this.goodsSn = GOODSINFO.goodsSn;
        this.warehouseCode = GOODSINFO.warehouseCode;
        this.advanceAmount = '';
        this.isCanShowDep = 0;
        this.isPlatform = GOODSINFO.isPlatform || 0; // 是否开平SKU,1 ：是，0：否
        this.deliveryType = GOODSINFO.deliveryType || 0; // 发货模式：0.自营 1.直发 2.代发（FBG）
        this.shipTemplateId = GOODSINFO.shipTemplateId || ''; // 物流运费模版ID,只有开平SKU有数据
        this.platformCategoryId = GOODSINFO.platformCategoryId || ''; // 平台分类ID,只有开平SKU有数据

        // 要运输到达的国家简码名称
        this.shipToCountryCode = null;
        this.shipToCountryName = null;

        // 仓库（国家地区）简码
        this.warehouseAbbr = ($('#js-hdWarehouseAbbr').val() || '').trim().toLocaleLowerCase();
        // 仓库（国家地区）名称
        this.warehouseName = ($('#js-hdWarehouseName').val() || '').trim().toLocaleLowerCase();

        // 运费列表数
        this.shipListData = [];
        // 可运送到达国家列表
        this.shipCountryData = undefined;
        // 页面展示信息对象
        this.pageInfo = {};
        // 缓存运输数据
        this.cacheData = undefined;

        // 初始化异步数据
        this.bindEvent();
    }

    async initAsyncData() {
        // 要运输到达的国家简码名称
        const dataCurrencyCountry = await getCountry();
        this.shipToCountryCode = dataCurrencyCountry.countryCode;
        this.shipToCountryName = dataCurrencyCountry.countryName;
    }

    bindEvent() {
        const self = this;

        // 触发打开运输列表
        $btnShowShipping.on('click', () => {
            self.showPop();
        });

        // 点选某项运输方式
        $(document).on('click', '.js-rdBtnShipWay', (e) => {
            const $this = $(e.currentTarget);
            self.selectShip($this.val());
        });

        // 异步价格获取成功后,自动填充商品属性区运输信息
        PubSub.subscribe('goods.multiInfoReady', async (msg, resData) => {
            const { price = {}, stock, goodsStatus } = resData;
            const canStock = getObjectMin(stock);

            self.priceMd5 = price.priceMd5;
            self.goodPrice = price.price;
            self.labelId = price.labelId;
            self.goodsStatus = goodsStatus;
            self.canStock = canStock;
            if (+price.labelId === 28) {
                // 定金膨胀预付定金
                self.advanceAmount = price.advanceAmount;
                self.isCanShowDep = price.isCanShowDep;
            }

            await self.initAsyncData();

            // 获取筛选后的仓库列表及运费信息
            // this.getWareListAndShipping();

            self.defaultFill(true);
        });

        // 公用顶部变更到达国家(地区) => 变更运输到达国家
        PubSub.subscribe('sysUpdateCountry', (msg, data) => {
            self.shipToCountryCode = data.gb_countryCode;
            self.shipToCountryName = data.gb_countryName;
            self.defaultFill();
        });
    }

    // 默认仅填充页面上数据
    defaultFill(isFirst = false) {
        this.fillInfo({
            where: ['page'],
            isFirst
        }, false);
    }

    // 显示运费选择弹窗
    async showPop() {
        const html = await import('./shipping.art');
        const self = this;

        // 弹窗显示整个运费操作面板
        this.popEle = layer.open({
            title: trans('goods.shipping_methods'),
            content: html({
                warehouseCode: self.warehouseAbbr,
                warehouseName: self.warehouseName,
                isPlatform: self.isPlatform,
            }),
            area: '750px',
            closeBtn: 1,
            btn: false,
            skin: 'goodsPop goodsPop_shipping',
            success() {
                // 数量控制
                self.panelInputNumber = new InputNumber('js-shippingQTY', {
                    onChange(val) {
                        self.num = val;
                        self.fillInfo({
                            where: ['ship', 'page'],
                        });
                    },
                });

                // 回填数量
                self.panelInputNumber.oInput.value = self.num;

                // 被动加载国家列表及运费列表
                self.fillInfo({
                    where: ['country', 'ship'],
                }, true);
            },
        });
    }

    // 异步获取获取运费数据
    ajaxData(useCache = false) {
        const self = this;
        return new Promise(async (resolve, reject) => {
            if (self.priceMd5 || self.isPlatform) {
                if (!useCache || undefined === this.cacheData) {
                    try {
                        const wareList = this.getAllWareList();
                        const baseInfo = GOODSINFO.baseGoodsInfo;
                        const params = {
                            goodSn: GOODSINFO.goodsSn,
                            countryCode: self.shipToCountryCode,
                            realWhCodeList: wareList.join(','),
                            realWhCode: GOODSINFO.warehouseCode,
                            priceMd5: self.priceMd5,
                            goodPrice: self.goodPrice,
                            num: self.num,
                            categoryId: GOODSINFO.categoryId,
                            saleSizeLong: baseInfo.saleSizeLong,
                            saleSizeWide: baseInfo.saleSizeWide,
                            saleSizeHigh: baseInfo.saleSizeHigh,
                            saleWeight: baseInfo.saleWeight,
                            volumeWeight: baseInfo.columeWeight,
                            properties: baseInfo.properties,
                            shipTemplateId: self.shipTemplateId,
                            isPlatform: self.isPlatform,
                            virWhCode: self.warehouseCode,
                            deliveryType: self.deliveryType,
                            platformCategoryId: self.platformCategoryId,
                            recommendedLevel: baseInfo.recommendedLevel,
                        };
                        const { status, data } = await serviceGetWareListAndShipping.http({
                            method: 'get',
                            errorPop: false,
                            params,
                        });
                        if (status === 0) {
                            this.cacheData = data;
                            resolve(this.cacheData);
                        } else {
                            this.cacheData = {};
                            resolve({});
                        }
                    } catch (e) {
                        reject();
                    }
                } else {
                    resolve(this.cacheData);
                }
            } else {
                resolve({});
            }
        });
    }

    // 填充信息
    fillInfo(config, useCache) {
        const self = this;
        const cfg = config || {
            where: ['page', 'country', 'ship'],
        };

        this.ajaxData(useCache).then((data) => {
            this.shipListData = data.shippingMethodList || [];
            this.wareListData = data.wareHoseList || [];
            this.taxData = data.taxData || [];
            this.isBfCountry = data.isBfCounty;
            const freeShippingData = data.freeShipping || [];
            /* const $goodsRepairWarranty = $('.js-goodsRepairWarranty');
            // 支持售后服务国家：西班牙,德国,英国,法国,意大利,葡萄牙
            const canShowCountry = ['ES', 'DE', 'GB', 'FR', 'IT', 'PT'];
            if (canShowCountry.indexOf(self.shipToCountryCode) > -1) {
                $goodsRepairWarranty.removeClass('hideTip');
            } else {
                $goodsRepairWarranty.addClass('hideTip');
            } */

            // 支持货到货款的国家则显示COD
            const $goodsShippingCod = $('.js-goodsShippingCod');
            const isCod = $goodsShippingCod.data('iscod');
            const codCountry = $goodsShippingCod.data('codcountry');
            if (isCod && codCountry.indexOf(self.shipToCountryCode) > -1) {
                $goodsShippingCod.addClass('show');
            } else {
                $goodsShippingCod.removeClass('show');
            }

            // 税费展示
            self.getTaxInfo(this.taxData);

            // BF网采商品处理
            // self.bfProduct(this.isBfCountry);

            // 大于1个显示仓时才显示仓列表
            if (this.wareListData.length > 1) {
                $('#js-panelWarehouseBox').addClass('show');
            } else {
                $('#js-panelWarehouseBox').removeClass('show');
            }

            if (cfg.where) {
                const where = cfg.where || [];
                const info = cfg.pageInfo;

                // 需要填充选中的方式到页面上
                if (where.includes('page')) {
                    if (!info) { // 默认取最经济的运输方式
                        self.pageInfo = self.getBestShipping();
                    } else { // 一般由用户主动选择某项运输方式
                        self.pageInfo = cfg.pageInfo;
                    }
                    self.fillInfoToPage();
                }

                // 需要填充国家列表
                if (where.includes('country')) {
                    self.fillCountryToSelect();
                }

                // 填充当前可先的运输方式到列表中
                if (where.includes('ship')) {
                    self.fillShipToTable();
                }
            }
            // promotion coupon 异步载入
            (async function asyncPromotionCoupon() {
                const { promotionCoupon } = await import('../promotion_coupon/promotion_coupon');
                promotionCoupon.init(freeShippingData);
            }());
        }).catch(() => {
            // nothing
        });
    }

    // 获取最实惠的配送方式(取selected标识)
    getBestShipping() {
        const shipList = this.shipListData;
        if (shipList.length) {
            let tempObj = {};
            shipList.forEach((item) => {
                if (item.selected) {
                    tempObj = item;
                }
            });
            return tempObj;
        }
        return {};
    }

    // 获取配送国家列表
    async getCountryList() {
        if (!this.shipCountryData) {
            const params = {
                warehouse_code: this.warehouseCode,
            };
            if (this.isPlatform) {
                Object.assign(params, {
                    shipTemplateId: this.shipTemplateId,
                    virWhCode: this.warehouseCode,
                    isPlatform: this.isPlatform,
                });
            }
            const { status, data } = await serviceGoodsShippingCountry.http({
                errorPop: false,
                params,
            });
            if (+status === 0) {
                this.shipCountryData = data.shippingCountry;
                return data.shippingCountry;
            }
        }
        return this.shipCountryData;
    }

    // 填充运费信息到页面上,新增仓库列表
    fillInfoToPage() {
        const self = this;
        const info = this.pageInfo || {};
        let costHtml = '';
        let fillHtml;
        let hasShip;

        // 2018-09-26 18:43:45 新增网采商品作为不能发物流处理
        if (
            /\d/.test(info.actualFee) &&
            typeof this.shipToCountryName !== 'undefined' &&
            typeof info.logisticsGroupName !== 'undefined'
        ) {
            // 免邮
            if (+info.actualFee === 0) {
                costHtml = `<strong class="goodsIntro_shippingCost">${trans('goods.free_shipping')}</strong>`;
            } else {
                costHtml = `
                    <strong class="goodsIntro_shippingCost js-currency" data-currency="${info.actualFee}">
                        ${info.actualFee}
                    </strong>`;
            }
            hasShip = true;
            fillHtml = trans('goods.cost_to_country_via_name', [costHtml, this.shipToCountryName, info.logisticsGroupName]);
        } else {
            hasShip = false;
            fillHtml = trans('goods.no_more_shipping_to_country', [`<span class="no-shipping-country">${this.shipToCountryName}</span>`]);
        }

        /**
         * 购买按钮状态
         * 2    stock>1 ? 加车|一键购: OOS
         * 3    中止购买
         * 4    到货通知
         */
        shopBtnOperate.init({
            status: self.goodsStatus,
            stock: self.canStock,
            labelId: self.labelId,
            advanceAmount: self.advanceAmount,
            isCanShowDep: self.isCanShowDep
        });

        // 填充物流耗费
        $('#js-panelShippingShow').html(fillHtml);

        // 展开物流信息显示
        $btnShowShipping.addClass('show');

        // 仓库列表显示
        if (self.wareListData && self.wareListData.length) {
            $('#js-panelWarehouse').html(tempWarehouseList({
                warehouseList: self.wareListData,
            }));

            // 其他仓sku选择弹窗
            self.showWareListPop(self.canStock);
        } else {
            linkRedirect.set({
                shipping: 1
            });
        }

        // 有物流可发
        if (hasShip) {
            // 更新货币
            PubSub.publish('sysUpdateCurrency', {
                context: $('#js-panelShippingShow')[0],
            });

            // 需要多少工作日
            self.dispatchSwitch('show');
            $('#js-panelBusinessDays').text(info.expectTime);


        } else { // 无物流可发
            self.dispatchSwitch('hide');
        }
    }

    dispatchSwitch(flag = 'show') {
        const clsSet = flag === 'show' ? 'addClass' : 'removeClass';
        $('#js-panelShippingDispatch')[clsSet]('show');
    }

    // 填充国家下拉列表
    async fillCountryToSelect() {
        const self = this;
        const shipCountryData = await this.getCountryList();
        const $selPopShipTo = $('#js-selPopShipTo');
        const getFrequentCountry = shipCountryData.filter(item => item.isFrequent === 1);

        $selPopShipTo.combobox({
            data: [getFrequentCountry, shipCountryData],
            placeholder: trans('goods.choose_another_country'),
            value: 'countryCode',
            text: 'countryName',
            default: self.shipToCountryCode,
            onChange($country) {
                self.shipToCountryCode = $country.val();
                self.shipToCountryName = $country.select('getText');

                // 只变更填充运输方式列表
                self.fillInfo({
                    where: ['ship', 'page'],
                });
            },
            onComplete($country) {
                $country.select({
                    searchable: [$country.find('optgroup').length || 1],
                    skin: 'select-country'
                });
            }
        });

        // 如果没有选中 国家（一般是公用顶部选中某国，但物流面板国家下拉列表中无此国家）
        if (!$('#js-selPopShipTo').val()) {
            // 选中第一项，即提示用户选择其他国家 => Choose another country
            $('#js-selPopShipTo').select('setValue', '');
        }
    }

    // 填充运费信息表格
    async fillShipToTable() {
        const self = this;
        const shipTemp = await import('./ship_type_list.art');

        $('#js-tbodyShipTypeList').html(shipTemp({
            data: self.shipListData,
        }));

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            context: $('#js-tbodyShipTypeList')[0],
        });
    }

    // 选择运费方式 触发事件
    selectShip(index) {
        const self = this;

        // 将指定行的运输方式置为选中
        try {
            this.cacheData.shippingMethodList.forEach((item, cIndex) => {
                Object.assign(item, {
                    selected: +index === cIndex,
                });
            });
        } catch (e) {
            // nothing
        }

        // 填充运费信息到页面上
        self.fillInfo({
            where: ['page'],
            pageInfo: self.shipListData[index],
        }, true);

        // 关闭弹层
        layer.close(self.popEle);
        setCountry(self.shipToCountryCode);
    }

    // 获取当前sku仓库列表-来自页面
    getAllWareList() {
        const wareList = [];
        GOODSINFO.warehouseList.forEach((item) => {
            wareList.push(item.code);
        });
        return wareList;
    }

    // 获取税费信息
    getTaxInfo(taxData = {
        taxTitle: undefined,
        taxContent: undefined
    }) {
        const $panelTaxInfo = $('#js-panelTaxInfo');
        if (typeof taxData.taxTitle !== 'undefined' && typeof taxData.taxContent !== 'undefined') {
            const taxInfoHtml = `
                <label class="goodsIntro_label">${taxData.taxTitle}:</label>
                <div class="goodsIntro_attrBox goodsIntro_taxRule">${trans(`goods.${taxData.taxContent}`)}</div>`;
            $panelTaxInfo.html(taxInfoHtml).addClass('show');
        } else {
            $panelTaxInfo.removeClass('show').empty();
        }
    }

    // 显示仓库列表弹窗（仅当当前仓无库存时显示） 2018-04-13 16:55:56改：当前仓不为空 且 访问仓与当前仓不一致 时弹窗
    // 选中状态，判断是否上架且无库存 弹
    // 未选中状态，判断返回的仓库列表数据是否不为空
    async showWareListPop(stock) {
        let flag = 0;
        const $panelWarehouse = $('#js-panelWarehouse'); // 库存面板区
        const $itemWarehouseCheck = $panelWarehouse.find('.js-btnWarehouseCheck'); // 库存所有选项
        const wareLen = $('#js-panelWarehouse').find('.goodsIntro_warehouseActive').length;

        // 有选中的仓，库存为0
        if (wareLen && stock < 1) {
            flag = 1;
        }

        // 有仓库列表 但 没有选中仓
        if ($itemWarehouseCheck.length && !wareLen) {
            flag = 1;
        }

        if (flag) {
            // 页面加载时选仓弹窗
            const { default: showWarehousePop } = await import('../warehouse_status/warehouse_status.js');
            showWarehousePop();
        } else {
            linkRedirect.set({
                shipping: 1
            });
        }
    }
}

export default Shipping;
