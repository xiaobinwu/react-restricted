/* #Arrival Notice 到货通知弹窗# */
import layer from 'layer';
import { serviceArrivalNotice } from 'js/service/goods.js';
import GoodsInfo from 'js/core/goods/GoodsInfo.js';
import { trans } from 'js/core/translate.js';
import temp from './arrival_notice.art';
import '../../module/pop.css';
import './arrival_notice.css';

const GOODSINFO = GoodsInfo.get();

export const arrivalNotice = {
    // 弹窗方法
    showPop() {
        const self = this;
        layer.open({
            title: trans('goods.arrival_notice'),
            content: temp({
                goodsSn: GOODSINFO.goodsSn,
                vhCode: GOODSINFO.warehouseCode,
                lang: window.GLOBAL.LANG,
                t: +new Date()
            }),
            area: '560px',
            closeBtn: 1,
            btn: false,
            move: false,
            shadeClose: false,
            skin: 'goodsPop goodsPop_arrivalNotice',
            success() {
                self.bindEvent();
            }
        });
    },

    bindEvent() {
        const self = this;

        // 表单验证
        $('#js-formArrivalNotice').validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                },
                captch: {
                    required: true,
                },
            },
        });

        // 表单提交
        $('#js-formArrivalNotice').off('submit').on('submit', function (e) {// eslint-disable-line
            e.preventDefault();
            if ($(this).valid()) {
                self.subArrivalNotice($(this).serialize());
            }
        });

        // 刷新验证码
        $('.js-btnRefreshVerify').off('click').on('click', function () { // eslint-disable-line
            self.refreshVerify();
        });
    },

    // 提交订阅
    async subArrivalNotice(sdata) {
        const res = await serviceArrivalNotice.http({
            errorPop: false,
            loading: true,
            data: sdata,
        });
        layer.msg(res.msg || 'warning:Server error');
    },

    // 刷新验证码
    refreshVerify() {
        const $imgVerify = $('#js-verifyArrivalNotice');
        $('[name=captch]').val('');
        $imgVerify.attr('src', `${$imgVerify.data('path')}?${Math.random()}`);
    }
};
