/**
 * 图片放大
 * paramet：
 *    wrap为鼠标经过移动的元素
 *    src为大图资源地址
 */
let bI;
export default function bigImg({ wrap, smallSrc, bigSrc }) {
    if (!bI) {
        bI = new BigImg({ wrap, smallSrc, bigSrc });
    } else {
        bI.generatorIMG(smallSrc, bigSrc);
    }
}

class BigImg {
    constructor({ wrap, smallSrc, bigSrc }) {
        this.RADUISW = 0;
        this.RADUISH = 0;
        this.bg = 'rgba(163, 227, 255, 0.4)';
        this.wrapElement = document.querySelector(wrap); // 鼠标经过的元素 本文称为容器
        this.width = parseFloat(window.getComputedStyle(this.wrapElement, null).getPropertyValue('width')); // 容器宽度
        this.height = parseFloat(window.getComputedStyle(this.wrapElement, null).getPropertyValue('height')); // 容器高度
        this.ST = 0; // 定时延时
        this.scrollLock = false; // 滚动隐藏
        this.clientWidth = document.body.clientWidth;
        this.generatorIMG(smallSrc, bigSrc);
    }

    init() {
        this.plugsBox = document.createElement('div'); // 生成所有的元素都在此容器，并且生成在body一级子元素
        this.plugsBox.setAttribute('style', 'position: fixed;display:none;z-index:2;');
        this.divCover = document.createElement('div'); // 鼠标经过容器，容器显示的遮罩层
        this.divCover.setAttribute('style', `
            position: absolute;
            width:${this.RADUISW * 2}px;
            height:${this.RADUISH * 2}px;
            background:${this.bg};
        `);
        this.plugsBox.appendChild(this.divCover);

        const bigImgParent = document.createElement('div'); // 展示的大图
        bigImgParent.setAttribute('style', `
            position:relative;
            width: ${this.width}px; 
            height: ${this.height}px;
            top:0; left: ${this.width + 20}px;
            overflow:hidden;
            background: #fff;
        `);
        bigImgParent.className = 'gbBigImg';

        bigImgParent.addEventListener('mousemove', (e) => {
            e.stopPropagation();
        });
        this.wrapElement.addEventListener('mouseenter', this.mouseenter.bind(this));
        this.wrapElement.addEventListener('mousemove', this.mouseMove.bind(this));
        this.wrapElement.addEventListener('mouseleave', this.mouseleave.bind(this));
        this.plugsBox.addEventListener('mousemove', this.mouseMove.bind(this));
        this.plugsBox.addEventListener('mouseleave', this.mouseleave.bind(this));
        window.addEventListener('scroll', this.winScroll.bind(this));
        this.plugsBox.appendChild(bigImgParent);
        document.body.appendChild(this.plugsBox);
        this.bigImgParent = bigImgParent;
    }

    resizeStylePlugsBox() {
        this.divCover.style.width = `${this.RADUISW * 2}px`;
        this.divCover.style.height = `${this.RADUISH * 2}px`;

        this.bigImgParent.style.width = `${this.width}px`;
        this.bigImgParent.style.height = `${this.height}px`;
        this.bigImgParent.style.left = `${this.width + 20}px`;
    }

    calcRaduis() {
        this.smallWidth = Math.min(this.smallImgWidth, this.width);
        this.smallHeight = Math.min(this.smallImgHeight, this.height);
        this.RADUISW = (this.smallWidth * this.width) / this.biggImg.width / 2;
        this.RADUISH = (this.smallHeight * this.height) / this.biggImg.height / 2;
    }

    async generatorIMG(smallSrc, bigSrc) {
        try {
            const [smallImg, biggImg] = await Promise.all([this.imgLoad(smallSrc), this.imgLoad(bigSrc)]);
            this.smallImgWidth = smallImg.width;
            this.smallImgHeight = smallImg.height;
            this.biggImg = biggImg;
            this.calcRaduis();
            if (!this.plugsBox) this.init();
            else {
                this.divCover.style.width = `${this.RADUISW * 2}px`;
                this.divCover.style.height = `${this.RADUISH * 2}px`;
            }
            biggImg.setAttribute('style', `
            position:absolute;
            top:50%;
            left:50%;
            margin-left:-${biggImg.width / 2}px;
            margin-top:-${biggImg.height / 2}px;
            width:${biggImg.width}px;
            height:${biggImg.height}px;
        `);
            this.bigImgParent.innerHTML = '';
            this.bigImgParent.appendChild(biggImg);
        } catch (e) {
            // nothing
        }
    }

    imgLoad(src) {
        return new Promise((resolve, reject) => {
            const IMG = new Image();
            IMG.src = src;
            IMG.onload = () => {
                resolve(IMG);
            };
            IMG.onerror = () => {
                reject(new Error(`Image load error: ${src}`));
            };
        });
    }

    mouseenter(event) {
        // 判断页面是否进行过resize
        const currentClientWidth = document.body.clientWidth;
        if (currentClientWidth !== this.clientWidth) {
            this.clientWidth = currentClientWidth;
            this.resize();
        }
        this.clientRect = this.wrapElement.getBoundingClientRect();
        this.plugsBox.style.top = `${this.clientRect.top}px`;
        this.plugsBox.style.left = `${this.clientRect.left}px`;
        this.scrollLock = false;
        this.mouseMove(event, true);
    }

    resize() {
        this.width = parseFloat(window.getComputedStyle(this.wrapElement, null).getPropertyValue('width')); // 容器宽度
        this.height = parseFloat(window.getComputedStyle(this.wrapElement, null).getPropertyValue('height')); // 容器高度
        this.calcRaduis();
        this.resizeStylePlugsBox();
    }

    mouseMove(event, isEnter) {
        if (this.ST) return;
        if (this.scrollLock) { // 滚动时鼠标还在元素中
            this.scrollLock = false;
            this.mouseenter();
        }
        if (!isEnter) {
            this.ST = setTimeout(() => {
                this.ST = 0;
                // hack offsetX 不准 why!!!
                const x = event.clientX - this.clientRect.left;
                const y = event.clientY - this.clientRect.top;
                this.showBigImg(x, y);
            }, 15);
        }
    }

    mouseleave() {
        setTimeout(() => {
            // 极端情况会出问题：用户急速甩动，出现鼠标脱离divCover 并且那一瞬间鼠标突然没动
            if (!this.ST) {
                clearTimeout(this.ST);
                this.ST = 0;
                this.plugsBox.style.display = 'none';
            }
        }, 15);
    }

    winScroll(e) {
        if (!this.scrollLock) {
            this.scrollLock = true;
            this.mouseleave();
        }

    }


    showBigImg(x, y) {

        // 可用鼠标xy距离容器中间点的距离
        const pointMsg = {
            distanceX: 0,
            distanceY: 0,
        };

        pointMsg.distanceX = (this.width / 2) - x;
        if (pointMsg.distanceX > (this.width / 2) - this.RADUISW) pointMsg.distanceX = (this.width / 2) - this.RADUISW;
        else if (pointMsg.distanceX < -((this.width / 2) - this.RADUISW)) pointMsg.distanceX = -((this.width / 2) - this.RADUISW);

        pointMsg.distanceY = (this.height / 2) - y;
        if (pointMsg.distanceY > (this.height / 2) - this.RADUISH) pointMsg.distanceY = (this.height / 2) - this.RADUISH;
        else if (pointMsg.distanceY < -((this.height / 2) - this.RADUISH)) pointMsg.distanceY = -((this.height / 2) - this.RADUISH);

        this.divCover.style.top = `${(this.height / 2) - pointMsg.distanceY - (this.RADUISH - 1)}px`;
        this.divCover.style.left = `${(this.width / 2) - pointMsg.distanceX - (this.RADUISW - 1)}px`;

        this.plugsBox.style.display = 'block';
        const transNum = `translate(
            ${(pointMsg.distanceX * Math.abs(this.biggImg.width - this.smallWidth)) / 2 / ((this.smallWidth / 2) - this.RADUISW)}px, 
            ${(pointMsg.distanceY * Math.abs(this.biggImg.height - this.smallHeight)) / 2 / ((this.smallHeight / 2) - this.RADUISH)}px)
        `;
        this.biggImg.style.transform = transNum;
        this.biggImg.style.webkitTransform = transNum;
        this.biggImg.style.mozTransform = transNum;
        this.biggImg.style.msTransform = transNum;
    }
}
