/**
 * @Desc: 商详页js
 * @Author: luochongfei
 * @Date: 2017-11-06 10:22:10
 */
import 'js/bootstrap';

import $ from 'jquery';
import PubSub from 'pubsub-js';
import layer from 'layer';
import lazyObserver from 'js/utils/lazyObserver';
import videoPlay from 'js/core/videoPlay.js';
import GoodsViewHistory from 'js/core/goods/GoodsViewHistory.js';
import { initLazyload } from 'js/utils/lazyload';
import { isLogin } from 'js/core/user.js';

import { slickFn } from 'js/core/slickFn.js';

import {
    transform,
    addSymbol,
    add,
} from 'js/core/currency';

import {
    // getObjectMin,
    replaceUrlVal,
    getUrlQuery,
} from 'js/utils/index.js';

import {
    serviceCollectAdd,
    serviceCollectRemove,
    serviceStoreCollect
} from 'js/service/common.js';

import {
    serviceWholesaleInquiry,
    serviceGoodsMultiInfo,
    serviceGoodsCollect,
} from 'js/service/goods.js';

// 商品业务逻辑
import GoodsInfo from 'js/core/goods/GoodsInfo.js';

// 网采国家判断
import { isBfCountry } from 'js/core/bfCountry';

// 记录进入商详来源
import RecordToGoods from 'js/core/goods/recordToGoods.js';


// 大数据埋点
import goodsTrack from 'js/track/define/goods.js';

// 多语言
import { trans } from 'js/core/translate.js';
// artTemplate挂载
import runtime from 'art-template/lib/runtime';

import StateStore from 'js/core/goods/stateStore';

// 公用tab
import 'component/tab/tab.js';
// 公用评星
import Rating from 'component/rating/rating.js';
// 公用分享
// import Share from 'component/share/share.js';
// 公用加减组件
import InputNumber from 'component/input_number/input_number.js';
// 公用多规格属性
import GoodsAttr from 'component/goods_attr/goods_attr.js';
// 公用下拉切换
import 'component/dropdown/dropdown.js';
// 告知用户使用cookie通知
import generatorCookiePolicy from 'modules/common/cookie_policy/cookie_policy';

// 弹窗-商品纠错
// import '../component/report_error/report_error.js';
// 弹窗-税费|价格保护|免责声明
import '../component/normal_info_pop/normal_info_pop.js';
// 弹窗-运费
import Shipping from '../component/shipping/shipping.js';
// 商品营销价格状态
import GoodsPromoPrice from '../component/goods_promo_price/goods_promo_price.js';
// 购买按钮状态
// import shopBtnOperate from '../component/shopbtn_operate/shopbtn_operate.js';

// 弹窗-提问
import '../component/ask_question/ask_question.js';

// 评论模块
import '../component/review/review.js';
// 评论图片预览
import imgView from '../component/img_view/img_view.js';
// faq
import '../component/faq/faq.js';

// 推荐位
import RecomList from '../component/recom_list/recom_list.js';
// 图片放大器
import bigImg from './bigImg';
// 搭售版块
import panelBindBuy from '../component/panelBindBuy/panelBindBuy.js';
// 切换语言查询多语言信息
import switchInfo from '../component/switchInfo/switchInfo.js';

// 推广链接，商品不可购买状态301跳转
import linkRedirect from '../component/linkRedirect/linkRedirect';

// 商详页样式
import './goods_detail.css';


// ******************************** 本页全局变量 ********************************
// const WINLOCATION = window.location.href;
const GOODSINFO = GoodsInfo.get();
window.SELECTEDGOODS = {
    warehouseCode: GOODSINFO.warehouseCode,
    goodsSn: GOODSINFO.goodsSn,
    qty: 1,
};
// 转汇率
const transformCy = pPrice => transform({
    price: pPrice,
});

const $panelRecomNormal = $('#js-goodsRecommendSlick');
const $panelRecomAlsoBought = $('#js-goodsAlsoBoughtSlick');
const $panelRecomGuessLike = $('#js-goodsGuessLikeSlick');
const $panelRecomSponsored = $('#js-goodsSponsoredSlick');

const stateStore = new StateStore();

// ******************************** 商详全局调用 - 前置 ********************************
const goodsGlobalBefore = {
    init() {
        // 大数据埋点
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            window.goodsPriceData = resData.price;
            goodsTrack();

            // 推荐位1
            lazyObserver({
                callBack: (observerTarget) => {
                    new RecomList($panelRecomNormal).init();
                },
                observeDom: $('#js-goodsRecommendSlick-flag')[0],
            });

            // 推荐位2（其他用户也买）
            lazyObserver({
                callBack: (observerTarget) => {
                    new RecomList($panelRecomAlsoBought).init();
                },
                observeDom: $('#js-goodsAlsoBoughtSlick-flag')[0],
            });

            // 推荐位3（猜你喜欢）
            lazyObserver({
                callBack: (observerTarget) => {
                    new RecomList($panelRecomGuessLike).init();
                },
                observeDom: $('#js-goodsGuessLikeSlick-flag')[0],
            });

            // 推荐位4（Sponsored第四泳道）
            lazyObserver({
                callBack: (observerTarget) => {
                    new RecomList($panelRecomSponsored).init();
                },
                observeDom: $('#js-goodsSponsoredSlick-flag')[0],
            });
        });

        // 商详页所有art模板注入语言转换方法
        runtime.trans = trans;
    }
};
goodsGlobalBefore.init();

// ******************************** 商品图片 ********************************
const $panelIntroNormalImg = $('#js-goodsNormalImg');
// const $panelIntroImgPreview = $('#js-goodsImgPreview');
const $panelIntroThumbs = $('#js-goodsThumbnail');

const $thumbnailSlick = $('#js-goodsThumbnail');
const goodsImage = {
    init() {

        // 网采图片处理
        this.bfProduct();

        // 绑定事件
        this.bindEvent();
    },

    bindEvent() {
        const self = this;
        const $thumbs = $panelIntroThumbs.find('.js-goodsThumbnailItem');

        // 商品缩略图点击切换对应大图
        $(document).on('mouseover', '.js-goodsThumbnailItem', (e) => {
            self.switchOrigin($(e.currentTarget), $thumbs);
        });
    },

    // 主图初始化
    mainImgInit(flag) {
        // 移除懒加载完成标识
        $('#js-goodsNormalImg').removeAttr('data-was-processed')
            .parent().css('pointer-events', flag === 'origin' ? 'auto' : 'none');

        // 初始化加载图像
        initLazyload({
            elements_selector: '#js-goodsNormalImg',
            data_src: flag === 'origin' ? 'img' : 'gbimg',
        });

        // 放大镜
        bigImg({
            wrap: '.goodsIntro_largeImgWrap',
            smallSrc: $panelIntroNormalImg.attr('src'),
            bigSrc: $panelIntroNormalImg.attr('data-zoom')
        });

        goodsDesc.descImgHandle(flag);

        const $thumbs = $panelIntroThumbs.find('.js-goodsThumbnailItem');

        // 缩略图滑动
        this.thumbSlick();

        // 默认显示第一张
        this.thumbActive($thumbs.eq(0), $thumbs);
    },

    // 网采商品处理
    async bfProduct() {
        if (await isBfCountry() && +GOODSINFO.recommendedLevel === 14) {
            this.mainImgInit();
        } else {
            this.mainImgInit('origin');
        }
    },

    // 切换为指定的预览大图
    switchOrigin($thumb, $thumbs) {
        const normalImg = $thumb.data('normal-src');
        const originImg = $thumb.data('origin-src');

        // 切换大图src
        $panelIntroNormalImg.attr('src', normalImg).attr('data-zoom', originImg);

        // 加载大图loading
        let originIsLoaded = false;
        clearTimeout(this.thumbTimer);
        this.thumbTimer = setTimeout(() => {
            if (!originIsLoaded) {
                $panelIntroNormalImg.parent().addClass('loading');
            }
        }, 100);
        $panelIntroNormalImg.get(0).onload = () => {
            originIsLoaded = true;
            $panelIntroNormalImg.parent().removeClass('loading');
        };

        // 大图放大镜
        bigImg({
            wrap: '.goodsIntro_largeImgWrap',
            smallSrc: $panelIntroNormalImg.attr('src'),
            bigSrc: $panelIntroNormalImg.attr('data-zoom')
        });

        // 缩略图高亮样式
        this.thumbActive($thumb, $thumbs);
    },

    // 商品缩略图滑动
    thumbSlick() {
        slickFn({
            container: $thumbnailSlick,
            variableWidth: false,
            infinite: false,
            slidesToShow: 6,
            slidesToScroll: 6,
            lazyLoad: 'ondemand',
            prevArrow: $thumbnailSlick.prev('.js-slickBtn'),
            nextArrow: $thumbnailSlick.next('.js-slickBtn'),
            respondTo: 'slider',
            responsive: [{
                breakpoint: 343,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 5,
                }
            }, {
                breakpoint: 442,
                settings: {
                    slidesToShow: 6,
                    slidesToScroll: 6,
                }
            }]
        });
    },

    // 当前选中缩略图高亮
    thumbActive($thumbActive, $thumbs) {
        $thumbs.removeClass('active');
        $thumbActive.addClass('active');
    },
};
setTimeout(() => {
    goodsImage.init();
}, 800);

// ******************************** 商品分享 ********************************
// const goodsShare = {
//     init() {
//         this.insGoodsShare = new Share();
//         this.bindEvent();
//     },
//     bindEvent() {
//         this.insGoodsShare.facebook({
//             appId: 900125666754558,
//             selector: '.js-btnIntroShareFB',
//             url: WINLOCATION,
//         });
//         this.insGoodsShare.twitter({
//             desc: GOODSINFO.title,
//             url: WINLOCATION,
//             selector: '.js-btnIntroShareTT',
//         });
//         this.insGoodsShare.vk({
//             selector: '.js-btnIntroShareVK',
//         });
//         this.insGoodsShare.pinterest({
//             selector: '.js-btnIntroSharePT',
//             url: WINLOCATION,
//             title: GOODSINFO.title,
//         });
//     },
// };
setTimeout(() => {
    $.getScript('https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5c1325729d50f61c', () => {
        $('#js-panelShare').addClass('show');
    });
}, 1000);


// ******************************** 商品-营销区（营销描述|营销价格|手机专享价|优惠券|促销活动） ********************************
const $panelPromoPriceDesc = $('#js-panelIntroSaleDescribe');
const $panelAppOnly = $('#js-goodsIntroAppOnly');
const $panelAppSavePrice = $('#js-panelIntroAppSavePrice');
const goodsPromo = {
    init() {
        // 营销价格状态
        this.insGoodsPromoPrice = new GoodsPromoPrice();
        this.insGoodsPromoPrice.init();

        this.bindEvent();
    },

    // 绑定事件
    bindEvent() {
        const self = this;

        // 异步价格获取成功
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            const { price = {} } = resData;

            // 营销价格描述
            $panelPromoPriceDesc.html(price.declare);
            // app节省价格
            self.appExtraPrice(price.price, price.labelId);

            // 更新货币
            PubSub.publish('sysUpdateCurrency');
        });

        // app专享价
        if ($panelAppOnly.length) {
            $panelAppOnly.on('mouseover', '.goodsIntro_appSave', async (e) => {
                const $this = $(e.currentTarget);
                $this.addClass('show');
                const $qrcode = $this.find('.js-goodsQrcode');
                if (!$qrcode.hasClass('qrcoded')) {
                    const img = await self.createQrcode();
                    $qrcode.attr('src', img).addClass('qrcoded');

                    // 图片懒加载
                    PubSub.publish('sysInitLazyload');
                }
            }).on('mouseout', '.goodsIntro_appSave', (e) => {
                const $this = $(e.currentTarget);
                $this.removeClass('show');
            });
        }
    },

    // app节省价格
    appExtraPrice(price, labelId) {
        // app专享价处理
        const salePrice = price;
        const appPrice = GOODSINFO.appPrice;
        const appSavePrice = add(salePrice, -appPrice);
        if (appSavePrice > 0 && !/^(1|28)$/.test(labelId)) {
            $panelAppOnly.show();
            $panelAppSavePrice.attr('data-currency', appSavePrice);
        } else {
            $panelAppOnly.hide();
        }
    },

    // 创建二维码
    async createQrcode() {
        // 老版本   gearbest://product?goods_id=&wid=
        // SOA新版  gearbest://product?goods_web_sn=&warehouse_code=
        const uri = `gearbest://product?goods_id=${GOODSINFO.webGoodsSn}&wid=${GOODSINFO.warehouseCode}`;
        const jrQrcode = await import('jr-qrcode');
        const base64 = jrQrcode.getQrBase64(uri, {
            padding: 0,
            width: 150,
            height: 150
        });
        return base64;
    }

};
goodsPromo.init();


// ********************* 商品-属性区（仓库|数量|规格属性|运输） *********************
const $panelIntroAttr = $('#js-introAttrWrap'); // 商品属性面板
const $panelGoodsQTY = $('#js-goodsIntroQTY'); // 商品数量控件面板
const $panelWarehouse = $('#js-panelWarehouse'); // 库存面板区
const $panelIntroStockTag = $('#js_panelIntroStockTag'); // 库存状态标识
const $panelIntroMaxPerOrder = $('#js_panelIntroMaxPerOrderg'); // 可购买上限显示
const goodsAttr = {
    init() {
        this.stock = 0;
        this.multiInfoReadyFirstChange = false; // 判断在+按钮设置最大值时是否可以调用弹窗提示

        // 规格属性
        if ($panelIntroAttr.length) {
            this.insGoodsAttr = this.attr();
            this.insGoodsAttr.init();
        }

        // 运输（运费）方式
        this.insShipping = new Shipping({
            goodsImage
        });

        const self = this;
        stateStore.init({
            pool: ['goodsMulti', 'userInstalmentInfo'],
            callback({ goodsMulti, userInstalmentInfo }) {
                self.installmentPay(goodsMulti, userInstalmentInfo);
            }
        });

        let depData = ''; // 保存price数据
        let depStock = 0; // 保存库存
        // 分期数据就绪
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            const { price = {}, stock } = resData;
            depData = price;
            depStock = self.setStock(stock);
            (async () => {
                const loginStatus = await isLogin();
                if (loginStatus) {
                    stateStore.set('goodsMulti', resData);
                    // 临时放在这里，后续要划归到商详底部处理
                    $('.js-goodsViewed_sign').hide();
                } else {
                    this.installmentPay(resData);
                }
            })();
        });
        // 数量控件
        if ($panelGoodsQTY.length) {
            self.insGoodsNumber = new InputNumber('js-goodsIntroQTY', {
                // input值有变化时
                onChange(val) {
                    window.SELECTEDGOODS.qty = val;
                    PubSub.publish('goods.numberChange', val);
                },
                onMax(val) {
                    if (+depData.labelId === 28 && +depData.isCanShowDep && !self.multiInfoReadyFirstChange) {
                        let depLessCount = depData.saleQty - depData.count;
                        depLessCount = depLessCount > 0 ? depLessCount : 0;
                        const arr = [depLessCount, depData.userBuyLimit, depStock];
                        const lessCanBuy = Math.min.apply(null, arr);
                        layer.msg(trans('goods.deposit_detail_canbuytip', [lessCanBuy]));
                    }
                }
            });
            this.insGoodsNumber.setVal(1);
            window.SELECTEDGOODS.qty = 1;
        }

        this.bindEvent();
    },

    bindEvent() {
        const self = this;

        // 仓库切换
        $panelWarehouse.on('click', '.js-btnWarehouseCheck', (e) => {
            self.switchWarehouse($(e.currentTarget).attr('data-code'));
        });

        // 异步价格获取成功后
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            const { price = {}, stock } = resData;
            let canStock = self.setStock(stock);
            // 设置数量控件
            if (self.insGoodsNumber) {
                if (+price.labelId === 28 && +price.isCanShowDep) {
                    // 活动剩余可订货量
                    const lessCount = price.saleQty - price.count;
                    const arr = [lessCount, price.userBuyLimit, canStock];
                    canStock = Math.min.apply(null, arr);
                }
                const stockOut = canStock < 1;
                self.multiInfoReadyFirstChange = true;
                self.insGoodsNumber.setMax(stockOut ? 1 : canStock); // 初始化时会默认调用弹窗提醒，设置multiInfoReadyFirstChange不给调用
                self.insGoodsNumber.setDisable(stockOut);
                self.multiInfoReadyFirstChange = false;
            }

            // 购买上限显示
            self.maxPerOrder(price.userBuyLimit || '');

            // 设置库存状态标识
            self.stockStatusTag(canStock);

        });
        // 弹框显示size guide
        const $sizeGuide = $('.js-goodsSizeGuide_wrap');
        if ($sizeGuide.length) {
            this.sizeGuildLayerBox($sizeGuide);
        }
    },

    sizeGuildLayerBox($sizeGuide) {
        const sizeGuildHTML = $sizeGuide[0].outerHTML;
        $('.js-goodsIntro_sizeGuide').click(() => {
            layer.open({
                content: sizeGuildHTML,
                area: '750px',
                closeBtn: 1,
                btn: false,
                success() {
                    $('body').css('overflow', 'hidden');
                },
                end() {
                    $('body').css('overflow', 'initial');
                }
            });
        });
        // 鼠标经过动效
        function getRowCol(str) {
            const gridMap = str.split('-');
            return { row: gridMap[0], col: gridMap[1] };
        }

        $('body').on('mouseenter', '.js-sizeGuild_td', (e) => {
            let { row: currentRow, col: currentCol } = getRowCol(e.currentTarget.dataset.grid);
            currentRow = Number(currentRow);
            currentCol = Number(currentCol);
            const $currentSizeGuide = $(e.currentTarget).closest('.goodsSizeGuide_tableItem');
            $currentSizeGuide.find('[data-grid]').each((index, ele) => {
                let { row: unitRow, col: unitCol } = getRowCol(ele.dataset.grid);
                unitRow = Number(unitRow);
                unitCol = Number(unitCol);
                const eleClass = ele.classList;
                eleClass.remove('hover', 'hover-line');
                if (unitRow === currentRow && unitCol <= currentCol) {
                    if (unitCol === currentCol || unitCol === '0') {
                        eleClass.add('hover');
                    } else {
                        eleClass.add('hover-line');
                    }
                } else if (unitCol === currentCol && unitRow <= currentRow) {
                    if (unitRow === '0') {
                        eleClass.add('hover');
                    } else {
                        eleClass.add('hover-line');
                    }
                }
            });
        });
        $('body').on('mouseleave', '.goodsSizeGuide_tableItem', (e) => {
            $('[data-grid]').removeClass('hover hover-line');
        });
    },

    // 显示分期信息
    async installmentPay(goodsMulti, userInstalmentInfo) {
        const { price = {} } = goodsMulti;
        let instalmentInfo = goodsMulti.instalmentInfo;
        if (userInstalmentInfo) instalmentInfo = userInstalmentInfo;
        if (instalmentInfo.length) {
            // 分期付款 异步载入
            (async function asyncInstallment() {
                const { Installment } = await import('../component/installment/installment.js');
                const insInstallment = new Installment();
                insInstallment.price = price.price;
                insInstallment.installmentData = instalmentInfo;
                insInstallment.filterData();
                insInstallment.renderSel();

                // 商品数量变更
                PubSub.subscribe('goods.numberChange', (msg2, num) => {
                    insInstallment.filterData(num);
                    insInstallment.renderSel();
                    // 显示选中的分期信息
                    insInstallment.showSelected();
                });
            }());
        }
    },

    // 仓库切换（跳转页面式）
    switchWarehouse(code) {
        window.location.href = replaceUrlVal('wid', code);
    },

    // 设置商品库存
    setStock(stockData) {
        let stock = 0;
        const num = [];

        Object.entries(stockData).forEach((item) => {
            num.push(item[1]);
        });
        stock = Math.min.apply(null, num);
        // 暂存stock供其他调用
        this.stock = stock;
        return stock;
    },

    // 库存状态标识
    stockStatusTag(stock) {
        if (!+GOODSINFO.isVirtual) {
            let stockStr = '';
            if (stock === 1) {
                stockStr = trans('goods.one__pc_left');
            } else if (stock < 1) {
                stockStr = '';
            } else if (stock < 10) {
                stockStr = trans('goods.number_of_pcs_left', [stock]);
            } else if (stock >= 10) {
                stockStr = trans('goods.in_stock');
            }
            $panelIntroStockTag.html(stockStr).fadeIn();
        } else {
            $panelIntroStockTag.hide();
        }
    },

    // 购买上限显示
    maxPerOrder(userBuyLimit) {
        try {
            if (userBuyLimit > 0) {
                $panelIntroMaxPerOrder.text(`${trans('goods.max_per_order')} : ${userBuyLimit}`).show();
            }
        } catch (error) {
            throw new Error(error);
        }
    },

    // 多规格属性操作
    attr() {
        return new GoodsAttr({
            goodsList: window.goodsLink, // 商品sku匹配质数 数据列表
            jqWrap: $panelIntroAttr, // 商品属性区父面板
            rowCls: 'js-goodsIntroAttr', // 每项属性所在行的className
            activeCls: 'line1', // 选中规格项的className
            multiplyAttrName: 'prime', // 数据列表中匹配乘积的key
            success(product) { // 所选的规格有匹配数据时
                if (product.url === window.location.href.split('#')[0] && !$('.no-shipping-country').length) {
                    PubSub.publish('goods.enableShopBtn');
                } else {
                    // 商详来源记录
                    RecordToGoods.set('isChangeAttr', true);

                    const resultHref = document.createElement('a');
                    resultHref.href = product.url;
                    resultHref.hash = '#goodsDetail';
                    window.location.href = resultHref.href;
                }
            },
            fail() {
                // 匹配不上时禁用购买按钮
                PubSub.publish('goods.disableShopBtn');
            }
        });
    },
};
goodsAttr.init();


// ********************* 商品-购买操作区（加入购物车(add to cart)|立即买(buy now)|收藏） *********************
const $btnsCollect = $('.js-btnGoodsCollect');
const goodsBuy = {
    init() {
        // 绑定事件
        this.bindEvent();
    },

    // 绑定事件
    bindEvent() {
        const self = this;

        // 收藏操作
        $(document).on('click', '.js-btnGoodsCollect', (e) => {
            const $this = $(e.currentTarget);
            self.collect($this);
        });

        // 异步商品信息获取成功后
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            // const { price = {}, stock, goodsStatus } = resData;
            const { price = {} } = resData;
            const { labelId } = price;
            // const canStock = getObjectMin(stock);

            // 邮件加密价
            if (+labelId === 1) {
                let locEo = '';
                if (window.localStorage.getItem('gb_saveEo')) {
                    locEo = window.localStorage.getItem('gb_saveEo');
                }
                window.SELECTEDGOODS.ciphertext = locEo;
            }

            // 加车时要新增实时价
            window.SELECTEDGOODS.addPrice = price.price;

            // // 购买按钮初始化
            // shopBtnOperate.init({
            //     status: goodsStatus,
            //     stock: canStock,
            //     labelId
            // });
        });

        // 获取商品收藏状态后更新收藏状态
        PubSub.subscribe('goods.goodsCollectStatusReady', (msg, favList) => {
            self.setCollectList(favList);
        });
    },

    // 获取收藏请求数据序列
    getCollectList() {
        const data = [];

        $btnsCollect.each((index, ele) => {
            const $this = $(ele);
            const sku = $this.attr('data-sku');
            const warehouse = $this.attr('data-warehouse');
            data.push([sku, warehouse].join('_'));
        });

        return data;
    },

    // 设置所有收藏按钮的收藏状态
    setCollectList(favList) {
        if (favList && favList.length) {
            const goodsCollectData = favList;
            // 验证是否一一对上
            if ($btnsCollect.length === goodsCollectData.length) {
                const resultData = goodsCollectData;
                $btnsCollect.each((index, ele) => {
                    const $this = $(ele);
                    const $count = $this.find('.js-favCount');

                    if (resultData[index].fav) {
                        $this.addClass('collected').attr('data-id', resultData[index].id);
                    } else {
                        $this.removeClass('collected');
                    }

                    let num = resultData[index].skuNum;
                    if (num < 1) {
                        num = 0;
                    } else if (num > 1000) {
                        num = '999+';
                    }

                    $count.text(num);
                });
            }
        }
    },

    // 分发收藏=> 添加|取消
    collect($btnCollect) {
        if ($btnCollect.hasClass('collected')) {
            this.collectRemove($btnCollect);
        } else {
            this.collectAdd($btnCollect);
        }
    },

    // 加入收藏
    async collectAdd($btnCollect) {
        const res = await serviceCollectAdd.http({
            loading: true,
            errorPop: false,
            data: {
                goods: [[GOODSINFO.goodsSn, GOODSINFO.warehouseCode].join('_')],
            },
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
            },
        });
        if (+res.status === 0) {
            goodsGlobalAfter.getCollectStatus({
                goodsSnlist: goodsBuy.getCollectList().join(',')
            }, ['goods']);
            PubSub.publish('sysUpdateUserInfo');
        } else if (res.data && res.data.redirectUrl) {
            window.location.href = res.data.redirectUrl;
        } else {
            layer.msg(res.msg);
        }
    },

    // 取消收藏
    async collectRemove($btnCollect) {
        const collectId = $btnCollect.attr('data-id');
        const res = await serviceCollectRemove.http({
            loading: true,
            errorPop: false,
            method: 'POST',
            data: {
                favId: [collectId],
            },
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
            },
        });
        if (+res.status === 0) {
            goodsGlobalAfter.getCollectStatus({
                goodsSnlist: goodsBuy.getCollectList().join(',')
            }, ['goods']);
            PubSub.publish('sysUpdateUserInfo');
        } else if (res.data && res.data.redirectUrl) {
            window.location.href = res.data.redirectUrl;
        } else {
            layer.msg(res.msg);
        }
    },
};
goodsBuy.init();


// ********************* 商品-服务标 *********************
const goodsServerTag = {
    init() {
        const self = this;
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            const { price = {} } = resData;
            let clearanceFlag = +GOODSINFO.saleMark;
            // 营销价类型为10 或 '6396395377285853184' saleMark标识为清仓
            if (+price.labelId === 10 || String(price.labelId) === '6396395377285853184') {
                clearanceFlag = 3;
            }
            // 营销价类型不为127且 saleMark=3时
            if (!/^[127]$/.test(price.labelId) && clearanceFlag === 3) {
                self.clearanceShow();
            }

        });
    },

    // 显示清仓标
    clearanceShow() {
        $('#js-tagClearance').addClass('show');
    }
};
goodsServerTag.init();


// ******************************** 店铺相关 ********************************
const $btnFavStore = $('.js-btnFavStore');
const txtStoreFav = $btnFavStore.attr('data-trans-favorites');
const txtStoreCollected = $btnFavStore.attr('data-trans-collected');
const goodsStore = {
    init() {
        // if ($('#js-panelStoreWrap').length) {
        this.bindEvent();
        // }
    },

    bindEvent() {
        const self = this;
        let favStoreLock = true;
        PubSub.subscribe('goods.storeCollectStatusReady', (msg, storeCollectStatus) => {
            // 设置收藏状态
            const collectStatus = storeCollectStatus;
            favStoreLock = false;
            self.collectStatusSet({
                collectFlag: collectStatus,
                collectTxt: +collectStatus === 0 ? txtStoreFav : txtStoreCollected,
            });
        });

        // 触发收藏(Favorites)店铺
        (async () => {
            const loginStatus = await isLogin();
            $btnFavStore.on('click', (e) => {
                if (loginStatus && favStoreLock) return;
                const $this = $(e.currentTarget);
                const shopId = $this.attr('data-code');
                const isCollect = $this.hasClass('collected');

                if (+isCollect === 0) {
                    self.collectAdd(shopId);
                } else {
                    self.collectRemove(shopId);
                }
            });
        })();
    },

    // 店铺-加入收藏
    collectAdd(shopId) {
        this.collectHandle(shopId, {
            flag: 1, // 加入收藏
            collectFlag: 1, // 收藏成功后标识
            collectTxt: txtStoreCollected, // 收藏成功后文案
        });
    },

    // 店铺-取消收藏
    collectRemove(shopId) {
        this.collectHandle(shopId, {
            flag: 2, // 取消收藏
            collectFlag: 0, // 取消收藏后标识
            collectTxt: txtStoreFav, // 取消收藏后文案
        });
    },

    // 加入(取消)收藏店铺
    async collectHandle(shopId, config) {
        try {
            const res = await serviceStoreCollect.http({
                loading: true,
                errorPop: false,
                method: 'POST',
                data: {
                    shopCodeList: shopId,
                    flag: config.flag,
                },
            });
            if (+res.status === 0) {
                layer.msg(res.msg);
                // 变更收藏状态
                this.collectStatusSet(config);
            } else if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        } catch (error) {
            throw new Error(error);
        }
    },

    // 收藏状态变更
    collectStatusSet(config) {
        $btnFavStore[config.collectFlag ? 'addClass' : 'removeClass']('collected')
            .find('span').text(config.collectTxt);
    },
};
goodsStore.init();


// ******************************** 搭配购 ********************************
const goodsBindBuy = {
    bindEvent() {
        const self = this;

        // 因涉及到前端计算，获取汇率及实时价后进行配件购
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            const { price = {} } = resData;

            panelBindBuy(GOODSINFO, () => {
                self.$panelBindBuy = $('#js-panelBindBuy');
                self.$tabBindBuy = self.$panelBindBuy.find('.js-tabBindBuy');
                self.$itemSwitchBindBuy = $('.js-panelSwitchBindBuy');
                self.$panelMainDisplayPriceBindBuy = $('#js-bindBuyMainPrice');
                self.$panelMainMktPriceBindBuy = $('#js-bindBuyMainMktPrice');
                self.$panelTotalPriceBindBuy = $('#js-bindBuyTotalPrice');
                self.$panelTotalSavePriceBindBuy = $('#js-bindBuyTotalSavePrice');
                self.$panelTotalFinalPriceBindBuy = $('#js-bindBuyTotalFinalPrice');
                self.$panelTotalCountBindBuy = $('#js-bindBuyTotalCount');
                self.$btnBindBuy = $('#js-btnBindBuy');
                self.$itemGoodsFitting = self.$panelBindBuy.find('.js-itemBoxBindbuy');

                self.switchPanel(0);

                // 更新主件价格及
                self.updateMainPrice(price.price);

                // 生成数据模型
                self.generateDataModel(price.price);

                // 初始要进行计算
                self.fillFinal();

                // 默认勾选的配件数据（供外部调用，例如埋点）
                window.GOODS_TOGETHERDATA = self.getSeletedData(true);

                // tab切换
                self.$tabBindBuy.on('click', (e) => {
                    const index = $(e.currentTarget).index();
                    self.switchPanel(index);
                });

                // 勾选某个配件时触发
                self.$panelBindBuy.on('change', '.js-bindBuyItemCheck', (e) => {
                    const $this = $(e.currentTarget);
                    self.updateSelectedData($this.val(), 'checked', $this[0].checked);
                    window.GOODS_TOGETHERDATA = self.getSeletedData(true);
                });

                // 将选好的配件加入购物车
                self.$btnBindBuy.on('click', (e) => {
                    const $this = $(e.currentTarget);
                    const cartData = self.getSeletedData();

                    PubSub.publish('sysAddToCart', {
                        goods: cartData,
                        cartAni: {
                            imgSrc: GOODSINFO.thumb,
                            origin: $this,
                        },
                    });
                });
            });
        });

    },

    // 因要保持和商品信息区价格一致，此处更新主件的价格为实时价，并决定是否显示划线价
    updateMainPrice(price) {
        const self = this;
        const mktPrice = self.$panelMainMktPriceBindBuy.attr('data-currency');
        self.$panelMainDisplayPriceBindBuy.attr('data-currency', price);
        try {
            if (Number(mktPrice) > Number(price)) {
                self.$panelMainMktPriceBindBuy.show();
            }
        } catch (error) {
            // error
        }
    },

    // 生成数据模型
    generateDataModel(price) {
        const self = this;
        const model = {};

        // 主商品
        model.ID_MAIN = Object.assign({
            checked: true,
            displayPrice: transformCy(price),
            marketPrice: +transformCy(self.$panelMainMktPriceBindBuy.attr('data-currency')) || transformCy(price),
        }, window.SELECTEDGOODS);

        // 循环所有配件项
        self.$itemGoodsFitting.each((index, ele) => {
            const $this = $(ele);
            const genId = $this.attr('data-genid');
            const goodsSn = $this.attr('data-sku');
            const warehouseCode = $this.attr('data-warehousecode');
            const categoryId = $this.attr('data-category');
            const { checked } = $this.find('.js-bindBuyItemCheck')[0];
            const displayPrice = transformCy($this.find('.js-bindBuyItemPrice').attr('data-currency'));
            const marketPrice = +transformCy($this.find('.js-bindBuyItemMktPrice').attr('data-currency')) || displayPrice;

            // 单个配件模型数据
            model[genId] = {
                // 基础加购参数
                qty: 1,
                goodsSn,
                warehouseCode,

                // 作为配件所需参数
                goodsType: 1,
                mainGoodsSn: GOODSINFO.goodsSn,

                // 勾选标识
                checked,
                // 销售价
                displayPrice,
                // 市场价
                marketPrice,
                // 分类ID
                categoryId,
            };
        });
        this.dataModel = model;
        return model;
    },

    // 配件slick自适应配置
    slickResp() {
        /**
         * 页面适配了三个宽度 1000 1200 1488，slider区域对应以下宽度
         * 460px以下 显示2个
         * 660px以下 显示3个
         * 948px以下 显示5个
         */
        const respCfg = {
            461: 2,
            661: 3,
        };
        return respCfg;
    },

    // 多配件滚动特效
    panelSlick($panel) {
        try { // 已绑定slick特效
            $panel.slick('getSlick');
        } catch (e) {
            RecomList.slick($panel, {
                variableWidth: false,
                slidesToShow: 5,
                slidesToScroll: 5,
                respondTo: 'slider'
            }, this.slickResp());
        }
    },

    // 切换面板
    switchPanel(index) {
        const self = this;
        const $currentSwitch = self.$itemSwitchBindBuy.eq(index);
        const $panelSlick = $currentSwitch.find('.js-goodsBindList').eq(0);

        // 高亮切换
        self.$tabBindBuy.eq(index).addClass('active').siblings().removeClass('active');
        self.$itemSwitchBindBuy.hide();
        $currentSwitch.show();

        // 当前面板加滑动特效
        this.panelSlick($panelSlick);
    },

    // 更新勾选数据
    updateSelectedData(genId, key, val) {
        this.dataModel[genId][key] = val;
        this.fillFinal();
    },

    // 合计
    calc() {
        const list = Object.entries(this.dataModel);
        const mainMarketPrice = +list[0][1].marketPrice;
        const mainDisplayPrice = +list[0][1].displayPrice;
        let displayPrice = [];
        let marketPrice = [];
        let savePrice = 0;
        let selectCount = 0;

        list.forEach((item) => {
            if (+item[1].checked === 1) {
                displayPrice.push(item[1].displayPrice);
                marketPrice.push(item[1].marketPrice);
                selectCount += 1;
            }
        });

        displayPrice = add(displayPrice);
        marketPrice = add(marketPrice);

        // 节省价无需包含主件
        const mainMarketPriceForSave = add(marketPrice, -mainMarketPrice);
        const displayPriceForSave = add(displayPrice, -mainDisplayPrice);
        savePrice = add(mainMarketPriceForSave, -displayPriceForSave);

        this.calcResult = {
            totalPrice: marketPrice,
            finalPrice: displayPrice,
            savePrice,
            selectCount,
        };
    },

    // 填充计算结果
    fillFinal() {
        const self = this;
        self.calc();
        const result = self.calcResult;

        self.$panelTotalPriceBindBuy.text(addSymbol(result.totalPrice));
        self.$panelTotalSavePriceBindBuy.text(addSymbol(result.savePrice));
        self.$panelTotalFinalPriceBindBuy.text(addSymbol(result.finalPrice));
        self.$panelTotalCountBindBuy.text(result.selectCount - 1); // 只计算配件数量

        PubSub.publish('sysUpdateCurrency', {
            context: self.$panelBindBuy[0],
        });
    },

    // 获取所有勾选数据
    getSeletedData(getAll) {
        const list = Object.entries(this.dataModel);
        const goods = [];

        list.forEach((item) => {
            const tempItem = JSON.parse(JSON.stringify(item[1]));
            if (+tempItem.checked === 1) {
                tempItem.addPrice = tempItem.displayPrice;
                if (!getAll) {
                    delete tempItem.checked;
                    delete tempItem.displayPrice;
                    delete tempItem.marketPrice;
                    delete tempItem.categoryId;
                }
                goods.push(tempItem);
            }
        });
        return goods;
    },
};

goodsBindBuy.bindEvent();


// ******************************** 商详导航 ********************************
const $panelNav = $('#js-navGoods');
const $itemNavScroll = $panelNav.find('.js-navTabItem a'); // 需要滚动对应高亮的导航项
const $itemNavAll = $panelNav.find('.compTab_item'); // 所有大导航项
const $itemPanelNavCont = $('.js-goodsNavPanel'); // 导航对应大板块(1.商详大区 2.配送及支付 3.批发询价)
const navHeight = $panelNav.outerHeight();
const goodsNav = {
    init() {
        this.$doc = $(document);
        this.$win = $(window);
        this.docHeight = this.$doc.height();

        // 要滚动对应版块的Y轴位置集合 例： {'goodsDesc': 2590}
        this.posConfig = {};
        // 导航外容器Y轴位置
        this.navWrapTop = $panelNav.parent().offset().top;
        // 不间断更新版块位置信息
        this.intervalScroll();

        // 导航是否开启高亮对应显示(商详描述|FAQ|评论 默认开启)
        this.navActiveShow = 1;

        this.bindEvent();
    },
    bindEvent() {
        const self = this;

        // 点击导航项滚动到对应位置
        $panelNav.on('click', '.js-navItem', (e) => {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const href = $this.attr('href');
            const panel = $this.attr('data-panel');

            self.togglePanel(panel); // 切换大面板
            self.goToPanel(href); // 到达指定面板
        });
    },

    // 循环滚动
    intervalScroll() {
        const self = this;
        let docHeight;

        // 页面滚动事件
        PubSub.subscribe('nativeScroll', () => {
            self.scrolling = true;
        });

        // 持续检查滚动状态及页面高度
        self.timer = setInterval(() => {
            docHeight = self.$doc.height();

            // 正在滚动
            if (self.scrolling) {
                self.scrolling = false;
                self.navFixed();
                // 仅基础版块(商详描述|FAQ|评论)需要滚动对应高亮
                if (this.navActiveShow) {
                    self.scrollChange();
                }
            }

            // 页面高度变化
            if (docHeight !== self.docHeight) {
                self.docHeight = docHeight;
                self.setPanelPos();
                self.setNavWrapTop();
            }
        }, 250);
    },

    // 通过滚动条位置确定对应版块
    getSection(scrollTop) {
        let returnValue = null;
        // const winHeight = Math.round(this.$win.height());

        for (const section in this.posConfig) {
            if (this.posConfig[section] < scrollTop) {
                returnValue = section;
            }
        }

        return returnValue;
    },

    // 当前导航项加高亮
    currentNavActive($current) {
        $panelNav.find('.active').removeClass('active');
        $current.addClass('active');
    },

    // 页面滚动变更导航高亮项
    scrollChange() {
        const scrollTop = this.$win.scrollTop();
        const section = this.getSection(scrollTop);
        let $parent;

        // 未匹配到版块
        if (section !== null) {
            $parent = $panelNav.find(`a[href="#${section}"]`).parent();

            // 如果当前匹配到的panel未高亮
            if (!$parent.hasClass('active')) {
                // 当前导航项加高亮
                this.currentNavActive($parent);
            }
        }
    },

    // 获取href的hash
    getHash($link) {
        return $link.attr('href').split('#')[1];
    },

    // 获取需要滚动对应面板的位置（此处为top）
    setPanelPos() {
        const self = this;
        let linkHref;
        let $target;

        $itemNavScroll.each((index, ele) => {
            linkHref = self.getHash($(ele));
            $target = $(`#${linkHref}`);

            if ($target.length) {
                const topPos = $target.offset().top;
                self.posConfig[linkHref] = Math.round(topPos) - navHeight;
            }
        });
    },

    // 更新导航外容器的Y轴位置
    setNavWrapTop() {
        this.navWrapTop = $panelNav.parent().offset().top;
    },

    // 导航置顶显示
    navFixed() {
        const winScrT = this.$win.scrollTop();

        // 导航固定
        if (winScrT >= this.navWrapTop) {
            $panelNav.addClass('goodsNav-fixed');
        } else {
            $panelNav.removeClass('goodsNav-fixed');
        }
    },

    /**
     * 切换大面板
     *
     * 板块0 =>商详描述|FAQ|评论
     * 板块1 => 支付
     * 板块2 => 运输
     * 板块3 => 批发查询
     */
    togglePanel(panel) {
        // 根据data-panel值决定显示哪个版块
        $itemPanelNavCont.hide().eq(panel).show();

        // 清空导航高亮状态
        $itemNavAll.removeClass('active');

        // 基础版块(商详描述|FAQ|评论)需要滚动对应高亮
        if (+panel === 0) {
            this.navActiveShow = 1;
        } else { // (支付方式|运输|批发查询)单个版块展示,当前高亮即可
            this.navActiveShow = 0;
            $panelNav.find(`[data-panel=${panel}]`).parents('li').addClass('active');
        }
    },

    // 到达指定的面板(id)
    goToPanel(id) {
        if ($(id).length) {
            const targetTop = $(id).offset().top;
            $('body,html').animate({
                scrollTop: targetTop - (navHeight - 2),
            });
        }
    },
};
goodsNav.init();


// ******************************** 商详 ********************************
const goodsDesc = {
    init() {
        this.bindEvent();

        // 初始化加载图像
        initLazyload({
            elements_selector: '#anchorGoodsDesc .js-descLazyload',
            data_src: 'lazy',
            skip_invisible: false,
        });
    },
    bindEvent() {
        // size Guide 切换
        $(document).on('click', '.js-tabSizeGuide li', (e) => {
            const $this = $(e.currentTarget);
            const $panel = $this.parent().next();
            const index = $this.index();
            $this.addClass('active').siblings().removeClass('active');
            $panel.children().eq(index).addClass('show').siblings()
                .removeClass('show');
        });
        // 异步价格获取成功
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            linkRedirect.set({
                resData
            });
        });
        // 切换语言查询多语言信息
        switchInfo.init(GOODSINFO.goodsSn);

        // 开平商城端商详描述Specification添加view more限高点击加载
        if (GOODSINFO.isPlatform) {
            const $sizeDescription = $('.js-sizeDescription');
            const $descViewMore = $('.js-descViewMore');
            const sizeDescriptionH = $sizeDescription.height();
            const maxHeight = 600;
            if (sizeDescriptionH > maxHeight) {
                $sizeDescription.addClass('hidePart');
                $descViewMore.show();
            }

            $descViewMore.on('click', () => {
                $sizeDescription.removeClass('hidePart');
                $descViewMore.hide();
            });
        }
    },

    // 描述图片处理（屏蔽网采商品处理）
    descImgHandle(flag) {
        const $goodsDesc = $('#anchorGoodsDesc');
        const $goodsThumbNail = $('#js-goodsIntroThumbNail');

        if (flag === 'origin') {
            $goodsDesc.find('.js-descLazyload').show(); // 描述区图片
            $goodsDesc.find('.goodsDesc_videoItem').show(); // 描述区视频
            $goodsThumbNail.addClass('show'); // 缩略图区
        } else {
            $goodsDesc.find('.js-descLazyload').hide();
            $goodsDesc.find('.goodsDesc_videoItem').hide();

            $goodsThumbNail.removeClass('show');
        }
    }
};
goodsDesc.init();


// ******************************** FAQ ********************************
const $panelGoodsFaqList = $('#js-goodsFAQList');
const queryFaqItem = '.js-faqItem';
const $btnToggleFaq = $('#js-btnToggleOFaq');
const goodsFAQ = {
    init() {
        this.bindEvent();
    },
    bindEvent() {
        // FAQ条目显隐
        $panelGoodsFaqList.on('click', queryFaqItem, (e) => {
            const $this = $(e.currentTarget);
            $this.toggleClass('show');
            $this.next().stop().slideToggle(300);
        });

        // 切换显示5条之后的faq
        $btnToggleFaq.on('click', (e) => {
            $(e.currentTarget).parent().toggleClass('show');
        });
    },
};
goodsFAQ.init();


// ******************************** 评论 ********************************
const $panelReview = $('#js-reviewWrap');
const queryItemReviewImg = '.js-imgItemReviews';
const queryUlReviewImg = '.goodsReviews_itemImgs';
const queryLiReviewImg = '.goodsReviews_itemImgLi';
const goodsReview = {
    init() {
        this.bindEvent();
    },

    // 绑定事件
    bindEvent() {
        const self = this;
        $panelReview.on('click', queryItemReviewImg, (e) => {
            const $this = $(e.currentTarget);
            const $currentPar = $this.parents(queryUlReviewImg);
            const clickIndex = $this.parents(queryLiReviewImg).data('num');
            const imgData = self.packageImgData($currentPar) || [];

            imgView(imgData, clickIndex);
        });

        // 禁止评论区复制
        $panelReview.on('copy', (e) => {
            e.preventDefault();
        });
    },

    // 组装预览图集数据
    packageImgData($parent) {
        const $imgItems = $parent.find(queryItemReviewImg);
        const imgData = [];
        $imgItems.each((index, item) => {
            imgData.push({
                thumb: $(item).attr('src'),
                origin: $(item).data('big'),
            });
        });
        return imgData;
    },
};
setTimeout(() => {
    goodsReview.init();
}, 1500);


// ******************************** 批发询价 ********************************
const $formWholesale = $('#js-formWholesale');
const goodsWholesaleInquiry = {
    init() {
        // 表单验证
        this.validate();

        this.bindEvent();
    },
    bindEvent() {
        const self = this;

        // 批发询价表单提交
        $formWholesale.on('submit', (e) => {
            e.preventDefault();
            if ($formWholesale.valid()) {
                self.wholesaleInquiry();
            }
        });
    },

    // 批发询价处理
    async wholesaleInquiry() {
        try {
            const sdata = $formWholesale.serialize();
            const res = await serviceWholesaleInquiry.http({
                method: 'POST',
                data: sdata,
            });
            if (+res.status === 0) {
                // 成功后清空表单
                $formWholesale.get(0).reset();
            }
            layer.msg(res.msg);
        } catch (error) {
            throw new Error(error);
        }
    },

    // 验证
    validate() {
        // 批发询价表单验证
        $formWholesale.validate({
            rules: {
                price: {
                    required: true,
                    number: true,
                },
                quantity: {
                    required: true,
                    number: true,
                },
                country: {
                    required: true,
                },
                name: {
                    required: true,
                },
                phone: {
                    required: true,
                },
                email: {
                    required: true,
                    email: true,
                },
                company_name: {
                    required: true,
                },
                message: {
                    required: true,
                },
            },
        });
    },
};
goodsWholesaleInquiry.init();


// ******************************** 商详全局调用 - 后置 ********************************
// const $panelRecomNormal = $('#js-goodsRecommendSlick');
// const $panelRecomAlsoBought = $('#js-goodsAlsoBoughtSlick');
// const $panelRecomGuessLike = $('#js-goodsGuessLikeSlick');
// const $panelRecomSponsored = $('#js-goodsSponsoredSlick');
const $hdClickUrl = $('#js-hdClickUrl');
const goodsGlobalAfter = {
    init() {
        const self = this;

        // 商品点击率统计数据传送(2019-3-13 10:50:00商详取消webclick--获取商品详情的数据统计)
        // setTimeout(() => {
        //     self.getGoodsClickUrl();
        // }, 2000);

        // 设置浏览历史记录
        PubSub.subscribe('goods.multiInfoReady', (msg, resData) => {
            const { price = {} } = resData;
            self.setViewHistory(price.price);
        });

        // 异步获取价格
        this.getGoodsInfo();

        // 获取商品|店铺收藏状态
        (async () => {
            const loginStatus = await isLogin();
            if (loginStatus) {
                this.getCollectStatus({
                    goodsSnlist: goodsBuy.getCollectList().join(','),
                    shopCode: GOODSINFO.shopCode,
                    good_sn: GOODSINFO.goodsSn,
                    categoryId: GOODSINFO.categoryId,
                });
            }
        })();
        PubSub.subscribe('nativeReady', () => {
            generatorCookiePolicy();
        });

        // 绑定事件
        this.bindEvent();

    },
    bindEvent() {
        // 评星初始化
        new Rating();

        // 视频播放功能(普通弹窗)
        $(document).on('click', '[data-video]', (e) => {
            const $this = $(e.currentTarget);
            if ($this.data('video')) {
                const video = $this.data('video');
                videoPlay(video);
            }
        });

        // 行内载入iframe(商详描述里用到)
        $(document).on('click', '[data-video-inline]', (e) => {
            const $this = $(e.currentTarget);
            if ($this.data('video-inline')) {
                const video = $this.data('video-inline');
                videoPlay(video, {
                    inline: true,
                    ele: $this,
                });
            }
        });
    },

    /**
     * 获取商品 营销价格+商品库存+分期信息
     * 入参：good_sn,warehouse_code,shop_code,is_virtual,categoryId
     */
    async getGoodsInfo() {
        try {
            const params = {
                good_sn: GOODSINFO.goodsSn,
                shop_code: GOODSINFO.shopCode,
                warehouse_code: GOODSINFO.warehouseCode,
                is_virtual: GOODSINFO.isVirtual,
                categoryId: GOODSINFO.categoryId,
            };
            let locEo = '';
            if (window.localStorage.getItem('gb_saveEo')) {
                locEo = window.localStorage.getItem('gb_saveEo');
            }
            const GetUrlQuery = getUrlQuery();
            const eo = GetUrlQuery.eo || locEo;
            const linkid = GetUrlQuery.lkid;
            const utmSource = GetUrlQuery.utm_source;
            const urlQuery = window.location.search.substr(1);
            let isSetEo = true;
            if (eo) {
                if (linkid && GetUrlQuery.eo) {
                    isSetEo = false;
                }
                if (utmSource && GetUrlQuery.eo) {
                    if (urlQuery.indexOf('utm_source') === urlQuery.lastIndexOf('utm_source')) {
                        if (!(utmSource === 'mail_api' || utmSource === 'email_sys')) {
                            isSetEo = false;
                        }
                    } else {
                        isSetEo = false;
                    }
                }
                if (isSetEo) {
                    if (GetUrlQuery.eo) {
                        const saveEo = GetUrlQuery.eo;
                        window.localStorage.setItem('gb_saveEo', saveEo);
                    }
                    params.eo = eo;
                }
            }

            const res = await serviceGoodsMultiInfo.http({
                params,
                errorPop: false,
            });
            if (+res.status === 0 && res.data) {
                const resData = res.data;
                const stock = goodsAttr.setStock(resData.stock);
                // resData.price = {
                //     advanceAmount: '1',
                //     advanceEndTime: '1552458105',
                //     advanceStartTime: '1549864286',
                //     count: 0,
                //     currentVirtualOrder: '',
                //     declare: '',
                //     deductionAmount: '',
                //     endTime: 1552458105,
                //     finalAmount: '',
                //     finalEndTime: '',
                //     finalStartTime: '',
                //     flashSalePrice: 8.88,
                //     goodSn: '203896301',
                //     groupId: '6383719613313581056',
                //     isAdvance: '',
                //     labelId: '11',
                //     price: 11.71,
                //     priceFact: '9',
                //     priceId: '6383719613313581056',
                //     priceMd5: '981C8DB3E3E1555DE5BB768482A1F122',
                //     pricePage: '11.71',
                //     saleQty: 1000,
                //     showNextInterval: 1,
                //     siteCode: 'GB',
                //     startTime: Math.round(new Date() / 1000) - 1,
                //     stepPrice: '',
                //     swellDiscontAmount: '9',
                //     userBuyLimit: '',
                //     userCount: 0,
                //     userLabelId: '',
                //     virtualSaleQty: 56,
                //     warehouseCode: '1433363',
                // };

                // console.log('resData.price', resData.price);

                // 无特殊价时，默认为本店正常售价
                if (resData.price && typeof resData.price.labelId === 'undefined') {
                    resData.price.labelId = -1;
                }

                // (为后面比较使用) 当单价格可售数量(saleQty)为空或者无返回字段时，本应为无穷大，现赋值为库存值+1 (为后面比较使用)
                if (+resData.price.labelId === 28 && !resData.price.saleQty) {
                    resData.price.saleQty = +stock + 1;
                }

                // (为后面比较使用) 当单用户可购数量(userBuyLimit)为空或者无返回字段时，本应为无穷大，现赋值为库存值+1
                if (+resData.price.labelId === 28 && !resData.price.userBuyLimit) {
                    resData.price.userBuyLimit = +stock + 1;
                }

                // 如果是膨胀金额，但不在预订时间范围或者预订数量小于0时走普通价格
                if (+resData.price.labelId === 28) {
                    const price = resData.price;
                    const nowTime = (new Date()).getTime() / 1000;
                    const canBuyQty = price.saleQty - price.count;

                    // 标识定金膨胀-可预付款状态
                    // 1.当前已处于定金膨胀时间段期间
                    // 2.预付款时间已开始 且 预付款时间未结束 且 可预付款商品数量大于0
                    const isCanShowDep = nowTime - price.startTime > 0 && price.endTime - nowTime > 0 && nowTime - price.advanceStartTime > 0
                    && price.advanceEndTime - nowTime > 0 && canBuyQty > 0;

                    // 标识定金膨胀-显示普通价状态
                    // 1.当前已处于定金膨胀时间段期间
                    // 2.预付款时间未开始 或 预付款时间已结束 或 可预付款商品数量不足
                    const isShowNorPrice = nowTime - price.startTime > 0 && price.endTime - nowTime > 0 &&
                    (nowTime - price.advanceStartTime < 0 || price.advanceEndTime - nowTime < 0 || canBuyQty <= 0);

                    // 仅显示普通价
                    if (isShowNorPrice) {
                        window.SELECTEDGOODS.advanceLabel = 2; // 定金膨胀加车为页面价
                    }

                    // 显示定金膨胀状态
                    if (isCanShowDep) {
                        window.SELECTEDGOODS.advanceLabel = 1; // 定金膨胀加车为预付价
                        $('#js-panelBindBuy').remove(); // 定金膨胀活动隐藏搭配购
                        $('#js-goodsPromotion').remove(); // 定金膨胀隐藏promotion活动
                        price.isCanShowDep = 1;
                    }
                }
                /**
                 * 商品异步信息发布
                 * goodsStatus      商品状态
                 * instalmentInfo   分期付款
                 * price            营销价格
                 * stock            库存
                 */
                PubSub.publish('goods.multiInfoReady', resData);
            }
        } catch (error) {
            throw new Error(error);
        }
    },

    // 获取商品|店铺收藏状态
    async getCollectStatus(params, updateType = ['store', 'goods']) {
        try {
            const res = await serviceGoodsCollect.http({
                loading: false,
                errorPop: false,
                params,
            });

            if (+res.status === 0 && res.data) {
                const resData = res.data;

                // 店铺收藏数据
                if (typeof resData.shopCollect !== 'undefined' && updateType.includes('store')) {
                    PubSub.publish('goods.storeCollectStatusReady', resData.shopCollect);
                }

                // 商品收藏数据
                if (resData.favList && updateType.includes('goods')) {
                    PubSub.publish('goods.goodsCollectStatusReady', resData.favList);
                }

                stateStore.set('userInstalmentInfo', res.data.instalmentInfo);
            }
        } catch (error) {
            // error
        }
    },

    // 商品点击率统计数据传送
    getGoodsClickUrl() {
        let url = $hdClickUrl.val();
        url = url.replace(/{{goodSn}}/, GOODSINFO.goodsSn);
        $(`<div><img src="${url}"></div>`).css('display', 'none').appendTo('body');
    },

    // 设置历史记录
    setViewHistory(price = '') {
        GoodsViewHistory.set({
            url: window.location.href,
            img: GOODSINFO.thumb,
            title: GOODSINFO.title,
            sku: GOODSINFO.goodsSn,
            wid: GOODSINFO.warehouseCode,
            categoryId: GOODSINFO.categoryId,
            cateLink: $('.cGoodsCrumb_itemLink:last').attr('href'),
            price,
        });

        // 异步载入历史记录
        lazyObserver({
            callBack: () => {
                import('modules/common/view_history/view_history.js');
            },
            observeDom: $('#js-goodsViewHistory')[0],
        });
        PubSub.publish('goods.setViewHistoryReady');
    },
};
goodsGlobalAfter.init();
