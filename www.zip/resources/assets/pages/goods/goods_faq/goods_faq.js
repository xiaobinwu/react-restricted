import 'js/bootstrap';
import './goods_faq.css';

import '../component/faq/faq.js';
import boxSticky from '../assets/js/boxSticky.js';

// 弹窗-提问
import '../component/ask_question/ask_question.js';

boxSticky.init();
