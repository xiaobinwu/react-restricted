import 'js/bootstrap';
import $ from 'jquery';

// 公用评星
import Rating from 'component/rating/rating.js';
import videoPlay from 'js/core/videoPlay.js';
import boxSticky from '../assets/js/boxSticky.js';

import './reviews.css';

// 评论模块
import '../component/review/review.js';
// 评论图片预览
import imgView from '../component/img_view/img_view.js';

// ******************************** 评论 ********************************
const $panelReview = $('#js-reviewWrap');
const queryItemReviewImg = '.js-imgItemReviews';
const queryUlReviewImg = '.goodsReviews_itemImgs';
const queryLiReviewImg = '.goodsReviews_itemImgLi';
const goodsReview = {
    init() {
        // 评星初始化
        new Rating();
        this.bindEvent();
    },

    // 绑定事件
    bindEvent() {
        const self = this;

        // 查看图片功能
        $panelReview.on('click', queryItemReviewImg, (e) => {
            const $this = $(e.currentTarget);
            const $currentPar = $this.parents(queryUlReviewImg);
            const clickIndex = $this.parents(queryLiReviewImg).data('num');
            const imgData = self.packageImgData($currentPar) || [];

            imgView(imgData, clickIndex);
        });

        // 视频播放功能(普通弹窗)
        $(document).on('click', '[data-video]', (e) => {
            const $this = $(e.currentTarget);
            if ($this.data('video')) {
                const video = $this.data('video');
                videoPlay(video);
            }
        });

        // 禁止评论区复制
        $panelReview.on('copy', (e) => {
            e.preventDefault();
        });

        boxSticky.init();
    },

    // 组装预览图集数据
    packageImgData($parent) {
        const $imgItems = $parent.find(queryItemReviewImg);
        const imgData = [];
        $imgItems.each((index, item) => {
            imgData.push({
                thumb: $(item).attr('src'),
                origin: $(item).data('big'),
            });
        });
        return imgData;
    },
};
goodsReview.init();
