/**
 * 商详二级页面：FAQ，评论详情页 部分元素吸顶处理
 * 下方代码较烂，后续需要优化
 * 2018-11-12 11:45:43
 */

const boxSticky = {
    init() {
        this.bindEvent();
    },

    bindEvent() {

        const $wrapBox = $('.js-panelOtherDetailWrap');
        const wrapBoxTop = $wrapBox.offset().top;
        const wrapBoxHeight = $wrapBox.outerHeight();

        // 左侧商品信息框吸顶
        const $infoBox = $('.js-panelGoodsInfo');
        const infoBoxWidth = $infoBox.outerWidth();
        const infoBoxHeight = $infoBox.outerHeight();
        const infoBoxTop = $infoBox.offset().top;
        const infoBoxLeft = $infoBox.offset().left;
        function infoBoxSticky(winScrollTop) {
            if (winScrollTop < infoBoxTop) {
                $infoBox.css({
                    position: 'static',
                });
            } else if (winScrollTop < (wrapBoxTop + wrapBoxHeight) - infoBoxHeight - 30) {
                $infoBox.css({
                    position: 'fixed',
                    top: 30,
                    bottom: 'auto',
                    left: infoBoxLeft,
                    width: infoBoxWidth
                });
            } else {
                $infoBox.css({
                    position: 'absolute',
                    bottom: 0,
                    top: 'auto',
                    left: 0,
                    width: infoBoxWidth,
                });
            }
        }

        // 右侧导航吸顶
        const $goodsfilter = $('.js-panelGoodsFilter');
        const goodsfilterWidth = $goodsfilter.outerWidth();
        const goodsfilterTop = $goodsfilter.offset().top;
        const goodsfilterLeft = $goodsfilter.offset().left;
        function filterNavSticky(winScrollTop) {
            if (winScrollTop < goodsfilterTop) {
                $goodsfilter.css({
                    position: 'static',
                });
            } else {
                $goodsfilter.css({
                    position: 'fixed',
                    top: 0,
                    left: goodsfilterLeft,
                    width: goodsfilterWidth
                });
            }
        }

        $(window).on('scroll', () => {
            const scrollT = $(window).scrollTop();
            if (wrapBoxHeight > infoBoxHeight * 1.5) {
                infoBoxSticky(scrollT);
            }
            filterNavSticky(scrollT);
        });
    }
};

export default boxSticky;
