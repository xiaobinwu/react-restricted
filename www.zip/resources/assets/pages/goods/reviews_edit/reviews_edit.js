import 'js/bootstrap';
import Rating from 'component/rating/rating';
import 'js/utils/validation.config.js';
import layer from 'layer';
import Navigate from 'component/navigate/navigate';
import { serviceReviewCreate } from 'js/service/goods';

import './reviews_edit.css';

let uploader = null;
let loading = null;
const PICS = [];
const $captchaImg = $('#js-captchaImg');
const $captchaIpt = $('#js-captcha');

function run() {
    new Rating();
    initCaptcha();
    initForm();
    initNavigate();
    initUpload();
}

/**
 * 验证码
 */
function initCaptcha() {
    $captchaImg.on('click', () => {
        $captchaIpt.val('').focus();
        refreshCaptcha();
    });
}

/**
 * 刷新验证码
 */
function refreshCaptcha() {
    $captchaImg.attr('src', `${$captchaImg.data('path')}?${Math.random()}`);
}

/**
 * 表单交互
 */
function initForm() {
    const $form = $('#form');

    // 让文本域模拟 placeholder 换行
    $form.find('.form_placeholer').each((index, elem) => {
        const $this = $(elem);
        const $textarea = $this.siblings('textarea');

        $this.on('click', () => {
            $this.hide();
            $textarea.focus();
        });

        $textarea.on('blur', (e) => {
            if ($(e.currentTarget).val() === '') {
                $this.show();
            }
        });
    });

    // 表单校验规则
    $form.validate({
        rules: {
            rate_overall: { required: true },
            nick_name: { required: true },
            subject: { required: true },
            pros: { required: true, minlength: 100 },
            captcha: { required: true },
        }
    });

    // 点击星星的时候触发表单验证
    $form.find('.reviewRating .js-rating').on('change', (e) => {
        const $this = $(e.currentTarget);
        if (!Number($this.val())) $this.val('');
        $this.valid();
    });

    // 表单提交
    $form.on('submit', (e) => {
        e.preventDefault();
        if ($form.valid()) {
            if (uploader.getFiles().length > 0) {
                loading = layer.loading();
                uploader.upload();
            } else {
                formSubmit();
            }
        }
    });
}

/**
 * 初始化图片上传
 */
async function initUpload() {
    const $uploadBtn = $('.js-uploadPic');
    const $uploadPick = $('#uploadPicture');

    const WebUploader = await import('webuploader');

    uploader = new WebUploader.Uploader({
        title: 'Images',
        extensions: 'gif,jpg,jpeg,bmp,png',
        mimeTypes: 'image/*',
        pick: '#uploadPicture',
        fileVal: 'files',
        formData: {
            site: window.GLOBAL.SITE_FLAG,
        },
        server: `${window.GLOBAL.DOMAIN_UPLOAD}/review/upload`,
    });

    uploader.on('fileQueued', (file) => {
        uploader.makeThumb(file, (error, src) => {
            if (error) {
                layer.error('Image preview error!');
            } else {
                $(`<figure class="picture">
                        <img src="${src}">
                        <a href="javascript:;" class="delete js-delete" data-id="${file.id}"><i class="icon-delete"></i></a>
                    </figure>`).insertBefore($uploadBtn);
            }
        }, 100, 100);
    });

    uploader.on('uploadSuccess', (file, res) => {
        PICS.push({
            small_pic: res.thumb,
            big_pic: res.file,
        });

        if (uploader.getStats().progressNum === 0) {
            layer.close(loading);
            formSubmit();
        }
    });

    $uploadBtn.on('click', () => {
        $uploadPick.find('label, object').trigger('click');
    });

    // 删除
    $('.uploadImg').on('click', '.js-delete', (e) => {
        const $this = $(e.currentTarget);
        $this.closest('.picture').remove();
        uploader.removeFile($this.attr('data-id'));
    });
}

/**
 * 初始化导航切换
 */
function initNavigate() {
    const $uploadImg = $('.uploadImg');
    const $uploadVideo = $('.uploadVideo');

    // 初始化导航
    new Navigate('.navigate', {
        default: 0,
        onChange($case) {
            if ($case[0].dataset.type === '0') {
                $uploadImg.show();
                $uploadVideo.hide();
            } else {
                $uploadImg.hide();
                $uploadVideo.show();
            }
        }
    });
}

// 表单提交
async function formSubmit() {
    const formData = new FormData($('#form')[0]);
    formData.append('pics', JSON.stringify(PICS));
    const res = await serviceReviewCreate.http({
        data: formData,
    });

    if (res.status === 0) {
        layer.msg(res.msg);
    } else {
        refreshCaptcha();
    }
}

run();
