import { slickFn } from 'js/core/slickFn.js';
import Timer from 'component/timer/timer';
import './black_friday_preheat_time.css';
import timeShaftArt from './component/time_shaft.art';

const timeShaft = {
    init() {
        this.times = [];
        this.roundIndex = -1; // 用于倒计时开启哪个数组, 0表示第一轮
        this.startRound = false; // 用于这一轮是否开启
        this.timer = new Timer();
        this.appendHtml();
        this.calculateRoundIndex();
        this.scrollSlick();
        if (this.roundIndex < this.times.length) {
            this.openTime();
        }
        this.bindEvent();
    },
    bindEvent() {
    },
    appendHtml() {
        this.times = window.BLACKFRIDAY.timeline;
        const html = timeShaftArt({ times: this.times });
        $('.js-timeShaft').append(html);
        this.slick();
    },
    // 计算值
    calculateRoundIndex() {
        const currentStamp = Math.floor(new Date().getTime() / 1000);
        for (let i = 0; i < this.times.length; i += 1) {
            if (currentStamp <= this.times[i].end) {
                this.roundIndex = i;
                if (currentStamp >= this.times[i].start) {
                    this.startRound = true;
                } else {
                    // nothing
                }
                break;
            } else {
                $('.js-timeSlick .slick-slide').eq(i).find('.timeShaft_slickItem')
                    .removeClass('timeShaft_slickItem-after')
                    .addClass('timeShaft_slickItem-over');
                const $bannerUrl = $('.js-bannerUrl').eq(i);
                const url = $bannerUrl.data('url');
                $bannerUrl.attr('href', url);
            }
        }
        if (this.roundIndex === -1) {
            this.roundIndex = this.times.length;
        }
    },
    scrollSlick() {
        let scrollDistance = this.roundIndex - 2;
        if (scrollDistance >= 1) {
            if (!this.startRound) {
                scrollDistance -= 1;
            }
        }
        const maxDistance = this.times.length - 5;
        if (scrollDistance >= maxDistance) {
            $('.js-timeSlick').slick('slickGoTo', maxDistance);
        } else {
            $('.js-timeSlick').slick('slickGoTo', scrollDistance);
        }
        $('.js-timeSlick').on('afterChange', (event, slick, currentSlide, nextSlide) => {
            this.calculateNavDisable();
        });
    },
    calculateNavDisable() {
        const slickCurrentSlide = $('.js-timeSlick').slick('slickCurrentSlide');
        if (this.times.length > 5) {
            if (slickCurrentSlide === 0) {
                $('.timeShaft_navItem').eq(0).addClass('disable');
            } else if (slickCurrentSlide >= this.times.length - 5) {
                $('.timeShaft_navItem').eq(1).addClass('disable');
            } else {
                $('.timeShaft_navItem').removeClass('disable');
            }
        }
    },
    openTime() {
        const self = this;
        function gapTime(timestamp) {
            const now = Math.floor((new Date()) / 1000);
            const interval = timestamp && timestamp - now > 0 ? timestamp - now : 0;
            return interval;
        }
        self.timer.add('.js-timeSlick', {
            interval: gapTime(self.times[self.roundIndex].start),
            onChange() {
            },
            onStart(targetOne) {
            },
            onEnd(targetOne) {
                const $slide = $(targetOne).find('.slick-slide').eq(self.roundIndex);
                $slide.find('.timeShaft_slickItem ')
                    .removeClass('timeShaft_slickItem-after')
                    .addClass('timeShaft_slickItem-now');
                const $bannerUrl = $slide.find('.js-bannerUrl');
                const url = $bannerUrl.data('url');
                $bannerUrl.attr('href', url);
                self.timer.add(targetOne, {
                    interval: gapTime(self.times[self.roundIndex].end),
                    onChange() {
                    },
                    onStart(targetTwo) {
                    },
                    onEnd(targetTwo) {
                        $('.js-timeSlick').slick('slickNext');
                        $(targetTwo).find('.slick-slide').eq(self.roundIndex).find('.timeShaft_slickItem')
                            .removeClass('timeShaft_slickItem-now')
                            .addClass('timeShaft_slickItem-over');
                        self.roundIndex += 1;
                        if (self.roundIndex < self.times.length) {
                            self.openTime();
                        }
                    },
                });
            },
        });
    },
    slick() {
        const $timeNavItem = $('.timeShaft_navItem');
        // 跑马灯调用
        slickFn({
            container: $('.js-timeSlick'),
            dots: false,
            autoplay: false,
            slidesToShow: 5,
            infinite: false,
            prevArrow: $timeNavItem.eq(0),
            nextArrow: $timeNavItem.eq(1)
        });
    }
};
if (window.BLACKFRIDAY && window.BLACKFRIDAY.timeline && window.BLACKFRIDAY.timeline.length) {
    timeShaft.init();
}
