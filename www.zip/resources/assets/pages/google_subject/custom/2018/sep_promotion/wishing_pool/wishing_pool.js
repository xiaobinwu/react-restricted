import Marquee from 'component/marquee';
import { serviceOrderLottery, serviceGetPrizeList } from 'js/service/promotion.js';
import layer from 'layer';
import { isLogin } from 'js/core/user.js';
import { trans } from 'js/core/translate.js';
import './wishing_pool.css';
import './customStyle.css';

const singleCase = {
    marqueeMap: [],
    isLoginStatus: false,
    runPoolAni() {
        const $poolAni = $('.js-poolAni');
        let idNum = 0;
        function timeChange(id) {
            $poolAni.attr('class', `js-poolAni wishingPool_water poolAni-${id}`);
            setTimeout(() => {
                idNum += 1;
                timeChange(idNum % 5);
            }, 400);
        }
        timeChange(idNum);
    },
    async lotteryResult(goodsSn) {
        const { status, msg, data } = await serviceOrderLottery.http({
            loading: false,
            errorPop: false,
            data: {
                activityId: $('.js-wishingPool').data('id'),
                sn: goodsSn
            }
        });
        return {
            fun: () => {
                const $poolMsgBox = $('.js-poolMsgBox');
                const $tips = $poolMsgBox.find('.msgBox_content');
                if (status === 0) {
                    if (data.code === 10054001) { // 中奖
                        $tips.html(`
                    <span class="tipsIcon_head"></span>
                    <span class="wishingPrize_img"></span>
                    <span class="tipsContent">${msg}</span>
                `);
                    } else if (data.code === 10054002) { // 未中奖
                        $tips.html(`
                    <span class="tipsIcon"></span>
                    <span class="tipsContent">${msg}</span>
                `);
                    }
                } else {
                    if (data.redirectUrl) {
                        window.location.href = data.redirectUrl;
                    }
                    $tips.html(`<span class="tipsContent">${msg}</span>`);
                }
                $poolMsgBox.show();
            },
            status
        };
    },
    async getSortData() { // 获取榜单数据
        const { status, msg, data } = await serviceGetPrizeList.http({
            loading: false,
            errorPop: false,
            params: {
                activityId: $('.js-wishingPool').data('id'),
            }
        });
        if (status === 0) {
            console.log(data);
            const { commonList, prizeList } = data;
            let prizeStr = '';
            prizeList.forEach((value) => {
                prizeStr += `<li class="prizeWinner_item">${value}</li>`;
            });
            $('.js-prizeWinner').html(prizeStr);

            let commonStr = '';
            commonList.forEach((value) => {
                commonStr += `<li class="prizeWinner_item">${value}</li>`;
            });
            $('.js-couponWinner').html(commonStr);

            this.marqueeMap = new Marquee({
                selector: '.js-prizeSort',
            }).list;
        } else {
            layer.msg(msg);
        }
    },
    scaleShowBox($frame) {
        $frame.show().addClass('scaleShow');
    },
    hideShowBox($frame) {
        $frame.hide().removeClass('scaleShow');
    },
    init() {
        const self = this;
        isLogin().then((res) => {
            self.isLoginStatus = res;
        });
        this.runPoolAni();
        this.bindEvent();
        this.getSortData();
    },
    bindEvent() {
        const self = this;
        // 规则弹框
        const $ruleBox = $('.js-poolRuleBox');
        const $poolMsgBox = $('.js-poolMsgBox');
        const $tips = $poolMsgBox.find('.msgBox_content');
        $('.js-showRule').mouseenter(() => {
            self.scaleShowBox($ruleBox);
        }).mouseleave(() => {
            self.hideShowBox($ruleBox);
        });
        // 抽奖
        const $goldBlock = $('.js-goldBlock');
        let showLottery;
        let lotteryLock = false;
        function showLotteryBack() {
            showLottery();
            showLottery = null;
            lotteryLock = false;
            return undefined;
        }
        function sleep(time) {
            return new Promise((resolve) => {
                setTimeout(() => {
                    resolve();
                }, time);
            });
        }
        function animationendHandle() {
            $goldBlock.addClass('goldEnd');
            $goldBlock.hide().removeClass('goldEnd goldBlock_translate');
            showLotteryBack();
        }
        async function awaitAnimationend() {
            if (typeof document.body.style.animation !== 'string') await sleep(2000);
            animationendHandle();
        }
        $('.js-wishBtn').click(() => {
            if (!self.isLoginStatus) { // 判断是否登陆
                const { DOMAIN_LOGIN } = GLOBAL;
                $tips.html(`
                    <span class="tipsContent">
                        ${trans('promotion.order_prize_login_tip', [`${DOMAIN_LOGIN}/m-users-a-sign.htm?type=1&ref=${window.location.href}`])}
                    </span>
                `);
                return $poolMsgBox.show();
            }
            const goodsSn = $('.js-orderNumber_input').val().trim();
            if (goodsSn.length === 0) {
                $tips.html(`
                    <span class="tipsContent">
                        ${trans('promotion.order_prize_please_order_num')}
                    </span>
                `);
                return $poolMsgBox.show();
            }
            if (!lotteryLock) {
                lotteryLock = true;
                self.lotteryResult(goodsSn).then(({ fun, status }) => {
                    showLottery = fun;
                    if (status === 0) {
                        $goldBlock.show().addClass('goldBlock_translate goldStart');
                        setTimeout(() => {
                            $goldBlock.removeClass('goldStart');
                        }, 1000);
                        if (typeof document.body.style.animation !== 'string') {
                            awaitAnimationend();
                        }
                    } else {
                        showLotteryBack();
                    }
                });
            }
            return undefined;
        });
        $goldBlock[0].addEventListener('animationend', () => {
            animationendHandle();
        });

        // 抽奖输入框placeholder
        const $placeHoderTxt = $('.placeholder_txt');
        const $orderNumberInput = $('.js-orderNumber_input');
        $orderNumberInput.on('input', (e) => {
            const $this = $(e.target);
            if ($this.val().length > 0) {
                $placeHoderTxt.addClass('hidden');
            } else {
                $placeHoderTxt.removeClass('hidden');
            }
        });
        // 模块标题头
        $('.js-achor .active-list-title').addClass('wishingPool_title-normal');
        // 清空输入框
        $('.orderNumber_close').click((e) => {
            $orderNumberInput.val('');
            $placeHoderTxt.removeClass('hidden');
        });
        // 关闭提示框
        $('.js-tipsContent_close').click(() => {
            $('.js-poolMsgBox').hide();
        });
        // 鼠标经过暂停
        $('.js-prizeSort ul').mouseenter((e) => {
            const index = $(e.currentTarget).closest('.prizeSort_block').data('index');
            this.marqueeMap[index].stop();
        }).mouseleave((e) => {
            const index = $(e.currentTarget).closest('.prizeSort_block').data('index');
            this.marqueeMap[index].start();
        });
        // 分享
        $('.sideQr').prepend(`<p class="wishingShare_txt">${trans('promotion.order_prize_game_win_gifts')}</p>`);
        // $('.side-share-wrap').prepend(`<p class="wishingShare_txt">${trans('promotion.order_prize_share_win_points')}</p>`);
    }
};

singleCase.init();
