import { serviceRedRainRaffle } from 'js/service/promotion.js';
import layer from 'layer';
import './prize.css';
import temp from './prize.art';

export default async (score, activityId, couponUrl, mainUrl) => {
    layerPrize();
    let result = {};
    try {
        result = await serviceRedRainRaffle.http({
            params: {
                activityId
            },
            data: {
                count: score
            },
            loading: false,
        });
    } catch (err) {
        // 强制未中奖状态
        result.status = -1;
    }
    const { status, data } = result;
    let html = '';
    if (status === 0 && data.length > 0) {
        html = temp({
            list: data,
            status: 0, // 0,代表中奖，1代表没中奖
            couponUrl
        });
    } else {
        html = temp({
            status: 1,
            mainUrl
        });
    }
    $('.layui-layer-page .layui-layer-content').html(html);
    openBox();
};

function layerPrize(data) {
    layer.open({
        type: 1,
        content: temp(data),
        area: ['660px', '730px'],
        className: 'redPacket_prize',
        btn: false,
        shadeClose: false
    });
}

function openBox() {
    setTimeout(() => {
        $('.prize').removeClass('prize-none');
    }, 1500);
}
