import layer from 'layer';
import Marquee from 'component/marquee';
import { dateFormat } from 'js/utils/index.js';
import { isLogin } from 'js/core/user.js';
import { serviceGetPrizeList, serviceRedRainHasPlay } from 'js/service/promotion.js';
import { msg as layerBoxMsg } from 'component/layerBox/layerBox';
import Timer from 'component/timer/timer';
import { trans } from 'js/core/translate.js';
import tipLayer from './component/red_packet_tip/red_packet_tip';
import rain from './component/rain/rain.js';
import prizeLayer from './component/prize/prize';
import './red_packet_rain.css';


const redPacketRain = {
    marqueeMap: [],
    async init() {
        this.hasPlay = false; // 这轮是否玩过这个游戏
        this.currentDateIndex = null; // 当前时间所处的时间戳段
        this.lotteryStatus = null; // 进度条位置
        this.dateSlotList = []; // 时间段文案
        this.times = []; // 时间段列表
        this.userIsLogin = await isLogin();
        this.mainSiteUrl = $('.js-mainUrl').val() ? $('.js-mainUrl').val() : window.GLOBAL.DOMAIN_MAIN; // 主会场链接
        this.activityId = $('.js-redPacketRain').data('id');
        this.$rogressInfoList = $('.js-rogressInfoList');
        this.$progressCurrent = $('.js-progressCurrent');
        this.bindEvent();
        this.getSortData();
        this.countTime();
    },

    // 点击事件
    bindEvent() {
        const self = this;
        const $document = $(document);
        // 关闭弹框
        $document.on('click', '.js-closeLayer', () => {
            layer.closeAll();
        });

        // 关闭红包雨游戏
        $document.on('click', '.js-closeRainlayer', () => {
            tipLayer();
            if (this.currentDateIndex >= this.times.length) {
                tipLayer({
                    status: 1,
                    type: 3, // 1代表rule ,2代表quit, 3代表去主会场
                    url: this.mainSiteUrl
                });
                this.turnUrl();
            }
        });

        // 开始开红包雨游戏
        $document.on('click', '.js-readyGo', () => {
            if (this.userIsLogin) {
                rain.init(async (score) => {
                    const couponUrl = `${window.GLOBAL.DOMAIN_USER}/index#/coupon`;
                    await prizeLayer(score, this.activityId, couponUrl, this.mainSiteUrl);
                    self.currentDateIndex += 1;
                    if (self.currentDateIndex >= self.times.length) {
                        // nothing
                    } else {
                        self.timerCalculate(self.times[self.currentDateIndex]);
                    }
                }, () => {
                    tipLayer({
                        status: 1, // 1代表不需要close 按钮
                        type: 2 // 2代表quit, 3代表去主会场
                    });
                });
            } else {
                window.location.href = `${GLOBAL.DOMAIN_LOGIN}/m-users-a-sign.htm?type=1&ref=${encodeURIComponent(window.location.href)}`;
            }
        });
    },

    // 获取榜单数据
    async getSortData() {
        const { status, msg, data } = await serviceGetPrizeList.http({
            loading: false,
            errorPop: false,
            params: {
                activityId: this.activityId,
            }
        });
        if (status === 0) {
            const { commonList, prizeList } = data;
            let prizeStr = '';
            prizeList.forEach((value) => {
                prizeStr += `<li class="prizeWinner_item">${value}</li>`;
            });
            $('.js-prizeWinner').html(prizeStr);

            let commonStr = '';
            commonList.forEach((value) => {
                commonStr += `<li class="prizeWinner_item">${value}</li>`;
            });
            $('.js-couponWinner').html(commonStr);

            this.marqueeMap = new Marquee({
                selector: '.js-prizeSort',
            }).list;
        } else {
            layerBoxMsg(msg);
        }
    },

    /**
     * 1.先对时间数据进行排序
     * 2
     */
    async countTime() {
        const self = this;
        const currentTime = new Date().getTime() / 1000;
        const timeArr = JSON.parse($('.js-timeData').val() || '[]');
        self.times = timeArr.map((item, index) => item.split('-'));
        self.times.forEach((item, index) => {
            if (currentTime < item[1] && self.currentDateIndex === null) {
                self.currentDateIndex = index;
                if (currentTime < item[0]) {
                    self.lotteryStatus = index - 1;
                } else {
                    self.lotteryStatus = index;
                }
            }

            // 储存进度条各时间段的信息
            const dateItem = {
                month: dateFormat(item[0], 'MM'),
                day: dateFormat(item[0], 'dd'),
                startHour: dateFormat(item[0], 'hh'),
                startMin: dateFormat(item[0], 'mm'),
                startSec: dateFormat(item[0], 'ss'),
                endHour: dateFormat(item[1], 'hh'),
                endMin: dateFormat(item[1], 'mm'),
                emdSec: dateFormat(item[1], 'ss'),
            };
            self.dateSlotList.push(dateItem);

        });

        // 没有可抽奖时段时，处于最后一个抽奖时段
        if (self.currentDateIndex === null) {
            self.currentDateIndex = self.dateSlotList.length - 1;
        }

        if (this.userIsLogin) {
            const { status } = await serviceRedRainHasPlay.http({
                params: { activityId: this.activityId },
                data: {}
            });
            if (status === 1) {
                this.currentDateIndex += 1;
            }
        }
        this.openTime();
    },

    // 打开倒计时
    openTime() {
        this.timer = new Timer();
        if (this.currentDateIndex >= this.dateSlotList.length) {
            // nothing
            tipLayer({
                status: 1, // 0 代表需要close按钮， 1代表不需要
                type: 3, // 1代表rule ,2代表quit, 3代表去主会场
                url: this.mainSiteUrl
            });
            this.timerCalculate(this.times[this.currentDateIndex - 1]);
            this.turnUrl();
        } else {
            this.timerCalculate(this.times[this.currentDateIndex]);
        }
        return true;
    },

    // 传入当前时间段，启动倒计时
    timerCalculate(timeArr) {
        const self = this;
        const $timeTitle = $('.js-timeTitle');
        const $rearyGo = $('.js-readyGo');
        const $minTen = $('.js-minTen');
        const $maxTen = $('.js-maxTen');
        function gapTime(timestamp) {
            const now = Math.floor((new Date()) / 1000);
            const interval = timestamp && timestamp - now > 0 ? timestamp - now : 0;
            return interval;
        }
        const formatStr = ` <em class="redPacket_timeNum">{dd}</em>
                        <em class="redPacket_colon">:</em>
                        <em class="redPacket_timeNum">{hh}</em>
                        <em class="redPacket_colon">:</em>
                        <em class="redPacket_timeNum">{mm}</em>
                        <em class="redPacket_colon">:</em>
                        <em class="redPacket_timeNum">{ss}</em>`;
        self.timer.add('.js-redPacketCountDown', {
            format: formatStr,
            interval: gapTime(Number(timeArr[0])),
            onStart(targetOne) {
                self.showTimeSort(self.currentDateIndex - 1);
                $timeTitle.text(`${trans('promotion.red_rain_next_round_begin')}：`);
                $rearyGo.removeClass('active');
                $minTen.removeClass('active');
                $maxTen.addClass('active');
                self.timer.add(targetOne, {
                    interval: gapTime(Number(timeArr[0]) - (10 * 60)),
                    onStart() {
                    },
                    onEnd() {
                        $rearyGo.removeClass('active');
                        $minTen.addClass('active');
                        $maxTen.removeClass('active');
                    },
                    onChange() {}
                });
            },
            onEnd(targetOne) {
                if (self.currentDateIndex < self.times.length) {
                    self.showTimeSort(self.currentDateIndex);
                }
                self.timer.add(targetOne, {
                    format: formatStr,
                    interval: gapTime(Number(timeArr[1])),
                    onStart(targetTwo) {
                        $timeTitle.text(trans('promotion.red_rain_the_round_end'));
                        if (self.currentDateIndex >= self.dateSlotList.length) {
                            $rearyGo.removeClass('active');
                            $minTen.removeClass('active');
                            $maxTen.addClass('active');
                        } else {
                            $rearyGo.addClass('active');
                            $minTen.removeClass('active');
                            $maxTen.removeClass('active');
                        }
                    },
                    onEnd(targetTwo) {
                        $rearyGo.removeClass('active');
                        self.currentDateIndex += 1;
                        if (self.currentDateIndex >= self.times.length) {
                            // nothing
                            tipLayer({
                                status: 1, // 0 代表需要close按钮， 1代表不需要
                                type: 3, // 1代表rule ,2代表quit, 3代表去主会场
                                url: self.mainSiteUrl
                            });
                            self.turnUrl();
                        } else {
                            self.timerCalculate(self.times[self.currentDateIndex]);
                        }
                    }
                });
            }
        });
    },

    // 加载进度条时间段数据
    showTimeSort(dateIndex) {
        this.$rogressInfoList.html('');
        if (dateIndex <= 2) {
            const timeSortLength = this.dateSlotList.length < 8 ? this.dateSlotList.length : 8;
            let classNo = 0;
            for (let i = 0; i < timeSortLength; i += 1) {
                classNo = i + 1;
                this.timeSortHtml(classNo, i);
            }
            // 进度条当前位置
            this.$progressCurrent.addClass(`current_rogress_no${dateIndex + 1}`);
        } else if (this.dateSlotList.length > 8 && this.dateSlotList.length - dateIndex <= 6) {
            const startPosition = this.dateSlotList.length - 8;
            for (let i = startPosition; i < this.dateSlotList.length; i += 1) {
                this.timeSortHtml((i - startPosition) + 1, i);
            }

            // 进度条当前位置
            this.$progressCurrent.addClass(`current_rogress_no${(dateIndex - startPosition) + 1}`);
        } else {
            const startPosition = this.dateSlotList.length <= 8 ? 0 : dateIndex - 2;
            const classNo = this.dateSlotList.length <= 8 ? dateIndex + 1 : 3;
            const timeSortLength = this.dateSlotList.length <= 8 ? this.dateSlotList.length : dateIndex + 6;
            for (let i = startPosition; i < timeSortLength; i += 1) {
                this.timeSortHtml((i - startPosition) + 1, i);
            }
            // 进度条当前位置
            this.$progressCurrent.addClass(`current_rogress_no${classNo}`);
        }
    },

    // 跳转主会场
    turnUrl() {
        setTimeout(() => {
            window.location.href = this.mainSiteUrl;
        }, 2000);
    },

    // 进度条HTML
    timeSortHtml(classNo, index) {
        this.$rogressInfoList.append(`
        <div class="current_rogressInfo current_rogressInfo_no${classNo}" >
            <div class="current_rogressInfo_box">
                <h4>${this.dateSlotList[index].month}-${this.dateSlotList[index].day}</h4>
                <p>${this.dateSlotList[index].startHour}:${this.dateSlotList[index].startMin}-
                ${this.dateSlotList[index].endHour}:${this.dateSlotList[index].endMin}</p>
            </div>
        </div>
        `);
    }
};

redPacketRain.init();
