import layer from 'layer';
import './red_packet_tip.css';
import temp from './red_packet_tip.art';

export default (data) => {
    layer.open({
        type: 1,
        content: temp(data),
        area: '540px',
        className: 'redPacket_tip',
        btn: false,
        shadeClose: false,
    });
};
