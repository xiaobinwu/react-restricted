const win = window;
const ground = $('#ground');
const gameCount = +$('#gameCount').val();
const offsetAngle = -45;
const offsetX = 400;
const offsetY = -500;

(() => {
    let lastTime = 0;
    const vendors = ['webkit', 'moz', 'o', 'ms'];
    // let animationEndEvent = 'animationend';

    for (const i in vendors && !window.requestAnimationFrame) {
        window.requestAnimationFrame = window[`${vendors[i]}RequestAnimationFrame`];
        window.cancelAnimationFrame = window[`${vendors[i]}CancelAnimationFrame`] || window[`${vendors[i]}CancelRequestAnimationFrame`];
    }

    if (!window.requestAnimationFrame) {
        window.requestAnimationFrame = (callback) => {
            const currTime = new Date().getTime();
            const timeToCall = Math.max(0, 16.7 - (currTime - lastTime));
            const id = window.setTimeout(() => {
                callback(currTime + timeToCall);
            }, timeToCall);
            lastTime = currTime + timeToCall;
            return id;
        };
    }

    if (!window.cancelAnimationFrame) {
        window.cancelAnimationFrame = (id) => {
            clearTimeout(id);
        };
    }
    /*
    if (!window.onanimationend) {
        window.animationEnd = function (elem, fn) {
            elem.addEventListener(animationEndEvent, function(e) {
                fn && fn(e);
            }, false);
        };
    } */
})();

const rain = {
    score: 0,
    inited: false,
    raining: false,
    rainTimer: null,
    running: {
        count: gameCount || 10,
        timer: null
    },
    offset: [
        [10, 60],
        [40, 120],
        [70, 180],
        [100, 240],
        [-10, -60],
        [-40, -120],
        [-70, -180],
        [-100, -240],
    ],
    originData: [],
    speed() {
        return (this.random() + 2) * 2;
    },
    supportCss3(style) {
        const prefix = ['webkit', 'Moz', 'ms', 'o'];
        const htmlStyle = document.documentElement.style;
        const humpString = [];
        let i;

        function toHumb(string) {
            return string.replace(/-(\w)/g, ($0, $1) => $1.toUpperCase());
        }

        for (i in prefix) {
            humpString.push(toHumb(`${prefix[i]}-${style}`));
        }

        humpString.push(toHumb(style));

        for (i in humpString) {
            if (humpString[i] in htmlStyle) return true;
        }

        return false;
    },
    init(endCall, pauseCall) {
        this.score = 0;
        this.endCall = endCall;
        this.pauseCall = pauseCall;
        setTimeout(() => {
            ground[0].classList.add('gameEnter');
        }, 33);

        // 是否初始化过
        if (!this.inited) {
            this.inited = true;
        } else {
            return;
        }

        let timer = null;
        let introRectTimer = null;
        const introRect = $('#introRect');
        if (!this.supportCss3('animation')) {

            let count = 0;

            introRectTimer = setInterval(() => {
                count += 1;
                if (count >= 6) {
                    count = 0;
                }
                introRect[0].className = `noani frame_${count}`;
            }, 500);
        }

        $('#readygo').on('click', () => {
            introRect[0].className = '';
            clearInterval(introRectTimer);
            $('#rainIntro')[0].classList.add('hidden');

            const rainCountLayer = $('#rainCountLayer');
            const rainRun = $('#rainRun');
            const countDOM = $('#rainCount');
            rainCountLayer[0].classList.remove('hidden');
            let count = 3;

            countDOM.html(count);

            timer = setInterval(() => {
                count -= 1;
                if (count <= 0) {
                    count = 4;
                    clearInterval(timer);
                    rainCountLayer[0].classList.add('hidden');
                    rainRun[0].classList.remove('hidden');

                    // 计算需要多少个元素
                    this.addEl();
                    this.start();
                } else {
                    countDOM.html(count);
                }
            }, 1000);
        });

        const exit = $('#exit');
        exit.on('mousedown', () => {
            clearInterval(timer);
            this.pause();
        });

        const raining = $('#raining');
        raining.on('mousedown', (e) => {
            if (this.raining && e.target.classList.contains('coupon')) {
                e.target.parentNode.classList.add('flip');
                this.score += 1;
            }
        });

        // 退出游戏
        $(document).on('click', '.js-layer_tipBtn-y', () => {
            $('.layui-layer, .layui-layer-shade, .layui-layer-move').remove();
            this.end(0);
        });
        // 继续游戏
        $(document).on('click', '.js-layer_tipBtn-n', () => {
            $('.layui-layer, .layui-layer-shade, .layui-layer-move').remove();
            this.start();
        });
    },

    addEl() {
        this.originData = [];

        const raining = $('#raining');
        const wWidth = win.innerWidth;
        const wHeight = win.innerHeight;
        const horizontal = Math.ceil((wWidth * 2) / 200);
        const vertical = Math.ceil(wHeight / 70);
        const data = this.originData;
        const offset = this.offset;
        let old = false;
        let str = '';

        for (let i = 0; i < horizontal; i += 1) {
            for (let j = 0; j < vertical; j += 1) {
                const speed = this.speed();
                const left = (i * offsetX) + offset[this.random()][0];
                const top = (j * offsetY) + offset[this.random()][1];
                let style = '';
                if (!this.supportCss3('transform')) {
                    style = `left:${left}px;top:${top}px;`;
                }
                // 记录初始数据
                data.push({
                    top,
                    left,
                    origin: {
                        top: -400,
                        left,
                        speed,
                    }
                });
                if (i % 2 === 0) {
                    if (j % 2 === 0) {
                        old = true;
                    } else {
                        old = false;
                    }
                } else if (j % 2 !== 0) {
                    old = true;
                } else {
                    old = false;
                }
                if (!old) {
                    str += `<i class="line" style="${style}"></i>`;
                } else {
                    str += `<div class="overlying" style="${style}z-index:${(i * j) + 2}">
                        <div class="coupon"></div>
                    </div>`;
                }
            }
        }

        $(raining).html(str);
    },

    start() {
        $('#raining').removeClass('clarity');
        const processbar = $('#processbar').children('.running');
        const endCount = $('#endCount');
        // 下雨动画
        this.rain();

        endCount.html(this.running.count);

        this.running.timer = setInterval(() => {
            this.running.count -= 1;

            if (this.running.count <= 0) {
                // 结束
                clearInterval(this.running.timer);
                this.running.count = gameCount;
                processbar.css({
                    width: 0,
                });
                this.end();
            } else {
                endCount.html(this.running.count);

                processbar.css({
                    width: `${100 - (((this.running.count - 1) / gameCount) * 100)}%`,
                });
            }
        }, 1000);
    },

    // 随机函数
    random(n = 2, m = 6) {
        return +parseInt((Math.random() * ((m - n) + 1)) + n, 10);
    },

    rain() {
        const wHeight = win.innerHeight;
        const elements = $('#raining').children();
        this.raining = true;

        cancelAnimationFrame(this.rainTimer);
        this.rainTimer = requestAnimationFrame(() => {
            // 设置位置
            this.setPos(wHeight, elements);
        });
    },

    setPos(wHeight, elements) {
        const data = this.originData;
        elements.each((index, item) => {
            const curData = data[index];
            const { speed } = curData.origin;
            let { left, top } = curData;
            left -= speed;
            curData.left = left;
            top += speed;
            curData.top = top;

            if (Math.abs(curData.top) - Math.abs(curData.origin.top) > wHeight) {
                curData.left = curData.origin.left;
                curData.top = curData.origin.top;
                item.classList.remove('flip');
                curData.origin.speed = this.speed();
            }

            const translate = `translate(${left}px,${top}px) rotate(${offsetAngle}deg)`;
            if (this.supportCss3('transform')) {
                $(item).css({
                    transform: translate,
                    WebKitTransform: translate,
                    MozTransform: translate,
                    oTransform: translate,
                    msTransform: translate,
                });
            } else {
                $(item).css({
                    left: `${left}px`,
                    top: `${top}px`
                });
            }

        });

        cancelAnimationFrame(this.rainTimer);
        this.rainTimer = requestAnimationFrame(() => {
            // 设置位置
            this.setPos(wHeight, elements);
        });
    },

    pause(status) {
        const raining = $('#raining');
        if (this.raining) {
            this.raining = false;
            clearInterval(this.running.timer);
            cancelAnimationFrame(this.rainTimer);
            raining.addClass('clarity');

            const { pauseCall } = this;
            if (!status && pauseCall) {
                pauseCall();
            }
        }
    },

    // 结束
    end(score) {
        this.pause('end');
        $('#rainRun').addClass('hidden');
        $('#rainIntro').removeClass('hidden');
        $('#raining').removeClass('clarity').html('');
        ground.removeClass('gameEnter');

        const { endCall } = this;
        if (endCall) {
            endCall(score !== undefined ? score : this.score);
        }
    }
};

export default rain;
