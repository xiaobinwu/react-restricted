import layer from 'layer';
import './lucky_ban.css';
import temp from './lucky_ban.art';

export default data => layer.open({
    type: 1,
    content: temp(data),
    area: '900px',
    btn: false,
    skin: 'lucky_ban_dialog',
    shadeClose: false,
});
