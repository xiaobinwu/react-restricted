/**
    @Title 专题状态关闭状态处理临
    @Author luochongfei
    @Time 2018-05-28 16:21:15
*/
import layer from 'layer';
import Timer from 'component/timer/timer.js';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';

import tplDialog from './special_close_handle.art';
import './special_close_handle.css';

runtime.trans = trans;

const app = {
    init() {
        const $modal = $('#js-specialCloseModal');
        if ($modal.length) {
            this.locationHref = $modal.data('jump_link');
            this.showSpecialEndDialog();
        }
    },

    // 显示弹窗
    showSpecialEndDialog() {
        const self = this;
        layer.open({
            fixed: true,
            area: '400px',
            closeBtn: 0,
            btn: false,
            move: false,
            shadeClose: false,
            shade: 0,
            content: tplDialog({
                jumpLink: self.locationHref,
            }),
            success() {
                if (self.locationHref) {
                    self.timerToEnter();
                }
            }
        });
    },

    // 倒计时并处理
    timerToEnter() {
        const self = this;
        const timer = new Timer();
        timer.add('#js-closeTimerWrap', {
            interval: 3,
            format: trans('promotion.jump_text', ['{s}']),
            onEnd() {
                window.location.href = self.locationHref;
            },
        });
    }
};
app.init();
