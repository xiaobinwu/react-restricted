import { throttle } from 'js/utils/index.js';
import './left_nav.css';

const leftNavApp = {
    init() {
        this.bindEvent();
        this.positionChange();
        // this.judgeNavIndex();
    },
    bindEvent() {
        this.winHigh = window.innerHeight;
        const $window = $(window);
        $window.resize(() => {
            this.winHigh = window.innerHeight;
        });
        $window.scroll(throttle(this.positionChange.bind(this), 100));
        const $expand = $('.js-expand');
        const $navContent = $('.js-navContent');
        const $shrink = $('.js-shrink');
        $expand.click(() => {
            $navContent.show(100);
            $expand.hide(100);
        });
        $shrink.click(() => {
            $navContent.hide(100);
            $expand.show(100);
        });
        // $('.leftNav_list').on('click', '.leftNav_link-disabled', (e) => {
        //     e.preventDefault();
        // });
    },
    // 判断当前处于导航栏中的哪个链接
    // judgeNavIndex() {
    //     const $listItem = $('.leftNav_list li');
    //     const linkList = [];
    //     for (let i = 0; i < $listItem.length; i += 1) {
    //         linkList.push($listItem.eq(i).find('a').attr('href'));
    //     }
    //     let currentIndex;
    //     const currentLink = window.location.href;
    //     currentIndex = linkList.findIndex(value => value.indexOf(currentLink) >= 0);
    //     if (currentIndex >= 0) {
    //         $listItem.eq(currentIndex).find('a').addClass('leftNav_link-disabled');
    //     } else {
    //         const searchStr = currentLink.match(/-\d+\.html/)[0];
    //         currentIndex = linkList.findIndex(value => value.indexOf(searchStr) >= 0);
    //         if (currentIndex >= 0) {
    //             $listItem.eq(currentIndex).find('a').addClass('leftNav_link-disabled');
    //         }
    //     }
    // },
    positionChange() {
        const $win = $(window);
        const scrollTop = $win.scrollTop();
        const $leftNav = $('.leftNav');
        if (scrollTop >= $win.height() && scrollTop + this.winHigh <= $('.siteFooter').offset().top) {
            $leftNav.show();
        } else {
            $leftNav.hide();
        }
    }
};

leftNavApp.init();
