import './footer_banner.css';
import FlyingSlide from './flyingSlide';

const footBanner = {
    init() {
        const flyingSlideArr = document.querySelectorAll('.js_flying_slide');
        [...flyingSlideArr].forEach((value) => {
            const flyingSlide = new FlyingSlide({
                wrap: value,
                onChange() {
                    const index = $(value).find('.slide-center').data('index');
                    $(value).find('.slide-radio').removeClass('radio-active');
                    $(value).find('.slide-radio').eq(index).addClass('radio-active');
                }
            });
            if (value.children.length < 2) return;
            // 轮播
            let slideSTLock = false;
            function stopSlideST() {
                slideSTLock = true;
                setTimeout(() => {
                    slideSTLock = false;
                }, 3000);
            }
            $('.js_flying_slide').mouseenter(() => {
                slideSTLock = true;
            }).mouseleave(() => {
                slideSTLock = false;
            });
            setInterval(() => {
                if (slideSTLock) return;
                flyingSlide.operate(1);
                this.judgeScroll();
            }, 3000);
            $(value).on('click', '.slide-left', () => {
                flyingSlide.operate(-1);
                stopSlideST();
                this.judgeScroll();
            });
            $(value).on('click', '.slide-right', () => {
                flyingSlide.operate(1);
                stopSlideST();
                this.judgeScroll();
            });
        });

        // 新增品牌广告位
        const $floatGoodsItem = $('.footer_banner_itemwrap');
        $floatGoodsItem.on('mouseover', '.floatGoodsItem', (e) => {
            const $this = $(e.currentTarget);
            $this.find('.floatGoodsImg').addClass('dsn');
        }).on('mouseout', '.floatGoodsItem', (e) => {
            const $this = $(e.currentTarget);
            $this.find('.floatGoodsImg').removeClass('dsn');
        });
    },
    judgeScroll() {
        const $window = $(window);
        if (this.scrollFlag === 1) {
            $window.scrollTop($window.scrollTop() + 1);
            this.scrollFlag = 0;
        } else {
            $window.scrollTop($window.scrollTop() - 1);
            this.scrollFlag = 1;
        }
    },
    scrollFlag: 1
};

export default footBanner;
