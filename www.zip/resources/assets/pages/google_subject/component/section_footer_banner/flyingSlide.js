/**
 * [getElement 获取元素数组]
 * @param  {HTMLElement|String|ElementArray} element [你需要获取的元素的标记]
 * @return {ElementArray}         [返回元素数组]
 */
function getElement(element) {
    let node = [];
    if (element && element.nodeType && element.nodeType === 1) {
        node = [element];
    } else if (typeof element === 'string') {
        node = document.querySelectorAll(element);
    } else if (Object.prototype.toString.call([]).slice(8, -1) === 'Array') {
        node = element;
    } else {
        console.error('参数有误');
    }
    return [...node];
}

/**
 * [addClass 元素添加类名]
 * @param {HTMLElement|String|ElementArray}    element   [需要添加类名的元素]
 * @param {Array<String>} className [需要添加的类名]
 */
function addClass(element, ...className) {
    getElement(element).forEach((value) => {
        if (value.className.indexOf(className) === -1) {
            value.className = `${value.className.trim()} ${className}`;
        }
    });
}

/**
 * [removeClass 元素删除类名]
 * @param  {HTMLElement|String|ElementArray}    element   [需要删除类名的元素]
 * @param  {Array<String>} className [需要删除的类名]
 */
function removeClass(element, ...className) {
    const reg = new RegExp(className.join('|'), 'g');
    getElement(element).forEach((value) => {
        value.className = value.className.replace(reg, '');
    });
}

/**
 * FlyingSlide：wrap的一级子元素添加切换状态的工具
 * 当子元素不大于2时，工具类FlyingSlide不做任何操作
 * 不做任何样式操作，需要你为类名添加样式[prevClass|centerClass|leftClass|rightClass|nextClass]
 */
export default class FlyingSlide {
    constructor({
        /**
        * [wrap 传入必须是能查到的唯一值]
        * @type {String|HTMLElement}
        */
        wrap = null,
        /**
         * [prevClass 前一个类名的展示，用于动画展示的过度，位置放置在整个容器的左外侧]
         * @type {String}
         */
        prevClass = 'slide-prev',
        /**
         * [centerClass 正中间的类名，z-index要比(leftClass&nextClass)高]
         * @type {String}
         */
        centerClass = 'slide-center',
        leftClass = 'slide-left',
        rightClass = 'slide-right',
        /**
         * [nextClass 后一个类名的展示，用于动画展示的过度，位置放置在整个容器的右外侧]
         * @type {String}
         */
        nextClass = 'slide-next',
        /**
         * [onChange 每次切换触发函数调用]
         */
        onChange = () => {},
    }) {
        this.eleMap = [];
        if (typeof wrap === 'string') {
            this.wrapElement = document.querySelector(wrap);
        } else if (wrap.nodeType === 1) {
            this.wrapElement = wrap;
        } else {
            console.log('FlyingSlide wrap属性错误');
            return false;
        }
        this.lists = [...this.wrapElement.children];

        this.initLength = this.lists.length;
        if (this.initLength <= 1) return false;

        this.onChange = onChange;
        this.currentIndex = 2;
        this.prevClass = prevClass.replace(/^\./, '');
        this.centerClass = centerClass.replace(/^\./, '');
        this.leftClass = leftClass.replace(/^\./, '');
        this.rightClass = rightClass.replace(/^\./, '');
        this.nextClass = nextClass.replace(/^\./, '');

        this.init();
        this.createRadio();
        this.layoutSlick();
    }

    init() {
        this.eleMap[0] = this.lists[this.initLength - 2] ?
            this.lists[this.initLength - 2].cloneNode(true) :
            this.lists[this.initLength - 1].cloneNode(true);
        this.eleMap[1] = this.lists[this.initLength - 1].cloneNode(true);
        this.lists.forEach((value, index) => {
            this.eleMap[index + 2] = value;
        });
        this.eleMap[this.initLength + 2] = this.lists[0].cloneNode(true);
        this.eleMap[this.initLength + 3] = this.lists[1] ? this.lists[1].cloneNode(true) : this.lists[0].cloneNode(true);
        let fragment = document.createDocumentFragment();
        this.eleMap.forEach((value) => {
            fragment.appendChild(value);
        });
        this.wrapElement.innerHTML = '';
        this.wrapElement.appendChild(fragment);
        fragment = null;
    }

    exchangePosition() {
        addClass(this.eleMap, 'stop-transition');
        this.layoutSlick();
        setTimeout(() => {
            removeClass(this.eleMap, 'stop-transition');
        }, 10);
    }

    operate(num) {
        if (num < 0) {
            if (this.currentIndex === 1) {
                this.currentIndex = this.eleMap.length - 3;
                this.exchangePosition();
            }
        } else if (this.currentIndex === this.eleMap.length - 2) {
            this.currentIndex = 2;
            this.exchangePosition();
        }
        setTimeout(() => {
            this.currentIndex = this.currentIndex + num;
            this.layoutSlick();
            this.onChange();
        }, 15);

    }

    layoutSlick() {
        removeClass(this.eleMap, this.leftClass, this.centerClass, this.rightClass, this.nextClass, this.prevClass);

        addClass(this.eleMap[this.currentIndex], this.centerClass);
        addClass(this.eleMap[this.currentIndex - 1], this.leftClass);
        addClass(this.eleMap[this.currentIndex + 1], this.rightClass);

        if (this.currentIndex !== this.eleMap.length - 2) {
            addClass(this.eleMap[this.currentIndex + 2], this.nextClass);
        }

        if (this.currentIndex !== 1) {
            addClass(this.eleMap[this.currentIndex - 2], this.prevClass);
        }

    }

    createRadio() {
        const RADIO = document.createElement('div');
        RADIO.className = 'slide-radio-container';
        for (let i = 0; i < this.initLength; i += 1) {
            const DIV = document.createElement('div');
            const className = i === 0 ? 'slide-radio radio-active' : 'slide-radio';
            DIV.className = className;
            DIV.setAttribute('data-index', i);
            RADIO.appendChild(DIV);
        }
        this.wrapElement.appendChild(RADIO);
    }

}
