import Timer from 'component/timer/timer.js';
import { trans } from 'js/core/translate.js';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import Clipboard from 'clipboard';
import layer from 'layer';
import './promotion_code.css';

/* 新增 - 噱头商品抢购 */
const codeSystem = {
    init() {
        this.timeCut();
        this.eventBind();
    },
    eventBind() {
        /* 新增优惠券弹窗 */
        $(document).on('click', '.js-gimmickGoodsGetCoupon', async function () {  // eslint-disable-line
            const $this = $(this);
            const id = $this.attr('data-couponid');
            if ($this.hasClass('loading') || $this.hasClass('ok')) return;
            $this.addClass('loading');
            getCouponItem({
                templateCode: id,
                defaultState: false,
                errorPop: false
            }).then(async ({ status, msg, data }) => {
                $this.removeClass('loading');
                let str;

                if (data.redirectUrl) {
                    window.location.href = data.redirectUrl;
                } else if (status === 0) {
                    str = `
                    <div class='getCouponDesc'>
                    <p class='getCouponDesc1'>${trans('goodslist.coupon_received_tip')}</p>
                    <p class='getCouponDesc2'>${trans('goods.coupon')}</p>
                    <p class='getCouponDesc3 js-copy2' data-code='${data.couponCode}'><span>${data.couponCode}</span> <i class='copy-icon'></i></p>
                    <p class='getCouponDesc4'>${trans('goodslist.coupon_received_dec1')} -
                    <a href='${GLOBAL.DOMAIN_USER}/index#/coupon'>${trans('goodslist.coupon_received_dec2')}
                    </a> <i class='icon-arrow-right'></i></p>
                    </div>
                    `;
                    new Clipboard('.js-copy2', {
                        text(trigger) {
                            return trigger.dataset.code;
                        },
                    });

                    $this.addClass('ok');
                    $this.html(`
                        <p class="gimmickGoods-couponInfo pr">
                            <strong class="gimmickGoods-couponCode">${data.couponCode}</strong>
                            <a href="${$this.data('goodslink')}" class="gimmickGoods-couponBtn"></a>
                        </p>
                    `);

                    layer.open({
                        type: 1,
                        content: str,
                        area: ['400px', '220px'],
                        offset: ['300px'],
                        closeBtn: 1,
                    });

                } else if (status === 10052071) {
                    $this.addClass('ok');
                    $this.html(`
                        <p class="gimmickGoods-couponInfo pr">
                            <strong class="gimmickGoods-couponCode">${data.couponCode}</strong>
                            <a href="${$this.data('goodslink')}" class="gimmickGoods-couponBtn"></a>
                        </p>
                    `);

                    str = `<div class='getCouponDescError'>${msg}</div>`;
                    layer.open({
                        type: 1,
                        content: str,
                        area: ['400px', '220px'],
                        offset: ['300px'],
                        closeBtn: 1,
                    });

                } else {
                    str = `<div class='getCouponDescError'>${msg}</div>`;
                    layer.open({
                        type: 1,
                        content: str,
                        area: ['400px', '220px'],
                        offset: ['300px'],
                        closeBtn: 1,
                    });
                }
            });
        });
    },
    timeCut() { // 倒计时
        const timer = new Timer();
        timer.add('.js-gimmickGoodsDown', {
            format: `${trans('promotion.begins_in')} {dd}:{hh}:{mm}:{ss}`,
            interval: 'begin',
            onStart(target) { // 初始化按钮状态
                const $subjectGoodItem = target.closest('.gimmickGoods');
                const $btn = $subjectGoodItem.find('.gimmickGoods-btn');
                $btn.show();

                timer.add(target, {
                    interval: 'stopremind',
                    onChange: $.noop,
                    onStart(endTarget) {
                        $btn.addClass('remind js-couponRemind');
                        $btn.text(trans('promotion.promotion_remind_me'));
                    },
                    onEnd(endTarget) {
                        $btn.removeClass('remind js-couponRemind');
                        $btn.addClass('disable');
                        $btn.text(trans('promotion.coming_soon'));
                    }
                });

            },
            onEnd(target) { // 活动开始
                const $subjectGoodItem = target.closest('.gimmickGoods');
                const $btn = $subjectGoodItem.find('.gimmickGoods-btn');

                timer.add(target, {
                    format: `${trans('promotion.ends_in')} {dd}:{hh}:{mm}:{ss}`,
                    interval: 'end',
                    onStart(endTarget) {
                        $btn.removeClass('disable');
                        $btn.addClass('js-gimmickGoodsGetCoupon');
                        $btn.text(trans('promotion.grab_coupon_now'));
                    },
                    onEnd(endTarget) { // 活动结束
                        $btn.removeClass('js-gimmickGoodsGetCoupon');
                        $btn.addClass('disable');
                        $btn.text(trans('promotion.deals_ended'));
                    }
                });
            },
        });
    }
};
codeSystem.init();
