import './rush_to_purchase.css';
