import './coupon.css';

const addCoupon = {
    init() {
        $('.coupon_line_multiple .icon-faq').on('mouseenter', (e) => {
            const $this = $(e.currentTarget);
            const couponTips = $this.find('.coupon_tips');
            if (couponTips.offset().left + couponTips.width() + 40 > ($(window).width() - 160)) {
                couponTips.addClass('coupon_tips_right');
            }
        });
    }
};
export default addCoupon;
