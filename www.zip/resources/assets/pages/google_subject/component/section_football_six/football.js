import { slickFn } from 'js/core/slickFn.js';
import Share from 'component/share/share';
import Service from 'js/http/service';
import layer from 'layer';

const gameScene = $('#gameScene');
if (gameScene.length > 0) {
    // import('./football.css');

    const { DOMAIN_MAIN, DOMAIN_USER, DOMAIN_LOGIN } = GLOBAL;
    const ball = $('#ball');
    const goal = $('#goal');
    const player = $('#player');
    const start = $('#start');
    const cards = goal.children();
    const ballCenter = $('#ballCenter');
    const activityId = gameScene.attr('data-actid');
    const shareWays = $('.commonShare').clone()[0];
    const jsSideNav = $('#js_sideNav');
    let prized = false;
    let gameon = false;
    let random = 0;

    class NormalShare extends Share {
        diyLoginCall() {
            dialog(`<div class="login">Please <a href="${DOMAIN_LOGIN}/m-users-a-sign.htm?type=1">log in</a> to your GearBest account first.</div>`); // eslint-disable-line
        }
        async shareFunc(selector) {
            const { msg } = await new Service().http({
                loading: false,
                errorPop: false,
                method: 'POST',
                cache: false,
                url: `${DOMAIN_MAIN}/activity/lottery/share?t=${+new Date()}`,
                data: {
                    activityId,
                    fackType: $(selector).data('type')
                }
            });
            dialog(msg);
            game.getUserInfo();
        }
    }
    const shareObj = new NormalShare();

    // 分享
    shareObj.facebook({
        appId: 900125666754558,
        selector: '.js-share-fb',
        isLogin: true,
        diyLogin: true
    });
    shareObj.twitter({
        selector: '.js-share-tw',
        desc: $('.js-share-tw').data('desc'),
        title: $('.js-share-tw').data('title'),
        isLogin: true,
        diyLogin: true
    });
    shareObj.google({
        selector: '.js-share-gp',
        title: $('.js-share-gp').data('title'),
        isLogin: true,
        diyLogin: true
    });
    shareObj.vk({
        selector: '.js-share-vk',
        img: $('.js-share-vk').data('image'),
        title: $('.js-share-vk').data('title'),
        desc: $('.js-share-vk').data('desc'),
        isLogin: true,
        diyLogin: true
    });
    shareObj.reddit({
        selector: '.js-share-rt',
        title: $('.js-share-rt').data('title'),
        isLogin: true,
        diyLogin: true
    });
    shareObj.telegram({
        selector: '.js-share-tg',
        desc: $('.js-share-tg').data('desc'),
        isLogin: true,
        diyLogin: true
    });

    jsSideNav.prepend('<div id="ad_app"><p>Download to Get $100 <br>of FREE Coupons!</p><span class="img"><a href="https://gearbest.app.link/pctopios" target="_special"></a><a href="https://gearbest.app.link/pctopandroid" target="_special"></a></span></div>'); // eslint-disable-line

    // 兼容 IE 老版本
    let moveStyle = 'margin';
    const testDiv = document.createElement('div');
    if ('oninput' in testDiv) {
        ['', 'ms', 'webkit', 'moz', 'o'].forEach((prefix) => {
            const transform = `${prefix + (prefix ? 'T' : 't')}ransform`;
            if (transform in testDiv.style) {
                moveStyle = transform;
            }
        });
    }

    let lastTime = 0;
    const vendors = ['webkit', 'moz', 'o', 'ms'];
    let animationEndEvent = '';

    for (const i in vendors && !window.requestAnimationFrame) {
        window.requestAnimationFrame = window[`${vendors[i]}RequestAnimationFrame`];
        window.cancelAnimationFrame = window[`${vendors[i]}CancelAnimationFrame`] || window[`${vendors[i]}CancelRequestAnimationFrame`];
    }

    if (window.animationEnd) {
        animationEndEvent = 'animationend';
    }
    for (const j in vendors && !window.animationEnd) {
        animationEndEvent = `${vendors[j]}Animationend`;
    }

    if (!window.requestAnimationFrame) {
        window.requestAnimationFrame = (callback) => {
            const currTime = new Date().getTime();
            const timeToCall = Math.max(0, 16.7 - (currTime - lastTime));
            const id = window.setTimeout(() => {
                callback(currTime + timeToCall);
            }, timeToCall);
            lastTime = currTime + timeToCall;
            return id;
        };
    }

    if (!window.cancelAnimationFrame) {
        window.cancelAnimationFrame = (id) => {
            clearTimeout(id);
        };
    }

    const animationEnd = (elem, fn) => {
        if (animationEndEvent === '') {
            if (fn) {
                fn();
            }
        } else {
            elem.addEventListener(animationEndEvent, (e) => {
                if (fn) {
                    fn(e);
                }
            }, false);
        }
    };

    start.on('click', () => {
        // reset();
        if (!gameon) {
            gameon = true;
            game.getCheck();
        }
    });

    const curveMove = {
        a: '',
        b: '',
        deg: 0,
        // 相对坐标
        elCoord: {
            x: 0,
            y: 0
        },
        targetCoord: {
            x: 0,
            y: 0
        },
        distance: 0,
        init(el, target, curvature, speed, complete) {
            const self = this;

            // 抛物线公式： y = a*x*x + b*x + c;
            self.a = curvature || 0.007;

            // 元素中心坐标
            const elCenter = {
                x: el.offset().left + (el.width() / 2),
                y: el.offset().top + (el.height() / 2),
            };
                // 目标中心坐标
            let targetCenter = {
                x: 0,
                y: 0,
            };

            if (target.x) {
                targetCenter = {
                    x: target.x,
                    y: target.y
                };
            } else {
                targetCenter = {
                    x: target.offset().left + (target.width() / 2),
                    y: target.offset().top + (target.height() / 2)
                };
            }

            const targetCoordX = targetCenter.x - elCenter.x;
            const targetCoordY = targetCenter.y - elCenter.y;

            self.targetCoord = {
                x: targetCoordX,
                y: targetCoordY
            };

            self.distance = self.targetCoord.y;

            /*
                * 因为经过(0, 0), 因此c = 0
                * 于是：
                * y = a * x*x + b*x;
                * y1 = a * x1*x1 + b*x1;
                * y2 = a * x2*x2 + b*x2;
                * 利用第二个坐标：
                * b = (y2+ a*x2*x2) / x2
            */
            self.b = (targetCoordY - (self.a * targetCoordX * targetCoordX)) / targetCoordX;

            self.move(el, speed, complete);
        },
        move(el, speed, complete) {
            const self = this;
            let startX = 0;
            const rate = self.targetCoord.x > 0 ? 1 : -1;
            const step = () => {
                // 切线 y'=2ax+b
                const tangent = (2 * self.a * startX) + self.b;
                // 下面是根据确定的移动速度，得到当前切线下x也就是水平方向移动的大小
                // 已知两点之间的距离为
                // Math.sqrt((x2-x1) * (x2-x1) + (y2-y1) * (y2-y1));
                // 因此应当是
                // Math.sqrt(△x*△x + △y*△y) = speed
                // y*y + x*x = speed
                // (tangent * x)^2 + x*x = speed
                // x = Math.sqr(speed / (tangent * tangent + 1));
                startX += rate * Math.sqrt(speed / ((tangent * tangent) + 1));

                // 防止过界
                if ((rate === 1 && startX > self.targetCoord.x) || (rate === -1 && startX < self.targetCoord.x)) {
                    startX = self.targetCoord.x;
                }
                self.distance *= 0.985;
                const scale = Math.abs(self.distance / self.targetCoord.y);
                const x = startX;
                const y = (self.a * x * x) + (self.b * x);
                self.deg += 30;

                el[0].setAttribute('data-x', x);
                el[0].setAttribute('data-y', y);
                el[0].setAttribute('data-scale', scale);
                // x, y目前是坐标，需要转换成定位的像素值
                if (moveStyle === 'margin') {
                    el[0].style.marginLeft = `${x}px`;
                    el[0].style.marginTop = `${y}px`;
                } else {
                    el[0].style[moveStyle] = `translate(${x}px, ${y}px) scale(${scale})`;
                    ballCenter[0].style[moveStyle] = `rotate(${self.deg}deg)`;
                }

                if (startX !== self.targetCoord.x) {
                    window.requestAnimationFrame(step);
                } else if (complete) {
                    // 运动结束，回调执行
                    complete();
                }
            };
            window.requestAnimationFrame(step);
        }
    };

    const game = {
        // 抽奖状态
        getCheck: async () => {
            const { status, data, msg } = await new Service({
                method: 'POST',
                loading: false,
                url: `${DOMAIN_MAIN}/activity/lottery/check?t=${+new Date()}`,
            }).http({
                data: {
                    activityId
                }
            });

            if (status === 0) {
                if (+data.code === 10053001) {
                    // 有抽奖次数
                    game.toRaffle().then((resData) => {
                        if (resData.status === 0) {
                            game.toStart(resData.msg);
                        }
                    });
                } else if (+data.code === 10053002) {
                    // 用积分抵扣
                    dialog(msg, () => {
                        $('.footballGame-content').append('<span class="confirmDraw">I’M NOT GIVING UP</span>');
                    });
                } else if (+data.code === 10053003 || +data.code === 10053004) {
                    // 分享获取次数/明天再来
                    dialog(msg, () => {
                        $('.footballGame-content').append(shareWays);
                    });
                }
            } else if (status === 1) {
                // 未登录
                dialog(`<div class="login">Please <a href="${DOMAIN_LOGIN}/m-users-a-sign.htm?type=1">log in</a> to your GearBest account first.</div>`); // eslint-disable-line
            } else if (status === 2) {
                dialog(`<div class="shareNormal">${msg}</div>`);
            }
        },
        // 确认抽奖
        toRaffle: async (needPoint) => {
            const postData = {
                activityId
            };
            if (needPoint) {
                postData.usePoint = 1;
            }
            const { status, msg, data } = await new Service({
                method: 'POST',
                loading: false,
                url: `${DOMAIN_MAIN}/activity/lottery/raffle?t=${+new Date()}`,
            }).http({
                data: postData
            });

            if (status === 0) {
                if (+data.code === 10054001) {
                    prized = true;
                } else {
                    prized = false;
                }
            } else {
                prized = false;
                dialog(msg);
            }
            return { status, msg };
        },
        // 获取用户积分
        getUserInfo: async () => {
            const { status, data } = await new Service({
                method: 'jsonp',
                loading: false,
                errorPop: false,
                url: `${DOMAIN_USER}/query-user-points-info?t=${+new Date()}`,
            }).http();

            if (status === 0) {
                game.getGameTimes(data.pointsBalance);
            }
        },
        // 获取用户可玩次数
        getGameTimes: async (pointsBalance) => {
            const { status, data } = await new Service({
                method: 'jsonp',
                loading: false,
                errorPop: false,
                url: `${DOMAIN_MAIN}/activity/lottery/get-counter-remain?t=${+new Date()}&activityId=${activityId}`,
            }).http();

            if (status === 0) {
                $('.remain_num')[0].innerHTML = pointsBalance;
                $('.remain_num')[1].innerHTML = data.count || 0;
            }
        },
        // 初始化积分排行
        pointsRank: async () => {
            const resData = await new Service({
                method: 'jsonp',
                loading: false,
                errorPop: false,
                url: `${DOMAIN_MAIN}/activity/get-lottery-prize-list?activityId=${activityId}`,
                cache: true,
            }).http();

            if (resData.status === 0) {
                const { commonList, prizeList } = resData.data;

                const container = $('.winListWrap');
                commonList.forEach((item) => {
                    $(container[0]).append(`<div class="li">${item}</div>`);
                });
                prizeList.forEach((item) => {
                    $(container[1]).append(`<div class="li">${item}</div>`);
                });

                container.each(function () { // eslint-disable-line
                    const li = $(this).find('.li');
                    if (li.length > 10) {
                        slickFn({
                            container: $(this),
                            slidesToScroll: 1,
                            slidesToShow: 10,
                            vertical: true,
                            autoplay: true
                        });
                    }
                });
            }
        },
        // 重置足球位置
        reset: () => {
            ball.addClass('wait').css({
                transform: 'translate(0px, 0px) scale(1)',
                top: '0px',
                left: '0px',
            });
            player.removeClass('step_1 step_2');
            cards[random].className = '';
            gameon = false;
        },
        // 开始抽奖
        toStart: (msg) => {
            ball.removeClass('wait');
            random = Math.floor(Math.random() * 10);
            if (random > 8) random = 8;
            const position = $(cards[random]);

            player.addClass('step_1');
            setTimeout(() => {
                player.addClass('step_2');
                // ball roll
                curveMove.init(ball, position, 0.0007, 200, () => {
                    game.finish(msg);
                });
            }, 200);
        },
        // 踢完
        finish: (msg) => {
            const prize = prized ? 'prized' : 'noprize';
            $(cards[random]).addClass('kicked');
            animationEnd(cards[random], (e) => {
                $(cards[random]).addClass(`${prize} showed`).removeClass('kicked');
            });
            // 重置球的位置
            ball.css({
                transform: `translate(0px, 0px) scale(${ball.attr('data-scale')})`,
                top: `${ball.attr('data-y')}px`,
                left: `${ball.attr('data-x')}px`,
            });
            // 回弹
            curveMove.init(ball, { x: 2000, y: 1000 }, 0.0002, 200, () => {
                // 抽奖完成
                dialog(msg, () => {
                    $('.footballGame-content').append(shareWays);
                });
                game.getUserInfo();
            });
        }
    };

    game.getUserInfo();
    game.pointsRank();

    /* eslint-disable */
    function dialog(msg, success) {
        layer.open({
            skin: 'layer-footballGame',
            content: `<div class="footballGame-content">${msg}</div>`,
            end: () => {
                game.reset();
            },
            area: '670px',
            closeBtn: true,
            shade: 0.6,
            btn: false,
            success,
        });
    }
    /* eslint-enable */

    // 消耗积分抽奖
    $(document).on('click', '.confirmDraw', () => {
        game.toRaffle(1).then((resData) => {
            const { status, msg } = resData;
            if (status === 0) {
                layer.closeAll();
                setTimeout(() => {
                    game.toStart(msg);
                }, 400);
            } else {
                dialog(`<div class="shareNormal">${msg}</div>`);
                game.getUserInfo();
            }
        });
    });
}
