import { trans } from 'js/core/translate.js';
import './multiple_goods.css';

const nowTime = parseInt((+new Date()) / 1000, 10);
$('.js-depositExpansion').each((index, value) => {
    const startTime = value.dataset.startTime;
    const endTime = value.dataset.endTime;
    if (!startTime || !endTime || (nowTime > endTime || nowTime < startTime)) {
        $(value).find('.depositExpansion_board').addClass('hidden');
        $(value).addClass('good_dealEnded').find('.js-imgLink').append(`<span class="goodStatus">${trans('promotion.deals_ended')}</span>`);
        $(value).find('.js-addCart').hide();
    }
});
