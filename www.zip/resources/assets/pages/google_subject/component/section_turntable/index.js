import Service from 'js/http/service';
import Rotate from 'component/rotate';
import Marquee from 'component/marquee';
import Share from 'component/share/share';
import layer from 'layer';
import { isLogin } from 'js/core/user.js';
import brushCheck from 'component/brushCheck/brushCheck.js';

const { DOMAIN_MAIN, DOMAIN_USER, DOMAIN_LOGIN } = window.GLOBAL;
const activityId = $('#activityId').val();

class MyService extends Service {
    constructor(params) {
        super(Object.assign({
            method: 'jsonp',
            loading: false,
            errorPop: false,
            cache: false,
        }, params));
    }
}

// 用户是否登陆（Promise对象）
const userIsLogin = isLogin();

// 脚本入口
async function init() {
    const $turntable = $('.turntable');
    if ($turntable.length > 0) {
        import('./index.css');
        new Turntable($turntable);

        // 因为谷歌模板不支持配置下载按钮（侧边导航处）
        // 所以这块人为添加，后期优化需要挪走
        $('#js_sideNav').prepend(`
            <div id="ad_app">
                <p>Download to Get $100 <br>of FREE Coupons!</p>
                <span class="img">
                    <a href="https://gearbest.app.link/pctopios" target="_special"></a>
                    <a href="https://gearbest.app.link/pctopandroid" target="_special"></a>
                </span>
            </div>
        `);
    }
}

class Turntable {
    constructor($parent = null) {
        this.priceIndex = {}; // 奖品索引
        this.isArrowLottery = true; // 是否允许再次抽奖
        this.$parent = $parent;
        this.defineService();
        this.init();
        this.bindEvent();
        this.getWinnerList();
        this.initShare();
    }

    /**
     * 定义请求
     */
    defineService() {
        // 检查是否可以抽奖
        this.serviceCheckLottery = new MyService({
            url: `${DOMAIN_MAIN}/activity/lottery/check`,
            method: 'post',
            data: { activityId }
        });

        // 抽奖接口
        this.serviceRunLottery = new MyService({
            url: `${DOMAIN_MAIN}/activity/lottery/raffle`,
            method: 'post',
            data: { activityId }
        });

        // 请求剩余抽奖次数
        this.serviceGetSpins = new MyService({
            url: `${DOMAIN_MAIN}/activity/lottery/get-counter-remain?&activityId=${activityId}`,
        });

        // 请求剩余积分
        this.serviceGetPoints = new MyService({
            url: `${DOMAIN_USER}/query-user-points-info`,
        });

        // 请求中奖列表
        this.serviceGetWinner = new MyService({
            url: `${DOMAIN_MAIN}/activity/get-lottery-prize-list?activityId=${activityId}`,
            cache: true,
        });

        // 分享完成后请求回调函数
        this.serviceShareCallback = new MyService({
            url: `${DOMAIN_MAIN}/activity/lottery/share`,
            method: 'POST',
        });
    }

    /**
     * 弹出登陆框
     */
    toLogin(link = `${DOMAIN_LOGIN}/m-users-a-sign.htm?type=1`) {
        dialog(`
            <div class="loginDialog">
                Please <a href="${link}">log in</a> to your GearBest account first.
            </div>
        `);
    }

    /**
     * 初始化
     */
    async init() {
        // 兼容性测试
        const bodyStyle = document.body.style;
        const TRANSFORM = ['transform', 'webkitTransform', 'MozTransform', 'msTransform', 'OTransform'];
        const transform = TRANSFORM.find(item => bodyStyle[item] !== undefined);

        const $prizeList = this.$parent.find('.turntable_prizeList');
        const $prizeItem = $prizeList.find('.turntable_prizeItem');
        const $prizeImg = $prizeList.find('.turntable_prizeImg');

        const prizeCount = $prizeItem.length;
        const unitAngle = 360 / prizeCount;
        const unitSkew = 90 - unitAngle;
        const firstAngle = (unitAngle / 2) + 90;

        $prizeItem.each((index, elem) => {
            elem.style[transform] = `rotate(${(unitAngle * index) - firstAngle}deg) skewX(${unitSkew}deg)`;
            this.priceIndex[elem.dataset.order] = index;
        });

        $prizeImg.each((index, elem) => {
            elem.style[transform] = `skewX(${-unitSkew}deg) rotate(${firstAngle}deg) translate(-50%, -210%)`;
        });

        // 一切属性设置好后才显示转盘
        $prizeList.css('opacity', 1);

        // 新建旋转实例
        this.rotate = new Rotate({
            element: this.$parent.find('.turntable_disk')[0],
            duration: 3000,
        });

        this.prizeCount = prizeCount;

        if (await userIsLogin) {
            this.updateSpins();
            this.updatePoints();
        }
    }

    /**
     * 事件定义
     */
    bindEvent() {
        const self = this;
        /**
         * 点击抽奖
         */
        this.$parent.find('.turntable_axle').on('click', async () => {
            if (!self.isArrowLottery) return;
            self.isArrowLottery = false;

            const { status, data, msg } = await self.serviceCheckLottery.http();

            if (status === 0) {
                if (data.code === 10053001) { // 有抽奖次数
                    self.lottery();
                } else if (data.code === 10053002) { // 用积分抵扣
                    self.isArrowLottery = true;
                    dialog(`${msg}<div class="control"><a href="javascript:;" class="confirmBtn">I’M NOT GIVING UP</a></div>`, {
                        success(layero, index) {
                            $(layero).find('.confirmBtn').on('click', () => {
                                self.lottery('usePoint');
                                layer.close(index);
                            });
                        }
                    });
                } else if (data.code === 10053003) { // 分享获取次数
                    dialog(msg, { share: true });
                    self.isArrowLottery = true;
                } else if (data.code === 10053004) { // 明天再来
                    dialog(msg);
                    self.isArrowLottery = true;
                }
            } else if (status === 1 && data.redirectUrl) {
                self.toLogin(data.redirectUrl);
                self.isArrowLottery = true;
            }
        });
    }

    /**
     * 抽奖
     * @param usePoint  是否使用积分抽奖
     */
    async lottery(usePoint) {
        const self = this;
        self.isArrowLottery = false;
        const { status, msg, data } = await this.serviceRunLottery.http({
            data: usePoint ? { activityId, usePoint: 1 } : { activityId }
        }).then(async (resOne) => {
            if (resOne.status === 40373285) {
                const checkContent = await brushCheck({
                    action: resOne.data.action,
                    siteKey: resOne.data.siteKey,
                    recaptchaVersion: resOne.data.recaptchaVersion
                });
                const res = await self.serviceRunLottery.http({
                    data: usePoint ? {
                        activityId,
                        usePoint: 1,
                        gbcaptcha: checkContent.gbcaptcha,
                        captchaType: checkContent.captchaType,
                        recaptchaVersion: checkContent.recaptchaVersion,
                    } : {
                        activityId,
                        gbcaptcha: checkContent.gbcaptcha,
                        captchaType: checkContent.captchaType,
                        recaptchaVersion: checkContent.recaptchaVersion,
                    }
                });
                return res;
            }
            return resOne;
        });
        if (status === 0) {
            const prizeIndex = this.priceIndex[data.order];
            this.rotate.run({
                animateTo: ((360 / this.prizeCount) * (this.prizeCount - prizeIndex)) + (360 * 5),
                onEnd() {
                    dialog(msg, { share: true });
                    self.isArrowLottery = true;
                }
            });

            if (usePoint) {
                this.updatePoints();
            } else {
                this.updateSpins();
            }
        } else {
            dialog(msg);
            self.isArrowLottery = true;
        }
    }

    /**
     * 更新剩余积分
     * @return {Promise<void>}
     */
    async updatePoints() {
        const { status, data } = await this.serviceGetPoints.http();
        if (status === 0) {
            $('#remainingPoints').text(data.pointsBalance);
        }
    }

    /**
     * 更新剩余抽奖次数
     * @return {Promise<void>}
     */
    async updateSpins() {
        const { status, data } = await this.serviceGetSpins.http();
        if (status === 0) {
            $('#remainingSpins').text(data.count);
        }
    }

    /**
     * 请求用于中奖列表
     * @return {Promise<void>}
     */
    async getWinnerList() {
        const { status, data } = await this.serviceGetWinner.http();
        if (status === 0) {
            $('.winnerList-prize').html(data.commonList.map(item => `<li class="winner">${item}</li>`).join(''));
            $('.winnerList-common').html(data.prizeList.map(item => `<li class="winner">${item}</li>`).join(''));
            window.mq = new Marquee({
                selector: '.js-marquee',
            });
        }
    }

    /**
     * 初始化分享功能
     */
    initShare() {
        const self = this;
        class MyShare extends Share {
            diyLoginCall() {
                self.toLogin();
            }
            async shareFunc(selector) {
                const { status, msg } = await self.serviceShareCallback.http({
                    data: {
                        fackType: $(selector).data('type'),
                        activityId,
                    }
                });

                if (status === 1) {
                    // 未登录
                    self.toLogin();
                } else {
                    dialog(msg, {
                        share: true,
                        success() {
                            self.updateSpins();
                        }
                    });
                }
            }
        }

        const share = new MyShare();
        const $turntableTw = $('.js-turntableTw');
        const $turntableGg = $('.js-turntableGg');
        const $turntableVk = $('.js-turntableVk');
        const $turntableRt = $('.js-turntableRt');
        const $turntableTg = $('.js-turntableTg');

        share.facebook({
            appId: 900125666754558,
            selector: '.js-turntableFb',
            isLogin: true,
            diyLogin: true
        });
        share.twitter({
            selector: '.js-turntableTw',
            desc: $turntableTw.data('desc'),
            title: $turntableTw.data('title'),
            isLogin: true,
            diyLogin: true
        });
        share.google({
            selector: '.js-turntableGg',
            title: $turntableGg.data('title'),
            isLogin: true,
            diyLogin: true
        });
        share.vk({
            selector: '.js-turntableVk',
            img: $turntableVk.data('image'),
            title: $turntableVk.data('title'),
            desc: $turntableVk.data('desc'),
            isLogin: true,
            diyLogin: true
        });
        share.reddit({
            selector: '.js-turntableRt',
            title: $turntableRt.data('title'),
            isLogin: true,
            diyLogin: true
        });
        share.telegram({
            selector: '.js-turntableTg',
            desc: $turntableTg.data('desc'),
            isLogin: true,
            diyLogin: true
        });
    }
}

/**
 * 弹出框
 */
function dialog(msg, {
    share = false,
    success = () => {},
    cancel = () => {},
    yes = () => {},
    end = () => {},
} = {}) {
    const shareHtml = share ? `<div class="shareBtns">${$('.turntable_shareBtns').html()}</div>` : '';

    layer.open({
        skin: 'layer-luckyWheel',
        content: `<div class="layer-content-luckyWheel">
                        <div class="vcenter">${msg}${shareHtml}</div>
                  </div>
                  <img src="https://uidesign.gbtcdn.com/GB/image/promotion/20180525_3489/beauty.png?impolicy=hight" class="luckyWheel_beauty">`,
        area: ['640px', '330px'],
        closeBtn: true,
        shade: 0.7,
        btn: false,
        success,
        cancel,
        yes,
        end,
    });
}


export default {
    init,
};
