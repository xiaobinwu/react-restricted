import './increase_purchase.css';
