import 'js/bootstrap';
import $ from 'jquery';
import PubSub from 'pubsub-js';
// 多语言
import { trans } from 'js/core/translate.js';
import { updateLazyload } from 'js/utils/lazyload.js';
// 大数据埋点
import flashSaleTrack from 'js/track/define/flashSale.js';
import Timer from '../../component/timer/timer.js';
import './flash_sale.css';

flashSaleTrack();

const flashSlaeApp = {
    init() {
        const $tabContainer = $('.flaseTabContainer');
        const $tabList = $tabContainer.find('.flaseTabContainer_list');
        let tabOffsetTop = 0;
        if ($tabContainer.length) {
            tabOffsetTop = $tabContainer.offset().top;
        }
        let SeperatTop;
        $('.flaseTabContainer_list .flaseTabContainer_item').on('click', (e) => {
            const index = $(e.currentTarget).index();
            if ($('.tabContentSeperat').length) {
                SeperatTop = $('.tabContentSeperat').offset().top;
            }
            if (index === 0) {
                $(window).scrollTop(parseInt(tabOffsetTop, 10));
            } else {
                $(window).scrollTop(parseInt(SeperatTop - 95, 10));
            }
        });
        PubSub.subscribe('nativeScroll', () => {
            const pageScrollTop = $(window).scrollTop();
            if ($('.tabContentSeperat').length) {
                SeperatTop = $('.tabContentSeperat').offset().top;
            }
            if (pageScrollTop - tabOffsetTop > 0) {
                $tabList.addClass('flaseTabContainer_list-fixed');
            } else {
                $tabList.removeClass('flaseTabContainer_list-fixed');
            }
            if (pageScrollTop - SeperatTop > -100) {
                $tabList.find('.flaseTabContainer_item').removeClass('active').eq(1).addClass('active');
            } else {
                $tabList.find('.flaseTabContainer_item').removeClass('active').eq(0).addClass('active');
            }
        });
        /*
        daily deals 切换
        */
        $('.cateList_tab').on('click', (e) => {
            const $target = $(e.target);
            const index = $target.parents('.cateList_item').index() || $target.index();
            $target.parents('.cateList_item').addClass('cateList_item-active').siblings().removeClass('cateList_item-active');
            $('.cateListContent').find('.cateListContent_list')
                .removeClass('cateListContent_list-show').eq(index)
                .addClass('cateListContent_list-show');
            updateLazyload();
        });

        // 倒计时
        // 你可以这么
        const timer = new Timer();
        // 标题的时间
        timer.add('.js-titleTime', {
            format: '{dd}:{hh}:{mm}:{ss}',
            interval: 'begin',
        });
        // tab 时间
        timer.add('.js-tabTime', {
            format: '{dd}:{hh}:{mm}:{ss}',
            interval: 'begin',
        });

        // 活动已经开始商品的倒计时
        timer.add('.js-goodTime', {
            format(time) {
                return time < 24 * 60 * 60 ? `${trans('goodslist.end_time')}: {hh}:{mm}:{ss}` : `${trans('goodslist.end_time')}: {d} D {h} H`;
            },
            interval: 'end',
            onStart() {
                // 按钮文案显示为 "Coming Soon"
            },
        });

        // 活动还未开始的商品倒计时
        timer.add('.js-goodTime-coming', {
            format(time) {
                return time < 24 * 60 * 60 ? `${trans('goodslist.start_time')}: {hh}:{mm}:{ss}` : `${trans('goodslist.start_time')}: {d} D {h} H`;
            },
            interval: 'begin',
            onStart() {
                // 按钮文案显示为 "Coming Soon"
            },
        });
    },
};
flashSlaeApp.init();
