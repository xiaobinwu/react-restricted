import 'js/bootstrap';
import $ from 'jquery';
import { slickFn } from 'js/core/slickFn.js';
import { serviceGetConcentrateGoods } from 'js/service/goods';
import { dateFormat } from 'js/utils/index.js';
import PubSub from 'pubsub-js';
import './global_launch.css';

const $imgStartBanNavItem = $('.imgStartBan_navItem');
const $imgComingBanNavItem = $('.imgComingBan_navItem');
const $window = $(window);
const $categoryItemTab = $('.js-categoryItemTab');
const tabPage = [1, 0, 0, 0, 0]; // 固定5个选项卡，产品确认的，代表每个tab目前已经已经获得的页数

// tab选项卡页面事件
const tabProductApp = {
    init() {
        this.formatTime();
        this.bindEvent();
    },
    bindEvent() {
        this.ceiling();
        this.switch();
        this.insertDOM();
    },
    // 吸顶
    ceiling() {
        PubSub.subscribe('nativeScroll', (e) => {
            const $categoryItemTabHeight = $categoryItemTab.outerHeight(); // 导航栏的高度
            const scrollWindowTop = $window.scrollTop(); // window滚动高度
            const $categoryProductProductDiv = $('.categoryProduct_productDiv');
            const $categoryProductProductDivTop = $categoryProductProductDiv.offset().top; // 商品栏距离文档顶部高度
            if (scrollWindowTop >= $categoryProductProductDivTop - $categoryItemTabHeight) {
                if (!$categoryItemTab.hasClass('categoryProduct_Tab-fixed')) {
                    $categoryItemTab.addClass('categoryProduct_Tab-fixed');
                }
            } else {
                $categoryItemTab.removeClass('categoryProduct_Tab-fixed');
            }
        });
    },
    // 切换种类商品
    switch() {
        $(document).on('click', '.js-itemTab', async (e) => {
            const $currentTarget = $(e.currentTarget);
            const currentIndex = $currentTarget.index();
            $currentTarget.addClass('active').siblings().removeClass('active');
            $('.categoryProduct_productItem').eq(currentIndex).addClass('active').siblings()
                .removeClass('active');
            const $productItemWrap = $('.categoryProduct_productItem ').eq(currentIndex).find('.categoryProduct_Wrap');
            if (tabPage[currentIndex] === 0) {
                const currentPageIndex = tabPage[currentIndex] + 1;
                tabPage[currentIndex] = currentPageIndex;
                try {
                    const res = await serviceGetConcentrateGoods.http({
                        params: {
                            tab: currentIndex + 1,
                            page: currentPageIndex,
                            pageSize: 30,
                        },
                    });
                    if (res.status === 0) {
                        if (res.data.length < 30) {
                            const tabIndex = $(e.currentTarget).index();
                            $('.categoryProduct_productItem').eq(tabIndex).find('.js-viewMore').hide();
                        }
                    }
                    const temp = await import('./component/product_item.art');
                    $productItemWrap.append(temp(res));
                    PubSub.publish('sysUpdateCurrency', {
                        context: $productItemWrap[0],
                    });
                } catch (err) {
                    throw new Error(err);
                }
            }
        });
    },
    // viewmore异步插入dom
    insertDOM() {
        $(document).on('click', '.js-viewMore', async (e) => {
            const $currentTarget = $(e.currentTarget);
            const viewMoreDataIndex = $currentTarget.data('categoryindex');
            // const viewMoreDomIndex = $currentTarget.index();
            const $productItemWrap = $currentTarget.parent().siblings('.categoryProduct_Wrap');
            const currentTabPage = tabPage[viewMoreDataIndex - 1] + 1; // 将要获取的页数数据
            tabPage[viewMoreDataIndex - 1] = currentTabPage;
            try {
                const res = await serviceGetConcentrateGoods.http({
                    params: {
                        tab: viewMoreDataIndex,
                        page: currentTabPage,
                        pageSize: 30,
                    },
                });
                if (res.status === 0) {
                    if (currentTabPage === 4 || res.data.length < 30) {
                        $(e.currentTarget).hide();
                    }
                }
                const temp = await import('./component/product_item.art');
                $productItemWrap.append(temp(res));
                PubSub.publish('sysUpdateCurrency', {
                    context: $productItemWrap[0],
                });
            } catch (err) {
                const turnOldIndex = tabPage[viewMoreDataIndex - 1] - 1; // 当网络请求错误时，页数回到上一页
                tabPage[viewMoreDataIndex - 1] = turnOldIndex;
            }
        });
    },
    // 格式化时间
    formatTime() {
        const $comingTime = $('.js-commingTime');
        $.each($comingTime, (index, value) => {
            const timeStamp = $(value).data('comingtime');
            const formatTime = dateFormat(timeStamp, 'dd/MM/yyyy');
            $(value).text(formatTime);
        });
    }
};
tabProductApp.init();

// 返回顶部
$('.js-toTop').click(() => {
    $window.scrollTop(0);
});

// 跑马灯调用
slickFn({
    container: $('.js-startImgSlick'),
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
    slidesToShow: 4,
    slidesToScroll: 4,
    prevArrow: $imgStartBanNavItem.eq(0),
    nextArrow: $imgStartBanNavItem.eq(1)
});

slickFn({
    container: $('.js-comingImgSlick'),
    dots: true,
    autoplay: true,
    autoplaySpeed: 2000,
    lazyLoad: 'ondemand',
    slidesToShow: 4,
    slidesToScroll: 4,
    prevArrow: $imgComingBanNavItem.eq(0),
    nextArrow: $imgComingBanNavItem.eq(1)
});

