import 'js/bootstrap';
import 'js/utils/validation.config.js';
import $ from 'jquery';
import layer from 'layer';
import { serviceConfirmIdentity } from 'js/service/auth.js';
import './confirm_identity.css';

const app = {
    // 初始化
    init() {
        this.initForm();
        this.defineEvent();
    },

    // 表单
    $form: $('#js-formConfirmIdentity'),

    // 验证码输入框
    $captchIpt: $('#js-iptVerify'),

    // 验证码图片
    $captchImg: $('#js-captchImg'),

    // 提交按钮
    $submit: $('input[type="submit"]'),

    // 定义事件
    defineEvent() {
        const self = this;
        this.$form.on('submit', function(e) {// eslint-disable-line
            e.preventDefault();
            if (self.$form.valid()) {
                self.validIdentity();
            }
        });

        this.$captchImg.on('click', function(){// eslint-disable-line
            self.refreshCaptcha();
        });
    },

    // 初始化表单
    initForm() {
        this.$form.validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                },
                captcha: {
                    required: true,
                },
            },
        });
    },

    // 刷新验证码
    refreshCaptcha() {
        this.$captchIpt.val('').focus();
        this.$captchImg.attr('src', `${this.$captchImg.data('path')}?${Math.random()}`);
    },

    // 请求验证账号
    async validIdentity() {
        try {
            this.$submit.addClass('loading');
            const sdata = this.$form.serialize();
            const res = await serviceConfirmIdentity.http({
                loading: true,
                errorPop: false,
                data: sdata,
            });
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else if (res.msg) {
                layer.msg(res.msg);
            }
            this.refreshCaptcha();
            this.$submit.removeClass('loading');
        } catch (error) {
            // error
        }
    },
};

app.init();
