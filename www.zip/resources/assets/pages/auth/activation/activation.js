import $ from 'jquery';
import 'js/bootstrap';
import Timer from 'component/timer/timer';
import { serviceActivationEmail } from 'js/service/auth.js';
import './activation.css';

const $hdEmail = $('#js-hdEmail'); // 邮件地址
const $btnSend = $('#js-btnResendEmail'); // 发送按钮
const $panelResendTime = $('#js-activateResendTime'); // 再次可发送倒计时显示区
const $activationReturn = $('.js-activationReturn'); // 激活倒计时


// 发送邮件
async function sendActivationEmail(email) {
    const res = await serviceActivationEmail.http({
        method: 'POST',
        data: {
            email,
        },
    });

    $btnSend.addClass('disabled');

    new Timer($panelResendTime, {
        format: '{ss}',
        interval: Number(res.data.ttl),
        onEnd() {
            $btnSend.removeClass('disabled');
            $panelResendTime.parent().slideUp();
        }
    });

    // 仅优化显示效果
    setTimeout(() => {
        $panelResendTime.parent().slideDown();
    }, 1000);
}

// 触发发送邮件
$btnSend.on('click', function (e) { // eslint-disable-line
    e.preventDefault();
    const email = $hdEmail.val();
    sendActivationEmail(email);
});

// 激活倒计时
if ($activationReturn.length > 0) {
    const rollbackUrl = $('.js-activationRollbackUrl').data('rollbackurl');
    new Timer($activationReturn, {
        format: '{ss}',
        interval: 3,
        onEnd() {
            window.location.href = rollbackUrl;
        }
    });
}
