import 'js/bootstrap';
import 'js/utils/validation.config.js';
import $ from 'jquery';
import layer from 'layer';
import { serviceResetPassword } from 'js/service/auth.js';
import './reset_password.css';

const app = {
    // 初始化
    init() {
        this.initForm();
        this.defineEvent();
    },

    // 表单
    $form: $('#js-formResetPassword'),

    // 提交按钮
    $submit: $('input[type="submit"]'),

    // 登录页面
    uriLogin: $('#js-hdUrlLoginIndex').val(),

    // 定义事件
    defineEvent() {
        const self = this;
        this.$form.on('submit', function(e) {// eslint-disable-line
            e.preventDefault();
            if (self.$form.valid()) {
                self.validIdentity();
            }
        });

        // password 提示 特殊处理
        this.$form.find('#passWord').on('input', (e) => {
            e.target.value = e.target.value.replace(/\s/g, '');
        });
    },

    // 初始化表单
    initForm() {
        this.$form.validate({
            rules: {
                passWord: {
                    required: true,
                    vldPassword: true,
                },
                configPassword: {
                    required: true,
                    equalTo: '#passWord',
                },
            },
        });
    },

    // 请求验证账号
    async validIdentity() {
        try {
            this.$submit.addClass('loading');
            const sdata = this.$form.find('input[id!="password2"]').serialize();
            const res = await serviceResetPassword.http({
                loading: true,
                errorPop: false,
                data: sdata,
            });
            if (+res.status === 0) {
                window.location.href = this.uriLogin;
            } else if (typeof res.msg !== 'undefined') {
                layer.msg(res.msg);
            }
            this.$form[0].reset();
            this.$submit.removeClass('loading');
        } catch (error) {
            // error
        }
    },
};

app.init();
