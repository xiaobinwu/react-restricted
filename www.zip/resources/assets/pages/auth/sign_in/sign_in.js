import 'js/bootstrap';
import 'js/utils/validation.config.js';

import Cookies from 'js/utils/cookie';
import { trans } from 'js/core/translate.js';
import brushCheck from 'component/brushCheck/brushCheck.js';
import {
    serviceLogin,
    serviceSocialLogin,
    serviceSocialLoginUrl,
    serviceSocialCheck,
    serviceSocialTypeList,
    servicePassportInit
} from 'js/service/auth.js';
import { serializeData, getTimezone, getUrlQuery } from 'js/utils/index.js';

import $ from 'jquery';
import Track from 'js/track/track';
import layer from 'layer';
import Searcher from 'component/searcher/index';
import { getCountryCode } from 'js/core/currency.js';
import { initFirebase } from 'js/core/firebase/main.js';
import './sign_in.css';
import bindEmail from './component/bind_email/bind_email';

new Track({
    page: true,
}).run();

const $formSign = $('#js-formLogin');
const $btnSubmit = $('#js-btnSubmit');

const $captchaBox = $('#js-captchaBox');
const $verify = $('#js-verify');
const $iptVerify = $('#js-iptVerify');
const $prejudgingForm = $('#js-prejudgingForm');

let showCaptcha = false;

// 刷新验证码
function refreshVerify() {
    $iptVerify.val('');
    $verify.attr('src', `${$verify.data('path')}?${Math.random()}`);
}

// 触发验证码刷新
$verify.on('click', () => {
    refreshVerify();
});

function showCaptchaFn() {
    refreshVerify();
    $captchaBox.show();
    $iptVerify.removeClass('ignore');
    showCaptcha = true;
}

// 登录请求并处理
async function sign(sdata) {
    $btnSubmit.addClass('loading');
    const currentUrl = window.location.href;
    const refUrl = getUrlQuery(currentUrl).ref;
    const { data, status, msg } = await serviceLogin.http({
        data: Object.assign(sdata, {
            userCenterSuffix: window.location.hash,
        }),
    });
    // 防刷校验
    // if (+status === 40373285) {
    //     const checkContent = await brushCheck({
    //         action: data.action,
    //         siteKey: data.siteKey,
    //         recaptchaVersion: data.recaptchaVersion
    //     });
    //     if (!checkContent) {
    //         return;
    //     }
        // const res = await serviceLogin.http({
        //     data: Object.assign(sdata, {
        //         userCenterSuffix: window.location.hash,
        //         gbcaptcha: checkContent.gbcaptcha,
        //         captchaType: checkContent.captchaType,
        //         recaptchaVersion: checkContent.recaptchaVersion
        //     }),
        // });
        // // 临时处理，后序需要确定status状态码区分各状态
        // if (res.status === 0) {
        //     if (refUrl && currentUrl.indexOf('user.gearbest') < 0 && currentUrl.indexOf('login.gearbest') < 0) { // 处理专题页面跳转登录页时，跳不回来源页面
        //         window.location.href = refUrl;
        //     } else if (res.data && res.data.redirectUrl) {
        //         window.location.href = res.data.redirectUrl;
        //     }
        // } else if (res.status === 10070002) {
        //     showCaptchaFn();
        // } else if (res.status === 10070003) {
        //     window.location.href = res.data.redirectUrl;
        // } else if (res.data && res.data.redirectUrl) {
        //     window.location.href = res.data.redirectUrl;
        // } else {
        //     layer.msg(res.msg);
        // }
        // if (showCaptcha) {
        //     refreshVerify();
        // }

        // $btnSubmit.removeClass('loading');
    //     return;
    // }

    // 临时处理，后序需要确定status状态码区分各状态
    if (status === 0) {
        try {
            await initFirebase(true);
        } catch (e) {
            // nothing
        }
        if (refUrl && currentUrl.indexOf(window.GLOBAL.DOMAIN_USER_PREFIX) < 0 &&
            currentUrl.indexOf(window.GLOBAL.DOMAIN_USER) < 0) { // 处理专题页面跳转登录页时，跳不回来源页面录页时，跳不回来源页面
            window.location.href = refUrl;
        } else if (data && data.redirectUrl) {
            window.location.href = data.redirectUrl;
        }
    } else if (status === 40373285) { // 防刷校验40373285,然后第二次调用登陆接口
        const checkContent = await brushCheck({
            action: data.action,
            siteKey: data.siteKey,
            recaptchaVersion: data.recaptchaVersion
        });
        console.log(checkContent);
        if (!checkContent) {
            return;
        }
        sign(Object.assign(sdata, {
            gbcaptcha: checkContent.gbcaptcha,
            captchaType: checkContent.captchaType,
            recaptchaVersion: checkContent.recaptchaVersion
        }));
        return;
    } else if (status === 10070002) {
        showCaptchaFn();
    } else if (status === 10070003) {
        window.location.href = data.redirectUrl;
    } else if (data && data.redirectUrl) {
        window.location.href = data.redirectUrl;
    } else {
        layer.msg(msg);
    }
    if (showCaptcha) {
        refreshVerify();
    }

    $btnSubmit.removeClass('loading');
}

// 登录表单验证
$formSign.validate({
    rules: {
        email: {
            required: true,
            email: true,
        },
        passWord: {
            required: true,
        },
        captcha: {
            required: true,
        },
    },
    messages: {
        email: {
            required: trans('login.please_enter_a_valid_email_address'),
        },
        passWord: {
            required: trans('login.provide_a_password'),
        },
        captcha: {
            required: trans('login.please_enter_the_correct_code'),
        }
    }
});
$prejudgingForm.validate({
    debug: true,
    rules: {
        agree: {
            required: true,
        },
        confirm: {
            required: true,
        },
        email: {
            required: true,
        }
    },
    messages: {
        agree: {
            required: trans('login.to_complete_the_registration')
        },
        confirm: {
            required: trans('login.to_complete_the_registration_eu')
        },
        email: {
            required: trans('login.to_complete_the_registration_eu')
        }
    }
});

// 登录表单提交
$formSign.on('submit', (e) => {
    e.preventDefault();
    const $this = $(e.currentTarget);

    if ($btnSubmit.hasClass('loading')) {
        return;
    }
    if ($this.valid()) {
        const sdata = serializeData($this);

        // 添加时区
        sdata.timeZone = getTimezone();
        if (!showCaptcha) {
            delete sdata.captcha;
        }
        sign(sdata);
    }
});

// 针对邮件输入时追加邮箱后缀
async function emailSuffix() {
    const localIp = await getCountryCode();
    const globalEmailSuffix = [
        '@gmail.com',
        '@yahoo.com',
        '@hotmail.com',
        '@outlook.com'
    ];
    const localEmail = {
        US: '@aol.com',
        RU: [
            '@yandex.com',
            '@inbox.ru',
            '@mail.ru'
        ],
        IT: '@libero.it',
        BR: '@sinos.net',
        DE: '@gmx.de',
        FR: '@orange.fr'
    };
    new Searcher({
        selector: '#email',
        skin: '',
        keyOfName: 'name',
        keyOfCode: 'code',
        minLength: 0,
        preventDefault: false,
        service: (data) => {
            const dataArr = [];
            if (data && data.substr(data.length - 1, 1) === '@') {
                const newData = data.substr(0, data.length - 1);
                globalEmailSuffix.forEach((item) => {
                    dataArr.push({ name: newData + item });
                });
                if (Array.isArray(localEmail[localIp])) {
                    localEmail[localIp].forEach((localItem) => {
                        dataArr.push({ name: newData + localItem });
                    });
                } else if (localEmail[localIp]) {
                    dataArr.push({ name: newData + localEmail[localIp] });
                }
            }
            return dataArr;
        },
        onChange() {
            $('#email').focus().blur();
        }
    });
}
emailSuffix();


// ******************************** 第三方(社会化)登录 ********************************
class SocialLogin {
    constructor(options) {
        const defaults = {
            socialList: [],
        };
        this.setting = Object.assign(defaults, options);

        this.msgAuthFail = trans('login.auth_fail');

        this.$thirdLoginList = $('.js-thirdLoginList');

    }

    init() {
        this.ThirdEvent();
    }

    // 第三方登录请求（修定）
    async ajaxCode() {
        const self = this;

        // 记录时区
        self.ajaxData.timeZone = getTimezone();

        const res = await serviceSocialLogin.http({
            data: Object.assign(self.ajaxData, {
                userCenterSuffix: window.location.hash,
            }),
        });

        if (+res.status === 0) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                window.location.href = window.GLOBAL.DOMAIN_MAIN || '/';
            }
        } else if (Number(res.data.innerCode) === 70051) {
            // 取绑定邮箱地址
            if (res.data.email) {
                self.ajaxData.email = res.data.email;
            }
            bindEmail(self.ajaxData);
        } else {
            layer.msg(res.msg);
        }
    }

    // 第三方 event
    ThirdEvent() {
        this.$thirdLoginList.find('.js-thirdLoginBtn').on('click', (e) => {
            e.preventDefault();
            const thirdType = $(e.currentTarget).data('type');
            const features = this.windowConfig(700, 500);
            const myWindow = window.open('', 'newwindow', features);
            this.ThirdLogin(myWindow, thirdType);
        });
    }

    // 第三方登录
    async ThirdLogin(myWindow, typeVal) {
        const csrfName = '_token';
        const ajdata = { type: typeVal };
        const res = await serviceSocialLoginUrl.http({
            data: ajdata,
        });
        myWindow.location.href = res.data.loginUrl;
        const loop = setInterval(async () => {
            if (myWindow.closed) {
                clearInterval(loop);
                if (Cookies.get('sing_code')) {
                    this.ajaxData = {
                        type: typeVal,
                        code: Cookies.get('sing_code')
                    };
                    Cookies.set('sing_code', null, { expires: 0 });
                } else if (Cookies.get('sing_token')) {
                    this.ajaxData = {
                        type: typeVal,
                        token: Cookies.get('sing_token')
                    };
                    Cookies.set('sing_token', null, { expires: 0 });
                } else {
                    return false;
                }
                // CSRF攻击防御
                this.ajaxData[csrfName] = $('input[name=_token]').val();

                // 获取是否欧盟
                const passportInit = await servicePassportInit.http();
                if (passportInit.status !== 0) {
                    layer.msg(passportInit.msg);
                    return false;
                }
                if (Number(passportInit.data.isEU) === 1) {
                    const check = await serviceSocialCheck.http({
                        data: this.ajaxData
                    });
                    if (check.status === 0) {
                        this.ajaxCode();
                    } else if (check.data.innerCode === 70017) {
                        const preLayer = layer.open({
                            content: $('.js-prejudging'),
                            type: 1,
                            offset: '250px',
                            area: '550px',
                            btn: 0,
                            shadeClose: 0,
                            closeBtn: 1
                        });
                        $prejudgingForm.on('submit', (e) => {
                            e.preventDefault();
                            if ($prejudgingForm.valid()) {
                                layer.close(preLayer);
                                this.ajaxCode();
                            }
                        });
                    } else {
                        layer.msg(check.msg);
                    }
                } else {
                    this.ajaxCode();
                }
            }
            return true;
        }, 200);
    }

    // window open 基本配置
    windowConfig(wid, hei) {
        const windowWidth = $(window).width();
        const windowHeight = $(window).height();
        const width = wid;
        const height = hei;
        const top = (windowHeight - height) / 2;
        const left = (windowWidth - width) / 2;
        const features = `
            toolbar = no, 
            menubar = no, 
            scrollbars = no, 
            resizable = no, 
            location = no, 
            status = no, 
            titlebar = yes, 
            alwaysRaised = yes, 
            width=${width}, 
            height=${height},
            top=${top},
            left=${left}`;
        return features;
    }
}

const socialLogin = new SocialLogin({
    socialList: ['facebook', 'google', 'vk', 'instagram'],
});

// 加载第三方登录按钮
async function getThredBtn() {
    const $thirdLoginList = $('.js-thirdLoginList');
    let loginBtnHtml = '';
    const thredBtnList = await serviceSocialTypeList.http();
    thredBtnList.data.forEach((item) => {
        switch (item.type) {
        case 1:
            loginBtnHtml = `<a href="javascript:;" class="authVia_item authVia_fb js-thirdLoginBtn" id="" data-type="1">
            <i class="icon-fb"></i>
            </a>`;
            $thirdLoginList.append(loginBtnHtml);
            break;
        case 2:
            loginBtnHtml = `<a href="javascript:;" class="authVia_item authVia_gplus js-thirdLoginBtn" id="" data-gapiattached="true" data-type="2">
            <i class="icon-gplus"></i>
            </a>`;
            $thirdLoginList.append(loginBtnHtml);
            break;
        case 5:
            loginBtnHtml = `<a href="javascript:;" class="authVia_item authVia_vk gb-hide js-thirdLoginBtn"  data-gapiattached="true" data-type="5">
            <i class="icon-vk"></i>
            </a>`;
            $thirdLoginList.append(loginBtnHtml);
            break;
        case 6:
            loginBtnHtml = `<a href="javascript:;" class="authVia_item authVia_instagram js-thirdLoginBtn" data-gapiattached="true" data-type="6">
            </a>`;
            $thirdLoginList.append(loginBtnHtml);
            break;
        default:
        }
    });
    socialLogin.init();
}
getThredBtn();

// ******************************** 访客模式功能 ********************************
const visitorObj = {
    faqBtn: $('.js-visitorFaqBtn'),
    faqBox: $('.js-visitorFaqBox'),
    init() {
        const that = this;
        this.faqBtn.click(() => {
            layer.open({
                content: that.faqBox,
                type: 1,
                area: '730px',
                btn: 0,
                shadeClose: 1,
                closeBtn: 1
            });
        });
    }
};
if (window.SIGNVAR.visitor) visitorObj.init();
