/**
 * Created by Liu.Jun on 2018/3/7.
 */

import { getTimezone } from 'js/utils/index.js';
import { trans } from 'js/core/translate.js';
import layer from 'layer';
import { serviceSocialBind } from 'js/service/auth.js';
import 'js/utils/validation.config.js';

const NO_EMAIL = 70051;
const EMAIL_BIND = 70119;
const EMAIL_REGISTERED = 70008;

class BindEmail {
    constructor($form) {
        this.$form = $form;
        this.$btnSubmit = $form.find('#js-bindEmailSubmit');
        this.$tipBox = $form.find('#bindMailForm_tip');

        this.validator();
        this.bindEvent();
        this.reset();
    }

    postData = {};
    timerList = [];
    static countdown(callBack, endCall, maxTime = 60, duration = 1000) {
        let times = maxTime;
        let countdownTimer = null;
        let callFn = null;

        const end = () => {
            clearTimeout(countdownTimer);
            callFn = null;
            endCall();
        };

        callFn = () => {
            if (times > 0) {
                callBack(times);
                times -= 1;
                countdownTimer = setTimeout(() => {
                    callFn();
                }, duration);
            } else {
                end();
            }
        };

        callFn();
        return end;
    }
    codeAdapter = {
        [NO_EMAIL]({ ttl }) {
            // 未注册 提示发送邮件
            const { $tipBox, $btnSubmit } = this;
            if ($tipBox.is(':visible')) {
                // 重复发送提示 倒计时
                const endTimer = BindEmail.countdown((time) => {
                    $btnSubmit.prop('disabled', true);
                    this.setMsg(1, trans('login.link_email_resend', [time]));
                }, () => {
                    this.setMsg(1, trans('login.link_email_tips_unregistered'));
                    $btnSubmit.prop('disabled', false);
                }, ttl);
                this.timerList.push(endTimer);
            } else {
                // 首次点击
                $btnSubmit.attr('value', trans('login.resend_activation_email'));
                this.setMsg(1, trans('login.link_email_tips_unregistered'));
            }
        },
        [EMAIL_BIND]() {
            // 已绑定过 提示错误
            this.setMsg(2, trans('login.link_email_defeated'));
        },
        [EMAIL_REGISTERED]() {
            // 已注册 提示输入密码绑定
            const { $form, $btnSubmit } = this;
            this.setMsg(1, trans('login.link_email_tips_registered'));
            this.togglePassbox(1);
            $btnSubmit.attr('value', trans('login.button_sign_in'));
            $form.find('#bindEmail').prop('readonly', true);
            $form.find('#js-changeMailBox').show();
        },
    }
    validator() {
        // 第三方登陆绑定
        const { $form } = this;

        $form.validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                },
                passWord: {
                    required: true,
                },
                agree: {
                    required: true,
                },
                confirm: {
                    required: true,
                },
            },
            messages: {
                agree: {
                    required: trans('login.to_complete_the_registration')
                },
                confirm: {
                    required: trans('login.to_complete_the_registration_eu')
                }
            }
        });
    }

    // type 0不现实 1普通提示 2错误提示
    setMsg(type = 0, text = '') {
        const { $tipBox } = this;

        if (type === 0) {
            $tipBox.hide();
        } else {
            $tipBox[type === 1 ? 'removeClass' : 'addClass']('errTip').html(text).show();
        }
    }

    reset() {
        const { $form, $tipBox, $btnSubmit } = this;
        $tipBox.hide();
        $btnSubmit.attr('value', trans('login.link_email'));
        $form.find('#bindEmail').prop('readonly', false);
        $form.find('#js-changeMailBox').hide();
        this.togglePassbox();
    }
    togglePassbox(show = 0) {
        const { $form } = this;
        $form.find('#js-bindPassowrd')[show ? 'show' : 'hide']();
        $form.find('#bindPasswordInput')[show ? 'removeClass' : 'addClass']('ignore');
    }
    setData(data) {
        this.postData = data;
    }

    async eventSubmitPass() {
        const { $form, $btnSubmit } = this;
        const isToLogin = $form.find('#js-bindPassowrd').is(':visible');

        if ($btnSubmit.hasClass('loading')) {
            return;
        }
        Object.assign(this.postData, {
            timeZone: getTimezone(),
            email: $form.find('#bindEmail').val(),
        });
        if (isToLogin) {
            Object.assign(this.postData, {
                passWord: $form.find('#bindPasswordInput').val(),
            });
        }

        try {
            this.loading(1);
            let resData = null;
            if ('code' in this.postData) {
                resData = await serviceSocialBind.http({
                    params: this.postData,
                });
            } else {
                resData = await serviceSocialBind.http({
                    params: this.postData,
                });
            }
            if (resData.status === 0) {
                if (isToLogin) {
                    // 登陆成功
                    const { redirectUrl } = resData.data;
                    if (redirectUrl) {
                        window.location.href = redirectUrl;
                    }
                } else {
                    // 新邮箱 返回倒计时
                    this.codeAdapter[NO_EMAIL].call(this, resData.data);
                }
            } else {
                const { innerCode } = resData.data;
                const curCodeAdapter = this.codeAdapter[innerCode];
                if (curCodeAdapter) {
                    curCodeAdapter.call(this);
                } else {
                    // 直接提示错误
                    layer.msg(resData.msg);
                }
            }
        } finally {
            this.loading(0);
        }
    }

    loading(mailStatus = 1) {
        const { $btnSubmit } = this;
        $btnSubmit[mailStatus ? 'addClass' : 'removeClass']('loading');
    }

    bindEvent() {
        const { $form } = this;

        $form.find('#js-changeMailBtn').on('click', (e) => {
            e.preventDefault();
            this.reset();
        });

        $form.on('submit', (e) => {
            e.preventDefault();
            if ($form.valid()) {
                this.eventSubmitPass();
            }
        });
    }
}

const bindEmail = new BindEmail($('#js-bindEmail'));

function layerOpen(bindData) {
    // const html = await import('./bind_email.art');
    layer.open({
        // content: html(),
        content: $('.bindMailForm'),
        type: 1,
        offset: '200px',
        area: '550px',
        btn: 0,
        shadeClose: 0,
        closeBtn: 1,
        end: () => {
            bindEmail.timerList.forEach((timer) => {
                try {
                    timer();
                } catch (e) {
                    // nothing
                }
            });
            bindEmail.timerList = [];
            bindEmail.reset();
        },
    });
    if (bindData.email) {
        bindEmail.$form.find('#bindEmail').val(bindData.email);
        bindEmail.$form.find('#bindEmail').prop('readonly', 'readonly');
    }
    bindEmail.setData(bindData);
}

export default function (bindData) {
    layerOpen(bindData);
}
