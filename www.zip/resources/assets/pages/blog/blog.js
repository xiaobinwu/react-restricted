/**
 * @authors Your Name (you@example.org)
 * @date    2017-12-20 18:54:27
 * @version $Id$
 */
import 'js/bootstrap';
import PubSub from 'pubsub-js';
import { slickFn } from 'js/core/slickFn.js';
import $ from 'jquery';
import { serviceGetHowtoData, serviceArticleLike } from 'js/service/blog';
import { getUserStatus } from 'js/core/user.js';
import { throttle } from 'js/utils/index.js';
import Masonry from 'masonry-layout';
import layer from 'layer';
// 多语言
import { trans } from 'js/core/translate.js';
import 'slick-carousel';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import Share from '../../component/share/share.js';
import './blog.css';

const { DOMAIN_LOGIN } = GLOBAL;

PubSub.subscribe('nativeReady', () => {
    // 首页slickbanner
    slickFn({
        container: '.js-slickBanner',
        dots: true,
        autoplay: true,
        autoplaySpeed: 3000,
        lazyLoad: 'progressive',
        draggable: false,
        prevArrow: $('.blogBanner_slickPre'),
        nextArrow: $('.blogBanner_slickNext'),
    });
    // 显示用户登录信息
    (async () => {
        const data = await getUserStatus({ update: 1, toLogin: 0 });
        if (data.isLogin) {
            $('.js-noLogined').hide();
            $('.js-logined').show().find('.js-accoutName').text(`${data.user.userName || data.user.email}`);
        }
    })();

    // 下载附件
    $('.js-download').on('click', async (e) => {
        const data = await getUserStatus({ update: 1, toLogin: 0 });
        if (!data.isLogin) {
            window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm?type=1&ref=${window.location.href}`;
        } else {
            const href = $(e.target).data('href');
            const fileName = $(e.target).data('file');
            const link = document.createElement('a');
            const $document = document.documentElement || document.body;
            link.href = href;
            link.download = fileName;
            link.style.display = 'none';
            link.target = 'special';
            $document.appendChild(link);
            link.click();
            $document.removeChild(link);
        }
    });

    // 头部快捷操作
    $('.js-liveChatSwitch li').on('mouseover', (e) => {
        const $liveCon = $('.js-liveChatBox');
        const index = $(e.target).parents('li').index();
        $liveCon.find('.liveChat_contentItem').eq(index).show().siblings()
            .hide();
        $(e.target).parents('li').find('.liveChat_item').addClass('active');
        $(e.target).parents('li').siblings().find('.liveChat_item')
            .removeClass('active');
    });

    // 滚动页面固定头部导航
    const navOffsetTop = $('.blogMainNav').offset().top;
    const $share = $('.leftSharePanel');
    const $changeBtn = $('.js-toggleShow');
    // 左侧分型栏显示
    $share.addClass('show');
    $changeBtn.on('click', (e) => {
        $(e.target).toggleClass('change');
        $share.toggleClass('show');
    });
    PubSub.subscribe('nativeScroll', () => {
        const pageScrollTop = $(window).scrollTop();
        if (pageScrollTop - navOffsetTop > 0) {
            $('.blogMainNav').addClass('blogMainNav-fixed');
        } else {
            $('.blogMainNav').removeClass('blogMainNav-fixed');
        }

        // 页面滚动一定距离显示回到顶部按钮
        if (pageScrollTop > 300) {
            $('.asidePanel').css({
                opacity: 1,
                visibility: 'visible',
            });
        } else {
            $('.asidePanel').css({
                opacity: 0,
                visibility: 'hidden',
            });
        }
    });

    // 展示搜索框
    $('.js-toggleSearch').on('click', (e) => {
        if ($(e.target).hasClass('icon-search')) {
            $(e.target).parent('.js-toggleSearch').addClass('opne_search');
        } else {
            $(e.target).toggleClass('opne_search');
        }
        $('.blogSearch').slideDown();
    });

    $('.js-closeSearch').on('click', () => {
        $('.blogSearch').slideUp();
        $('.js-toggleSearch').removeClass('opne_search');
    });


    // daily deals 轮播
    $('.js-dailySlick').on('init', (e, slick) => {
        $('.dailyDeals_page').html(`<span>${slick.currentSlide + 1}</span> / <span>${slick.slideCount}</span>`);
    });
    slickFn({
        container: '.js-dailySlick',
        autoplay: true,
        autoplaySpeed: 3000,
        lazyLoad: 'progressive',
        draggable: false,
        prevArrow: $('.daily_slickPre'),
        nextArrow: $('.daily_slickNext'),
    }).on('afterChange', (e, slick) => {
        $('.dailyDeals_page').html(`<span>${slick.currentSlide + 1}</span> / <span>${slick.slideCount}</span>`);
    });

    // how to 切换 内容是异步加载
    async function renderHoto($this, nextPage) {
        const $targetRenderDom = $('.howtoCon_list');
        let id = parseInt($this.attr('data-id'), 10) || 0;
        const resultTemp = await import('./common/howto');
        let msnry = null;
        let currentPage = 0;
        let pageInex = 1;

        if (serviceGetHowtoData.cancel) {
            serviceGetHowtoData.cancel();
        }
        let resultData = await serviceGetHowtoData.http({
            params: {
                cat_id: id,
                page: nextPage,
            },
        });
        $targetRenderDom.html(resultTemp({ data: resultData.data }));
        const elem = document.querySelector('.howtoCon_list');
        if (resultData.data.length) {
            $(elem.querySelectorAll('img')).on('load', () => {
                msnry = new Masonry(elem, {
                    itemSelector: '.howtoCon_item',
                    columnWidth: '.howtoCon_item',
                    gutter: 10,
                });
                setTimeout(() => {
                    msnry.layout();
                }, 1000);
            });
        } else {
            elem.innerHTML = `<li style = "text-align:center;height:500px; line-height:500px;">${trans('blog.no_more_products')}</li>`;
        }
        $('.loading_marke').hide();

        // 翻页
        $('.js-nextPageBtn').off('click').on('click', () => {
            id = parseInt($('.howtoTab_item-active').attr('data-id'), 10);
            currentPage = $('.js-nextPage').val();
            async function add() {
                resultData = await serviceGetHowtoData.http({
                    params: {
                        cat_id: id,
                        page: currentPage,
                    },
                });
                const html = resultTemp({ data: resultData.data });
                const fragment = document.createDocumentFragment();
                const elements = [];
                $(html).each((index, el) => {
                    fragment.appendChild($(el)[0]);
                    elements.push($(el)[0]);
                });
                $targetRenderDom[0].appendChild(fragment);
                msnry.appended(elements);
                msnry.layout();
            }
            add();
            pageInex += 1;
            $('.js-nextPage').val(pageInex);
        });
    }
    $('.howtoTab_item').on('click', (e) => {
        const $this = $(e.target).parent('.howtoTab_item');
        $this.addClass('howtoTab_item-active').siblings().removeClass('howtoTab_item-active');
        $('.howtoCon_list').html('');
        $('.loading_marke').show();
        $('.js-nextPage').val(1);
        renderHoto($this, 0);
    });
    $('.howtoTab_item').eq(0).trigger('click');

    // 文章点赞
    let isCanClick = true;
    $('.js-like').on('click', (e) => {
        const $self = $(e.target).parent('.js-like');
        const articlid = $self.attr('data-articleid');
        const $icon = $self.find('.icon-collection');
        const $num = $self.find('.num');
        let num = parseInt($num.text(), 10);
        // 用户不能重复点赞
        if (serviceGetHowtoData.cancel) {
            serviceGetHowtoData.cancel();
        }
        if (isCanClick) {
            serviceArticleLike.http({
                errorPop: false,
                params: {
                    id: articlid,
                },
            }).then((resultData) => {
                if (resultData.status === 0) {
                    num += 1;
                    $num.text(num);
                    $icon.addClass('addIcon');
                    layer.msg(resultData.msg);
                } else if (resultData.status === 1) {
                    window.location.href = `${DOMAIN_LOGIN}/m-users-a-sign.htm?type=1&ref=${window.location.href}`;
                } else if (resultData.status === 2) {
                    layer.msg(resultData.msg);
                    isCanClick = false;
                    $icon.addClass('unClick');
                }
            });
        }
    });

    // 过滤掉特殊符号
    const stripscript = (str) => {
        // const pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]");
        // let result = '';
        // for (let i = 0; i < str.length; i += 1) {
        //     result += str.substr(i, 1).replace(pattern, '');
        // }

        // 不用去除搜索关键字特殊字符，用编码传输即可 2018-08-10 17:12:16
        const str1 = encodeURIComponent(str);
        return str1;
    };
    // 文章搜索
    $('#js-blogSeachButton').on('click', (e) => {
        const { DOMAIN_MAIN } = window.GLOBAL;
        window.location.href = `${DOMAIN_MAIN}/blog/search/${stripscript($(e.currentTarget).prev('.js-blogSeachInput').val())}/1.html`;
    });
    // 文章搜索时按下enter键也可以搜索
    $('#blogSearch_input').on('keydown', (e) => {
        if (e.keyCode === 13) {
            const { DOMAIN_MAIN } = window.GLOBAL;
            window.location.href = `${DOMAIN_MAIN}/blog/search/${stripscript($(e.target).val())}/1.html`;
        }
    });

    // 滚动时让右侧导航Related Products模块固定
    if ($('.js-relatePro').length) {
        const relateProTop = $('.js-relatePro').offset().top;
        const headerHeight = $('.blogHeader').height();
        const relatePanelH = $('.relatePanel').height();
        const winHeight = Number(window.innerHeight);
        const scrollShow = () => {
            const scrollTop = Number($(window).scrollTop());
            if (relateProTop - headerHeight - scrollTop < 0 && scrollTop + winHeight < $('.blogFooter').offset().top) {
                $('.relatePanel').height(relatePanelH);
                $('.js-relatePro').addClass('relatePro-fixed');
            } else {
                $('.js-relatePro').removeClass('relatePro-fixed');
            }
        };

        PubSub.subscribe('nativeScroll', throttle(scrollShow, 300));
    }

    class BlogShare extends Share {}
    // 分享
    const shareObj = new BlogShare();
    shareObj.facebook({
        appId: 900125666754558,
        selector: '.js-fb',
    });
    shareObj.twitter({
        selector: '.js-tw',
        url: window.location.href,
    });

    shareObj.google({
        selector: '.js-gp',
        url: window.location.href,
        title: trans('blog.google_share_text'),
    });

    shareObj.pinterest({
        selector: '.js-pt',
    });

    // 点击回到页面顶部
    $('.js-backTop').on('click', () => {
        $('body, html').animate({
            scrollTop: 0,
        }, 200);
    });
});
