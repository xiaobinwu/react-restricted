import 'js/bootstrap';
import './search.css';
import '../component/aside/search_left.js';

const searchPageChageModule = {
    searchSortItemBox: $('.js-SortItemBox'),
    init() {
        this.listSortNodeControl();
    },
    listSortNodeControl() {
        const taht = this;
        taht.searchSortItemBox.on('click', 'a', function() { // eslint-disable-line
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
            }
        });
    },
};

searchPageChageModule.init();
