import 'js/bootstrap';
import $ from 'jquery';
import GoodsItem from 'component/goods_item/goods_item.js';
import './search_recom.css';

/* 初始化橱窗 */
GoodsItem.init({
    container: $('.cateMain_listModel'),
});

const recomPageChageModule = {
    recSearchItemBox: $('.js-SortItemBox'),
    init() {
        this.recSearchNodeControl();
        this.goodsDepoistControl();
    },
    recSearchNodeControl() {
        const taht = this;
        taht.recSearchItemBox.on('click', 'a', (e) => {
            const thatSef = $(e.currentTarget);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
            }
        });
    },
    goodsDepoistControl() {
        try {
            const nowTime = Math.floor((new Date()).getTime() / 1000);
            $('.js-depositExpired').each((index, item) => {
                const tahtSef = $(item);
                const startTime = tahtSef.data('start-time');
                const endTime = tahtSef.data('end-time');
                if (nowTime - startTime > 0 && endTime - nowTime > 0) {
                    tahtSef.addClass('on');
                }
            });
        } catch (error) {
            // error...
        }
    },
};

recomPageChageModule.init();
