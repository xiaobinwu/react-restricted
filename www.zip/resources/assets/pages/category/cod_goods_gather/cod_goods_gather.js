import 'js/bootstrap';
import layer from 'layer';
import { serviceCollectAdd, serviceGoodlistCollectRemove } from 'js/service/common';
import GoodsItem from 'component/goods_item/goods_item.js';
import './cod_goods_gather.css';
import '../component/paging/paging.js';
import '../component/brandUp_aside/brandUp_aside';

/* 初始化公共橱窗组件 */
GoodsItem.init({
    container: $('.cateMainWarp_goodsItem'),
});

const codGoodsPage = {
    clearCateMenu: $('.js-clearCateMenu'),
    clearCatNavBtn: $('.js-clearCatNavMore'),
    clearCateItemBox: $('.js-cateMainWarp_catNav'),
    clearOrderNav: $('.js-clearOrderNav'),
    allCategory: $('.js-allCategory'),
    init() {
        this.clearCateMoreControl();
        this.clearOrderColumnBox();
        this.selectAllCategories();
        this.exploreToggleControl();
    },
    clearCateMoreControl() {
        const that = this;
        that.clearCatNavBtn.on('click', () => {
            that.clearCateItemBox.toggleClass('all');
            that.clearCateMenu.toggleClass('down');
        });
    },
    clearOrderColumnBox() {
        const that = this;
        that.clearOrderNav.on('click', 'a', (e) => {
            const thatSef = $(e.currentTarget);
            if (!thatSef.hasClass('on')) {
                setTimeout(() => {
                    thatSef.addClass('on').siblings('a').removeClass('on');
                }, 500);
            }
        });
    },
    // pm说加一个allcategory按钮
    selectAllCategories() {
        const currentLocation = window.location.href;
        const catReg = /cat-id=(\w*)/ig;
        const matchArr = currentLocation.match(catReg);
        let hasCatId = false;
        // 处理高亮
        if (matchArr && matchArr.length) {
            hasCatId = true;
            const matchStr = matchArr[0].split('=')[1];
            if (matchStr === '' || matchStr === '0') {
                this.allCategory.parent('li').addClass('on');
            }
        } else {
            this.allCategory.parent('li').addClass('on');
        }
        this.allCategory.click(() => {
            const hasSearch = currentLocation.indexOf('?') > 0;
            let newCurrentLocation = '';
            if (hasCatId) {
                newCurrentLocation = currentLocation.replace(catReg, () => 'cat-id=0');
            }

            if (!hasCatId) {
                newCurrentLocation = hasSearch ? `${currentLocation}&cat-id=0` : `${currentLocation}?cat-id=0`;
            }
            newCurrentLocation = newCurrentLocation.replace(/odr=\w*/ig, '');
            window.location.href = newCurrentLocation;
        });
    },

    async exploreAddCollectControl(goodsCode, goodsWareCode, thatElem) {
        const res = await serviceCollectAdd.http({
            errorPop: false,
            data: {
                goods: [`${goodsCode}_${goodsWareCode}`],
            },
        });
        if (+res.status === 0) {
            const $likeIcon = thatElem.find('.sp-collect');
            if (!$likeIcon.hasClass('sp-collected')) {
                $likeIcon.addClass('sp-collected');
                thatElem.removeClass('cancelCollect');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
    },
    async exploreDeleteCollectControl(goodsCode, goodsWareCode, thatElem) {
        const res = await serviceGoodlistCollectRemove.http({
            errorPop: false,
            data: {
                goodSn: goodsCode,
                virCode: goodsWareCode,
            },
        });
        if (+res.status === 0) {
            const $likeIcon = thatElem.find('.sp-collect');
            if (!thatElem.hasClass('cancelCollect')) {
                thatElem.addClass('cancelCollect');
                $likeIcon.removeClass('sp-collected');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
    },

    exploreToggleControl() {
        const that = this;
        $('.js_dealsList').on('click', '.js-exploreCollection', function exploreCollectX() {
            const tahtSef = $(this);
            const dataSn = tahtSef.data('sku').toString();
            const dataWid = tahtSef.data('wid').toString();
            const $likeIcon = tahtSef.find('.sp-collect');
            if (!$likeIcon.hasClass('sp-collected')) {
                that.exploreAddCollectControl(dataSn, dataWid, tahtSef);
            } else {
                that.exploreDeleteCollectControl(dataSn, dataWid, tahtSef);
            }
        });
    },
};

codGoodsPage.init();
