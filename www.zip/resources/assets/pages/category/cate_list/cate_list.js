import 'js/bootstrap';
import $ from 'jquery';
import 'slick-carousel';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { STORAGE_LOGIN } from 'js/variables';
import { slickFn } from 'js/core/slickFn.js';
import lazyObserver from 'js/utils/lazyObserver';
import GoodsItem from 'component/goods_item/goods_item.js';
import searchTrack from 'js/track/define/search.js';
import './cate_list.css';
import '../component/paging/paging.js';
import '../component/aside/search_left.js';
import '../component/apparel/apparel_temp.js';
import '../component/view_history/view_history.js';
import '../component/search_feedback/search_feedback.js';
import '../component/searchCatefilter/searchCatefilter.js';
import '../component/brandUp_aside/brandUp_aside';


/* 搜索分类列表大数据埋点 */
searchTrack();

/* 初始化公共橱窗组件 */
GoodsItem.init({
    container: $('.cateMain_listModel'),
});

const catePageChageModule = {
    recItemBox: $('.js-recItemSlick'),
    recSearchItemBox: $('.js-SortItemBox'),
    recItemBtn: $('.cateMain_recItemNavInfo'),
    relatedItemBox: $('.js-relatedItemSlick'),
    relatedItemBtn: $('.cateMain_relatedItemNavInfo'),
    recentlyLoginBox: $('.js-recentlyLogin'),
    recentactiveBox: $('.js-activeCheckBox'),
    recentServerBox: $('.js-serverCheckBox'),

    init() {
        this.cateMainSlick();
        /* this.caterItemSlick(); */
        this.recentlyLoginControl();
        this.recSearchNodeControl();
        this.activeTagControl();
        this.labelSearchControl();
        this.goodsDepoistControl();
        this.cateSlickState(this.recItemBox, this.recItemBtn);
        this.cateSlickState(this.relatedItemBox, this.relatedItemBtn);
    },
    recSearchNodeControl() {
        const taht = this;
        taht.recSearchItemBox.on('click', 'a', function recSet() {
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                setTimeout(() => {
                    thatSef.addClass('on').siblings('a').removeClass('on');
                }, 500);
            }
        });
    },
    setWidth() {
        $(window).on('resize', () => {
            const winDoc = $('.cateMain_listModel');
            const searchWordBox = $('.cateMain_searchWordBox, .cateMain_searchTip, .cateMain_header-sort');
            if (winDoc) {
                const docWidth = winDoc.width() - 55;
                searchWordBox.css({
                    width: docWidth,
                });
            }
        }).trigger('resize');
    },
    cateMainSlick() {
        slickFn({
            container: '.js-cateMainSlick',
            lazyLoad: 'ondemand',
            speed: 300,
            autoplay: true,
            dots: true,
            fade: true,
            prevArrow: '.cateMain_pnBtn.prev',
            nextArrow: '.cateMain_pnBtn.next',
        });
    },
    caterItemSlick() {
        const that = this;
        // that.recItemBox.slick({
        slickFn({
            container: that.recItemBox,
            lazyLoad: 'ondemand',
            variableWidth: true,
            slidesToShow: 8,
            slidesToScroll: 8,
            prevArrow: $('.cateMain_recItemNavInfo').eq(0),
            nextArrow: $('.cateMain_recItemNavInfo').eq(1),
        });
    },
    cateSlickState($Wrap, $Btn) {
        if ($Wrap.length) {
            lazyObserver({
                callBack: (observerTarget) => {
                    const cateBtn = $Wrap.parent().next('div').find($Btn);
                    slickFn({
                        container: $Wrap,
                        lazyLoad: 'ondemand',
                        variableWidth: true,
                        slidesToShow: 8,
                        slidesToScroll: 8,
                        prevArrow: cateBtn.eq(0),
                        nextArrow: cateBtn.eq(1),
                        responsive: [
                            {
                                breakpoint: 1813,
                                settings: {
                                    slidesToShow: 7,
                                    slidesToScroll: 7,
                                },
                            },
                            {
                                breakpoint: 1653,
                                settings: {
                                    slidesToShow: 6,
                                    slidesToScroll: 6,
                                },
                            },
                            {
                                breakpoint: 1493,
                                settings: {
                                    slidesToShow: 5,
                                    slidesToScroll: 5,
                                },
                            },
                            {
                                breakpoint: 1333,
                                settings: {
                                    slidesToShow: 4,
                                    slidesToScroll: 4,
                                },
                            },
                        ],
                    });
                },
                observeDom: $Wrap,
            });
        }
    },
    recentlyLoginControl() {
        const that = this;
        const loginCookie = window.sessionStorage.getItem(STORAGE_LOGIN);

        if (loginCookie && loginCookie.length > 0) {
            that.recentlyLoginBox.hide();
        }
    },
    recGetUrlParam(name) {
        const reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`);
        const str = window.location.search.substr(1).match(reg);
        if (str != null) return decodeURI(str[2]);
        return null;
    },
    goodsDepoistControl() {
        try {
            const nowTime = Math.floor((new Date()).getTime() / 1000);
            $('.js-depositExpired').each((index, item) => {
                const tahtSef = $(item);
                const startTime = tahtSef.data('start-time');
                const endTime = tahtSef.data('end-time');
                if (nowTime - startTime > 0 && endTime - nowTime > 0) {
                    tahtSef.addClass('on');
                }
            });
        } catch (error) {
            // error...
        }
    },
    activeTagControl() {
        const that = this;
        that.recentactiveBox.on('click', function activeTag() {
            const thatSef = $(this);
            const dataLabelId = thatSef.data('node');
            const locationUrl = window.location.href;
            const indexOfString = locationUrl.indexOf('?') >= 0 ? '&' : '?';
            const isParamreplaceText = that.recGetUrlParam('tagValue');

            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('span').removeClass('on');
                const replaceText = locationUrl.indexOf('tagValue') >= 0 ? locationUrl
                    .replace(`tagValue=${isParamreplaceText}`, `tagValue=${dataLabelId}`) : `${locationUrl}${indexOfString}tagValue=${dataLabelId}`;
                const locationPathName = /\/([^/]*?)\/?$/.exec(new URL(replaceText).pathname)[1];
                const replacePathNameX = locationPathName.indexOf('.htm') >= 0 || locationPathName.indexOf('.html') >= 0 ? replaceText
                    .replace(locationPathName, '') : replaceText;
                window.location.href = replacePathNameX;
            } else {
                thatSef.removeClass('on');
                const replaceParam = locationUrl.indexOf('?tagValue=') >= 0 ? locationUrl
                    .replace(`?tagValue=${isParamreplaceText}`, '') : locationUrl.replace(`&tagValue=${isParamreplaceText}`, '');
                const locationPathNameX = locationUrl.indexOf('?tagValue=') >= 0 && replaceParam.indexOf('&') >= 0 ? replaceParam
                    .replace('&', '?') : replaceParam;
                window.location.href = locationPathNameX;
            }
        });
    },
    labelSearchControl() {
        const that = this;
        that.recentServerBox.on('click', (e) => {
            e.preventDefault();
            const thatSef = $(e.currentTarget);
            const dataLabelCode = thatSef.data('code');
            const locationPath = window.location.href;
            const indexOfString = locationPath.indexOf('?') >= 0 ? '&' : '?';
            const isParamreplaceVal = that.recGetUrlParam('serverMarkValues');
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('span').removeClass('on');
                const replaceTextVal = locationPath.indexOf('serverMarkValues') >= 0 ?
                    locationPath.replace(`serverMarkValues=${isParamreplaceVal}`, `serverMarkValues=${dataLabelCode}`)
                    : `${locationPath}${indexOfString}serverMarkValues=${dataLabelCode}`;
                const locationPathFormat = /\/([^/]*?)\/?$/.exec(new URL(replaceTextVal).pathname)[1];
                const replacePathFormatVal = locationPathFormat.indexOf('.htm') >= 0 || locationPathFormat
                    .indexOf('.html') >= 0 ? replaceTextVal.replace(locationPathFormat, '') : replaceTextVal;
                window.location.href = replacePathFormatVal;
            } else {
                thatSef.removeClass('on');
                const replaceParamt = locationPath.indexOf('?serverMarkValues=') >= 0 ? locationPath
                    .replace(`?serverMarkValues=${isParamreplaceVal}`, '') : locationPath.replace(`&serverMarkValues=${isParamreplaceVal}`, '');
                const locationPatX = locationPath.indexOf('?serverMarkValues=') >= 0 && replaceParamt.indexOf('&') >= 0 ? replaceParamt
                    .replace('&', '?') : replaceParamt;
                window.location.href = locationPatX;
            }
        });
    },
};

catePageChageModule.init();
