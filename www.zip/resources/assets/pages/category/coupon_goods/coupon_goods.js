
import 'js/bootstrap';
import layer from 'layer';
import GoodsItem from 'component/goods_item/goods_item.js';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import PubSub from 'pubsub-js';
import { getCurrency, multiply, toFixed, divide } from 'js/core/currency';
import { throttle } from 'js/utils/index.js';
import './coupon_goods.css';
import '../component/paging/paging.js';
import '../component/share_aside/share_aside.js';
import clearTemp from './template/clear_temp.art';

runtime.trans = trans;

/* 初始化公共橱窗组件 */
GoodsItem.init({
    container: $('.cateMainWarp_goodsItem'),
});

const couponPageChageModule = {
    couponCateMenu: $('.js-couponCateMenu'),
    couponCatNavBtn: $('.js-couponCatNavMore'),
    couponCateItemBox: $('.js-cateMainWarp_catNav'),
    couponSearchBtn: $('.js-couponSearchBtn'),
    couponMinPrice: $('.cateMainWarp_minPrice'),
    couponMaxPrice: $('.cateMainWarp_maxPrice'),
    couponOrderNav: $('.js-couponOrderNav'),
    couponTransUnit: $('.js-transformUnit'),
    couponEmptyBtn: $('.js-couponEmptyBtn'),
    coupon: $('.js-coupon'),
    couponOut: $('.js-couponOut'),
    window: $(window),

    init() {
        this.couponCateMoreControl();
        this.couponCatePriceControl();
        // this.clearCheckBoxState();
        this.couponUnitPrice();
        this.couponOrderColumnBox();
        this.transformControl();
        this.couponBottom();
        this.couponEmptyPrice();
    },
    async transformControl() {
        const that = this;
        PubSub.subscribe('sysUpdateCurrency', async () => {
            const { currencySign, currencyRate } = await getCurrency();
            that.couponTransUnit.text(currencySign);
            if (that.couponMinPrice.data('range')) {
                that.couponMinPrice.val(toFixed(multiply(that.couponMinPrice.data('range'), currencyRate), 2));
            }
            if (that.couponMaxPrice.data('range')) {
                that.couponMaxPrice.val(toFixed(multiply(that.couponMaxPrice.data('range'), currencyRate), 2));
            }
        });
    },
    async couponUnitPrice() {
        const { currencySign, currencyRate } = await getCurrency();
        if (this.couponTransUnit.text() === '') {
            this.couponTransUnit.text(currencySign);
            if (this.couponMinPrice.data('range')) {
                this.couponMinPrice.val(toFixed(multiply(this.couponMinPrice.data('range'), currencyRate), 2));
            }
            if (this.couponMaxPrice.data('range')) {
                this.couponMaxPrice.val(toFixed(multiply(this.couponMaxPrice.data('range'), currencyRate), 2));
            }
        }
    },
    couponCateMoreControl() {
        const that = this;
        that.couponCatNavBtn.on('click', () => {
            that.couponCateItemBox.toggleClass('all');
            that.couponCateMenu.toggleClass('down');
        });
    },
    couponEmptyPrice() {
        const that = this;
        this.couponEmptyBtn.on('click', (e) => {
            that.couponMinPrice.val('');
            that.couponMaxPrice.val('');
            const currentUrl = window.location.href;
            const reg = /(price-area=)(([0-9]+\.?[0-9]*)_([0-9]+\.?[0-9]*))?/;
            const currentNewUrl = currentUrl.replace(reg, ($0, $1, $2) => 'price-area=');
            window.location.href = currentNewUrl;
        });
    },
    couponOrderColumnBox() {
        const that = this;
        that.couponOrderNav.on('click', '.js-couponSort', (e) => {
            const thatSef = $(e.currentTarget);
            if (!thatSef.hasClass('on')) {
                setTimeout(() => {
                    thatSef.addClass('on').siblings('a').removeClass('on');
                }, 500);
            }
        });
    },
    couponCatePriceControl() {
        const that = this;
        that.couponSearchBtn.on('click', async () => {
            const { currencyRate } = await getCurrency();
            const minValNum = Number(that.couponMinPrice.val());
            const maxValNum = Number(that.couponMaxPrice.val());
            if (Number.isNaN(minValNum) || Number.isNaN(maxValNum)) {
                return layer.msg(trans('goodslist.coupon_valild_price_range'));
            }
            const minPriceVal = Number(toFixed(divide(minValNum, currencyRate), 2));
            const maxPriceVal = Number(toFixed(divide(maxValNum, currencyRate), 2));
            if (minPriceVal >= 0 && maxPriceVal >= 0 && minPriceVal <= maxPriceVal) {
                const reg = /(price-area=)(([0-9]+\.?[0-9]*)_([0-9]+\.?[0-9]*))?/;
                const currentUrl = window.location.href;
                if (reg.test(currentUrl)) {
                    let currentNewUrl;
                    if (!this.couponMinPrice.val() && !this.couponMaxPrice.val()) {
                        currentNewUrl = currentUrl.replace(reg, ($0, $1, $2) => 'price-area=');
                    } else {
                        currentNewUrl = currentUrl.replace(reg, ($0, $1, $2) => `price-area=${minPriceVal}_${maxPriceVal}`);
                    }
                    window.location.href = currentNewUrl;
                } else {
                    window.location.href = `${currentUrl}&price-area=${minPriceVal}_${maxPriceVal}`;
                }
            } else {
                layer.open({
                    content: clearTemp(),
                    area: ['auto', 'auto'],
                    btn: false,
                    closeBtn: 1,
                });
            }
            return true;
        });
    },
    couponBottom() {
        this.window.scroll(throttle(() => {
            const couponOutOffsetTop = this.couponOut.offset().top;
            const couponOutHeight = this.couponOut.height();
            const windowScrollTop = this.window.scrollTop();
            const sperateScrollDistance = couponOutOffsetTop - (this.window.height() - couponOutHeight);
            if (windowScrollTop >= sperateScrollDistance) {
                this.coupon.css('position', 'static');
            } else {
                this.coupon.css('position', 'fixed');
            }
        }, 50));
    }
};

couponPageChageModule.init();
