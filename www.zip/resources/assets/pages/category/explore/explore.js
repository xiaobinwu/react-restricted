import 'js/bootstrap';
import $ from 'jquery';
import PubSub from 'pubsub-js';
import layer from 'layer';
import exploreTrack from 'js/track/define/explores.js';
import { serviceExploreData } from 'js/service/promotion';
import { serviceCollectAdd, serviceGoodlistCollectRemove } from 'js/service/common';
import { trans } from 'js/core/translate.js';
import { STORAGE_EXPLORE_NODE_DATA_ID, STORAGE_EXPLORE_NODE } from 'js/variables';
import { asyncPrice } from 'js/core/asyncPrice';
import '../component/brandUp_aside/brandUp_aside';
import './explore.css';

/* explore页数据曝光埋点 */
exploreTrack();

const explorePageChageModule = {
    isLoad: true,
    exploreUrl: $('.js-exploreUrl'),
    exploreCool: $('.js-exploreCool'),
    exploreSelectBox: $('.js-exploreSelectBox'),
    exploreMainBox: $('.cateMainWarp_exploreBox'),
    exploreWrap: $('.js-exploreBox'),
    explorePagex: $('.js-pageLoading'),
    exploreClearBtn: $('.js_exploreClearBtn'),
    exploreNextPage: $('.js-exploreNextPage'),
    exploreSortName: $('.js-exploreSortName'),
    exploreCollect: $('.js-exploreCollection'),

    init() {
        this.exploreRandArrayElement();
        this.exploreCateState();
        this.exploreSortNode();
        this.exploreViewedState();
        this.exploreVieweDelete();
        this.exploreScrollCallBack();
        this.exploreAddCartControl();
        // this.exploreShowOpen();
        this.exploreToggleControl();
    },
    exploreRandomArrayElement() {
        Array.prototype.indexOf = (val) => { // eslint-disable-line
            for (let i = 0; i < this.length; i += 1) {
                if (this[i] === val) return i;
            }
            return -1;
        };
        Array.prototype.remove = (val) => { // eslint-disable-line
            const index = this.indexOf(val);
            if (index > -1) {
                return this.splice(index, 1);
            }
        };
        const exploreArr = ['hot', 'recommend', 'trending'];
        const rand = Math.floor(Math.random() * 2);
        const tmp = exploreArr[rand];
        exploreArr.remove(tmp);
        exploreArr.push(tmp);
        return tmp;
    },
    exploreRandArrayElement() {
        const exploreArr = ['hot', 'recommend', 'trending'];
        const index = Math.floor((Math.random() * exploreArr.length));
        const tmp = exploreArr[index];
        return tmp;
    },
    exploreBlockState(hide) {
        const taht = this;
        switch (hide) {
        case 'hide':
            taht.exploreWrap.hide();
            break;
        case 'show':
            taht.exploreWrap.show();
            break;
        default:
            taht.exploreWrap.hide();
        }
    },
    exploreDelRepeat() {
        Array.prototype.delRepeat = (e) => { // eslint-disable-line
            this.sort();
            const n = [this[0]];
            for (let i = 1; i < this.length; i += 1) {
                if (this[i] !== n[n.length - 1]) {
                    n.push(this[i]);
                }
            }
            return n;
        };
    },
    exploreCollectControl() {
        return false;

        // const dataColle = [];
        // const itemColleWrap = $('.js-exploreCollection');
        // const itemlikeOpre = $('.cateMainWarp_exploreOpe');
        // if (itemColleWrap && itemColleWrap.length > 0) {
        //     itemColleWrap.each((index, item) => {
        //         const tahtSef = $(item);
        //         dataColle.push(tahtSef.data('collect-code'));
        //     });
        //     try {
        //         if (dataColle && dataColle.length > 0) {
        //             const res = await serviceCollectStatus.http({
        //                 errorPop: false,
        //                 isCancel: false,
        //                 params: {
        //                     goodsSnlist: dataColle.join(','),
        //                 },
        //             });
        //             if (+res.status === 0) {
        //                 if (res.data && res.data.length > 0) {
        //                     res.data.forEach((item, index) => {
        //                         const itemIndex = res.data[index];
        //                         const renderItemX = itemlikeOpre.find(`a[data-collect-id="${itemIndex.goodSn}"]`);
        //                         renderItemX.attr({
        //                             'data-favid': `${itemIndex.id}`,
        //                             'data-vircode': `${itemIndex.virCode}`,
        //                             'data-colle-num': `${itemIndex.skuNum}`,
        //                         });
        //                         if (itemIndex.fav === true) {
        //                             if (!renderItemX.hasClass('collected')) {
        //                                 renderItemX.addClass('collected');
        //                             }
        //                         }
        //                     });
        //                 }
        //             }
        //         }
        //     } catch (error) {
        //         console.log(error);
        //     }
        // }
    },
    async exploreShowPage(exploreCurNextPagex, explorOrderStr) {
        const that = this;
        const exploreNode = that.exploreUrl.val();
        const exploreNextPageX = that.exploreNextPage.attr('data-lastpage'); // eslint-disable-line
        const exploreCurNextPage = that.exploreNextPage.attr('data-nextpage'); // eslint-disable-line
        // const explorOrderStr = that.exploreSortName.val();
        that.exploreNextPage.attr('data-lastpage', 0);
        // that.exploreBlockState('hide');
        // that.explorePagex.show();
        that.isLoad = false;
        const data = await serviceExploreData.http({
            loading: true,
            params: {
                exploreCate: exploreNode,
                exploreOrd: explorOrderStr,
                explorePage: exploreCurNextPagex,
            },
        });
        if (+data.status === 0) {
            let exploreNextPageNum = +that.exploreNextPage.attr('data-nextpage');
            that.isLoad = true;
            that.exploreNextPage.attr('data-lastpage', 1);
            that.exploreNextPage.attr('data-nextpage', exploreNextPageNum += 1);
            if (data.data && data.data.length > 0) {
                const temp = await import('./template/explore_item.art');
                that.exploreWrap.append(temp(data));
                that.exploreBlockState('show');
                that.explorePagex.hide();
                that.exploreCollectControl();

                // 接口有cache，要调实时价
                asyncPrice({
                    callback() {
                        PubSub.publish('sysUpdateCurrency', {
                            context: that.exploreWrap[0],
                        });
                    }
                });
            }
        } else {
            // layer.msg(data.msg);
            that.explorePagex.hide();
            that.exploreNextPage.attr('data-lastpage', 0);
        }
    },
    exploreScrollCallBack() {
        const that = this;
        const exploreDoc = $(document);
        const exploreWindow = $(window);
        const exploreNextPagex = that.exploreNextPage.attr('data-lastpage');
        exploreWindow.on('scroll', () => {
            const exploreTranX = that.exploreUrl.val();
            if ((exploreDoc.scrollTop() + exploreWindow.height() > exploreDoc.height() - $('.siteFooter').height() - 10) && this.isLoad) {
                if (exploreNextPagex !== '0' && exploreTranX !== 'viewed') {
                    const explorOrderStr = that.exploreSortName.val();
                    const exploreCurNextPage = that.exploreNextPage.attr('data-nextpage');
                    that.exploreShowPage(exploreCurNextPage, explorOrderStr);
                }
            }
        });
    },
    exploreViewedState() {
        const that = this;
        that.exploreWrap.on('click', 'li', function exploreViewed() {
            const thatSef = $(this);
            const exploreVieweArray = []; // eslint-disable-line
            const exploreNodeDataId = window.localStorage.getItem(STORAGE_EXPLORE_NODE_DATA_ID);
            const exploreOldDataId = exploreNodeDataId ? exploreNodeDataId.split('_') : [];
            const exploreGoodsId = thatSef.data('id').toString();

            for (let i = 0; i < exploreOldDataId.length; i += 1) {
                if (exploreGoodsId === exploreOldDataId[i]) {
                    exploreOldDataId.splice(i, 1);
                }
            }
            exploreOldDataId.unshift(exploreGoodsId);
            window.localStorage.setItem(STORAGE_EXPLORE_NODE_DATA_ID, exploreOldDataId.join('_'));
        });
    },
    exploreCateState() {
        const taht = this;
        taht.exploreSelectBox.on('click', 'li', async function exploreState() {
            const thatSef = $(this);
            const exploreNode = thatSef.attr('data-node');
            const exploreStorage = thatSef.attr('data-node') ? thatSef.attr('data-node') : ''; // eslint-disable-line
            const exploreNodeStr = window.localStorage.setItem(STORAGE_EXPLORE_NODE, exploreStorage); // eslint-disable-line
            const exploreNodeItem = window.localStorage.getItem(STORAGE_EXPLORE_NODE_DATA_ID);
            const exploreFirstNode = [];
            const exploreVieweItem = (exploreNodeItem && exploreNodeItem.length) ? exploreNodeItem.split('_') : null;
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('li').removeClass('on');
                if (exploreNode !== 'all') {
                    $('.exploreSelectAll').removeClass('on');
                } else {
                    $('.exploreSelectOther').find('li').removeClass('on');
                }
                taht.exploreUrl.val(exploreNode);
                taht.exploreBlockState('hide');
                taht.exploreNextPage.attr('data-nextpage', 2);
                // taht.explorePagex.show();

                if (exploreNode === 'viewed') {
                    if (exploreVieweItem && exploreVieweItem.length > 0) {
                        for (let i = 0; i < exploreVieweItem.length; i += 1) {
                            if (i < 50) {
                                exploreFirstNode.push(exploreVieweItem[i]);
                            } else {
                                taht.exploreMainBox.html(`${trans('goodslist.no_more_product_tip')}`);
                            }
                        }
                        const exploreVieweItems = `${exploreFirstNode.join(',')}`;
                        const data = await serviceExploreData.http({
                            loading: true,
                            params: {
                                exploreCate: exploreNode,
                                exploreItem: exploreVieweItems,
                            },
                        });
                        if (+data.status === 0) {
                            if (data.data && data.data.length > 0) {
                                const temp = await import('./template/explore_item.art');
                                taht.exploreWrap.html(temp(data));
                                taht.exploreBlockState('show');
                                taht.explorePagex.hide();
                                taht.exploreClearBtn.show();
                                taht.exploreCollectControl();

                                // 接口有cache，要调实时价
                                asyncPrice({
                                    callback() {
                                        PubSub.publish('sysUpdateCurrency', {
                                            context: taht.exploreWrap[0],
                                        });
                                    }
                                });
                            }
                        } else {
                            layer.msg(data.msg);
                        }
                    } else {
                        taht.exploreBlockState('show');
                        taht.explorePagex.hide();
                        taht.exploreWrap.html(`<font class="exploreWrap_tips">${trans('goodslist.no_more_product_tip')}</font>`);
                    }
                } else {
                    taht.exploreClearBtn.hide();
                    const exploreOoderStr = taht.exploreRandArrayElement();
                    // const exploreOoderVal = taht.exploreSortName.val(taht.exploreRandArrayElement());
                    const data = await serviceExploreData.http({
                        loading: true,
                        errorPop: false,
                        params: {
                            exploreCate: exploreNode,
                            exploreOrd: exploreOoderStr,
                            explorePage: '1',
                        },
                    });

                    if (+data.status === 0) {
                        if (data.data && data.data.length > 0) {
                            const temp = await import('./template/explore_item.art');
                            taht.exploreWrap.html(temp(data));
                            taht.exploreBlockState('show');
                            taht.explorePagex.hide();
                            taht.exploreCollectControl();

                            // 接口有cache，要调实时价
                            asyncPrice({
                                callback() {
                                    PubSub.publish('sysUpdateCurrency', {
                                        context: taht.exploreWrap[0],
                                    });
                                }
                            });
                        }
                    } else {
                        layer.msg(data.msg);
                    }
                }
            }
        });
    },
    exploreSortNode() {
        const that = this;
        const exploreMenu = $('.js-exploreSelectBox li');
        const exploreSort = window.localStorage.getItem(STORAGE_EXPLORE_NODE);
        if (exploreSort && exploreSort.length > 0) {
            for (let i = 0; i < exploreMenu.length; i += 1) {
                if (exploreMenu[i].getAttribute('data-node') === exploreSort) {
                    $(exploreMenu[i]).trigger('click');
                    break;
                }
            }
        } else {
            exploreMenu.filter(that.exploreCool).trigger('click');
        }
    },
    exploreVieweDelete() {
        const that = this;
        that.exploreClearBtn.on('click', () => {
            const exploreNodeMemory = window.localStorage.getItem(STORAGE_EXPLORE_NODE_DATA_ID);
            if (exploreNodeMemory && exploreNodeMemory.length > 0) {
                window.localStorage.removeItem(STORAGE_EXPLORE_NODE_DATA_ID);
                that.exploreClearBtn.hide();
                that.exploreWrap.html(`<font class="clear">${trans('goodslist.no_more_product_tip')}</font>`);
            }
        });
    },
    exploreShowOpen() {
        const that = this;
        that.exploreMainBox.on('mouseenter', 'li', function exploreOpera() {
            $(this).addClass('on');
        }).on('mouseleave', 'li', function exploreOpera() {
            $(this).removeClass('on');
        });
    },
    exploreAddCartControl() {
        const that = this;
        that.exploreWrap.on('click', '.js-exploreAddCart', function exploreAddCart() {
            const thatSef = $(this);
            const exploreGoodsId = thatSef.attr('data-sku');
            const exploreGoodsQty = thatSef.attr('data-num');
            const exploreGoodsWid = thatSef.attr('data-wid');
            const exploreGoodsImg = thatSef.attr('data-img');
            PubSub.publish('sysAddToCart', {
                goods: {
                    goodsSn: exploreGoodsId,
                    qty: exploreGoodsQty,
                    warehouseCode: exploreGoodsWid,
                },
                cartAni: {
                    imgSrc: exploreGoodsImg,
                    origin: thatSef,
                    // target: $('.js-relocate .icon-cart'),
                },
            });
        });
    },
    async exploreAddCollectControl(goodsCode, goodsWareCode, thatElem) {
        const res = await serviceCollectAdd.http({
            errorPop: false,
            data: {
                goods: [`${goodsCode}_${goodsWareCode}`],
            },
        });
        if (+res.status === 0) {
            const $likeIcon = thatElem.find('.sp-collect');
            if (!$likeIcon.hasClass('sp-collected')) {
                $likeIcon.addClass('sp-collected');
                thatElem.removeClass('cancelCollect');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
    },
    async exploreDeleteCollectControl(goodsCode, goodsWareCode, thatElem) {
        const res = await serviceGoodlistCollectRemove.http({
            errorPop: false,
            data: {
                goodSn: goodsCode,
                virCode: goodsWareCode,
            },
        });
        if (+res.status === 0) {
            const $likeIcon = thatElem.find('.sp-collect');
            if (!thatElem.hasClass('cancelCollect')) {
                thatElem.addClass('cancelCollect');
                $likeIcon.removeClass('sp-collected');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
    },
    exploreToggleControl() {
        const that = this;
        that.exploreWrap.on('click', '.js-exploreCollection', function exploreCollectX() {
            const tahtSef = $(this);
            const dataSn = tahtSef.data('sku').toString();
            const dataWid = tahtSef.data('wid').toString();
            const $likeIcon = tahtSef.find('.sp-collect');
            if (!$likeIcon.hasClass('sp-collected')) {
                that.exploreAddCollectControl(dataSn, dataWid, tahtSef);
            } else {
                that.exploreDeleteCollectControl(dataSn, dataWid, tahtSef);
            }
        });
    },
};

explorePageChageModule.init();
