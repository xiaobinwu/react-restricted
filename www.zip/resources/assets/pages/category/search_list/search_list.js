import 'css/bootstrap';
import './search_list.css';
import '../component/aside/search_left.js';
