import 'js/bootstrap';
import $ from 'jquery';
import GoodsItem from 'component/goods_item/goods_item.js';
import presaleTrack from 'js/track/define/presales.js';
import Timer from 'component/timer/timer.js';
import { trans } from 'js/core/translate.js';
import { STORAGE_LOGIN } from 'js/variables';
import './presale.css';
import '../component/paging/paging.js';
import '../component/share_aside/share_aside.js';
import '../component/view_history/view_history.js';

/* 新品页数据曝光埋点 */
presaleTrack();

/* 初始化公共橱窗组件 */
GoodsItem.init({
    container: $('.cateMainWarp_newArrivalBox'),
});

const presalePageChageModule = {
    presaleCateBox: $('.js-newArrivalBox'),
    presaleBox: $('.js-cateArrivalBox'),
    presaleCateNavBtn: $('.js-cateNavMore'),
    recentlyLoginBox: $('.js-recentlyLogin'),

    init() {
        this.presaleCateMoreControl();
        this.presaleTimeCounteControl();
        this.recentlyLoginControl();
    },
    presaleCateMoreControl() {
        const that = this;
        that.presaleCateNavBtn.on('click', () => {
            that.presaleBox.toggleClass('all');
            that.presaleCateBox.toggleClass('down');
        });
    },
    presaleTimeCounteControl() {
        const timer = new Timer();
        timer.update('.js-goodsItemTime', {
            format: `${trans('goodslist.end_time')}: {dd}:{hh}:{mm}:{ss}`,
            interval: 'time',
        });
    },
    recentlyLoginControl() {
        const that = this;
        const loginData = window.sessionStorage.getItem(STORAGE_LOGIN);
        if (loginData && loginData.length > 0) {
            that.recentlyLoginBox.hide();
        }
    },
};

presalePageChageModule.init();
