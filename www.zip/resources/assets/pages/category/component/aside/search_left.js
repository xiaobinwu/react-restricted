import $ from 'jquery';
import PubSub from 'pubsub-js';
import { debounce } from 'js/utils/index.js';
import { trans } from 'js/core/translate.js';
import runtime from 'art-template/lib/runtime';
import './search_left.css';

// 状态缓存器
class StateCache {
    state;
    on(st, func) {
        if (this.state !== st) {
            func();
            this.state = st;
        }
    }
    init() {
        this.state = undefined;
    }
}

const $win = $(window);
const $ucenterWrap = $('.cateMainWarp');
const $ucenterNav = $('.cateMain_asideSeachWrap, .cateMain_asideWrap');

const searchPageChageModule = {
    asideBlockBox: $('.js_asideBlockViewMore'),
    asideViewMore: $('.js_asideViewMore'),
    asideCateSadeBar: $('#js_show_saderBar'),
    asideOperaBox: $('.cateMain_asideOpera'),
    asideCheckBox: $('.js-checkBox'),
    asidelimtColumnBox: $('.js-limtColumnBox'),

    init() {
        this.asideSlideChangeState();
        this.asideBlockViewMore();
        // this.asideFixedSidebar();
        this.setCateMainBoxHeiht();
        /* this.setCateMainHeaderPositin(); */
        this.setCateMainSidebar();
        this.asideCheckBoxState();
        this.asideItemColumnBox();
        // this.setCateMainAsideState();
        // this.initNav();
        this.setWidth();
    },
    initNav() {
        let limitTop;
        let limitBottom;
        let navHeight;

        // 一个状态缓存器对象（共享同一个状态变量）
        const stateCache = new StateCache();

        // 用来时刻更新某些值
        const update = () => {
            const wrapTop = $ucenterWrap.offset().top;
            const wrapHeight = $ucenterWrap.height();

            stateCache.init();
            navHeight = $ucenterNav.height();
            limitTop = wrapTop - 12;
            limitBottom = (wrapTop + wrapHeight) - navHeight - 12;
        };

        // update的节能模式
        const lazyUpdate = debounce(update, 1000, true);

        $win.scroll(() => {
            const scrTop = $win.scrollTop();

            lazyUpdate();

            if (scrTop <= limitTop) {
                stateCache.on('top', () => {
                    $ucenterNav.css({
                        position: 'absolute',
                        top: 12,
                        left: 0,
                    });
                });
            } else if (scrTop >= limitBottom) {
                stateCache.on('bottom', () => {
                    $ucenterNav.css({
                        position: 'absolute',
                        top: limitBottom - limitTop,
                        left: 0,
                    });
                });
            } else {
                stateCache.on('center', () => {
                    $ucenterNav.css({
                        position: 'fixed',
                        top: 12,
                        left: $ucenterWrap.offset().left,
                    });
                });
            }
        });

        PubSub.subscribe('domSizeChange', () => {
            update();
            $win.trigger('scroll');
        });
    },
    asideCheckBoxState() {
        const that = this;
        that.asideOperaBox.on('click', 'li', function checkBoxRect() {
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('li').removeClass('on');
            } else {
                thatSef.removeClass('on');
            }
        });
    },
    asideItemColumnBox() {
        const that = this;
        that.asidelimtColumnBox.on('click', 'li', function itemRect() {
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('li').removeClass('on');
            }
        });
    },
    asideSlideChangeState() {
        const that = this;
        const asideSeachItem = $('.cateMain_asideSeachItem');
        that.asideViewMore.on('click', function slideRect() {
            const thatSef = $(this);
            const seachText = $('.cateMain_asideSeachText');
            thatSef.parent(asideSeachItem).toggleClass('active');
            if (thatSef.prev('ul').find('li').length > 5) {
                if (thatSef.parent(asideSeachItem).hasClass('active')) {
                    thatSef.find(seachText).html(`${trans('goodslist.search_view_less')}`);
                    setTimeout(() => {
                        that.setCateMainBoxHeiht();
                    }, 500);
                } else {
                    setTimeout(() => {
                        that.setCateMainBoxHeiht();
                    }, 500);
                    thatSef.find(seachText).html(`${trans('goodslist.search_view_more')}`);
                }
            }
        });
    },
    asideBlockViewMore() {
        const that = this;
        const cateWrap = $('.cateMain_box');
        const asideWrap = $('.cateMain_asideWrap');
        const asideSeachBox = $('.cateMain_asideSearchBox');
        that.asideBlockBox.on('click', () => {
            asideSeachBox.toggleClass('open');
            setTimeout(() => {
                const cateWrapH = Number(cateWrap.height());
                const asideSeachH = Number(asideWrap.height());
                if (asideSeachBox.hasClass('open')) {
                    if (asideSeachH > cateWrapH) {
                        cateWrap.height(asideSeachH);
                    }
                } else {
                    cateWrap.height('auto');
                }
            }, 1000);
        });
    },
    asideFixedSidebar() {
        const asideParentBox = $('.cateMain_asideSeachWrap');
        const asideSidebar = $('.cateMain_asideSeachBox');
        if (asideSidebar && asideSidebar.length > 0) {
            $(window).scroll(function() { // eslint-disable-line
                const scrollHeight = $(window).scrollTop();
                if (scrollHeight >= 60) {
                    asideParentBox.addClass('fixed');
                } else {
                    asideParentBox.removeClass('fixed');
                }
            });
        }
    },
    /* 比较左右两栏高度，保持右边栏目不低于左栏 */
    setCateMainBoxHeiht() {
        const cateWrap = $('.cateMain_box');
        const asideWrap = $('.cateMain_asideWrap');
        if (asideWrap.height() > cateWrap.height()) {
            cateWrap.height(asideWrap.height());
        }
    },
    setCateMainHeaderPositin() {
        const cateWrap = $('.cateMain_box');
        const cateHeader = $('.cateMain_header');
        cateHeader.css({
            width: cateWrap.width(),
            left: cateWrap.css('marginLeft'),
        });
    },
    setWidth() {
        $(window).on('resize', () => {
            const winDoc = $('.cateMain_listModel');
            const searchWordBox = $('.cateMain_searchWordBox, .cateMain_searchTip, .cateMain_header-sort');
            if (winDoc) {
                const docWidth = winDoc.width() - 55;
                searchWordBox.css({
                    width: docWidth,
                });
            }
        }).trigger('resize');
    },
    setCateMainSidebar() {
        const that = this;
        const cateMainBox = $('.cateMain_box');
        const asideWrap = $('.cateMain_asideWrap');
        const cateMainBoxLeft = cateMainBox.offset().left;
        that.asideCateSadeBar.on('click', () => {
            if (!asideWrap.is(':hidden')) {
                asideWrap.addClass('z-index-out');
                cateMainBox.animate({ marginLeft: '120px' }, 200, () => {
                    that.asideCateSadeBar.addClass('on');
                    /* that.setCateMainHeaderPositin(); */
                    that.setWidth();
                    asideWrap.hide();
                    cateMainBox.height('auto').addClass('active');
                });
            } else {
                asideWrap.show();
                cateMainBox.animate({ marginLeft: cateMainBoxLeft }, 200, () => {
                    that.asideCateSadeBar.removeClass('on');
                    /* that.setCateMainHeaderPositin(); */
                    that.setWidth();
                    asideWrap.removeClass('z-index-out');
                    cateMainBox.removeClass('active');
                    // that.setCateMainBoxHeiht();
                });
            }
        });
    },
    setCateMainAsideState() {
        const asideFixedBox = $('.cateMain_asideWrap');
        if (asideFixedBox && asideFixedBox.length > 0) {
            $(window).scroll(function() { // eslint-disable-line
                const scrollHeight = $(window).scrollTop();
                if (scrollHeight >= 60) {
                    asideFixedBox.addClass('fixed');
                } else {
                    asideFixedBox.removeClass('fixed');
                }
            });
        }
    },
};

searchPageChageModule.init();

// 生成搜索词链接
runtime.createSearchLink = (keyword, catId) => {
    if (typeof keyword === 'undefined' || typeof catId === 'undefined') {
        return false;
    }
    const innerKeyword = keyword.toString().split(' ').join('-');
    return `/${innerKeyword}-_gear/c_${catId}/`;
};

// 从数组中随机随指定个数的元素
function getRandomFromArray(arr, count) {
    const shuffled = arr.slice(0);
    let i = arr.length;
    const min = i - count;
    let temp;
    let index;
    while (i-- > min) { // eslint-disable-line
        index = Math.floor((i + 1) * Math.random());
        temp = shuffled[index];
        shuffled[index] = shuffled[i];
        shuffled[i] = temp;
    }
    return shuffled.slice(min);
}

// P0需求 分类页热搜词，js动态插入，仅全球站 2018-09-29 17:42:36 luochongfei
const cateLeftHotWord = async () => {
    const $panelCateLeftHotWord = $('#js-panelCateLeftHotWord');
    const catId = $panelCateLeftHotWord.data('catid');
    const pipeline = $panelCateLeftHotWord.data('pipeline');
    const maxShowCount = 20;
    const searchResultLength = $('.js_seachResultList').find('.js-gbGoodsItem').length;

    // searchResultLength 判断是因为左侧内容较多，右侧结果list较少，左侧放置不下，强行放入影响用户体验
    if ($panelCateLeftHotWord.length && typeof catId !== 'undefined' && searchResultLength > 30) {
        try {
            const mock = await import(`./hotword_mock/${pipeline}.json`);
            const temp = await import('./searchHotWord.art');
            let list = mock[catId] || [];
            list = $.unique(list);
            if (list.length > maxShowCount) {
                list = getRandomFromArray(list, maxShowCount);
            }

            if (list && list.length) {
                $panelCateLeftHotWord.html(temp({
                    catId,
                    list
                }));
            }
        } catch (e) {
            console.log('ERROR:search_left.js => cateLeftHotWord', e);
        }
    }
};

PubSub.subscribe('nativeLoad', async () => {
    // 分类搜词
    cateLeftHotWord();
});
