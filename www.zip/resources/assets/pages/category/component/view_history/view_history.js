import lazyObserver from 'js/utils/lazyObserver';

lazyObserver({
    callBack: () => {
        import('modules/common/view_history/view_history.js');
    },
    observeDom: $('#js-goodsViewHistory')[0],
});
