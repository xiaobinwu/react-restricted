/*
 * name: goodsItem（全站商品列表页橱窗）
 * author: duanmin
 * date: 2017/12/26
 */
import 'js/bootstrap';
import PubSub from 'pubsub-js';
import swal from 'sweetalert2';
import runtime from 'art-template/lib/runtime';
import render from './goods_item.art';
import './goods_item.css';
// import Lang from 'Lang';

// 商品橱窗分类样式
runtime.skins = [
    'gbGoodsItem-type0', // 0-首页推荐版块
    'gbGoodsItem-type1', // 1-用户中心收藏页
    'gbGoodsItem-type2', // 2-分类页/搜索页
    'gbGoodsItem-type3', // 3-服装分类页
    'gbGoodsItem-type4', // 4-Deals频道页
    'gbGoodsItem-type5', // 5-0.99 Zone版块页
    'gbGoodsItem-type6', // 6-Clearance清仓页
    'gbGoodsItem-type7', // 7-new_arrival NEW频道页
];

runtime.GLOBAL = window.GLOBAL;

// 多语言配置
runtime.lang = {
    // off: Lang['off'],
    // Lang.off,
};

const GoodsItem = {
    /**
     * 初始化（调用入口）
     * @param  {Object} options.container 父容器
     * @param  {Number} options.type      类型
     * @param  {Array}  options.list      列表数据
     */
    init({
        container = $(document),
        type = 0,
        list = [],
    }) {
        // 模板渲染（用于异步获取）
        if (list && list.length > 0) {
            // 如果是土耳其渲染土耳其模板
            container.html(render({
                // warehouseId: 'fdafdid',
                type,
                list,
            }));
        }

        // 定义事件
        if (container.closest('.goodsItem-initialized').length === 0) {
            container.addClass('goodsItem-initialized');
            container.on('click', '.js-opera', (e) => {
                const $this = $(e.target);
                const opera = $this.data('opera');

                if (opera === 'addToCart') GoodsItem.addToCart($this); // 添加购物车
                else if (opera === 'collect') GoodsItem.collect(); // 添加收藏
                else if (opera === 'videoShow') GoodsItem.videoShow(); // 播放视频
                else if (opera === 'cancelCollect') GoodsItem.cancelCollect(); // 取消收藏
                else if (opera === 'toggleCollect') GoodsItem.toggleCollect(); // 切换收藏
            });
        }
    },

    /**
     * 添加购物车
     * @param {Object} $btn 操作按钮
     */
    addToCart($btn) {
        console.log($btn); // eslint-disable-line
        const goodsId = $btn.data('sku');
        const goodsQty = $btn.data('num');
        const goodsWid = $btn.data('wid');
        const goodsImg = $btn.data('img');
        PubSub.publish('sysAddToCart', {
            goods: {
                goodsSn: goodsId,
                qty: goodsQty,
                warehouseCode: goodsWid,
            },
            cartAni: {
                imgSrc: goodsImg,
                origin: $btn,
                target: $('.js-addCart'),
            },
        });
    },

    /**
     * 播放视频弹框
     * @param {Object} $btn 操作按钮
     */
    async cateSwalBoxControl(extendVideoCode) {
        const showVideoTemp = await import('./show_video.art');
        swal({
            html: showVideoTemp({ videoCode: extendVideoCode }),
            customClass: 'showVideoPop',
            padding: '12px 0 5px 0',
            width: 855,
            height: 460,
            background: '#fff',
            animation: true,
            showCloseButton: true,
            showConfirmButton: false,
            onOpen: () => {
                swal.showLoading();
                setTimeout(() => {
                    swal.disableLoading();
                }, 500);
            },
        });
    },

    /**
     * 播放视频
     * @param {Object} $btn 操作按钮
     */

    videoShow($btn) {
        const videoCodeItem = [];
        const videoCodex = $btn.data('video');
        const videoCodeStr = videoCodex.split(',');
        for (let i = 0; i < videoCodeStr.length; i += 1) {
            videoCodeItem.push(videoCodeStr[i]);
        }
        if (videoCodeItem && videoCodeItem.length >= 2) {
            const k = Math.floor((Math.random() * videoCodeItem.length));
            const videoCodeMore = videoCodeItem[k];
            GoodsItem.cateSwalBoxControl(videoCodeMore);
        } else {
            GoodsItem.cateSwalBoxControl(videoCodex);
        }
        console.log($btn); // eslint-disable-line
    },


    /**
     * 添加收藏
     * @param {Object} $btn 操作按钮
     */
    collect($btn) {
        console.log($btn);
        $btn.addClass('collected');
    },

    /**
     * 取消收藏
     * @param {Object} $btn 操作按钮
     */
    cancelCollect($btn) {
        console.log($btn);
        $btn.removeClass('collected');
    },

    /**
     * 切换收藏
     * @param {Object} $btn 操作按钮
     */
    toggleCollect($btn) {
        if ($btn.hasClass('collected')) {
            GoodsItem.cancelCollect($btn);
        } else {
            GoodsItem.collect($btn);
        }
    },
};

export default GoodsItem;
