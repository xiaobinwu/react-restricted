import 'js/bootstrap';
import $ from 'jquery';
import PubSub from 'pubsub-js';
import swal from 'sweetalert2';
import { serviceReviewHelpful, serviceCollectAdd, serviceCollectRemove } from 'js/service/common'; // eslint-disable-line
import Rating from 'component/rating/rating.js';
import './item.css';

const extendMethodControl = {
    addToCartBtn: $('.js-addToCart'),
    extendVideoBtn: $('.js-showVideo'),
    addFavoriteBtn: $('.js-addFavorite'),

    init() {
        this.cateAddToCart();
        this.cateExtendShowVideo();
        this.collectAddControl();
        this.cateSetRate();
        // this.cateAddFavoriteControl();
    },
    cateSetRate() {
        new Rating();
    },
    cateAddToCart() {
        const that = this;
        that.addToCartBtn.on('click', function () { // eslint-disable-line
            const thatSef = $(this);
            const goodsId = thatSef.attr('data-sku');
            const goodsQty = thatSef.attr('data-num');
            const goodsWid = thatSef.attr('data-wid');
            const goodsImg = thatSef.attr('data-img');

            PubSub.publish('sysAddToCart', {
                goods: {
                    goodsSn: goodsId,
                    qty: goodsQty,
                    warehouseCode: goodsWid,
                },
                cartAni: {
                    imgSrc: goodsImg,
                    origin: thatSef,
                    target: $('.js-addCart'),
                },
            });
        });
    },
    async cateSwalBoxControl(extendVideoCode) {
        const showVideoTemp = await import('./show_video.art');
        swal({
            html: showVideoTemp({ videoCode: extendVideoCode }),
            customClass: 'showVideoPop',
            padding: '12px 0 5px 0',
            width: 855,
            height: 460,
            background: '#fff',
            animation: true,
            showCloseButton: true,
            showConfirmButton: false,
            onOpen: () => {
                swal.showLoading();
                setTimeout(() => {
                    swal.disableLoading();
                }, 500);
            },
        });
    },
    cateExtendShowVideo() {
        const that = this;
        that.extendVideoBtn.on('click', function(event) { // eslint-disable-line
            const thatSef = $(this);
            const videoCodeItem = [];
            const videoCodex = thatSef.attr('data-video');
            const videoCodeStr = videoCodex.split(',');
            for (let i = 0; i < videoCodeStr.length; i += 1) {
                videoCodeItem.push(videoCodeStr[i]);
            }
            if (videoCodeItem && videoCodeItem.length >= 2) {
                const k = Math.floor((Math.random() * videoCodeItem.length));
                const videoCodeMore = videoCodeItem[k];
                that.cateSwalBoxControl(videoCodeMore);
            } else {
                that.cateSwalBoxControl(videoCodex);
            }
        });
    },
    collectAddControl() {
        const that = this;
        that.addFavoriteBtn.on('click', async function() { // eslint-disable-line
            const thatSef = $(this);
            const dataId = thatSef.attr('data-sku'); // eslint-disable-line
            const dataWid = thatSef.attr('data-wid'); // eslint-disable-line
            const collectBox = $('.js-collectionNum');
            const collectCount = $('.js-likeCount');
            const collectIco = $('.gbGoodsItem_likeIcon');
            const collectNum = thatSef.find(collectCount).text();
            let viewStrNum = parseInt(collectNum.replace(/\(/g, '').replace(/\)/g, '')); // eslint-disable-line

            const data = await serviceCollectAdd.http({
                method: 'POST',
                data: {
                    goodSn: dataId,
                    virCode: dataWid,
                },
            });
            if (data.status === 0) {
                if (thatSef.hasClass('collected')) {
                    thatSef.removeClass('collected');
                    thatSef.find(collectIco).addClass('animation');
                    thatSef.find(collectBox).show().addClass('add-animation').html('-1')
                        .hide(300);
                    viewStrNum -= 1;
                    thatSef.find(collectCount).text(`(${viewStrNum})`);
                } else {
                    thatSef.find(collectIco).addClass('animation');
                    thatSef.addClass('collected');
                    thatSef.find(collectBox).show().addClass('add-animation').html('+1')
                        .hide(300);
                    viewStrNum += 1;
                    thatSef.find(collectCount).text(`(${viewStrNum})`);
                }
                console.log('success');
            } else if (data.status === 2) {
                console.log(data.msg);
                // window.location.href = '/user/login' + window.location.href; // eslint-disable-line
                window.location.href = `${window.GLOBAL.DOMAIN_LOGIN}/user/login`;
            } else {
                console.log('fail');
            }
        });
    },
    cateAddFavoriteControl() {
        const that = this;
        that.addFavoriteBtn.on('click', async function() { // eslint-disable-line
            const thatSef = $(this);
            const dataId = thatSef.attr('data-sku');
            const dataWid = thatSef.attr('data-wid');
            const data = await serviceReviewHelpful.http({
                method: 'POST',
                data: {
                    goodsId: dataId,
                    wid: dataWid,
                },
            });
            if (data.status === 0) {
                console.log('success'); // eslint-disable-line
            } else if (data.status === 2) {
                swal({
                    text: data.msg,
                    timer: 3000,
                    showConfirmButton: false,
                });
                // window.location.href = '/user/login';
            } else {
                console.log('fail'); // eslint-disable-line
            }
        });
    },
};

extendMethodControl.init();
