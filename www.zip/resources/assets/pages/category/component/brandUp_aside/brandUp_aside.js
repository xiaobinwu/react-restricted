import PubSub from 'pubsub-js';
import Share from 'component/share/share.js';
import './brandUp_aside.css';

const asideApp = {
    shareTopBtn: $('.js-asideTop'),
    shareAsideBox: $('.js-shareAsideBox'),
    shareTitle: $('meta[name="shareTxt"]').attr('content'),
    shareText: $('meta[name="twitter:description"]').attr('content'),
    init() {
        this.setShareControl();
        this.setScrollTopControl();
        this.setShareAsideControl();
    },
    setShareControl() {
        const that = this;
        const asideShare = new Share();
        asideShare.facebook({
            appId: 900125666754558, // 361131840691772
            selector: '.js-btnShareFacebook',
            url: window.location.href,
        });
        asideShare.twitter({
            desc: that.shareText,
            url: window.location.href,
            selector: '.js-btnShareTwitter',
        });
    },
    setScrollTopControl() {
        const that = this;
        that.shareTopBtn.on('click', () => {
            $('html,body').animate({
                scrollTop: 0,
            }, 1000);
            return false;
        });
    },
    setShareAsideControl() {
        const that = this;
        if (typeof that.shareAsideBox !== typeof undefined && that.shareAsideBox !== false) {
            PubSub.subscribe('nativeScroll', () => {
                if ($(window).scrollTop() > 300) {
                    that.shareAsideBox.addClass('on');
                } else {
                    that.shareAsideBox.removeClass('on');
                }
            });
        }
    },
};

asideApp.init();
