import layer from 'layer';
import PubSub from 'pubsub-js';
import { getCurrency, divide, transform, toFixed } from 'js/core/currency.js';
import './searchCatefilter.css';


const searchCatefilter = {
    brandViewBtn: $('.js-brandViewBtn'),
    brandVieweBtn: $('.js-brandVieweBtn'),
    brandContentBox: $('.js-brandContentBox'),
    brandItemBox: $('.js-brandItemBox'),
    priceTextInput: $('.js-textInput'),
    priceSelectSubmit: $('.js-filterPrice'),
    filterInputMin: $('.js-filterPriceMin'),
    filterInputMax: $('.js-filterPriceMax'),
    filterSubmit: $('.js-filterSubmit'),
    filterLink: $('.js-filterLink'),
    filterLen: $('.js-filterLog'),
    filterClear: $('.js-asideClear'),
    filterClearBtn: $('.js-asideClearBtn'),

    init() {
        this.bindEvent();
        // this.clearBtnHandle();
        this.clearFilterControl();
    },
    bindEvent() {
        this.getState();

        // 品牌面板折叠
        this.brandViewBtn.on('click', (e) => {
            this.brandViewBtn.closest(this.brandContentBox).toggleClass('on');
        });

        this.brandVieweBtn.on('click', (e) => {
            if (this.brandContentBox.hasClass('on')) {
                this.brandContentBox.removeClass('on');
                window.sessionStorage.removeItem('gb_brandView');
            }
        });

        // 缓存品牌折叠状态
        this.brandItemBox.on('click', 'a', (e) => {
            const thatSef = $(e.currentTarget);
            const dataState = thatSef.data('select');

            if (dataState && dataState === 1) {
                window.sessionStorage.setItem('gb_brandView', true);
            } else {
                window.sessionStorage.removeItem('gb_brandView');
            }
        });

        // 价格筛选
        this.priceTextInput.on('focus', (e) => {
            this.priceSelectSubmit.addClass('active');
        });

        this.priceTextInput.on('keyup', (e) => {
            const reg = /^\d+\.?(\d{1,2})?$/;
            const thatSef = $(e.currentTarget);
            if (!reg.test(thatSef.val()) && thatSef.val() !== '') {
                thatSef.val(this.checkStr(thatSef.val()));
            }
        });

        // 删除筛选记录
        this.filterLen.on('click', 'a', (e) => {
            e.preventDefault();
            const thatSef = $(e.currentTarget);
            const dataLink = thatSef.data('url');

            if (!thatSef.hasClass('on')) thatSef.addClass('on').siblings('a').removeClass('on');
            else thatSef.removeClass('on');
            window.location.href = dataLink;
            setTimeout(() => {
                thatSef.remove();
            }, 1000);
        });

        // 提交筛选
        this.filterSubmit.on('click', (e) => {
            e.preventDefault();
            const min = this.filterInputMin.val().trim();
            const max = this.filterInputMax.val().trim();
            if (min === '' || max === '') {
                layer.msg('Sorry, please enter a valid price range!');
            } else {
                getCurrency().then(({ currencyRate }) => {
                    this.filterHandleControl(Number(toFixed(divide(min, currencyRate), 4)), Number(toFixed(divide(max, currencyRate), 4)));
                });
            }
        });

        // 点击其它区域收起面板
        PubSub.subscribe('nativeDocumentClick', (msg, e) => {
            const { target } = e;
            if (this.priceSelectSubmit.length > 0) {
                if (!$.contains(this.priceSelectSubmit[0], target)) {
                    this.priceSelectSubmit.removeClass('active');
                }
            }
        });
    },

    filterHandleControl(min, max) {
        // 获取Url参数并转换为对象
        const getpram = this.getQueryStringControl();

        // 将筛选后的值与原始url值对象合并转换为Url参数
        if (min > max) [max, min] = [min, max];
        const attrfilterVal = {
            price_min: min,
            price_max: max
        };
        const concatpramX = Object.assign(getpram, attrfilterVal);
        const getpramX = this.cateBuildUrlControl(concatpramX);
        window.location.href = `${GLOBAL.DOMAIN_MAIN}${window.location.pathname}${getpramX}`;
    },

    checkStr(str) {
        str = str.substring(0, str.length - 1);
        return str;
    },

    getState() {
        const inforDate = window.sessionStorage.getItem('gb_brandView');
        if (inforDate) {
            this.brandContentBox.addClass('on');
        } else {
            this.brandContentBox.removeClass('on');
        }
    },

    isHasOwnPropertyControl(object, uselessKeys, object2, delgate) {
        uselessKeys.forEach((key) => {
            if (typeof object[key] === 'undefined') {
                delgate.forEach((i) => {
                    delete object2[i];
                });
            }
            return object2;
        });
    },

    /**
     * 判断参数的类型，以字符串的形式返回
     * @param：String
     */
    dataTypeObjectControl(objt) {
        if (objt === null) return 'Null';
        if (objt === undefined) return 'Undefined';
        return Object.prototype.toString.call(objt).slice(8, -1);
    },

    // 货币精度
    getDollarNum($ele) {
        let result = Number(toFixed($ele.attr('data-currency'), 2));
        if (result === 0) {
            result = '';
        }
        return result;
    },

    clearBtnHandle() {
        const filterLen = $('.js-filterLog a');
        if (filterLen && filterLen.length > 0) {
            this.filterClearBtn.addClass('on');
        } else {
            this.filterClearBtn.removeClass('on');
        }
    },

    clearFilterControl() {
        const filterLog = $('.js-filterLog');
        const asideFilterBox = $('.js-asideFilterBox');
        this.filterClearBtn.on('click', (e) => {
            e.preventDefault();
            const thatSef = $(e.currentTarget);
            const dataLink = thatSef.data('link');
            if (filterLog && filterLog.find('a').length > 0) {
                filterLog.empty();
                thatSef.removeClass('on');
                asideFilterBox.addClass('hiden');
                window.location.href = dataLink;
            }
        });
    },

    getQueryStringControl() {
        const theRequest = {};
        const url = window.location.search;
        if (url.indexOf('?') !== -1) {
            const str = url.substr(1);
            const strs = str.split('&');
            for (let i = 0; i < strs.length; i += 1) {
                theRequest[strs[i].split('=')[0]] = decodeURIComponent(strs[i].split('=')[1]);
            }
        }
        return theRequest;
    },

    cateBuildUrlControl(obj) {
        let url = (obj.url !== undefined ? obj.url : '?');
        try {
            if (obj) {
                for (const key in obj) {
                    if (key !== 'url' && obj[key] !== null) {
                        url += (`${key}=${decodeURIComponent(obj[key])}&`);
                    }
                }
                return url.substring(0, url.lastIndexOf('&'));
            }
        } catch (error) {
            // throw new Error
        }
        return true;
    },
};

searchCatefilter.init();

const updateDollarNum = ($ele) => {
    let result = Number(toFixed($ele.attr('data-currency'), 2));
    if (result === 0) {
        result = '';
    }
    return result;
};

const getCurrencyStorageControl = () => {
    const $min = $('.js-filterPriceMin');
    const $max = $('.js-filterPriceMax');
    const min = $min.data('range');
    const max = $max.data('range');
    if (min) {
        $min.val(transform({ price: min, round: 1 }));
    }
    if (max) {
        $max.val(transform({ price: max, round: 1 }));
    }
};

const emptySyncCurrencyHandle = () => {
    const filterSubmit = $('.js-filterSubmit');
    if (filterSubmit && filterSubmit.length) {
        if (filterSubmit.attr('data-price-min') === '' && filterSubmit.attr('data-price-max') === '') {
            const elementNodeX = updateDollarNum($('input[name=minPrice]'));
            const elementNodeY = updateDollarNum($('input[name=maxPrice]'));
            filterSubmit.attr({
                'data-price-min': elementNodeX || '',
                'data-price-max': elementNodeY || '',
            });
        }
    }
};
getCurrency().then(() => {
    getCurrencyStorageControl();
});
PubSub.subscribe('nativeLoad', async () => {
    emptySyncCurrencyHandle();
});

