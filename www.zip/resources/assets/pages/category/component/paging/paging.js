import layer from 'layer';
import { trans } from 'js/core/translate.js';
import './paging.css';

const pagingApp = {
    pageSet: $('.js-pageSelect'),
    pageGoBtn: $('.js-pageGoBtn'),
    pageGotoUrl: $('.js-defaultPageValue'),
    pageInputVal: $('.js-inputPageValue'),
    init() {
        this.pageSelectControl();
        this.setPagingControl();
    },
    pageSelectControl() {
        const that = this;
        that.pageSet.on('click', 'a', function pageStatus() {
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
            }
        });
    },
    setPagingControl() {
        const that = this;
        that.pageGoBtn.on('click', function pageSelect() {
            const thatSef = $(this);
            const inputPlanVal = $.trim(that.pageInputVal.val());
            const replaceVal = that.pageGotoUrl.val();
            if (!thatSef.hasClass('disabled')) {
                if (inputPlanVal !== '') {
                    if (replaceVal.indexOf('defaultPageValue') >= 0) {
                        const replaceText = replaceVal.replace('defaultPageValue', inputPlanVal);
                        window.location.href = replaceText;
                    }
                } else {
                    layer.msg(trans('goodslist.store_product_tip'));
                }
            } else {
                layer.msg(trans('goodslist.search_page_number_tips'));
            }
        });
    },
};

pagingApp.init();
