import layer from 'layer';
import { STORAGE_APPAREL } from 'js/variables';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import './apparel_temp.css';

runtime.trans = trans;

const apparelApp = {
    init() {
        this.renderlayerControl();
    },
    async layerControl() {
        const ageTemp = await import('./apparel_temp.art');
        layer.open({
            content: ageTemp(),
            area: '400px',
            btn: [trans('goods.yes'), trans('goods.no')],
            shadeClose: false,
            shade: [0.9, '#000000'],
            skin: 'apparelTemp_content',
            btn1: function yes(index) {
                layer.close(index);
                window.localStorage.setItem(STORAGE_APPAREL, 1);
            },
            btn2: function no(index, layero) {
                window.location.href = GLOBAL.DOMAIN_MAIN;
            }
        });
    },
    renderlayerControl() {
        const that = this;
        const apparelCode = window.localStorage.getItem(STORAGE_APPAREL);
        const linkAppareID = window.location.pathname.match(/c_([^/]*)/);
        const linkAppareArr = ['12181', '12182', '12183', '12184', '12185', '12186'];
        if (linkAppareID) {
            if ($.inArray(linkAppareID[1].toString(), linkAppareArr) >= 0) {
                if (!apparelCode) {
                    that.layerControl();
                }
            }
        }
    },
};

apparelApp.init();

