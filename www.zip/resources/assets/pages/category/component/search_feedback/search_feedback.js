import 'js/bootstrap';
import $ from 'jquery';
import PubSub from 'pubsub-js';
// import layer from 'layer';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import { serviceSearchFeedBack } from 'js/service/common';
import 'js/utils/validation.config.js';
import renderTextarea from './feedback.art';
import renderSuccTemp from './feedback_succes.art';
import renderErrorTemp from './feedback_error.art';
import './search_feedback.css';

runtime.trans = trans;

const SearchFeedBackApp = {
    feedbackBtn: $('.js-feedbackBtn'),
    feedbackVal: $('.js-feedbackVal'),
    feedbackText: $('.js-feedbackText'),
    feedbackList: $('.js-feedbackList'),
    feedbackForm: $('.js-feedbackForm'),
    feedbackInput: $('.js-feedbackInput'),
    feedbackFilter: $('.js-feedbackFilter'),
    feedbackContain: $('.js-feedbackContain'),
    feedbackCloseBtn: $('.js-feedbackClose'),
    feedbackInfoBox: $('.js-feedbackInfoBox'),
    feedbackInfoTip: $('.js-feedbackInfoTip'),
    feedbackReportButton: $('.js-feedbackReportButton'),
    init() {
        this.bindEvent();
        this.feedbackValidatorControl();
    },
    bindEvent() {
        const that = this;

        // 显示面板
        that.feedbackText.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            const containBox = thatSef.next('div');
            thatSef.toggleClass('on');
            if (!thatSef.hasClass('on')) containBox.removeClass('active');
            else containBox.addClass('active');
        });

        // 按钮选择
        that.feedbackBtn.on('click', 'a', (e) => {
            const thatSef = $(e.currentTarget);
            const dataIndex = thatSef.index();
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
                if (dataIndex === 0) {
                    that.feedbackButtonControl(0);
                } else if (dataIndex === 1) {
                    that.feedbackButtonControl(1);
                    if (that.feedbackVal.attr('data-val') !== '0') {
                        that.feedbackInput.addClass('active');
                    } else {
                        that.feedbackInput.removeClass('active');
                    }
                }
            }
        });

        // 下拉面板分类数据
        that.feedbackList.on('click', 'a', (e) => {
            const thatSef = $(e.currentTarget);
            if (!thatSef.hasClass('on')) {
                that.feedbackPanelControl();
                thatSef.addClass('on').siblings('a').removeClass('on');
                that.feedbackText.find('span').text(thatSef.text()).attr('data-val', thatSef.attr('data-val'));
                if (thatSef.attr('data-val') !== '0') that.feedbackInput.addClass('active');
            }
        });

        // 点击其它区域收起面板
        PubSub.subscribe('nativeDocumentClick', (msg, e) => {
            const { target } = e;
            if (that.feedbackFilter.length > 0) {
                if (!$.contains(that.feedbackFilter[0], target)) {
                    that.feedbackPanelControl();
                }
            }
        });
    },

    // 面板状态
    feedbackPanelControl() {
        const that = this;
        that.feedbackText.removeClass('on');
        that.feedbackList.removeClass('active');
    },

    feedbackRemoveInfoBox() {
        setTimeout(() => {
            $('.js-feedbackOpera').removeClass('on');
            $('.js-feedbackInfoBox').removeClass('active').remove();
        }, 5000);
    },

    feedbackInforrenderControl() {
        $('.js-feedbackClose').on('click', (e) => {
            const thatSef = $(e.currentTarget);
            if (thatSef.closest($('.js-feedbackInfoBox')).hasClass('active')) {
                thatSef.closest($('.js-feedbackInfoBox')).removeClass('active');
            }
        });
    },

    feedbackSuccessControl() {
        const that = this;
        that.feedbackInput.removeClass('active');
        that.feedbackContain.removeClass('active');
    },

    feedbackValidatorControl() {
        const that = this;
        that.feedbackForm.validate({
            rules: {
                content: {
                    required: true,
                    maxlength: 5000
                },
            },
            messages: {
                content: {
                    maxlength: trans('goodslist.search_feedback_character')
                }
            }
        });
        that.feedbackForm.on('submit', (e) => {
            e.preventDefault();
            const $form = $(e.currentTarget);
            const $btn = $form.find('button');
            const typeCode = Number($btn.data('type'));
            const typeValue = Number($form.find('.js-feedbackVal').attr('data-val')) || '';
            if ($form.valid()) {
                $btn.addClass('loading');
                serviceSearchFeedBack.http({
                    data: {
                        type: typeValue,
                        is_useful: typeCode,
                        feedback_content: $form.find('textarea').val(),
                    },
                }).then((res) => {
                    if (+res.status === 0) {
                        that.feedbackInfoTip.html(renderSuccTemp({
                            renderText: 'active',
                            renderMessage: trans('goodslist.search_feedback_thank'),
                        }));
                        that.feedbackRemoveInfoBox();
                        that.feedbackInforrenderControl();
                    } else {
                        that.feedbackInfoTip.html(renderErrorTemp({
                            renderText: 'active',
                            renderMessage: trans('goodslist.search_feedback_failed'),
                        }));
                        that.feedbackRemoveInfoBox();
                        that.feedbackInforrenderControl();
                    }
                    $btn.removeClass('loading');
                    that.feedbackSuccessControl();
                });
            }
        });
    },

    // 按钮状态
    feedbackButtonControl(typeCode) {
        const that = this;
        if (typeCode === 0) {
            that.feedbackContain.removeClass('active');
            that.feedbackInput.addClass('active').html(renderTextarea({
                btnCode: 1
            }));
        } else if (typeCode === 1) {
            that.feedbackInput.html(renderTextarea({
                btnCode: 0
            }));
            that.feedbackContain.addClass('active');
        }
    },
};

SearchFeedBackApp.init();
