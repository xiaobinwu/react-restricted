import 'js/bootstrap';
import $ from 'jquery';
import GoodsItem from 'component/goods_item/goods_item.js';
import searchResultsTrack from 'js/track/define/search_results.js';
import './search_result.css';
import '../component/search_feedback/search_feedback.js';

/* 搜索分类列表大数据埋点 */
searchResultsTrack();

GoodsItem.init({
    container: $('.cateMain_listModel'),
});

const goodsDepoistControl = {
    init() {
        this.depoistExpiredControl();
    },
    depoistExpiredControl() {
        try {
            const nowTime = Math.floor((new Date()).getTime() / 1000);
            $('.js-depositExpired').each((index, item) => {
                const tahtSef = $(item);
                const startTime = tahtSef.data('start-time');
                const endTime = tahtSef.data('end-time');
                if (nowTime - startTime > 0 && endTime - nowTime > 0) {
                    tahtSef.addClass('on');
                }
            });
        } catch (error) {
            // error...
        }
    }
};

goodsDepoistControl.init();
