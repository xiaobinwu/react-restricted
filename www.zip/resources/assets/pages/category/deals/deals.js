import 'js/bootstrap';
import $ from 'jquery';
import Clipboard from 'clipboard';
import layer from 'layer';
import Timer from 'component/timer/timer.js';
import GoodsItem from 'component/goods_item/goods_item.js';
import dealsTrack from 'js/track/define/dealses.js';
import { trans } from 'js/core/translate.js';
import { serviceDealsUserlikes } from 'js/service/promotion';
import { STORAGE_DEALS_NODE_ITEM } from 'js/variables';
import { isLogin } from 'js/core/user.js';

import './deals.css';
import '../component/paging/paging.js';
import '../component/brandUp_aside/brandUp_aside.js';
import successTemp from './template/copy_success';

/* Deals频道大数据埋点 */
dealsTrack();

/* 初始化公共橱窗组件 */
GoodsItem.init({
    container: $('.cateMainWarp_goodsItem'),
});

const dealsPageChageModule = {
    showCateMore: $('.js-showCatMore'),
    recCateMore: $('.js-recCateMore'),
    selectItemd: $('.js-selectItemd'),
    timeCounte: $('.js-goodsItemTime'),
    likesWrap: $('.js-likesControl'),
    likeSelect: $('.gbGoodsItem_ctrl'),
    copyCodeBtn: $('.js-copyCode'),

    init() {
        this.catelikesControl();
        this.cateChageState();
        this.cateRecentlyBox();
        this.cateChageStore();
        this.cateRecentlyViewed();
        this.cateViewlocalStorage();
        this.cateTimeCounteControl();
        this.cateClipboard();
    },
    async catelikesControl() {
        const that = this;
        const curIsLogin = await isLogin();
        if (!curIsLogin) {
            return;
        }
        const res = await serviceDealsUserlikes.http({
            errorPop: false,
        });
        if (+res.status === 0) {
            if (res.data && res.data.length > 0) {
                res.data.forEach((item, index) => {
                    const renderIndex = that.likeSelect.find(`a[data-deals-id="${res.data[index].deals_id}"]`);
                    if (!renderIndex.hasClass('on')) {
                        renderIndex.addClass('on');
                    }
                });
            }
        } else {
            layer.msg(res.msg);
        }
    },
    cateChageState() {
        const that = this;
        const toggleElement = $('.cateMainWarp_catNav-deals');
        that.showCateMore.on('click', () => {
            toggleElement.toggleClass('all');
        });
    },
    cateRecentlyBox() {
        const that = this;
        const selectCookie = $('.cateMainWarp_selectCookie');
        const getlocalStorage = window.localStorage.getItem(STORAGE_DEALS_NODE_ITEM);
        that.recCateMore.on('click', (e) => {
            if (getlocalStorage && getlocalStorage.length > 0) {
                that.cateRecentlyViewed();
            }
            selectCookie.toggleClass('show');
            e.stopPropagation();
        });
        $(document).on('click', () => {
            if (selectCookie.hasClass('show')) {
                selectCookie.removeClass('show');
            }
        });
    },
    cateChageStore() {
        const selectItem = $('.cateMainWarp_sortsNav');
        selectItem.on('click', 'a', function selectItems() {
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
            }
        });
    },
    cateRecentlyViewed() {
        const recentlyBox = $('.cateMainWarp_selectCookie');
        let goodsArr = window.localStorage.getItem(STORAGE_DEALS_NODE_ITEM);
        let html = '';
        let arr = [];
        if (goodsArr) {
            goodsArr = goodsArr.split(',');
            if (goodsArr.length > 0) {
                for (let i = 0; i < goodsArr.length; i += 1) {
                    arr = goodsArr[i].split('&');
                    html += `<a class="cateMainWarp_selectItem js-selectItemd" href="${arr[0]}" data-id="${arr[1]}" data-img="${arr[2]}">
                                <img src="${arr[2]}">
                            </a>`;
                }
                recentlyBox.find('.cateMainWarp_selectChildBox').html(html);
            }
        }
    },
    cateViewlocalStorage() {
        $('.cateMainWarp_goodsItem').on('click', '.js-selectItemd', function localStorage() {
            const thatSef = $(this);
            const dataId = thatSef.data('id');
            const href = thatSef.attr('href');
            const dataImg = thatSef.data('img');
            let arrViewPro = window.localStorage.getItem(STORAGE_DEALS_NODE_ITEM);

            arrViewPro = arrViewPro ? arrViewPro.split(',') : [];
            arrViewPro.unshift(`${href}&${dataId}&${dataImg}`);
            for (let i = 1; i < arrViewPro.length; i += 1) {
                if (`${href}&${dataId}&${dataImg}` === arrViewPro[i]) {
                    arrViewPro.splice(i, 1);
                    break;
                }
            }
            arrViewPro = arrViewPro.slice(0, 6);
            window.localStorage.setItem(STORAGE_DEALS_NODE_ITEM, arrViewPro.join(','));
        });
    },
    cateTimeCounteControl() {
        const timer = new Timer();
        timer.update('.js-goodsItemTime', {
            format: `<div class="dealsEndText">${trans('goodslist.end_time')}:</div> <div class="dealsEndTime">{dd}:{hh}:{mm}:{ss}</div>`,
            interval: 'time',
        });
    },
    cateClipboard() {
        const that = this;
        that.copyCodeBtn.each((i, el) => {
            const clip = new Clipboard(el, {
                text(trigger) {
                    return trigger.dataset.code;
                },
            });
            clip.on('success', () => {
                layer.open({
                    content: successTemp({ copySuccessedTip: trans('goodslist.copy_successed') }),
                    area: ['auto', 'auto'],
                    btn: false,
                    closeBtn: 1,
                });
            });
        });
    },
};

dealsPageChageModule.init();
