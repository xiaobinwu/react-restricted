import 'js/bootstrap';
import { STORAGE_LOGIN } from 'js/variables';
import { slickFn } from 'js/core/slickFn.js';
import { throttle } from 'js/utils/index.js';
import lazyObserver from 'js/utils/lazyObserver';
import PubSub from 'pubsub-js';
import { serviceGetNewProducts } from 'js/service/promotion';
import GoodsItem from 'component/goods_item/goods_item.js';
import newArrivaTrack from 'js/track/define/arrival.js';
import './new_arrival.css';
import '../component/paging/paging.js';
import '../component/brandUp_aside/brandUp_aside.js';
import '../component/view_history/view_history.js';

/* 新品页数据曝光埋点 */
newArrivaTrack();

/* 初始化公共橱窗组件 */

// 新品版块slick
lazyObserver({
    threshold: 0.1,
    async callBack(observerTarget) {
        const $this = $(observerTarget);
        const $navItem = $('.newArrival_navItem');
        slickFn({
            container: $this,
            slidesToShow: 4,
            slidesToScroll: 4,
            autoplaySpeed: 3000,
            speed: 1000,
            autoplay: true,
            prevArrow: $navItem.eq(0),
            nextArrow: $navItem.eq(1),
        });
    },
    observeDom: document.querySelector('.js-siteNewArrivalSlick'),
});

// 定金膨胀版块slick
lazyObserver({
    threshold: 0.1,
    async callBack(observerTarget) {
        const $this = $(observerTarget);
        const $navItem = $('.preOrder_navItem');
        slickFn({
            container: $this,
            autoplay: true,
            autoplaySpeed: 3000,
            speed: 1000,
            prevArrow: $navItem.eq(0),
            nextArrow: $navItem.eq(1),
        });
    },
    observeDom: document.querySelector('.js-sitePreOrderSlick'),
});

// 首发banner版块slick
lazyObserver({
    threshold: 0.1,
    async callBack(observerTarget) {
        const $this = $(observerTarget);
        const $navItem = $('.previousBanner_navItem');
        slickFn({
            container: $this,
            autoplay: true,
            autoplaySpeed: 3000,
            speed: 1000,
            prevArrow: $navItem.eq(0),
            nextArrow: $navItem.eq(1),
        });
    },
    observeDom: document.querySelector('.js-sitePreviousBannerSlick'),
});

// 瀑布流分类导航置顶时slick
lazyObserver({
    threshold: 0.1,
    async callBack(observerTarget) {
        const $this = $(observerTarget);
        const $navItem = $('.newNavList_navItem');
        slickFn({
            container: $this,
            slidesToShow: 8,
            slidesToScroll: 8,
            autoplaySpeed: 3000,
            speed: 1000,
            autoplay: false,
            prevArrow: $navItem.eq(0),
            nextArrow: $navItem.eq(1),
        });
    },
    observeDom: document.querySelector('.js-newNavListSlick'),
});

const arrivalPageChageModule = {
    arrivalCateBox: $('.js-newArrivalBox'),
    arrivalBox: $('.js-cateArrivalBox'),
    arrivalCateNavBtn: $('.js-cateNavMore'),
    arrivalCheckBox: $('.js-clearCheckbox'),
    recentlyLoginBox: $('.js-recentlyLogin'),

    init() {
        this.arrivalCateMoreControl();
        this.arrivalCheckBoxState();
        this.recentlyLoginControl();
        this.newProdNavToFixed();
        this.bindEvent();
        this.page = 0; // 初始化当前页码为0
        this.cateId = 0; // 初始化当前分类ID为0
        this.isAppend = true; // 初始化加载方式为append,false为html
        this.canShowMore = true; // 初始化可以加载更多
    },
    arrivalCateMoreControl() {
        const that = this;
        that.arrivalCateNavBtn.on('click', () => {
            that.arrivalBox.toggleClass('all');
            that.arrivalCateBox.toggleClass('down');
        });
    },
    arrivalCheckBoxState() {
        const that = this;
        that.arrivalCheckBox.on('click', function CheckBox() {
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on');
            } else {
                thatSef.removeClass('on');
            }
        });
    },
    recentlyLoginControl() {
        const that = this;
        const loginCookie = sessionStorage.getItem(STORAGE_LOGIN);
        if (loginCookie && loginCookie.length > 0) {
            that.recentlyLoginBox.hide();
        }
    },
    newProdNavToFixed() {
        if ($('.js-newNavList').length) {
            const self = this;
            const $newNavListUpdate = $('.js-newNavListUpdate');
            const $newNavListFixed = $('.js-newNavListUpdate .js-newNavListFixed');
            const newNavFixedH = +$newNavListUpdate.offset().top + 200;
            const $navListFixed = $newNavListUpdate.find('.js-newNavListFixed .js-newNavCateInfo');
            const $navListNormal = $newNavListUpdate.find('.js-newNavListNormal .js-newNavCateInfo');
            PubSub.subscribe('nativeScroll', () => {
                const pageScrollTop = $(document).scrollTop();
                if (pageScrollTop > newNavFixedH) {
                    // 瀑布流分类导航添加置顶固定class
                    $newNavListFixed.addClass('navFixed');

                    // 瀑布流分类导航置顶固定时切换分类高亮
                    if ($navListFixed.length) {
                        $navListFixed.each((index, item) => {
                            const $item = $(item);
                            if ($item.length && ($item[0].dataset.catId).toString() === (self.cateId).toString()) {
                                $item.addClass('on').closest('.slick-slide').siblings('.slick-slide').find('li')
                                    .removeClass('on');
                            }
                        });
                    }
                } else {

                    // 瀑布流分类导航去掉置顶固定class
                    $newNavListFixed.removeClass('navFixed');

                    // 瀑布流分类导航普通展示时切换分类高亮
                    if ($navListNormal.length) {
                        $navListNormal.each((index, item) => {
                            const $item = $(item);
                            if ($item.length && ($item[0].dataset.catId).toString() === (self.cateId).toString()) {
                                $item.addClass('on').siblings('li').removeClass('on');
                            }
                        });
                    }
                }
            });
        }
    },

    bindEvent() {
        const self = this;
        const $btnViewMorePage = $('.js-btnNewArrivalViewmore');
        // 滚动加载更多
        const scrollShow = () => {
            const $win = $(window);
            const scrollTop = $(document).scrollTop();
            const winHeight = $win.height();
            const docHeight = $(document).height();
            const footerHeight = $('.js-siteFooterWrap').height();
            if ((scrollTop + winHeight > docHeight - footerHeight - 1) && self.canShowMore) {
                self.isAppend = true;
                self.newProductsShowPage();
            }
        };

        PubSub.subscribe('nativeScroll', throttle(scrollShow, 300));

        const $prodCollectBox = $('.js-newCollectionProd');
        // 点击 view more 加载更多
        $prodCollectBox.on('click', '.js-btnNewArrivalViewmore', () => {
            self.canShowMore = true;
            self.isAppend = true;
            self.newProductsShowPage();
            $btnViewMorePage.removeClass('show');
        });
        // 点击分类加载
        $prodCollectBox.on('click', '.js-newNavCateInfo', (e) => {
            const $newNavListUpdate = $('.js-newNavListUpdate');
            self.cateId = $(e.currentTarget).data('cat-id');
            self.page = 0;
            self.isAppend = false;
            $(window).scrollTop($prodCollectBox.offset().top);
            if ($newNavListUpdate.hasClass('navFixed')) {
                $(e.currentTarget).addClass('on').closest('.slick-slide').siblings('.slick-slide')
                    .find('li')
                    .removeClass('on');
            } else {
                $(e.currentTarget).addClass('on').siblings('li').removeClass('on');
            }

            self.newProductsShowPage();
        });
    },
    async newProductsShowPage() {
        const self = this;
        self.page += 1;
        self.canShowMore = false;
        const $btnViewMorePage = $('.js-btnNewArrivalViewmore');
        const params = {
            page: self.page
        };
        if (self.cateId) {
            Object.assign(params, {
                id: self.cateId
            });
        }
        try {
            const { data, status } = await serviceGetNewProducts.http({
                params
            });
            if (+status === 0) {
                self.canShowMore = true;
                if (self.page % 4 === 0) {
                    $btnViewMorePage.addClass('show');
                    self.canShowMore = false;
                } else {
                    $btnViewMorePage.removeClass('show');
                }
                if (data && data.goodsList && data.goodsList.length > 0) {
                    const trackCate = self.cateId || 'ALL';
                    const trackInfo = `30_${trackCate}_${self.page}`;
                    $('input[name=track-infor]').attr('data-track-inofo', trackInfo);
                    if (!data.countPage || data.countPage === self.page) {
                        self.canShowMore = false;
                    }
                    GoodsItem.init({
                        container: $('.js-newCollectionProdList'),
                        type: 7,
                        list: data.goodsList,
                        append: self.isAppend,
                        currentPage: self.page
                    });
                    PubSub.publish('sysUpdateCurrency', {
                        context: $('.js-newCollectionProdList')[0],
                    });
                } else {
                    self.canShowMore = false;
                }
            }
        } catch (e) {
            console.log(e);
        }
    },
};

arrivalPageChageModule.init();
