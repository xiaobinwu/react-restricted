import 'js/bootstrap';
import $ from 'jquery';
import layer from 'layer';
import PubSub from 'pubsub-js';
import GoodsItem from 'component/goods_item/goods_item.js';
import { trans } from 'js/core/translate.js';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import { serviceGoodsCollect } from 'js/service/goods.js';
import {
    serviceStoreCollect,
    serviceStoreData,
    serviceStoreActiveData,
    serviceStoreBlockData,
} from 'js/service/store_serivce';
import asyncPricePromise from 'js/core/goods/asyncPricePromise';
import { getDiscount, getDiscountStr } from 'js/core/goods/discountCalc.js';
// 大数据埋点
import storeTrack from 'js/track/define/store.js';

import couponTemp from './component/coupon_success';
import './store.css';
import '../component/aside/search_left.js';

storeTrack();

// 实时价渲染等待
asyncPricePromise.then((resList) => {
    resList.forEach((item) => {
        showRealDiscount(item.el, item.displayPrice);
    });
});

// 显示实时折扣标
function showRealDiscount(item, displayPrice) {
    const $itemLi = $(item).parents('.js-gbGoodsItem'); // 商品位li
    const $discount = $itemLi.find('.gbGoodsItem_discount'); // 折扣标元素
    const needShowDiscount = $itemLi.parent().data('show-realdiscount'); // 是否需要显示实时折扣标
    const shopPrice = $itemLi.data('shopprice'); // 本店售价
    const notDeposit = $itemLi.data('notdeposit'); // 当前商品是否属定金膨胀
    const discount = getDiscount(displayPrice, shopPrice); // 计算获取折扣标

    // 需要显示折扣标 && 非定金膨胀 && 折扣大于0小于100
    if (needShowDiscount && notDeposit && discount > 0 && discount < 100) {

        // 同步渲染存在，直接覆盖
        if ($discount.length) {
            $discount.find('.gbGoodsItem_per').text(discount);
        } else { // 创建折扣标
            const discountStr = getDiscountStr(displayPrice, shopPrice);

            $itemLi.append(`
                <span class="gbGoodsItem_discount">
                    ${discountStr}
                    <i class="gbGoodsItem_off">${trans('goodslist.discount_off')}</i>
                </span>
            `);
        }
    }
}

const catePageChageModule = {
    recMainBox: $('.cateMain_allPro'),
    recItemBox: $('.js-recItemSlick'),
    recSearchItemBox: $('.js-SortItemBox'),
    recStoreCollect: $('.js-toggleCollect'),
    recgetCouponBtn: $('.js-getCouponBtn'),
    recStorelistBox: $('.js-flashSaleModel'),
    recStoreMaxBox: $('.js-allPorModel'),
    recStoreStatus: $('.js-collectStatus'),
    recStoreViewMoreBtn: $('.js-storeViewMoreBtn'),
    recStoreViewMoreBtnX: $('.js-storeViewMoreBtns'),
    recStoreOrderWrap: $('.js-labeleOrder'),
    recStoreOrderBox: $('.js-activeSaleBox'),
    recStoreMaxWrap: $('.js-storeMaxBox'),
    recStoreBlockBox: $('.js-storelistBox'),
    recActiveViewMore: $('.js-activeViewMore'),

    init() {
        this.recSearchNodeControl();
        this.recToggleCollect();
        this.recGetCouponCollect();
        this.recGetViewMoreCollect();
        this.recSetGoodsItemControl();
        this.recGetActiveDataCollect();
        this.recViewMoreBlockCollect();
        this.getCollectStatus();
        // this.recViewMoreCollect(this.recStoreViewMoreBtn, this.recStorelistBox);
        // this.recViewMoreCollect(this.recStoreViewMoreBtnX, this.recStoreMaxBox);

        // 切换优惠券显示
        $('.js-btnToggleCouponShow').on('click', () => {
            $('#js-panelCouponWrap').toggleClass('showAll');
        });
    },
    recSetGoodsItemControl() {
        GoodsItem.init({
            container: $('.cateMain_flashSale, .cateMain_allPro, .cateMain_activeItemBox'),
        });
    },
    recSearchNodeControl() {
        const taht = this;
        taht.recSearchItemBox.on('click', 'a', function selectNode() {
            const thatSef = $(this);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
            }
        });
    },
    setWidth() {
        $(window).on('resize', () => {
            const winDoc = $('.cateMain_listModel');
            const searchWordBox = $('.cateMain_searchWordBox, .cateMain_searchTip, .cateMain_header-sort');
            if (winDoc) {
                const docWidth = winDoc.width() - 55;
                searchWordBox.css({
                    width: docWidth,
                });
            }
        }).trigger('resize');
    },
    async storeCollectAddControl(shopCode) {
        const taht = this;
        taht.recStoreCollect.addClass('lock').attr('data-lock', 1);
        const res = await serviceStoreCollect.http({
            method: 'POST',
            errorPop: false,
            data: {
                shopCodeList: shopCode.toString(),
                flag: 1,
            },
        });
        if (+res.status === 0) {
            layer.msg(res.msg);
            if (!(+taht.recStoreCollect.attr('data-collected') === 1)) {
                taht.recStoreStatus.html(`${trans('goodslist.collected')}`);
                taht.recStoreCollect.removeClass('lock').attr({
                    'data-collected': 1,
                    'data-collectcode': 1,
                    'data-lock': 0,
                });
                taht.recStoreCollect.find('.sp-collect').addClass('sp-collected');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
        taht.recStoreCollect.removeClass('lock').attr('data-lock', 0);
    },
    async storeRemoveControl(shopCode) {
        const taht = this;
        // const storeStatus = thatSef.data('collectCode');
        taht.recStoreCollect.addClass('lock').attr('data-lock', 1);
        const res = await serviceStoreCollect.http({
            method: 'POST',
            errorPop: false,
            data: {
                shopCodeList: shopCode.toString(),
                flag: 2,
            },
        });
        if (+res.status === 0) {
            layer.msg(res.msg);
            if (+taht.recStoreCollect.attr('data-collected') === 1) {
                taht.recStoreStatus.html(`${trans('goodslist.add_to_favorites')}`);
                taht.recStoreCollect.removeClass('lock').attr('data-collected', 0).attr({
                    'data-collectcode': 2,
                    'data-lock': 0,
                });
                taht.recStoreCollect.find('.sp-collect').removeClass('sp-collected');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
        taht.recStoreCollect.removeClass('lock').attr('data-lock', 0);
    },
    // 获取店铺收藏状态
    async getCollectStatus() {
        try {
            const taht = this;
            const storeCode = taht.recStoreCollect.data('shopcode');
            const res = await serviceGoodsCollect.http({
                loading: false,
                errorPop: false,
                params: {
                    shopCode: storeCode,
                }
            });

            if (+res.status === 0 && res.data) {
                const resData = res.data;
                if (resData.shopCollect === 1) {
                    taht.recStoreCollect.attr('data-collected', 1)
                        .find('.sp-collect').addClass('sp-collected');
                    taht.recStoreStatus.html(`${trans('goodslist.collected')}`);
                } else {
                    taht.recStoreCollect.attr('data-collected', 0)
                        .find('.sp-collect').removeClass('sp-collected');
                    taht.recStoreStatus.html(`${trans('goodslist.add_to_favorites')}`);
                }
            }
        } catch (error) {
            // error
        }
    },
    recToggleCollect() {
        const taht = this;
        taht.recStoreCollect.on('click', function recStoreData() {
            const thatSef = $(this);
            const isLock = thatSef.attr('data-lock');
            const storeCode = thatSef.data('shopcode');
            if (+isLock === 0) {
                if (+thatSef.attr('data-collected') === 1) {
                    taht.storeRemoveControl(storeCode);
                } else {
                    taht.storeCollectAddControl(storeCode);
                }
            } else {
                layer.msg(trans('goodslist.coupon_error_tip'));
            }
        });
    },
    recGetCouponCollect() {
        const taht = this;
        taht.recgetCouponBtn.on('click', async function getCoupon() {
            const tahtSef = $(this);
            const couponCode = tahtSef.data('rec');
            if (tahtSef.hasClass('is-received')) {
                layer.msg(trans('goodslist.already_claimed_yours'));
            } else if (tahtSef.hasClass('is-taken')) {
                layer.msg(trans('goodslist.no_more_coupons_available'));
            } else if (tahtSef.hasClass('is-expired')) {
                layer.msg(trans('goodslist.coupon_expired_tip'));
            } else if (tahtSef.hasClass('loading')) {
                layer.msg(trans('goodslist.coupon_error_tip'));
            } else {
                tahtSef.addClass('loading');
                getCouponItem({
                    templateCode: couponCode,
                    successTip: false,
                    errorPop: false,
                }).then((res) => {
                    if (+res.status === 0) {
                        tahtSef.closest('li').addClass('is_received');
                        tahtSef.addClass('is-received');
                        layer.open({
                            content: couponTemp({
                                couponReceivedTip: trans('goodslist.coupon_received_tip'),
                                couponReceivedDec1: trans('goodslist.coupon_received_dec1'),
                                couponReceivedDec2: trans('goodslist.coupon_received_dec2'),
                            }),
                            area: ['auto', 'auto'],
                            btn: false,
                            closeBtn: 1,
                        });

                        // 已领取后变更领取处的html显示
                        tahtSef.find('.cateMain_couponStateBox').html(`
                            <span class="cateMain_couponReceived">
                                ${trans('goodslist.received')}
                            </span>
                        `);
                    }
                    tahtSef.removeClass('loading');
                });
            }
        });
    },
    recViewMoreCollect(targetBlock, activeBlock) {
        targetBlock.on('click', function recdata() {
            const tahtSef = $(this);
            activeBlock.toggleClass('open');
            if (tahtSef.closest(activeBlock).hasClass('open')) {
                tahtSef.html(`${trans('goodslist.view_less')}<i class="icon-arrows-small-down"></i>`);
            } else {
                tahtSef.html(`${trans('goodslist.view_more')}<i class="icon-arrows-small-down"></i>`);
            }
        });
    },
    recViewMoreBlockCollect() {
        const taht = this;
        taht.recStoreViewMoreBtn.on('click', async function asyncBlocklist() {
            const tahtSef = $(this);
            const shopCode = tahtSef.data('shop-code');
            const nextPage = Number(tahtSef.data('next-page'));
            const lastPage = Number(tahtSef.data('last-page'));
            const windowCode = tahtSef.data('window-id');
            const thisParent = tahtSef.closest('.js-flashSaleModel').find('ul');
            if (nextPage > lastPage) {
                tahtSef.hide();
            } else {
                tahtSef.addClass('loading');
                const res = await serviceStoreBlockData.http({
                    loading: true,
                    errorPop: false,
                    params: {
                        shop_code: shopCode.toString(),
                        windowId: windowCode.toString(),
                        page: nextPage,
                    },
                });
                if (+res.status === 0) {
                    let nextPageNumX = +tahtSef.data('next-page');
                    tahtSef.data('next-page', nextPageNumX += 1);
                    tahtSef.removeClass('loading');
                    if (nextPage === lastPage) {
                        tahtSef.hide();
                    }
                    if (res.data.list && res.data.list.length > 0) {
                        GoodsItem.init({
                            container: thisParent,
                            type: 2,
                            list: res.data.list,
                            append: true,
                        });
                        PubSub.publish('sysUpdateCurrency', {
                            context: taht.recStoreBlockBox[0],
                        });
                    }
                } else {
                    layer.msg(res.msg);
                }
                tahtSef.removeClass('loading');
            }
        });
    },
    recGetUrlParam(name) {
        const reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`);
        const str = window.location.search.substr(1).match(reg);
        if (str != null) return decodeURI(str[2]);
        return null;
    },
    recGetViewMoreCollect() {
        const taht = this;
        taht.recStoreViewMoreBtnX.on('click', async function asyncData() {
            const tahtSef = $(this);
            const shopCode = tahtSef.data('shopcodex');
            const nextPage = Number(tahtSef.data('nextpage'));
            const lastPage = Number(tahtSef.data('lastpage'));
            if (nextPage > lastPage) {
                tahtSef.hide();
            } else {
                tahtSef.addClass('loading');
                const res = await serviceStoreData.http({
                    method: 'jsonp',
                    loading: true,
                    errorPop: false,
                    params: {
                        shop_code: shopCode,
                        cat_id: taht.recGetUrlParam('cat_id'),
                        dn: taht.recGetUrlParam('dn'),
                        on_sale: taht.recGetUrlParam('on_sale'),
                        on_stock: taht.recGetUrlParam('on_stock'),
                        is_clear: taht.recGetUrlParam('is_clear'),
                        is_presale: taht.recGetUrlParam('is_presale'),
                        brand_code: taht.recGetUrlParam('brand_code'),
                        odr: taht.recGetUrlParam('odr'),
                        price_num: taht.recGetUrlParam('price_num'),
                        page: nextPage,
                    },
                });
                if (+res.status === 0) {
                    let nextPageNum = +tahtSef.data('nextpage');
                    tahtSef.data('nextpage', nextPageNum += 1);
                    tahtSef.removeClass('loading');
                    if (nextPage === lastPage) {
                        tahtSef.hide();
                    }
                    if (res.data && res.data.length > 0) {
                        GoodsItem.init({
                            container: taht.recMainBox,
                            type: 2,
                            list: res.data,
                            append: true,
                        });
                        PubSub.publish('sysUpdateCurrency', {
                            context: taht.recStoreMaxWrap[0],
                        });
                    }
                } else {
                    layer.msg(res.msg);
                }
                tahtSef.removeClass('loading');
            }
        });
    },
    recGetActiveDataCollect() {
        const taht = this;
        taht.recStoreOrderWrap.on('click', 'a', async function activeData() {
            const tahtSef = $(this);
            const orderCode = tahtSef.data('label').toString();
            const storeUrl = tahtSef.data('url');
            const shopCode = tahtSef.data('shop-code').toString();
            if (!tahtSef.hasClass('on')) {
                tahtSef.addClass('on').siblings('a').removeClass('on');
                const res = await serviceStoreActiveData.http({
                    loading: true,
                    errorPop: false,
                    params: {
                        activity_id: orderCode.toString(),
                        shop_code: shopCode.toString(),
                    },
                });
                if (+res.status === 0) {
                    if (res.data && res.data.length > 0) {
                        taht.recActiveViewMore.attr('href', storeUrl).show();
                        GoodsItem.init({
                            container: taht.recStoreOrderBox,
                            type: 2,
                            list: res.data,
                        });
                        PubSub.publish('sysUpdateCurrency', {
                            context: taht.recStoreOrderBox[0],
                        });
                    } else {
                        taht.recStoreOrderBox
                            .html(`<font class="cateMain_activeTips">${trans('goodslist.store_product_tip')}</font>`);
                        layer.msg(trans('goodslist.store_product_tip'));
                    }
                }
            }
        });
    },
};

catePageChageModule.init();
