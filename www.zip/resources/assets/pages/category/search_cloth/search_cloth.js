import 'css/bootstrap';
import './search_cloth.css';
