import 'js/bootstrap';
import $ from 'jquery';
import PubSub from 'pubsub-js';
import layer from 'layer';
import { serviceZoneData } from 'js/service/promotion';
import GoodsItem from 'component/goods_item/goods_item.js';
import { asyncPrice } from 'js/core/asyncPrice';
import zoneDealsTrack from 'js/track/define/zone_dealses.js';
import { STORAGE_ZONE_CATE_NAV, STORAGE_ZONE_DEALS_NODE } from 'js/variables';
import { getUrlQuery } from 'js/utils/index.js';
import '../component/brandUp_aside/brandUp_aside.js';
import './zone_deals.css';

/* 每日折扣页数据曝光埋点 */
zoneDealsTrack();

const listDealsPageChageModule = {
    isLoad: true,
    isMore: false,
    isGetDataIng: false,
    listZoneCateNav: $('.js-zoneDealsCatNav'),
    listCateZoneWrap: $('.js-cateDealsList'),
    listCateZoneUrl: $('.js-cateZoneUrl'),
    listPageLoading: $('.js-pageLoading'),
    listCateOrderBy: $('.js-cateOrderBy'),
    listCateOrderStr: $('.js-dealsOrderNav'),
    listFirstCateNav: $('.js-firstCateNav'),
    listZoneNextPage: $('.js-listZoneNextPage'),
    listCatePageBtn: $('.js-morePageBtn'),

    init() {
        this.listZoneCateControl();
        this.listCateOrderControl();
        this.listCateSortNodeControl();
        this.listScrollControl();
        this.listClickMoreBtn();
    },
    listZoneBlockState(hide) {
        const that = this;
        switch (hide) {
        case 'hide':
            that.listCateZoneWrap.hide();
            break;
        case 'show':
            that.listCateZoneWrap.show();
            break;
        default:
            that.listCateZoneWrap.hide();
        }
    },
    listMoreBtnSH(hide) {
        const that = this;
        switch (hide) {
        case 'hide':
            that.listCatePageBtn.hide();
            break;
        case 'show':
            that.listCatePageBtn.show();
            that.listClickMoreBtn();
            break;
        default:
            that.listCatePageBtn.hide();
        }
    },
    listparameterAttr() {
        const that = this;
        if (that.listZoneNextPage.attr('data-nextpage') < 20) {
            const listPageNum = that.listZoneNextPage.attr('data-nextpage');
            that.listZoneNextPage.attr('data-lastpage', 1);
            if (listPageNum % 2 === 0) {
                that.isMore = false;
                // that.listMoreBtnSH('show');
            } else {
                that.isMore = false;
                that.listMoreBtnSH('hide');
            }
        } else {
            that.listZoneNextPage.attr('data-lastpage', 0);
        }
    },
    // 列表分页获取
    async listZoneShowPage(listCurNextPage, listOrderStr) { // eslint-disable-line
        const that = this;
        const listOrder = that.listCateOrderBy.val(); // eslint-disable-line
        const listNextPages = that.listZoneNextPage.attr('data-nextpage'); // eslint-disable-line
        const listOrderW = that.listCateZoneUrl.val();
        // const listOrderBy = that.listCateOrderBy.val();
        that.isLoad = false;
        // that.listPageLoading.show();
        if (that.isGetDataIng) return;
        const data = await that.listZoneData(listOrderW, listOrderStr, listCurNextPage);
        if (+data.status === 0) {
            let listNextPageNum = +that.listZoneNextPage.attr('data-nextpage');
            that.isLoad = true;
            that.listparameterAttr();
            that.listZoneNextPage.attr({
                'data-lastpage': 1,
                'data-nextpage': listNextPageNum += 1,
            });
            if (data.data && data.data.length > 0) {
                data.data[0].goodsNum = 1;
                GoodsItem.init({
                    container: that.listCateZoneWrap,
                    type: 5,
                    list: data.data,
                    append: true,
                });

                // 接口有cache，要调实时价
                asyncPrice({
                    callback() {
                        PubSub.publish('sysUpdateCurrency', {
                            context: that.listCateZoneWrap[0],
                        });
                    }
                });

                that.listZoneBlockState('show');
                that.listPageLoading.hide();
            }
        } else {
            layer.msg(data.msg);
            that.listPageLoading.hide();
            that.listZoneNextPage.attr('data-lastpage', 0);
        }
        // const temp = await import('./template/zone_item.art');
        // that.listCateZoneWrap.append(temp(data));
    },
    /* 滑动加载数据及分页 */
    listScrollControl() {
        const that = this;
        const listDoc = $(document);
        const listWindow = $(window);
        const listNextPage = that.listZoneNextPage.attr('data-lastpage');
        listWindow.on('scroll', () => {
            if ((listDoc.scrollTop() + listWindow.height() > listDoc.height() - $('.siteFooter').height() - 10) && that.isLoad && !that.isMore) {
                if (listNextPage !== '0') {
                    const listOrderStr = that.listCateOrderBy.val();
                    const listCurNextPage = that.listZoneNextPage.attr('data-nextpage');
                    that.listZoneShowPage(listCurNextPage, listOrderStr);
                }
            }
        });
    },
    listClickMoreBtn() {
        const that = this;
        that.listCatePageBtn.unbind('click');
        this.listCatePageBtn.on('click', function () { // eslint-disable-line
            that.isMore = false;
            const listOrderStr = that.listCateOrderBy.val();
            const listCurNextPage = that.listZoneNextPage.attr('data-nextpage');
            that.listZoneShowPage(listCurNextPage, listOrderStr);
        });
    },
    // 价格列表切换
    listZoneCateControl() {
        const that = this;
        that.listZoneCateNav.on('click', 'li', async function () { // eslint-disable-line
            const thatSef = $(this);
            const dataNodeCode = thatSef.attr('data-ajax');
            const dataLockCode = thatSef.attr('data-lock'); // eslint-disable-line
            const dataOrderCode = that.listCateOrderBy.val();
            const listHasNextPage = that.listZoneNextPage.attr('data-lastpage'); // eslint-disable-line
            const listLocalSort = window.localStorage.setItem(STORAGE_ZONE_CATE_NAV, dataNodeCode); // eslint-disable-line
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('li').removeClass('on');
                if (dataNodeCode !== 'all') {
                    that.listFirstCateNav.removeClass('on');
                } else {
                    $('.cateMainWarp_catNavOther').find('li').removeClass('on');
                }
                that.listCateZoneUrl.val(dataNodeCode);
                that.listZoneBlockState('hide');
                // that.listPageLoading.show();
                that.listZoneNextPage.attr({
                    'data-nextpage': 2,
                    'data-lastpage': 1,
                });
                if (dataNodeCode || dataNodeCode !== 'all') {
                    if (that.isGetDataIng) {
                        return false;
                    }
                    const data = await that.listZoneData(dataNodeCode, dataOrderCode, 1);
                    if (+data.status === 0) {
                        thatSef.attr('data-lock', 0);
                        if (data.data && data.data.length > 0) {
                            // 货物数量定为 1
                            data.data[0].goodsNum = 1;
                            GoodsItem.init({
                                container: that.listCateZoneWrap,
                                type: 5,
                                list: data.data,
                            });

                            // 接口有cache，要调实时价
                            asyncPrice({
                                callback() {
                                    PubSub.publish('sysUpdateCurrency', {
                                        context: that.listCateZoneWrap[0],
                                    });
                                }
                            });

                            that.listZoneBlockState('show');
                            that.listPageLoading.hide();
                        }
                    } else {
                        layer.msg(data.msg);
                        thatSef.attr('data-lock', 0);
                    }
                    // const temp = await import('./template/zone_item.art');
                    // that.listCateZoneWrap.html(temp(data));
                }
            }
        });
    },
    // 获取列表
    listCateOrderControl() {
        const that = this;
        that.listCateOrderStr.on('click', 'a', async function () { // eslint-disable-line
            const thatSef = $(this);
            const dataSort = thatSef.attr('data-sort');
            const dataAjax = that.listCateZoneUrl.val();
            const zoneNodeStr = window.localStorage.setItem(STORAGE_ZONE_DEALS_NODE, dataSort); // eslint-disable-line
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
                // that.listPageLoading.show();
                that.listZoneBlockState('hide');
                that.listCateOrderBy.val(dataSort);
                that.listZoneNextPage.attr({
                    'data-nextpage': 2,
                    'data-lastpage': 1,
                });
                if (that.isGetDataIng) {
                    return false;
                }
                const data = await that.listZoneData(dataAjax, that.listCateOrderBy.val(), 1);
                if (+data.status === 0) {
                    if (data.data && data.data.length > 0) {
                        data.data[0].goodsNum = 1;
                        GoodsItem.init({
                            container: that.listCateZoneWrap,
                            type: 5,
                            list: data.data,
                        });

                        // 接口有cache，要调实时价
                        asyncPrice({
                            callback() {
                                PubSub.publish('sysUpdateCurrency', {
                                    context: that.listCateZoneWrap[0],
                                });
                            }
                        });

                        that.listZoneBlockState('show');
                        that.listPageLoading.hide();
                    }
                } else {
                    layer.msg(data.msg);
                }
                // const temp = await import('./template/zone_item.art');
                // that.listCateZoneWrap.html(temp(data));
            }
        });
    },
    listCateSortNodeControl() {
        const that = this;
        const listDealsMenu = that.listZoneCateNav.find('li');
        const listLocalSort = window.localStorage.getItem(STORAGE_ZONE_CATE_NAV);
        if (listLocalSort && listLocalSort.length > 0) {
            for (let i = 0; i < listDealsMenu.length; i += 1) {
                if (listDealsMenu[i].getAttribute('data-ajax') === listLocalSort) {
                    $(listDealsMenu[i]).trigger('click');
                    break;
                }
            }
        } else {
            listDealsMenu.filter(that.listFirstCateNav).trigger('click');
        }
    },
    async listZoneData(price, ord, page) {
        const $this = this;
        $this.isGetDataIng = true;
        const data = await serviceZoneData.http({
            params: {
                price,
                ord,
                page,
                // 将URL参数传递给数据接口，主要为了调整第一位商品位置
                ...getUrlQuery()
            },
        });
        $this.isGetDataIng = false;
        return data;
    },
};

listDealsPageChageModule.init();
