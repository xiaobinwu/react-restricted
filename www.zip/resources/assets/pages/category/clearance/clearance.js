import 'js/bootstrap';
import $ from 'jquery';
import layer from 'layer';
import { serviceCollectAdd, serviceGoodlistCollectRemove } from 'js/service/common';
import GoodsItem from 'component/goods_item/goods_item.js';
import clearanceTrack from 'js/track/define/clearances.js';
import PubSub from 'pubsub-js';
import { getCurrency } from 'js/core/currency';
import './clearance.css';
import '../component/paging/paging.js';
import '../component/brandUp_aside/brandUp_aside.js';
import clearTemp from './template/clear_temp';

/* 清仓页数据曝光埋点 */
clearanceTrack();

/* 初始化公共橱窗组件 */
GoodsItem.init({
    container: $('.cateMainWarp_goodsItem'),
});

const clearancePageChageModule = {
    clearCateMenu: $('.js-clearCateMenu'),
    clearCatNavBtn: $('.js-clearCatNavMore'),
    clearCateItemBox: $('.js-cateMainWarp_catNav'),
    clearSearchBtn: $('.js-clearSearchBtn'),
    clearMinPrice: $('.cateMainWarp_minPrice'),
    clearMaxPrice: $('.cateMainWarp_maxPrice'),
    clearCheckBox: $('.js-clearCheckBox'),
    clearOrderNav: $('.js-clearOrderNav'),
    clearTransUnit: $('.js-transformUnit'),
    selectCoupon: $('.js-selectCoupon'),
    allCategory: $('.js-allCategory'),
    init() {
        this.clearCateMoreControl();
        this.clearCatePriceControl();
        this.clearCheckBoxState();
        this.clearOrderColumnBox();
        this.clearSelectCoupon();
        this.transformControl();
        this.couponTimingShow();
        this.selectAllCategories();
        this.exploreToggleControl();
    },
    transformControl() {
        const that = this;
        const currencyText = $('.siteHeader_currencyText');
        if (currencyText) {
            setTimeout(() => {
                const currencyStr = $('.siteHeader_currencyText').text().split(' ')[0];
                if (that.clearTransUnit.text() === '') {
                    that.clearTransUnit.text(currencyStr);
                }
            }, 1000);
        }
        PubSub.subscribe('sysUpdateCurrency', async () => {
            const { currencySign, currencyRate } = await getCurrency();
            that.clearTransUnit.text(currencySign);
            that.clearMinPrice.val(Math.round(that.clearMinPrice.data('range') * currencyRate));
            that.clearMaxPrice.val(Math.round(that.clearMaxPrice.data('range') * currencyRate));
        });
    },
    clearCateMoreControl() {
        const that = this;
        that.clearCatNavBtn.on('click', () => {
            that.clearCateItemBox.toggleClass('all');
            that.clearCateMenu.toggleClass('down');
        });
    },
    clearCheckBoxState() {
        const that = this;
        that.clearCheckBox.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').siblings('a').removeClass('on');
            } else {
                thatSef.removeClass('on');
            }
        });
    },
    clearOrderColumnBox() {
        const that = this;
        that.clearOrderNav.on('click', 'a', (e) => {
            const thatSef = $(e.currentTarget);
            if (!thatSef.hasClass('on')) {
                setTimeout(() => {
                    thatSef.addClass('on').siblings('a').removeClass('on');
                }, 500);
            }
        });
    },
    cateSetParamControl(param, value) {
        const query = window.location.search.substring(1);
        const p = new RegExp(`(^|)${param}=([^&]*)(|$)`);
        if (p.test(query)) {
            const firstParam = query.split(param)[0];
            const secondParam = query.split(param)[1];
            if (secondParam.indexOf('&') > -1) {
                const lastPraam = secondParam.split('&')[1];
                return `?${firstParam}&${param}=${value}&${lastPraam}`;
            } else if (firstParam) {
                return `?${firstParam}&${param}=${value}`;
            }
            return `?${param}=${value}`;
        } else if (query === '') {
            return `?${param}=${value}`;
        }
        return `?${query}&${param}=${value}`;
    },
    clearCatePriceControl() {
        const that = this;
        that.clearSearchBtn.on('click', async () => {
            const { currencyRate } = await getCurrency();
            const minPriceVal = Math.round(that.clearMinPrice.val() / currencyRate);
            const maxPriceVal = Math.round(that.clearMaxPrice.val() / currencyRate);
            if (maxPriceVal && minPriceVal <= maxPriceVal) {
                window.location.href = `${GLOBAL.DOMAIN_MAIN}/clearance-price-${minPriceVal}_${maxPriceVal}.html`;
            } else {
                layer.open({
                    content: clearTemp(),
                    area: ['auto', 'auto'],
                    btn: false,
                    closeBtn: 1,
                });
            }
        });
    },
    clearSelectCoupon() {
        const that = this;
        that.selectCoupon.on('click', (e) => {
            const thatSef = $(e.currentTarget);
            if (!thatSef.hasClass('on')) {
                thatSef.addClass('on').parent().siblings('li').find('a')
                    .removeClass('on');
            } else {
                thatSef.removeClass('on');
                const currentUrl = thatSef.attr('href');
                const reg = /([?&])coupon=[\w]+(&)?/ig;
                const newUrl = currentUrl.replace(reg, ($0, $1, $2) => {
                    if ($1 === '?' && $2) {
                        return '?';
                    } else if ($1 === '&' && $2) {
                        return '&';
                    }
                    return '';
                });
                window.location.href = newUrl;
                e.preventDefault();
            }
        });
    },
    // pm说要让它不跳动的处理方式
    couponTimingShow() {
        setTimeout(() => {
            $('.cateMainWarp_Coupon').css('opacity', 1);
        }, 100);
    },
    // pm说加一个allcategory按钮
    selectAllCategories() {
        const currentLocation = window.location.href;
        const catReg = /cat-id=(\w*)/ig;
        const matchArr = currentLocation.match(catReg);
        let hasCatId = false;
        // 处理高亮
        if (matchArr && matchArr.length) {
            hasCatId = true;
            const matchStr = matchArr[0].split('=')[1];
            if (matchStr === '' || matchStr === '0') {
                this.allCategory.parent('li').addClass('on');
            }
        } else {
            this.allCategory.parent('li').addClass('on');
        }
        this.allCategory.click(() => {
            const hasSearch = currentLocation.indexOf('?') > 0;
            let newCurrentLocation = '';
            if (hasCatId) {
                newCurrentLocation = currentLocation.replace(catReg, () => 'cat-id=0');
            }

            if (!hasCatId) {
                newCurrentLocation = hasSearch ? `${currentLocation}&cat-id=0` : `${currentLocation}?cat-id=0`;
            }
            newCurrentLocation = newCurrentLocation.replace(/odr=\w*/ig, '');
            window.location.href = newCurrentLocation;
        });
    },

    async exploreAddCollectControl(goodsCode, goodsWareCode, thatElem) {
        const res = await serviceCollectAdd.http({
            errorPop: false,
            data: {
                goods: [`${goodsCode}_${goodsWareCode}`],
            },
        });
        if (+res.status === 0) {
            const $likeIcon = thatElem.find('.sp-collect');
            if (!$likeIcon.hasClass('sp-collected')) {
                $likeIcon.addClass('sp-collected');
                thatElem.removeClass('cancelCollect');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
    },
    async exploreDeleteCollectControl(goodsCode, goodsWareCode, thatElem) {
        const res = await serviceGoodlistCollectRemove.http({
            errorPop: false,
            data: {
                goodSn: goodsCode,
                virCode: goodsWareCode,
            },
        });
        if (+res.status === 0) {
            const $likeIcon = thatElem.find('.sp-collect');
            if (!thatElem.hasClass('cancelCollect')) {
                thatElem.addClass('cancelCollect');
                $likeIcon.removeClass('sp-collected');
            }
        } else if (+res.status === 1) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                layer.msg(res.msg);
            }
        }
    },

    exploreToggleControl() {
        const that = this;
        $('.js_dealsList').on('click', '.js-exploreCollection', function exploreCollectX() {
            const tahtSef = $(this);
            const dataSn = tahtSef.data('sku').toString();
            const dataWid = tahtSef.data('wid').toString();
            const $likeIcon = tahtSef.find('.sp-collect');
            if (!$likeIcon.hasClass('sp-collected')) {
                that.exploreAddCollectControl(dataSn, dataWid, tahtSef);
            } else {
                that.exploreDeleteCollectControl(dataSn, dataWid, tahtSef);
            }
        });
    },
};

clearancePageChageModule.init();
