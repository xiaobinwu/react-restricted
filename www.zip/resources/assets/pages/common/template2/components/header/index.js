// 顶部分类
import './component/header_category/header_category.js';

// 搜索
import './component/search/search.js';

// 头部样式重置
import './index.css';

// 顶部广告banner
import './siteBanner.css';

// 这个css业务只用在了首页和商详页
import './cookie_policy.css';
