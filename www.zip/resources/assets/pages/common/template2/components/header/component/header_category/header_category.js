import './header_category.css';

// 一级菜单滑过，懒加载分类面板右侧图片
let cateItemTimer = null;
$('.js-navItem').on('mouseenter', (e) => {
    const $this = $(e.currentTarget);
    const $imgGroup = $this.find('.js-imgGroup');
    const $childImg = $this.find('.js-cateChildImg');
    console.log($imgGroup.data('loaded'));
    if (+$imgGroup.data('loaded') !== 1) {
        clearTimeout(cateItemTimer);
        cateItemTimer = setTimeout(() => {
            $imgGroup.data('loaded', 1);
            [...$childImg].forEach((item) => {
                const $item = $(item);
                $item.attr('src', $item.attr('data-custom-lazy'));
                $item.parent('.icon-loading').removeClass('icon-loading');
            });
        }, 200);
    }
}).on('mouseleave', () => {
    clearTimeout(cateItemTimer);
});
