/**
 * Created by Liu Jun on 2019/3/25
 */

/**
 * 顶部搜索区功能 2019-01-13 15:02:11 luochongfei
 * 0.过滤功能函数+CONFIG全局配置
 * 1.左侧分类下拉区处理 @searchCate
 * ----0.分类下拉变更处理
 * ----1.设置当前页面分类ID
 * 2.搜索框区处理 @searchInput
 * ----0.获取搜索框的值 getVal
 * ----1.输入框正在输入时处理
 * ----2.暗文相关处理
 * ----3.推荐词面板相关处理
 * ----4.推荐词面板上下按钮处理
 * 3.主要逻辑处理 @headSearch
 * ----0.搜索提交处理
 * ----1.搜索链接处理
 */

// 搜索关键词过滤
function searchFilter(kwVal) {
    kwVal = kwVal.replace(/\*/g, '~~');
    kwVal = kwVal.replace(/\|/g, ']]');
    kwVal = kwVal.replace(/=/g, '((');
    kwVal = kwVal.replace(/"/g, ' ');
    kwVal = kwVal.replace(/</g, '))');
    kwVal = kwVal.replace(/>/g, ')))');
    kwVal = kwVal.replace(/\?/g, '!!!');
    kwVal = kwVal.replace(/\+/g, '__');
    kwVal = kwVal.replace(/-/g, '^^');
    kwVal = kwVal.replace(/\//g, '..');
    kwVal = kwVal.replace(/\\/g, '...');
    kwVal = kwVal.replace(/%/g, '!!');
    kwVal = kwVal.replace(/#/g, '~~~');
    kwVal = kwVal.replace(/>/g, '___');
    kwVal = kwVal.replace(/</g, '^^^');
    kwVal = kwVal.replace(/"/g, '[[');
    kwVal = kwVal.replace(/\$/g, '[[[');
    kwVal = kwVal.replace(/@/g, ' ');
    kwVal = kwVal.replace(/\s+/g, '-');
    return encodeURIComponent(kwVal);
}

// 搜索按钮
const $iptKeyword = $('#js-iptKeyword'); // 搜索输入框
const $panelSearchForm = $('#js-formSearch'); // 搜索表单

$panelSearchForm.submit((event) => {
    event.preventDefault();

    const val = $iptKeyword.val();
    const keyword = val.trim() ? val.trim() : null;

    if (keyword) { // 优先关键词搜索
        // 普通搜索
        const resultHref = `${GLOBAL.DOMAIN_MAIN}/${searchFilter(keyword)}-_gear/`;

        if (resultHref) window.location.href = resultHref;
    }
});
