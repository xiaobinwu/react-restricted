/**
 * Created by Liu.Jun on 2018/7/22.
 */
import 'gbpolyfill';
import 'js/polyfill';
import 'modules/base_header/base_header.js';


// template2 icon
import 'common/icon/stSyncGlobal/iconfont.css';

// 公共样式
import './components/style/index.css';

// custom header
import './components/header/index.js';

// custom footer
import './components/footer/index.js';
