/**
 * Created by Liu.Jun on 2018/7/22.
 */
import 'gbpolyfill';
import 'js/polyfill';

// base header
import 'modules/base_header/base_header.js';

// 最顶banner广告位
import 'modules/common/site_bannerLogo/index.css';

// 顶部搜索 包含了推荐 暗文等
import headSearch from 'modules/common/search/search.js';

// 搜索bts
import { searchCateABTest } from 'js/core/searchCateABtest.js';

// footer
import './components/footer/index.js';

// 分类|搜索页 ABtest cookie设置
searchCateABTest.init();

// 搜索初始化
headSearch.init();
