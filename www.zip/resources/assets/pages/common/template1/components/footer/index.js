import 'modules/base_footer/base_footer.js';

import './index.css';
