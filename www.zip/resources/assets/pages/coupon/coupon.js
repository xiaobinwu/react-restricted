import 'js/bootstrap';
import Clipboard from 'clipboard';
import { trans } from 'js/core/translate.js';
import layer from 'layer';
import $ from 'jquery';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import { serviceCouponUpdateInfo } from 'js/service/common';
import couponTrack from 'js/track/define/coupons.js';
import './coupon.css';
import successTemp from './component/copy_success/copy_success';

/* 每日折扣页数据曝光埋点 */
couponTrack();

/*
* scan  the exist code to change the style
*/


/**
 *  aside link scroll to  specify section in home page
 */
$('.js-asideLink').click((e) => {
    const $this = $(e.currentTarget);
    const index = $this.index();
    $('html,body').animate({
        scrollTop: $('.couponSec').eq(index).offset().top,
    });
});
/**
 * scroll
 */
$(window).scroll(() => {
    const scrollTop = $(window).scrollTop();
    const $couponAside = $('.js-couponAside');
    if (scrollTop > 500) {
        $couponAside.show();
    } else {
        $couponAside.hide();
    }
});
/**
 * scroll to top
 */
$('.js-toTop').click(() => {
    $('html,body').animate({
        scrollTop: 0,
    }, 1000);
});

/**
 * copy coupon code
 */

$('.js-copy').each((i, el) => {
    if ($(el).attr('data-code')) {
        const parent = $(el).parents('.couponSec_actTwo');
        parent.fadeIn();
        parent.siblings('div').hide();
    }
    const clip = new Clipboard(el, {
        text(trigger) {
            return trigger.dataset.code;
        },
    });
    clip.on('success', () => {
        layer.msg(trans('promotion.copy_succeed'));
    });
});

$('.js-coupon').on('click', async function() { // eslint-disable-line
    const $this = $(this);
    const id = $this.attr('data-coupon');
    $this.addClass('loading');
    const res = await getCouponItem({ templateCode: id, couponResource: 5 });
    resHandle(res, $this);
});
function resHandle(res, $this) {
    const $parent = $this.parent('.couponSec_actOne');
    const $slibParent = $parent.next('div');
    if (res.status === 1) {
        if (res.data.redirectUrl) {
            window.location.href = res.data.redirectUrl;
        } else {
            layer.msg(res.msg);
        }
    } else if (res.status === 0 || res.status === 10052071) {
        $this.removeClass('loading');
        $parent.hide();
        $slibParent.fadeIn();
        $slibParent.find('.couponSec_code').text(res.data.couponCode);
        $slibParent.find('.couponSec_copy').attr('data-code', res.data.couponCode);
        layer.open({
            content: successTemp({ url: res.data.myCouponLink }),
            area: ['auto', 'auto'],
            btn: false,
            closeBtn: 1,
        });
    } else {
        layer.msg(res.msg);
    }
    $this.removeClass('loading');
}

// 刷新cdn缓存
(async () => {
    try {
        const { status, data } = await serviceCouponUpdateInfo.http({
            method: 'jsonp',
            params: {
                templateCode: $('.js-couponWrap').data('templatecodes'),
            }
        });
        if (status === 0) {
            $('.couponSec_actTwo').each((index, elem) => {
                const $elem = $(elem);
                const templateid = $elem.data('coupon');
                if (data && data[templateid]) {
                    const $panelOperateContainer = $elem.prev('.couponSec_actOne');
                    $panelOperateContainer.css('display', 'none');
                    $elem
                        .show()
                        .find('.couponSec_code')
                        .text(data[templateid])
                        .next('.couponSec_copy')
                        .attr('data-code', data[templateid]);
                }
            });
        }
    } catch (e) {
        // nothing
    }
})();
