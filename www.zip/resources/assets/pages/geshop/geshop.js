/**
 * GESHOP 专题脚本，暴露API
 * Created by Jiazhan Li on 2018/08/30.
 */

import 'js/bootstrap';
import PubSub from 'pubsub-js';
import { serviceCollectAdd, serviceCollectRemove } from 'js/service/common';
import getCouponItem from 'js/core/goods/getCouponItem.js';
import googleSubjectTrack from 'js/track/define/google_subject.js';
import landingTrack from 'js/track/define/landing_page.js';
import { isLogin } from 'js/core/user.js';

const GESHOP = {};

/**
 * 添加购物车
 * @param reqData           // 后台接口请求参数，这是一个数组类型，允许批量添加购物车，单个对象配置信息如下：
 *     -- goodsSn           // string      Y   商品SKU
 *     -- qty               // string      Y   商品数量
 *     -- warehouseCode     // string      Y   仓库代码
 *     -- goodsType         // int         N   商品类型    0：正常  1：配件  2：赠品  3：加价购 4：买即赠赠品
 *     -- activityId        // int         N   活动Id，不传默认为0
 *     -- mainGoodsSn       // string      N   主商品SKU （配件商品传），默认为空
 *     -- ciphertext        // string      N   邮箱加密价，不传默认为空
 *     -- source            // int         N   加购商品来源  0-详情 1-列表
 *
 * @param animation         // 飞入购物车动画配置，配置项如下
 *     -- imgSrc            // string      Y   飞入过程中小图片的src地址
 *     -- origin            // jquery      Y   飞出起点（$元素）
 *     -- target            // jquery      N   飞入目标元素（$元素）,默认页面顶部的购物车
 *
 * @return void
 */
GESHOP.addToCart = ({
    reqData = [],
    animation = {},
} = {}) => {
    PubSub.publish('sysAddToCart', {
        goods: reqData,
        cartAni: animation,
    });
};


/**
 * 添加收藏
 * @param reqData       // 后台接口请求参数，这是一个数组类型，允许批量添加收藏，单个对象配置信息如下：
 *     -- sku           // string      Y   商品SKU
 *     -- wid           // string      Y   仓库代码
 *
 * @return Promise
 */
GESHOP.addCollection = (reqData = []) => {
    const goods = reqData.map(item => `${item.sku}_${item.wid}`);
    return serviceCollectAdd.http({
        data: { goods },
    });
};


/**
 * 取消收藏
 * @param reqData       // 后台接口请求参数，这是一个数组类型，允许批量添加收藏，单个对象配置信息如下：
 *     -- favid         // string      Y   商品收藏ID（一般来源于上一步《添加收藏》返回的值）
 *
 * @return Promise
 */
GESHOP.removeCollection = (reqData = []) => serviceCollectRemove.http({
    data: { favId: reqData },
});


/**
 * 领取优惠券
 * @param couponCode        // string      Y   优惠券code
 * @param couponResource    // number      Y   优惠券渠道来源，默认：7
 * @param successTip        // boolean     N   是否启用默认成功提示，默认：true
 * @return Promise
 */
GESHOP.getCouponItem = getCouponItem;

// isLogin
GESHOP.isLogin = isLogin;

window.GESHOP = GESHOP;

if (window.geShopType === 'ads') {
    landingTrack();
} else {
    googleSubjectTrack();
}
