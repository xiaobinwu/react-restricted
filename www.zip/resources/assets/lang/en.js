/* eslint-disable */
var LANGUAGE = {
        user: {
            favorites_no_goods: 'You currently don\'t have any favorites.Add product to your favorites by clicking on the product page',
            favorites_no_store: 'You currently don\'t have any favorites.Add stores to your favorites by clicking on the product page',
            goods: 'Goods',
            stores: 'Stores',
            you_might_also_like: 'You Might Also Like',
            visit_store: 'Visit Store',
            remove: 'Remove',
            upload: 'upload',
            my_point: 'My Points',
            my_tickets_notice: 'Credit Value = Credits :#$1# \n:#$2# Points = 1 US dollar. You can use points for up to 30% of the Item Sub-total.',
            my_gb_wallet: 'My GB Wallet',
            edit_profile: 'Edit Profile',
            my_tickets: 'My Tickets',
            go_to_message: 'Go to Message',
            go_to_message_notice: '24h Customer Service,Order tracking , Shipping notification',
            my_point_: 'My Points',
            my_gb_wallet_: 'My GB Wallet',
            personal_information: 'Personal Information',
            upload_image: 'UPLOAD IMAGE',
            upload_tips: 'TIPS:Upload JPEG format image, 2MB maximum. Your image will be resized to 100*100 pixels.',
            name: 'Name',
            gender: 'Gender',
            sex_private: 'Private',
            sex_m: 'M',
            sex_f: 'F',
            mobile_phone: 'Mobile Phone',
            cancel: 'Cancel',
            save: 'Save',
            upload_profile_picture: 'Upload Profile Picture',
            reupload: 'Reupload',
            image_preview: 'Image Preview',
            change_password: 'Change Password',
            the_orginal_password: 'The original password',
            new_password: 'New Password',
            confirm_password: 'Confirm Password',
            submit_: 'Submit',
            address_book: 'Address Book',
            add_new_address: 'Add New Address',
            defult: 'Defult',
            set_for_defult_address: 'Set for defult address',
            submit: 'Submit',
            delete: 'Delete',
            frist_name: 'Frist Name',
            last_name: 'Last Name',
            e_mail_address: 'E-mail Address',
            please_select: 'Please select',
            address_line_one: 'Address Line 1',
            address_line_two: 'Address line 2',
            country_region: 'Country/Region',
            state_county: 'State / Country',
            address_city: 'City',
            phone_number: 'Phone Number',
            zip_postal_code: 'ZIP / Postal Code',
            make_this_defult_address: 'Make this my default address',
            cancel_: 'Cancel',
            save_: 'Save',
            unused_coupons: '可用优惠券',
            used_coupons: 'Used Coupons',
            expried_coupons: 'Expried Coupons',
            coupon_classify_by: 'Classify By',
            coupon_sort_by: 'Sort By',
            coupon_classify_all_type: 'All Type',
            coupon_classify_percentage_discount: 'Percentage Discount',
            coupon_classify_cash_discount: 'Cash Discount',
            coupon_classify_fixed_price: 'Fixed Price',
            coupon_sort_new: 'New Coupons',
            coupon_sort_expring: 'Expring Coupons',
            get_more_coupons: 'Get more Coupons',
            use_link: 'Use Link',
            msg_coupons_successfully_copoed: 'Coupons Successfully Copied',
            price_type_flash_sale: 'Flash Sale',
            price_type_presale: 'Presale',
            price_type_email_only: 'Email Only',
            price_type_all: 'All',
            price_type_accessories: 'Accessories',
            my_points__instruction: 'My Points:You have :#$1# points which equal :#$2# in store credit. Check out how to use them and get more points.',
            points_summary: 'Points Summary',
            points_gained: 'Points Gained',
            points_used: 'Points Used',
            date_used: 'Date Used',
            points_spent: 'Points Spent',
            saved: 'Saved',
            note: 'Note',
            get_points_daily_sign_in: 'Daily Sign-in',
            get_points_registered: 'Registered successfully and got :#$1# points(Expried on :#$2#)',
            my_review_notice: 'You can still earn an extra :#$1# points by submitting reviews for other products you have purchased. This is equal to :#$2# credit.',
            my_review_descrition: 'Descrition',
            my_review_goods_reviews: 'Goods Reviews',
            my_review_order_reviews: 'Order Reviews',
            my_review_order_amount: 'Order Amount',
            my_review_check_my_reviews: 'Chcek my reviews',
            my_review_write_my_reviews: 'Write my reviews',
            my_review_contact_us: 'Got any problem? Please contact us.',
            my_review_get_points: 'Get points',
            my_review_msg_net_work_timeout: 'Net work timeout, please try again later.',
            button_my_reviews: 'My Reviews',
            button_back_to_the_product: 'Back To The Product',
            msg_reviews_submitted: 'Your Reviews has been Submitted!',
            order_being_reviewed: 'ORDER BEING REVIEWED',
            rating_it_get_points: 'Rating it! You will get up to 5 GB points!',
            over_rating: 'Over Rating',
            your_reviews: 'Your Reviews',
            my_reviews_help_us_improve: 'Please wriite an honest review of your experience to help us improve.Thanks.(Please write at least 30 characters)',
            my_reviews_shipping_speed: 'Shipping speed',
            my_reviews_product_matched_descroption: 'Product matches description',
            ease_of_refunds_process: 'Ease of refunds process',
            customer_service_professionalism: 'Customer Service Professionalism',
            overall_returns_policy: 'Overall Returns Policy',
            submit_review: 'Submit Review',
            product_being_reviewed: 'PRODUCT BEING REVIEWED',
            write__product_review_get_points: 'Write a review for this product: Get 10 GB Points.',
            frist_reviews_get_double: 'First 5 Reviews get DOUBLE Points.',
            price_rating: 'Price Rating',
            ease_of_use_rating: 'Ease-of-use Rating',
            build_quality_rating: 'Build Quality Rating',
            usefulness_rating: 'Usefulness Rating',
            overall_rating: 'Overall Rating',
            my_reviews_name: 'Name',
            my_reviews_title: 'Title',
            my_reviews_pros: 'pros',
            my_reviews_cons: 'cons',
            no_more_than_3000_characters: 'Be detailed and specific, but no more than 3,000 characters.',
            upload_images_get_points: 'Upload Images: Get 20 GB Points',
            upload_video_get_points: 'Upload Video: Get 50-250 GB Points',
            provide_image_notice: 'Please provide image in JPEG, GIF or PNG. Width should be at least 500 px and height at least 600 px. All image sizes should not exceed 2 MB.',
            my_reviews_video_title: 'Video Title',
            my_reviews_video_url: 'Video URL',
            my_reviews_video_note: 'Please note the video:1. Should state you bought the product from us.2. YouTube text shows the product page URL.e.g.: https://www.youtube.com/watch?v=n3v4kTqF_w8',
            my_reviews_image_note: 'Please provide image in JPEG, GIF or PNG. Width should be at least 500 px and height at least 600 px. All image sizes should not exceed 2 MB.',
            my_reviews_goods_revieds_amount: ':#$1# reviews',
            my_reviews_submitted: 'Your review has been submitted',
            back_to_the_product: 'Back To The Product',
            address_delete: 'delete',
            address_comfirm: 'Comfirm',
            min_order: 'Min order',
            expired_time: 'Valid for *** days after receiving',
            num_left: '*** pieces left',
            take_coupon: 'Discover Deals',
            all_taken: 'All taken',
            coupon_expired: 'Expired'
        },
        login: {
            logged_out_notice: 'You are now logged out. Thank you and have a great day.',
            button_log_back_in: 'Log Back In',
            button_gearbest_home: 'Gearbest Home',
            shopping_made_easier_faster_and_safer: 'Shopping made easier, faster, and safer',
            download_our_cool_free_app:
                    'Download our Cool FREE App!',
            enjoy_app_exciusive_deals:
                    'Enjoy App-EXCLUSIVE Deals',
            email:
                    'Email',
            password:
                    'Password',
            keep_me_signed_in:
                    'Keep me signed in',
            link_forgot_your_password:
                    'Forgot your password?',
            please_enter_a_valid_email_address:
                    'Please enter a valid email address',
            provide_a_password:
                    'Provide a password',
            copyright_gearbestcom_all_rights_reserved:
                    'Copyright ©2014-2017 Gearbest.com All Rights Reserved.',
            button_sign_in:
                    'Sign In',
            or_connect_via:
                    'or connect via',
            password_is_at_least_6_characters:
                    'Password is at least 6 characters',
            password_again:
                    'Password again',
            enter_the_code:
                    'Enter the code',
            agree_to_gearbests:
                    'I agree to GearBest\'s Terms and Conditions and Privacy Policies',
            button_register:
                    'Register',
            repeat_your_password:
                    'Repeat your password',
            please_enter_the_correct_code:
                    'Please enter the correct code.',
            confirm_your_identity_to_reset_password:
                    'Confirm your identity to reset password',
            e_mail_address:
                    'E-mail address',
            access_code:
                    'Access code',
            continue:
                    'Continue',
            email_address_do_not_exist_please_re_enter:
                    'Email address do not exist, please re-enter！',
            button_previous_page:
                    'Previous page',
            button_home:
                    'Home',
            reset_system_information:
                    'System information',
            sorry_verification_code_incorrect:
                    'Sorry, the verification code you entered is incorrect.',
            sent_a_message_to_email_address_notice:
                    'We\'ve sent a message to the email address :#$1# you have on file with us.Please follow the instructions provided in the message to reset your password.',
            didnt_receive_the_mail_notice:
                    'Didn\'t receive the mail from us?Check your bulk or junk email folder.If you still can\'t find it, click support center for help',
            your_account_activated_successfully:
                    'Your account activated successfully!',
            activation_email_sent_notice:
                    'An activation email has been sent to you. Please follow the prompts to activate your customer account.',
            confirming_your_email_allows_you_to:
                    'Confirming your email allows you to',
            receive_free_welcome_gifts:
                    '• Receive free welcome gifts',
            manage_your_points_and_coupons:
                    '• Manage your points and coupons',
            view_billing_and_shipping_information:
                    '• View billing and shipping information',
            get_the_biggest_discounts:
                    '• Get the biggest discounts',
            check_your_order_status_and_order_history:
                    '• Check your order status and order history',
            manage_your_online_profile:
                    '• Manage your online profile',
            resend_activation_email:
                    'Resend Activation Email',
            have_not_received_the_verification_email:
                    'Haven’t received the verification email?',
            have_not_received_frist_notice:
                    '1. Check your spam or junk folder where the verification could be misclassified.',
            have_not_received_second_notice:
                    '2. In case of nondelivery, please consult Start Online Chat.',
            resent_successfully_check_account:
                    'Resent successfully. Please check your email bo :#$1# to activate your account.After :#$2# seconds, you can resend it again.'
        },
        blog: {
            gb_feature: 'GB Feature',
            new_gear:
                    'New Gear',
            how_to:
                    'How To',
            download:
                    'Download',
            buying_guide:
                    'Buying Guide',
            gearbestcom:
                    'GEARBEST.COM',
            what_are_you_looking_for:
                    'What are you looking for?',
            search:
                    'Search',
            see_more:
                    'See More',
            oops:
                    'Oops!',
            search_result_for_something:
                    'Search result for \":#$1#\"',
            search_result_fail:
                    'We couldn\'t find anything matching your search for \':#$1#\'Try a related item, a more general term, or you can leave us a message',
            download_all:
                    'All',
            download_firmwares:
                    'Firmwares',
            download_user_manuals:
                    'User Manuals',
            download_video_guides:
                    'Video Guides',
            how_to_all:
                    'All',
            how_to_xiaomi_gears:
                    'xiaomi Gears',
            how_to_phone_and_tablets:
                    'Phone & Tablets',
            how_to_computers_and_networking:
                    'Computers & Networking',
            how_to_electronics_and_tools:
                    'Electronics & Tools',
            how_to_home_and_garden:
                    'Home & Garden',
            how_to_sports_and_outdoors:
                    'Sports & Outdoors',
            how_to_entertainment:
                    'Entertainment',
            how_to_automotive_and_industrial:
                    'Automotive & Industrial',
            how_to_beauty_and_fashion:
                    'Beauty & Fashion',
            the_other_days_ago:
                    ':#$1# days ago',
            prev_article:
                    'Prev article',
            you_may_also_want_to_read:
                    'You may also want to read',
            you_might_also_like:
                    'You might also like',
            related_products:
                    'Related Products',
            buy_now:
                    'Buy Now',
            communtity_videos:
                    'COMMUNITY VIDEOS',
            video_view_more:
                    'View More'
        },
    
        order: {
            tab_my_orders: 'My orders',
            tab_unpaid:
                    'Unpaid',
            tab_dispatching:
                    'Dispatching',
            tab_partly_shipped:
                    'Partly Shipped',
            tab_not_received:
                    'Not Received',
            tab_no_comment:
                    'No Comment',
            tab_refunded_order:
                    'Refunded Order',
            product_name_or_number:
                    'Product name / number',
            you_have_no_order_yet:
                    'You have no order yet',
            go_shopping:
                    'Go Shopping',
            description:
                    'Description',
            unit_price:
                    'Unit Price',
            status:
                    'Status',
            order_list_subtotal:
                    'Subtotal',
            status_wait_for_payment:
                    'Wait for payment',
            status_pending:
                    'Pending',
            status_partialpay:
                    'Partial pay',
            status_paid:
                    'Paid',
            status_paid_unpacked:
                    'Paid',
            status_packed:
                    'Packed',
            status_partly_shipped:
                    'Partly shipped',
            status_shipped_out:
                    'Shipped out',
            status_delivered:
                    'Delivered',
            status_apply_for_refund:
                    'Apply for refund',
            status_refunding:
                    'Refunding',
            status_refunded:
                    'Refunded',
            status_cancelled:
                    'Cancelled',
            status_deleted:
                    'Deleted',
            split_order_notice:
                    'Note：We have split the order for you because of different warehouse',
            order_will_be_canceled_notice:
                    'Order will be canceled within :#$1# ,please submit payment as soon as possible.',
            order_canceledz_payment_not_received_notice:
                    'Note:Order canceled,payment not received withined :#$1#',
            price_type_flash_sale:
                    'Flash Sale',
            price_type_email_only:
                    'Email Only',
            price_type_accessory:
                    'Accessory',
            price_type_gift:
                    'Gift',
            price_type_add_on_item:
                    'Add-on item',
            button_order_detail:
                    'Detail',
            packed_notice:
                    'Your order ships soon ,Thank you so much for your patience.',
            delivered_notice:
                    'Delivered:Write a quick review now & get 5GB points',
            paid_notice:
                    'Paid：Your order ships soon , Thank you so much for your patience.',
            your_chosen_payment_method_notice:
                    'Your chosen payment method is: Wire Transfer .The payment amount is:*** \nSimply contact us at support center. We will help you to complete the payment process.\nThank you for your purchase.',
            dispatch_faster_notice:
                    '1. We process your order faster; it will leave our warehouse faster. \n2. We will not change shipping method, shipping speed is outside our control.',
            button_continue_to_pay:
                    'Continue to pay',
            button_continue_shopping:
                    'Continue Shopping',
            button_dispatch_faster:
                    'Dispatch Faster',
            button_confirm_receipt:
                    'Confirm Receipt',
            button_cancel:
                    'Cancel',
            button_contact_us:
                    'Contact us',
            button_review:
                    'Review',
            button_print_boleto_bancario:
                    'Print Boleto Bancario',
            are_you_sure_cancel_your_order:
                    'Are You Sure Cancel Your Order?',
            choose_order_cancel_reason:
                    'Please Choose the Reason Why You Cancel Your Order',
            please_select_a_aeason:
                    'Please Select a Reason',
            button_bubmit:
                    'Submit',
            i_have_made_wrong_orders:
                    'I have made wrong orders',
            i_cant_pay_for_my_orders:
                    'I can\'t pay for My orders',
            made_new_orders_because_i_have_found:
                    'Made new orders because I have found',
            i_dont_want_this_order:
                    'I don\'t want this order',
            i_find_some_great_deals_on_the_website:
                    'I find some great deals on the website',
            others:
                    'Others',
            date_package_arrived:
                    'Date Package Arrived:',
            notice_successed:
                    'Successed',
            dispatch_faster_failed_notice:
                    'Your \"Dispatch Faster\" request has failed due to server error.For any queries,please contact our Support Center',
            buttun_ok:
                    'OK',
            paid_cancel_note:
                    '我们正在给你配货，建议您稍等',
            paid_cancel_note_yes:
                    '取消订单',
            paid_cancel_note_no:
                    '等待发货',
            progress_bar_order_submitted:
                    'Order Submitted',
            progress_bar_payment_received:
                    'Payment Received',
            progress_bar_packed:
                    'Packed',
            progress_bar_split_delivery:
                    'Split Delivery',
            progress_bar_product_dispatch:
                    'Product Dispatch',
            progress_bar_apply_for_refund:
                    'Apply For Refund',
            progress_bar_refunding:
                    'Refunding',
            progress_bar_refunded:
                    'Refunded',
            order_detail_consignee_name:
                    'Consignee name',
            order_detail_contact_telephone:
                    'Contact telephone',
            order_detail_receipt_address:
                    'Receipt address',
            e_mail:
                    'E-mail',
            city:
                    'City',
            deliveries:
                    'Deliveries',
            state_county_province:
                    'State/County/Province',
            payment:
                    'Payment',
            pay_time:
                    'Pay time',
            country:
                    'Country',
            invoice:
                    'Invoice',
            zip:
                    'Zip',
            order_date:
                    'Order date',
            send_or_view_message:
                    'Send/View Message',
            item_sub_total:
                    'Item Sub-total',
            shipping_cost:
                    'Shipping Cost',
            insurance:
                    'Insurance',
            gb_points_disscount:
                    'GB Points Disscount',
            coupon:
                    'Coupon',
            promotion:
                    'Promotion',
            payment_discount:
                    'Payment discount',
            grand_total:
                    'Grand Total',
            track_order_number:
                    'Track order :#$1#',
            shippment_number:
                    'Shippment Number',
            tracking_number:
                    'Tracking Number',
            transfer_number:
                    'Transfer Number',
            referance_number:
                    'Referance Number',
            download_invoice:
                    'Download Invoice',
            trcking_message:
                    'Trcking message',
            inquiries_failed_notice:
                    'Inquiries failed,please visit the official website for logistics information',
            consignee_address:
                    'CONSIGNEE ADDRESS',
            date_of_exportation:
                    'DATE OF EXPORTATION',
            item_no:
                    'ITEM NO.',
            item_description:
                    'ITEM DESCRIPTION(FULL TITLE)',
            qty_pcs:
                    'QTY(PCS)',
            unit_value_usd:
                    'UNIT VALUE(USD)',
            total_value_usd:
                    'TOTAL VALUE(USD)',
            subtotal:
                    'Subtotal',
            shipping:
                    'Shipping',
            tracking:
                    'Tracking',
            invoice_notice:
                    'I/WE HEREBY CERTIFY THAT THE INFORMATION OF THIS INVOICE IS TRUE AND CORRECT,AND THAT THE CONTENTS OF THIS SHIPMENT ARE AS STATED ABOVE',
            bar_cart:
                    'Cart',
            bar_payment_:
                    'Payment & Shipping',
            bar_order:
                    'Place Order',
            shipping_information:
                    'Shipping Information',
            table_item:
                    'Notes: We hava spit the order for you because of different warehouse',
            table_price:
                    'Selected Items',
            table_num:
                    'Unit Price',
            table_total:
                    'Quantity',
            table_oper:
                    'Subtotal',
            goods_weight:
                    'Weight',
            shipping_options:
                    'Shipping Options',
            insurance_fee:
                    'Insurance',
            use_coupon:
                    'Use Coupon',
            use_points:
                    'Use GB Points',
            notice_shipping_title:
                    'What\'s The Total Delivery Time?',
            notice_shipping_content:
                    'Total Delivery Time = Processing Time + Packing Time + Shiping Time\n\nNote: To get a safe delivery,we recommend to buy insurance to guarantees your shipment. INthe event of verified shipping damage/loss, Gearbest will resend an identical parcel free of charge.',
            choose_coupon:
                    'Coupon',
            choose_points:
                    'GB Points',
            notice_coupon:
                    'Promotion Coupon',
            tips_coupon:
                    'Save More： You can use up to :#$1# GB points ( worth :#$1# [币种] :#$2# [金额]) from your account for a further discount.',
            estimate_points:
                    'I want to use :#$1# GB Points',
            item_subtotal:
                    'Item - subtotal',
            points_save:
                    'GB Points',
            coupon_save:
                    'Coupon',
            promotion_save:
                    'Promotion',
            shipping_fee:
                    'Shipping Cost',
            order_total:
                    'Grand Total',
            place_order:
                    'Place your order',
            notice_security:
                    'Every order you place with us is completely safe and secure.',
            demand_order:
                    'Order Requirement',
            dropping:
                    'Dropshipping',
            pay_succeed_1:
                    'We appreciate your shopping! Your order has been submitted successfully, please remember your order number:',
            pay_succeed_2:
                    'The payment amount is:',
            pay_succeed_3:
                    'Tips:Click Messenger, Get a chance to WIN a phone, And Track shipping At Anytime.',
            message_us:
                    'Go to Messenger',
            pay_succeed_4:
                    'Your order expires within 15 days.',
            pay_succeed_5:
                    'Simply contact us at support center. We will help you to complete the payment process.\nThank you for your purchase.\nOr you can return to Home or My Account',
            pay_succeed_6:
                    'Tips:Click Messenger, Get a chance to WIN a phone, And Track shipping At Anytime.'
        },
    
        base: {
            get_point: 'GET 60 FREE POINTS',
            register_subscribe:
                    'Register & Subscribe',
            top_globale_brands:
                    '100,000+ Epic Deals · TOP Globale Brands',
            full_warranty:
                    'FULL Warranty',
            anytime_support:
                    '24/7 Support',
            safe_shopping:
                    'SAFE Shopping',
            exclusives_deals:
                    'EXCLUSIVES Deals',
            latest_arrivals:
                    'LATEST Arrivals',
            best_promotions:
                    'BEST Promotions',
            sign_me_up:
                    'YES! Sign Me Up',
            data_always_safe:
                    'Your Personale Data is Always Safe With Us!',
            enter_email_address:
                    'Enter Your Email Address',
            get_cool_newsletter:
                    'Get Our Cool Newsletter',
            save_big_on_our_app:
                    'Save big on our app!',
            download_cool_free_app:
                    'Download our Cool FREE App!',
            enjoy_app_exclusive_deals:
                    'Enjoy App-EXCLUSIVE Deals',
            download_on_the_app_store:
                    'Download on the App Store',
            get_it_on_google_play:
                    'Get it on Google play',
            ship_to_place:
                    'Ship to :#$1#/:#$2#',
            select_regional_settings:
                    'Select Regional Settings',
            ship_to:
                    'Ship to',
            currency:
                    'Currency',
            quick_find:
                    'Quick Find',
            save:
                    'Save',
            language:
                    'Language',
            choose_language:
                    'Choose Language',
            live_chat:
                    'Live Chat',
            message_us:
                    'Message Us',
            one_stop_service:
                    'One stop service:solve all your problems',
            tracking_and_notification:
                    'Order Tracking and shipped out notification',
            more_campaigns_more_discounts:
                    'More campaigns More discounts',
            presale_live_chat:
                    'Presale Live Chat',
            need_help_before_order:
                    'Need help before making an order?',
            chat_in_real_time:
                    'Chat with us in real-time.',
            submit_a_ticket:
                    'Submit a Ticket',
            reply_within_one_day:
                    'For Aftersale issues, just submit a ticket. We will reply within 24 hours.',
            multi_language_service:
                    'Multi language service',
            anytime_service:
                    '24H service',
            country:
                    'Country',
            online_shopping:
                    'Online Shopping',
            more:
                    'More',
            product_keywords:
                    'Product keywords',
            recent_searches:
                    'Recent Searches:',
            clear_history:
                    'clear history',
            hot_searches:
                    'Hot Searches:',
            sign_in:
                    'Sign in',
            register_on_gearbest_earn_points:
                    'Register on GearBest: Earn 50 points',
            register:
                    'Register',
            hi_my_account:
                    'Hi, :#$1#\nMy Account',
            my_favorites:
                    'My Favorites',
            my_orders:
                    'My Orders',
            my_tickets:
                    'My Tickets',
            my_gb_wallet:
                    'My GB Wallet',
            my_points:
                    'My Points',
            my_profile:
                    'My Profile',
            my_coupon:
                    'My Coupon',
            my_share:
                    'My Share',
            logout:
                    'Logout',
            my_favorites_1:
                    'My Favorites',
            cart:
                    'Cart',
            items:
                    'Items(s)',
            total:
                    'Total',
            view_my_cart:
                    'View My Cart',
            cart_empty_sign_in:
                    'Your shopping cart is empty.Please Sign in.',
            shop_by_department:
                    'SHOP BY DEPARTMENT',
            daily_deals:
                    'Daily Deals',
            other_buyers_looking:
                    'What Other Buyers Are Looking At Right Now',
            related_items_viewed:
                    'Related to Items You\'ve Viewed',
            see_more:
                    'See More',
            buy_now:
                    'Buy now',
            ends_in:
                    'Ends In:',
            coming_soon:
                    'Coming soon',
            starts_in:
                    'Starts In:',
            ends_in_1:
                    'Ends In:',
            grab_it_now:
                    'GRAB IT NOW>>',
            download_free_app:
                    'Download our cool Free App!',
            mobile_site:
                    'Mobile Site',
            newsletter:
                    'Newsletter',
            enter_e_mail_get_points:
                    'Enter E-mail to get 10 points',
            subscribe:
                    'Subscribe',
            download_app:
                    'Download App!',
            download_on_app_store:
                    'Download on the App Store',
            messgae:
                    'Messgae',
            enter_valid_email_address:
                    'Please enter a valid email address.',
            check_email_and_get_points:
                    'Thank you for signing up. Please check your email and get the 10 points.',
            submission_frequency_too_high:
                    'Your submission of the frequency is too high!',
            e_mail_has_been_subscribed:
                    'E-mail::#$1# has been subscribed.',
            yes:
                    'Yes'
        },
    
        goodslist: {
            sort_by: 'Sort By:',
            discount_off:
                    ':#$1#%OFF',
            per_page:
                    'Per page:',
            prev:
                    'Prev',
            next:
                    'Next',
            go_to:
                    'Go To:',
            new_arrival:
                    'New Arrival',
            get_it_free:
                    'Get It Free',
            store:
                    'Store:',
            number_of_star:
                    ':#$1# star',
            add_to_favorites:
                    'Add to Favorites',
            coupons:
                    'Coupons',
            all_taken:
                    'All Taken',
            discover_deals:
                    'Discover Deals',
            have_expired:
                    'Have Expired',
            copy:
                    'Copy',
            already_claimed_yours:
                    'You have already claimed yours!',
            no_more_coupons_available:
                    'Sorry, no more coupons are available.',
            coupon_received:
                    'Coupon Received!',
            coupon:
                    'Coupon:',
            check_coupon_in_gb_account:
                    'Please check in your GB account - My coupon >',
            view_more:
                    'View More',
            view_less:
                    'View Less',
            all_products:
                    'All Products',
            on_sale_now:
                    'ON SALE NOW',
            coming_soon:
                    'COMING SOON',
            daily_deals:
                    'Daily Deals',
            start_time:
                    'Starts in',
            end_time:
                    'Ends in',
            grab_it_now:
                    'Grab it now',
            deals_title:
                    'Select Deals by Category',
            deals_cat:
                    'Categories',
            show_more:
                    'show more',
            sort_newest:
                    'Newest',
            sort_hottest:
                    'Hottest',
            sort_expiring:
                    'E***piring',
            sort_price:
                    'Price',
            sort_discount:
                    'Discount',
            deals_recently_viewed:
                    'Recently viewed',
            deals_end_time:
                    'Ends in'
        },
    
        goods: {
            choose_another_warehouse: 'Please choose another warehouse',
            warehouse:
                    'Warehouse',
            status:
                    'Status',
            price:
                    'Price',
            out_of_stock:
                    'Out of Stock',
            discontinue:
                    'Discontinue',
            sale:
                    'Sale',
            choose_another_warehouse_to_purchase:
                    'Tips: Since you did not select the current warehouse, please choose another warehouse to purchase.',
            brand:
                    'Brand:',
            number_of_customer_reviews:
                    '(:#$1# Customer Reviews)',
            number_of_answered_questions:
                    ':#$1# answered questions',
            ask_a_question:
                    'Ask a question',
            flash_sale_price:
                    'Flash Sale Price',
            email_only_price:
                    'Email Only Price',
            presale_price:
                    'Presale Price',
            number_of_notice_submitted:
                    ':#$1# Notice Submitted',
            number_of_notices_more:
                    ':#$1# Notices more',
            arrival_notice:
                    'Arrival Notice',
            stock_arrives_email_immediately:
                    'Once New Stock Arrives, We\'ll Email you immediately!',
            your_e_mail:
                    'Your E-mail:',
            e_mail_invalid:
                    'This E-mail appears to be invalid.',
            validation_code:
                    'Validation Code:',
            refresh:
                    'Refresh',
            the_code_is_incorrect:
                    'The code is incorrect!',
            submit:
                    'Submit',
            ok:
                    'OK',
            in_stock:
                    'in stock',
            one__pc_left:
                    '1 pc left',
            number_of_pcs_left:
                    ':#$1# pcs left',
            promotion:
                    'Promotion',
            gifts:
                    'Gifts',
            limited_quantity:
                    'Limited Quantity: Buy this product to receive FREE Gift Product(s).',
            view_gifts:
                    'View Gifts>>',
            gift:
                    'Gift',
            additional_purchase_deal:
                    'Additional Purchase Deal',
            additional_purchase_deal_rule:
                    'If Cart Subtotal exceeds $:#$1#, you can buy :#$2# Special Add-On for $:#$3#; spend over $:#$4# to buy :#$5# Add-On for $:#$6#. Discounts are automatically applied to shopping cart before checkout.',
            view_promo:
                    'View Promo>>',
            price_break_offer:
                    'Price Break Offer',
            price_break_offer_rule:
                    'Spend over $:#$1# on the featured products, get $:#$2# OFF. Spend over $:#$3#, get $:#$4# OFF. Discounts automatically applied to shopping cart before checkout.',
            combo_deal_price:
                    'Combo Deal Price',
            combo_deal_price_rule:
                    'Choose any :#$1#-unit combo from Featured Products, pay just $:#$2#. Choose any :#$3#-unit combo, pay just $:#$4#.',
            coupon:
                    'Coupon:',
            discount_off_over_price:
                    'X OFF Over X',
            end_time_h_m_s:
                    'End time: X/X/X',
            coupon_received:
                    'Coupon received!',
            already_claimed_yours:
                    'You have already claimed yours!',
            no_more_coupons_available:
                    'Sorry, no more coupons are available',
            view_more:
                    'View More',
            view_less:
                    'View Less',
            warehouse_options:
                    'Warehouse Options:',
            dispatch:
                    'Dispatch',
            ship_between_day_to_day:
                    'Ship between :#$1# - :#$2#',
            qty:
                    'QTY:',
            size_guide:
                    'Size Guide',
            shipping_cost:
                    'Shipping Cost:',
            shipping_methods:
                    'Shipping Methods',
            stock_in:
                    'Stock in:',
            ship_to:
                    'Ship to:',
            available_shipping_methods:
                    'Available shipping methods:',
            shipping:
                    'Shipping',
            estimated_shipping_time:
                    'Estimated Shipping Time',
            day_to_day_business_days:
                    ':#$1# - :#$2# business days',
            free_shipping:
                    'FREE SHIPPING',
            free_shipping_note:
                    'Please note: the standard and expedited shipping costs are only estimates; the actual shipping price will be shown on the order page.',
            buy_now:
                    'Buy Now',
            add_to_cart:
                    'Add to cart',
            add_to_favorites:
                    'Add to Favorites',
            tax_info:
                    'Tax Info',
            tax_information:
                    'Tax Information\nALL prices listed on GearBest exclude taxes, import fees, and customs duties. Customers may be subject to these fees.',
            i_understand_and_agree:
                    'I understand and agree',
            price_protection:
                    'Price Protection',
            price_protection_program:
                    '72 Hour Price Protection Program',
            price_protection_program_rule:
                    'At Gearbest we work hard to ensure we can offer our customers high quality products at the lowest possible price. If you\n purchase a Gearbest product and find that the price has dropped within 72 hours of paying the order, we will refund the\n difference - no questions asked. Simply contact our Customer Service team at our <a href=":#$1#" class="goodsPop_normalLink" target=":#$2#">Support Center</a> with the details. Please note that our 72 hours Price Protection Program does not apply to Flash Deal products.',
            price_disclaimer:
                    'Price Disclaimer',
            price_disclaimer_rule:
                    'Price DisclaimerPrices may fluctuate due to page caches, updates or sales ending; the most up-to-date price takes priority.',
            discount_off1:
                    'Discount : :#$1#% OFF',
            promo_ends_in_d_h_m_s:
                    'Promo ends in: :#$1#days :#$2#::#$3#::#$4#',
            pieces_left:
                    ':#$1# Pieces left',
            presale_starts:
                    'Presale Starts',
            pre_orders:
                    'Pre-Orders',
            presale_ends:
                    'Presale Ends',
            number_of_notices_submitted:
                    ':#$1# Notices submitted',
            save_for_using_app:
                    'Save an extra $:#$1# for using the App',
            save_for_using_app_rule:
                    'STEP 1\nScan the QR code to download our FREE App\nSTEP 2\nGet your App-Exclusive Discount now!\n1.Go to the page of the product you want to buy.\n2.Launch our app, scan the same QR code on product page to add to cart.\n3.Pay for your order for an immediate discount!',
            favourite_store:
                    'Favourite Store',
            visit_store:
                    'Visit Store',
            number_of_star:
                    ':#$1# Star',
            buy_together_save:
                    'Buy Together & Save',
            more:
                    'More',
            select:
                    'Select',
            total_price:
                    'Total Price:',
            you_save:
                    'You Save:',
            final_price:
                    'Final Price:',
            buy_together_save1:
                    'Buy Together & Save',
            recommended_products_for_you:
                    'Recommended Products for You',
            customers_also_bought:
                    'Customers Who Bought This Item Also Bought',
            description:
                    'Description',
            product_faq:
                    'Product FAQ',
            customers_reviews:
                    'Customers Reviews',
            shipping_payment:
                    'Shipping & Payment',
            wholesale_inquiry:
                    'Wholesale Inquiry',
            guess_you_like:
                    'Guess you like',
            faq_for_item:
                    'FAQ for :#$1#',
            customer_qusetions_answers:
                    'Customer Qusetions & Answers',
            all:
                    'All',
            product_information:
                    'Product Information',
            stock_status:
                    'Stock Status',
            payment:
                    'Payment',
            about_shipping:
                    'About Shipping',
            others:
                    'Others',
            faq_q:
                    'Q',
            faq_a:
                    'A',
            number_of_qusetions_answers:
                    ':#$1# Qusetions & Answers',
            view_all:
                    'View All>',
            name:
                    'Name:',
            e_mail:
                    'E-mail:',
            pre_sale_topic:
                    'Pre-sale topic:',
            please_select:
                    'Please Select ...',
            remaining_characters:
                    'Remaining characters:3000',
            first_to_ask_question:
                    'Be the FIRST to Ask a Question. Want GB Points? Just Write a Review!',
            prev:
                    'Prev',
            next:
                    'Next',
            go_to:
                    'Go To:',
            customer_reviews:
                    'Customer Reviews',
            overall_customer_rating:
                    'Overall Customer Rating:',
            base_on_customer_reviews:
                    'Base on :#$1# Customer Reviews',
            share_thoughts_with_other_customers:
                    'Share your thoughts with other customers',
            write_a_review:
                    'Write a Review',
            photos:
                    'Photos',
            videos:
                    'Videos',
            sort_by:
                    'Sort By:',
            hot:
                    'Hot',
            most_helpful:
                    'Most helpful',
            most_recent:
                    'Most recent',
            ease_of_use:
                    'Ease of Use',
            build_quality:
                    'Build Quality',
            usefulness:
                    'Usefulness',
            overall_rating:
                    'Overall Rating',
            pros:
                    'Pros:',
            cons:
                    'Cons:',
            is_this_helpful:
                    'Is this helpful?',
            yes:
                    'Yes',
            no:
                    'No',
            first_to_write_a_review:
                    'Get GB Points! Be the FIRST to Write a Review!',
            sponsored_products:
                    'Sponsored Products Related to This Item',
            your_target_price:
                    'Your Target Price:',
            enter_valid_number:
                    'Please enter a valid number.',
            order_quantity:
                    'Order Quantity:',
            country:
                    'Country:',
            your_name:
                    'Your Name:',
            your_tel:
                    'Your Tel:',
            include_country_code:
                    'please include country code',
            only_use:
                    'Please only use: numbers, +, -, or ()',
            provide_a_email:
                    'Provide a email',
            company_name:
                    'Company Name:',
            detailed_inquiry_information:
                    'Detailed Inquiry Information:',
            detailed_inquiry_information_rule:
                    'Please let us know as much as possible about your inquiry so that we can assist you with your specific needs. We are always happy to help wherever possible.',
            enter_min_characters:
                    'Please enter at least 6 characters',
            enter_no_more_than_max_characters:
                    'Please enter no more than 300 characters.',
            enquiry_submitted_and_reply:
                    'Your enquiry has been submitted and we will reply you within 24 hours, thank you!',
            your_recently_viewed_items:
                    'Your Recently Viewed Items',
            see_personalized_recommendations:
                    'See personalized recommendations',
            sign_in:
                    'Sign in',
            new_customer_start_here:
                    'New customer? Start here',
            number_of_reviews:
                    ':#$1# Reviews',
            view_product:
                    'View Product',
            wirte_a_review:
                    'Wirte a Review',
            base_on_number_of_customer_reviews:
                    'Base on :#$1# Customer Reviews',
            share_your_thoughts:
                    'Share your thoughts with other customers'
        },
    
        promotion: {
            top: 'TOP',
            all_taken:
                    'All Taken',
            discover_deals:
                    'Discover Deals',
            have_expired:
                    'Have Expired',
            copy:
                    'Copy',
            already_claimed_yours:
                    'You have already claimed yours!',
            no_more_coupons_available:
                    'Sorry, no more coupons are available.',
            coupon_received:
                    'Coupon Received!',
            coupon:
                    'Coupon:',
            check_coupon_in_gb_account:
                    'Please check in your GB account - My coupon >',
            sold_out:
                    'Sold Out',
            more_stock_soon:
                    'More Stock Soon',
            coming_soon:
                    'Coming Soon',
            buy_now:
                    'Buy Now',
            deals_ended:
                    'Deals Ended',
            some_items_insufficient_stock:
                    'Some Items Are Insufficient Stock',
            ends_in:
                    'Ends in:',
            number_of_pcs_left:
                    ':#$1# PCs left',
            after_coupon:
                    'After Coupon:',
            number_of_coupon_left:
                    ':#$1# Coupon left',
            total:
                    'Total:',
            you_save:
                    'You Save:',
            final_price:
                    'Final Price:',
            add_to_cart:
                    'Add to cart',
            promo_ends_in:
                    'Promo Ends In:',
            promo_start_in:
                    'Promo Start In:',
            limited_to_units:
                    'Limited to :#$1# Units'
        },
    
        cart: {
            ship_to: 'Ship to',
            bar_cart:
                    'Cart',
            bar_payment:
                    'Payment & Shipping',
            bar_order:
                    'Place Order',
            table_item:
                    'Selected Items',
            table_price:
                    'Unit Price',
            table_num:
                    'Quantity',
            table_total:
                    'Subtotal',
            table_oper:
                    'Operation',
            type_break_off:
                    'Price Break Offer',
            type_free_gift:
                    'Gift-with-purchase',
            type_purchase_deal:
                    'Additional Purchase Deal',
            type_deal_price:
                    'Combo Deal Price',
            rule_gift_with_purchase:
                    'Gift-with-purchase',
            rule_break_off:
                    'Spend over :#$1# :#$2# on the featured products, get :#$3#:#$4# OFF',
            rule_free:
                    'If Cart Subtotal exceeds :#$1# :#$2#, you can buy :#$1# Special Add-On-Item',
            rule_purchase_deal:
                    'Choose any :#$1# -unit combo from Featured Products, pay just :#$2# :#$3#',
            rule_deal_price:
                    'check redeem items',
            tip_purchase_deal:
                    'You can choose up to :#$1# pieces',
            tip_free_gift:
                    'You can choose up to :#$1# pieces',
            oper_edit:
                    'Edit',
            oper_add:
                    'Add to Cart',
            oper_fav:
                    'Favourite',
            oper_del:
                    'Delete',
            notice_price_title:
                    'Price Disclaimer',
            notice_price_content:
                    'Prices may fluctuate to page cahes,updates or sales ends; the most-up-to-date price takes priority.',
            notice_stock:
                    'Only :#$1# stock',
            notice_out_of_stock:
                    'Out of stock',
            all_select:
                    'Select all',
            all_del:
                    'Delete',
            all_fav:
                    'Add to Favourite',
            goods_expired:
                    'Expired',
            your_subtotal:
                    'Your subtotal',
            promotion_save:
                    'Promotion',
            grand_total:
                    'Grand total',
            guarantee_days:
                    ':#$1# days',
            guarantee_money_back:
                    'Money Back Guarantee',
            guarantee_free_repair:
                    'Free Repair Warranty',
            continnue_shipping:
                    'Continue Shopping',
            check_out:
                    'Proceed to Check out',
            we_accpet:
                    'we accept',
            notice_empty:
                    'Your shopping cart is empty',
            sign_in:
                    'Sign',
            go_shopping:
                    'Go Shopping',
            merge_title:
                    'You have qualified for a discount on additional cart items',
            merge_notice_purchase_deal:
                    'how to add on items？',
            items_for_merge:
                    'Items available to merge',
            merge_rule_purchase_deal:
                    'To qualify for the discount,the cart must contain item totals of',
            merge_purchase_deal_meet:
                    'Redeemtion conditions met, you can redeem items now',
            merge_purchase_not_meet:
                    '****** more and you are able to redeem items',
            merge_total:
                    'Total',
            view_cart:
                    'View My Cart',
            view_more:
                    'View More'
        }
    };
    
    