/**
 * Created by Liu Jun on 2019/3/19
 */

import $ from 'jquery';
import PubSub from 'pubsub-js';
import { serviceSubscribe } from 'js/service/common';
import layer from 'layer';
import footerTrack from 'js/track/define/footer.js';
import 'js/utils/validation.config.js';

const singleCase = {
    init() {
        this.bindEvent();
    },
    bindEvent() {
        /**
         * newletter subscrible validate
         */
        const $newsLetterForm = $('.js-newsLetter');
        const $formGroupInputEu = $('.js-formGroup-input-eu');
        $newsLetterForm.validate({
            rules: {
                email: {
                    required: true,
                    email: true,
                },
            }
        });

        $newsLetterForm.on('submit', (e) => {
            e.preventDefault();
            const $form = $(e.currentTarget);
            const $btn = $form.find('button');

            if ($form.valid()) {
                serviceSubscribe.http({
                    method: 'post',
                    data: {
                        email: $form.find('input').val(),
                        subscribedSource: 2,
                    },
                }).then((res) => {
                    layer.msg(res.msg);
                    $btn.removeClass('loading');
                });
            }
        });
        $formGroupInputEu.on('focus', (e) => {
            $('.js-gbform_input_tipsBox').show();
        });
        $formGroupInputEu.on('blur', (e) => {
            setTimeout(() => {
                $('.js-gbform_input_tipsBox').hide();
            }, 200);
        });

        /**
         * aside bar
         */
        if ($('.js-siteAside').length) {
            /**
             * scroll to top
             */
            $('.js-toTop').click(function toTop() { // eslint-disable-line prefer-arrow-callback
                $('html,body').animate({
                    scrollTop: 0,
                }, 1000);
            });

            /**
             *  aside link scroll to  specify section in home page
             */
            $('.js-asideLink').click(function sidelink() { // eslint-disable-line prefer-arrow-callback
                const $this = $(this);
                const index = $this.index();
                $('html,body').animate({
                    scrollTop: $('.indexLayer').eq(index).offset().top,
                });
            });

            const aside = $('.js-siteAside');
            PubSub.subscribe('nativeScroll', () => {
                if ($(window).scrollTop() > 300) {
                    aside.addClass('active');
                } else {
                    aside.removeClass('active');
                }
            });
        }
    }
};

PubSub.subscribe('nativeLoad', () => {
    singleCase.init();
    footerTrack();
});
