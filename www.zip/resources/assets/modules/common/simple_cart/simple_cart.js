import temp from './simple_cart.art';
import './simple_cart.css';

const simpleTemp = temp;

export default simpleTemp;
