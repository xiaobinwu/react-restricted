/**
 * 欧盟国家弹框显示GB会调用用户客户端cookie
 */
import { STORAGE_COOKIE_POLICY } from 'js/variables';
import { trans } from 'js/core/translate.js';
import { getCdnCountryCode } from 'js/core/currency';
import './cookie_policy.css';

export default async function generatorCookiePolicy() {
    const cookiePolicy = window.localStorage.getItem(STORAGE_COOKIE_POLICY);
    const countryCode = await getCdnCountryCode();
    const upperCountryCode = countryCode.toLocaleUpperCase();
    const europe = ['AT', 'BE', 'BG', 'CY', 'HR', 'TR',
        'CZ', 'DK', 'EE', 'FI', 'FR', 'DE',
        'GR', 'HU', 'IE', 'IT', 'LV', 'LT',
        'LU', 'MT', 'NL', 'PL', 'PT', 'RO',
        'SK', 'SI', 'ES', 'SE', 'GB', 'US'
    ];
    if (!cookiePolicy && europe.includes(upperCountryCode)) {
        const str = `
                <div class="cookiePolicy">
                    <div class="cookiePolicy-box">
                        <span class="cookiePolicy-tips">
                            <p class="cookiePolicy-tipsContent">
                                ${trans('base.cookie_policy', ['/about/cookie-policy.html'])}
                            </p>
                        </span>
                        <span class="cookiePolicy-close">
                            <i class="icon-close"></i>
                        </span>
                    </div>
                </div>
        `;
        $('.head').prepend(str);
        $('.cookiePolicy-close').click(() => {
            $('.cookiePolicy').remove();
            window.localStorage.setItem(STORAGE_COOKIE_POLICY, 1);
        });
    }
}

