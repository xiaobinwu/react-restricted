import PubSub from 'pubsub-js';
import smartPromise from 'js/utils/smartPromise.js';
import { getCountry, getCurrency, setCountry } from 'js/core/currency';

import './currency.css';

async function shipToInit() {
    await generateShipList();
    await generateCurrencyList();
}

// 获取国家码及货币信息
const getCountryCurrency = smartPromise(async () => {
    const [
        { countryCode },
        { currencyCode, currencySign, currencyName }
    ] = await Promise.all([getCountry(), getCurrency()]);

    return {
        countryCode,
        currencyCode,
        currencySign,
        currencyName
    };
});

// 生成到达国家列表
async function generateShipList() {
    const {
        countryCode
    } = await getCountryCurrency();

    const $select = $('.js-countrySelect');
    const $options = $select.find('option');
    const frequents = [];
    const countrys = [];

    $options.each((index, elem) => {
        const { frequent, countryName } = elem.dataset;
        if (countryName) elem.innerHTML = countryName;
        if (frequent === '1') {
            frequents.push({
                code: elem.value,
                name: elem.innerHTML,
            });
        }
        countrys.push({
            code: elem.value,
            name: elem.innerHTML,
        });
    });

    $select.combobox({
        data: [frequents, countrys],
        default: countryCode,
        onComplete($elem) {
            $elem.select({
                searchable: [$elem.find('optgroup').length || 1],
                skin: 'select-country'
            });

            shipListEvent();
        },
    });
}

// 寄送国家面板事件
function shipListEvent() {
    // select切换寄送国家地区
    $('.js-countrySelect').on('change', (e) => {
        const $this = $(e.currentTarget);
        const countryCode = $this.val();
        const countryName = $this.find('option:selected').text();

        // 发布变更寄送地区成功
        PubSub.publish('sysUpdateCountry', {
            gb_countryCode: countryCode,
            gb_countryName: countryName,
        });

        // 汇总更新
        updateShipCurrency();

        // 设置寄送地区
        setCountry(countryCode);

        // 针对于搜索分类页排序规则：'recommend' 'relevance' 用户自定义发货国家刷新当前页
        try {
            if ($('.js-orderItem').data('order-key') === 1) window.location.reload();
        } catch (error) {
            // error
        }
    });
}

// 生成货币列表
async function generateCurrencyList() {
    const temp = await import('./currency.art');
    const {
        currencyCode,
        currencySign,
        currencyName
    } = await getCountryCurrency();

    $('#js-listHeadCurrency').replaceWith(temp({
        currency: window.EXCHANGERATE,
        defaultCurrencyCode: currencyCode,
        defaultCurrencySign: currencySign,
        defaultCurrencyName: currencyName,
    }));

    // 初始更新货币label显示
    currentCurrencyShow(currencySign, currencyCode);

    // 初始绑定货币列表事件
    currencyListEvent();
}

// 货币列表面板事件
function currencyListEvent() {
    $('#js-panelHeadCurrency').on('click', '.js-itemHeadCurrency', (e) => {
        const $this = $(e.currentTarget);
        const sign = $this.data('sign');
        const code = $this.data('code');

        $('#js-labelHeadCurrency').text(`${sign} ${code}`);

        // 更新货币
        PubSub.publish('sysUpdateCurrency', {
            currencyCode: code,
        });

        // 更新货币label显示
        currentCurrencyShow(sign, code);

        // 汇总更新
        updateShipCurrency();
    });
}

// 更新货币label显示
function currentCurrencyShow(currencySign, currencyCode) {
    $('#js-labelHeadCurrency').text(`${currencySign} ${currencyCode}`);
    $('#js-panelHeadCurrency').find(`li[data-code=${currencyCode}]`).addClass('active').siblings()
        .removeClass('active');
}

// 汇总更新寄送地区或货币
function updateShipCurrency() {
    PubSub.publish('sysUpdateCurrencySuccess');

    setTimeout(() => {
        $('.clickShow .compDropdown-panel').css('display', 'none');
    }, 16);
}

export {
    shipToInit,
    getCountryCurrency,
    generateShipList,
    generateCurrencyList
};
