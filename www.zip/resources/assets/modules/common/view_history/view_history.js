import GoodsViewHistory from 'js/core/goods/GoodsViewHistory';
import temp from './view_history.art';
import './view_history.css';

const listData = GoodsViewHistory.get();
$('#js-goodsViewHistory').html(temp(listData));
