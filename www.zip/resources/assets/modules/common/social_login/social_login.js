/**
 * 公用头部第三方登录
 * 2019-01-28 17:31:42
 */
import Cookies from 'js/utils/cookie';
import { getTimezone } from 'js/utils/index.js';
import layer from 'layer';

import {
    serviceSocialLogin, // 异步登录
    serviceSocialCheck, // 检测第三方是否绑定
    servicePassportInit, // 检测是否欧盟
    serviceSocialLoginUrl, // 获取第三方登录界面地址
} from 'js/service/auth.js';

// 样式用于欧盟协议确认弹窗
import '../../../pages/auth/module/checkbox.css';

class SocialLogin {
    constructor(type) {
        // 第三方登录类型 1：facebook 2：google plus
        this.type = type;

        // 第三方登录参数
        this.ajaxData = {
            type,
            timeZone: getTimezone(),
            userCenterSuffix: window.location.hash
        };

        this.init();
    }

    async init() {
        // 创建弹窗
        this.createWindow();

        // 填充弹窗地址
        this.popWindow.location.href = await this.getLoginPageUrl(this.type);

        // 监听弹窗关闭时
        this.onPopWindowClose();
    }

    // 创建登录弹层
    createWindow() {
        const popWinWidth = 700;
        const popWinHeight = 400;
        const winWidth = $(window).width();
        const winHeight = $(window).height();
        const popWinleft = (winWidth - popWinWidth) / 2;
        const popWintop = (winHeight - popWinHeight) / 2;

        this.popWindow = window.open('', 'newwindowsss', `
            toolbar = no, 
            menubar = no, 
            scrollbars = no, 
            resizable = no, 
            location = no, 
            status = no, 
            titlebar = yes, 
            alwaysRaised = yes, 
            width=${popWinWidth}, 
            height=${popWinHeight},
            top=${popWintop},
            left=${popWinleft}`);

        return this.popWindow;
    }

    /**
     * 获取登录界面地址（第三方）
     * @param type
     * 1: facebook
     * 2: google plus
     */
    async getLoginPageUrl(type) {
        if (!type) {
            return '';
        }

        const res = await serviceSocialLoginUrl.http({
            data: {
                type
            },
        });

        return res.data.loginUrl || '';
    }

    // 第三方异步登录
    async ajaxSocialLogin() {
        const self = this;

        const res = await serviceSocialLogin.http({
            data: self.ajaxData,
        });

        if (+res.status === 0) {
            if (res.data && res.data.redirectUrl) {
                window.location.href = res.data.redirectUrl;
            } else {
                window.location.href = window.GLOBAL.DOMAIN_MAIN || '/';
            }
        } else if (Number(res.data.innerCode) === 70051) { // 未绑定邮箱
            // 取绑定邮箱地址
            if (res.data.email) {
                self.ajaxData.email = res.data.email;
            }

            // 绑定邮箱逻辑
            const { default: bindEmail } = await import('../../../pages/auth/sign_in/component/bind_email/bind_email.js');
            bindEmail(self.ajaxData);
        } else {
            layer.msg(res.msg);
        }
    }

    // 轮循检测弹窗的关闭
    onPopWindowClose() {
        const self = this;

        // 获取第三方登录加密串
        function getLoginCookie() {
            if (Cookies.get('sing_code')) {
                self.ajaxData.code = Cookies.get('sing_code');
                Cookies.set('sing_code', null, { expires: 0 });
                return true;
            } else if (Cookies.get('sing_token')) {
                self.ajaxData.token = Cookies.get('sing_token');
                Cookies.set('sing_token', null, { expires: 0 });
                return true;
            }

            return false;
        }

        // 轮循检测弹窗关闭
        async function loopCheckClosed() {
            if (self.popWindow.closed) {
                clearInterval(loop);

                if (getLoginCookie()) { // 已获取到加密串
                    // // CSRF攻击防御
                    // const token = '_token';
                    // this.ajaxData[token] = $('input[name=_token]').val();

                    if (await self.checkIsEU()) { // 欧盟
                        self.checkIsBindSocial();
                    } else { // 直接登录
                        self.ajaxSocialLogin();
                    }
                }
            }
        }

        const loop = setInterval(() => {
            loopCheckClosed();
        }, 200);
    }

    // 检测是否欧盟用户登录
    async checkIsEU() {
        // 获取是否欧盟
        const res = await servicePassportInit.http();

        if (res.status !== 0) {
            layer.msg(res.msg);
            return false;
        }

        // 如若是欧盟
        return Number(res.data.isEU) === 1;
    }

    // 检测第三方是否绑定
    async checkIsBindSocial() {
        const self = this;

        const check = await serviceSocialCheck.http({
            data: self.ajaxData
        });

        if (check.status === 0) { // 已绑定，直接登录
            self.ajaxSocialLogin();
        } else if (check.data.innerCode === 70017) { // 用户不存在，要求确认协议后绑定账号
            self.tipConfirmForEU();
        } else {
            layer.msg(check.msg);
        }
    }

    // 欧盟新用户绑定第三方账号 确认弹窗
    async tipConfirmForEU() {
        const preLayer = layer.open({
            content: $('.js-prejudging'),
            type: 1,
            offset: '250px',
            area: '550px',
            btn: 0,
            shadeClose: 0,
            closeBtn: 1
        });

        // 协议确认表单
        const $formConfirmPolicy = $('#js-prejudgingForm');

        // 开启验证
        $formConfirmPolicy.validate({
            rules: {
                agree: {
                    required: true,
                },
                confirm: {
                    required: true,
                }
            }
        });

        // 提交表单
        $formConfirmPolicy.on('submit', (e) => {
            e.preventDefault();
            if ($formConfirmPolicy.valid()) {
                layer.close(preLayer);
                this.ajaxSocialLogin();
            }
        });
    }
}

export default SocialLogin;
