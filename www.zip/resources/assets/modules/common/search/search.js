/**
 * 顶部搜索区功能 2019-01-13 15:02:11 luochongfei
 * 0.过滤功能函数+CONFIG全局配置
 * 1.左侧分类下拉区处理 @searchCate
 * ----0.分类下拉变更处理
 * ----1.设置当前页面分类ID
 * 2.搜索框区处理 @searchInput
 * ----0.获取搜索框的值 getVal
 * ----1.输入框正在输入时处理
 * ----2.暗文相关处理
 * ----3.推荐词面板相关处理
 * ----4.推荐词面板上下按钮处理
 * 3.主要逻辑处理 @headSearch
 * ----0.搜索提交处理
 * ----1.搜索链接处理
 */
import { throttle } from 'js/utils/index';
import SearchHistory from 'js/core/SearchHistory.js';
import { serviceSearch, serviceGetDark } from 'js/service/common.js';
import tempSearchHelp from './search_help_panel.art';
import './search.css';
import './search_help_panel.css';

// 搜索关键词过滤
function searchFilter(kwVal) {
    kwVal = kwVal.replace(/\*/g, '~~');
    kwVal = kwVal.replace(/\|/g, ']]');
    kwVal = kwVal.replace(/=/g, '((');
    kwVal = kwVal.replace(/"/g, ' ');
    kwVal = kwVal.replace(/</g, '))');
    kwVal = kwVal.replace(/>/g, ')))');
    kwVal = kwVal.replace(/\?/g, '!!!');
    kwVal = kwVal.replace(/\+/g, '__');
    kwVal = kwVal.replace(/-/g, '^^');
    kwVal = kwVal.replace(/\//g, '..');
    kwVal = kwVal.replace(/\\/g, '...');
    kwVal = kwVal.replace(/%/g, '!!');
    kwVal = kwVal.replace(/#/g, '~~~');
    kwVal = kwVal.replace(/>/g, '___');
    kwVal = kwVal.replace(/</g, '^^^');
    kwVal = kwVal.replace(/"/g, '[[');
    kwVal = kwVal.replace(/\$/g, '[[[');
    kwVal = kwVal.replace(/@/g, ' ');
    kwVal = kwVal.replace(/\s+/g, '-');
    return encodeURIComponent(kwVal);
}

// 当前模块全局配置项
const CONFIG = {
    // 用于搜索的分类 ID
    catId: 0,

    // 推荐分类搜索链接
    recomCateSearchHref: '',
};

// 搜索按钮
const $btnSubmitSearch = $('#js-btnSubmitSearch');

// 地址栏获取分类
const hrefCatId = window.location.pathname.match(/c_([^/]*)/);


// 搜索分类区处理
const $selSearchCateList = $('#js-selSearchCateList');
const searchCate = {
    init() {
        // 初始设置当前页面分类ID
        this.setCurrentCatId();

        this.bindEvent();
    },

    bindEvent() {
        // 搜索分列下拉列表
        $selSearchCateList.select({
            skin: 'headSearch-catelist',
            onDropdownOpen() {
                // $('.js-labelBtnSearchCate').addClass('_dropdown');
            },
            onDropdownClose() {
                // $('.js-labelBtnSearchCate').removeClass('_dropdown');
            }
        }).on('change', (e) => {
            this.selCateChange();
        });
    },

    // 分类下拉变更时
    selCateChange() {
        const selTxt = $selSearchCateList.find('option:selected').text();
        const selId = $selSearchCateList.val();

        // 变更分类可视文本
        if (selTxt && selTxt.length) {
            $('.headSearch_cateLabel').text(selTxt);
            // 变更全局分类ID
            CONFIG.catId = selId;
        }

        // 变更分类时，重新拉取暗文
        searchInput.getDarkwordList();
    },

    // 设置当前页面分类ID
    setCurrentCatId() {
        if (hrefCatId && hrefCatId[1]) {
            CONFIG.catId = hrefCatId[1];

            // 分类下拉对应选中
            $selSearchCateList.val(hrefCatId[1]);
            this.selCateChange();
        }
    }
};


// 搜索框区处理
const $panelSearchForm = $('#js-formSearch'); // 搜索表单
const $iptKeyword = $('#js-iptKeyword'); // 搜索输入框
const $panelDarkword = $('#js-panelDarkword'); // 暗文面板
const $panelSearchHelp = $('#js-panelSearchHelp'); // 推荐
const searchInput = {
    darkwordArr: [], // 暗文数据集
    darkwordIndex: 0, // 暗文当前显示序号
    darkTimer: 0, // 暗文定时器

    isFocus: false, // 输入框是否聚焦

    currentKeyIndex: -1, // 上下键选词

    init() {
        // 分类页|分类搜索页因为要先获取地址栏分类ID，然后才用分类ID去拉暗文
        if (!(hrefCatId && hrefCatId[1])) {
            // 初始拉取暗文数据
            this.getDarkwordList();
        }

        this.bindEvent();
    },


    bindEvent() {
        // 输入框操作
        $iptKeyword
            .on('input', throttle(() => {
                this.isFocus = true;
                this.onInputEvent();
            }, 300))
            .focus(() => { // 聚焦时
                this.isFocus = true;
                this.handleSearchHelpPanel(); // 显示推荐词面板
                this.pauseLoopDarkword(); // 停止自动切暗文
            })
            .blur(() => { // 失焦时
                this.isFocus = false;
                this.startLoopDarkword(); // 开始自动切暗文
            });

        // 点击页面关闭推荐面板
        $(document).on('mousedown', (e) => {
            const $target = $(e.target);

            if ($target.closest('#js-panelSearchHelp').length === 0 && $target.closest('#js-formSearch').length === 0) {
                $panelSearchHelp.removeClass('active');
                if (serviceSearch.cancel) {
                    serviceSearch.cancel();
                }
            }
        });

        // 搜索框区点击
        $panelSearchForm.on('click', '.js-btnClearAllHistory', () => { // 清空所有搜索历史
            SearchHistory.removeAll();
            $panelSearchForm.find('.js-panelSearchHistory').remove();
        }).on('click', '.js-btnClearItemHistory', (e) => { // 清空单个搜索历史
            const $this = $(e.currentTarget);
            const val = $this.siblings('span').text();
            const len = SearchHistory.remove(val);

            if (!len) {
                $panelSearchForm.find('.js-panelSearchHistory').remove();
            } else {
                $this.parent('li').remove();
            }
        }).on('click', '.siteSearch_historyLink', (e) => { // 点击搜索历史关键词
            const $this = $(e.currentTarget);
            this.toggleDarkworkPanel('hide');
            $iptKeyword.val($this.text());
            headSearch.searchSubmit();
        });

        // 推荐词面板区上下按键选词
        $(window).on('keydown', (e) => {
            if (!this.isFocus || e.defaultPrevented) return;
            const { keyCode } = e;
            if (keyCode === 38) { // ↑
                this.keySelhelpPanel('up');
            }
            if (keyCode === 40) { // ↓
                this.keySelhelpPanel('down');
            }
            if (keyCode === 27) { // Esc 关闭推荐词面板
                this.toggleSearchHelpPanel('hide');
                this.isFocus = false;
            }
        });
    },

    // 获取搜索框的值
    getVal() {
        const val = $iptKeyword.val();
        const keyword = val.trim() ? val.trim() : null;
        return keyword;
    },

    // 搜索框输入时执行事件
    onInputEvent() {
        const keyword = this.getVal();
        const hasKeyword = keyword && keyword.length; // 是否输入了关键词

        // 是否启用暗文搜索 标识
        this.toggleDarkFlag(hasKeyword);

        // 暗文面板切换
        this.toggleDarkworkPanel(hasKeyword ? 'hide' : 'show');

        // 推荐词面板显隐处理
        this.handleSearchHelpPanel();
    },

    // 远端拉取暗文数据集合
    async getDarkwordList() {
        // 全球站 且 有暗文面板时
        if (window.GLOBAL.PIPELINE === 'GB' && $panelDarkword.length) {
            this.pauseLoopDarkword();
            const { data, status } = await serviceGetDark.http({
                params: {
                    'cat-id': CONFIG.catId
                },
            });
            this.darkwordArr = status === 0 ? data : [];
            this.startLoopDarkword();
        }
    },

    // 开始自动切换暗文
    startLoopDarkword() {
        const len = this.darkwordArr.length;
        if (len === 0) return;

        const loop = () => {
            // 获取暗文名称和链接
            const { name, url } = this.darkwordArr[this.darkwordIndex];
            $panelDarkword.html(name).attr('data-href', url);

            // 循环切换
            this.darkTimer = setTimeout(() => {
                $btnSubmitSearch.attr('data-dark', 1);
                this.darkwordIndex = (this.darkwordIndex + 1) % len;
                loop();
            }, 5000);
        };
        loop();
    },

    // 暂停自动切换热搜词
    pauseLoopDarkword() {
        clearTimeout(this.darkTimer);
    },

    // 切换显示暗文面板
    toggleDarkworkPanel(flag = 'hide') {
        if ($panelDarkword.length) {
            $panelDarkword[flag]();
        }
    },

    // 切换暗文标识
    toggleDarkFlag(hasKeyword) {
        $btnSubmitSearch.attr('data-dark', hasKeyword ? 0 : 1);
    },

    // 远端摘取搜索推荐|模糊匹配 数据集合
    async getSearchHelpList() {
        const res = await serviceSearch.http({
            params: {
                keyword: searchInput.getVal() || '',
                cate_id: CONFIG.catId,
                page_type: window.GLOBAL.PAGETYPE,
            }
        });
        return res.data || [];
    },

    // 推荐词面板显隐
    toggleSearchHelpPanel(flag = 'hide') {
        if ($panelSearchHelp.length) {
            const flagCfg = {
                show: 'addClass',
                hide: 'removeClass'
            };
            $panelSearchHelp[flagCfg[flag]]('active');
        }
    },

    // 推荐关键词面板处理
    async handleSearchHelpPanel(hasKeyword = false) {
        // 先清空分类推荐搜索
        CONFIG.recomCateSearchHref = '';
        // 重置推荐面板上下按钮序号
        this.currentKeyIndex = -1;

        const history = SearchHistory.get();
        const keyword = this.getVal();
        let type = 'suggest'; // 默认是模糊推荐词类型
        let resData = await this.getSearchHelpList(); // 远端拉取推荐词

        if (!(resData instanceof Array)) {
            return;
        }

        // 未输入关键词时
        if (!keyword || !keyword.length) {
            // 排除历史搜索词
            resData = resData.filter(el => !history.includes(el.name)).slice(0, 6);
            // 类型为热搜词
            type = 'hot';
        }

        // 过滤后还有数据 或 有搜索历史记录
        if (resData.length > 0 || history.length > 0) {
            // 填充面板
            $panelSearchHelp.html(tempSearchHelp({
                type,
                history,
                data: resData,
            }));
            // 显示面板
            this.toggleSearchHelpPanel('show');
        } else { // 否则推荐词隐藏面板
            this.toggleSearchHelpPanel('hide');
        }
    },

    // 上下按键选推荐词
    keySelhelpPanel(direction = 'down') {
        // 隐藏暗文面板
        this.toggleDarkworkPanel('hide');

        const $keyRows = $panelSearchHelp.find('.js-searchItem_link'); // 可选词数量
        const maxIndex = $keyRows.length - 1; // 向下键最大可到序号

        // 上下键确定序号
        if (direction === 'down') { // 向下
            this.currentKeyIndex = this.currentKeyIndex === maxIndex ? 0 : this.currentKeyIndex + 1;
        } else if (direction === 'up') { // 向上
            this.currentKeyIndex = this.currentKeyIndex === 0 ? maxIndex : this.currentKeyIndex - 1;
        }

        // 当前选中行
        const $currentRow = $keyRows.eq(this.currentKeyIndex);

        // 当前选中词高亮
        $keyRows.removeClass('active');
        $currentRow.addClass('active');

        // 当前选中项中的历史记录项
        const $currentHistory = $currentRow.find('.siteSearch_historyLink');

        // 获取到搜索词
        let searchText = $currentHistory.length ? $currentHistory.text().trim() : $currentRow.text().trim();

        // 若当前项是带分类进行搜索
        if ($currentRow.hasClass('siteSearch_link-cate')) {
            // 从分类搜索中 获取到关键词
            const searchCateVal = $currentRow.html().split('<em>')[0] || '';
            searchText = searchCateVal.trim();

            // 将选中项作为搜索
            CONFIG.recomCateSearchHref = $currentRow.attr('href');

        } else {
            CONFIG.recomCateSearchHref = '';
        }

        // 将搜索词填入到输入框中
        $iptKeyword.val(searchText);

        // 让输入焦点在输入框的最后
        setTimeout(() => {
            $iptKeyword.get(0).setSelectionRange(searchText.length, searchText.length);
        }, 16);
    }
};


// 搜索主功能
const headSearch = {
    init() {
        // 搜索分类处理
        searchCate.init();

        // 搜索框处理
        searchInput.init();

        this.bindEvent();
    },

    bindEvent() {
        // 表单提交
        $('#js-formSearch').on('submit', (e) => {
            e.preventDefault();
            this.searchSubmit();
        });
    },

    // 搜索提交
    searchSubmit() {
        const searchHref = this.getSearchHref();

        if (searchHref) window.location.href = searchHref;
    },

    // 获取搜索链接
    getSearchHref() {
        // 有分类推荐搜索链接
        if (CONFIG.recomCateSearchHref) {
            return CONFIG.recomCateSearchHref;
        }

        const keywordVal = searchInput.getVal(); // 过滤后的关键词
        const recomSearchHref = $panelDarkword.attr('data-href'); // 推荐搜索链接

        let resultHref = '';

        if (keywordVal) { // 优先关键词搜索
            // 记录 用作 搜索历史
            SearchHistory.set(keywordVal);

            // 普通搜索
            resultHref = `${GLOBAL.DOMAIN_MAIN}/${searchFilter(keywordVal)}-_gear/`;

            // 选择了分类 再搜索
            if (+CONFIG.catId !== 0) {
                resultHref += `c_${CONFIG.catId}/`;
            }

        } else if (recomSearchHref) { // 无用户关键词走推荐搜索
            resultHref = recomSearchHref;
        }

        return resultHref;
    }
};


export default headSearch;
