import PubSub from 'pubsub-js';
import 'component/select/select.js';
import 'component/combobox/combobox';
import runtime from 'art-template/lib/runtime';
import { trans } from 'js/core/translate.js';
import {
    deleteFromCart,
    closeTinyCart,
} from 'js/core/goods/cart.js';
import { getCountry, getCurrency } from 'js/core/currency';
import { shipToInit } from 'modules/common/ship_to/ship_to.js';

import headerTrack from 'js/track/define/header';

import './base_header.css';

runtime.trans = trans;

// 顶部埋点
headerTrack();

// 头部初始化
function headInit() {
    // 订阅 shipto & currency
    shipCurrency();

    // 订阅 购物车
    simpleCart();

    // 订阅 google翻译
    googleTranslate();

    // 绑定事件
    bindEvent();

    // moduleSearchInput.init();
}

// 事件绑定
function bindEvent() {
    function hideDropdownPanel() {
        $('.clickShow .compDropdown-panel').hide();
    }

    // 点击页面，关闭所有浮层
    $(document).on('click', (e) => {
        hideDropdownPanel();
    });

    // 浮层内点击
    $('.compDropdown.clickShow').on('click', (e) => {
        e.stopPropagation();

        const $this = $(e.currentTarget);
        const logic = $this.data('logic');

        // 隐藏所有浮层
        hideDropdownPanel();

        // 显示当前内容面板
        $this.find('.compDropdown-panel').show();

        PubSub.publish('head.itemClick', {
            logic,
            $el: $this,
            $tar: $(e.target)
        });
    });

    // 浮层hover
    $('.compDropdown.hoverShow').on('mouseenter', (e) => {
        const $this = $(e.currentTarget);
        const logic = $this.data('logic');

        if (!$this.hasClass('hoverShow')) {
            return;
        }

        // 隐藏所有浮层
        hideDropdownPanel();

        // 显示当前内容面板
        $this.find('.compDropdown-panel').show();

        PubSub.publish('head.itemHover', {
            logic,
            $el: $this,
        });
    });

    // st 购物车点击事件
    const { CART_THEME_TYPE } = window.GLOBAL;

    if (CART_THEME_TYPE === 2) {
        let init = false;
        const tinyCartBtn = $('#js-tinyCartBtn');
        const tinyCartWrap = $('#js-tinyCartWrap');
        const panelUserInfo = $('#js-panelUserInfo');
        tinyCartBtn.on('click', (e) => {
            const tinyCartVisible = +tinyCartBtn.attr('visible');
            e.stopPropagation();

            if (!tinyCartVisible) {
                tinyCartBtn.attr('visible', 1);
                tinyCartWrap.show();
                setTimeout(() => {
                    tinyCartWrap.addClass('visible');
                    if (!init) {
                        init = true;
                        PubSub.publish('sysUpdateSampleCart');
                    }
                });
            } else {
                closeTinyCart();
            }
        });

        tinyCartWrap.on('click', (e) => {
            e.stopPropagation();
        });

        panelUserInfo.on('mouseenter', closeTinyCart);

        $(document).on('click', closeTinyCart);
    }

    // 第三方登录
    $(document).on('click', '.js-btnHeadSocialLogin', async (e) => {
        const $this = $(e.currentTarget);

        const { default: SocialLogin } = await import('../common/social_login/social_login.js');
        new SocialLogin($this.attr('data-type'));
    });

    // 一级菜单滑过，懒加载分类面板右侧图片
    let cateItemTimer = null;
    $('.headCate_item').on('mouseenter', (e) => {
        const $this = $(e.currentTarget);
        const $childImg = $this.find('.js-cateChildImg');

        if (+$childImg.data('loaded') !== 1) {
            clearTimeout(cateItemTimer);
            cateItemTimer = setTimeout(() => {
                $childImg.data('loaded', 1);
                $childImg.attr('src', $childImg.attr('data-custom-lazy'));
            }, 200);
        }
    }).on('mouseleave', () => {
        clearTimeout(cateItemTimer);
    });

    // 初始更新货币
    PubSub.publish('sysUpdateCurrencySuccess');

    // 初始更新用户信息(用户名|收藏数|购物车数)
    PubSub.publish('sysUpdateUserInfo');

    // 初始更新购物车
    // PubSub.publish('sysUpdateSampleCart');
}

// shipto 和 currency处理
function shipCurrency() {
    // 订阅货币更新
    PubSub.subscribe('sysUpdateCurrencySuccess', async (msg, data) => {
        const [
            { countryName, countryCode },
            { currencyCode, currencySign }
        ] = await Promise.all([getCountry(), getCurrency()]);

        if (countryCode) {
            // 国家简码小写
            const flagName = countryCode.toLowerCase();
            // 国旗src
            const flagSrc = `https://uidesign.gbtcdn.com/GB/app/2018/flag_png/${flagName}.png`;

            const domLabelShipTo = document.getElementById('js-labelShipTo');
            if (domLabelShipTo) {
                // 第一版首页样式(运送和货币)
                domLabelShipTo.innerHTML = `
                        <span>${trans('base.ship_to')}</span>
                        <img src="${flagSrc}" alt="${countryName}" title="${countryName}" class="headShortcut_nalflag"> /
                        <span>${currencyCode}</span>
                    `;
            }

            const domLabelShipItem = document.getElementById('js-labelShipItem');
            if (domLabelShipItem) {
                // 第二版样式 ST （运送和货币单独分开）
                domLabelShipItem.innerHTML = `${countryName}`;

                // 货币
                try {
                    document.getElementById('js-labelCurrencyItem').innerHTML = `${currencySign}${currencyCode}`;
                } catch (e) {
                    // nothing
                }
            }
        }
    });

    // 订阅shipto快捷点击
    PubSub.subscribe('head.itemClick', (msg, cfg) => {
        if (cfg.logic === 'ship_currency' && !cfg.$el.data('initialized')) {

            // 生成到达国家列表
            shipToInit();

            // 初始完成
            cfg.$el.data('initialized', 1);
        }
    });
}

// google 翻译
function googleTranslate() {
    PubSub.subscribe('head.itemClick', (msg, cfg) => {
        if (cfg.logic === 'google-lang' && !cfg.$el.data('initialized')) {
            $.getScript('//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit', () => {

                $('#google_translate_element').empty();

                window.googleTranslateElementInit = () => {
                    new window.google.translate.TranslateElement({
                        pageLanguage: window.GLOBAL.LANG || 'en',
                        layout: window.google.translate.TranslateElement.InlineLayout.SIMPLE
                    }, 'google_translate_element');
                };

                // 语言组件加载完成
                cfg.$el.data('initialized', 1);
            });
        }
    });
}

// 订阅购物车触发
function simpleCart() {
    PubSub.subscribe('head.itemHover', (msg, cfg) => {
        if (cfg.logic === 'simple-cart' && !cfg.$el.data('initialized')) {
            // 购物车初始过
            cfg.$el.data('initialized', 1);

            PubSub.publish('sysUpdateSampleCart');
        }
    });

    // 删除一个购物车商品
    $(document).on('click', '.js-btnDeleteItemSimpleCart', (e) => {
        e.preventDefault();
        const itemId = $(e.currentTarget).attr('data-id');
        deleteFromCart({
            itemIds: [itemId],
            success() {
                PubSub.publish('sysUpdateSampleCart');
            }
        });
    });
}


PubSub.subscribe('nativeReady', () => {
    headInit();
});
